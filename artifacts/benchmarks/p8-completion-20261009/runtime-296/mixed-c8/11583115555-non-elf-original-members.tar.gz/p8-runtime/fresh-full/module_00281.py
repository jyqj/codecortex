def stable_00281():
    return 281
