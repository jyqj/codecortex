from pathlib import Path,PurePosixPath
import json,hashlib,zipfile
BASE=Path("/workspace/scratch/bfccb8494ba0");OUT=Path("/dev/shm/pr-triage-round14-H2-publication")
PREFIX="artifacts/checkpoints/p8-a23-closeout-20261009-bfcc/round14-H2-original-v15-and-pr184-retarget"
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def info(p,repo):
 p=Path(p);b=p.read_bytes()
 return dict(local_path=str(p),repository_path=repo,bytes=len(b),sha256=sha(b),git_blob=blob(b))
def write(p,b):
 with p.open("xb") as f:f.write(b)
def js(v):return (json.dumps(v,ensure_ascii=False,indent=2)+"\n").encode()
selection_specs=[
 (BASE/"pr-triage-primary-recovery/derived-copy-migration-round15/archive-selection.json","artifacts/checkpoints/p8-a23-closeout-20261009-bfcc/round15-derived-copy-relocation/archive-selection.json"),
 (Path("/dev/shm/pr-triage-round15-pr184-review/archive-selection.json"),"artifacts/checkpoints/p8-a23-closeout-20261009-bfcc/round15-pr184-source-and-retarget-review/archive-selection.json")
]
entries=[]
for selection,repo in selection_specs:
 v=json.loads(selection.read_bytes());assert v["file_count"]==len(v["files"])
 assert sum(x["bytes"] for x in v["files"])==v["total_bytes"]
 for e in v["files"]:
  p=Path(e["local_path"]);a=info(p,e["repository_path"])
  assert all(a[k]==e[k] for k in ("bytes","sha256"))
  if "git_blob" in e:assert a["git_blob"]==e["git_blob"]
  entries.append(a)
 entries.append(info(selection,repo))
for name in ["actual-H2-and-v15-dispatch.json","H2-actual-original-v15-terminal.json","PR184-actual-retarget.json","native-H2-transfer/transport-receipt.json"]:
 entries.append(info(BASE/"root-round14"/name,PREFIX+"/root-records/"+name))
for name in ["review-H2-original-evidence.py","independent-H2-original-v15-review.json","existing-three-archive-byte-verification.json","package-checkpoint.py"]:
 entries.append(info(OUT/name,PREFIX+"/independent-review/"+name))
assert len(entries)==21 and len({x["repository_path"] for x in entries})==len(entries)
for e in entries:
 n=PurePosixPath(e["repository_path"]);assert not n.is_absolute() and ".." not in n.parts and str(n)==e["repository_path"]
payload_manifest={"schema_version":1,"scope":"Original selected bytes are unchanged. Repository paths of migration and PR184 selections are preserved; original three ZIPs are separately uploaded, not nested or recompressed.","file_count":len(entries),"total_bytes":sum(x["bytes"] for x in entries),"files":entries}
mp=OUT/"selected-originals-manifest.json";write(mp,js(payload_manifest))
zpath=OUT/"H2-review-migration-and-PR184-selected-originals.zip"
with zipfile.ZipFile(zpath,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for e in entries+[info(mp,PREFIX+"/selected-originals-manifest.json")]:
  b=Path(e["local_path"]).read_bytes();assert len(b)==e["bytes"] and sha(b)==e["sha256"]
  zi=zipfile.ZipInfo(e["repository_path"],(2026,10,9,0,0,0));zi.create_system=3;zi.external_attr=(0o100644<<16);zi.compress_type=zipfile.ZIP_DEFLATED
  z.writestr(zi,b)
with zipfile.ZipFile(zpath) as z:
 expected={e["repository_path"]:e for e in entries+[info(mp,PREFIX+"/selected-originals-manifest.json")]}
 assert len(z.infolist())==len(expected) and set(z.namelist())==set(expected)
 for i in z.infolist():
  b=z.read(i);e=expected[i.filename];assert len(b)==e["bytes"] and sha(b)==e["sha256"] and blob(b)==e["git_blob"]
uploads=[
 info(BASE/"root-round14/native-H2-transfer/native-public-api-H-and-H2-original-v15.zip",PREFIX+"/native-public-api-H-and-H2-original-v15.zip"),
 info(Path("/dev/shm/todo-audit-pr180-mainb941-H2-readback.zip"),PREFIX+"/todo-audit-pr180-mainb941-H2-readback.zip"),
 info(BASE/"scale-intake-primary/H-historical-input-preparation.zip",PREFIX+"/H-historical-input-preparation.zip"),
 info(zpath,PREFIX+"/"+zpath.name)]
readme="""# H2 original v15 and PR184 metadata checkpoint

This append-only checkpoint retains the original H/H2 preparation, actual H2 selected v15 execution, independent H2 source readback and original historical-input preparation. Publication was prepared locally against the previously supplied checkpoint parent prefix cd5c; root alone resolves the actual current publication parent and performs Git writes. This packaging did not mutate a branch, source file, existing selection, or prior evidence.

H 399a71a4c11e7041ce9946fba4d3f72200c47155 was prepared only. The actual native CLI ran once on H2 e5640904298febdf8dc951e0baddb2819f930c0b, tree 73b93b60865daf5d9b6b02afa8974688c64191a4, with ordered parents H and current-main-at-the-time b9412406e11422d7cf914458a8bfbbd58cf94eaa. Its product/review/guard remained c92/f89/b2bb. It ran python3 scripts/verify_reviewed_source_v15.py --source-version p8-completion-source-20261009-v15 from 2026-10-09 11:17:17.309941 UTC to 11:27:36.309324 UTC, actual integer child exit 0, elapsed 618.988764334 seconds. The 572-byte original stdout says passed, 1093 complete inputs, and executed previous v14 proof; stderr is empty.

Independent retained-evidence review checked all 58 ZIP members (57 original files plus their manifest), CRCs, hashes and the already extracted bytes. The exact 1435-entry before/after domain is byte-identical: initial 1246 entries plus 236 original protected historical entries with 47 overlapping paths. Each retained mode/blob matches original Git ls-tree output; all 1093 product and 139 validation entries also match the actual c92 canonical R inventory. The 236 historical entries match the original immutable BASE. This is the selected admission domain, not the entire repository.

This result is the original selected v15 CLI and its previous v14 proof. It does not assert the 181-method suite, Rust engineering tests, a formal scale study, actual DB acquisition observations, or original TODO closure. New combined P3ced and any later corrective source or controls are wholly separate and receive no result from this checkpoint.

PR184 was actually retargeted to main at 11:16:03 UTC, with head b715 unchanged, still open/draft. Its archived source review was read-only; the 11+5+5 source controls were pending at that review. Metadata retargeting is not a source change or a test pass. The prior PR181 external merge and H2 preservation are kept in their original time and source scopes.

The derivative-copy relocation evidence records 2890 files / 899258375 content bytes moved from this agent's reconstructed extraction directories to RAM, with source/destination SHA and mode checks and compatibility locators. Original Library-materialized ZIPs, unique evidence, failures and existing selections were not deleted. The existing 1 GiB intake threshold was unchanged. RAM remains transient; the preserved restoration map and original ZIPs provide the recovery path.

Three existing ZIPs are uploaded byte-for-byte, without recompression: native H/H2 originals, independent H2 readback, and historical-input preparation. The new selected-originals ZIP contains only the original migration/PR184 selections and their members, root's four frozen operation receipts, and this independent byte-review/packaging support. Its member names are full repository-relative paths, so extract that ZIP at an empty repository-root layout to preserve the exact paths declared in the old selections. Extract each of the three existing ZIPs into its own empty directory according to its embedded manifest; their layouts differ. All ZIPs have been CRC-read and all embedded manifest bytes/SHA values independently checked. No archive member requires absolute-path or parent-directory traversal.

The small publication manifest and upload index record each uploaded file's byte count, SHA-256 and Git blob OID. Every upload is at most 8 MiB. The selected ZIP's internal selected-originals-manifest lists all 21 originals; the manifest itself is the 22nd ZIP member. No signed download URL or temporary transport cookie is introduced by this package.

Original ledger remains 163 done / 29 remaining, with zero new original TODO completions from this checkpoint. The fixed Gc8 study and the original P8-007 DB lock-wait gap retain their separate records and acceptance conditions.
"""
rp=OUT/"README.md";write(rp,readme.encode());uploads.append(info(rp,PREFIX+"/README.md"))
pub={"schema_version":1,"prefix":PREFIX,"publication_parent_hint":"cd5c (root must resolve the actual fresh parent before publishing)","remote_mutations_by_packager":False,"source_inputs_modified":False,"existing_zip_bytes_reused":True,"new_zip_original_file_count":21,"new_zip_member_count":22,"new_zip_expanded_bytes":sum(e["bytes"] for e in expected.values()),"new_zip_all_CRC_and_manifest_hashes_verified":True,"existing_three_zip_review_reference":PREFIX+"/independent-review/existing-three-archive-byte-verification.json inside selected-originals ZIP","preparation_note":"An initial code-orchestration request was rejected by JavaScript parsing (Unexpected identifier cd5c) before any tool call or file creation. Corrected quoting then prepared this package. No native command, workload, remote mutation, or original file was affected.","files":uploads,"TODO_done":163,"TODO_remaining":29,"new_TODO_completions":0}
pm=OUT/"publication-manifest.json";write(pm,js(pub));uploads.append(info(pm,PREFIX+"/publication-manifest.json"))
assert all(x["bytes"]<=8*1024*1024 for x in uploads)
for e in uploads:
 b=Path(e["local_path"]).read_bytes();assert len(b)==e["bytes"] and sha(b)==e["sha256"] and blob(b)==e["git_blob"]
index={"schema_version":1,"prefix":PREFIX,"scope":"Frozen local upload plan only; root owns all Git mutations. Exact original files and selections retained; no CLI/workload rerun or P3ced execution credit.","file_count":len(uploads),"total_bytes":sum(x["bytes"] for x in uploads),"maximum_upload_bytes":8*1024*1024,"files":uploads,"index_repository_path":PREFIX+"/upload-index.json","index_self_hash_not_included":True}
ip=OUT/"upload-index.json";write(ip,js(index))
for p in [OUT/"independent-H2-original-v15-review.json",zpath,ip]:
 print(json.dumps(info(p,PREFIX+"/"+p.name)))
print(json.dumps({"upload_count_without_index":len(uploads),"upload_bytes_without_index":index["total_bytes"],"selected_zip_original_files":21,"selected_zip_members":22,"exit_code":0}))

