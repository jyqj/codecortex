def stable_00344():
    return 344
