def stable_00473():
    return 473
