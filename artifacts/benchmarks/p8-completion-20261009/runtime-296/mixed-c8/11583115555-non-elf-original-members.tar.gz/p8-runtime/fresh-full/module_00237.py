def stable_00237():
    return 237
