from pathlib import Path
import json,math,hashlib
r=Path('/workspace/independent-comparison-review'); probes=json.loads((r/'probes.json').read_text()); results={'query_api_pairs':0,'common_hits':0,'changed_bonus':{},'rank_metadata_changes':[],'regression':[],'scores':[],'boundary_checks':len(probes)}
# Independent contract assertions on real production modules; wrapper changes no production source.
direct={a:{x['query']:x for x in json.loads((r/f'{a}-probes.json').read_text())} for a in ['candidate','delivery']}
for p in probes:
 x=direct['delivery'][p['query']]
 for f in x['flags']:
  assert f['other'],(p,f)
  assert f['owner']==(not p['expected_owner_suppressed'] if f['kind'] in ['class','interface','type_alias','enum','module','namespace'] else True),(p,f)
 assert direct['candidate'][p['query']]['target']==x['target'],p
results['direct_probes_passed']=True
for variant in ['base','receiver','inversion']:
 arms={a:json.loads((r/f'results/{a}-{variant}/results.json').read_text()) for a in ['base','candidate','delivery']}
 assert len({x['source_text'] for x in arms.values()})==1
 assert arms['base']['queries'].keys()==arms['candidate']['queries'].keys()==arms['delivery']['queries'].keys()
 for q in arms['delivery']['queries']:
  for api in ['engine','mcp']:
   results['query_api_pairs']+=1
   entries={a:obj['queries'][q][api] for a,obj in arms.items()}
   hits={a:{h['chunk_id']:h for h in e['raw']['machine_pack']['hits']} for a,e in entries.items()}
   assert hits['base'].keys()==hits['candidate'].keys()==hits['delivery'].keys(),(variant,q,api,'returned identities')
   norm={a:{(h['path'],h['start_line'],h['end_line'],h['symbol_name'],h['kind']):h for h in e['normalized']} for a,e in entries.items()}
   assert norm['base']==norm['candidate']==norm['delivery'],(variant,q,api,'source evidence')
   for before in ['base','candidate']:
    for cid,x in hits[before].items():
     y=hits['delivery'][cid];results['common_hits']+=1
     for key in x:
      if key not in ['metadata','score_trace','rerank_score','reasons']:assert x[key]==y[key],(variant,q,api,cid,key)
     for key in x['metadata'].keys()|y['metadata'].keys():
      if key=='evidence_priority':
       if x['metadata'].get(key)!=y['metadata'].get(key):results['rank_metadata_changes'].append([variant,q,api,before,cid])
      else:assert x['metadata'].get(key)==y['metadata'].get(key),(q,key)
     assert [t for t in x['score_trace'] if t[0]!='boost:symbol-exact']==[t for t in y['score_trace'] if t[0]!='boost:symbol-exact']
     assert [t for t in x['reasons'] if t!='symbol-exact']==[t for t in y['reasons'] if t!='symbol-exact']
     for h in [x,y]:assert math.isclose(sum(v for _,v in h['score_trace']),h['rerank_score'],abs_tol=1e-9)
     if x['score_trace']!=y['score_trace']:
      assert x['symbol_name']=='Beacon' and x['symbol_kind']=='class' and 'exact-target' not in x['reasons']
      delta=y['rerank_score']-x['rerank_score'];assert math.isclose(delta,-.18 if before=='base' else .18,abs_tol=1e-9)
      results['changed_bonus'].setdefault(before,[]).append([variant,q,api,cid,delta])
     else:assert x['rerank_score']==y['rerank_score'] and x['reasons']==y['reasons']
   if q in direct['delivery']:
    expected=direct['delivery'][q]['context']==direct['candidate'][q]['context']
    a='candidate' if expected else 'base'
    for key in ['normalized','status','scores']:assert entries[a].get(key)==entries['delivery'].get(key),(q,key,a)
    assert entries[a]['raw']['machine_pack']['hits']==entries['delivery']['raw']['machine_pack']['hits'],(q,a,'ordered hits')
   if q=='Which Beacon API rather than Sink accepts state?':
    tops={a:next(iter(h.values()))['symbol_name'] for a,h in hits.items()};assert list(tops.values())==['Beacon','Sink','Beacon'];results['regression'].append([variant,api,tops])
   if q in ['Which Beacon API changes the ready state with Commit?','Which method on Beacon changes the ready state with Commit?']:
    scores={a:e['scores'] for a,e in entries.items()};results['scores'].append([variant,q,api,scores])
    if variant=='receiver':assert scores['base']['top1']==0 and scores['delivery']['top1']==1
    if variant=='inversion' and ' API ' in q:assert scores['delivery']['top1']==0
 assert arms['candidate']['top_k_1']['machine_pack']['hits']==arms['delivery']['top_k_1']['machine_pack']['hits']
results['input_sha256']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in r.glob('results/*/results.json')}
(r/'comparison.json').write_text(json.dumps(results,indent=2));print('PASS',results['query_api_pairs'],'query/API triples;',results['common_hits'],'common hit checks;',len(probes),'direct boundary probes')
print('bonus changes',{a:len(v) for a,v in results['changed_bonus'].items()},'rank metadata',len(results['rank_metadata_changes']))
