def stable_00021():
    return 21
