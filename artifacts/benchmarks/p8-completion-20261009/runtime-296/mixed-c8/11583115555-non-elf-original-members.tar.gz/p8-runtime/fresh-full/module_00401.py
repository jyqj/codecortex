def stable_00401():
    return 401
