#!/usr/bin/env python3
"""Finite transport custody using unchanged reviewed v2 ZIP functions; no API/workload."""
from pathlib import Path
import hashlib, importlib.util, json, shutil
HERE=Path(__file__).resolve().parent
MOD=Path('/dev/shm/execution-recon-recovery-20261009/intake_once.v2.py')
assert hashlib.sha256(MOD.read_bytes()).hexdigest()=='61f4ae48bc84dbc9f90862a80d06a8268ec4aa93f83c75582b716bc32f4c3369'
spec=importlib.util.spec_from_file_location('retained_zip_transport_v2',MOD);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
run=json.loads((HERE/'github-api/C3ff-run.json').read_bytes());index=json.loads((HERE/'github-api/C3ff-artifacts.json').read_bytes())
assert run['id']==37910924354 and run['head_sha']=='3ffcefc3b28ee1a4ed80caecebd7208a45c3e302' and run['run_attempt']==1 and run['event']=='pull_request' and run['path']=='.github/workflows/p8-scale.yml'
items=[(11626430756,'p8-scale-shard-100000-0-C3ff-37910924354-original.zip','p8-scale-shard-100000-0-37910924354'),(11626127365,'p8-scale-matrix-C3ff-37910924354-original.zip','p8-scale-matrix-37910924354')]
results=[]
for aid,filename,name in items:
 out=HERE/'raw'/str(aid)/'attempt01';out.mkdir(parents=True,exist_ok=False)
 source=Path('/workspace/scratch/bfccb8494ba0/round20-C3ff-failed-originals')/str(aid)/'attempt01'/filename
 assert source.is_file() and not source.is_symlink()
 meta=next(x for x in index['artifacts'] if x['id']==aid);assert meta['name']==name and not meta['expired']
 assert meta['workflow_run']['id']==run['id'] and meta['workflow_run']['head_sha']==run['head_sha']
 before=m.sha(source)
 with source.open('rb') as s,(out/'original.zip').open('xb') as d:shutil.copyfileobj(s,d,1024*1024)
 assert before==m.sha(source)==m.sha(out/'original.zip')
 m.write_new(out/'github-metadata.json',meta);m.write_new(out/'run-binding.json',{'run_id':run['id'],'source':run['head_sha'],'run_attempt':1,'event':'pull_request','workflow_path':run['path'],'note':'C3ff pull_request identity checked explicitly. Original v2 Gc8 workflow_dispatch binding functions are inapplicable and not invoked or modified.'})
 digest,verified=m.verify_zip_identity(out/'original.zip',meta,out);assert verified
 members=m.extract_original(out/'original.zip',out/'extracted')
 m.write_new(out/'zip-members.json',{'members':members,'member_count':len(members),'total_uncompressed_bytes':sum(x.get('bytes',0) for x in members)})
 assert m.sha(out/'original.zip')==digest==m.sha(source)
 result={'artifact_id':aid,'official_name':name,'materialized_original':str(source),'RAM_original':str(out/'original.zip'),'extracted':str(out/'extracted'),'bytes':meta['size_in_bytes'],'sha256':digest,'member_count':len(members),'uncompressed_bytes':sum(x.get('bytes',0) for x in members),'v2_verify_zip_identity_and_extract_original_unchanged':True,'source_copy_readonly':True,'measurements_or_acceptance_credit':False,'posix_mode_caveat':'v2 records original ZIP external_attr and receiver mode separately; does not claim receiver POSIX modes are identical.'}
 m.write_new(out/'materialized-to-RAM-transport-receipt.json',result);results.append(result)
m.write_new(HERE/'two-original-intake-summary.json',{'schema_version':1,'source':run['head_sha'],'run_id':run['id'],'attempt':1,'receiver_sha256':m.sha(MOD),'results':results,'semantic_validation':'pending','no_network_or_measurement':True})
print(json.dumps(results))
