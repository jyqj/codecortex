# b2 + G3：只读无回退整合预案

实际新 P 尚不存在。原 `b2a17adc188338c48b95d01761836916e5d0fcdb` 与 `67b7f4ee15a9c9633868b446870fec1358dda3d9` 的源码和运行身份保持各自独立。当前 PR188 的工程验证仍属于 G3，不能先标为本组合通过。

使用 b2 完整树 `8e82c2c60188148f91c2c8bfa58c1e158a94b8af` 为 base，仅加入四叶即可：我方 SQL v3 两产品文件，以及 R3 canonical JSON 与其原支持 ZIP。建议未来 P 的 ordered parents 为 `[b2, G3]`，预期树为 `5fc0327a9d2cebb7d23c47fff2f77fb714e018e7`。完整产品输入 1095，相对 BASE7354 的产品差异 71，验证输入 142。精确请求见 `prospective-four-leaf-create-tree-request.json`；它是待用数据，不是已执行的远端请求。

官方 H→b2 的 14 个 commit、42 叶变化已全部作用于原完整 H 树，重新计算得到官方 b2 tree SHA。所有叶均无丢失或 mode 回退。36 个 b2 新 artifacts、我方 2 个 R3 artifacts 均保留。双方 docs/BENCHMARK.md 已是同一 blob。任务台账仍为 Git blob `959a25ba851ff88f286bab0fa14167878129b1dd`；未更新状态或定义。

| 区域 | 本组合采用的字节与边界 |
|---|---|
| resolution_dependency_store.rs、p2b_resolution_store.rs | G3 / P3f 的两个 v3 原 blob，保留任意 excluded、全局 sorted/distinct cap+1 witness、原 read lease 和 cap。没有重新编辑。 |
| preselect.rs | b2 的 `acee54f…`。仅在图邻居最终得分相等时用路径排序，然后执行既有 truncate；新两个测试检查同分稳定裁切及分数优先。没有修改上游 top-20 seed 排序、DAO 数量上限或权重。不能据此宣称所有检索 tie 都已确定化。 |
| cc-eval/tests/p8_scale.rs | b2 的 `02dc35…`。fixture 增加一次无 descendant 的独立预热分支；保留受监督正式调用的 250ms 与 2s 墙钟断言、原 1ms deadline 负例，增加 worker exit 与 summary passed 断言。生产 supervisor 和 study budget 均未改。 |
| p8-db-lock-observation.yml | b2 的 `be748a…`。增加仅指定 a217 分支的 push 触发与相同 job 条件；原四 C、900 operations、1000 files、500ms 和 90min 均未变。普通其他分支 push 不匹配这个新增条件；显式 workflow_dispatch 仍有原效力。不能凭本审查启动诊断。 |
| registry / guard | 未来 P 暂保 b2 两文件原字节整对。它们绑定旧 a29f/fdce/M6，**不接受新 SQL 组合**。G3 旧绑定保存在 G3 parent 中。新 P 实际创建并由非作者完成 1095/71/142 的审查后，才能另建 R 和仅四 pin / 必需 registry 字段的新 G。 |

三个 b2 新源码/验证 blob 已经由官方 GitHub fetch_blob 唯一接收，并逐字重算 Git blob 和 SHA256。官方 patch 反向得到的三个 H preimage 与既有 H Git blob 均相同，再正向重放得到逐字相同的 b2 字节。两 b2 原绑定由官方 patch 重构后也与官方 blob 相等；guard 除四个 pin 外完全同原算法。b2 registry 的 71 条 before_sha256 与本预案全部相等，完整 142 验证 map 相等；产品 SHA 仅我方 SQL 两项不同。以上是静态字节核对，不是执行 source validator。

最小相关工程回归范围如下。此处给的是现有测试的归属与选择建议，不增加任务验收门、不启动命令，也不要求同一结果已被普通 CI 覆盖后再次本地重复：

| 原测试入口 | 静态范围 | 与本组合的关联 |
|---|---:|---|
| `cargo test -p cc-db --test p2b_resolution_store --locked -- --nocapture` | 9 个声明测试，无 ignored/cfg 跳过 | 新 2 个 SQL 排除控制加原 7 个，包括跨批 cap+1、原公共 catch+commit 70 前缀、替换失败不发布、generation 与 manifest。成功 eprintln 可保留真实 Rust SqlWork；Python SQL 设计探针不能替代。 |
| `cargo test -p cc-search --lib preselect::tests --locked` | 22 个声明测试 | 新 2 个 tie 控制与原 20 个 recall、budget、去重及 layer 行为。限定单 seed 的新 fixture 无法证明上游 seed 截断的另一个政策。 |
| `cargo test -p cc-eval --test p8_scale --locked subprocess_` | 原 2 个最直接 supervision 控制 | 1ms 失败/禁止复用与 250ms descendant stderr 成功场景，直接检测新的 fixture preflight 是否掩盖实际错误。该完整 test binary 仍有原 12 个测试，全部由现有普通 CI 的 workspace/all-targets 覆盖。 |
| 原 fmt / strict Clippy / source-integrity / selected v15 | 原 CI 原入口 | 手工 v3 从未声称 rustfmt 通过。新组合必须以实际源接受原格式、编译和原 source admission；可复用原 CI 真实结果，不能挪用 G3 或 b2 的绿色状态。 |

原 `.github/workflows/ci.yml` 与 H/G3 完全同一 blob，普通 pull_request 的 workspace/all-targets 包含上述 9+22+12 个声明测试及原普通回归。本预案不删 CI 步骤、不额外新增 workflow 或 CI gate。若以后明确只需先定位故障，可使用表中既有目标；最终按仓库原必需检查实际验收。

组合源码没有已观察到的路径冲突。仍有两项明确限制：SQL 的 dense-prefix VM 改善尚待真实 Rust 执行，设计探针中的 scattered/two-key VM +22.57% 反例保留；preselect tie-break 会改变过去任意同分截断的结果，这是预期的排序变化，不能从旧 raw 倒推新检索结果。这里既不认可通用性能收益，也不声称解除原 5h 大容量阻塞。

工程组合不以“另开一整套 150 GitHub jobs”作为通用前置。P8-005/006 的原五容量、完整增量/独立 fanout/oracle 证据仍未满足；已经开始的固定 source/N/阶段/预算 cohort 不能改协议、拼不同 source 样本或把失败重标为通过。关于原任务文字与既有 N30/150 分片/1500 样本协议的区别，沿用已封 `original-ten-critical-path-review-v2.json`，没有在此重新解释为更松或更严的门。

在实际实施前，由 root 重新确认 PR180 head 与当前 main；若有后续变化，保留其具体字节与 ancestry，不能用此冻结 b2 请求覆盖新 head。本次没有获取新性能 artifact、运行 Rust/Python 产品测试、调用 v15、创建 Git 对象或修改远端。
