def stable_00174():
    return 174
