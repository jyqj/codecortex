# P8 工程验证原件档案

本档案保留已经完成的历史工程验证；不改原始文件内容，不把旧源码结果重标为最终 CI 的源码。

## 内容与版本

- recovery/full-matrix-de04：de04d4c 的真实恢复矩阵、原 Rust 故障执行日志、stdio/HTTP raw、数据库与 runner 源码快照。
- rollback：原公开源码 277f2490 的构建回执，以及当前 de04/schema25 与历史 schema24 的两次真实四阶段版本回滚。第一次 runner 仅存 SHA，未冒用后版代码；closing-regression 精确对应 e5172ec。
- lifecycle：三份各10样本的原始 debug smoke。第一版 observer/evaluator 原件部分缺失，详见 observer-source 映射。第二份与 post-close 的实际 observer 字节按记录 SHA 恢复。前两份32KiB SHM统计缺口原样保留；post-close 的733184字节终态与29文件封存保留。均不认证 actual release CLI。
- scale：99f95742 的22项真实 release tests、60文件/10样本烟测原件，以及1000文件预检的 reexport_depth_budget_exceeded 原始失败；新修复不冒充这些旧执行已通过。
- reviews：独立审查报告及其准确范围。
- git：仅本轮7个本地 task 分支的固定快照增量 bundle，排除7354db23及其可达历史。

完整分类、原路径映射及每个文件 SHA/长度见 classifications.json、manifest.json 与 SHA256SUMS。manifest.json 自身的 SHA 在 SHA256SUMS；校验表不包含自身。原回执中的绝对路径保持原样；读取归档文件时按 manifest 的 origin 映射定位。

## Git 复核

先准备包含基线7354db236c9d9850a75f31672697ae9eab44565e及其历史的 codecortex checkout，再运行：

```bash
git bundle verify /absolute/path/git/local-p8-task-branches.bundle
git bundle list-heads /absolute/path/git/local-p8-task-branches.bundle
git fetch /absolute/path/git/local-p8-task-branches.bundle 'refs/heads/task/*:refs/remotes/p8-engineering-archive/*'
```

branch-and-commit-map.json 保存快照时7个分支、全部本轮提交及父提交/树身份。GitHub插件的平铺发布可以产生另一个 P；本 bundle 保存原本地来源，不将二者混同。

大二进制和 Cargo target 按要求不包含在紧凑档案内。此档案可审阅原始观测与代码来历，不能在缺少这些外部前提时声称完全自包含重跑。只遍历明确列出的合成夹具证据目录；不读取或复制 heldout corpus body。
