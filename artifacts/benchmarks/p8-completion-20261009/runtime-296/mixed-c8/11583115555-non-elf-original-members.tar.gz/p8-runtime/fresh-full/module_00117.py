def stable_00117():
    return 117
