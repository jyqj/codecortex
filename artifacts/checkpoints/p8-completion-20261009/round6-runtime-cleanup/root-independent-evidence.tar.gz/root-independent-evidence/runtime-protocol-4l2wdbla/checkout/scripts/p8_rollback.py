# committed protocol-control fixture: scripts/p8_rollback.py
