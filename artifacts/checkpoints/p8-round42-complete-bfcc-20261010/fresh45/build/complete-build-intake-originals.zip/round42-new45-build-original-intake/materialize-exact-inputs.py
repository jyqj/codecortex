import json,pathlib,subprocess,time,datetime,hashlib
D=pathlib.Path('/workspace/scratch/bfccb8494ba0/round42-new45-build-original-intake')
V=D/'source-exact-G2'
binding=json.loads((D/'recovered-contract/binding.template.json').read_text())
patterns=['/Cargo.toml','/Cargo.lock','/crates/']+['/'+x for x in binding['observer_inputs']]
(V/'.git/info/sparse-checkout').write_text('\n'.join(patterns)+'\n')
commands=[['git','config','core.sparseCheckout','true'],['git','config','core.sparseCheckoutCone','false'],['git','checkout','--detach','f97c5068d056969705e8387ba1f37d83847f5bee']]
for i,argv in enumerate(commands):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 with (D/f'materialize-{i}.stdout').open('wb') as out,(D/f'materialize-{i}.stderr').open('wb') as err:
  try: code=subprocess.run(argv,cwd=V,stdout=out,stderr=err,timeout=180).returncode
  except subprocess.TimeoutExpired:code=124
 r={'argv':argv,'cwd':str(V),'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_seconds':time.monotonic()-t,'exit':code}
 (D/f'materialize-{i}.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
 if code:raise SystemExit(code)
original=json.loads((D/'original-build/native-build/source-before.json').read_text())
inventory={}
for name,sha in original['inputs'].items():
 p=V/name;b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==sha,name
 inventory[name]={'bytes':len(b),'sha256':sha,'mode':oct(p.stat().st_mode&0o777)}
for name,spec in binding['observer_inputs'].items():
 p=V/name;b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==spec['sha256'],name
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==spec['git_blob'],name
 inventory[name]={'bytes':len(b),'sha256':spec['sha256'],'mode':oct(p.stat().st_mode&0o777)}
assert len(original['inputs'])==1096 and len(inventory)==1107
r={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=V,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=V,text=True).strip(),'source_count':len(original['inputs']),'observer_count':11,'inventory':inventory,'validators_run':False}
assert r['head']==binding['source'] and r['tree']==binding['source_tree']
(D/'restored-source-inventory.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='inventory'}),flush=True)
