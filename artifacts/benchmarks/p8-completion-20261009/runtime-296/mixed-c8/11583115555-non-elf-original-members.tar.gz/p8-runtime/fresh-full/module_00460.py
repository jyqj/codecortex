def stable_00460():
    return 460
