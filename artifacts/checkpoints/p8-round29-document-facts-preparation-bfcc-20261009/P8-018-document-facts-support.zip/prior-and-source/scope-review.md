# P8-018：文档事实与安装契约的有界核查

本次发现并准备修正一处真实文档漂移：`docs/BENCHMARK.md:38` 将当前 `mutation-case` 对照面写成“十四表”，实际 `oracle.rs:12–28` 的共享表清单已有 15 表，`mutation_case.rs:130,170–173,212` 直接使用该清单。候选只将该表述改为“当前 15 表统一投影”并链接到源文件；命令、测试、产品及原性能口径不变。

候选以固定主线 `51138c236cf2ed47858e2306f9c7bfd3600aaef9` 的原文为基础。Root 已确认新主线 `379099a4a7b09ebe9928c190017bae53d8d1edf6` 仅增加 P8-005 的五个任务进度文档变化；本次 BENCHMARK 文件和所有被引用产品声明未变。P8-005 已完成后的总数为 164/192，剩余 28；本候选不增加完成数。

## 原任务逐项对应

| 原要求 | 现有实际证据与本次发现 | 目前处理 |
| --- | --- | --- |
| 从 schema/capabilities 生成可核查事实 | `scripts/p8_facts.py` 从九个明确源文件提取声明；`P8-FACTS.md` 保留受管表和生成器限制。原 PR196 实际主检查日志第 5777 行输出 `status=passed`、`errors=[]`、`runtime_certified=false` 和九输入 SHA256。 | 已有声明事实检查；没有重新执行生成器。 |
| 文档表数/schema/工具数不再漂移 | 固定源及该真实输出一致：8 crates、schema 25、30 显式普通表、5 FTS5、14 MCP 工具。另发现 BENCHMARK 的 oracle 表数 14→15 漂移，原生成器的受管范围没有覆盖这一句。 | 已准备唯一文档修正，尚未合入。 |
| 更新安装、故障、默认离线说明 | README/TROUBLESHOOTING 已说明 Codex 结构化 TOML 更新、保留用户选项、无效配置不写入、命令任一目标失败返回非零。P8-FACTS/CONFIGURATION 区分语义关闭、普通本地索引写入、网络授权和 query 文本外发。 | 当前范围没有再发现需要改写的安装契约。 |
| 设计与已实现分开 | P8-FACTS 明确不声称交付不存在的 runtime schema/defaults 文件；声明抽取不等于运行时 schema 导出，工具注册不等于真实 provider 认证，旧轮安装“未执行”的历史描述保留其原身份。 | 不把历史说明改写为后来执行。 |
| 相关旧功能回归通过 | PR196 的同树固定执行已经通过 installer 56、CLI 5；原完整日志还实际包含 14 工具参数兼容、tools/schema/status、旧 modes、默认语义关闭的真实 stdio 控制，详见下文行号。 | 复用各自原执行范围；没有重跑旧回归。 |
| V18/V21 及 P8-017 依赖 | 原 V18 含工具/模式/参数贯穿及默认离线；V21 含 schema 降级重建、cache、两包、SDK/MSRV、文档漂移。既有平台/恢复/安装证明各有来源，不能只用本次声明输出宣称整个 V18/V21 或发行认证。P8-017 尚未完成。 | `apply_now=false`，任务仍 in_progress。既有证据应按适用组件关联，不增设全套重测要求。 |

## 实际原日志依据

完整原 PR196 主检查日志已持久为 Git blob `907b9a33cb22d7a13b947e4fac6aaa121c594d55`（1,081,030 UTF-8 bytes）。此前独立源/执行桥确认实际测试合并 checkout `dac7d9…` 的完整 tree `24df8be11955fda1f2e320de483e9eb4ddd1ffb3` 与 PR196 产品/主线51138相等；完整旧审查支持 ZIP 为 `1fc494aa4dc149d4c85b97b4bb8ec2dfd9aa024a`。本次只读同一旧日志，不重新下载 Actions 工件、不执行产品。

- 第 1550 行：`all_fourteen_parameter_types_deny_unknown_and_keep_default_requests ... ok`。
- 第 3975 行：`handle_status_all_includes_capabilities_and_schema ... ok`。
- 第 4480 行：`stdio_status_capabilities_and_schema ... ok`。
- 第 4710 行：`advertised_schema_keeps_fourteen_tools_and_optional_strategy_defaults ... ok`。
- 第 5777 行：原 `p8_facts.py --check` JSON 为 `passed`，全部错误列表为空，范围为 `declared_documentation_facts_only`。
- 第 8321 行：`p7_offline::real_stdio_default_disabled_semantic_contract ... ok`。
- 第 8411 行：`p1c_fourteen_tools_valid_unknown_schema_and_modes ... ok`。
- 第 9668 行：另一原调用组的默认关闭 stdio 同名控制通过；不与前项相加声称独立测试数。

该日志未出现名为 `test_p8_facts` 的用例，故不将旧任务 notes 中的“13 CLI 正负例”冒称为本次这份 CI 的 13 项。原命令输出本身已经证明事实检查实际执行；其他历史正负控制保留原时间/source。

## 当前主线与 b8ab 的边界

`b8ab8ecdc5b32993fc02ce43877b7e172b8a4b3f` 是独立候选，包括冷/宽脏研究入口、payload 优化和双 spool 兼容恢复等变化；这些不作为主线51138的已发布行为。当前文档修正来自主线已经存在的统一表清单，不依赖 b8ab 合入或其研究成功。本次不更改 P8 协议、cache/deadline、样本及受保护任务定义。

## 结束条件与当前交付

可独立推进的实际剩余修改就是这一处文档纠正；本次没有发现需要新增生产实现的事实/安装缺口。候选完成非作者文档审查并整合后，保留原 `p8_facts` 及已有相关回归的具体范围即可，不因此要求重跑规模实验。任务结项仍须等待原 P8-017 依赖，以及将已有适用 V18/V21 组件证据准确关联到最终声明；本报告本身不是全部验证包的验收。

`candidate-source-proof.json` 记录原 blob `cb85c58cdac336950612498c4ed638c99d7f689e`、候选 blob `69827051bc4e27c91d2061e1b80ee8b1c5db0e0f` 和唯一替换。`pending-closeout.json` 保持 `apply_now=false`。没有修改 tasks、其余任务、源绑定或任何 ref。
