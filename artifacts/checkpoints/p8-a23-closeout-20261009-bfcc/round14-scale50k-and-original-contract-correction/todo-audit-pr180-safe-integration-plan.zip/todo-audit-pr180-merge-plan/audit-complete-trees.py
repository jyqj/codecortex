#!/usr/bin/env python3
"""Read official Git tree metadata and immutable patch bytes; write derived audit only."""
import copy
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
IN = Path('/workspace/scratch/bfccb8494ba0/root-round13/current-merge-trees-transfer/extracted')
OLD = Path('/workspace/scratch/bfccb8494ba0/pr180181-readonly')
V2 = Path('/dev/shm/todo-audit-pr180-public-dependency-fix-v2')
SPECS = {
    'base': ('mergebase840fa', '840fa2e0a26ab60c138747a4309aba5df506edc1', '54d66ff6a15661c64d2a05df48f14e9aa09fc13c'),
    'main': ('mainfd9', 'fd9ca5db6485b575872c722995c451db926d05c9', '48d9e58e8bded84e0a9d56196929f5347a6d3b94'),
    'old180': ('pr180old3ff', '3ffcefc3b28ee1a4ed80caecebd7208a45c3e302', '0e655b4258afd9ca040dd7c1ace868bf1c322a30'),
    'head180': ('pr180head4652', '4652cad11dde4b41126544a38fddf25eb2fb7474', '6737ba0b700344853b6bce17cb3ee4bd792363d5'),
    'head181': ('pr181head4866', '4866ec5558f1cedd34c7dc54231af65b77f706ec', '7236f68d4d814d4e607d8c2c774ac227a91a092b'),
}

def sha(b): return hashlib.sha256(b).hexdigest()
def encoded(x): return json.dumps(x, sort_keys=True, separators=(',', ':')).encode()
def write(name, x):
    p = OUT / name
    b = (json.dumps(x, indent=2, sort_keys=True) + '\n').encode()
    p.write_bytes(b)
    return {'path': str(p), 'bytes': len(b), 'sha256': sha(b)}
def identity(v):
    return None if v is None else (v['mode'], v['type'], v['sha'])
def different(a, b):
    return sorted(p for p in a.keys() | b.keys() if identity(a.get(p)) != identity(b.get(p)))
def leafmap(rows):
    return {r['path']: {k: r[k] for k in ('mode', 'type', 'sha', 'size') if k in r}
            for r in rows if r['type'] != 'tree'}
def compute_trees(rows, expected_root=None):
    rows = copy.deepcopy(rows)
    bypath = {r['path']: r for r in rows}
    assert len(bypath) == len(rows)
    groups = {'': []}
    for r in rows:
        parent = r['path'].rsplit('/', 1)[0] if '/' in r['path'] else ''
        groups.setdefault(parent, []).append(r)
        if r['type'] == 'tree': groups.setdefault(r['path'], [])
    identities = {}
    for directory in sorted(groups, key=lambda x: (x.count('/') + bool(x), x), reverse=True):
        items = groups[directory]
        payload = b''
        for r in sorted(items, key=lambda r: (r['path'].rsplit('/', 1)[-1] + ('/' if r['type'] == 'tree' else '')).encode()):
            name = r['path'].rsplit('/', 1)[-1]
            oid = identities[r['path']] if r['type'] == 'tree' else r['sha']
            payload += r['mode'].lstrip('0').encode() + b' ' + name.encode() + b'\0' + bytes.fromhex(oid)
        actual = hashlib.sha1(b'tree ' + str(len(payload)).encode() + b'\0' + payload).hexdigest()
        identities[directory] = actual
        if expected_root is not None:
            expected = expected_root if not directory else bypath[directory]['sha']
            assert actual == expected, (directory, actual, expected)
    return identities

maps, tree_rows, receipts = {}, {}, {}
for key, (name, commit, expected_tree) in SPECS.items():
    p = IN / (name + '.json')
    raw = p.read_bytes(); x = json.loads(raw)
    assert x['truncated'] is False
    rows = x['tree']; computed = compute_trees(rows, expected_tree)
    maps[key] = leafmap(rows); tree_rows[key] = rows
    assert all(v['type'] == 'blob' for v in maps[key].values())
    receipts[key] = {'source_commit': commit, 'expected_tree': expected_tree,
       'input': {'path': str(p), 'bytes': len(raw), 'sha256': sha(raw)},
       'api_echo_sha': x['sha'], 'recomputed_root': computed[''],
       'all_subtree_objects_verified': len(computed), 'leaf_count': len(maps[key]),
       'artifact_leaf_count': sum(p.startswith('artifacts/') for p in maps[key]),
       'normalized_leaf_map_sha256': sha(encoded(maps[key]))}

base, main, old, head, other = (maps[k] for k in ('base','main','old180','head180','head181'))
both = sorted(p for p in base.keys() | main.keys() | old.keys()
              if identity(main.get(p)) != identity(base.get(p))
              and identity(old.get(p)) != identity(base.get(p))
              and identity(main.get(p)) != identity(old.get(p)))
collisions = []
for p in main:
    if p not in old:
        if any(x.startswith(p + '/') for x in old): collisions.append(p)
for p in old:
    if p not in main:
        if any(x.startswith(p + '/') for x in main): collisions.append(p)
categories = {
    'main_only_added': sorted(main.keys() - old.keys()),
    'pr180_only_added': sorted(old.keys() - main.keys()),
    'shared_different': sorted(p for p in main.keys() & old.keys() if identity(main[p]) != identity(old[p])),
    'both_changed_and_different_from_mergebase': both,
    'file_directory_collisions': sorted(set(collisions)),
}
union = set(main) | set(old)
missing_union = sorted(union - set(head))
extra_union = sorted(set(head) - union)
artifact_errors = []
for p in union:
    if p.startswith('artifacts/'):
        options = [v for v in (main.get(p), old.get(p)) if v is not None]
        if any(identity(v) != identity(options[0]) for v in options):
            artifact_errors.append({'path': p, 'reason': 'distinct_shared_evidence_blobs'})
        elif identity(head.get(p)) != identity(options[0]):
            artifact_errors.append({'path': p, 'reason': 'existing_evidence_not_preserved'})
assert not missing_union and not extra_union and not artifact_errors
is_product = lambda p: p in ('Cargo.toml', 'Cargo.lock') or p.startswith('crates/')
validation_excluded = {'scripts/verify_reviewed_source_v15.py', 'scripts/reviewed-source-registry-v15.json', '.github/workflows/ci.yml'}
is_validation = lambda p: (p.startswith(('scripts/', '.github/workflows/', 'tests/source_integrity/'))
                         and p not in validation_excluded
                         and not ('__pycache__' in Path(p).parts and p.endswith('.pyc')))
product = lambda m: {p:v for p,v in m.items() if is_product(p)}
validation = lambda m: {p:v for p,v in m.items() if is_validation(p)}
assert product(head) == product(old)
assert validation(head) == validation(old) == validation(main)
assert all(identity(head[p]) == identity(main[p]) for p in main if p == 'README.md' or p.startswith('docs/'))

reg = json.loads((OLD/'registry180.json').read_text())
regmain = json.loads(Path('/dev/shm/todo-audit-pr-refresh-175-179/source/p179_new/reviewed-source-registry-v15.json').read_text())
assert len(product(head)) == len(reg['complete_inputs']) == 1092
assert len(validation(head)) == len(reg['validation_inputs']) == 139
assert reg['validation_inputs'] == regmain['validation_inputs']
assert set(product(head)) == set(reg['complete_inputs'])
manifest = json.loads((V2/'source-manifest.json').read_text())
virtual_rows = copy.deepcopy(tree_rows['head180'])
virtual_by_path = {r['path']:r for r in virtual_rows}
virtual_reg = copy.deepcopy(reg)
patch_rows = []
for entry in manifest['modified_files']:
    p = entry['path']; before, after = entry['before'], entry['after']
    b = (V2/'candidate'/p).read_bytes()
    assert len(b) == after['bytes'] and sha(b) == after['sha256']
    assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest() == after['git_blob']
    assert head[p]['sha'] == before['git_blob'] and head[p]['mode'] == after['mode']
    assert reg['complete_inputs'][p] == before['sha256']
    virtual_by_path[p]['sha'] = after['git_blob']; virtual_by_path[p]['size'] = after['bytes']
    virtual_reg['complete_inputs'][p] = after['sha256']
    virtual_reg['delta'][p]['sha256'] = after['sha256']
    assert virtual_reg['delta'][p]['before_sha256'] != after['sha256']
    patch_rows.append(entry)
virtual_tree = compute_trees(virtual_rows)['']
prospective = {
    'kind': 'read_only_virtual_product_not_a_commit_or_execution',
    'expected_parent': SPECS['head180'][1], 'commit': None,
    'predicted_tree_without_any_archive_additions': virtual_tree,
    'base_source': reg['base_source'], 'complete_inputs': virtual_reg['complete_inputs'],
    'delta': virtual_reg['delta'], 'validation_inputs': virtual_reg['validation_inputs'],
    'counts': {'product': 1092, 'delta': 52, 'validation': 139},
    'modified_files': patch_rows,
    'old_P_R_G_evidence_credit_transferred': False,
}
prospective_record = write('prospective-product-input-maps.json', prospective)

old181reg = json.loads((OLD/'registry181.json').read_text())
new181reg = json.loads((OUT/'181registry.raw').read_text())
new181review = json.loads((OUT/'181review.raw').read_text())
assert set(product(other)) == set(new181reg['complete_inputs'])
assert len(product(other)) == 1091
assert validation(other) == validation(main)
assert new181reg['complete_inputs'] == new181review['complete_inputs']
assert new181reg['validation_inputs'] == new181review['validation_inputs'] == reg['validation_inputs']
new181delta = {p:{'before_sha256':old181reg['complete_inputs'].get(p),'sha256':new181reg['complete_inputs'].get(p)}
               for p in old181reg['complete_inputs'].keys() | new181reg['complete_inputs'].keys()
               if old181reg['complete_inputs'].get(p) != new181reg['complete_inputs'].get(p)}

out = {
    'kind': 'read_only_full_git_identity_and_virtual_composition_audit',
    'tree_receipts': receipts,
    'direct_comparison_categories': categories,
    'counts': {k:len(v) for k,v in categories.items()},
    'all_divergent_paths': {p:{'mergebase':base.get(p),'main':main.get(p),'old180':old.get(p),'actual_head180':head.get(p)} for p in both},
    'head180_vs_old180': {p:{'old':old.get(p),'head':head.get(p)} for p in different(old,head)},
    'head180_vs_main': {p:{'main':main.get(p),'head':head.get(p)} for p in different(main,head)},
    'artifact_union': {'all_old_and_main_leaves_preserved': True, 'errors': artifact_errors,
                      'main_only': [p for p in categories['main_only_added'] if p.startswith('artifacts/')],
                      'pr180_only': [p for p in categories['pr180_only_added'] if p.startswith('artifacts/')]},
    'no_extra_or_missing_files_beyond_union': True,
    'head180_products_equal_original3ff': True,
    '139_validation_mode_blob_inputs_equal_main_and_original3ff': True,
    'head180_all_README_docs_equal_main': True,
    'proposed_P': prospective_record,
    'proposed_P_tree_if_only_the_three_files_are_staged': virtual_tree,
    'pr181': {'source': new181reg['product_source'], 'review': new181reg['review_source'],
              'product_count':1091, 'validation_count':139, 'delta_count':len(new181reg['delta']),
              'canonical_R_source_matches_registry':new181review['source']==new181reg['product_source'],
              'canonical_R_SHA_matches_registry':sha((OUT/'181review.raw').read_bytes())==new181reg['review_sha256'],
              'old_to_new_four_product_paths':new181delta},
}
result = write('complete-tree-composition-audit.json', out)
print(json.dumps({'result':result, 'tree_roots_verified':{k:v['recomputed_root'] for k,v in receipts.items()},
                 'counts':out['counts'], 'divergent_paths':both,
                 'head180_vs_3ff_changed_paths':len(out['head180_vs_old180']),
                 'head180_vs_main_changed_paths':len(out['head180_vs_main']),
                 'artifact_union_counts':{k:len(out['artifact_union'][k]) for k in ('main_only','pr180_only')},
                 'predicted_P_tree':virtual_tree},indent=2))
