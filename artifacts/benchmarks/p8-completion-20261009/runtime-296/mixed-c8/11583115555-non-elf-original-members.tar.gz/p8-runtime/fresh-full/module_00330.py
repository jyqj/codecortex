def stable_00330():
    return 330
