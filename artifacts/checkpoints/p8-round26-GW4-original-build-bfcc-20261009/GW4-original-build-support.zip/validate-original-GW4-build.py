from pathlib import Path
import json,hashlib,sys,datetime,os,stat,importlib.util,platform
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;R=B/'source-exact-GW4';O=B/'original-validation-attempt01';O.mkdir(exist_ok=False)
ZIP=B.parent/'p8-scale-wide-dirty-build-008f-37982220020-1-original.zip';EXPECTED='6f39842dc5bd9292b1441b3d4fa8394c154c304ec63a72f44e95606656923447'
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,x):(O/name).write_text(json.dumps(x,indent=2)+'\n')
assert ZIP.stat().st_size==9222888 and sh(ZIP)==EXPECTED
receiver=B.parent/'todo-audit-round25-50k-recovery/support/driver-reconstruction/intake_once.v2.py';spec=importlib.util.spec_from_file_location('frozen_receiver',receiver);rx=importlib.util.module_from_spec(spec);spec.loader.exec_module(rx)
members=rx.extract_original(ZIP,O/'extracted');save('original-zip-members.json',members);assert sh(ZIP)==EXPECTED
sys.path.insert(0,str(R/'scripts'));import p8_scale_matrix as m
canonical=json.loads((B.parent/'round25-GW4-binding/inputs/canonical.json').read_text());snap=m.source_snapshot(R);assert snap['source_commit']=='008f1ec0ae16b9b6aff9f20d033b17b2219168f8' and snap['source_tree']=='d5ce466ab3ccde1f00dad693e39ebfa07f051f3b';assert snap['inputs']==canonical['complete_inputs'] and snap['input_count']==1095
observer=m.driver_snapshot(R);assert observer['source_commit']==snap['source_commit']
dirs=[p.parent for p in (O/'extracted').rglob('build.json')];assert len(dirs)==1;build=dirs[0];binary=build/'p8-scale';before=m.inventory(build);mode=stat.S_IMODE(binary.stat().st_mode);binary.chmod(mode|0o111);save('executable-mode-receipt.json',{'before':oct(mode),'after':oct(stat.S_IMODE(binary.stat().st_mode)),'sha256':sh(binary),'reason':'Original validate_build requires retained native --hash-file; no workload'})
save('inputs-before.json',{'source':snap,'observer':observer,'build_inventory':before,'zip_sha256':sh(ZIP)})
record,preserved=m.validate_build(build,root=R)
save('original-validate-build-output.json',record)
after={'source':m.source_snapshot(R),'observer':m.driver_snapshot(R),'build_inventory':m.inventory(build),'zip_sha256':sh(ZIP)};save('inputs-after.json',after)
assert after==json.loads((O/'inputs-before.json').read_text());assert preserved==binary
report={'schema':'original-GW4-build-independent-intake-v1','status':'original_validate_build_passed','source':snap['source_commit'],'source_tree':snap['source_tree'],'product':canonical['source'],'review':'a61ab54a7cbad41db3e17fb4b4d628ec217de5a8','canonical_sha256':sh(B.parent/'round25-GW4-binding/inputs/canonical.json'),'artifact_id':11642471195,'run_id':37982220020,'run_attempt':1,'original_zip':{'path':str(ZIP),'bytes':ZIP.stat().st_size,'sha256':sh(ZIP)},'original_receiver':{'path':str(receiver),'sha256':sh(receiver),'function':'extract_original'},'driver_source':observer,'source_input_count':1095,'source_equals_canonical':True,'original_validate_build_invocations':1,'original_native_hash_file_executed':True,'original_binary_sha256':record['binary_sha256'],'original_binary_blake3':record['binary_blake3'],'original_binary_bytes':record['binary_bytes'],'retained_build_directory':str(build),'source_and_observers_before_after_equal':True,'build_inventory_before_after_equal':True,'actual_protocol_tests':'separately reviewed CI proof10a09397c44341781335d7713e5adf951744baf9; not rerun here','new_measurements':0,'accepted_shards':0,'accepted_samples':0,'new_TODO_completions':0,'TODO_remaining':29,'runtime':{'platform':platform.platform(),'python':platform.python_version()}}
save('independent-build-review.json',report);print(json.dumps(report))
