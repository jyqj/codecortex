def stable_00275():
    return 275
