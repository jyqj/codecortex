#!/usr/bin/env python3
"""Build, execute and replay an immutable, completely covered P8 scale matrix.

Each native shard retains its original 512 MiB maximum and global N >= 30.
The separate fanout workload belongs to the 1k scale's shards, exactly once.
Aggregation consumes original raw records, not a collection of green summaries.
This certifies measurement coverage only, never G8, quality or a release.
"""
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys

from p7_build_identity import file_sha256, json_bytes, source_snapshot, verify_release_profile


SCALES = (1000, 5000, 10000, 50000, 100000)
BATCHES = (1, 10, 100, 1000)
FANOUTS = (1, 4, 16, 64, 128)
TABLES = frozenset(("document_manifest", "resolution_frontier", "semantic_edges",
                   "dispatch_sites", "resolution_manifests", "resolution_dependencies",
                   "public_surfaces", "files", "symbols", "imports", "symbol_refs",
                   "call_edges", "chunks", "test_edges", "routes"))
PHASES = ("scan_diff_ms", "parse_ms", "resolve_ms", "write_ms", "postprocess_ms", "analysis_ms")
HEX = re.compile(r"[0-9a-f]{64}\Z")
MAX_BYTES = 512 * 1024 * 1024
MAX_LINE_BYTES = 64 * 1024 * 1024
SCHEMA = "p8-scale-matrix-v1"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value, name, minimum=0, maximum=None):
    require(type(value) is int and value >= minimum and
            (maximum is None or value <= maximum), "invalid integer: " + name)
    return value


def exact_equal(a, b):
    """Retain JSON number kinds; Python's True == 1 is not Value equality."""
    if type(a) is not type(b):
        return False
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(exact_equal(a[k], b[k]) for k in a)
    if isinstance(a, list):
        return len(a) == len(b) and all(exact_equal(x, y) for x, y in zip(a, b))
    return a == b


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON object key: " + key)
        result[key] = value
    return result


def decode(data):
    def finite_float(text):
        value = float(text)
        require(math.isfinite(value), "nonfinite JSON number")
        return value
    return json.loads(data, object_pairs_hook=unique_object,
                      parse_float=finite_float,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite JSON: " + value)))


def read_json(path, limit=8 * 1024 * 1024):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), "missing/nonregular JSON: " + str(path))
    require(path.stat().st_size <= limit, "JSON byte bound: " + str(path))
    return decode(path.read_bytes())


def write_new(path, value):
    with Path(path).open("xb") as stream:
        stream.write(json_bytes(value))


def new_directory(path):
    path = Path(path).absolute()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.mkdir()
    return path


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest_ok(value):
    return isinstance(value, str) and HEX.fullmatch(value) is not None


def native_digest(binary, path):
    result = subprocess.run([str(binary), "--hash-file", str(path)], check=True,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
    value = result.stdout.decode().strip()
    require(digest_ok(value), "native evidence hash response is invalid")
    return value


def inventory(directory, exclude=()):
    result = {}
    for path in sorted(Path(directory).rglob("*")):
        require(not path.is_symlink(), "symlink in evidence inventory")
        if path.is_file():
            relative = path.relative_to(directory).as_posix()
            if relative not in exclude:
                result[relative] = {"bytes": path.stat().st_size, "sha256": file_sha256(path)}
        else:
            require(path.is_dir(), "nonregular evidence input")
    return result


def runtime_environment():
    cpu = None
    try:
        for line in Path("/proc/cpuinfo").read_text().splitlines():
            if line.startswith("model name"):
                cpu = line.partition(":")[2].strip()
                break
    except OSError:
        pass
    return {"system": platform.system(), "release": platform.release(),
            "machine": platform.machine(), "cpu_model": cpu,
            "cpu_count": os.cpu_count(), "rustflags": os.environ.get("RUSTFLAGS")}


def verify_artifact(artifact, root=None):
    target = artifact.get("target", {})
    require(artifact.get("reason") == "compiler-artifact" and target.get("name") == "p8-scale"
            and target.get("kind") == ["bin"] and artifact.get("features") in ([], ["default"]),
            "Cargo record is not the default p8-scale executable")
    verify_release_profile(artifact.get("profile"))
    for key, suffix in (("manifest_path", "/crates/cc-eval/Cargo.toml"),):
        require(isinstance(artifact.get(key), str) and artifact[key].endswith(suffix),
                "unexpected Cargo manifest")
    require(isinstance(target.get("src_path"), str) and
            target["src_path"].endswith("/crates/cc-eval/src/bin/p8-scale.rs"), "unexpected Cargo source")
    if root is not None:
        require(Path(artifact["manifest_path"]).resolve() == root / "crates/cc-eval/Cargo.toml" and
                Path(target["src_path"]).resolve() == root / "crates/cc-eval/src/bin/p8-scale.rs",
                "Cargo artifact belongs to another source checkout")


def build(root, output, target_directory=None):
    root = Path(root).resolve(strict=True)
    out = new_directory(output)
    target = Path(target_directory).absolute() if target_directory else out.parent / (out.name + "-cargo")
    require(target != out and out not in target.parents, "Cargo target must stay outside the evidence bundle")
    before = source_snapshot(root)
    write_new(out / "source-before.json", before)
    command = ["cargo", "build", "--release", "--locked", "-p", "cc-eval", "--bin", "p8-scale",
               "--message-format=json", "--target-dir", str(target)]
    record = {"schema": SCHEMA, "kind": "build", "status": "failed", "started_utc": utc(),
              "command": command, "source_commit": before["source_commit"],
              "source_manifest_sha256": before["manifest_sha256"],
              "driver_sha256": file_sha256(__file__), "environment": runtime_environment(),
              "toolchain": {name: subprocess.check_output([name, "--version", "--verbose"], text=True).strip()
                            for name in ("cargo", "rustc")}}
    try:
        with (out / "cargo.jsonl").open("xb") as stdout, (out / "cargo.stderr").open("xb") as stderr:
            result = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr)
        record["exit_code"] = result.returncode
        after = source_snapshot(root)
        write_new(out / "source-after.json", after)
        require(before == after, "build source changed during compilation")
        require(result.returncode == 0, "Cargo build failed")
        messages = [decode(line) for line in (out / "cargo.jsonl").read_bytes().splitlines() if line]
        require(messages and messages[-1] == {"reason": "build-finished", "success": True}, "missing Cargo completion")
        candidates = [m for m in messages if m.get("reason") == "compiler-artifact" and
                      m.get("target", {}).get("name") == "p8-scale"]
        require(len(candidates) == 1, "expected one p8-scale Cargo artifact")
        artifact = candidates[0]
        verify_artifact(artifact, root)
        produced = Path(artifact["executable"]).resolve(strict=True)
        require(target.resolve() in produced.parents, "executable outside selected Cargo target")
        shutil.copy2(produced, out / "p8-scale")
        record.update(status="passed", cargo_artifact=artifact,
                      binary_sha256=file_sha256(out / "p8-scale"),
                      binary_blake3=native_digest(out / "p8-scale", out / "p8-scale"))
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        record["error"] = str(error)
    record["finished_utc"] = utc()
    record["files"] = inventory(out)
    write_new(out / "build.json", record)
    return record


def validate_build(directory, root=None):
    directory = Path(directory).resolve(strict=True)
    record = read_json(directory / "build.json")
    require(record.get("schema") == SCHEMA and record.get("kind") == "build" and
            record.get("status") == "passed" and record.get("exit_code") == 0, "build receipt is not successful")
    require(record.get("files") == inventory(directory, ("build.json",)), "build evidence changed")
    before = read_json(directory / "source-before.json")
    require(before == read_json(directory / "source-after.json"), "build source snapshots differ")
    require(before["source_commit"] == record["source_commit"] and
            before["manifest_sha256"] == record["source_manifest_sha256"], "build source identity differs")
    if root is not None:
        require(source_snapshot(root) == before, "execution checkout differs from built source")
    verify_artifact(record.get("cargo_artifact", {}))
    cargo = [decode(line) for line in (directory / "cargo.jsonl").read_bytes().splitlines() if line]
    require(cargo and cargo[-1] == {"reason": "build-finished", "success": True}, "Cargo completion changed")
    require(sum(m == record["cargo_artifact"] for m in cargo) == 1, "Cargo artifact missing/duplicated in original log")
    binary = directory / "p8-scale"
    require(file_sha256(binary) == record["binary_sha256"] and
            native_digest(binary, binary) == record["binary_blake3"], "preserved build executable changed")
    return record, binary


def registered_plan(scale, shard_index, shard_count, repetitions=30, seed=12648430, deadline_ms=18_000_000):
    require(scale in SCALES, "noncanonical scale")
    integer(repetitions, "registered repetitions", 30, 200)
    integer(shard_count, "shard count", 1, repetitions)
    integer(shard_index, "shard index", 0, shard_count - 1)
    integer(deadline_ms, "deadline", 1, 86_400_000)
    integer(seed, "seed", 0, (1 << 64) - 1)
    return dict(schema_version=1, profile="release", files=[scale], seed=seed,
                repetitions=repetitions, shard=dict(index=shard_index, count=shard_count),
                skip_fanout=scale != SCALES[0], dirty_budget=8, max_resume_builds=128,
                batch_sizes=list(BATCHES), fanouts=list(FANOUTS),
                deadline_ms=deadline_ms, max_output_bytes=MAX_BYTES)


def repetition_range(plan):
    n, shard = plan["repetitions"], plan["shard"]
    return range(n * shard["index"] // shard["count"], n * (shard["index"] + 1) // shard["count"])


def run_shard(root, build_directory, output, plan):
    root = Path(root).resolve(strict=True)
    built, binary = validate_build(build_directory, root)
    out = new_directory(output)
    write_new(out / "registered-plan.json", plan)
    before = source_snapshot(root)
    write_new(out / "source-before.json", before)
    command = [str(binary), "--profile", "release", "--files", str(plan["files"][0]),
               "--seed", str(plan["seed"]), "--repetitions", str(plan["repetitions"]),
               "--shard-index", str(plan["shard"]["index"]), "--shard-count", str(plan["shard"]["count"]),
               "--dirty-budget", str(plan["dirty_budget"]), "--max-resume-builds", str(plan["max_resume_builds"]),
               "--batch-sizes", ",".join(map(str, plan["batch_sizes"])),
               "--fanouts", ",".join(map(str, plan["fanouts"])), "--deadline-ms", str(plan["deadline_ms"]),
               "--max-output-bytes", str(plan["max_output_bytes"]), "--output", str(out / "native")]
    if plan["skip_fanout"]:
        command.append("--skip-fanout")
    record = {"schema": SCHEMA, "kind": "shard", "status": "failed", "started_utc": utc(),
              "command": command, "plan": plan, "build_receipt_sha256": file_sha256(Path(build_directory) / "build.json"),
              "source_commit": built["source_commit"], "source_manifest_sha256": built["source_manifest_sha256"],
              "binary_sha256": built["binary_sha256"], "binary_blake3": built["binary_blake3"],
              "environment": runtime_environment(), "release_certification": "not_run"}
    try:
        with (out / "supervisor.stdout").open("xb") as stdout, (out / "supervisor.stderr").open("xb") as stderr:
            result = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr,
                                    timeout=plan["deadline_ms"] / 1000 + 120)
        record["exit_code"] = result.returncode
        after = source_snapshot(root)
        write_new(out / "source-after.json", after)
        require(before == after, "source changed during measured shard")
        require(file_sha256(binary) == built["binary_sha256"], "binary changed during measured shard")
        require(result.returncode == 0, "native shard failed")
        record["status"] = "passed"
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        record["error"] = str(error)
    record["finished_utc"] = utc()
    record["files"] = inventory(out)
    write_new(out / "shard.json", record)
    return record


def check_build_report(report):
    require(isinstance(report, dict), "missing original IndexReport")
    for field in ("files_scanned", "files_added", "files_updated", "files_removed", "files_skipped",
                  "files_parsed", "symbols_total", "chunks_total", "elapsed_ms"):
        integer(report.get(field), field)
    require(report.get("parse_errors") == [], "original parse errors are not empty")
    require(isinstance(report.get("dirty_plan"), dict) and isinstance(report.get("project_model"), dict),
            "missing original phase work reports")
    require(isinstance(report.get("document_changes"), dict), "missing document change report")
    phases = report.get("phase_timing", {})
    for phase in PHASES:
        integer(phases.get(phase), phase)
    complete = report.get("resolution_freshness", {}).get("complete")
    require(type(complete) is bool, "missing explicit closure status")
    return {"elapsed_ms": report["elapsed_ms"], "phases": phases, "complete": complete,
            "files_added": report["files_added"], "files_updated": report["files_updated"],
            "files_removed": report["files_removed"]}


def check_counts(counts):
    require(isinstance(counts, dict) and set(counts.get("tables", {})) == TABLES, "incomplete table counts")
    for key, value in counts["tables"].items():
        integer(value, "table count " + key)
    for name in ("files", "symbols", "chunks"):
        integer(counts.get(name), "flattened " + name)
        require(counts.get(name) == counts["tables"][name], "flattened table count differs")
    for name in ("call_edges", "semantic_edges", "test_edges"):
        integer(counts.get("edges", {}).get(name), "edge " + name)
        require(counts.get("edges", {}).get(name) == counts["tables"][name], "edge count differs")
    require(counts.get("vectors", {}).get("state") == "disabled" and
            "count" in counts["vectors"] and counts["vectors"]["count"] is None,
            "disabled vectors misrepresented as measured workload")
    integer(counts.get("index_db_with_wal_shm_bytes"), "index bytes", 1)


def check_parity(parity):
    require(parity.get("equal") is True and parity.get("status") == "equal" and
            parity.get("different_tables") == [], "incomplete or failed full parity")
    tables = parity.get("tables", [])
    require(len(tables) == len(TABLES) and {row.get("table") for row in tables} == TABLES,
            "parity must contain all fifteen unique tables")
    for row in tables:
        require(row.get("equal") is True and row.get("different_row_count") == 0,
                "a canonical table has a recorded difference")
        integer(row.get("incremental_rows"), "incremental row count")
        integer(row.get("full_rows"), "full row count")
        require(row["incremental_rows"] == row.get("full_rows"), "canonical row multiplicity differs")
        require(digest_ok(row.get("incremental_digest")) and digest_ok(row.get("full_digest")),
                "missing full canonical row digests")
        # Different encodings of equal signed zero may legitimately have
        # different digests. The original full Value comparison is retained.
    for side in ("incremental_counts", "full_counts"):
        check_counts(parity.get(side))
        require(all(parity[side]["tables"][row["table"]] == row[
                    "incremental_rows" if side == "incremental_counts" else "full_rows"] for row in tables),
                "count/parity row inventory differs")


def check_fact(fact, config_files, changed):
    target = config_files[1 if changed else 0]
    require(fact == dict(consumer=config_files[2], expected_target=target, actual_targets=[target], passed=True),
            "independent config target assertion failed or changed")


def compact_build(event, started):
    require(event.get("label") == started.get("label") and event.get("full") is started.get("full") and
            event.get("start_us") == started.get("start_us"), "build start/finish identity differs")
    start = integer(event.get("start_us"), "build start")
    end = integer(event.get("end_us"), "build end", start)
    require(event.get("wall_us") == end - start, "build wall range differs")
    result = check_build_report(event.get("report"))
    result.update(wall_us=end - start, full=event["full"])
    return result


def inspect_raw(path, plan):
    """Replay the complete event population, retaining bounded summaries."""
    scale, reps = plan["files"][0], set(repetition_range(plan))
    stages = ("no_op", "body", "api", "config") + tuple(f"batch_{n}" for n in plan["batch_sizes"])
    expected_samples = {f"scale-{scale}/repetition-{r}" for r in reps}
    inputs, starts, builds, mutations, cold, finished = {}, {}, {}, {}, {}, {}
    used_builds, fanout_started, fanout_finished, measurements = set(), {}, {}, []
    engine = None
    sequence = 0
    require(path.stat().st_size <= plan["max_output_bytes"], "raw exceeds registered evidence budget")
    with path.open("rb") as raw:
        while line := raw.readline(MAX_LINE_BYTES + 1):
            require(len(line) <= MAX_LINE_BYTES and line.endswith(b"\n"), "oversized/truncated raw record")
            event = decode(line)
            kind = event.get("event")
            if kind == "run_started":
                require(sequence == 0 and event.get("plan") == plan, "run header/plan mismatch")
                require(event.get("release_certification") == "not_run" and event.get("shard_only") is True,
                        "single shard claimed full certification")
                engine = event.get("engine")
                require(isinstance(engine, dict), "missing raw engine provenance")
            elif kind == "input":
                sample = event.get("sample")
                require(sample in expected_samples and sample not in inputs, "unexpected/duplicate input sample")
                require(event.get("seed") == plan["seed"] and event.get("synthetic_files_requested") == scale and
                        event.get("synthetic_files_written") == scale and event.get("auxiliary_visible_config_files") == 1,
                        "input count/seed differs from registered corpus")
                records = event.get("files", [])
                paths = [row["path"] for row in records]
                require(len(records) == scale + 1 and paths == sorted(set(paths)) and "tsconfig.json" in paths,
                        "missing/duplicate generated input files")
                for row in records:
                    require(not row["path"].startswith("/") and ".." not in row["path"].split("/"), "unsafe input path")
                    integer(row.get("bytes"), "generated file bytes", 1)
                    require(digest_ok(row.get("digest")), "missing generated file digest")
                require(digest_ok(event.get("input_digest")), "missing whole input digest")
                require(event.get("batch_target_policy") == "generated_code_then_existing_route_and_yaml_v2",
                        "batch workload policy differs")
                runtime = event.get("runtime_config")
                expected_runtime = {"auto_index": {"enabled": False}, "indexing": {
                    "dirty_propagation": True, "dirty_propagation_max_files": plan["dirty_budget"],
                    "db_read_pool_size": 1, "max_concurrent_parse": 2}, "semantic": {
                        "enabled": False, "network_opt_in": False, "allow_query_network": False}}
                require(exact_equal(runtime, expected_runtime), "runtime config drift")
                config = event.get("config_fixture_augmented_code_files")
                require(isinstance(config, list) and len(config) == 3 and len(set(config)) == 3 and
                        all(p in paths and p.endswith(".ts") for p in config), "config fixture witness changed")
                inputs[sample] = dict(digest=event["input_digest"], paths=set(paths), config=config)
            elif kind == "build_started":
                label = event.get("label")
                require(isinstance(label, str) and label not in starts, "duplicate build identity")
                starts[label] = event
            elif kind == "build_finished":
                label = event.get("label")
                require(label in starts and label not in builds, "missing/duplicate build completion")
                builds[label] = compact_build(event, starts[label])
            elif kind == "cold_parity":
                sample = event.get("sample")
                require(sample in inputs and sample not in cold, "unexpected/duplicate cold comparison")
                labels = [sample + "/cold_incremental", sample + "/cold_full_control"]
                require(all(label in builds and builds[label]["full"] is True and builds[label]["complete"] is True
                            for label in labels), "missing/incomplete independent cold builds")
                check_parity(event.get("parity", {}))
                check_fact(event.get("independent_config_fact"), inputs[sample]["config"], False)
                integer(event.get("parity_wall_us"), "cold parity wall")
                cold[sample] = event["parity"]["incremental_counts"]
                used_builds.update(labels)
                measurements.append(dict(group=f"scale-{scale}/cold", sample=sample,
                                         engine_ms=builds[labels[0]]["elapsed_ms"],
                                         index_wall_us=builds[labels[0]]["wall_us"],
                                         full_control_ms=builds[labels[1]]["elapsed_ms"],
                                         parity_wall_us=event["parity_wall_us"], counts=cold[sample],
                                         phases=builds[labels[0]]["phases"]))
            elif kind == "mutation":
                label = event.get("label", "")
                sample, _, stage = label.rpartition("/")
                require(sample in cold and stage in stages and label not in mutations, "unexpected/duplicate mutation")
                expected = 0 if stage == "no_op" else int(stage[6:]) if stage.startswith("batch_") else 1
                operations, receipts = event.get("operations", []), event.get("receipts", [])
                require(event.get("requested_files") == expected and len(operations) == len(receipts) == expected,
                        "mutation count differs or batch was silently shrunk")
                paths = [op.get("path") for op in operations]
                require(len(set(paths)) == expected and set(paths) <= inputs[sample]["paths"], "mutation not on unique existing inputs")
                require(paths == [receipt.get("path") for receipt in receipts], "mutation receipt order differs")
                repetition = int(sample.rsplit("-", 1)[1])
                if stage == "config":
                    require(paths == ["tsconfig.json"] and decode(operations[0].get("content", "")) == {
                        "compilerOptions": {"baseUrl": ".", "paths": {"@p8/config": ["./" + inputs[sample]["config"][1]]}}},
                        "config mutation did not switch the registered target")
                elif stage.startswith("batch_"):
                    require("tsconfig.json" not in paths, "batch changed the independent config control")
                    for op in operations:
                        comment = "#" if op["path"].endswith((".py", ".yaml")) else "//"
                        require(op.get("content", "").endswith(f"\n{comment} p8 batch {expected} repetition {repetition}\n"),
                                "batch mutation body differs from registered workload")
                elif stage == "body":
                    require(f"p8_body_{repetition}" in operations[0].get("content", ""), "body mutation marker missing")
                elif stage == "api":
                    require(f"p8_offset: number = {repetition + 1}" in operations[0].get("content", ""), "API mutation marker missing")
                for op, receipt in zip(operations, receipts):
                    require(isinstance(op.get("content"), str) and len(op["content"].encode()) == receipt.get("bytes"),
                            "mutation byte count differs")
                    require(digest_ok(receipt.get("before_digest")) and digest_ok(receipt.get("after_digest")) and
                            receipt["before_digest"] != receipt["after_digest"], "mutation is unchanged or unbound")
                mutations[label] = len(operations)
            elif kind == "stage_finished":
                label = event.get("label", "")
                sample, _, stage = label.rpartition("/")
                require(label in mutations and label not in finished and stage in stages, "unexpected/duplicate stage")
                count = integer(event.get("incremental_builds"), "incremental builds", 1, plan["max_resume_builds"] + 1)
                labels = [f"{label}/incremental-{n}" for n in range(count)]
                control = label + "/full_control"
                require(all(key in builds and builds[key]["full"] is False for key in labels) and
                        control in builds and builds[control]["full"] is True, "missing native incremental/full report")
                require(event.get("passed") is True and event.get("complete") is True and event.get("full_complete") is True and
                        builds[labels[-1]]["complete"] is True and builds[control]["complete"] is True,
                        "incomplete closure cannot certify full parity")
                require(all(builds[key]["complete"] is False for key in labels[:-1]), "unexpected resume after completed closure")
                check_parity(event.get("parity", {}))
                check_fact(event.get("independent_config_fact"), inputs[sample]["config"], stage == "config" or stage.startswith("batch_"))
                if stage == "no_op":
                    require(all(builds[labels[0]][key] == 0 for key in ("files_added", "files_updated", "files_removed")),
                            "no-op changed indexed files")
                require(event.get("no_op_unchanged") is True, "native no-op assertion failed")
                integer(event.get("incremental_wall_us"), "incremental wall")
                integer(event.get("parity_wall_us"), "parity wall")
                used_builds.update(labels + [control])
                finished[label] = True
                measurements.append(dict(group=f"scale-{scale}/{stage}", sample=sample,
                    engine_ms=sum(builds[key]["elapsed_ms"] for key in labels),
                    index_wall_us=sum(builds[key]["wall_us"] for key in labels),
                    outer_incremental_wall_us=event["incremental_wall_us"],
                    full_control_ms=builds[control]["elapsed_ms"], parity_wall_us=event["parity_wall_us"],
                    builds=count, phases={phase: sum(builds[key]["phases"][phase] for key in labels) for phase in PHASES}))
            elif kind == "fanout_started":
                key = (event.get("fanout"), event.get("repetition"))
                require(not plan["skip_fanout"] and key[0] in plan["fanouts"] and key[1] in reps and
                        key not in fanout_started, "unexpected/duplicate fanout start")
                fanout_started[key] = event.get("case")
            elif kind == "fanout_finished":
                key = (event.get("fanout"), event.get("repetition"))
                require(key in fanout_started and key not in fanout_finished, "unexpected/duplicate fanout completion")
                fanout, repetition = key
                case, result = fanout_started[key], event.get("result", {})
                require(event.get("passed") is True and result.get("passed") is True and result.get("failure_signature") is None,
                        "fanout replay failed")
                require(event.get("fixture_files") == fanout + 1 and set(case.get("initial", {})) ==
                        {"api.ts"} | {f"use_{i:03}.ts" for i in range(fanout)}, "fanout fixture file count differs")
                require(case.get("dirty_budget") == plan["dirty_budget"] and case.get("max_resume_builds") == plan["max_resume_builds"],
                        "fanout closure budget differs")
                require(set(result.get("tables", [])) == TABLES and len(result["tables"]) == 15, "fanout oracle table set changed")
                checkpoints = result.get("checkpoints", [])
                require(len(checkpoints) == 1, "fanout must retain the actual checkpoint")
                point = checkpoints[0]
                require(point.get("status") == "compared" and point.get("settle_required") is True and point.get("different_tables") == [],
                        "fanout parity incomplete")
                require(set(point.get("incremental", {})) == TABLES and set(point.get("full", {})) == TABLES and
                        exact_equal(point["incremental"], point["full"]), "fanout original full canonical facts differ")
                expected_truth = [{"id": f"caller_{i}", "expected": 1, "actual": 1, "passed": True} for i in range(fanout)]
                require(point.get("truth") == expected_truth, "fanout independent truth receipts differ")
                for i in range(fanout):
                    wanted = dict(file_path=f"use_{i:03}.ts", callee_symbol="scale_ping", target_file_path="api.ts")
                    actual = sum(all(row.get(k) == v for k, v in wanted.items()) for row in point["incremental"]["call_edges"])
                    require(actual == 1, "fanout hand-authored call edge missing or duplicated")
                reports = [check_build_report(report) for report in point.get("reports", [])]
                require(reports and reports[-1]["complete"] is True and all(r["complete"] is False for r in reports[:-1]),
                        "fanout closure not complete or resumed after completion")
                require(event.get("incremental_builds") == len(reports) and event.get("incremental_engine_elapsed_ms") ==
                        sum(r["elapsed_ms"] for r in reports), "fanout time attribution differs from raw reports")
                incomplete = reports[0]["complete"] is False
                require(event.get("first_build_incomplete") is incomplete, "fanout budget claim differs from actual first report")
                integer(event.get("wall_us"), "whole fanout replay wall")
                fanout_finished[key] = True
                measurements.append(dict(group=f"fanout-{fanout}", sample=f"fanout-{fanout}/repetition-{repetition}",
                    engine_ms=event["incremental_engine_elapsed_ms"], whole_fixture_wall_us=event["wall_us"],
                    builds=len(reports), first_build_incomplete=incomplete,
                    phases={phase: sum(r["phases"][phase] for r in reports) for phase in PHASES}))
            else:
                raise ValueError("failed, unknown or not-run raw event: " + str(kind))
            sequence += 1
    require(engine is not None and set(inputs) == set(cold) == expected_samples, "missing full scale input/cold samples")
    expected_stages = {sample + "/" + stage for sample in expected_samples for stage in stages}
    require(set(mutations) == set(finished) == expected_stages, "missing registered mutation stages")
    require(set(starts) == set(builds) == used_builds, "missing, incomplete or unconsumed native builds")
    expected_fanouts = set() if plan["skip_fanout"] else {(fanout, rep) for fanout in plan["fanouts"] for rep in reps}
    require(set(fanout_started) == set(fanout_finished) == expected_fanouts, "missing registered fanout samples")
    require(len({record["digest"] for record in inputs.values()}) == 1, "same-seed input digest changed across repetitions")
    return dict(engine=engine, input_digest=next(iter(inputs.values()))["digest"], measurements=measurements)


def validate_shard(directory, build_record, binary, build_receipt_sha256):
    directory = Path(directory).resolve(strict=True)
    record = read_json(directory / "shard.json")
    require(record.get("schema") == SCHEMA and record.get("kind") == "shard" and record.get("status") == "passed" and
            record.get("exit_code") == 0, "shard execution failed or is missing")
    require(record.get("files") == inventory(directory, ("shard.json",)), "shard evidence changed after sealing")
    require(record.get("build_receipt_sha256") == build_receipt_sha256, "shard used another build receipt")
    for key in ("source_commit", "source_manifest_sha256", "binary_sha256", "binary_blake3"):
        require(record.get(key) == build_record[key], "shard " + key + " mismatch")
    before = read_json(directory / "source-before.json")
    require(before == read_json(directory / "source-after.json") and before["source_commit"] == build_record["source_commit"] and
            before["manifest_sha256"] == build_record["source_manifest_sha256"], "shard source drift")
    plan = record["plan"]
    expected = registered_plan(plan["files"][0], plan["shard"]["index"], plan["shard"]["count"],
                               plan["repetitions"], plan["seed"], plan["deadline_ms"])
    require(exact_equal(plan, expected) and plan == read_json(directory / "registered-plan.json") and
            plan == read_json(directory / "native/plan.json"), "shard plan differs from fixed matrix protocol")
    report, summary = read_json(directory / "native/report.json"), read_json(directory / "native/worker-summary.json")
    require(report.get("exit_code") == 0 and report.get("worker_exit_code") == 0 and report.get("status") == "measurement_complete" and
            report.get("stderr_complete") is True and report.get("fixture_cleanup", {}).get("error") is None,
            "native supervisor did not complete successfully")
    require(report.get("worker_binary_unchanged") is True and report.get("worker_binary_digest_before") == build_record["binary_blake3"] and
            report.get("worker_binary_digest_after") == build_record["binary_blake3"], "native binary provenance differs")
    for file, field in (("plan.json", "plan_digest"), ("raw.jsonl", "raw_digest")):
        require(native_digest(binary, directory / "native" / file) == report.get(field), "native " + file + " digest mismatch")
    require(report.get("summary") == summary and summary.get("passed") is True and report.get("shard_only") is True and
            summary.get("shard_only") is True and report.get("registered_repetitions") == plan["repetitions"],
            "native summary/shard coverage differs")
    expected_range = dict(start=repetition_range(plan).start, end=repetition_range(plan).stop)
    require(report.get("executed_repetition_range") == summary.get("executed_repetition_range") == expected_range,
            "native global sample range differs")
    require(report.get("release_certification") == summary.get("release_certification") == "not_run" and
            report.get("full_100k_certification") == summary.get("full_100k_certification") == "not_run",
            "a shard cannot certify a full release")
    inspected = inspect_raw(directory / "native/raw.jsonl", plan)
    engine = inspected["engine"]
    require(engine.get("eval_debug_assertions") is False and engine.get("engine_head_observed") == build_record["source_commit"] and
            engine.get("binary_digest") == build_record["binary_blake3"] and digest_ok(engine.get("source_files_digest")) and
            digest_ok(engine.get("cargo_lock_digest")), "raw engine provenance is not the built release candidate")
    require(summary.get("sample_count") == len(inspected["measurements"]) and summary.get("raw_bytes") ==
            (directory / "native/raw.jsonl").stat().st_size, "summary count/raw byte coverage differs")
    groups = summary.get("groups", [])
    expected_groups = Counter(item["group"] for item in inspected["measurements"])
    require(len(groups) == len(expected_groups) and {group.get("group") for group in groups} == set(expected_groups),
            "native summary group coverage differs")
    for group in groups:
        require(group.get("samples") == group.get("passed") == expected_groups[group["group"]] and
                group.get("failed_or_not_compared") == 0, "native summary masks failed samples")
    return dict(directory=str(directory), receipt_sha256=file_sha256(directory / "shard.json"),
                plan=plan, environment=record["environment"], **inspected)


def statistics(values):
    require(values and all(isinstance(value, (int, float)) and math.isfinite(value) for value in values), "invalid raw latency population")
    return {"n": len(values), "min": min(values), "max": max(values), "mean": sum(values) / len(values), "samples": values}


def combine(shards, repetitions=30, shard_count=6):
    integer(repetitions, "aggregate repetitions", 30, 200)
    integer(shard_count, "aggregate shard count", 1, repetitions)
    expected = {(scale, index) for scale in SCALES for index in range(shard_count)}
    seen, by_group, sources, environments, inputs, common = set(), defaultdict(list), set(), set(), {}, set()
    for shard in shards:
        plan = shard["plan"]
        key = (plan["files"][0], plan["shard"]["index"])
        require(key in expected and key not in seen, "duplicate or unexpected matrix shard")
        require(plan["repetitions"] == repetitions and plan["shard"]["count"] == shard_count, "matrix repetition/shard population changed")
        seen.add(key)
        signature = dict(plan)
        for field in ("files", "shard", "skip_fanout"):
            signature.pop(field)
        common.add(json.dumps(signature, sort_keys=True))
        engine = shard["engine"]
        sources.add(tuple(engine.get(key) for key in ("engine_head_observed", "source_files_digest", "cargo_lock_digest",
                                                     "binary_digest", "eval_version", "os", "arch", "rustflags", "cpu_parallelism")))
        environments.add(json.dumps(shard["environment"], sort_keys=True))
        scale = plan["files"][0]
        if scale in inputs:
            require(inputs[scale] == shard["input_digest"], "matrix input changed between same-scale shards")
        inputs[scale] = shard["input_digest"]
        for sample in shard["measurements"]:
            by_group[sample["group"]].append(sample)
    require(seen == expected, "missing matrix shards: " + str(sorted(expected - seen)))
    require(len(common) == len(sources) == len(environments) == 1, "matrix source/binary/profile/runtime/environment mismatch")
    stages = ("cold", "no_op", "body", "api", "config") + tuple(f"batch_{n}" for n in BATCHES)
    expected_groups = {f"scale-{scale}/{stage}" for scale in SCALES for stage in stages} | {f"fanout-{n}" for n in FANOUTS}
    require(set(by_group) == expected_groups, "missing or unexpected full matrix groups")
    groups = []
    for name, samples in sorted(by_group.items()):
        prefix = name.split("/")[0]
        expected_ids = {f"{prefix}/repetition-{r}" for r in range(repetitions)}
        require(len(samples) == repetitions and {sample["sample"] for sample in samples} == expected_ids,
                "missing/duplicate global repetition in " + name)
        samples.sort(key=lambda item: int(item["sample"].rsplit("-", 1)[1]))
        group = {"group": name, "n": repetitions, "engine_ms": statistics([s["engine_ms"] for s in samples]),
                 "phase_ms": {phase: statistics([s["phases"][phase] for s in samples]) for phase in PHASES}}
        for metric in ("index_wall_us", "outer_incremental_wall_us", "full_control_ms", "parity_wall_us", "whole_fixture_wall_us", "builds"):
            present = [s[metric] for s in samples if metric in s]
            if present:
                require(len(present) == repetitions, "partly missing metric: " + metric)
                group[metric] = statistics(present)
        if name.endswith("/cold"):
            group["counts_by_repetition"] = [sample["counts"] for sample in samples]
        if name.startswith("fanout-"):
            group["first_build_incomplete_samples"] = sum(sample["first_build_incomplete"] for sample in samples)
        groups.append(group)
    require(any(group.get("first_build_incomplete_samples", 0) > 0 for group in groups), "no actual over-budget closure was observed")
    return {"schema": SCHEMA, "status": "complete_measurement_coverage", "passed": True,
            "registered_repetitions": repetitions, "shard_count_per_scale": shard_count,
            "scales": list(SCALES), "batch_sizes": list(BATCHES), "fanouts": list(FANOUTS),
            "fanout_owner_scale": SCALES[0], "sample_count": sum(len(s) for s in by_group.values()),
            "input_digests": inputs, "environment": json.loads(next(iter(environments))),
            "engine": shards[0]["engine"], "groups": groups,
            "evidence": [{"directory": s["directory"], "receipt_sha256": s["receipt_sha256"]} for s in shards],
            "statistics_scope": "all registered samples; no best-of, causal speedup, stable p95/p99 or quality inference",
            "resources_scope": "original single-worker snapshots; whole-process-tree peaks not certified",
            "release_certification": "not_run", "G8": "not_evaluated", "task_statuses_changed": False}


def aggregate(build_directory, directories, output, repetitions=30, shard_count=6):
    out = new_directory(output)
    result = {"schema": SCHEMA, "status": "failed", "passed": False, "release_certification": "not_run"}
    try:
        built, binary = validate_build(build_directory)
        build_digest = file_sha256(Path(build_directory) / "build.json")
        shards = [validate_shard(path, built, binary, build_digest) for path in directories]
        result = combine(shards, repetitions, shard_count)
        result["build_receipt_sha256"] = build_digest
        result["replay_driver_sha256"] = file_sha256(__file__)
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
        result["error"] = str(error)
    write_new(out / "matrix.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="mode", required=True)
    compile_parser = commands.add_parser("build")
    compile_parser.add_argument("--root", type=Path, default=Path.cwd())
    compile_parser.add_argument("--output", type=Path, required=True)
    compile_parser.add_argument("--target-directory", type=Path)
    run_parser = commands.add_parser("run")
    run_parser.add_argument("--root", type=Path, default=Path.cwd())
    run_parser.add_argument("--build", type=Path, required=True)
    run_parser.add_argument("--output", type=Path, required=True)
    run_parser.add_argument("--scale", type=int, choices=SCALES, required=True)
    run_parser.add_argument("--shard-index", type=int, required=True)
    run_parser.add_argument("--shard-count", type=int, default=6)
    run_parser.add_argument("--repetitions", type=int, default=30)
    run_parser.add_argument("--seed", type=int, default=12648430)
    run_parser.add_argument("--deadline-ms", type=int, default=18_000_000)
    aggregate_parser = commands.add_parser("aggregate")
    aggregate_parser.add_argument("--build", type=Path, required=True)
    aggregate_parser.add_argument("--inputs", type=Path, nargs="+", required=True)
    aggregate_parser.add_argument("--output", type=Path, required=True)
    aggregate_parser.add_argument("--repetitions", type=int, default=30)
    aggregate_parser.add_argument("--shard-count", type=int, default=6)
    args = parser.parse_args()
    try:
        if args.mode == "build":
            result = build(args.root, args.output, args.target_directory)
        elif args.mode == "run":
            plan = registered_plan(args.scale, args.shard_index, args.shard_count, args.repetitions, args.seed, args.deadline_ms)
            result = run_shard(args.root, args.build, args.output, plan)
        else:
            result = aggregate(args.build, args.inputs, args.output, args.repetitions, args.shard_count)
        print(json.dumps({key: result.get(key) for key in ("status", "passed", "error", "sample_count")}, indent=2))
        return 0 if result.get("status") == "passed" or result.get("passed") is True else 1
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
        print(str(error), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
