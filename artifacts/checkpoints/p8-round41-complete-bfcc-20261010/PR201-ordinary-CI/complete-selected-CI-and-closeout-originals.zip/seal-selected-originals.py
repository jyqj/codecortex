from pathlib import Path
import hashlib, json, zipfile

ROOT=Path('/workspace/scratch/bfccb8494ba0')
HERE=Path(__file__).resolve().parent
def ident(p):
    b=p.read_bytes()
    return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
names=[
 'pull.official-original.json','runs.official-original.json','checks.official-original.json',
 'current-testmerge.official-original.json','jobs-38025451919.root-original-fragment.json',
 'jobs-38025451863.official-original.json','jobs-38025451979.official-original.json',
 'jobs-38025451790.official-original.json','jobs-38025451862.official-original.json',
 'jobs-38025451807.official-original.json','jobs-38025451825.official-original.json',
 'summarize-original-status.py','reader.stdout','reader.stderr','reader.exit.json',
 'independent-finite-CI-observation.json','review-closeout-and-launch.py',
 'closeout-reader.stdout','closeout-reader.stderr','closeout-reader.exit.json',
 'independent-original-closeout-review.json','study-launch-readiness-after-default-success.json',
 'seal-selected-originals.py',
]
selection=[(n,HERE/n) for n in names]
selection += [
 ('root-originals/round41-0506-main-jobs-original.json',ROOT/'round41-0506-main-jobs-original.json'),
 ('source/original-ordinary26-watch-list.json',ROOT/'round40-fresh45-route-independent-review/ordinary26-watch-list.json'),
 ('source/ci.yml',ROOT/'round32-capture-context-admission/guard-view/.github/workflows/ci.yml'),
 ('source/p8-task-profile.yml',ROOT/'round40-task-profile-workflow-candidate/candidate/.github/workflows/p8-task-profile.yml'),
]
manifest={'schema_version':1,'scope':'Complete selected small original API responses, independent read-only readers/results and exact command sources; not whole Actions artifact custody.',
 'source':'f97c5068d056969705e8387ba1f37d83847f5bee',
 'files':[{'archive_path':n,'local_path':str(p),**ident(p)} for n,p in selection],
 'external_originals':[{'name':'114135223961-original-closeout.log','actual_git_blob':'703de5825d10906a0fb8e19e9f28f971357955a7','bytes':1916891,'sha256':'5541ef7a6ef6a7d7cc0222619cc4ffc66db87aaf1d10e21db630b07357c10688','custody_owner':'root','not_redownloaded':True}],
 'manifest_self_entry_excluded_to_avoid_recursive_hash':True}
save(HERE/'selected-member-manifest.json',manifest)
zip_path=HERE/'complete-selected-CI-and-closeout-originals.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,p in selection:
        info=zipfile.ZipInfo(n,(2026,10,10,0,0,0));info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,p.read_bytes())
    info=zipfile.ZipInfo('selected-member-manifest.json',(2026,10,10,0,0,0));info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED
    z.writestr(info,(HERE/'selected-member-manifest.json').read_bytes())
with zipfile.ZipFile(zip_path) as z:
    assert z.namelist()==[n for n,p in selection]+['selected-member-manifest.json']
    assert z.testzip() is None
    for row in manifest['files']:
        b=z.read(row['archive_path']);assert len(b)==row['bytes'];assert hashlib.sha256(b).hexdigest()==row['sha256']
upload_names=['independent-finite-CI-observation.json','independent-original-closeout-review.json','study-launch-readiness-after-default-success.json','complete-selected-CI-and-closeout-originals.zip']
publication={'schema_version':1,'repository':'jyqj/codecortex','prefix':'artifacts/checkpoints/p8-round41-complete-bfcc-20261010/PR201-ordinary-CI/',
 'source':manifest['source'],'actual_uploads_pending':True,
 'files':[{'name':n,'local_path':str(HERE/n),**ident(HERE/n)} for n in upload_names],
 'support_members':len(selection)+1,'raw_closeout_log_external_actual_blob':'703de5825d10906a0fb8e19e9f28f971357955a7',
 'not_actions_zip':'The support ZIP is a selected evidence archive, not the original uploaded closeout artifact.'}
save(HERE/'publication-selection.json',publication)
print(json.dumps({'files':publication['files'],'selection':ident(HERE/'publication-selection.json'),'members':len(selection)+1}))
