from pathlib import Path
import hashlib,json,zipfile,subprocess,base64,datetime,sys,time
base=Path.cwd()/'artifacts/benchmarks/p8-bfccb8494ba0';out=base/'native-db-observation-G-d7f21ab5-admission'
(out/'package-original-G-admission-controller.py').write_bytes(Path(sys.argv[0]).read_bytes())
rp=out/'original-v15-command-receipt.json';rb=rp.read_bytes();r=json.loads(rb)
assert r['source_G']=='d7f21ab52ee2068c45ab5f7781e9e1db57f613de' and r['product_P']=='bb290be2deaf4334863e09dbf47fe4ccc9625f2b' and r['review_R']=='51d5ed91e14ddb13eccb93ebd28311a3235075cc'
assert r['exit_code']==0 and 'controller_exception' not in r and 'controller_timeout_seconds' not in r
assert r['domain_before']['sha256']==r['domain_after']['sha256'] and r['domain_before']['count']==1440
assert r['parent_head_before']==r['parent_head_after']=='ff458bc591b4e7e444af4464d6eef2513cdb335c'
for k in ['stdout','stderr','domain_before','domain_after']:
 f=out/r[k]['path'];b=f.read_bytes();assert len(b)==r[k]['bytes'] and hashlib.sha256(b).hexdigest()==r[k]['sha256']
cli=json.loads((out/'original-v15.stdout').read_text());assert cli['status']=='passed' and cli['complete_inputs']==1095 and cli['product_source']==r['product_P'] and cli['review_source']==r['review_R']
files=[]
for p in sorted(out.rglob('*')):
 assert not p.is_symlink()
 if p.is_dir():continue
 b=p.read_bytes();files.append({'path':'G-admission/'+p.relative_to(out).as_posix(),'original_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':oct(p.stat().st_mode&0o777)})
manifest={'schema_version':1,'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_G':r['source_G'],'product_P':r['product_P'],'review_R':r['review_R'],'scope':'Complete original actual G selected preparation and single actual original v15 execution. 1440 input files identical before/after; old dirty parent HEAD preserved. No diagnostic runtime, P2 engineering, scale or TODO completion claim.','files':files}
mb=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();zp=base/'native-db-observation-G-d7f-original-v15-round16.zip';assert not zp.exists()
with zipfile.ZipFile(zp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in files:z.writestr(f['path'],Path(f['original_path']).read_bytes())
 z.writestr('archive-manifest.json',mb)
with zipfile.ZipFile(zp) as z:
 assert z.testzip() is None
 for f in files:
  b=z.read(f['path']);assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
raw=zp.read_bytes();oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();transport=base64.b64encode(raw).decode()
receipt={'zip_path':str(zp),'zip_bytes':len(raw),'zip_sha256':hashlib.sha256(raw).hexdigest(),'git_blob':oid,'members':len(files)+1,'selected_files':len(files),'expanded_bytes':sum(f['bytes'] for f in files)+len(mb),'base64_chars':len(transport),'base64_sha256':hashlib.sha256(transport.encode()).hexdigest(),'original_v15_receipt':{'path':str(rp),'bytes':len(rb),'sha256':hashlib.sha256(rb).hexdigest()},'actual_v15_exit':r['exit_code'],'actual_G':r['source_G']}
for label,encoding in [('binary','base64'),('base64-transport','utf-8')]:
 cmd=['/opt/homebrew/bin/gh','api','-X','POST','repos/jyqj/codecortex/git/blobs','--input','-'];start=time.monotonic();p=subprocess.run(cmd,input=json.dumps({'content':transport,'encoding':encoding}).encode(),capture_output=True)
 receipt[label]={'command':cmd,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}
 if p.returncode:
  (base/'native-db-observation-G-d7f-original-v15-round16-transport.json').write_text(json.dumps(receipt,indent=2)+'\n');print(p.stderr.decode(errors='replace'));sys.exit(p.returncode)
 value=json.loads(p.stdout);receipt[label]['sha']=value['sha'];expected=oid if encoding=='base64' else hashlib.sha1(b'blob '+str(len(transport)).encode()+b'\0'+transport.encode()).hexdigest();assert value['sha']==expected
 (base/'native-db-observation-G-d7f-original-v15-round16-transport.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
