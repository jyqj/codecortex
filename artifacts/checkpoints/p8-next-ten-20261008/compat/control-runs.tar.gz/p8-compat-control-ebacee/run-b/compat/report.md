# CodeCortex benchmark baseline

Suite: `V19 Express public dev repair-v1 pending independent recheck`
Adapter: `rg-literal`
Scoring: `OceCompat`
Measurement profile: `smoke`

Status: **baseline_recorded_not_quality_certified** (exit 0)

Queries: 59; measured rows: 177.
Mean Top-1: 0.000000; mean nDCG@10: -0.000000.

These are baseline observations, not a release quality certificate.
Latency: Distribution { samples: 177, p50_us: Some(12331), p95_us: Some(149432), max_us: Some(267475), tail_claim: "insufficient_for_tail_claim" }; samples are retained, not best-of.
Source evidence: 0 invalid, 0 unverified hits.

| Case | Top-1 | nDCG@10 | Repetitions |
|---|---:|---:|---:|
| v19.express.f0001.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0002.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0004.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0006.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0007.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0010.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0013.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0014.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0015.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0024.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0025.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0028.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0031.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0032.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0033.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0035.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0036.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0038.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0039.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0040.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0042.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0043.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0045.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0046.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0047.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0048.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0049.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0050.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0051.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0053.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0054.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0055.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0056.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0057.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0058.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0060.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0061.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0063.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0064.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0065.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0068.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0069.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0070.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0072.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0074.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0075.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0076.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0077.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0079.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0080.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0081.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0083.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0085.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0088.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0098.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0099.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0100.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0101.en01 | 0.000000 | -0.000000 | 3 |
| v19.express.f0102.en01 | 0.000000 | -0.000000 | 3 |

## Measurement coverage

`latency-summary.json` retains its legacy success/no-match-only semantics. `latency-strata.json` retains every measured attempt, including deadline-censored timeouts and failures, and reports missing samples against the planned denominator. This runner records no per-request lifecycle/result-cache receipt, so these queries remain `unknown`; repetition and warmup do not prove cache hits. No OS cold-cache or performance-gate pass is inferred.

`resource-ledger.json` reports observed per-role RSS snapshots and missing observations. Native/ps runner alternatives, server PID/tree values and peaks from different stages are never summed. Disk layout, I/O and model billing remain unavailable until a profile supplies direct observations.

## Failures
