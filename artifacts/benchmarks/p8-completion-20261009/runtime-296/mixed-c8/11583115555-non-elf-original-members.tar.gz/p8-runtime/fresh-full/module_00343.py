def stable_00343():
    return 343
