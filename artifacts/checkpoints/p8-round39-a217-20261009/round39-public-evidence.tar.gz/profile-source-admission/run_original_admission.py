import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
VIEW=HERE/'guard-view'
OUT=HERE/'actual-original-validation'
OUT.mkdir(exist_ok=False)
ENV={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','GIT_TERMINAL_PROMPT':'0','GIT_OPTIONAL_LOCKS':'0','TMPDIR':str(HERE/'guard-temp')}
Path(ENV['TMPDIR']).mkdir(exist_ok=True)
def snapshot():
    reg=json.loads((VIEW/'scripts/reviewed-source-registry-v15.json').read_text())
    names=set(reg['complete_inputs'])|set(reg['validation_inputs'])|{'scripts/verify_reviewed_source_v15.py','scripts/reviewed-source-registry-v15.json','.github/workflows/ci.yml','artifacts/checkpoints/p8-profile-isolated-source-a217-20261009/independent-source-review.json'}
    names.update(e['path'] for e in json.loads((HERE/'private-view-actual-source-proof.json').read_text())['files'])
    hashes={p:hashlib.sha256((VIEW/p).read_bytes()).hexdigest() for p in sorted(names)}
    return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=VIEW,env=ENV).decode().strip(),'index_sha256':hashlib.sha256((VIEW/'.git/index').read_bytes()).hexdigest(),'inputs':hashes}
def execute(name,command):
    before=snapshot();(OUT/(name+'-inputs-before.json')).write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();timer=time.monotonic()
    with (OUT/(name+'.stdout')).open('wb') as stdout,(OUT/(name+'.stderr')).open('wb') as stderr:
        try:
            result=subprocess.run(command,cwd=VIEW,env=ENV,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=3600)
            exit_code=result.returncode;error=None
        except subprocess.TimeoutExpired:
            exit_code=None;error='outer timeout3600s; not success'
    wall=time.monotonic()-timer;after=snapshot()
    (OUT/(name+'-inputs-after.json')).write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
    record={'name':name,'command':command,'cwd':str(VIEW),'started_at_utc':started,'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_seconds':wall,'exit_code':exit_code,'error':error,'inputs_unchanged':before==after,'scope':'actual original CLI in byte-verified required-file projection; full historical Git objects; not full archive checkout; no Rust/native execution'}
    for ext in ['stdout','stderr']:
        raw=(OUT/(name+'.'+ext)).read_bytes();record[ext]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()}
    (OUT/(name+'-execution.json')).write_text(json.dumps(record,sort_keys=True,indent=2)+'\n');print(json.dumps(record),flush=True)
    assert before==after,'source/index changed'
    return exit_code
if execute('original-v15',['python3','-B','scripts/verify_reviewed_source_v15.py','--source-version','p8-completion-source-20261009-v15'])!=0:
    raise SystemExit(1)
raise SystemExit(execute('original-task-plan',['python3','-B','scripts/code_index_plan.py']))
