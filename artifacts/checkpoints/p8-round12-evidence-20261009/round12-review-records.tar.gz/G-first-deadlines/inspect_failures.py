"""Review original failed G shards without executing a native binary."""
import collections
import hashlib
import json
import sys
from pathlib import Path

if sys.flags.optimize:
    raise SystemExit("optimized Python disables review assertions")
sys.dont_write_bytecode = True
ROOT = Path("/workspace/scratch/2eaa00d0f93a/codecortex-scale-replay-G")
sys.path.insert(0, str(ROOT / "scripts"))
import p8_scale_matrix as matrix

HOME = Path(__file__).resolve().parent
BUILD = HOME.parent / "p8-scale-actions-37830173594/artifacts/p8-scale-build-37830173594"
build = matrix.read_json(BUILD / "build.json")
prior = matrix.read_json(HOME.parent / "p8-scale-actions-37830173594/build-replay-review.json")
assert prior["status"] == "passed"
assert matrix.file_sha256(BUILD / "build.json") == prior["build_receipt_sha256"]
assert matrix.file_sha256(BUILD / "p8-scale") == prior["binary_sha256"] == build["binary_sha256"]
assert build["files"] == matrix.inventory(BUILD, ("build.json",))
assert matrix.driver_snapshot(ROOT) == build["driver_source"]
matrix.verify_build_origin(build, [matrix.decode(line) for line in (BUILD / "cargo.jsonl").read_bytes().splitlines() if line])
build_source = matrix.read_json(BUILD / "source-before.json")
matrix.validate_snapshot(build_source)
assert build_source == matrix.read_json(BUILD / "source-after.json")

def summarize_builds(items):
    keys = ("prepare_us", "full_staging_us", "commit_write_us")
    return {"count": len(items), "outer_wall_us": sum(e["wall_us"] for e in items),
            "timing_observed_us": {key: (sum(e["report"]["build_timing"][key] for e in items if e["report"]["build_timing"][key] is not None)
                if any(e["report"]["build_timing"][key] is not None for e in items) else None) for key in keys}}

results = []
for artifact, index in ((11587885815, 7), (11587052830, 4)):
    out = HOME / str(artifact)
    receipt = matrix.read_json(out / "shard.json")
    before = matrix.read_json(out / "source-before.json")
    report = matrix.read_json(out / "native/report.json")
    assert receipt["files"] == matrix.inventory(out, ("shard.json",))
    matrix.validate_snapshot(before)
    assert before == matrix.read_json(out / "source-after.json") == build_source
    assert before["source_commit"] == receipt["source_commit"] == "bb9a96d71622458c39a143055360cc97f0d11d78"
    assert receipt["build_receipt_sha256"] == prior["build_receipt_sha256"]
    for key in ("source_manifest_sha256", "binary_sha256", "binary_blake3", "driver_source"):
        assert receipt[key] == build[key]
    plan = matrix.registered_plan(100000, index, 30, 30, 12648430, 18000000, "scale_capacity_v1")
    assert plan == receipt["plan"] == matrix.read_json(out / "registered-plan.json") == matrix.read_json(out / "native/plan.json")
    assert receipt["capacity_contract"] == matrix.capacity_contract()
    assert matrix.read_json(out / "disk-preflight.json")["passed"] is True
    assert receipt["status"] == "failed" and receipt["exit_code"] == 3
    assert report["status"] == "deadline_exceeded" and report["exit_code"] == 3
    assert report["worker_binary_unchanged"] is True
    assert report["worker_binary_digest_before"] == report["worker_binary_digest_after"] == build["binary_blake3"]
    assert report["summary"] is None and report["release_certification"] == report["full_100k_certification"] == "not_run"
    events = [json.loads(line) for line in (out / "native/raw.jsonl").open()]
    engine = events[0]["engine"]
    assert engine["binary_digest"] == build["binary_blake3"] and engine["engine_head_observed"] == build["source_commit"]
    assert engine["eval_debug_assertions"] is False
    try:
        matrix.validate_shard(out, build, BUILD / "p8-scale", prior["build_receipt_sha256"])
    except ValueError as error:
        shard_rejection = str(error)
    else:
        raise AssertionError("Failed shard accepted")
    try:
        matrix.inspect_raw(out / "native/raw.jsonl", plan)
    except ValueError as error:
        raw_rejection = str(error)
    else:
        raise AssertionError("Incomplete raw accepted")
    builds = [e for e in events if e["event"] == "build_finished"]
    finished = {e["label"] for e in builds}
    parities = [e for e in events if e["event"] in ("cold_parity", "stage_finished")]
    assert all(e["parity"]["equal"] and len(e["parity"]["tables"]) == 15 for e in parities)
    result = {"artifact_id": artifact, "shard_index": index, "status": "deadline_exceeded_not_certified",
        "source": receipt["source_commit"], "source_before_after_equal": True, "exact_original_build_binding": True,
        "native_binary_check_scope": "Original build replay receipt plus freshly unchanged SHA256; no native hashing command rerun.",
        "zip_sha256": matrix.file_sha256(HOME / f"{artifact}.zip"), "raw_sha256": matrix.file_sha256(out / "native/raw.jsonl"),
        "receipt_sha256": matrix.file_sha256(out / "shard.json"), "raw_rejection": raw_rejection,
        "shard_rejection": shard_rejection, "native_report": report, "engine": engine, "environment": receipt["environment"],
        "event_counts": dict(collections.Counter(e["event"] for e in events)),
        "completed_parity_groups": [e.get("sample", e.get("label")) for e in parities],
        "completed_full_builds": summarize_builds([e for e in builds if e["full"]]),
        "completed_incremental_builds": summarize_builds([e for e in builds if not e["full"]]),
        "completed_oracle_wall_us": sum(e["parity_wall_us"] for e in parities),
        "last_events": [{k: e[k] for k in ("event", "label", "start_us", "end_us", "wall_us", "incremental_builds", "complete", "passed") if k in e} for e in events[-5:]],
        "unfinished_builds": [{k: e[k] for k in ("label", "full", "start_us") if k in e} for e in events if e["event"] == "build_started" and e["label"] not in finished],
        "TODO_closed": 0}
    assert receipt["files"] == matrix.inventory(out, ("shard.json",))
    (HOME / f"{artifact}-inspection.json").write_text(json.dumps(result, indent=2) + "\n")
    results.append({k: result[k] for k in ("artifact_id", "shard_index", "status", "raw_rejection", "completed_parity_groups", "completed_full_builds", "completed_incremental_builds", "completed_oracle_wall_us", "unfinished_builds", "last_events")})
print(json.dumps(results, indent=2))
