#!/usr/bin/env python3
"""Record the actual packaging process exit and upload metadata; no repository mutation."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
B=Path(__file__).resolve().parent
def sha(v):return hashlib.sha256(v).hexdigest()
def blob(v):return hashlib.sha1(b'blob '+str(len(v)).encode()+b'\0'+v).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
argv=[sys.executable,str(B/'package-checkpoint.py')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (B/'package.stdout').open('xb') as out,(B/'package.stderr').open('xb') as err:
    proc=subprocess.run(argv,stdout=out,stderr=err,check=False)
receipt={'argv':argv,'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_exit_code':proc.returncode,'scope':'Evidence packaging only; no product/validator execution, no network or remote mutation','stdout_sha256':sha((B/'package.stdout').read_bytes()),'stderr_sha256':sha((B/'package.stderr').read_bytes())}
write(B/'packaging-command-receipt.json',receipt)
print(json.dumps(receipt,sort_keys=True))
if proc.returncode:sys.exit(proc.returncode)
out=B/'sealed-attempt01'
for name in ['package.stdout','package.stderr','packaging-command-receipt.json']:
    (out/name).write_bytes((B/name).read_bytes())
names=['round21-selected-evidence.zip','round21-member-index.json','round21-summary.json','round21-formal-closeout.json','README.md','packaging-command-receipt.json','package.stdout','package.stderr']
prefix=json.loads((B/'package-inputs.json').read_bytes())['repository_prefix']
files=[]
for name in names:
    p=out/name;raw=p.read_bytes();files.append({'repository_path':prefix+name,'local_path':str(p),'mode':'100644','type':'blob','bytes':len(raw),'sha256':sha(raw),'git_blob':blob(raw)})
write(out/'root-upload-manifest.json',{'scope':'Round21 selected checkpoint only; exact original formal-closeout separate leaf, no large R8 artifact duplication','files':files,'file_count':len(files),'remote_objects_created':False,'checkpoint_parent_must_be_freshly_checked':True})
print(json.dumps({'manifest_path':str(out/'root-upload-manifest.json'),'file_count':len(files),'files':files},sort_keys=True))
