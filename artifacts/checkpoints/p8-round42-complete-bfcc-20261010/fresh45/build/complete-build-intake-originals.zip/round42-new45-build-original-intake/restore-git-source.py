import pathlib,subprocess,json,datetime,time
ROOT=pathlib.Path('/workspace/scratch/bfccb8494ba0/round42-new45-build-original-intake')
VIEW=ROOT/'source-exact-G2'
VIEW.mkdir()
steps=[['git','init'],['git','remote','add','origin','https://github.com/jyqj/codecortex'],['git','config','remote.origin.promisor','true'],['git','config','remote.origin.partialclonefilter','blob:none'],['git','fetch','--depth=1','--filter=blob:none','origin','f97c5068d056969705e8387ba1f37d83847f5bee']]
for i,argv in enumerate(steps):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 with (ROOT/f'restore-{i}.stdout').open('wb') as out,(ROOT/f'restore-{i}.stderr').open('wb') as err:
  try: code=subprocess.run(argv,cwd=VIEW,stdout=out,stderr=err,timeout=180).returncode
  except subprocess.TimeoutExpired: code=124
 record={'argv':argv,'cwd':str(VIEW),'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_seconds':time.monotonic()-t,'exit':code}
 (ROOT/f'restore-{i}.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record),flush=True)
 if code: raise SystemExit(code)
