def stable_00253():
    return 253
