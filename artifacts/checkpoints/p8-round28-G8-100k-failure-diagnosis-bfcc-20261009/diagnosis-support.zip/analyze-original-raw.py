#!/usr/bin/env python3
"""Read original terminal raw records; no product, validator, database or ZIP execution."""
import collections
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/bfccb8494ba0')
ORIGINAL = ROOT / 'round28-G8-100k-original-failure/shard-original'
OUT = ROOT / 'round28-G8-100k-phase-diagnostic'
SOURCE = '4fe927488d5cb7f26bd27c7624745fb1b6ca202b'

def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}

inputs = [ORIGINAL / n for n in ['native/raw.jsonl', 'native/report.json', 'native/worker.stderr',
          'shard.json', 'supervisor.stdout', 'supervisor.stderr', 'source-before.json',
          'source-after.json', 'registered-plan.json', 'native/plan.json']]
before = [identity(p) for p in inputs]
raw = [json.loads(line) for line in inputs[0].read_text().splitlines()]
assert before[0]['sha256'] == '72ec93ae24739379a00d08d6f97219ce823f2a34762d7c47ecbe6b886da691a5'
report = json.loads((ORIGINAL / 'native/report.json').read_text())
shard = json.loads((ORIGINAL / 'shard.json').read_text())
plan = json.loads((ORIGINAL / 'registered-plan.json').read_text())
source = json.loads((ORIGINAL / 'source-before.json').read_text())
assert source['source_commit'] == SOURCE == shard['source_commit']
assert (ORIGINAL/'source-before.json').read_bytes() == (ORIGINAL/'source-after.json').read_bytes()
assert report['status'] == 'deadline_exceeded' and report['exit_code'] == 3
assert report['summary'] is None and shard['status'] == 'failed'

source_paths = {
    'p8_scale.rs': 'crates/cc-eval/src/benchmark/p8_scale.rs',
    'streaming.rs': 'crates/cc-eval/src/benchmark/oracle/streaming.rs',
    'resolution_dependency_store.rs': 'crates/cc-db/src/resolution_dependency_store.rs',
    'public_surface_store.rs': 'crates/cc-db/src/public_surface_store.rs',
    'reconcile.rs': 'crates/cc-index/src/indexer_phases/reconcile.rs',
}
source_ids = []
for local, repo in source_paths.items():
    item = identity(OUT/'source'/local)
    assert item['sha256'] == source['inputs'][repo], repo
    item.update(repository_path=repo, source_commit=SOURCE)
    source_ids.append(item)

builds = [r for r in raw if r['event'] == 'build_finished']
starts = [r for r in raw if r['event'] == 'build_started']
assert collections.Counter(r['label'] for r in starts) == collections.Counter(r['label'] for r in builds)
assert all(r['end_us']-r['start_us'] == r['wall_us'] for r in builds)
parities = [r for r in raw if r['event'] in ('cold_parity','stage_finished')]
full = [r for r in builds if r['full']]
inc = [r for r in builds if not r['full']]
groups = collections.defaultdict(list)
for r in builds:
    groups[r['label'].split('/')[2]].append(r)

def aggregate_builds(rows):
    return {
        'count': len(rows), 'outer_wall_us': sum(r['wall_us'] for r in rows),
        'reported_phase_timing_ms': {
            key: sum(r['report']['phase_timing'].get(key,0) for r in rows)
            for key in sorted({k for r in rows for k in r['report']['phase_timing']})},
        'reported_build_timing_us': {
            key: sum(r['report']['build_timing'].get(key) or 0 for r in rows)
            for key in sorted({k for r in rows for k in r['report']['build_timing'] if k.endswith('_us')})},
        'dependency_sql_counters': {
            key: sum(r['report']['dirty_plan']['dependency_sql'].get(key,0) for r in rows)
            for key in ['rows','statements','sorts','vm_steps','fullscan_steps']},
    }

stage_rows = []
for name, rows in groups.items():
    incremental = [r for r in rows if not r['full']]
    stage_rows.append({
        'stage': name, 'full': aggregate_builds([r for r in rows if r['full']]),
        'incremental': aggregate_builds(incremental),
        'first_build_start_us': min(r['start_us'] for r in rows),
        'last_build_end_us': max(r['end_us'] for r in rows),
        'first_incremental_dirty_plan': incremental[0]['report']['dirty_plan'] if incremental else None,
        'last_incremental_dirty_plan': incremental[-1]['report']['dirty_plan'] if incremental else None,
        'last_incremental_freshness': incremental[-1]['report']['resolution_freshness'] if incremental else None,
    })

parity_rows = []
for r in parities:
    p = r['parity']
    table_rows = [{k:t[k] for k in ['table','equal','incremental_rows','full_rows','equal_input_order_witness']} for t in p['tables']]
    assert len(table_rows) == 15 and p['equal'] is True
    parity_rows.append({
        'stage': r.get('label','cold').split('/')[-1], 'parity_wall_us': r['parity_wall_us'],
        'stage_finished': r['event']=='stage_finished', 'passed': r.get('passed'),
        'canonical_bytes': p['canonical_bytes'], 'scratch_peak_bytes': p['scratch_peak_bytes'],
        'sorting_cache_kib': p['sorting_cache_kib'], 'capacity_profile': p['capacity_profile'],
        'storage_layout': p['storage_layout'], 'tables': table_rows,
        'witness_true_tables': [t['table'] for t in table_rows if t['equal_input_order_witness']],
        'witness_false_tables': [t['table'] for t in table_rows if not t['equal_input_order_witness']],
    })

build_wall = sum(r['wall_us'] for r in builds)
parity_wall = sum(r['parity_wall_us'] for r in parities)
last = builds[-1]
result = {
    'schema_version': 1, 'scope': 'read_only_original_raw_and_exact_source_diagnosis',
    'source_commit': SOURCE, 'run_id': 37962416564, 'run_attempt': 1,
    'job_id': 113930880282, 'artifact_id': 11647876945, 'scale':100000, 'repetition':0,
    'original_inputs_before': before, 'source_files': source_ids,
    'terminal': {'native_report': report, 'actions_step_exit_code':1,
        'native_supervisor_exit_code':3, 'worker_exit_code':None,
        'stderr_complete':False, 'empty_stderr_does_not_prove_complete_absence_of_error':True},
    'registered_plan':plan, 'raw_lines':len(raw), 'event_counts':dict(collections.Counter(r['event'] for r in raw)),
    'all_emitted_build_starts_have_finish':True, 'full_builds':aggregate_builds(full),
    'incremental_builds':aggregate_builds(inc), 'stages':stage_rows, 'completed_parities':parity_rows,
    'completed_costs':{
        'build_outer_wall_us':build_wall, 'parity_wall_us':parity_wall,
        'sum_nonoverlapping_recorded_build_and_parity_us':build_wall+parity_wall,
        'canonical_bytes_total_across_completed_parities':sum(p['parity']['canonical_bytes'] for p in parities),
        'last_build_end_worker_clock_us':last['end_us'],
        'worker_clock_minus_completed_timers_us':last['end_us']-build_wall-parity_wall,
        'nominal_deadline_minus_last_build_end_us':plan['deadline_ms']*1000-last['end_us'],
        'nominal_delta_is_not_a_measured_parity_duration':True,
    },
    'last_record':{k:last[k] for k in ['event','label','start_us','end_us','wall_us','full','resource_scope','process_snapshot']},
    'stop_interval':{
        'last_completed_stage':'batch_10', 'in_progress_unfinished_stage':'batch_100',
        'last_completed_build':'batch_100/full_control', 'next_stage_batch_1000_observed':False,
        'exact_source_lines':'p8_scale.rs:897-925; parity:581-603',
        'possible_unlogged_work':['parity counts(A/B)','streaming full comparison','config_fact','stage verdict construction or raw emission'],
        'parity_started_event_exists':False, 'per_table_phase_timing_exists':False,
        'precise_active_function_or_table_at_kill':None,
    },
    'interpretation_limits':[
        'This is one failed repetition, not a successful shard/sample or a confidence interval.',
        'Build timing subfields and phase timing overlap; never sum them with outer build wall time.',
        'Dependency SQL counters combine dependency and positive-surface queries, not one method.',
        'Canonical bytes are logical validation accounting, not measured disk transfer bytes.',
        'Scratch sizes are the reported oracle file high-water mark, not global disk peak or IO latency.',
        'Process snapshots are not a process-tree RSS peak.',
        'Seven successful intermediate parities do not complete batch_100/batch_1000 or the shard.',
        'Wider-dirty or restored-dual-spool sources are distinct; no cross-source causal performance credit.',
        'No product, original validator, CRC validation, study, compiler or test was executed by this analysis.',
    ],
    'original_inputs_after':[identity(p) for p in inputs],
}
assert result['original_inputs_after'] == before
(OUT/'diagnostic.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'completed_read_only','raw_lines':len(raw),'full_builds':len(full),
 'incremental_builds':len(inc),'completed_parities':len(parities),'build_wall_us':build_wall,
 'parity_wall_us':parity_wall,'last_completed_build':last['label'],
 'original_inputs_unchanged':True,'diagnostic':identity(OUT/'diagnostic.json')},sort_keys=True))
