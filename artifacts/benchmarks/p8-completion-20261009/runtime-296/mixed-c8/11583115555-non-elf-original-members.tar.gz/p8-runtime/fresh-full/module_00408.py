def stable_00408():
    return 408
