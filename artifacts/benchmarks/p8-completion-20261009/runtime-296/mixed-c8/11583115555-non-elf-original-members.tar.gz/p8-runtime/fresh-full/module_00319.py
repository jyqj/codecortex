def stable_00319():
    return 319
