#!/usr/bin/env python3
"""Uncommitted author-side Git/map preparation, without source execution."""
import ast
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HELPER = ROOT.parent/'R3-G3-thin-review/verify-G3-two-bindings.py'
PATH = 'crates/cc-db/tests/p2b_resolution_store.rs'
module = ast.parse(HELPER.read_text())
nodes = []
for node in module.body:
    if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'report' for t in node.targets):
        break
    nodes.append(node)
namespace = {'__file__': str(HELPER)}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(HELPER), 'exec'), namespace)
leaves = namespace['leaves']
canonical = namespace['canonical']
assert namespace['root'] == 'e7a7f5a685c44aee34b8716377308f0af8782fdd'
raw = (ROOT/'candidate'/PATH).read_bytes()
sha = hashlib.sha256(raw).hexdigest()
git_blob = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
assert git_blob == '9c2aa567b007cb7c3a97adce2bb7184c0662a18f'
assert leaves[PATH]['sha'] == '265e2b7ae7660c7dbd07e2f8d8c26efe8206ff7c'
before = copy.deepcopy(leaves)
leaves[PATH] = {'mode': '100644', 'type': 'blob', 'sha': git_blob, 'size': len(raw)}
tree = namespace['hash_leaves'](leaves)['']
assert [p for p in leaves if leaves[p] != before[p]] == [PATH]
maps = {key: copy.deepcopy(canonical[key]) for key in ['base', 'complete_inputs', 'validation_inputs', 'paths', 'actual_input_mode_blob_inventory']}
maps['complete_inputs'][PATH] = sha
maps['paths'][PATH]['sha256'] = sha
maps['actual_input_mode_blob_inventory'][PATH].update(sha=git_blob, sha256=sha, size=len(raw))
assert [len(maps[k]) for k in ['complete_inputs', 'paths', 'validation_inputs']] == [1095,70,142]
assert all(maps['complete_inputs'][p] == value for p,value in canonical['complete_inputs'].items() if p != PATH)
assert maps['validation_inputs'] == canonical['validation_inputs']
for path, row in maps['actual_input_mode_blob_inventory'].items():
    assert all(row[k] == leaves[path][k] for k in ['mode','type','sha'])
maps.update(actual_P4=None, expected_tree=tree, required_ordered_parents=['67b7f4ee15a9c9633868b446870fec1358dda3d9'], parent_tree=namespace['root'], scope='author-side prospective identity preparation; not an independent R and not a committed object', product_runtime='not_run', all_original_G3_artifacts_and_other_leaves_retained=True, source_binding_inherited_from_G3_pending_new_R_G=True)
request = {'base_tree': namespace['root'], 'tree': [{'path': PATH, 'mode': '100644', 'type': 'blob', 'sha': git_blob}]}
for name, value in [('prospective-P4-complete-product-validation-inputs.json', maps), ('P4-one-leaf-create-tree-request.json', request)]:
    with (ROOT/name).open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write('\n')
print(json.dumps({'actual_P4': None, 'expected_tree': tree, 'ordered_parents': maps['required_ordered_parents'], 'source_count':1095,'validation_count':142,'historical_delta_count':70,'changed_leaves':1,'git_blob':git_blob},sort_keys=True))
