from pathlib import Path

BASE = Path('/workspace/scratch/bfccb8494ba0')
old = (BASE / 'round40-PR192-main-integration-candidate/candidate/scripts/p8_profile_matrix.py').read_text()
out = BASE / 'round40-task-descriptive-driver-candidate/candidate/scripts/p8_task_profile_matrix.py'
text = old.replace('p8-isolated-profile-study-v1', 'p8-profile-task-descriptive-v1')
text = text.replace('profile_isolated_v1', 'profile_task_descriptive_v1')
text = text.replace('p8_profile_matrix.py', 'p8_task_profile_matrix.py')
text = text.replace('profile-build', 'task-build').replace('profile-shard', 'task-shard').replace('profile-matrix', 'task-matrix')
text = text.replace('profile_build_receipt_sha256', 'task_build_receipt_sha256')
text = text.replace('profile observer', 'task observer').replace('profile envelope', 'task envelope')
start = text.index('"""')
end = text.index('"""', start + 3) + 3
text = text[:start] + '''"""Independent N=1 descriptive task population: 45 cells and 85 retained records.

Fresh history per mutation, complete original native closure and fifteen-table
parity, no tail statistics, no automatic task status or release certification.
The existing N30 isolated profile study and sequential study remain unchanged.
"""''' + text[end:]
start = text.index('DRIVER_FILES =')
end = text.index('\nrequire =', start)
text = text[:start] + '''DRIVER_FILES = full.DRIVER_FILES + (
    "scripts/p8_task_profile_matrix.py", "scripts/p8_runner_capacity.py",
    "scripts/p8_task_profile_capture.py",
    "scripts/tests/test_p8_task_profile_matrix.py",
    "scripts/tests/test_p8_task_profile_capture.py",
    ".github/workflows/p8-task-profile.yml",
    "docs/roadmap/code-index-v2/P8-TASK-PROFILE-DESCRIPTIVE.md",
    "docs/roadmap/code-index-v2/p8-profile-task-descriptive-v1.json",
)''' + text[end:]
start = text.index('def registered_plan(')
end = text.index('\n\ndef envelope(', start)
text = text[:start] + '''def registered_plan(scale, shard_index, shard_count=1, repetitions=1, seed=12648430,
                    deadline_ms=18_000_000, capacity_profile=full.CAPACITY_PROFILE, *, study,
                    mutation_profile, fanout=None):
    require(type(repetitions) is int and repetitions == 1 and type(shard_count) is int and shard_count == 1
            and type(shard_index) is int and shard_index == 0 and type(seed) is int and seed == 12648430
            and type(deadline_ms) is int and deadline_ms == 18_000_000
            and capacity_profile == full.CAPACITY_PROFILE,
            "descriptive task N1/seed/worker budget/capacity differs")
    require(type(scale) is int and scale in full.SCALES, "noncanonical task scale")
    require(mutation_profile in PROFILES + ("fanout",), "unknown task profile")
    if mutation_profile == "fanout":
        require(type(fanout) is int and fanout in full.FANOUTS and scale == 1000,
                "fanout requires actual N+1 files; 1000 is only the capacity field")
    else:
        require(fanout is None, "mutation cell cannot carry a fanout")
    require(full.exact_equal(study, study_identity(study["run_id"], study["run_attempt"])),
            "task study identity differs")
    contract = full.capacity_contract(capacity_profile)
    return dict(schema_version=1, profile="release", files=[scale], seed=seed,
                repetitions=1, shard=dict(index=0, count=1),
                skip_fanout=mutation_profile != "fanout", capacity_profile=capacity_profile,
                dirty_budget=contract["scale_dirty_budget"],
                max_resume_builds=contract["scale_max_resume_builds"],
                batch_sizes=list(full.BATCHES), fanouts=list(full.FANOUTS),
                deadline_ms=deadline_ms, max_output_bytes=full.MAX_BYTES, stage_scope=SCOPE,
                profile_study=dict(run_id=study["run_id"], run_attempt=study["run_attempt"],
                                   mutation_profile=mutation_profile, fanout=fanout))


def registration(study, driver, built, native_receipt_sha256):
    """Written by build before any cell; every consumer checks this exact object."""
    return dict(schema=SCHEMA, kind="task-registration", stage_scope=SCOPE,
                study=study, driver_source=driver,
                source_commit=built["source_commit"],
                source_manifest_sha256=built["source_manifest_sha256"],
                binary_sha256=built["binary_sha256"], binary_blake3=built["binary_blake3"],
                native_build_receipt_sha256=native_receipt_sha256,
                repetitions=1, cell_count=45, record_count=85,
                cold_curve_selection="no_op setup only: five scales; included in forty setup records",
                plans=[registered_plan(1000 if profile == "fanout" else amount, index,
                         study=study, mutation_profile=profile,
                         fanout=amount if profile == "fanout" else None)
                       for profile, amount, index in sorted(expected_slots())],
                statistics="not_computed_N1_descriptive", task_statuses_changed=False,
                release_certification="not_run")''' + text[end:]
text = text.replace('inspected = full._inspect_raw(path, plan, isolated_profile=profile)',
                    'inspected = full._inspect_raw(path, plan, isolated_profile=profile, profile_scope=SCOPE)')
text = text.replace('"isolated native sample count differs"', '"task native sample count differs"')
text = text.replace('"native profile terminal summary differs"', '"native task terminal summary differs"')
anchor = '        require(record["driver_source"] == driver_snapshot(root), "profile build observer changed")\n'
assert anchor in text
text = text.replace(anchor, anchor + '''        registry = registration(record["study"], record["driver_source"], native,
                                file_sha256(out / "native-build/build.json"))
        full.write_new(out / "task-registry.json", registry)
        record["registration_sha256"] = file_sha256(out / "task-registry.json")
''')
anchor = '    return outer, built, binary\n'
assert text.count(anchor) == 1
text = text.replace(anchor, '''    require(outer["registration_sha256"] == file_sha256(directory / "task-registry.json"),
            "task registration bytes changed")
    require(full.exact_equal(full.read_json(directory / "task-registry.json"),
            registration(outer["study"], outer["driver_source"], built,
                         outer["native_build_receipt_sha256"])), "task registration differs")
    return outer, built, binary
''')
start = text.index('def run_shard(')
end = text.index('\n\ndef expected_fanout_case(', start)
text = text[:start] + '''def run_shard(root, build_directory, output, scale, shard_index, run_id, attempt, mutation_profile, fanout=None):
    root = Path(root).resolve(strict=True)
    study = study_identity(run_id, attempt)
    out = full.new_directory(output)
    record = envelope(out, "task-shard", study, driver_snapshot(root))
    record["requested_slot"] = dict(scale=scale, shard_index=shard_index,
                                    mutation_profile=mutation_profile, fanout=fanout)
    try:
        built, _, _ = validate_build(build_directory, root)
        require(built["study"] == study, "build belongs to another task run/attempt")
        record["task_build_receipt_sha256"] = file_sha256(Path(build_directory) / "task-build.json")
        record["registration_sha256"] = built["registration_sha256"]
        record["measurement_environment"] = observed_environment(out)
        plan = registered_plan(scale, shard_index, study=study, mutation_profile=mutation_profile, fanout=fanout)
        record["plan"] = plan
        inner = full.run_shard(root, Path(build_directory) / "native-build", out / "native-shard", plan)
        require(inner["status"] == "passed", "native task shard failed")
        require(record["driver_source"] == driver_snapshot(root), "task observer changed during measurement")
        require(record["measurement_environment"] == observed_environment(out), "measurement environment changed")
        record.update(status="passed", passed=True)
    except ERRORS as error:
        record["error"] = str(error)
    return finish(out, "task-shard.json", record)''' + text[end:]
anchor = '    selection = full.read_json(directory / "native-shard/registered-plan.json")["profile_study"]\n'
assert text.count(anchor) == 1
text = text.replace(anchor, '''    require(record["registration_sha256"] == outer_build["registration_sha256"],
            "task shard used another registration")
    original_plan = full.read_json(directory / "native-shard/registered-plan.json")
    require(full.exact_equal(record["plan"], original_plan), "outer/native task plan differs")
    selection = original_plan["profile_study"]
''')
text = text.replace('                            study=record["study"], driver_source=record["driver_source"],',
'''                            study=record["study"], driver_source=record["driver_source"],
                            registration_sha256=record["registration_sha256"],''')
start = text.index('def expected_slots():')
end = text.index('\n\ndef main():', start)
text = text[:start] + '''def expected_slots():
    return ({(profile, scale, 0) for profile in PROFILES for scale in full.SCALES}
            | {("fanout", fanout, 0) for fanout in full.FANOUTS})


def combine(shards):
    expected = expected_slots()
    seen, identities, environments, inputs = set(), set(), {}, {}
    cells, setup, mutations, fanouts, cold_curve = [], [], [], [], []
    for shard in shards:
        plan = shard["plan"]
        key = slot_key(plan)
        require(key in expected and key not in seen, "duplicate/unexpected task slot")
        fanout = key[0] == "fanout"
        require(full.exact_equal(plan, registered_plan(plan["files"][0], key[2], study=shard["study"],
            mutation_profile=key[0], fanout=key[1] if fanout else None)), "task registered plan differs")
        seen.add(key)
        engine = shard["engine"]
        identity = {field: engine.get(field) for field in ("engine_head_observed", "source_files_digest", "cargo_lock_digest",
                    "binary_digest", "eval_version", "os", "arch", "rustflags", "eval_debug_assertions")}
        identity.update(study=shard["study"], driver_source=shard["driver_source"],
                        build_receipt_sha256=shard["build_receipt_sha256"],
                        registration_sha256=shard["registration_sha256"])
        identities.add(json.dumps(identity, sort_keys=True))
        measurements = shard["measurements"]
        require(len(measurements) == (1 if fanout else 2), "missing setup or selected task profile")
        sample = measurements[-1]
        group = f"fanout-{key[1]}" if fanout else f"scale-{key[1]}/{key[0]}"
        sample_id = f"fanout-{key[1]}/repetition-0" if fanout else f"scale-{key[1]}/repetition-0"
        require(sample["group"] == group and sample["sample"] == sample_id, "task sample identity differs")
        environment = dict(shard["environment"], engine_cpu_parallelism=engine.get("cpu_parallelism"),
                           measurement_environment=shard["measurement_environment"],
                           profile_environment=shard["profile_environment"])
        require(isinstance(environment.get("host"), str) and environment["host"], "missing measured host")
        full.integer(environment["engine_cpu_parallelism"], "native CPU parallelism", 1)
        environment_id = hashlib.sha256(json_bytes(environment)).hexdigest()
        environments[environment_id] = environment
        input_key = f"fanout-{key[1]}" if fanout else f"scale-{key[1]}"
        if input_key in inputs:
            require(inputs[input_key] == shard["input_digest"], "pristine corpus differs across task profiles")
        inputs[input_key] = shard["input_digest"]
        selected = dict(slot=list(key), n=1, environment_id=environment_id, sample=sample)
        if fanout:
            fanouts.append(selected)
        else:
            cold = measurements[0]
            require(cold["group"] == f"scale-{key[1]}/cold" and cold["sample"] == sample_id,
                    "missing pristine setup pair")
            initial = dict(slot=list(key), n=1, environment_id=environment_id,
                           sample=cold, resource_snapshots=shard["resource_snapshots"])
            setup.append(initial)
            if key[0] == "no_op":
                cold_curve.append(initial)
            mutations.append(selected)
        cells.append(dict(slot=list(key), environment_id=environment_id,
                          directory=shard["directory"], receipt_sha256=shard["receipt_sha256"],
                          measurements=measurements))
    require(seen == expected and len(identities) == 1, "missing task slots or mixed source/binary/driver/build/run/attempt")
    require(len(cells) == 45 and len(setup) == len(mutations) == 40 and len(fanouts) == len(cold_curve) == 5,
            "task record coverage differs")
    require(any(item["sample"].get("first_build_incomplete") is True for item in fanouts),
            "no actual over-budget closure observed")
    for values in (cells, setup, mutations, fanouts, cold_curve):
        values.sort(key=lambda item: item["slot"])
    return dict(schema=SCHEMA, stage_scope=SCOPE, status="complete_task_descriptive_coverage", passed=True,
                study=shards[0]["study"], engine=json.loads(next(iter(identities))), registered_repetitions=1,
                cell_count=45, sample_count=85, record_count=85,
                mutation_sample_count=40, fanout_sample_count=5, setup_pair_count=40,
                setup_pairs=setup, mutation_samples=mutations, fanout_samples=fanouts,
                cold_curve_from_no_op=cold_curve, cold_curve_is_subset_of_setup=True,
                cells=cells, environments=environments, capacity_contract=full.capacity_contract(),
                input_digests=inputs,
                evidence=[dict(directory=s["directory"], receipt_sha256=s["receipt_sha256"]) for s in shards],
                history="fresh pristine A/B per profile; distinct from sequential warm/history distribution",
                deadline_scope="five hours per cell INCLUDING setup, full control and complete parity",
                total_time_allowance="225 worker-hours across 45 cells; neither old 150 nor isolated N30 population",
                scope="P8-006 descriptive task evidence only; no automatic task completion",
                resources_scope="original worker snapshots, not peaks or process-tree proof",
                statistics_scope="N1 per cell, each environment retained; no pooled or tail statistics",
                release_certification="not_run", G8="not_evaluated", task_statuses_changed=False)


def aggregate(build_directory, directories, output, root=None):
    out = full.new_directory(output)
    attempts, shards, errors = [], [], []
    result = dict(schema=SCHEMA, stage_scope=SCOPE, status="failed", passed=False,
                  release_certification="not_run", task_statuses_changed=False)
    try:
        outer, built, binary = validate_build(build_directory, root)
        result.update(study=outer["study"], driver_source=outer["driver_source"],
                      registration_sha256=outer["registration_sha256"],
                      task_build_receipt_sha256=file_sha256(Path(build_directory) / "task-build.json"))
        # Attempt every supplied cell once, retaining failures; never substitute a prefix.
        for directory in directories:
            entry = dict(directory=str(directory), status="failed", passed=False)
            try:
                path = Path(directory)
                entry["files"] = full.inventory(path)
                receipt = path / "task-shard.json"
                if receipt.is_file():
                    entry["original_task_receipt"] = full.read_json(receipt)
                    entry["receipt_sha256"] = file_sha256(receipt)
                inspected = validate_shard(path, outer, built, binary, build_directory, root)
                shards.append(inspected)
                entry.update(status="passed", passed=True, slot=list(slot_key(inspected["plan"])))
            except ERRORS as error:
                entry["error"] = str(error)
                errors.append(dict(directory=str(directory), error=str(error)))
            attempts.append(entry)
        require(not errors, "one or more task cells failed original validation")
        result.update(combine(shards))
    except ERRORS as error:
        result["error"] = str(error)
    result["input_results"] = attempts
    result["input_errors"] = errors
    result["missing_slots"] = [list(slot) for slot in sorted(expected_slots() - {slot_key(s["plan"]) for s in shards})]
    result["accepted_cell_count"] = len(shards)
    full.write_new(out / "task-matrix.json", result)
    return result
''' + text[end:]
text = text.replace('from collections import defaultdict\n', '')
out.write_text(text)
