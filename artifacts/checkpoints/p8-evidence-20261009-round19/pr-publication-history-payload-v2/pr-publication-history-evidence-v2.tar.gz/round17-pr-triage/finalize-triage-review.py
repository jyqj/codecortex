from pathlib import Path
import collections,datetime,difflib,hashlib,json,re,subprocess
P=Path('/dev/shm/a217aaae3bde/platform-review/round17-pr-triage')
E='a23bb72d3c954f385b99fe81ce9189885c208557'
V='/dev/shm/a217aaae3bde/codecortex-combined-guard-view'
def read(n):return json.loads((P/n).read_text())
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def digest(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob_sha1':blob(b)}
def write(n,d):
 p=P/n;p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(digest(p)))
def git(path):return subprocess.check_output(['git','-C',V,'show',E+':'+path])
logs=[]
for pr,job,metadata in [(168,113640456594,'pr168-ci-jobs-1791517066875.json'),(168,113640456619,'pr168-ci-jobs-1791517066875.json'),(169,113649687536,'pr169-ci-jobs-1791517066875.json')]:
 f=P/f'job-{job}-original.log';s=f.read_text();lines=s.splitlines();official=next(x for x in read(metadata)['jobs'] if x['id']==job)
 checkout=[]
 for i,l in enumerate(lines):
  if 'git log -1 --format=%H' in l:checkout.append({'line':i+2,'sha':lines[i+1].split()[-1]})
 assert len(checkout)==1
 groups=[{'line':i+1,'text':l,'counts':list(map(int,m.groups()))} for i,l in enumerate(lines) if (m:=re.search(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',l))]
 ignored=[{'line':i+1,'text':l} for i,l in enumerate(lines) if re.search(r'\btest .+ \.\.\. ignored',l)]
 special=[{'line':i+1,'text':l} for i,l in enumerate(lines) if re.search(r'test (?:index_db_snapshot_insert::tests::(?:bound_payload_measures_sql_values_and_keeps_large_rows_legal|failed_window_stops_before_later_rows_or_tables|semantic_leaf_batches_reduce_actual_sqlite_statement_runs)|snapshot_leaf_[\w]+) \.\.\. ok$',l)]
 failures=[{'line':i+1,'text':l} for i,l in enumerate(lines) if any(x in l for x in ('error[E0282]','snapshot_leaf_batching.rs:149:','Process completed with exit code 101'))]
 guard=[{'line':i+1,'text':l,'report':json.loads(l.split(' ',1)[1])} for i,l in enumerate(lines) if '"status": "passed"' in l and ('"source_version": "p8-completion-source-20261009-v15"' in l or '"verifier_version": "historical-integrations-v2"' in l)]
 if pr==168:
  assert official['conclusion']=='failure' and failures and not special
  assert checkout[0]['sha']=='4b79e13c94c564a9a3b1b46c96216c5e68177c2c'
 else:
  assert official['conclusion']=='success' and len(special)==9
  assert checkout[0]['sha']=='fa6c6c69ae3dd459a78b60c9d5ca369f9eb9824b'
  assert all(x['counts'][1]==0 for x in groups)
  assert len(guard)==2 and guard[0]['report']['product_source']=='29281cbca0004ae1228f2599ca8f4a704507f60d' and guard[0]['report']['complete_inputs']==1089
 logs.append({'pr':pr,'job_id':job,'run_id':official['run_id'],'name':official['name'],'official_head':official['head_sha'],'conclusion':official['conclusion'],'actual_checkout':checkout,'log':digest(f),'official_job':official,'rust_result_groups':groups,'rust_totals_are_occurrences_not_unique_tests':True,'rust_totals':dict(zip(['passed','failed','ignored','measured','filtered'],[sum(x['counts'][j] for x in groups) for j in range(5)])),'all_ignored_named_lines':ignored,'nine_new_actual_controls':special,'failure_original_lines':failures,'original_guard_lines':guard})
write('candidate-ci-original-logs-independent-review.json',{'schema':'candidate-ci-original-log-review-v1','reviewer':'/root/pr_audit','scope':'Official original completed job logs of fixed PR168/169; no local native execution, no scale acceptance, no source adoption','saved_memory_byte_proof':digest(P/'original-logs-memory-byte-proof.json'),'logs':logs,'limits':['PR168 E0282/exit101 history remains failed','PR169 nine controls really executed successfully at actual test merge fa6c6c6; this does not accept its different runtime failure semantics or a 100k result','All ignored occurrences retained; official job head and actual checkout are separate identities'],'task_counts':{'done':163,'remaining':29,'newly_completed':0}})
raws=read('E-vs169-runtime-rollback-original-captures.json');verified=[]
remote169={e['path']:e for e in read('pr169-scripts-1791516951145.json')['tree']}
for key,s in raws.items():
 side,path=key.split('|');b=s.encode();sha=blob(b)
 if side=='E':assert b==git(path)
 else:assert sha==remote169[path.removeprefix('scripts/')]['sha']
 verified.append({'side':side,'path':path,'bytes':len(b),'git_blob_sha1':sha,'sha256':hashlib.sha256(b).hexdigest()})
types=read('pr168-pr169-typefix-original-captures.json');types={x['name']:x['content'] for x in types}
ta=types['168'].splitlines(keepends=True);tb=types['169'].splitlines(keepends=True)
assert len(ta)==len(tb) and [i for i,(a,b) in enumerate(zip(ta,tb)) if a!=b]==[148]
assert ta[148].strip()=='.collect::<rusqlite::Result<_>>()' and tb[148].strip()=='.collect::<rusqlite::Result<Vec<String>>>()'
for side,s in types.items():
 inv={e['path']:e for e in read(f'pr{side}-crates-1791516951145.json')['tree']}
 assert blob(s.encode())==inv['cc-index/tests/snapshot_leaf_batching.rs']['sha']
tasks_raw=(P/'pr161-tasks-blob-1791517066875.json').read_bytes()
assert blob(tasks_raw[:-1])=='f36b757b0d75ac9b495be039b35b187e8d4ff788'
tasks=json.loads(tasks_raw);base=json.loads(git('docs/roadmap/code-index-v2/tasks.json'))
assert {k:v for k,v in tasks.items() if k!='tasks'}=={k:v for k,v in base.items() if k!='tasks'}
taskdiff=[]
for a,b in zip(base['tasks'],tasks['tasks']):
 assert a['id']==b['id'] and a['status']==b['status']
 ks=[k for k in set(a)|set(b) if a.get(k)!=b.get(k)]
 assert not set(ks)-{'evidence','implementation_notes'}
 if ks:taskdiff.append({'id':a['id'],'changed_fields':sorted(ks)})
assert [x['id'] for x in taskdiff]==['P8-007','P8-010','P8-012','P8-016']
openprs=read('open-page-1-1791516824492.json');assert read('open-page-2-1791516844972.json')==[]
assert len(openprs)==35 and sum(x['draft'] for x in openprs)==34
decision={'schema':'round17-pr-triage-final-independent-review-v1','reviewer':'/root/pr_audit','scope':'Fresh paginated PR inventory, exact Git source differences and actual candidate CI logs; read-only, no source adoption','captured_snapshot_readback':1791516824492,'main':'4775bf44dc09c11cea88211e06ccec97c4de44aa','frozen_E':E,'open_count':35,'draft_count':34,'all_open_pr_heads':[{'number':x['number'],'head':x['head']['sha'],'draft':x['draft']} for x in openprs],'pr160':{'head':'260f596582f2d82b8d7c707b61a6b8b6a43b069f','path_disposition':digest(P/'pr160-complete-path-disposition.json'),'all_paginated_changed_paths':133,'nonartifact_changed_paths':64,'nonartifact_exact_E':46,'nonartifact_different_E':18,'artifact_changed_paths':69,'artifact_count_is_not_unique_new_evidence_count':True,'decision':'retain; do not whole-branch merge','close_conditions':['E engineering merge actually complete','Every independent artifact/failed-history path preserved or immutable-linked after overlap analysis','18 remaining nonartifact paths explicitly superseded/rejected/or tracked followup; deferred invalid-collector failure receipt improvement is not falsely claimed absorbed','Fresh head/readiness check finds no new unreviewed required work'],'risk':'Entire branch would reintroduce ten product differences against E, including earlier project_session cancellation and nearest-rank/statistics state; current E observer and source must be preserved'},'pr161':{'head':'34aa30d7bad4b5069934aa008c9394f514995a4b','body_e95_reference_is_stale':True,'all_changed_paths':368,'artifact_changed_paths':345,'artifact_count_is_not_unique_new_evidence_count':True,'114_nonpin_scripts_and_138_validation_same_E':True,'different_trustroot_bindings_not_interchangeable':True,'whole_product_differences_vs_E':10,'task_notes_only':taskdiff,'original_task_definitions_statuses_top_navigation_unchanged':True,'decision':'retain until unique evidence/notes preserved and E actual merge; never whole-branch merge just because observer scripts match'},'candidate168169':{'heads':{'168':'f3c71a6bbafbc639413c4737c469c3b873a8888f','169':'0272a1fb152fd76a7cfb22386a580629d4038a64'},'scope':'Not archive-only. Seven product path differences versus E: five existing modified plus two new, 1082 existing product inputs identical. Six paths form DB batching subset; p8_scale expression is separate. Ten observer/trustroot scripts also differ; two auxiliary workflows are added.','product_delta_inventory':digest(P/'candidate-vs-E-core-path-deltas.json'),'only_test_type_fix_between_168_169':'.collect::<rusqlite::Result<_>>() -> .collect::<rusqlite::Result<Vec<String>>>() at snapshot_leaf_batching.rs:149','ci_log_review':digest(P/'candidate-ci-original-logs-independent-review.json'),'db_subset_peer_review':digest(Path('/dev/shm/a217aaae3bde/scale-combined-E-review/pr169-snapshot-leaf-batching-scoped-static-review.json')),'db_subset_limits':['64-row/64KiB bound is per-file per-table batch payload, not a single-row or RSS limit; legal oversized row uses original binder','Six parameter lists match existing binders; original transaction/pragma/epoch seam retained; DirectWriter journal-OFF success parity is not physical rollback proof','Only full snapshot/tables >=8 rows; no inferred 100k or full-stage speedup; exact new-source study required if adopted'],'runtime_actual_difference':'E terminal_operation_metadata, admission handshake, product/comparison construction_pending ownership flags and pre-replay product_writers_stopped assertion are removed. The 169 product_stopped(None) is True and lacks pending-construction veto; a constructor exception before handle assignment can falsely establish quiescence. Main workload KeyboardInterrupt catch is narrowed; finalization still catches it.','runtime_decision':'Do not take whole 169 observer/source. If needed separately review minimal DB5 + integration test onto preserved E source; normal CI alone does not resolve failure-path equivalence.','raw_script_git_verified':verified,'scale_run_status_snapshot_only':'169 aux100k was in_progress; 168 skipped scale is not a passed study; no native artifact acceptance or old sample transfer'},'capture_format_note':'Initial API JSON captures saved via apply_patch contain a harmless additional final LF; parsed Git fields are preserved and tree/blob identities verified separately. The task blob payload is explicitly recovered by removing exactly one added final LF and checking original Git SHA. Complete job logs have a separate direct-memory UTF-8 SHA256 proof and are byte exact.','task_counts':{'done':163,'remaining':29,'newly_completed':0},'remote_mutations':False,'native_executions':0,'unresolved_blockers_to_current_E':[]}
write('final-independent-triage-review.json',decision)
