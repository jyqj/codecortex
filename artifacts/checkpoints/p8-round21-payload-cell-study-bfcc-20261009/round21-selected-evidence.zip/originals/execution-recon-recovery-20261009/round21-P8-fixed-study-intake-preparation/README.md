# Fixed P8 / pending G8 original scale intake

This is transport and evidence preparation, not a registration rewrite or a new study.
Actual product P is `44e6248106335b5f0625e53de38f76d26aeeadcf`; the public G, branch,
original dispatch run, R and artifact IDs remain **null**. Root alone publishes and
performs the one authorized dispatch. Fill an additional bound file after official
readback; preserve the pending template. Do not execute against a guessed identity.

The retained C3ff `p8_scale_matrix.py` and `p7_build_identity.py`, plus the cached
original scale workflow, were checked against actual P8's 1095-product/142-validation
map by SHA256, Git blob and size. They are identical. They are reference originals,
**not an exact G8 checkout**; never run `validate_build` from this reference directory
and claim its Git identity is G8.

## Observe once per useful state change

After root gives the actual run, save official GET responses for:

- `/repos/jyqj/codecortex/actions/runs/{run_id}`;
- `/repos/jyqj/codecortex/actions/runs/{run_id}/jobs?per_page=100&page=N`;
- `/repos/jyqj/codecortex/actions/runs/{run_id}/artifacts?per_page=100&page=N`.

Use all pages implied by the first `total_count`; these are not atomic snapshots.
The full planned study can produce 152 jobs and 302 artifacts (one build, 150
capacity, 150 shard, one matrix); jobs/artifacts not yet created are not failures
or successes. Do not treat workflow queued as proof that no jobs are active.
Record run and job states separately. Do not loop, sleep, rerun, relabel or dispatch
from a receiver. A terminal study needs no further polling.

## Download each original once, preserve it independently

1. The single intake owner selects a new official artifact ID not already in the
   append-only index. Keep failed and unsuccessful originals as well as successes.
2. One GitHub artifact download produces its `file_id` and name. Materialize that
   exact existing file through the official workspace materialization channel.
   Keep the materialization response. Do not use failed signed-URL or native gh
   routes, make duplicate Library copies, or retry automatically.
3. Save the decoded official run/artifact JSON (plus original tool wrappers
   separately). Run the finite command below in a fresh output directory. It never
   calls the network, compiles, starts a primary, or runs a product validator.
4. Persist the original ZIP once, alongside official metadata, source/run/attempt,
   receipt/member hashes and immutable remote locator. For repository storage use
   one binary ZIP blob if within the existing upload size limit; otherwise split
   the *same bytes* into fixed-size parts, retaining order, each part hash and whole
   ZIP hash. Do not nest 150 ZIPs inside repeatedly growing archives. No product
   sample is discarded or renamed because of transfer difficulty.
5. Keep receiver review and durability states separate from measurement status.
   After remote readback proves the original bytes persist, only regenerable local
   extraction may be reclaimed if needed. Retain the build executable and metadata;
   never delete a sole original or a failure log. Original artifact names and sample
   IDs remain unchanged. Preserve each shard's whole raw JSONL, not only summaries.

```sh
python3 receive-materialized-once.py \
  --binding binding.actual-G8-run.json \
  --run-metadata official/run.json \
  --artifact-metadata official/artifact-ID.json \
  --zip raw/RUN_ID/ARTIFACT_ID/original.zip \
  --output raw/RUN_ID/ARTIFACT_ID/review-attempt-01
```

Capture actual stdout, stderr and integer exit in the caller. Existing output
paths are refused. Original v2 requires exact official ZIP size, exact digest
when supplied, safe unique member paths, no symlinks/special members, intact CRC,
and sufficient extraction capacity with its original 1 GiB receiver reserve.
Digest absence is recorded as unavailable, never as verified. This storage reserve
is a receiver requirement, not a new measurement budget. Receiver POSIX modes and
original ZIP external attributes are recorded separately.

The original transport module still contains historical Gc8-specific network
functions. The new adapter invokes **only** its unchanged ZIP verification and
extraction functions; it does not use the historical hard-coded product/gh route.

## Exact original artifacts and checks

| Artifact | Original content and acceptance role |
|---|---|
| `p8-scale-build-{run}` | `build.json`, original release ELF, Cargo JSON/build logs, before/after complete product snapshots and all sealed build evidence. Bind the actual source G and full product map, driver/helper Git blobs, build command/profile/features, binary SHA256 and original binary BLAKE3. |
| `p8-scale-capacity-{scale}-{rep}-{run}` | Original capacity observations/preparation, including failures. Preserve as execution context. The aggregate itself checks the shard's registered disk preflight; do not invent an extra success gate for the external capacity archive. |
| `p8-scale-shard-{scale}-{rep}-{run}` | Whole `shard.json`, registered plan, before/after source snapshots, disk before/after, supervisor stdout/stderr and original native plan/raw JSONL/worker stderr/worker summary/report. Never replace failure or missing repetition 0 with a rerun. |
| `p8-scale-matrix-{run}` | Original `matrix.json`, together with the aggregate job's actual checkout, command and exit. Preserve failure matrices too. |

The unchanged plan is five scales `[1000,5000,10000,50000,100000]`, rep0–29 per scale,
150 disjoint shards and 1500 measurements. Nine main stages per scale, and five
fanout groups only in 1k, give 50 groups each containing the original 30 repetitions.
The first five rep0 shards are part of this population; only all five success
permits the other 145 jobs. Original 200/1024 scale and 8/128 fanout budgets,
18,000,000 ms native deadline, 512 MiB output and capacity profile are unchanged.

When a shard appears, record its intact transport and source/build/plan identity.
The original function `validate_shard` may provide an early raw review if useful;
that is evidence replay, never another product run. It is **not necessary to run
150 extra product workloads or impose 150 new local validation gates**.

## What a genuine original aggregate exit 0 establishes

The original workflow calls `matrix.aggregate` with `repetitions=30`,
`shard_count=30`, `capacity_profile=scale_capacity_v1`, then exits according to
`result.passed`. This function already:

- runs `validate_build`, including same-G driver/helper Git-byte checks, sealed
  complete source snapshots, exact Cargo origin and original ELF hash verification;
- calls original `validate_shard` for every input, checking the original binary's
  BLAKE3 hash operation, source/build/plan, successful supervisor/worker, complete
  stderr/cleanup, all raw records, stages, closure, 15-table parity and fanout facts;
- runs `combine`, rejecting missing/duplicate shards, mixed source/binary/plan,
  mismatched input digests, wrong populations or absent repetitions. It retains
  all original samples and the original host/CPU/kernel strata.

Therefore exact-G original aggregate command **actual exit 0**, an intact bound
`matrix.json` with `passed=true`, `status=complete_measurement_coverage`,
`registered_repetitions=30`, `shard_count_per_scale=30`, `sample_count=1500`, all
150 referenced shard-receipt hashes and the original artifacts are sufficient
for these existing complete scale-coverage gates. A receiver can check that the
received original shard receipt hashes match matrix evidence without reexecuting
product code or adding another full aggregate prerequisite. A green run summary
alone, transport success, partial raw or a merely queued aggregate is insufficient.

If an independent replay is needed for a concrete discrepancy, use the exact G8
checkout and its unchanged original script/ELF. Do not monkeypatch `driver_snapshot`
or fabricate a full checkout from a sparse tree. An exact-G sparse checkout can
support the default original driver/helper Git verification, but full 1095-product
source equivalence must be demonstrated by the canonical map and original
source-input snapshots; do not claim `source_snapshot(root)` ran on missing files.
The optional original replay command, only after actual input paths exist, is:

```sh
python3 EXACT_G8_CHECKOUT/scripts/p8_scale_matrix.py aggregate \
  --build ORIGINAL_BUILD_DIRECTORY --inputs ORIGINAL_150_SHARD_DIRECTORIES \
  --shard-count 30 --repetitions 30 --capacity-profile scale_capacity_v1 \
  --output FRESH_REPLAY_OUTPUT
```

This coverage result can close the scale execution/coverage portion of original
P8-005/006 and unblock their downstream evidence assessment. It does not itself
edit tasks, certify all ten TODOs, demonstrate the separate mixed-load DB-wait
component, certify release/quality, claim process-tree resource peaks or stable
p95/p99, or pool heterogeneous-host timings. Original `release_certification:
not_run` and protocol `G8: not_evaluated` remain allowed; that latter field is an
original gate label, not this candidate's Git-G naming. Other existing task
requirements still use their own exact-source evidence and owner review.

Historical a23/Gc8/C3ff and all other failed or partial studies remain independent.
Their samples, binaries and failures are never relabeled as the new G8's samples.
