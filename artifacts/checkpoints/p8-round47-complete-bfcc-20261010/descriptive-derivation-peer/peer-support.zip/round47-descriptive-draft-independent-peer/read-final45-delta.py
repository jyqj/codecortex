import json,hashlib,datetime,pathlib,collections,decimal
ROOT=pathlib.Path('/workspace/scratch/bfccb8494ba0');P=ROOT/'round47-new45-descriptive-analysis';O=pathlib.Path(__file__).parent
ids={};n=0
def load(p):
 b=p.read_bytes();ids[str(p)]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};return json.loads(b)
def eq(a,b,s):
 global n
 assert a==b,s;n+=1
old=load(P/'accepted-44-descriptive-draft.json');new=load(P/'accepted-45-descriptive-pending-aggregate-draft.json');prior=load(O/'independent-44-cell-descriptive-review.json')
eq(prior['checks_passed'],11985,'prior checked scope')
oldc={tuple(c['slot']):c for c in old['cells']};newc={tuple(c['slot']):c for c in new['cells']};slot=('body',100000,0)
eq(set(newc)-set(oldc),{slot},'one new slot');eq(len(newc),45,'45 unique');eq(new['missing_slots'],[],'zero missing')
for s,c in oldc.items():
 d=newc[s];eq({k:v for k,v in c.items() if k!='environment_ref'},{k:v for k,v in d.items() if k!='environment_ref'},'44 inherited cell exact')
 eq(old['environments'][c['environment_ref']],new['environments'][d['environment_ref']],'environment remap retains complete object')
obsold={(tuple(r['slot']),r['role']):r for r in old['observations']};obsnew={(tuple(r['slot']),r['role']):r for r in new['observations']}
eq(len(obsnew),85,'85 unique roles');eq(set(obsnew)-set(obsold),{(slot,'setup'),(slot,'mutation')},'two new roles')
for s,r in obsold.items():eq({k:v for k,v in r.items() if k!='environment_ref'},{k:v for k,v in obsnew[s].items() if k!='environment_ref'},'83 inherited roles exact')
eq(new['roles'],{'setup':40,'mutation':40,'fanout':5},'role denominator');eq(new['preselected_cold_subset'],old['preselected_cold_subset'],'cold fixed subset')
ret=load(pathlib.Path(newc[slot]['original_result']['local_path']));facts=load(pathlib.Path(newc[slot]['phase_fact_source']['path']));peer=load(ROOT/'round47-body-100k-independent-review/original-timing-phase-and-parity-selection.json')
eq(hashlib.sha256(pathlib.Path(newc[slot]['phase_fact_source']['path']).read_bytes()).hexdigest(),newc[slot]['phase_fact_source']['sha256'],'new facts identity')
eq(newc[slot]['registered_plan'],ret['plan'],'new plan');eq(newc[slot]['original_task_receipt_sha256'],ret['receipt_sha256'],'new receipt')
bylabel={b['label']:b for b in peer['builds']}
for g,bs in facts['report_groups'].items():
 c=facts['count_summaries'][g];eq(c['original_report_count'],len(bs),'group count')
 for k in ['files_parsed','files_updated','files_scanned','files_skipped']:
  vs=[r['report'].get(k) for r in bs];eq(c[k+'_sum'],sum(vs) if vs and all(type(v)is int for v in vs) else None,'count missing preserved')
 eq(c['selected_dependents_sum'],sum(r['report']['dirty_plan']['selected_dependents'] for r in bs),'selection visits')
 for r in bs:
  b=bylabel[r['label']];eq(r['provenance']['line'],b['line'],'same raw line');eq(r['wall_us'],b['wall_us'],'same enclosing clock')
  for k,v in r['report'].items():
   if k in b['report_fields']:eq(v,b['report_fields'][k],'same independently-read body field '+k)
for ix,role in enumerate(['setup','mutation']):
 row=obsnew[(slot,role)];m=ret['measurements'][ix];bs=facts['report_groups'][role];full=facts['report_groups'][role+'_full_control']
 for k,v in row['original'].items():eq(v,m[k],'original measure')
 eq(row['counts_over_original_reports'],facts['count_summaries'][role],'counts role')
 eq(row['full_control_counts_over_original_reports'],facts['count_summaries'][role+'_full_control'],'control counts')
 eq(m['engine_ms'],sum(r['report']['elapsed_ms'] for r in bs),'engine ms')
 eq(m['index_wall_us'],sum(r['wall_us'] for r in bs),'index us')
 eq(m['full_control_ms'],sum(r['report']['elapsed_ms'] for r in full),'full ms')
 for key,val in m['build_timing'].items():
  vs=[r['report']['build_timing'][key] for r in bs];eq(val,None if all(v is None for v in vs) else sum(vs),'phase us')
 for key,val in m['phases'].items():eq(val,sum(r['report']['phase_timing'][key] for r in bs),'legacy phase ms')
eq(new['original_aggregate']['status'],'failed','originalActionsfailure');eq(new['original_aggregate']['accepted_inputs'],42,'42 actual inputs');eq(new['original_aggregate']['recovery_aggregate_executed'],False,'pending recovery');eq(new['task_credit'],0,'no taskcredit');eq(new['apply'],False,'no apply')
r={'schema':'independent-full45-descriptive-draft-delta-review-v1','reviewer':'/root/pr_triage','reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decision':'accepted_descriptive_derivation_pending_complete_original_aggregate_and_formal_task_decision','source':new['source'],'run_id':new['run_id'],'attempt':1,'counts':{'cells':45,'role_records':85,'setup':40,'mutation':40,'fanout':5,'fixed_cold_subset':5},'checks_this_delta':n,'prior44_checks':11985,'delta':'Only body100k and its2roles added. Existing44 cell payloads and83 role payloads unchanged;15 environment labels renumbered but exact underlying per-slot environment objects preserved.','new_body':'All493 emitted builds mapped to independently read raw labels/line positions and overlapping exact fields. New two role engine/phases/counts sum correctly.490 incremental,489resumed,finalready; initial/final full15tableparity equal.','timing_and_count_boundaries':['503 old elapsed_ms omitted from author closure projections remain available in original returns and pre-existing exact peer facts, checked in prior44review. No fabricated zero.','prepare_snapshot and full_staging remain nested within prepare. Legacy phase_ms separate, not additive to build_timing_us.','Repeated scan/selection counts are visits, not unique files. fanout fixtureN+1 differs from capacity1000.','Cold5 is predetermined no_opsetup subset, not five extra records; N1/host/environment retained, no pooledstatistic or speedup.'],'aggregate':new['original_aggregate'],'task_credit':0,'apply_now':False,'peer_original_calls':0,'raw_reads_this_delta':0,'ZIP_ELF_CRC_calls':0,'body_original_raw_read':'Only in separately archived body peer; this derivation review reuses those small facts.'}
(O/'independent-45-cell-descriptive-delta-review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');(O/'final45-delta-input-identities.json').write_text(json.dumps(ids,indent=2)+'\n');print(json.dumps({'checks':n,'counts':r['counts'],'decision':r['decision']}))
