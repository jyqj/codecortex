from pathlib import Path
import datetime, hashlib, json, re

BASE = Path('/workspace/scratch/bfccb8494ba0')
O = Path(__file__).resolve().parent
F = O / 'owner-official-files'
C = BASE / 'cold044-original-intake'
SOURCE = '044c008c9459cfa61e7701db2eb868342c508a39'
RUN = 37954851017
EXPECTED = {(scale, rep) for scale in [1000, 5000, 10000, 50000, 100000] for rep in range(30)}

def read(p):
    return json.loads(p.read_bytes())

def digest(p):
    b = p.read_bytes()
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()}

def object_for(e):
    p = F / (e['git_blob'] + '.raw')
    assert digest(p)['git_blob'] == e['git_blob']
    return read(p)

owner_commits = {x['commit']: x['data'] for x in read(F / 'owner-four-commits.json')}
owner_index = read(F / 'owner-file-index.json')
owner_files = {(e['commit'], e['path']): e for e in owner_index}
for e in owner_index:
    object_for(e)
    changed = {f['filename']: f for f in owner_commits[e['commit']]['files']}
    assert changed[e['path']]['sha'] == e['git_blob'] and changed[e['path']]['status'] == 'added'
root_commits = {x['sha']: x['content'] for x in read(O / 'root-five-publications.json')}
final = read(O / 'final-publication.json')
FINAL = final['sha']
root_commits[FINAL] = final
assert len({f['filename'] for f in final['files']}) == len(final['files'])

matrix_path = BASE / 'cold044-original-aggregate-intake/11644384839/attempt01/extracted/cold-matrix.json'
matrix = read(matrix_path)
assert matrix['driver_source']['source_commit'] == SOURCE
assert matrix['study'] == {'protocol': 'p8-cold-only-study-v1', 'run_id': str(RUN), 'run_attempt': 1}
evidence = {Path(x['directory']).name: x for x in matrix['evidence']}
assert len(evidence) == len(matrix['evidence']) == 150
assert matrix['sample_count'] == 150 and matrix['registered_repetitions'] == 30

artifacts = {}
receipts = {}
build = None

def slot_from_name(name):
    m = re.fullmatch(r'p8-cold-(shard|capacity)-(1000|5000|10000|50000|100000)-(\d+)-37954851017-1', name)
    assert m, name
    return m.group(1), int(m.group(2)), int(m.group(3))

def add_artifact(a, custody):
    assert a['workflow_run']['id'] == RUN and a['workflow_run']['head_sha'] == SOURCE
    assert a['size_in_bytes'] == custody['whole_zip_bytes']
    assert a['digest'] == 'sha256:' + custody['whole_zip_sha256']
    key = slot_from_name(a['name'])
    assert (key[1], key[2]) in EXPECTED and key not in artifacts, key
    assert a['id'] not in [x['artifact_id'] for x in artifacts.values()]
    artifacts[key] = {'artifact_id': a['id'], 'artifact_name': a['name'],
                      'official_bytes': a['size_in_bytes'], 'official_digest': a['digest'],
                      'source': SOURCE, 'run_id': RUN, 'attempt': 1, 'custody': custody}

def add_receipt(scale, rep, sha, provenance):
    key = (scale, rep)
    assert key not in receipts
    name = f'p8-cold-shard-{scale}-{rep}-{RUN}-1'
    assert name in evidence and evidence[name]['receipt_sha256'] == sha
    receipts[key] = {'cold_shard_receipt_sha256': sha, 'exact_original_aggregate_evidence': evidence[name],
                     'receipt_evidence': provenance}

owner_official = {}
restores = {}
for e in owner_index:
    if e['path'].endswith('/original-official-artifacts.json'):
        for a in object_for(e)['artifacts']:
            if a['id'] in owner_official:
                assert owner_official[a['id']]['digest'] == a['digest']
            owner_official[a['id']] = a
    if e['path'].endswith('/full-original-restore-verification.json'):
        obj = object_for(e)
        assert obj['all_byte_exact'] and obj['native_execution'] is False
        restores[e['commit']] = (e, {x['artifact_id']: x for x in obj['restored_originals']})

for e in owner_index:
    if '/manifests/' not in e['path']:
        continue
    m = object_for(e)
    assert m['source_commit'] == SOURCE and m['run_id'] == RUN and m['attempt'] == 1
    a = owner_official[m['artifact_id']]
    assert a['name'] == m['artifact_name']
    prefix = e['path'].split('/manifests/')[0]
    changed = {f['filename']: f for f in owner_commits[e['commit']]['files']}
    position = 0
    chunks = []
    for chunk in m['chunks']:
        assert chunk['offset'] == position
        path = prefix + '/' + chunk['path']
        assert changed[path]['sha'] == chunk['git_blob'] and changed[path]['status'] == 'added'
        chunks.append({**chunk, 'repository_path': path, 'immutable_commit': e['commit']})
        position += chunk['bytes']
    assert position == m['original_zip_bytes']
    restore_entry, restore_rows = restores[e['commit']]
    rr = restore_rows[a['id']]
    assert rr['exit_code'] == 0 and rr['restored_bytes'] == position and rr['restored_sha256'] == m['original_zip_sha256']
    custody = {'storage': 'whole_zip_single_chunk' if len(chunks) == 1 else 'ordered_byte_exact_original_zip_chunks',
               'whole_zip_bytes': position, 'whole_zip_sha256': m['original_zip_sha256'],
               'whole_zip_git_blob': chunks[0]['git_blob'] if len(chunks) == 1 else None,
               'immutable_commit': e['commit'], 'repository_path': chunks[0]['repository_path'] if len(chunks) == 1 else None,
               'manifest_repository_path': e['path'], 'manifest_git_blob': e['git_blob'], 'chunks': chunks,
               'prior_original_restore_receipt': {'immutable_commit': restore_entry['commit'], 'repository_path': restore_entry['path'], 'git_blob': restore_entry['git_blob'], 'row': rr},
               'current_zip_redownload_or_restore': False}
    assert a['size_in_bytes'] == position and a['digest'] == 'sha256:' + m['original_zip_sha256']
    if a['name'].startswith('p8-cold-build-'):
        assert build is None
        build = {'artifact_id': a['id'], 'artifact_name': a['name'], 'official_bytes': a['size_in_bytes'], 'official_digest': a['digest'], 'custody': custody}
    else:
        add_artifact(a, custody)

for e in owner_index:
    if '/accepted-original-' not in e['path']:
        continue
    accepted = object_for(e)
    p = accepted['plan']
    assert accepted['driver_source']['source_commit'] == SOURCE
    assert accepted['study'] == matrix['study']
    assert p['stage_scope'] == 'cold_only_v1' and p['repetitions'] == 30
    add_receipt(p['files'][0], p['shard']['index'], accepted['receipt_sha256'],
                {'kind': 'previously_published_original_validator_output', 'immutable_commit': e['commit'], 'repository_path': e['path'], 'git_blob': e['git_blob']})
assert len(receipts) == 10 and len(artifacts) == 20 and build is not None

def direct_custody(entry, commit):
    path = entry.get('repository_path', entry.get('path'))
    oid = entry.get('git_blob', entry.get('sha'))
    file_map = {f['filename']: f for f in root_commits[commit]['files']}
    assert file_map[path]['sha'] == oid and file_map[path]['status'] == 'added'
    return {'storage': 'whole_original_zip_blob', 'whole_zip_bytes': entry['bytes'], 'whole_zip_sha256': entry['sha256'],
            'whole_zip_git_blob': oid, 'immutable_commit': commit, 'repository_path': path,
            'official_commit_file_membership_checked': True}

batches = [
    ('sealed-28-originals-attempt02', '39cc7981ea6f085ee9f429af4e0083b17c6ee4cc'),
    ('increment-50k11-17/sealed', 'b64764ab2802747f431bd185d42ea14bea71e793'),
    ('increment-50k18-23/sealed', '2c20e8bf3d505a67ad7b0bad47815978b1a0e18e'),
    ('increment-50k24-29-and-10k1-8/sealed', 'ddb2c8a08a88034efe0ba5f20957e0644c652540'),
    ('increment-10k9-29-and-5k1-5/sealed', 'ca526d3a6acca5d078817f3dba9113481a4f9eeb'),
    ('increment-final-53/sealed', FINAL),
]
for directory, commit in batches:
    p = C / directory
    summary = read(p / 'summary.json')
    manifest = read(p / 'publication-manifest.json')
    entries = {x.get('repository_path', x.get('path')): x for x in manifest['entries']}
    originals = summary.get('originals', summary.get('original_zips'))
    for original in originals:
        a = original['artifact']
        entry = entries[original['repository_path']]
        assert (entry['bytes'], entry['sha256'], entry.get('sha', entry.get('git_blob'))) == (original['bytes'], original['sha256'], original['git_blob'])
        add_artifact(a, direct_custody(entry, commit))
        if '-shard-' in a['name']:
            key = slot_from_name(a['name'])
            original_output = C / 'raw' / str(a['id']) / 'original-validation-attempt01/original-validate-shard-output.json'
            output = read(original_output)
            original_outer = original_output.parent / 'extracted/cold-shard.json'
            sha = digest(original_outer)['sha256']
            assert sha == output['receipt_sha256']
            assert output['study'] == matrix['study'] and output['driver_source']['source_commit'] == SOURCE
            add_receipt(key[1], key[2], sha, {'kind': 'previously_verified_original_shard_receipt', 'local_original_receipt': str(original_outer),
                                            'receipt_bytes': digest(original_outer)['bytes'], 'original_validator_output': digest(original_output),
                                            'contained_in_measurement_zip': True, 'immutable_commit': commit})
assert len(receipts) == 144 and len(artifacts) == 288

recovery = BASE / 'cold044-owner-six-custody-recovery'
recovery_summary = read(recovery / 'transport-verification-attempt01/summary.json')
recovery_manifest = read(recovery / 'sealed/root-upload-manifest.json')
recovery_entries = {x['artifact_id']: x for x in recovery_manifest['entries'] if 'artifact_id' in x}
for x in recovery_summary['originals']:
    a = x['artifact']
    add_artifact(a, direct_custody(recovery_entries[a['id']], FINAL))
    if x['kind'] == 'shard':
        p = recovery / 'transport-verification-attempt01/metadata' / str(a['id']) / 'cold-shard.json'
        sha = digest(p)['sha256']
        key = slot_from_name(a['name'])
        add_receipt(key[1], key[2], sha, {'kind': 'previously_accepted_owner_slot_custody_recovery_only',
                                        'local_original_receipt': str(p), 'receipt_bytes': digest(p)['bytes'],
                                        'contained_in_measurement_zip': True, 'immutable_commit': FINAL,
                                        'newly_accepted_sample_count': 0})
assert len(receipts) == 150 and set(receipts) == EXPECTED
assert len(artifacts) == 300
assert {(k[1], k[2]) for k in artifacts if k[0] == 'shard'} == EXPECTED
assert {(k[1], k[2]) for k in artifacts if k[0] == 'capacity'} == EXPECTED

aggregate_base = BASE / 'cold044-original-aggregate-intake'
aggregate_selection = read(aggregate_base / 'official-original-selection.json')
aggregate_manifest = read(aggregate_base / 'upload-manifest.json')
aggregate_entry = next(x for x in aggregate_manifest['files'] if x['local_path'].endswith('.zip'))
aggregate_a = aggregate_selection['aggregate_artifact']
aggregate = {'artifact_id': aggregate_a['id'], 'artifact_name': aggregate_a['name'], 'official_bytes': aggregate_a['size_in_bytes'],
             'official_digest': aggregate_a['digest'], 'custody': direct_custody(aggregate_entry, FINAL)}
assert aggregate['official_digest'] == 'sha256:' + aggregate['custody']['whole_zip_sha256']
assert aggregate['official_bytes'] == aggregate['custody']['whole_zip_bytes']
job_map = {}
for j in aggregate_selection['all_measurement_jobs']:
    m = re.fullmatch(r'(?:measure|preflight) \((\d+), (\d+)\)', j['name'])
    if m:
        key = (int(m.group(1)), int(m.group(2)))
        assert key not in job_map
        assert j['head_sha'] == SOURCE
        assert aggregate_selection['source'] == SOURCE and aggregate_selection['run_id'] == RUN and aggregate_selection['attempt'] == 1
        assert j['status'] == 'completed' and j['conclusion'] == 'success'
        job_map[key] = j['id']
assert set(job_map) == EXPECTED

rows = [{'scale': scale, 'repetition': rep, 'original_job_id': job_map[(scale, rep)],
         'measurement': artifacts[('shard', scale, rep)], 'capacity': artifacts[('capacity', scale, rep)],
         **receipts[(scale, rep)]} for scale, rep in sorted(EXPECTED)]
report = {'schema': 'cold044-complete-150-slot-original-custody-ledger-v1',
          'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'reviewer': '/root/execution_recon',
          'source': SOURCE, 'run_id': RUN, 'attempt': 1, 'stage_scope': 'cold_only_v1',
          'verdict': 'all_150_unique_measurement_slots_and_150_capacity_originals_have_exact_immutable_custody_and_receipt_matrix_identity',
          'counts': {'registered_scales': 5, 'registered_repetitions_per_scale': 30, 'unique_slots': 150, 'measurement_zip_artifacts': 150,
                     'capacity_zip_artifacts': 150, 'build_originals': 1, 'aggregate_originals': 1,
                     'new_measurements_or_original_validator_executions_in_this_review': 0},
          'latest_root_publication_commit': FINAL, 'owner_head': '9aba8f01e5f5766ac55f3ebed1ff21991dcb6cdb',
          'owner_chunked_archive_boundary': 'Previously published original ZIPs are either a single blob chunk or an ordered byte-exact multi-chunk archive. Multi-chunk whole_zip_git_blob is null, never fabricated. Original whole SHA/length, declared offsets, every chunk Git OID/path and original successful byte-exact restore receipts are preserved; no ZIP redownload/restore/CRC here.',
          'build': build, 'aggregate': aggregate, 'original_matrix': {'local_path': str(matrix_path), **digest(matrix_path)},
          'matrix_identity': {'exact_original_receipt_sha256_matches': 150, 'matrix_evidence_entries': 150,
                              'artifact_ids_come_from_official_metadata_not_matrix_inference': True},
          'slot_rows': rows,
          'review_boundary': 'Custody and source/slot/receipt identity only. Uses previously run original intake results and original aggregate evidence. Does not rerun any validator, ELF, ZIP CRC, measurement or original collector. Does not transfer cold evidence to sequential-history or different-source cohorts. Task completion and prerequisite evaluation remain root-owned.',
          'newly_completed_todos': 0, 'remaining_todos_at_review': 29}
(O / 'complete-cold150-custody-ledger.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'path': str(O / 'complete-cold150-custody-ledger.json'), **digest(O / 'complete-cold150-custody-ledger.json')}))
