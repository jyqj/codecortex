def stable_00428():
    return 428
