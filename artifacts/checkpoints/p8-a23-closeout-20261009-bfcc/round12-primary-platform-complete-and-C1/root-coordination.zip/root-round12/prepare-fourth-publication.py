import datetime
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path('/workspace/scratch/bfccb8494ba0')
RAM = Path('/dev/shm/pr-triage-bfcc-c8be5afa')
OUT = ROOT / 'root-round12/publication-fourth'
PREFIX = 'artifacts/checkpoints/p8-a23-closeout-20261009-bfcc/round12-primary-platform-complete-and-C1'
OUT.mkdir(parents=True, exist_ok=True)
groups, entries, selections, direct = {}, [], [], []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def member(p):
    p = p.resolve()
    if p.is_relative_to(ROOT):
        return p.relative_to(ROOT).as_posix()
    assert p.is_relative_to(RAM), str(p)
    return 'ram-intake/' + p.relative_to(RAM).as_posix()

def add(group, p, expected=None):
    p = Path(p)
    assert p.is_file() and not p.is_symlink(), str(p)
    name = member(p)
    data = p.read_bytes()
    if expected:
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256'], str(p)
    if p.name.endswith('.tar.gz'):
        assert expected and expected.get('repository_path'), str(p)
        assert len(data) <= 8 * 1024 * 1024, str(p)
        record = {'file_name':p.name, 'local_path':str(p), 'repository_path':expected['repository_path'],
                  'bytes':len(data), 'sha256':sha(data), 'git_blob_sha':blob(data),
                  'scope':'New lossless container of selected original artifact members, distinct from official GitHub ZIP.'}
        assert not any(x['repository_path'] == record['repository_path'] for x in direct)
        direct.append(record)
        entries.append({'direct_repository_path':record['repository_path'], 'original_local_path':str(p),
                        'bytes':len(data), 'sha256':sha(data)})
        return
    try:
        decoded = data.decode('utf-8')
    except UnicodeDecodeError:
        decoded = ''
    for pattern in [r'(?:[?&]|\\u0026)(?:sig|signature|x-amz-signature|x-goog-signature|token|access_token)=[A-Za-z0-9%/+_-]{12,}',
                    r'(?im)^set-cookie:\s*(?!\[?REDACTED)[^\r\n]{12,}']:
        assert not re.search(pattern, decoded, re.I), (str(p),'private transfer value')
    g = groups.setdefault(group, {})
    assert name not in g or g[name][1] == data, name
    g[name] = (str(p), data)

def select(group, source):
    p = Path(source)
    if not p.is_absolute():
        p = ROOT / p
    data = p.read_bytes()
    d = json.loads(data)
    add(group, p)
    selections.append({'local_path':str(p),'bytes':len(data),'sha256':sha(data)})
    for entry in d.get('files',d.get('entries',[])):
        p2 = Path(entry.get('local_path',entry.get('path')))
        if not p2.is_absolute():
            p2 = Path(d.get('base',str(p.parent))) / p2
        add(group,p2,entry)

select('original-platform-complete', 'todo-audit-round12/platform-final-Gc8/archive-selection.json')
select('original-C1-reviews', RAM/'runtime-review-Gc8/c1-publication-selection.json')
select('original-ten-closeout-map', 'scale-intake-primary/target-ten-closeout-map/archive-selection.json')
for name in ['third-primary-git-publication-receipt.json','pr174-superseded-root-review.json',
             'pr174-closure-receipt.json','external-main-900539-observation.json','prepare-fourth-publication.py']:
    add('root-coordination',ROOT/'root-round12'/name)

bundles = []
for group,files in sorted(groups.items()):
    p = OUT/(group+'.zip')
    assert not p.exists(), str(p)
    with zipfile.ZipFile(p,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,(original,data) in sorted(files.items()):
            info = zipfile.ZipInfo(name,date_time=(2026,10,9,0,0,0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
            entries.append({'archive':p.name,'archive_member':name,'original_local_path':original,
                            'bytes':len(data),'sha256':sha(data)})
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None and z.namelist() == sorted(files)
        assert all(z.read(n) == pair[1] for n,pair in files.items())
    data = p.read_bytes()
    assert len(data) <= 8 * 1024 * 1024, str(p)
    bundles.append({'file_name':p.name,'local_path':str(p),'repository_path':PREFIX+'/'+p.name,
                    'bytes':len(data),'sha256':sha(data),'git_blob_sha':blob(data),
                    'members':len(files),'uncompressed_bytes':sum(len(x[1]) for x in files.values())})

manifest = {'schema':'codecortex.primary-fourth-acceptance-publication.v1',
 'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'parent_commit':'56cf243df673a0745644ff17351353c8e416d349',
 'current_source_G':'c8be5afaac568ffd40ef86d3795423c3b73c9f39',
 'original_tasks':{'total':192,'done':163,'remaining':29,'new_completed':0},
 'accepted_scopes':['Original mixed C1:900 operations, configured and observed concurrency1. No read/build overlap is expected by the original C1 contract.',
                    'Complete original platform8/8 cells plus original collector job113746378011 and artifact11605154697; unchanged collect_cells replay actual0.',
                    'Original ten-task closeout mapping preserves definitions, hard dependencies, budgets and unavailable classifications.',
                    'PR174 superseded draft closed after its four source/test Git blobs were confirmed identical in active PR178 and current corresponding source/platform checks passed. Branch retained.'],
 'limits':['No task states changed. Full original scale matrix and one-hour soak still await completion and acceptance.',
           'This final platform increment supplements the unchanged prior289-file recovery/seven-cell selection in56cf243.',
           'The C1 tar is a new lossless container, distinct from the official GitHub ZIP. Its2126 members plus3 excluded ELFs match all2129 original ZIP member byte counts and SHA256 values.',
           'Actual ZIP/member or direct_repository_path entries below govern public locations; selection repository_path fields for ZIP-contained files describe expanded layouts.',
           'PR175/179 external head updates and newly observed PR180/181 have separate identities and are not added to Gc8 study.',
           'External main900539 documentation/evidence changes must be preserved at eventual task closeout; this packet does not overwrite main or the original ledger.'],
 'selections':selections,'bundles':bundles,'direct_files':direct,'file_count':len(entries),'files':entries}
p = OUT/'publication-manifest.json'
p.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
index = {'prefix':PREFIX,'files_to_upload':bundles+direct,
         'manifest':{'local_path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}}
(OUT/'upload-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(entries),'bundles':bundles,'direct':direct,'manifest_bytes':p.stat().st_size},ensure_ascii=False))
