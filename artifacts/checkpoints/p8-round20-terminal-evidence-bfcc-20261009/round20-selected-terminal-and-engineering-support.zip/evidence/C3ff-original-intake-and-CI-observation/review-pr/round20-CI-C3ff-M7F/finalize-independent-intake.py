#!/usr/bin/env python3
"""Summarize preserved original bytes and already-run read-only validation receipts."""
from pathlib import Path
from collections import Counter
import hashlib
import json

B = Path(__file__).resolve().parent
S = '3ffcefc3b28ee1a4ed80caecebd7208a45c3e302'
D = B / 'raw/11626430756/attempt01/extracted'
def read(p): return json.loads(p.read_bytes())
def entry(p):
    data = p.read_bytes()
    return {'local_path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}
def save(name, value):
    with (B / name).open('x') as out: out.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
run = read(B / 'github-api/C3ff-run.json')
jobs = read(B / 'github-api/C3ff-jobs.json')['jobs']
assert run['id'] == 37910924354 and run['head_sha'] == S and run['run_attempt'] == 1
assert run['event'] == 'pull_request' and run['conclusion'] == 'failure'
assert all(j['head_sha'] == S and j['run_attempt'] == 1 for j in jobs)
record = read(D / 'shard.json')
native = read(D / 'native/report.json')
integrity = read(B / 'original-replay/integrity.stdout')
replays = {name: read(B / ('original-replay/' + name + '.receipt.json')) for name in ('validate_shard', 'inspect_raw', 'integrity')}
assert {name: value['exit_code'] for name, value in replays.items()} == {'validate_shard': 1, 'inspect_raw': 1, 'integrity': 0}
# Verify no replay altered any retained ZIP member.
for aid in (11626430756, 11626127365):
    root = B / 'raw' / str(aid) / 'attempt01'
    for row in read(root / 'zip-members.json')['members']:
        actual = entry(root / 'extracted' / row['path'])
        assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
raw = [json.loads(line) for line in (D / 'native/raw.jsonl').read_bytes().splitlines()]
counts = Counter(row['event'] for row in raw)
starts = {row['label']: row for row in raw if row['event'] == 'build_started'}
ends = {row['label']: row for row in raw if row['event'] == 'build_finished'}
assert len(starts) == counts['build_started'] and len(ends) == counts['build_finished']
assert set(starts) == set(ends)
parities = []
for row in raw:
    if row['event'] in ('cold_parity', 'stage_finished'):
        p = row['parity']
        parities.append({'event': row['event'], 'label': row.get('label', row.get('sample', '') + '/cold'),
            'parity_wall_us': row['parity_wall_us'], 'equal': p['equal'], 'status': p['status'],
            'different_tables': p['different_tables'], 'tables': p['tables'],
            'canonical_bytes': p['canonical_bytes'], 'scratch_peak_bytes': p['scratch_peak_bytes'],
            'oracle_mode': p['oracle_mode'], 'capacity_profile': p['capacity_profile'],
            'limits': p['limits'], 'storage_layout': p['storage_layout'], 'sorting_cache_kib': p['sorting_cache_kib'],
            'incremental_builds': row.get('incremental_builds'), 'incremental_wall_us': row.get('incremental_wall_us'),
            'stage_passed': row.get('passed'), 'stage_complete': row.get('complete'), 'stage_full_complete': row.get('full_complete')})
    if row['event'] == 'build_finished':
        assert row['label'] in starts and row['start_us'] == starts[row['label']]['start_us']
raw_summary = {'source': S, 'raw': entry(D / 'native/raw.jsonl'), 'events': dict(counts),
    'build_start_count': len(starts), 'build_finish_count': len(ends), 'unmatched_builds': [],
    'completed_original_parity_event_count': len(parities), 'completed_parities': parities,
    'mutations_started': [row['label'] for row in raw if row['event'] == 'mutation'],
    'stages_finished': [row['label'] for row in raw if row['event'] == 'stage_finished'],
    'last_record': {key: raw[-1][key] for key in ('event', 'label', 'full', 'start_us', 'end_us', 'wall_us')},
    'last_record_resolution_complete': raw[-1]['report']['resolution_freshness']['complete'],
    'unfinished_stage': 'scale-100000/repetition-0/batch_10',
    'stages_with_no_mutation_start': ['batch_100', 'batch_1000'],
    'completed_parity_scope': 'Six retained 15-table parity records passed original check_parity while inspect_raw traversed to its final missing-stage rejection. They are not six accepted study samples.',
    'last_record_scope': 'No build is unmatched in this C3ff raw. No batch_10 stage_finished or parity result is retained. The last timed build end alone does not establish the internal operation executing at termination.',
    'cross_source_scope': 'No Gc8 event/count/timing is substituted or pooled.'}
save('retained-raw-coverage-facts.json', raw_summary)
for name in ('G4', 'M7F'):
    r = read(B / f'github-api/{name}-run.json')
    jj = read(B / f'github-api/{name}-jobs.json')['jobs']
    assert all(j['head_sha'] == r['head_sha'] and j['run_attempt'] == 1 for j in jj)
observation = {'schema_version': 1, 'observed_at_utc': '2026-10-09T15:27:05Z', 'scope': 'One official read, immutable historical observation; no later state substituted',
    'runs': {name: {'id': read(B / f'github-api/{name}-run.json')['id'],
        'source': read(B / f'github-api/{name}-run.json')['head_sha'],
        'run_attempt': 1, 'run_status': read(B / f'github-api/{name}-run.json')['status'],
        'run_conclusion': read(B / f'github-api/{name}-run.json')['conclusion'],
        'jobs': [{k: j[k] for k in ('id', 'name', 'status', 'conclusion', 'started_at', 'completed_at', 'steps')}
            for j in read(B / f'github-api/{name}-jobs.json')['jobs']]}
        for name in ('G4', 'C3ff', 'M7F')},
    'PR180_head_at_observation': read(B / 'github-api/PR180.json')['head']['sha'],
    'G4_scope': 'At this read the check was in progress at step 13. Step success is not a substitute for the terminal log or exact test/source admission analysis. Root separately owns the later terminal log.',
    'M7F_scope': 'Run aggregate queued while check job actually in_progress; queued security and MSRV are not running or passed.',
    'C3ff_measure_scope': 'One measure matrix placeholder job is skipped. Remaining 145 registered shards were not executed; these are not 145 separately observed completed job records. Skipped-job API timestamps are retained uncorrected, not used as a duration.',
    'mutations_or_dispatch': False, 'new_TODO_done': 0, 'remaining_TODO': 29}
save('official-three-source-CI-observation.json', observation)
report = {'schema_version': 1, 'reviewer': '/root/pr_triage', 'source': S, 'run_id': run['id'], 'run_attempt': 1,
    'workflow_event': run['event'], 'workflow_path': run['path'], 'review_scope': 'Complete original ZIP transport plus read-only integrity and original failed-shard/raw validators, no workload replay',
    'conclusion': 'original_failed_shard_retained_and_rejected',
    'originals': read(B / 'two-original-intake-summary.json')['results'],
    'intake_implementation': {'receiver': '/dev/shm/execution-recon-recovery-20261009/intake_once.v2.py',
        'sha256': '61f4ae48bc84dbc9f90862a80d06a8268ec4aa93f83c75582b716bc32f4c3369',
        'unchanged_functions': ['verify_zip_identity', 'extract_original'],
        'source_binding': 'Receiver Gc8-only checked_binding/verify_run were neither used nor relabelled. Wrapper checks actual C3ff pull_request run/head/attempt/path and both artifact workflow_run records.',
        'actual_transport_exit': read(B / 'original-transport-execution-receipt.json')['exit_code']},
    'fixed_original_drivers': [entry(p) for p in sorted((B / 'source/scripts').glob('*.py'))],
    'validation_execution': replays,
    'validation_limits': {'validate_shard': 'Original first gate rejects status failed/exit 3 before build_record or binary access. Passed None for these unavailable unused arguments; this does not revalidate the original release build/ELF or accept later gates.',
        'inspect_raw': 'Original full traversal of the retained raw reaches and fails missing registered mutation stages. No assertion was removed, monkeypatched or widened.',
        'integrity': 'Original inventory/validate_snapshot/registered_plan/capacity_contract functions plus explicit immutable identity comparisons succeed. Integrity success does not replace workload acceptance.',
        'unchanged_after_replay': 'Every one of the 13 retained files across both originals has unchanged byte count and SHA256 against initial CRC/member receipt.'},
    'actual_checkout': {'source': S, 'source_tree': integrity['source_tree'], 'crate_Cargo_input_count': integrity['input_count'],
        'source_manifest_sha256': integrity['source_manifest_sha256'], 'before_after_byte_equal': True,
        'job_log_evidence': {'100k': {'job_id': 113760872142, 'checkout_lines': [115, 237, 238]}, 'aggregate': {'job_id': 113891085346, 'checkout_lines': [114, 236, 237]}},
        'scope': 'Exact direct C3ff checkout in both original jobs and original source snapshots; no PR merge checkout or newer main substitution.'},
    'actual_native_terminal': native,
    'layered_failures': {'native': {'status': native['status'], 'exit_code': native['exit_code'], 'worker_exit_code': native['worker_exit_code'], 'stderr_complete': native['stderr_complete'], 'summary': native['summary']},
        'shard_driver': {'status': record['status'], 'exit_code_field': record['exit_code'], 'error': record['error'], 'outer_job_process_exit': 1},
        'aggregate': {**read(B / 'raw/11626127365/attempt01/extracted/matrix.json'), 'original_job_process_exit': 1}},
    'stderr_and_cleanup': {'worker_stderr_bytes': 0, 'supervisor_stderr_bytes': 0, 'empty_is_not_complete': True,
        'fixture_cleanup': native['fixture_cleanup'], 'worker_summary_exists': False,
        'scope': 'cleanup error null is the supervisor record, not independent process-tree proof. Worker exit remains null, not 0 or an inferred signal.'},
    'registered_budget': record['plan'], 'original_shard_argv': record['command'],
    'original_binary_identity_record_only': {k: record[k] for k in ('binary_sha256', 'binary_blake3', 'build_receipt_sha256')},
    'disk_preflight': integrity['disk_preflight_record'],
    'raw_coverage_reference': entry(B / 'retained-raw-coverage-facts.json'),
    'root_cause_boundary': 'The recorded terminal cause is the original five-hour child-lifetime deadline. This record does not establish OOM, loss of runner communication, a parse/SQL correctness failure, or a worker exit code. Completed parity records show equality for their own stage only. An unfinished batch_10 parity/stage cannot be accepted from its completed builds.',
    'counts': {'newly_accepted_shards': 0, 'newly_accepted_primary_samples': 0, 'prior_C3ff_accepted_shards_reported': 4, 'registered_shards': 150, 'prior_C3ff_accepted_samples_reported': 41, 'registered_primary_samples': 1500,
        'prior_count_scope': 'Prior four accepted shards are retained as previously reported; they were not downloaded or independently reaccepted in this intake.',
        'remaining_145_scope': 'measure branch skipped after mandatory first cohort failure; no substitution or continuation samples accepted'},
    'decision': {'study_passed': False, 'release_certification': 'not_run', 'original_TODO_newly_done': 0, 'original_TODO_remaining': 29,
        'next_action_scope': 'Preserve this failed primary study. Product fixes and any future complete study require their own explicit fixed-source identities; do not rerun or pool this failed C3ff shard.'},
    'publication_scope': 'Both complete original ZIPs are separate immutable Git blob leaves, not nested again in support ZIP. Small selected raw files and hashes do not purport to replace the complete raw.jsonl retained in the original ZIP.',
    'timestamp_scope': 'Official GitHub timestamps are used for original execution. Local replay receipts explicitly label local host clock; it differs from tool UTC and is not used to alter original study clocks.',
    'historical_pending_records': ['artifact-file-reference-receipt.json', 'two-original-intake-summary.json']}
save('independent-C3ff-failed-original-intake-review.json', report)
print(json.dumps({name: entry(B / name) for name in ('retained-raw-coverage-facts.json', 'official-three-source-CI-observation.json', 'independent-C3ff-failed-original-intake-review.json')}, indent=2))
