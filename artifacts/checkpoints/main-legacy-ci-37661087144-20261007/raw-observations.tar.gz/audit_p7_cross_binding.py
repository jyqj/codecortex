#!/usr/bin/env python3
"""Read retained P7 raw evidence; do not execute or retry a product/test."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).resolve().parent
DATA = OUT.parent / 'ci-pr144-final-p7'
ROOT = OUT.parent / 'codecortex-historical-v2'
SOURCE = 'b951f27d3ed50b7755bc2456c6425355f753ec17'
EXPECTED_REVIEWS = {
    '37657882000': 'e17fbcb69e44d12451c2dce2239439833c1d5b14cb249219c400eb1a0979a853',
    '37661087236': '3341c58ba4bad345a9efd2d14a7d622ef24a5f43b9e55ce9b2e69d769ab232d5',
}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def load(path):
    return json.loads(path.read_bytes())

def main():
    binding = load(OUT / 'git-source-binding.json')
    git_map = {path: row['sha256'] for path, row in binding['files'].items()}
    receipt_path = 'artifacts/checkpoints/p7-deadline-wiring-20261007/p7-013-receipt.json'
    receipt_raw = subprocess.check_output(['git', 'show', SOURCE + ':' + receipt_path], cwd=ROOT)
    assert sha(receipt_raw) == '7a647f66344e7e30a7018e19d0e723ee37e98b9876ccf9cc4b2e634123dbdedb'
    original = json.loads(receipt_raw)
    expected = [case['identity'] for group in original['primary_matrix'] for case in group['test_cases']]
    assert len(expected) == len(set(expected)) == 58
    result = {}
    for run, review_sha in EXPECTED_REVIEWS.items():
        folder = DATA / run
        review_raw = (folder / 'independent-review.json').read_bytes()
        assert sha(review_raw) == review_sha
        review = json.loads(review_raw)
        assert review['run_id'] == int(run) and review['job_conclusion'] == 'success'
        before_raw = (folder / 'artifact/source-before.json').read_bytes()
        after_raw = (folder / 'artifact/source-after.json').read_bytes()
        assert before_raw == after_raw
        before = json.loads(before_raw)
        assert before['inputs'] == git_map and before['input_count'] == 776
        assert before['manifest_sha256'] == binding['crate_manifest_sha256']
        index = load(folder / 'actual-rust-test-index.json')
        actual, sources = [], {}
        for log_name in ('deadline-cache.log', 'query-encoding.log', 'execution-deadline.log'):
            raw = (folder / 'artifact' / log_name).read_bytes()
            lines = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', raw.decode()).splitlines()
            sources[log_name] = {'bytes': len(raw), 'sha256': sha(raw)}
            for target in index[log_name]:
                summary = target['summary']
                assert summary['failed'] == summary['ignored'] == 0 and summary['result'] == 'ok'
                assert summary['passed'] == len(target['test_cases'])
                line = lines[summary['log_line'] - 1]
                assert 'test result: ok. ' + str(summary['passed']) + ' passed; 0 failed; 0 ignored;' in line
                for case in target['test_cases']:
                    assert case['result'] == 'ok' and case['ignored_reason'] is None
                    function = case['identity'].split('::', 1)[1]
                    assert 'test ' + function + ' ... ok' in lines[case['log_line'] - 1]
                    actual.append(case['identity'])
        assert len(actual) == len(set(actual)) == 58 and set(actual) == set(expected)
        result[run] = {
            'run_id': int(run), 'job_id': review['job_id'],
            'execution_owner': 'GitHub Actions; not this reviewer',
            'original_independent_reviewer': '/root/ci_evidence',
            'review_sha256': review_sha, 'actual_checkout': before['source_commit'],
            'source_before_after_sha256': sha(before_raw),
            'crate_input_count': 776, 'crate_manifest_sha256': before['manifest_sha256'],
            'all_source_snapshot_entries_match_independently_reconstructed_main_git': True,
            'original58_names_match_original_fixed_receipt': True,
            'each_actual_case_and_summary_checked_against_raw_log_line': True,
            'passed': 58, 'failed': 0, 'ignored': 0, 'duplicates': 0,
            'raw_test_logs': sources,
            'source_and_execution_details': 'See original independent review and retained source/command indices; original schedule and fresh private target were reviewed by ci_evidence.',
        }
    output = {'schema_version': 1, 'reviewer': '/root/ci_history_review',
              'scope': 'Independent raw-line and fixed-Git cross-binding of two previously audited P7 runs',
              'test_or_product_executions_by_this_reviewer': 0,
              'old_primary_57_1_and_diagnostic_2_0_preserved': True,
              'old_failure_cause': 'not_proven', 'runs': result}
    (OUT / 'p7-cross-binding-review.json').write_text(json.dumps(output, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'runs': list(result), 'each_original58': '58 passed / 0 failed / 0 ignored; one execution per identity', 'source_map': binding['crate_manifest_sha256']}))

if __name__ == '__main__':
    main()
