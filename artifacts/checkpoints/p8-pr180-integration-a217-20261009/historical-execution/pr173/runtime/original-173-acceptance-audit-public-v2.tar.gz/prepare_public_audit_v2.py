"""Remove one private transport capture from the public audit delivery.

All v1 files and original measurement evidence remain untouched. No acceptance
or measurement code is run by this packaging step.
"""
from pathlib import Path
import gzip,hashlib,io,json,stat,tarfile
B=Path(__file__).resolve().parent
OLD=B/'durable-audit'
OUT=B/'durable-audit-public-v2';OUT.mkdir(exist_ok=False)
def identity(data):
 return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),git_blob_sha1=hashlib.sha1(('blob %d\0'%len(data)).encode()+data).hexdigest())
def file_identity(path):return dict(path=str(path),**identity(path.read_bytes()))
manifest_path=OLD/'payload-manifest.json'
manifest=json.loads(manifest_path.read_text())
excluded=[r for r in manifest['members'] if r['member']=='official-intake-index.json']
assert len(excluded)==1
x=excluded[0]
exclusions=dict(schema='public-audit-v2-exclusion-v1',v1_archive=manifest['archive'],v1_manifest=file_identity(manifest_path),
 excluded_members=[dict(member=x['member'],bytes=x['bytes'],sha256=x['sha256'],git_blob_sha1=x['git_blob_sha1'],
  reason='Entire transport intake capture excluded because it contains eight private transfer file identifiers at /file_refs/0..7/file_id. No identifier values are copied into this record.')],
 retained_original_members=166,modified_original_members=[],replacement_transport_capture_created=False,
 official_identity_preserved='All eight original artifact-metadata.json members, acceptance-index.json and nine complete original review reports remain byte-identical.',
 v1_private_original_and_all_eight_zip_files_retained=True,measurement_or_acceptance_rerun=False,
 formal_task_completion=False,ledger=dict(done=163,remaining=29))
(OUT/'PUBLIC-EXCLUSIONS.json').write_text(json.dumps(exclusions,indent=2,sort_keys=True)+'\n')
(OUT/'PUBLIC-DELIVERY.md').write_text('''# Public audit delivery v2\n\nUse this v2 archive for publication. The prior v1 archive is retained locally as a private capture and must not be published. `PUBLIC-EXCLUSIONS.json` identifies the single wholly omitted transport-index member by path, size and hashes without exposing its private file identifiers.\n\nAll other 166 original audit members are unchanged. The eight official GitHub artifact metadata files, nine full acceptance reports, command exits, raw-data replay outputs and source/helper identity evidence remain complete. No replacement or edited measurement record was created. The original README and v1 packager are historical members; this note controls the public delivery boundary.\n\nNo measurements or acceptance were rerun. No task status, acceptance requirement or result changed. Formal completion remains false: 163 done / 29 remaining. The complete original ZIPs remain separately retained; this compact audit archive does not claim to contain or publish those ZIPs.\n''')
selected={}
records=[]
for row in manifest['members']:
 if row['member']==x['member']:continue
 p=Path(row['source_path']);data=p.read_bytes()
 assert identity(data)=={k:row[k] for k in ['bytes','sha256','git_blob_sha1']}
 assert stat.S_IMODE(p.stat().st_mode)==row['source_mode']
 selected[row['member']]=p;records.append(dict(row))
assert len(selected)==166
for name,p in [('PUBLIC-EXCLUSIONS.json',OUT/'PUBLIC-EXCLUSIONS.json'),('PUBLIC-DELIVERY.md',OUT/'PUBLIC-DELIVERY.md'),('prepare_public_audit_v2.py',Path(__file__).resolve())]:
 assert name not in selected
 selected[name]=p;records.append(dict(member=name,source_path=str(p),source_mode=stat.S_IMODE(p.stat().st_mode),archive_mode=0o644,**identity(p.read_bytes())))
records.sort(key=lambda r:r['member'])
def serialize():
 out=io.BytesIO()
 with gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0,compresslevel=9) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as tar:
   for row in records:
    data=selected[row['member']].read_bytes();assert identity(data)=={k:row[k] for k in ['bytes','sha256','git_blob_sha1']}
    t=tarfile.TarInfo(row['member']);t.size=len(data);t.mode=0o644;t.mtime=0;t.uid=t.gid=0;t.uname=t.gname='';tar.addfile(t,io.BytesIO(data))
 return out.getvalue()
data=serialize();assert data==serialize()
archive=OUT/'original-173-acceptance-audit-public-v2.tar.gz';archive.write_bytes(data)
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert [m.name for m in members]==[r['member'] for r in records]
 assert x['member'] not in [m.name for m in members]
 for m,r in zip(members,records):
  assert m.isfile() and m.mode==0o644 and m.mtime==0 and m.size==r['bytes']
  assert tar.extractfile(m).read()==selected[m.name].read_bytes()
assert file_identity(manifest_path)==exclusions['v1_manifest']
assert identity(Path(manifest['archive']['path']).read_bytes())=={k:manifest['archive'][k] for k in ['bytes','sha256','git_blob_sha1']}
public=dict(schema='public-original-173-acceptance-audit-package-v2',source_commit=manifest['source_commit'],
 archive=file_identity(archive),members=records,member_count=len(records),uncompressed_bytes=sum(r['bytes'] for r in records),
 unchanged_v1_members=166,new_public_boundary_members=3,exclusions=exclusions,
 sorted_USTAR_gzip_mtime0=True,independent_second_serialization_byte_identical=True,full_reopen_source_byte_equality=True,
 original_zips_in_package=False,all_original_zips_retained=True,public_raw_parts_completion_claim=False,
 measurement_rerun=False,formal_task_completion=False,ledger=dict(done=163,remaining=29))
p=OUT/'payload-manifest.json';p.write_text(json.dumps(public,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(archive=file_identity(archive),manifest=file_identity(p),exclusions=file_identity(OUT/'PUBLIC-EXCLUSIONS.json'),members=len(records)),indent=2))
