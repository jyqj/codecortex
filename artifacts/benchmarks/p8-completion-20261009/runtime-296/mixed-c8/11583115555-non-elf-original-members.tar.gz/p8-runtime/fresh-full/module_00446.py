def stable_00446():
    return 446
