#!/usr/bin/env python3
"""Generate two v15 binding files only after actual P6B and independent R4 exist.
This author-side mechanical tool cannot create or sign an independent review.
It does not run the original source verifier or claim any runtime/task result.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
BASE = "7354db236c9d9850a75f31672697ae9eab44565e"
EXPECTED_PRODUCT = "5534ebf38cc31efec1590d132ca57c30e2f77f1b"
EXPECTED_PRODUCT_TREE = "3d3d5a6ef11f3e632eb5ab8ce2502d7854aa2bd1"
EXPECTED_REVIEW_PATH = "artifacts/checkpoints/p8-crash-ready-publication-bfcc-20261009/independent-source-review.json"
EXPECTED_COUNTS = {"product": 1095, "delta": 72, "validation": 142}
PINS = ("PRODUCT", "REVIEW", "REVIEW_PATH", "REGISTRY_SHA256")
AUTHORS = {"/root", "root"}  # P6B creator; current reviewer did not author the existing candidate patch.
NEW_VALIDATION = set()
CHANGED_VALIDATION = set()
SEED_G = "fffd950d5b34b0180f308db1428a57d5bf358bf1"
SEED_REGISTRY_SHA256 = "2bb7060e4af149ebe3a56aed86dc6c387b0748a7a1c5ef3dd91b152ea6a6fd52"
SEED_GUARD_SHA256 = "6eb8315072647f67bcf15ac2772c6c28411bf57c0e547b9c4ab907b2f076ed12"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git_blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def required(condition, message):
    if not condition:
        raise ValueError(message)

def immutable(value):
    return isinstance(value, str) and re.fullmatch("[0-9a-f]{40}", value) is not None

def read_json(path):
    return json.loads(path.read_bytes())

def prepare(args):
    inputs = read_json(args.product_inputs)
    product_metadata = read_json(args.product_commit_file)
    review_metadata = read_json(args.review_commit_file)
    product = inputs.get("source")
    product_tree = inputs.get("source_tree", inputs.get("tree"))
    review_commit = review_metadata.get("sha")
    required(immutable(product) and immutable(product_tree) and immutable(review_commit),
             "Actual immutable P/tree/R metadata is required; null and placeholders are rejected")
    required(product == EXPECTED_PRODUCT and product_tree == EXPECTED_PRODUCT_TREE,
             "This prepared generator binds only the observed actual integrated P6B")
    required(product_metadata.get("sha") == product
             and product_metadata.get("tree", {}).get("sha") == product_tree,
             "P identity must equal the observed official product commit")
    required([v.get("sha") for v in product_metadata.get("parents", [])] == [SEED_G],
             "Actual one-fixture P6B must have the actual M7F as sole parent")
    required([v.get("sha") for v in review_metadata.get("parents", [])] == [product],
             "Actual R must have this actual P as its sole parent")
    counts = {"product": len(inputs["complete_inputs"]), "delta": len(inputs["paths"]),
              "validation": len(inputs["validation_inputs"])}
    required(counts == EXPECTED_COUNTS, "Wrong combined product/delta/validation counts")
    required(inputs.get("base") == BASE, "Historical BASE must remain unchanged")
    required(all(set(v) == {"before_sha256", "sha256"} for v in inputs["paths"].values()),
             "Review deltas must retain the original two-key schema")
    review_path = args.review_path
    required(review_path == EXPECTED_REVIEW_PATH, "Wrong final canonical review artifact path")
    required(review_path.startswith("artifacts/checkpoints/")
             and review_path.endswith("/independent-source-review.json")
             and ".." not in Path(review_path).parts and not Path(review_path).is_absolute(),
             "An actual canonical review artifact path is required")

    raw = args.review_file.read_bytes()
    review = json.loads(raw)
    required(review.get("source") == product and review.get("base") == BASE,
             "Review must bind this actual P and original BASE")
    required(review.get("verdict") == "accepted_scoped"
             and review.get("scope") == "independently_reviewed_source_and_validation_inputs",
             "A real non-author scoped source review is required")
    reviewers = review.get("independent_reviewers")
    required(isinstance(reviewers, list) and bool(reviewers)
             and all(isinstance(v, str) and v.strip() for v in reviewers),
             "Missing actual independent reviewers")
    required(reviewers == ["/root/todo_audit"],
             "Bind the actual independently signed R6B; reviewer did not author the existing PID candidate")
    reviewer_ids = {v.split(":", 1)[0].strip() for v in reviewers}
    required(not AUTHORS.intersection(reviewer_ids),
             "The integration/fix author cannot sign this independent R")
    required(review.get("unresolved_blockers") == [],
             "Independent source blockers are unresolved or unspecified")
    required(review.get("paths") == inputs["paths"], "All 72 exact deltas must match actual P")
    required(review.get("complete_inputs") == inputs["complete_inputs"],
             "All 1095 exact product hashes must match actual P")
    required(review.get("validation_inputs") == inputs["validation_inputs"],
             "All 142 exact validation hashes must match actual P")
    if "source_tree" in review:
        required(review["source_tree"] == product_tree, "Wrong reviewed product tree")
    required(immutable(args.review_git_blob) and git_blob(raw) == args.review_git_blob,
             "Canonical review bytes must equal the actual installed R Git blob")

    required(sha((HERE / "seed-M7F-registry.json").read_bytes()) == SEED_REGISTRY_SHA256
             and sha((HERE / "seed-M7F-guard.py").read_bytes()) == SEED_GUARD_SHA256,
             "Seeds must be the exact actual M7F binding bytes")
    registry = read_json(HERE / "seed-M7F-registry.json")
    before_validation = registry["validation_inputs"]
    new_validation = set(inputs["validation_inputs"]) - set(before_validation)
    changed_validation = {p for p in before_validation
                          if inputs["validation_inputs"].get(p) != before_validation[p]}
    required(new_validation == NEW_VALIDATION and changed_validation == CHANGED_VALIDATION,
             "Combined validation domain must contain zero additions/removals/hash changes relative to actual M7F")
    changed_test = "crates/cc-semantic/tests/p7_crash_preparation.rs"
    required(inputs["complete_inputs"].keys() == registry["complete_inputs"].keys()
             and {p for p in inputs["complete_inputs"] if inputs["complete_inputs"][p] != registry["complete_inputs"][p]} == {changed_test},
             "Exactly the existing reviewed PID fixture product hash may differ from M7F")
    required(changed_test not in registry["delta"]
             and set(inputs["paths"]) == set(registry["delta"]) | {changed_test}
             and all(inputs["paths"][p] == v for p, v in registry["delta"].items())
             and inputs["paths"][changed_test] == {
                 "before_sha256": registry["complete_inputs"][changed_test],
                 "sha256": inputs["complete_inputs"][changed_test]},
             "All prior 71 BASE deltas remain exact; only the BASE-identical PID fixture becomes delta 72")
    old_registry = dict(registry)
    registry.update(product_source=product, review_source=review_commit,
                    review_sha256=sha(raw), complete_inputs=inputs["complete_inputs"],
                    delta=inputs["paths"], validation_inputs=inputs["validation_inputs"])
    allowed_registry = {"product_source", "review_source", "review_sha256",
                        "complete_inputs", "delta", "validation_inputs"}
    required({k for k in old_registry.keys() | registry.keys()
              if old_registry.get(k) != registry.get(k)} <= allowed_registry,
             "Unexpected registry metadata change")
    registry_raw = (json.dumps(registry, indent=2, sort_keys=True) + "\n").encode()

    guard_before = (HERE / "seed-M7F-guard.py").read_text()
    guard = guard_before
    values = {"PRODUCT": product, "REVIEW": review_commit,
              "REVIEW_PATH": review_path, "REGISTRY_SHA256": sha(registry_raw)}
    for name, value in values.items():
        guard, count = re.subn("^" + name + r' = "[^"]*"$',
                               name + " = " + json.dumps(value), guard, flags=re.M)
        required(count == 1, "Expected one original pin: " + name)
    normalize = lambda text: re.sub(
        r"^(PRODUCT|REVIEW|REVIEW_PATH|REGISTRY_SHA256) = .*$",
        r"\1 = <PIN>", text, flags=re.M)
    required(normalize(guard) == normalize(guard_before),
             "Original guard changed beyond its four identity pins")
    before_lines, after_lines = guard_before.splitlines(), guard.splitlines()
    required(len(before_lines) == len(after_lines), "Guard line count changed")
    changed = [a.split(" = ")[0] for a, b in zip(before_lines, after_lines) if a != b]
    required(set(changed) == set(PINS) and len(changed) == 4,
             "Expected exactly four changed pin lines")
    receipt = {
        "scope": "Mechanical binding generation from actual P and actual non-author R only",
        "product": product, "product_tree": product_tree, "base": BASE, "seed_G": SEED_G,
        "review": review_commit, "review_path": review_path,
        "review_bytes": len(raw), "review_sha256": sha(raw), "review_git_blob": git_blob(raw),
        "actual_reviewers": reviewers, "counts": counts,
        "new_validation": sorted(new_validation), "changed_validation": sorted(changed_validation),
        "changed_guard_lines": changed,
        "registry_bytes": len(registry_raw), "registry_sha256": sha(registry_raw),
        "registry_git_blob": git_blob(registry_raw),
        "guard_bytes": len(guard.encode()), "guard_sha256": sha(guard.encode()),
        "guard_git_blob": git_blob(guard.encode()),
        "review_or_source_admission_signed_by_this_generator": False,
        "original_v15_actual_execution_remains_separate": True,
        "Rust_runtime_performance_or_TODO_credit": False,
    }
    return registry_raw, guard.encode(), receipt

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--product-inputs", type=Path, required=True)
    p.add_argument("--product-commit-file", type=Path, required=True)
    p.add_argument("--review-file", type=Path, required=True)
    p.add_argument("--review-commit-file", type=Path, required=True)
    p.add_argument("--review-path", required=True)
    p.add_argument("--review-git-blob", required=True)
    targets = p.add_mutually_exclusive_group(required=True)
    targets.add_argument("--output-directory", type=Path)
    targets.add_argument("--verify-existing-directory", type=Path)
    args = p.parse_args()
    registry, guard, receipt = prepare(args)
    if args.verify_existing_directory:
        target = args.verify_existing_directory
        required((target / "scripts/reviewed-source-registry-v15.json").read_bytes() == registry,
                 "Installed registry differs from generated bytes")
        required((target / "scripts/verify_reviewed_source_v15.py").read_bytes() == guard,
                 "Installed guard differs from four-pin generated bytes")
        receipt["mode"] = "read_only_existing_byte_comparison"
    else:
        target = args.output_directory
        required(not target.exists(), "Output must be a new directory; never overwrite old source")
        (target / "scripts").mkdir(parents=True)
        (target / "scripts/reviewed-source-registry-v15.json").write_bytes(registry)
        (target / "scripts/verify_reviewed_source_v15.py").write_bytes(guard)
        receipt["mode"] = "new_staging_directory_only"
        (target / "generation-receipt.json").write_text(
            json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(json.dumps(receipt, sort_keys=True))

if __name__ == "__main__":
    main()
