def stable_00301():
    return 301
