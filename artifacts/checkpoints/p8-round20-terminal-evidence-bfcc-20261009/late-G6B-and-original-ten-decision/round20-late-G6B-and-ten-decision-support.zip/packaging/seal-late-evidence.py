#!/usr/bin/env python3
"""A bounded append-only evidence package; no network or product execution."""
from pathlib import Path, PurePosixPath
import datetime
import hashlib
import json
import stat
import zipfile

ROOT=Path(__file__).resolve().parent
CONFIG=ROOT/'frozen-config.json'
config=json.loads(CONFIG.read_bytes())
OUT=ROOT/'sealed-attempt01'
OUT.mkdir(exist_ok=False)

def sha(b):return hashlib.sha256(b).hexdigest()
def oid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def js(v):return (json.dumps(v,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode()
def meta(p):
    b=p.read_bytes();return {'local_path':str(p),'bytes':len(b),'sha256':sha(b),'git_blob':oid(b),'mode':'100644'}

payload={};members=[];originals=[]
def add(name,b,mode=0o644):
    q=PurePosixPath(name)
    assert not q.is_absolute() and '..'not in q.parts and '\x00'not in name and '\\'not in name
    assert name not in payload and not name.lower().endswith('.zip')
    payload[name]=(b,mode);members.append({'path':name,'bytes':len(b),'sha256':sha(b),'git_blob':oid(b),'posix_mode':format(mode,'04o')})
def add_file(p,name,expected=None):
    assert p.is_file() and not p.is_symlink()
    b=p.read_bytes();mode=stat.S_IMODE(p.stat().st_mode)
    if expected:
        assert len(b)==expected['bytes'] and sha(b)==expected['sha256']
        if expected.get('git_blob'):assert oid(b)==expected['git_blob']
        m=expected.get('posix_mode',expected.get('mode'))
        if m and len(str(m))<=4:assert mode==int(str(m),8)
    add(name,b,mode);originals.append({**meta(p),'member':name,'posix_mode':format(mode,'04o')})

for group in config['groups']:
    p=Path(group['selection_path']);b=p.read_bytes();assert len(b)==group['bytes'] and sha(b)==group['sha256']
    d=json.loads(b);assert len(d['files'])==group['file_count'] and sum(x['bytes']for x in d['files'])==group['selected_bytes']
    add_file(p,'selections/'+group['name']+'.json')
    for row in d['files']:
        p=Path(row.get('local_path',row.get('source_path')))
        rel=row.get('bundle_path',row.get('archive_path',row.get('relative_path',row.get('repository_path'))))
        assert rel
        add_file(p,'evidence/'+group['name']+'/'+rel,row)
for row in config['root_receipts']:
    p=Path(row['local_path']);add_file(p,'evidence/root-round20/'+p.name,row)

pub=json.loads(Path('/dev/shm/root-round20/round20-checkpoint-publication-original.json').read_bytes())
parent=pub['commit']['structuredContent']['sha'];tree=pub['tree']['structuredContent']['sha']
assert parent=='3339b010a2ee7f94fb01f9cf1c2a4e0c07967c6a' and tree=='592d325d01bd0d28a973fad5329be02d22e65d54'
peer=json.loads(Path('/dev/shm/pr-triage-round20-installed-R6B-G6B-review/independent-installed-R6B-G6B-review.json').read_bytes())
ci=json.loads(Path('/dev/shm/pr-triage-round20-G6B-first-CI/initial-G6B-CI-and-M7F-terminal-snapshot.json').read_bytes())
assert peer['actual_G']==ci['PR180']['head']=='88d5f547bb0fae273f4270742503fd1fd5e70bc2'
assert peer['actual_G_tree']==ci['test_merge']['tree']=='e039a817291934b15cc018fd74d2c83982bb7f37'
assert ci['G6B_counts']=={'runs':7,'check_runs':25,'actual_jobs':25,'queued_jobs':25,'in_progress_jobs':0,'completed_jobs':0}
summary={'schema':'round20-late-append-only-evidence-snapshot-v1','sealed_at_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'formal_round_state':{'round':20,'state':'active','closed_by_this_package':False},
         'original_TODO':{'total':192,'done':163,'new_completed':0,'remaining':29},
         'checkpoint_parent':{'commit':parent,'tree':tree},
         'G6B_source_binding':{'P':peer['actual_P'],'R':peer['actual_R'],'G':peer['actual_G'],'tree':peer['actual_G_tree'],
                               'peer_verdict':peer['verdict'],'maps':peer['canonical_maps_equal'],
                               'scope':'Source/review installation and two bindings only; no product/runtime execution credit.'},
         'publication_and_first_CI':{'observation_window_UTC':ci['observation_window_UTC'],'PR180':ci['PR180'],
                                     'test_merge':ci['test_merge'],'counts':ci['G6B_counts'],
                                     'run_ids':[r['run_id']for r in ci['G6B_runs']],
                                     'all_created_jobs_queued_at_original_snapshot':True,
                                     'final_job_denominator_not_assumed':True,'executed_checkout_not_claimed':True,
                                     'early_stale_PR_response_retained':True},
         'previous_M7F_scope':{'selected_four_jobs':ci['previous_M7F_four_jobs'],'source_execution_not_transferred_to_G6B':True,
                               'run_and_job_layer_state_both_preserved':True},
         'original_ten_decision':{'source_directory_label':'round21-original-ten-decision',
                                  'directory_and_original_title_do_not_announce_formal_round21':True,
                                  'interpretation':'Bounded existing-definition/index review:005/006 retain their own missing complete-study gates; eight other accepted components retain actual-source scopes and open original dependencies. No newly discovered same-source complete accepted five-capacity study was found in that bounded index.',
                                  'no_new_acceptance_gate_or_TASK_status_edit':True},
         'missing_requested_items':[],
         'past_snapshots_unchanged':True,'no_new_CI_observation_or_product_execution':True,
         'no_nested_ZIP_or_reembedded_canonical_review':True,
         'selected_group_counts':[{k:g[k]for k in ['name','file_count','selected_bytes']}for g in config['groups']],
         'root_receipts':len(config['root_receipts'])}
locators={'schema':'already-persisted-evidence-only-references-v1',
          'checkpoint3339':{'commit':parent,'tree':tree,'prefix':'artifacts/checkpoints/p8-round20-terminal-evidence-bfcc-20261009/',
                            'includes_complete_C3ff_original_ZIPs_and_prior_G4_terminal_package':True},
          'checkpoint8d585':{'commit':'8d585ac602f2e8d045afcb6b423e25802517a14a','prefix':'artifacts/checkpoints/p8-a23-closeout-20261009-bfcc/round19-selected-progress/'},
          'R6B_canonical_and_support':{'commit':peer['actual_R'],'files':peer['R_exact_two_added_artifact_leaves']},
          'not_included_as_payload':'All referenced previous ZIPs/canonical full review bytes. This package adds only the specifically selected late receipts and bounded reports.'}
for name,value in [('snapshot-summary.json',summary),('immutable-existing-locators.json',locators),('original-member-custody.json',{'files':list(originals),'count':len(originals)})]:
    b=js(value);add(name,b);(OUT/name).write_bytes(b)
add_file(CONFIG,'packaging/frozen-config.json')
add_file(Path(__file__),'packaging/seal-late-evidence.py')
zpath=OUT/'round20-late-G6B-and-ten-decision-support.zip'
with zipfile.ZipFile(zpath,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
    for name in sorted(payload):
        b,mode=payload[name];i=zipfile.ZipInfo(name,date_time=(2026,10,9,0,0,0));i.create_system=3;i.external_attr=(stat.S_IFREG|mode)<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,b)
with zipfile.ZipFile(zpath)as z:
    assert z.testzip()is None and sorted(z.namelist())==sorted(payload)
    for i in z.infolist():
        b,mode=payload[i.filename];assert z.read(i)==b and stat.S_IMODE(i.external_attr>>16)==mode
for row in originals:
    p=Path(row['local_path']);r=meta(p)
    assert all(r[k]==row[k]for k in ['bytes','sha256','git_blob'])
    assert format(stat.S_IMODE(p.stat().st_mode),'04o')==row['posix_mode']
result={'schema':'late-evidence-package-verified-v1','ZIP':meta(zpath),'member_count':len(members),'uncompressed_bytes':sum(r['bytes']for r in members),
        'members':members,'summary':summary,'immutable_locators':locators,'originals_before_after_equal':True,
        'CRC_SHA_Gitblob_bytes_POSIXmode_verified':True,'nested_ZIPs':0,'remote_uploaded':False}
(OUT/'package-verification-for-final-index.json').write_bytes(js(result))
print(json.dumps({k:result[k]for k in ['ZIP','member_count','uncompressed_bytes','originals_before_after_equal','nested_ZIPs','remote_uploaded']},sort_keys=True))
