from pathlib import Path
import hashlib,json,re,stat,zipfile
p=Path(__file__).resolve().parent
parent=p.parent
out=p/'sealed-attempt02';out.mkdir(exist_ok=False)
def ident(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
names=['candidate.patch','candidate-source-proof.json','scope-review.md','pending-closeout.json','candidate/docs/BENCHMARK.md','package-v2.py']
selected=[('final/'+n,p/n) for n in names]
for n in ['candidate.patch','candidate-source-proof.json','candidate/docs/BENCHMARK.md','scope-review.md','pending-closeout.json','package-reviewed-candidate.py','pack.stdout','pack.stderr','pack-receipt.json','original-task-and-validation-excerpt.json','read-scope-and-source-locators.json','original/facts-check-output.json','original/retained-compatibility-log-lines.json','original/docs/BENCHMARK.md','original/crates/cc-eval/src/benchmark/oracle.rs','original/crates/cc-eval/src/benchmark/mutation_case.rs']:
    selected.append(('prior-and-source/'+n,parent/n))
peer=parent.parent/'round29-P8-018-document-facts-peer/independent-document-scope-review.json'
selected.append(('independent-v1-document-review.json',peer))
data={};members=[]
for name,path in selected:
    assert path.is_file() and not path.is_symlink(),str(path)
    b=path.read_bytes()
    urls=re.findall(rb'https?://[^\s<>"\x27]+',b)
    assert not any(re.search(rb'[?&](?:sig|X-Amz-Signature)=',u,re.I) for u in urls), name
    data[name]=b;members.append({'member':name,'original_path':str(path),'mode':format(stat.S_IMODE(path.stat().st_mode),'04o'),**ident(b)})
assert ident(data['final/candidate/docs/BENCHMARK.md'])['git_blob']=='39513e0fa62eeab815e0c503594846d48b75c8e6'
assert json.loads(data['final/pending-closeout.json'])['apply_now'] is False
assert json.loads(data['prior-and-source/pack-receipt.json'])['exit_code']==1
manifest={'scope':'P8-018 documentary candidate and original evidence references; no new tests','members':members,'full_original_log_not_duplicated':{'git_blob':'907b9a33cb22d7a13b947e4fac6aaa121c594d55','bytes':1081030}}
mb=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();(out/'member-manifest.json').write_bytes(mb)
with zipfile.ZipFile(out/'P8-018-document-facts-support.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for row in members:
        zi=zipfile.ZipInfo(row['member'],(1980,1,1,0,0,0));zi.create_system=3;zi.external_attr=(stat.S_IFREG|int(row['mode'],8))<<16;zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,data[row['member']])
    z.writestr('member-manifest.json',mb)
with zipfile.ZipFile(out/'P8-018-document-facts-support.zip') as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(data)|{'member-manifest.json'}
    for row in members:assert z.read(row['member'])==data[row['member']]
for name,path in selected:assert path.read_bytes()==data[name]
summary={'task_id':'P8-018','apply_now':False,'status':'in_progress','remaining_tasks':28,'new_task_credit':0,'only_product_path':'docs/BENCHMARK.md','candidate_git_blob':'39513e0fa62eeab815e0c503594846d48b75c8e6','only_change':'14 oracle tables to current linked 15 table list; MCP tool count remains 14','root_v2_label_adjustment':True,'v1_peer_blob':'4bd359696fe62860e7c3fda42451804d414ba6f3','prior_packaging_failure_preserved':True,'product_tests_executed':False,'selected_original_files':len(members),'support_zip_members':len(members)+1}
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
prefix='artifacts/checkpoints/p8-round29-document-facts-preparation-bfcc-20261009/'
upload={'candidate_product_blob':{'repository_path':'docs/BENCHMARK.md','local_path':str(p/'candidate/docs/BENCHMARK.md'),**ident(data['final/candidate/docs/BENCHMARK.md'])},'checkpoint_leaves':[]}
for n in ['P8-018-document-facts-support.zip','member-manifest.json','summary.json']:
    upload['checkpoint_leaves'].append({'repository_path':prefix+n,'local_path':str(out/n),**ident((out/n).read_bytes())})
(out/'upload-manifest.json').write_text(json.dumps(upload,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'packaged','selected_files':len(members),'zip_members':len(members)+1,'original_inputs_unchanged':True,'upload_manifest':str(out/'upload-manifest.json')}))
