def p8_runtime_stable_signal():
    return 7
