def stable_00120():
    return 120
