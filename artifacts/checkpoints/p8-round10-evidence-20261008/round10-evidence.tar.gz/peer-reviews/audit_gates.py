#!/usr/bin/env python3
"""Read original G4 gate bytes and source; no product/Cargo execution."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/2eaa00d0f93a/p8-formal-evidence-G4/gates')
REPO = Path('/workspace/scratch/2eaa00d0f93a/p8-G4-exact-source')
OUT = Path(__file__).resolve().parent
G = '260f596582f2d82b8d7c707b61a6b8b6a43b069f'
def sha(b): return hashlib.sha256(b).hexdigest()
def file_sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
def read(p): return json.loads(p.read_bytes())

review = read(ROOT/'inspection.json')
assert file_sha(ROOT/'inspection.json') == '87ece4c38eae2a513515be88aefbad59cc9487c99c75e5579bfad715e910cfdf'
archive = ROOT/'artifact-11584996050.zip'
assert archive.stat().st_size == review['artifact_bytes'] == 32977177
assert file_sha(archive) == review['artifact_sha256'] == 'b5d6fd945c468822700aafe0f66fcf482697c2333e2197fd2e0039969671a529'
inventory = read(ROOT/'member-hashes.json')
with zipfile.ZipFile(archive) as z:
    assert len(z.infolist()) == len(set(z.namelist())) == len(inventory) == 337
    for entry in z.infolist():
        with z.open(entry) as f: digest = hashlib.file_digest(f, 'sha256').hexdigest()
        assert inventory[entry.filename] == {'bytes':entry.file_size,'sha256':digest,'crc32':f'{entry.CRC:08x}'}
    report = json.loads(z.read('report.json'))
    assert report['files'] == {n:r['sha256'] for n,r in inventory.items() if n != 'report.json'}
    source=report['source']
    assert source['source_commit'] == G and source['source_tree'] == '645404431ca15770d6e729785a3ada68b096c593'
    assert len(source['inputs']) == source['input_count'] == 1087
    for path,expected in source['inputs'].items():
        body=subprocess.check_output(['git','show',G+':'+path],cwd=REPO)
        assert sha(body)==expected
    test_body=subprocess.check_output(['git','show',G+':crates/cc-eval/tests/benchmark_cli.rs'],cwd=REPO).decode()
    cli_body=test_body[test_body.index('fn compare_cli('):test_body.index('\n#[test]',test_body.index('fn compare_cli('))]
    assert 'CARGO_BIN_EXE_cc-eval' in cli_body and '.output()' in cli_body
    for i,case in enumerate(report['cases']):
        prefix=f'case-{i:02}/'
        output=z.read(prefix+'execution/stdout.log').decode()
        assert 'test '+case['test_name']+' ... ok' in output
        assert '1 passed; 0 failed; 0 ignored;' in output
        assert case['source']==source and case['execution']['exit_code']==case['build']['exit_code']==0
        assert case['executable_sha256']==inventory[prefix+'fault-test']['sha256']
        rows=[json.loads(line) for line in z.read(prefix+'build/stdout.log').splitlines()]
        a=case['cargo_artifact']
        assert a in rows and rows[-1]=={'reason':'build-finished','success':True}
        assert a['manifest_path']=='/home/runner/work/codecortex/codecortex/crates/cc-eval/Cargo.toml'
        assert a['target']['src_path']=='/home/runner/work/codecortex/codecortex/crates/cc-eval/tests/benchmark_cli.rs'
        assert a['profile']['test'] is True
        for stage in ('build','execution'):
            for name,digest in case[stage]['logs_sha256'].items(): assert inventory[prefix+stage+'/'+name]['sha256']==digest
    comp={n:json.loads(z.read(n)) for n in inventory if n.endswith('comparison.json')}
    assert len(comp)==5
    actual=sorted((r['status'],r['exit_code']) for r in comp.values())
    assert actual==sorted([('failed',1),('failed',1),('inconclusive',1),('invalid_measurement',2),('invalid_measurement',2)])
    assert inventory['cc-eval']['sha256']==report['cli']['executable_sha256']==review['cli_sha256']
log=(ROOT/'job-113576446441.log').read_text()
assert 'git checkout --progress --force '+G in log and re.search(r'git log -1 --format=%H\n[^\n]*'+G,log)
result={'status':'accepted_scoped_second_review_of_actual_original_G4_gate_evidence','source':G,'root_inspection_sha256':file_sha(ROOT/'inspection.json'),'root_inspector_sha256':file_sha(ROOT/'inspect_original.py'),'original_zip_sha256':file_sha(archive),'all_337_members_CRC_SHA_reverified':True,'source_inputs_independently_rehashed':1087,'actual_rust_test_passes':6,'actual_library_test_cases':2,'actual_CLI_test_cases':4,'actual_CLI_invocations_asserted_in_fixed_Rust_source':6,'retained_comparison_outputs':5,'exit_scope':'quality/latency/inconclusive actual CLI exits 1; raw lock/bad policy/refusal actual CLI exits 2; all six Rust test harness executions exit 0','limitations':['These synthetic controls do not establish retrieval quality or performance.','CLI exit assertions are original CI executions retained by test logs/source, not new receiver executions.','No Cargo, product, native replayer, or source modification performed by this review.','Dependencies and original TODOs remain open.'],'TODO_closed':0,'TODO_remaining':29}
(OUT/'gates-audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':result['status'],'sha256':file_sha(OUT/'gates-audit.json')}))
