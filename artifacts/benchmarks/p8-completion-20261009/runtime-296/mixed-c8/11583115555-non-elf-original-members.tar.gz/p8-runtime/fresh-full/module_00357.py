def stable_00357():
    return 357
