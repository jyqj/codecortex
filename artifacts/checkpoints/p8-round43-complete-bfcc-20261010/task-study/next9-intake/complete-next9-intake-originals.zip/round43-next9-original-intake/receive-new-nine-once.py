import pathlib,json,hashlib,zipfile,stat,subprocess,datetime,time,traceback,re
from record_child_once import capture_once, inspect_recorded_stdio
R=pathlib.Path('/workspace/scratch/bfccb8494ba0');D=pathlib.Path(__file__).resolve().parent;BD=R/'round42-new45-build-original-intake';V=BD/'source-exact-G2';B=BD/'original-build'
SOURCE='f97c5068d056969705e8387ba1f37d83847f5bee';RUN=38026411200
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def meta(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':oct(p.stat().st_mode&0o777)}
def shared():
 inventory=json.loads((BD/'restored-source-inventory.json').read_text())['inventory']
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=V,text=True).strip(),'index':meta(V/'.git/index'),'source':{x:meta(V/x) for x in inventory},'build':{p.relative_to(B).as_posix():meta(p) for p in sorted(B.rglob('*')) if p.is_file()},'accepted_tuple':meta(BD/'validation-attempt01/original-validate-build-return.json')}
original=R/'round43-new45-original-artifacts/next9-original-inputs.json';data=json.loads(original.read_text());dump(D/'official-original-inputs.json',data)
assert data['run_id']==RUN and data['attempt']==1 and data['source']==SOURCE
assert len(data['inputs'])==9
expected={('body',50000,0),('config',50000,0)} | {('batch_10',n,0) for n in [1000,5000,10000,50000]} | {('batch_100',n,0) for n in [1000,5000,10000]};seen=set();records=[]
before=shared();dump(D/'shared-source-build-before.json',before)
for item in data['inputs']:
 a=item['artifact'];m=re.fullmatch(r'p8-task-shard-(body|config|batch_10|batch_100)-(1000|5000|10000|50000)-38026411200-1',a['name']);assert m
 slot=(m[1],int(m[2]),0);assert slot in expected and slot not in seen;seen.add(slot)
 name=f'{slot[0]}-{slot[1]}-0';A=D/name;A.mkdir();S=A/'original-shard';zpath=pathlib.Path(item['local_path'])
 record={'slot':list(slot),'artifact':a,'zip_path':str(zpath),'receipt_directory':str(A),'shard_directory':str(S),'transport_exit':None,'original_validate_shard_calls':0,'validator_exit':None}
 try:
  assert a['workflow_run']['id']==RUN and a['workflow_run']['head_sha']==SOURCE
  zb=zpath.read_bytes();assert len(zb)==a['size_in_bytes'] and hashlib.sha256(zb).hexdigest()==a['digest'].removeprefix('sha256:')
  record['whole_zip']={'bytes':len(zb),'sha256':hashlib.sha256(zb).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(zb)).encode()+b'\0'+zb).hexdigest()}
  S.mkdir();members=[];paths=set()
  with zipfile.ZipFile(zpath) as z:
   for entry in z.infolist():
    p=pathlib.PurePosixPath(entry.filename);mode=(entry.external_attr>>16)&0xffff
    assert entry.filename not in paths and not p.is_absolute() and '..' not in p.parts and '\\' not in entry.filename and not stat.S_ISLNK(mode) and not entry.flag_bits&1
    paths.add(entry.filename);dest=S.joinpath(*p.parts)
    if entry.is_dir():dest.mkdir(parents=True,exist_ok=True);continue
    assert entry.file_size<=512*1024*1024
    b=z.read(entry);assert len(b)==entry.file_size
    dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('xb') as out:out.write(b)
    restored=mode&0o777 or 0o644;dest.chmod(restored)
    members.append({'path':entry.filename,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'zip_crc32':f'{entry.CRC:08x}','zip_mode':oct(mode),'restored_mode':oct(restored)})
  record['transport_exit']=0;dump(A/'transport-original.json',{'artifact':a,'whole_zip':record['whole_zip'],'members':members,'full_member_reads_for_CRC':1})
 except Exception:
  record['transport_exit']=1;(A/'transport-error.original.txt').write_text(traceback.format_exc());records.append(record);dump(D/'progress.json',records);continue
 config={'slot':list(slot),'artifact':a,'shard_directory':str(S),'receipt_directory':str(A),'source_directory':str(V),'build_directory':str(B),'accepted_build_tuple':str(BD/'validation-attempt01/original-validate-build-return.json')};dump(A/'input.json',config)
 argv=['python3','-B',str(D/'validate-one-original-shard.py'),str(A/'input.json')];start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 record['original_validate_shard_calls']=1
 receipt=capture_once(argv,R,A)
 custody=inspect_recorded_stdio(A);dump(A/'stdio-custody-check.json',custody)
 record['validator_exit']=receipt['exit_code'];record['execution']=receipt;record['stdio_custody']=custody
 if receipt['exit_code']==0:
  result=json.loads((A/'original-validate-shard-return.json').read_text());record['measurement_records']=len(result['measurements']);record['return']=meta(A/'original-validate-shard-return.json')
 records.append(record);dump(D/'progress.json',records);print(json.dumps({'slot':slot,'exit':receipt['exit_code'],'records':record.get('measurement_records')}),flush=True)
after=shared();dump(D/'shared-source-build-after.json',after)
assert seen==expected and before==after
terminal={'schema':'new9-original-shards-terminal-v1','source':SOURCE,'run_id':RUN,'attempt':1,'new_slot_count':9,'accepted_cells':sum(x['validator_exit']==0 for x in records),'failed_cells':sum(x['validator_exit']!=0 for x in records),'accepted_records':sum(x.get('measurement_records',0) for x in records),'records':records,'source_build_before_after_equal':True,'validate_build_calls':0,'compile_or_measurement_calls':0,'old_slots_reexecuted':0,'task_credit':0,'aggregate_executed':False,'stdio_custody_complete':all(x.get('stdio_custody',{}).get('custody_complete') is True for x in records)};dump(D/'terminal.json',terminal)
print(json.dumps({k:v for k,v in terminal.items() if k!='records'}),flush=True)
raise SystemExit(0 if terminal['failed_cells']==0 else 1)
