"""Read-only receiver binding to exact canonical R; not a full Git checkout.

Original verification functions are imported byte-for-byte from the received
artifact only after all seven modules match the canonical validation inventory.
This adapter substitutes only the local Git snapshot transport, not the original
portable-cell assertions or producer's source/observer receipts.
"""
import hashlib
import importlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
BASE = Path('/workspace/scratch/bfccb8494ba0')
OUT = BASE / 'todo-audit-round12/recovery-platform-Gc8'
RAW = BASE / 'pr-triage-primary-recovery/raw-pr178-c8be5afa'
COMMIT = 'c8be5afaac568ffd40ef86d3795423c3b73c9f39'
TREE = '9b031be22a430e51e153cce6e80770ed885818e3'
HOME = RAW / '11604900056/attempt01/extracted/p8-full-recovery'
SOURCE = HOME / 'observer-source'
R_PATH = BASE / 'pr-triage-primary-recovery/runtime-review-Gc8/exact-canonical-R.json'
R_SHA = 'c38d10f1b0d5935384039a6af7df6e8d222bc351a68d3137b09e664735ee9404'

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()

assert digest(R_PATH) == R_SHA
R = json.loads(R_PATH.read_text())
assert len(R['complete_inputs']) == 1090 and len(R['validation_inputs']) == 139
J = json.loads((HOME / 'full-recovery.json').read_text())
CURRENT = dict(source_commit=COMMIT, source_tree=TREE, input_count=1090,
               inputs=R['complete_inputs'], manifest_sha256=hashlib.sha256(json_bytes(R['complete_inputs'])).hexdigest())
assert J['source'] == CURRENT
assert J['observer_before'] == J['observer_after']
assert J['observer_before']['source_commit'] == COMMIT

def observer_from_archive(root, scope='cold'):
    root = Path(root).resolve(strict=True)
    names = set(J['observer_before']['inputs']) if scope == 'full' else {
        'scripts/p8_cold_build.py', 'scripts/p8_rollback.py',
        'scripts/resource_harness/__init__.py', 'scripts/resource_harness/runtime.py'}
    assert scope in ('cold', 'rollback', 'full')
    inputs = {}
    for name in sorted(names):
        path = root / name
        assert path.resolve(strict=True) == path and path.is_file() and not path.is_symlink()
        raw = path.read_bytes()
        sha = hashlib.sha256(raw).hexdigest()
        assert sha == R['validation_inputs'][name]
        mode = R['validation_modes'][name]
        assert mode in ('100644', '100755')
        assert bool(path.stat().st_mode & 0o100) == (mode == '100755')
        blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        inputs[name] = dict(sha256=sha, bytes=len(raw), git_blob=blob, git_mode=mode)
        assert inputs[name] == J['observer_before']['inputs'][name]
    result = dict(source_commit=COMMIT, source_root=str(root), scope=scope, inputs=inputs,
                  manifest_sha256=hashlib.sha256(json_bytes(inputs)).hexdigest())
    if scope == 'full':
        assert dict(J['observer_before'], source_root=str(root)) == result
    return result

# Validate every imported module byte before adding its directory to sys.path.
observer_from_archive(SOURCE, 'full')
sys.path.insert(0, str(SOURCE / 'scripts'))
import p8_cold_build
for name, module_name in p8_cold_build.FULL_OBSERVER_MODULES.items():
    module = importlib.import_module(module_name)
    assert Path(module.__file__).resolve(strict=True) == SOURCE / name

def source_snapshot(_root):
    """Canonical-R comparison, explicitly not Git/lstat source_snapshot execution."""
    assert digest(R_PATH) == R_SHA
    assert json.loads((HOME / 'source-inputs.json').read_text()) == R['complete_inputs']
    assert json.loads((HOME / 'full-recovery.json').read_text())['source'] == CURRENT
    observer_from_archive(SOURCE, 'full')
    return CURRENT

def artifact(aid, run_id=37901931021):
    top = RAW / str(aid)
    meta = json.loads((top / 'github-metadata.json').read_text())
    transport = json.loads((top / 'attempt01/transport-receipt.json').read_text())
    assert meta['id'] == aid and meta['workflow_run']['id'] == run_id
    assert meta['workflow_run']['head_sha'] == COMMIT
    assert transport['artifact_id'] == aid and transport['run_attempt'] == 1
    assert transport['source'] == COMMIT and transport['status'] == 'transport_verified'
    archive = Path(transport['original_zip_path'])
    assert archive.stat().st_size == meta['size_in_bytes'] == transport['zip_bytes']
    assert 'sha256:' + digest(archive) == meta['digest'] == 'sha256:' + transport['zip_sha256']
    extracted = top / 'attempt01/extracted'
    assert not any(x.is_symlink() for x in extracted.rglob('*'))
    return extracted, meta

