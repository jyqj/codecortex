"""Read retained evidence and emit a pending ledger input; never edits tasks or runs tests."""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = Path(__file__).resolve().parent
BASE = ROOT / 'P8-005-closeout-preparation/baseline-main23eab'
TEMPLATE_ROOT = ROOT / 'round28-supported-template-recovery'
TASK_PATH = 'docs/roadmap/code-index-v2/tasks.json'
G8 = '4fe927488d5cb7f26bd27c7624745fb1b6ca202b'
GW4 = '008f1ec0ae16b9b6aff9f20d033b17b2219168f8'

def read(p):
    return json.loads(p.read_text())

def dump(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def info(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()}

def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

data = read(BASE / TASK_PATH)
tasks = {t['id']: t for t in data['tasks']}
eight = read(TEMPLATE_ROOT / 'eight-task-pending-closeout-fields.json')
ten = read(TEMPLATE_ROOT / 'ten-task-dependent-update-input.json')
index = read(OUT / 'restored-reused-accepted-evidence-index.json')
original006 = read(OUT / 'restored-P8-006-pending-fields.json')
wide = read(ROOT / 'GW4-next-original-intake/sealed-50k-evidence/summary.json')
assert eight['apply_now'] is False and ten['apply_now'] is False
assert [r['task_id'] for r in eight['rows']] == ['P8-007', 'P8-008', 'P8-009', 'P8-010', 'P8-011', 'P8-012', 'P8-013', 'P8-016']
member_index = read(ROOT / 'round27-old-closeout-template-recovery/round22-member-index.original.json')
restoration = []
for filename in ['P8-006-pending-fields.json', 'reused-accepted-evidence-index.json']:
    path = OUT / ('restored-' + filename)
    matching = [row for row in member_index['members'] if (row.get('member') or row.get('name') or row.get('path', '')).endswith('/' + filename)]
    assert len(matching) == 1, matching
    m = matching[0]
    assert info(path)['sha256'] == m['sha256']
    restoration.append({'restored': info(path), 'original_member_manifest': m})
dump('additional-two-retained-member-restoration.json', {'scope': 'Only two exact small members from already-held original Round22 ZIP; no source, workload or validator execution.', 'members': restoration})

documents = {}
for file in ['02-CONTRACTS.md', '09-BENCHMARK.md', 'P8-SCALE.md']:
    p = OUT / 'original' / file
    response = read(OUT / 'original' / (file + '.official-response.json'))['structuredContent']
    assert info(p)['git_blob'] == response['sha']
    documents[file] = info(p) | {'source': G8, 'repository_path': 'docs/roadmap/code-index-v2/' + file}
driver = ROOT / 'GW4-original-build-intake/source-exact-GW4/scripts/p8_scale_matrix.py'
docs = {
    'task006': {'source': '51138c236cf2ed47858e2306f9c7bfd3600aaef9', 'original_blob': '959a25ba851ff88f286bab0fa14167878129b1dd', 'selector': 'tasks[id=P8-006]', 'steps': tasks['P8-006']['steps'], 'acceptance': tasks['P8-006']['acceptance'], 'dependencies': tasks['P8-006']['depends_on'], 'validations': tasks['P8-006']['validations'], 'root_base_bridge': 'Root official PR196 merge changed no ledger or these definition files; exact original task bytes retained locally.'},
    'C05': {'file': '02-CONTRACTS.md', 'lines': [41,47], 'requirement': 'Complete conservative dirty closure or persistent incomplete frontier and resumable basis; no fixed200/4096 numerical budget.'},
    'C15': {'file': '02-CONTRACTS.md', 'lines': [120,122], 'requirement': 'Per-phase touched/parsed/resolved/written/reconciled plus cache/FTS/SQL/candidate/budget/vector accounting.'},
    'V07_V20': {'file': 'docs/roadmap/code-index-v2/06-VALIDATION.md', 'lines': [29,42], 'git_blob': 'fcbcf9e9280d41a4e8e138543d2bd217137a2c5e', 'requirement': 'Dirty mutation/fanout/cache-history fixed-point full parity and1k–100k cold/no-op/body/API/config/batch resource scopes; no default200 clause.'},
    'D4_and_sampling': {'file': '09-BENCHMARK.md', 'lines': [154,173], 'requirement': 'Five synthetic capacities plus real-repo broad suite; query-profile N/tail guidance, cold definitions and no best-of. Not a literal task006 immutable200 configuration.'},
    'registered_default_capacity': {'file': 'P8-SCALE.md', 'lines': [212,226,260,281], 'requirement': 'For named scale_capacity_v1:200/1024 main,8/128 fanout,5 capacities×9 stages×N30 plus5fanouts×N30=1500,150shards,all original source/binary/driver and5h/512MiB limits. Missing/failure cannot pass or be retrospectively reduced.'},
    'registered_wide_capacity': {'source': GW4, 'file': 'scripts/p8_scale_matrix.py', 'source_identity': info(driver), 'lines': [47,64,344,364,873,936], 'requirement': 'Separate scale_wide_dirty_v1 changesmain dirty4096 only; inheritsresume1024 andphysicaloracle scale_capacity_v1,fanout8/128,fullstage/capacity/N population. combine rejects profile mismatch, missing slots, mixedsource/binary/commonconfiguration.'}
}
studies = [
    {'study_key': 'G8_default200', 'source': G8, 'run_id': 37962416564, 'run_attempt': 1, 'capacity_profile': 'scale_capacity_v1', 'main_dirty_resume': [200,1024], 'fanout_dirty_resume': [8,128], 'registered_shards': 150, 'registered_measurements': 1500, 'global_repetitions_per_group': 30, 'source_specific_final_aggregate_acceptance': None, 'source_specific_complete_custody': None, 'status': 'incomplete_as_of_retained_records; current remote terminal not polled by this preparation'},
    {'study_key': 'GW4_wide4096', 'source': GW4, 'run_id': 37982220020, 'run_attempt': 1, 'capacity_profile': 'scale_wide_dirty_v1', 'oracle_physical_profile': 'scale_capacity_v1', 'main_dirty_resume': [4096,1024], 'fanout_dirty_resume': [8,128], 'registered_shards': 150, 'registered_measurements': 1500, 'global_repetitions_per_group': 30, 'last_retained_receipt': info(ROOT / 'GW4-next-original-intake/sealed-50k-evidence/summary.json'), 'last_receipt_accepted_shards': 4, 'last_receipt_accepted_measurements': 41, 'last_receipt_time_utc': wide['receipt']['finished_utc'], 'status': 'incomplete_as_of_this_retained_receipt; not a fresh remote observation', 'source_specific_final_aggregate_acceptance': None, 'source_specific_complete_custody': None}
]
for study in studies:
    study['source_compatibility_disposition'] = None
    study['may_mix_with_other_study'] = False
    study['may_inherit_repaired_main_execution'] = False
    study['planned_population_may_be_reduced_after_start'] = False
report = {
    'schema': 'original-task006-and-dependent-eight-pending-scope-v1',
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'apply_now': False, 'task_or_ref_modified': False, 'new_workload_test_or_validation_executed': False,
    'decision': {
        'default200_is_original_task_universal_hard_requirement': False,
        'wide4096_is_categorically_ineligible_for_any_task006_evidence': False,
        'reason': 'No such prohibition appears in the checked original task006,C05/C15,V07/V20 or09.200 is a specific registered protocol value. A complete independently registeredwide run can support its explicitly declared configuration; it cannot certify productiondefault200 or replace/mix/relabel an incomplete200study.',
        'task006_may_close_now': False,
        'why_not_now': ['Neither selected study has complete accepted150shard/1500sample evidence in these retained inputs.', 'The actual sample source has an inherited oracle compatibility finding. Subsequent repairedmain execution cannot silently erase that finding or relabel the old measurements.', 'P8-005 remote closeout publication must be checked at application time; local164/28 candidate is not a remote task update.'],
        'future_acceptance_boundary': 'After an actually complete selected registered study and applicable original regression/oracle correctness review, close only the accurately declared task scope. Choosing completewide evidence does not turn default200 or another run into passed; retain separate failures/incomplete status and all original raw. This preparation does not adjudicate the outstandingoracle finding.',
        'external_PR194_default200_opinion': {'exact_comment_or_requirement': None, 'proof_of_original_task_requirement': None, 'treatment': 'No exact externalcomment is supplied in this preparation. Treat a reviewer opinion separately; do not invent or promote it into immutable task text.'}
    },
    'original_sources': documents, 'requirements_and_protocol_distinction': docs,
    'registered_studies': studies,
    'oracle_compatibility_hold': {
        'original_finding': info(ROOT / 'round27-oracle-dual-spool-compatibility-candidate/admission-HOLD.json'),
        'original_finding_source': '411336a666df78cfc96172b889f9109c3e84c295',
        'known_wide_sample_source_record': wide['limits'][2],
        'scope': 'SkippingBscratch and additionalpublicreportfield compatibility, not a newly invented statistical/workload gate. Thecold044 double-spool population is separate.',
        'final_adjudication': None
    },
    'restored_template_identities': {name: info(TEMPLATE_ROOT / name) for name in ['eight-task-pending-closeout-fields.json','ten-task-dependent-update-input.json']},
    'own_component_reuse': 'Eight tasks retain their already accepted originalsource/run component dossiers. No blanketlatesthead rerun is added. Preserve scope limitations, null/unavailable and source-separated distributions.',
    'dependent_rows': [{'task_id': r['task_id'], 'accepted_own_scope': r['accepted_summary'], 'hard_dependencies': r['hard_dependencies'], 'remaining_known_own_scope_blockers_in_retained_review': r['remaining_known_own_scope_blockers'], 'evidence_refs': {k: index['records'][k] for k in r['evidence_index_keys']}, 'limitations': r['limitations_to_preserve']} for r in eight['rows']],
    'source_read_limitations': ['Initial guessedCONTRACTS.md path returnederror; originaltask identified02-CONTRACTS.md and that exact source was then retrieved andGit-verified.', 'No freshPR194comments/currentstudyjobs queried; unknownlatestremote state remainsunknown.', 'Old sources/CI/cold population were not rerun and noholdout bodies were read.']
}
dump('006-and-eight-remaining-gates-review.json', report)

ordered = ['P8-006'] + [r['task_id'] for r in eight['rows']]
updates = []
for i, task_id in enumerate(ordered):
    t = tasks[task_id]
    preserved = {k:v for k,v in t.items() if k not in {'status','evidence','implementation_notes'}}
    row = next((r for r in eight['rows'] if r['task_id'] == task_id), None)
    if row:
        assert t['steps'] == row['original_steps'] and t['acceptance'] == row['original_acceptance'] and t['depends_on'] == row['hard_dependencies']
        evidence_template = copy.deepcopy(row['pending_closure']['append_evidence'])
        evidence_template['source_and_run_refs'] = {k: index['records'][k] for k in row['evidence_index_keys']}
        evidence_template['actual_dependency_closeout_locators'] = {dep: None for dep in t['depends_on']}
        own_status = 'previously_accepted_source_scoped_components; no new component execution'
        remaining_own = row['remaining_known_own_scope_blockers']
    else:
        evidence_template = {'date': None, 'status': None, 'selected_source': None, 'selected_profile': None, 'run_id': None, 'run_attempt': None, 'actual_original_aggregate': None, 'complete_custody_locator': None, 'phase_accounting': None, 'full15table_parity_and_incomplete_to_closure': None, 'related_regression_evidence': None, 'source_compatibility_disposition': None, 'registered_population': {'shards':150,'measurements':1500,'repetitions':30}, 'other_study_preserved_separately': True, 'actual_dependency_closeout_locators': {dep:None for dep in t['depends_on']}, 'scope': 'Accurately declared selected configuration only; no default200 claim fromwide4096 and no crosssource pooling.'}
        own_status = 'incomplete_registered_study_and_source_compatibility_disposition_pending'
        remaining_own = ['complete selected frozen150/1500 population and originalaggregate acceptance','resolve source-specific oracle compatibility admission with actual evidence; do not transfer repairedsource execution','related original regression evidence at its actual source']
    updates.append({
        'task_id': task_id, 'apply_now': False,
        'selector': 'tasks entry selected by exact id, never array offset',
        'expected_current_status': t['status'],
        'expected_immutable_definition_sha256': digest(preserved),
        'definition_hash_encoding': 'UTF-8 json ensure_ascii=False, sort_keys=True, separators=(comma,colon); all taskfields exceptstatus/evidence/implementation_notes',
        'required_done_ids': t['depends_on'],
        'current_dependency_status_in_observed_main': {dep: tasks[dep]['status'] for dep in t['depends_on']},
        'accepted_own_scope_state': own_status, 'remaining_original_own_scope_actions': remaining_own,
        'conditional_patch': {'append_evidence': evidence_template, 'append_implementation_notes': None, 'set_status_after_actual_acceptance_and_dependencies': 'done'},
        'protected_acceptance_subgates': 'Preserve exact original map if present; currentclosure belongs in appended allowedprogress evidence/notes.',
        'actual_acceptance_review': None, 'actual_application_base': None, 'actual_application_date': None,
        'conditional_counts_if005_done_and_no_other_changes': {'done':165+i,'remaining':27-i}
    })
plan = {
    'schema': 'nine-dependent-task-exact-progress-input-not-applied-v1', 'apply_now':False,
    'observed_main': '51138c236cf2ed47858e2306f9c7bfd3600aaef9',
    'observed_tasks': info(BASE/TASK_PATH),
    'actual_005_publication':None, 'current_remote_counts_not_advanced_by_this_plan': {'done':163,'remaining':29},
    '005_local_candidate_only': {'done':164,'remaining':28,'manifest':str(ROOT/'P8-005-closeout-preparation/candidate-validation-attempt02-final/candidate-five-leaf-manifest.final.json')},
    'ordered_original_ids':ordered, 'updates':updates,
    'permitted_task_fields':['status','evidence','implementation_notes'],
    'forbidden_changes':['taskIDs/definitions/dependencies/acceptance/acceptance_subgates','any existing evidence or implementation_note bytes','registeredsource/binary/seed/profile/N/population/budget','newmeasurement claims from compatibilityrepair source'],
    'actual_apply_procedure':['Read freshmain and exacttasks; retain all externalnotes and existing191other tasks for each individualupdate.','Verify each immutabledefinition hash and originalharddependencies actuallydone; do not use prospectivecounts as proof.','Fill only actualaccepted nonnull evidence/review/locators, preserve originalsource identities and failed/incomplete otherstudies.','Append progressfields and set eligible taskstatus, then update originalnavigation to the next actualeligible incomplete task.','Run unchanged code_index_plan.py --write then noargs; retain actualoutputs/exit and fullbaseline-to-candidate diff.'],
    'original_commands':[['python3','scripts/code_index_plan.py','--write'],['python3','scripts/code_index_plan.py']],
    'derived_views':ten['original_view_files'],
    'evidence_locator_format': 'Immutable https://github.com/jyqj/codecortex/blob/<fullcommit>/<path> or tree/<fullcommit>/<directory>, optionally exactZIPmember/hash. Originalgenerator does not requirecopying olderlarge rawZIPs into finalPR; preserve realpublishedcustody and actualsame-source acceptance.',
    'source_component_index': index['records'],
    'root_decision_required_at_application': 'Actualacceptance and safeledgerintegration; thisfile is never an executableautomaticclose-all command.',
    'tests_workloads_or_aggregate_executed':False,'tasks_or_refs_modified':False
}
dump('nine-task-dependent-update-input.apply-now-false.json',plan)
rows = ['| 原任务 | 自身范围 | 当前真正剩余项 | 硬依赖 |', '|---|---|---|---|']
rows.append('| P8-006 | no-op/body/API/config/batch、阶段计数、超预算闭包与完整parity | 选定固定study完整150/1500与原aggregate；原source兼容性HOLD最终处置；相关回归证据 | P7-020、P8-001、P8-005 |')
for row in eight['rows']:
    rows.append('| '+row['task_id']+' | '+row['accepted_summary'].replace('|','/')+' | 已有自身组件接受；等原硬依赖，不新增测量 | '+', '.join(row['hard_dependencies'])+' |')
(OUT/'remaining-original-gates.md').write_text('仅待应用准备，apply_now=false；不改账本或注册研究。005本地候选164done/28remaining，不冒称远端已发表。\n\n原任务没有固定default200或wide永不可作006证据的条款；200是既定scale_capacity_v1协议参数，wide4096是独立声明配置。两个study各自150/1500、N30、固定source/binary/driver/seed与预算不变，不替代、不混池。现有样本和后续修复源码的执行身份分开，oracle兼容性HOLD不能自动由新main消除。\n\n'+'\n'.join(rows)+'\n')
selection = []
for p in sorted(OUT.rglob('*')):
    if p.is_file() and p.name != 'archive-selection.json':
        selection.append(info(p) | {'relative_path':p.relative_to(OUT).as_posix()})
dump('archive-selection.json', {'schema':'round28-pending-dependent-nine-selected-evidence','apply_now':False,'files':selection,'task_status_modified':False,'remote_mutations':False})
print(json.dumps({'status':'prepared_not_applied','apply_now':False,'updates':len(updates),'files':len(selection),'review':info(OUT/'006-and-eight-remaining-gates-review.json'),'template':info(OUT/'nine-task-dependent-update-input.apply-now-false.json'),'selection':info(OUT/'archive-selection.json')},ensure_ascii=False))
