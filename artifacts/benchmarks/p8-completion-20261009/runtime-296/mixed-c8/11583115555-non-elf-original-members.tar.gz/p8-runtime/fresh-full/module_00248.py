def stable_00248():
    return 248
