#!/usr/bin/env python3
"""Verify original Git blobs from the complete official patch; no product execution."""
import hashlib
import json
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parent
compare_raw = Path('/dev/shm/root-round17/H-to-b2-official-compare.json').read_bytes()
compare = json.loads(compare_raw)
files = {x['filename']: x for x in compare['files']}
def oid(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
def apply(raw, patch, reverse=False):
    src = raw.decode().splitlines(keepends=True)
    lines = patch.splitlines()
    out, cursor, at = [], 0, 0
    while at < len(lines):
        h = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*', lines[at])
        assert h, lines[at]
        old_start, old_count, new_start, new_count = int(h[1]), int(h[2] or 1), int(h[3]), int(h[4] or 1)
        start = (new_start if reverse else old_start) - 1
        assert start >= cursor
        out.extend(src[cursor:start]); cursor = start
        at += 1; used = produced = 0
        while at < len(lines) and not lines[at].startswith('@@ '):
            line = lines[at]; at += 1
            assert line and line[0] in ' +-', line
            kind = line[0]
            if reverse:
                kind = {'+': '-', '-': '+', ' ': ' '}[kind]
            text = line[1:]
            if kind != '+':
                assert src[cursor].rstrip('\n') == text, (cursor, src[cursor], text)
                if kind == ' ': out.append(src[cursor])
                cursor += 1; used += 1
            if kind == '+': out.append(text + '\n')
            if kind != '-': produced += 1
        assert used == (new_count if reverse else old_count)
        assert produced == (old_count if reverse else new_count)
    out.extend(src[cursor:])
    return ''.join(out).encode()
inventory = json.loads(Path('/dev/shm/todo-audit-p8007-final-main-integration/actual-P2/actual-P2-complete-product-validation-inputs.json').read_text())['actual_input_mode_blob_inventory']
(ROOT / 'original-H-preimages').mkdir(exist_ok=True)
(ROOT / 'b2-original-bindings').mkdir(exist_ok=True)
receipt = {'scope': 'static byte identity and official unified patch reconstruction only', 'product_or_validation_execution': False, 'preimages': [], 'bindings': []}
for p, name in [('crates/cc-search/src/preselect.rs', 'preselect.rs'), ('crates/cc-eval/tests/p8_scale.rs', 'p8_scale.rs'), ('.github/workflows/p8-db-lock-observation.yml', 'p8-db-lock-observation.yml')]:
    raw = (ROOT / 'source' / name).read_bytes()
    before = apply(raw, files[p]['patch'], reverse=True)
    assert oid(before) == inventory[p]['sha']
    assert apply(before, files[p]['patch']) == raw
    (ROOT / 'original-H-preimages' / name).write_bytes(before)
    receipt['preimages'].append({'path': p, 'before_git_blob': oid(before), 'before_sha256': hashlib.sha256(before).hexdigest(), 'after_git_blob': oid(raw), 'after_sha256': hashlib.sha256(raw).hexdigest(), 'forward_and_reverse_byte_exact': True})
for name in ['verify_reviewed_source_v15.py', 'reviewed-source-registry-v15.json']:
    p = 'scripts/' + name
    before = Path('/dev/shm/todo-audit-G2-cd68-binding/generated/scripts', name).read_bytes()
    after = apply(before, files[p]['patch'])
    assert oid(after) == files[p]['sha']
    assert apply(after, files[p]['patch'], reverse=True) == before
    (ROOT / 'b2-original-bindings' / name).write_bytes(after)
    receipt['bindings'].append({'path': p, 'git_blob': oid(after), 'sha256': hashlib.sha256(after).hexdigest(), 'bytes': len(after)})
before_guard = Path('/dev/shm/todo-audit-G2-cd68-binding/generated/scripts/verify_reviewed_source_v15.py').read_text()
after_guard = (ROOT / 'b2-original-bindings/verify_reviewed_source_v15.py').read_text()
canonical = lambda text: re.sub(r'^(PRODUCT|REVIEW|REVIEW_PATH|REGISTRY_SHA256) = .*$', r'\1 = <binding>', text, flags=re.M)
assert canonical(before_guard) == canonical(after_guard)
registry = json.loads((ROOT / 'b2-original-bindings/reviewed-source-registry-v15.json').read_text())
maps = json.loads((ROOT / 'prospective-complete-product-validation-inputs.json').read_text())
sql = ['crates/cc-db/src/resolution_dependency_store.rs', 'crates/cc-db/tests/p2b_resolution_store.rs']
assert registry['validation_inputs'] == maps['validation_inputs']
assert sorted(k for k in maps['complete_inputs'] if maps['complete_inputs'][k] != registry['complete_inputs'][k]) == sql
assert registry['delta'].keys() == maps['paths'].keys()
assert all(registry['delta'][p]['before_sha256'] == maps['paths'][p]['before_sha256'] for p in maps['paths'])
assert sorted(p for p in maps['paths'] if maps['paths'][p] != registry['delta'][p]) == sql
receipt.update({'b2_guard_exact_original_algorithm_except_four_pins': True, 'b2_registry_vs_prospective_complete_changes': sql, 'b2_registry_all142_validation_exact_prospective': True, 'b2_delta71_before_hashes_all_equal': True})
(ROOT / 'official-H-to-b2-compare.json').write_bytes(compare_raw)
(ROOT / 'original-ci.yml').write_bytes(Path('/dev/shm/todo-audit-P3-H-d22-candidate-plan/original-ci.yml').read_bytes())
(ROOT / 'bounded-patch-byte-proof.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
print(json.dumps(receipt, sort_keys=True))
