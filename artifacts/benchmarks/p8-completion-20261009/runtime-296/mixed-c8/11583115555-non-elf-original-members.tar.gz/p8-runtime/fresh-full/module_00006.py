def stable_00006():
    return 6
