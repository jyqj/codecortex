def stable_00472():
    return 472
