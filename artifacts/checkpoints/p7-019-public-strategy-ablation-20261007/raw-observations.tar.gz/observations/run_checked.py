import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/scratch/71bc431c4e4f/codecortex-p7-019')
out=Path(__file__).resolve().parent
name=sys.argv[1]
command=sys.argv[2:]
if not command or (out/(name+'.json')).exists(): raise SystemExit('new command/name required')
def inputs():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--','Cargo.toml','Cargo.lock','crates'],cwd=root).decode().splitlines()
 return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(set(names)) if (root/n).is_file()}
before=inputs()
(out/(name+'-source-sha256.json')).write_text(json.dumps(before,indent=2)+'\n')
env=os.environ.copy()
env.update(CARGO_TARGET_DIR='/workspace/scratch/71bc431c4e4f/target-validation-cost',CARGO_BUILD_BUILD_DIR='/workspace/scratch/71bc431c4e4f/target-validation-cost',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0')
executor_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
product_path=env.get('CODECORTEX_BENCH_BINARY')
product_before=hashlib.sha256(Path(product_path).read_bytes()).hexdigest() if product_path else None
source_commit_before=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
if source_commit_before != '93356fc87e9534c286192bde1fc88aa95abe878b' or hashlib.sha256((out/(name+'-source-sha256.json')).read_bytes()).hexdigest() != 'ef5a880e8633c605cd52ae50fc2b4dd7193a761602da98ac7f97c5dcdff43187': raise SystemExit('canonical source changed; command not run')
start=time.time()
with (out/(name+'.log')).open('wb') as log:
 p=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
after=inputs()
result={'executor_script_sha256':executor_script_sha256,'executor_script_unchanged':executor_script_sha256==hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'product_binary_before':product_before,'product_binary_after':hashlib.sha256(Path(product_path).read_bytes()).hexdigest() if product_path else None,'command':command,'cwd':str(root),'source_commit_before':source_commit_before,'source_parent':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_inputs':len(before),'source_manifest':name+'-source-sha256.json','source_manifest_sha256':hashlib.sha256((out/(name+'-source-sha256.json')).read_bytes()).hexdigest(),'source_inputs_unchanged':before==after,'environment':{k:env.get(k) for k in ['CARGO_TARGET_DIR','CARGO_BUILD_BUILD_DIR','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','CARGO_INCREMENTAL','RUSTUP_HOME','CARGO_HOME','RUSTFLAGS','SDKROOT','CODECORTEX_BENCH_BINARY','P7_STRATEGY_BINARY_SHA256','P7_STRATEGY_SOURCE_SNAPSHOT','P7_STRATEGY_BUILD_RECEIPT','P7_STRATEGY_EVIDENCE_DIR']},'exit_code':p.returncode,'elapsed_seconds':round(time.time()-start,3),'log':name+'.log','log_sha256':hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest()}
(out/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
print((out/(name+'.log')).read_text(errors='replace')[-6500:],flush=True)
raise SystemExit(p.returncode)
