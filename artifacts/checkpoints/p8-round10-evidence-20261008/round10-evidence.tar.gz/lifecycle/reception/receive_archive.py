#!/usr/bin/env python3
"""Receive one immutable G4 archive into an exclusively new directory."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import shutil
import stat
import zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = '260f596582f2d82b8d7c707b61a6b8b6a43b069f'
RUN, JOB, ARTIFACT = 37854847926, 113576451817, 11585181176
ZIP_BYTES = 49348679
ZIP_SHA = '81756f7d1990147961c87f905625c33da69b57d703f8eb4afa7e0f690ca52c31'
MEMBERS, EXPANDED_BYTES = 2391, 372943883

def require(ok, reason):
    if not ok:
        raise ValueError(reason)

def sha_file(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def main():
    for parent in (ROOT, *ROOT.parents):
        require(not parent.is_symlink(), 'aliased receiver parent')
    archive, output = ROOT / 'original-artifact.zip', ROOT / 'files'
    require(archive.is_file() and not archive.is_symlink()
            and archive.stat().st_size == ZIP_BYTES and sha_file(archive) == ZIP_SHA, 'original ZIP identity')
    require(not output.exists() and not output.is_symlink(), 'new extraction directory required')
    run, jobs, artifacts = [json.loads((ROOT / name).read_text())
                            for name in ('run.json', 'jobs.json', 'artifacts.json')]
    require(run['id'] == RUN and run['head_sha'] == SOURCE and run['run_attempt'] == 1
            and run['status'] == 'completed' and run['conclusion'] == 'success', 'first original run')
    require(jobs['total_count'] == len(jobs['jobs']) == 1 and jobs['jobs'][0]['id'] == JOB
            and jobs['jobs'][0]['run_id'] == RUN and jobs['jobs'][0]['conclusion'] == 'success', 'original job')
    require(artifacts['total_count'] == len(artifacts['artifacts']) == 1, 'all artifact metadata')
    artifact = artifacts['artifacts'][0]
    require(artifact['id'] == ARTIFACT and artifact['size_in_bytes'] == ZIP_BYTES
            and artifact['digest'] == 'sha256:' + ZIP_SHA and artifact['expired'] is False
            and artifact['name'] == 'p8-lifecycle-' + SOURCE
            and artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == SOURCE,
            'bound GitHub artifact metadata')
    require(shutil.disk_usage(ROOT).free >= EXPANDED_BYTES + 512 * 1024 * 1024,
            'retain 512 MiB actual free headroom after new extraction')
    inventory = {}
    with zipfile.ZipFile(archive) as z:
        require(len(z.infolist()) == MEMBERS and sum(i.file_size for i in z.infolist()) == EXPANDED_BYTES,
                'observed original archive population')
        for item in z.infolist():
            name, path = item.filename, PurePosixPath(item.filename)
            require(name and not item.is_dir() and not path.is_absolute() and '..' not in path.parts
                    and '\\' not in name and '\0' not in name and path.as_posix() == name
                    and name not in inventory and not (item.flag_bits & 1), 'unsafe archive member')
            require(stat.S_IFMT(item.external_attr >> 16) in (0, stat.S_IFREG), 'nonregular ZIP member')
            with z.open(item) as stream:
                digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            inventory[name] = dict(bytes=item.file_size, sha256=digest, crc32=f'{item.CRC:08x}')
        # Whole-archive CRC/SHA reception precedes any expansion. No deletion or
        # reuse of an old directory is supported, even if expansion fails.
        output.mkdir()
        for name, expected in inventory.items():
            destination = output / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            for parent in destination.parents:
                require(not parent.is_symlink(), 'aliased extraction path')
            with z.open(name) as source, destination.open('xb') as target:
                shutil.copyfileobj(source, target, 1024 * 1024)
            require(destination.stat().st_size == expected['bytes']
                    and sha_file(destination) == expected['sha256'], 'expanded byte copy')
    actual = {p.relative_to(output).as_posix() for p in output.rglob('*') if p.is_file()}
    require(actual == set(inventory), 'complete exclusive expanded inventory')
    expected = dict(source=SOURCE, run_id=RUN, run_attempt=1, job_id=JOB, artifact_id=ARTIFACT,
                    bytes=ZIP_BYTES, sha256=ZIP_SHA, members=MEMBERS, expanded_bytes=EXPANDED_BYTES,
                    scope='transport only; no lifecycle or TODO acceptance',
                    metadata_sha256={name: sha_file(ROOT / name) for name in ('run.json', 'jobs.json', 'artifacts.json')})
    for name, value in [('member-hashes.json', inventory), ('expected-artifact.json', expected)]:
        with (ROOT / name).open('x') as stream:
            json.dump(value, stream, sort_keys=True, indent=2)
            stream.write('\n')
    print(json.dumps(dict(transport_verified=True, members=MEMBERS, expanded_bytes=EXPANDED_BYTES,
                          zip_sha256=ZIP_SHA, expected_receipt_sha256=sha_file(ROOT / 'expected-artifact.json'),
                          TODO_closed=0)))

if __name__ == '__main__':
    main()
