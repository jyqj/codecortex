#!/usr/bin/env python3
"""Copy the compiler-selected original P7-017 runner and retain its identity."""
import json
from pathlib import Path
import shutil
import sys

ROOT = Path('/workspace/scratch/71bc431c4e4f/codecortex-p7-tooling')
OUT = Path(__file__).resolve().parent
SOURCE = 'a213a4cfab0e0e87198bc279acacda51e4ff62cf'
MAP = '487c8d0ec38378c8974725c43fd3f30946ba5bf4ed335aec947990df1125a9fe'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
from p7_build_identity import file_sha256, json_bytes, source_snapshot


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ('default', 'semantic'):
        raise SystemExit('expected default or semantic')
    package = sys.argv[1]
    name = package + '-test-runner-build'
    result_path = OUT / (name + '.json')
    log_path = OUT / (name + '.log')
    target = OUT / (package + '-product/cargo-target')
    copied = OUT / (package + '-benchmark-adapters')
    record_path = OUT / (package + '-test-runner.json')
    if copied.exists() or record_path.exists():
        raise SystemExit('runner copy/record already exists; refusing overwrite')
    result = json.loads(result_path.read_bytes())
    # The original runner commands enable Cargo's empty `default` feature;
    # only the default-product runner additionally enables eval-http.
    expected_features = ['default', 'eval-http'] if package == 'default' else ['default']
    for key in ('source_before', 'source_after'):
        actual = result[key]
        if (actual['source_commit'] != SOURCE or actual['input_count'] != 768
                or actual['manifest_sha256'] != MAP):
            raise SystemExit('build source identity does not match the fixed source')
    if result['exit_code'] != 0 or not result['source_unchanged']:
        raise SystemExit('runner build did not complete with unchanged source')
    if file_sha256(log_path) != result['log_sha256']:
        raise SystemExit('actual runner build log changed')
    for key in ('CARGO_TARGET_DIR', 'CARGO_BUILD_BUILD_DIR'):
        if result['environment'][key] != str(target):
            raise SystemExit('runner build did not use the owned private build directory')
    before = source_snapshot(ROOT)
    if before['source_commit'] != SOURCE or before['manifest_sha256'] != MAP:
        raise SystemExit('current source changed before runner capture')
    messages = []
    for line in log_path.read_text().splitlines():
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            messages.append(value)
    if not any(m.get('reason') == 'build-finished' and m.get('success') is True
               for m in messages):
        raise SystemExit('Cargo did not emit a successful build-finished message')
    selected = [m for m in messages if m.get('reason') == 'compiler-artifact'
                and m.get('target', {}).get('name') == 'benchmark_adapters'
                and m.get('target', {}).get('kind') == ['test']
                and m.get('executable')]
    if len(selected) != 1:
        raise SystemExit('exactly one original benchmark_adapters compiler artifact is required')
    artifact = selected[0]
    if artifact['manifest_path'] != str(ROOT / 'crates/cc-eval/Cargo.toml'):
        raise SystemExit('the test artifact is from a different checkout')
    if sorted(artifact['features']) != expected_features or artifact['fresh'] is not False:
        raise SystemExit('unexpected test-runner features or reused test artifact')
    executable = Path(artifact['executable'])
    if executable.is_symlink() or not executable.is_file():
        raise SystemExit('compiler-selected runner is not a regular file')
    if not executable.resolve().is_relative_to(target.resolve()):
        raise SystemExit('compiler-selected runner escaped the private target')
    original_sha = file_sha256(executable)
    shutil.copy2(executable, copied)
    if file_sha256(copied) != original_sha or file_sha256(executable) != original_sha:
        raise SystemExit('runner changed during copy')
    after = source_snapshot(ROOT)
    if before != after:
        raise SystemExit('source changed during runner capture')
    record = {
        'schema_version': 1,
        'package_kind': package,
        'source': {k: v for k, v in before.items() if k != 'inputs'},
        'source_unchanged_during_capture': True,
        'original_test_path': 'crates/cc-eval/tests/benchmark_adapters.rs',
        'original_test_sha256': file_sha256(ROOT / 'crates/cc-eval/tests/benchmark_adapters.rs'),
        'runner_build_record': result_path.name,
        'runner_build_record_sha256': file_sha256(result_path),
        'raw_cargo_log': log_path.name,
        'raw_cargo_log_sha256': file_sha256(log_path),
        'cargo_artifact': artifact,
        'compiler_selected_executable': str(executable),
        'copied_executable': str(copied),
        'executable_sha256': original_sha,
        'executable_bytes': copied.stat().st_size,
        'capture_script_sha256': file_sha256(__file__),
        'identity_helper_sha256': file_sha256(ROOT / 'scripts/p7_build_identity.py'),
        'scope': 'Compiler-selected original test runner copied byte-for-byte from the owned private target. This capture does not execute the gate.',
    }
    record_path.write_bytes(json_bytes(record))
    print(json.dumps({k: record[k] for k in ('package_kind', 'source', 'copied_executable', 'executable_sha256', 'executable_bytes')}, indent=2))


if __name__ == '__main__':
    main()
