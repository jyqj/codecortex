import json, hashlib, pathlib, datetime

ROOT = pathlib.Path('/workspace/scratch/bfccb8494ba0')
OUT = pathlib.Path(__file__).parent
inputs = {}
def read(rel):
    p = ROOT / rel
    raw = p.read_bytes()
    inputs[rel] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'git_blob': hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()}
    return json.loads(raw)
def digest(x):
    return hashlib.sha256(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
checks = []
def check(name, value):
    assert value, name
    checks.append(name)

p = read('round46-twelve-task-application-preparation/twelve-task-two-stage-application.applyfalse.json')
b = read('round46-twelve-task-application-preparation/original-192-task-preservation-baseline.json')
ledger = read('round44-nine-application-main-0da9-view/docs/roadmap/code-index-v2/tasks.json')
nine = read('round43-final-nine-application/nine-task-application.bound-G2.applyfalse.json')
seven = read('round45-P8-007-original-step-review/independent-P8-007-original-step-review.json')
eleven = read('round45-original-step-scope-review/independent-original-fault-step-and-main-scope-review.json')
post = read('round45-post-nine-independent-peer/independent-017-019-conditional-scope-review.json')
tasks = ledger['tasks']; byid = {t['id']: t for t in tasks}
ids = ['P8-'+s for s in ['006','007','008','009','010','011','012','013','016','017','018','019']]
allowed = ['status','evidence','implementation_notes']
immutable = {t['id']: {k:v for k,v in t.items() if k not in allowed} for t in tasks}
check('192 unique IDs and original order',len(tasks)==len(byid)==192 and b['original_task_order']==[t['id'] for t in tasks])
check('all 192 complete immutable definitions and dependencies',b['all192_immutable_definition_sha256']=={k:digest(v) for k,v in immutable.items()})
check('other 180 entire original records',b['other180_entire_record_sha256']=={t['id']:digest(t) for t in tasks if t['id'] not in ids} and len(b['other180_entire_record_sha256'])==180)
check('target 12 full original definitions',b['target12_original_definition_and_harddeps']=={k:immutable[k] for k in ids})
check('only original three progress fields permitted',p['permitted_task_fields']==b['allowed_task_progress_fields']==allowed)
check('frozen ledger exact identity',inputs['round44-nine-application-main-0da9-view/docs/roadmap/code-index-v2/tasks.json']['git_blob']==b['tasks_git']=='adb44ee70a4c129bfb443d4ecf678fb934c8ea6b')
check('ordered 12 updates',p['ordered_original_ids']==[u['task_id'] for u in p['updates']]==ids)
check('original historical component index retained',p['source_component_index_history_retained']==nine['source_component_index'])
for u in p['updates']:
    t = byid[u['task_id']]
    check(u['task_id']+' original definition/hash/harddeps',u['expected_immutable_definition_sha256']==digest(immutable[t['id']]) and u['required_done_ids']==t['depends_on'])
    check(u['task_id']+' original scope/steps/acceptance',all(t[k]==v for k,v in p['original_scope_and_harddeps'][t['id']].items()))
    check(u['task_id']+' future decision/date/base null',u['apply_now'] is False and all(u[k] is None for k in ['actual_acceptance_review','actual_application_base','actual_application_date']))
    expected_protection = ('Preserve exact original map if present; currentclosure belongs in appended allowedprogress evidence/notes.' if u['task_id'] in ids[:9] else t.get('acceptance_subgates'))
    check(u['task_id']+' protected acceptance subgates directive',u['protected_acceptance_subgates']==expected_protection and 'acceptance_subgates' not in allowed)
    check(u['task_id']+' conditional patch only',set(u['conditional_patch'])=={'append_evidence','append_implementation_notes','set_status_after_actual_acceptance_and_dependencies'})
for i,c in enumerate(p['ordered_counts'],1):
    check('conditional arithmetic '+str(i),c['done_after_if_applied']==164+i and c['remaining_after_if_applied']==28-i and c['session_completed_after_if_applied']==1+i)
a7=p['source_component_appendices']['P8-007_G275']; a11=p['source_component_appendices']['P8-011_G275']
check('007 mixed four exact selected source values',all(all(row[k]==seven['mixed_four_cells'][i][k] for k in row) for i,row in enumerate(a7['mixed_cells'])))
check('007 independent backfill exact selected values',all(v==seven['backfill'][k] for k,v in a7['backfill'].items()))
check('007 no same-process invention',a7['backfill']['same_process_as_mixed'] is None and a7['backfill']['same_case_artifact_as_mixed'] is False)
check('011 exact crash matrices',a11['additional_same_source_crash_matrices']==eleven['original_crash_matrices'])
check('011 exact active seeds',a11['additional_same_source_active_seeds']==eleven['original_active_seeds'])
check('011 exact named step mapping',a11['original_step_mapping']==eleven['step_mapping'])
check('011 local 3 passed / 4 not_run unchanged',a11['original_local_subreport']['passed']==len(eleven['local_report_unchanged']['passed'])==3 and a11['original_local_subreport']['not_run']==len(eleven['local_report_unchanged']['not_run_in_local_profile'])==4)
for u in p['updates'][-3:]:
    e=u['conditional_patch']['append_evidence']
    check(u['task_id']+' exact current peer reference',e['independent_scope_peer_git']=='1664f89789179c5b690247e3542ef26721cbf408' and e['current_scope_report_git']=='30bc665e25e0e4983c2a91e30b0a3bbb848e8606')
    check(u['task_id']+' dependency not preclosed',set(e['actual_dependency_closeout_locators'])==set(u['required_done_ids']) and all(v is None for v in e['actual_dependency_closeout_locators'].values()))
baseline=p['updates'][-2]['conditional_patch']['append_evidence']['baseline_actual_receipt']
check('018 baseline actual b9 not G2; historical 3 DRIFT retained',baseline['source']=='b9b089bb4eae072affe9326681d4980eae15fd84' and baseline['actual_exit']==0 and baseline['historical_DRIFT_count']==3)
files=['docs/roadmap/code-index-v2/tasks.json','docs/roadmap/code-index-v2/05-TODO.md','README.md','docs/roadmap/code-index-v2/README.md','docs/roadmap/code-index-v2/08-HANDOFF.md']
check('exact original five progress documents',p['updated_files']==files and p['derived_views']==files[1:])
check('P/R/guard/registry fixed',p['source_admission_unchanged']['product_P']=='3481da0baf46bf510580951a4f5fbc9cb2255ae5' and p['source_admission_unchanged']['review_R']=='533e900cf83900f726e92835956137356081861f' and p['source_admission_unchanged']['guard']=='8dddb85f5d09e6fa9543f8ab0cce9ea9e06050d2' and p['source_admission_unchanged']['registry']=='550263e844b8ff2577a7ca0f81a61db401f0e5bb')
slots=p['remaining_actual_evidence_slots']
check('aggregate/45/85/formal decision/application authorization null',all(v is None for k,v in slots.items() if k.startswith('actual_')))
check('no task/source execution or credit',p['apply_now'] is False and p['task_credit']==0 and all(p[k] is False for k in ['task_state_modified','tasks_or_refs_modified','generator_or_checker_run','new_CI_or_workload_run']))
report={
 'schema':'independent-twelve-task-applyfalse-preservation-review-v1',
 'reviewer':'/root/pr_triage','reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'decision':'accepted_as_applyfalse_preparation_only','apply_now':False,'task_credit':0,
 'checks':checks,'check_count':len(checks),'input_identities':inputs,
 'scope_findings':{
  'P8-007':'Exact G275 configured C1/4/8/16 versus observed1/4/7/12 retained. Independent same-source backfill24cells/768requests is not asserted to share mixed process; fake-provider transport is not paid/live evidence.',
  'P8-011':'Original local3passed/4not_run remain literal. Exact same-source12+15 SIGKILL and active223/227/229 supplement kill/network/cache/busy/replacement as the original detailed review mapped. No not_run waiver or physical-power-loss/billing claim.',
  'P8-017_to_019':'Reuses our previously accepted current-source conditional scope peer: single owners/necessary wire; current facts/install/offline; exact archive/no-clobber/replay/latest. Dependencies016→017→018→019 are still unclosed receipts. Historical baseline actualb9 exit0+3DRIFT is not G2 baseline rerun.',
  'preservation':'Recomputed all192 immutable definitions/order/harddeps and other180 full-record canonical hashes against actual frozen ledger; future raw-fragment equality and old evidence/notes remain required at the actual patch. This preparation is not proof of a future diff.',
  'five_docs':'Only original task ledger plus four derived progress views. Existing P/R/G, guard/registry, product and validation domains have no proposed edit. No fresh lease is inferred from observed main0da9.'},
 'remaining_boundaries':['Original full45 cells/85 records, complete raw custody and original Actions aggregate/full log remain required before formal006 decision. Engineering26/26 does not replace these.', 'API receipt was null when this06:44 preparation froze; later accepted API evidence must be appended explicitly. Do not edit historical nulls or mistake preparation for current population.', 'After real evidence, root formal decisions/authorization and a fresh main lease are still necessary; unchanged original generator/checker would run only on an authorized candidate five-doc patch. No generator was run in this review.'],
 'conditional_counts':{'stage_A':{'done':173,'remaining':19,'session_completed':10},'stage_B':{'done':176,'remaining':16,'session_completed':13}},
 'execution_boundary':{'only_existing_json_reader':True,'original_task_generator':False,'tests':False,'study_validator':False,'ZIP_CRC_or_ELF':False,'API_download':False,'task_or_ref_mutation':False},
 'reader_attempt_history':'attempt01 exit1 misread the first-nine protected_acceptance_subgates directive string as the task field value. Original tasks have no such field; immutable definitions already protect all original keys. Corrected reader checks the exact directive (and last-three null values); original preparation was not changed.'
}
(OUT/'independent-twelve-task-preparation-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'passed_read_only_review','checks':len(checks),'apply_now':False,'task_credit':0}))
