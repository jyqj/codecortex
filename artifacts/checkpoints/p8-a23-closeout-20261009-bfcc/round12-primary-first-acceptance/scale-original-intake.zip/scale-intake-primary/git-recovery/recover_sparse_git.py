import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/bfccb8494ba0/candidate-ready-signal-github')
DATA = json.loads((HERE / 'github-data.payload.json').read_text())
EXPECTED = 'c8be5afaac568ffd40ef86d3795423c3b73c9f39'

def git_sha(kind, data):
    return hashlib.sha1(kind.encode() + b' ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def git(*args, data=None):
    p = subprocess.run(['git', *args], cwd=ROOT, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode:
        raise RuntimeError((args, p.returncode, p.stderr.decode('utf-8', 'replace')))
    return p.stdout

def write_new(path, data):
    with path.open('xb') as f:
        f.write(data)

def put_object(kind, data, expected):
    assert git_sha(kind, data) == expected, (kind, expected)
    actual = git('hash-object', '-w', '-t', kind, '--stdin', data=data).decode().strip()
    assert actual == expected
    assert git('cat-file', kind, expected) == data
    write_new(HERE / (expected + '.' + kind + '.raw'), data)
    return {'type': kind, 'oid': expected, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

commit = json.loads(DATA['commit']['content'])
assert commit['sha'] == EXPECTED and commit['verification']['reason'] == 'unsigned'
assert commit['verification']['signature'] is None

# The REST author date normalizes away the original numeric timezone. Recreate
# only candidates whose complete Git commit object hashes to the official OID.
# No candidate is written or made HEAD before that equality is established.
def identity(key, offset):
    item = commit[key]
    epoch = int(datetime.datetime.fromisoformat(item['date'].replace('Z', '+00:00')).timestamp())
    return '{} {} <{}> {} {}\n'.format(key, item['name'], item['email'], epoch, offset)

prefix = 'tree ' + commit['tree']['sha'] + '\n' + ''.join('parent ' + x['sha'] + '\n' for x in commit['parents'])
matched = None
tried = []
for offset in ('+0800', '+0000', '-0700', '-0800'):
    for ending in ('\n', ''):
        raw = (prefix + identity('author', offset) + identity('committer', offset) + '\n' + commit['message'] + ending).encode()
        tried.append({'author_offset': offset, 'committer_offset': offset, 'final_newline': bool(ending), 'oid': git_sha('commit', raw)})
        if git_sha('commit', raw) == EXPECTED:
            matched = (raw, offset, bool(ending))
            break
    if matched:
        break
assert matched is not None, 'Cannot recreate exact official commit; no substitute is permitted'

trees = []
for key in ('root_tree', 'scripts_tree'):
    tree = json.loads(DATA[key]['content'])
    assert tree.get('truncated') is False
    raw = b''.join((x['mode'].lstrip('0') + ' ' + x['path']).encode() + b'\0' + bytes.fromhex(x['sha']) for x in tree['tree'])
    assert git_sha('tree', raw) == tree['sha']
    trees.append((tree, raw))
assert trees[0][0]['sha'] == commit['tree']['sha']
assert next(x for x in trees[0][0]['tree'] if x['path'] == 'scripts')['sha'] == trees[1][0]['sha']

blobs = []
for path, response in DATA['source_files'].items():
    raw = response['content'].encode()
    entry = next(x for x in trees[1][0]['tree'] if x['path'] == Path(path).name)
    assert entry['type'] == 'blob' and entry['mode'] == '100644'
    assert len(raw) == entry['size'] and git_sha('blob', raw) == entry['sha']
    blobs.append((path, entry, raw))

ROOT.mkdir(exist_ok=False)
git('init', '-q')
objects = [put_object('commit', matched[0], EXPECTED)]
objects += [put_object('tree', raw, tree['sha']) for tree, raw in trees]
for path, entry, raw in blobs:
    objects.append(put_object('blob', raw, entry['sha']))
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    write_new(target, raw)
    target.chmod(0o444)
git('update-ref', 'refs/heads/recovered-fixed-G', EXPECTED)
git('symbolic-ref', 'HEAD', 'refs/heads/recovered-fixed-G')
assert git('rev-parse', 'HEAD').decode().strip() == EXPECTED
for path, entry, raw in blobs:
    assert git('show', EXPECTED + ':' + path) == raw
    assert (ROOT / path).read_bytes() == raw

sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
import p8_scale_matrix
snapshot = p8_scale_matrix.driver_snapshot(ROOT)
assert snapshot['source_commit'] == EXPECTED
receipt = {
    'status': 'exact_sparse_driver_git_recovery_passed',
    'root': str(ROOT), 'source_G': EXPECTED, 'tree': commit['tree']['sha'],
    'objects': objects, 'rest_sources': {k: v['url'] for k, v in DATA.items() if k != 'source_files'},
    'recovered_paths': [x[0] for x in blobs],
    'timezone_recovery': {'evidence': 'Complete Git commit object SHA1 equality with official immutable G; REST datetime alone does not retain original offset', 'author_offset': matched[1], 'committer_offset': matched[1], 'final_newline': matched[2], 'attempted_candidates': tried},
    'original_driver_snapshot': snapshot,
    'scope': 'Five exact Git objects and two original driver files only; no full product/validation checkout, no complete source_snapshot, no 1235-input claim, no native build or measurement',
    'unrestored_references': 'Parents, other root children and other scripts blobs remain absent; do not claim complete Git history or a clean full worktree',
    'read_only_source_modes': '0444; later authorized sparse additions must be recorded separately',
    'native_validate_build': 'Not invoked; no new-study build artifact available yet'
}
write_new(HERE / 'recovery-receipt.json', (json.dumps(receipt, indent=2, ensure_ascii=False) + '\n').encode())
print(json.dumps(receipt, ensure_ascii=False))
