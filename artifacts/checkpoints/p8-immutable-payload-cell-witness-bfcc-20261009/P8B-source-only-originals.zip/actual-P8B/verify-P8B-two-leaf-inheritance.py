#!/usr/bin/env python3
"""Verify actual P8B using the already-hashed complete P7B tree/domain."""
from pathlib import Path
import json
import hashlib

HERE=Path(__file__).resolve().parent
P7DIR=Path('/dev/shm/pr-triage-round21-P7B-source-review')
R7=P7DIR/'final-R7B/independent-source-review.json'
SOURCE=Path('/dev/shm/root-round21/oracle-raw-cell-witness-v2/candidate')
P7='8831de11bc8d33735b665efda6c8aa511e4f1660'
P8='44e6248106335b5f0625e53de38f76d26aeeadcf'
EXPECTED={
 'crates/cc-eval/src/benchmark/oracle/streaming.rs':('6370b04d008787868666b0c035c8dbb9d92d67dfc3eb1bd790c578b1c2e2ad1c','b5eff557bed7d775490bc02c48a4678e0dd0f865',34836),
 'crates/cc-eval/tests/benchmark_oracle_streaming.rs':('0eebe45448130c73319736ec856f07ff7bc07a2538b418a50f152b19e25994a1','bc91a811b9845dadb07c73143a85dd82eb0ad8f8',18139)}
def load(path):return json.loads(Path(path).read_bytes())
def api(path):return json.loads(load(path)['structuredContent']['content'])
def sha(data):return hashlib.sha256(data).hexdigest()
def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def tree(entries):
 payload=b''
 for e in sorted(entries,key=lambda e:(e['path']+('/' if e['type']=='tree' else '')).encode()):
  payload+=e['mode'].lstrip('0').encode()+b' '+e['path'].encode()+b'\0'+bytes.fromhex(e['sha'])
 return hashlib.sha1(b'tree '+str(len(payload)).encode()+b'\0'+payload).hexdigest()
r7raw=R7.read_bytes();assert sha(r7raw)=='9de57a05b8d9896689a19a289fb3edfcfd8e859eef505f8ff7a63e9718ba3653'
old=json.loads(r7raw);assert old['source']==P7 and old['verdict']=='accepted_scoped'
actual=api(HERE/'P8B-commit.original.json');compare=api(HERE/'P7B-to-P8B-compare.original.json')
assert actual['sha']==P8 and [p['sha'] for p in actual['parents']]==[P7]
assert compare['base_commit']['sha']==P7 and compare['total_commits']==1
assert len(compare['commits'])==1 and compare['commits'][0]['sha']==P8
assert compare['base_commit']['commit']['tree']['sha']==old['source_tree']
assert compare['commits'][0]['commit']['tree']['sha']==actual['tree']['sha']
changes={f['filename']:f for f in compare['files']}
assert len(compare['files'])==2 and set(changes)==set(EXPECTED)
complete=dict(old['complete_inputs']);inventory={p:dict(v) for p,v in old['actual_input_mode_blob_inventory'].items()}
two=[]
for path,(digest,oid,size) in EXPECTED.items():
 raw=(SOURCE/path).read_bytes();assert (sha(raw),blob(raw),len(raw))==(digest,oid,size)
 assert changes[path]['status']=='modified' and changes[path]['sha']==oid
 before=inventory[path];assert before['mode']=='100644'
 after=dict(mode='100644',type='blob',sha=oid,size=size,sha256=digest)
 inventory[path]=after;complete[path]=digest
 two.append(dict(path=path,local_path=str(SOURCE/path),before=before,after=after))
nodes={}
for f in sorted((P7DIR/'git-trees').glob('*.json')):
 node=api(f);path='' if f.stem=='root' else f.stem.replace('__','/')
 assert tree(node['tree'])==node['sha'];nodes[path]=node
assert len(nodes)==13 and nodes['']['sha']==old['source_tree']
for path,node in nodes.items():
 if path:
  parent,_,name=path.rpartition('/');assert next(e['sha'] for e in nodes[parent]['tree'] if e['path']==name)==node['sha']
updated={}
for path in sorted(nodes,key=lambda p:len(p.split('/')),reverse=True):
 entries=[dict(e) for e in nodes[path]['tree']]
 for e in entries:
  full=path+'/'+e['path'] if path else e['path']
  if full in EXPECTED:
   assert e['mode']=='100644' and e['sha']==old['actual_input_mode_blob_inventory'][full]['sha']
   e['sha']=EXPECTED[full][1]
  elif e['type']=='tree' and full in updated:e['sha']=updated[full]
 updated[path]=tree(entries)
assert updated['']==actual['tree']['sha']=='6ade2b570e0d1bba09cf3f70ed6a1522c3c05e2b'
base=dict(old['complete_inputs'])
for p,v in old['paths'].items():
 assert set(v)=={'before_sha256','sha256'} and v['sha256']==base[p]
 if v['before_sha256'] is None:del base[p]
 else:base[p]=v['before_sha256']
delta={p:dict(before_sha256=base.get(p),sha256=s) for p,s in complete.items() if base.get(p)!=s}
assert (len(complete),len(delta),len(old['validation_inputs']),len(inventory))==(1095,75,142,1237)
assert set(complete)==set(old['complete_inputs']) and set(delta)==set(old['paths'])
assert all(v==old['actual_input_mode_blob_inventory'][p] for p,v in inventory.items() if p not in EXPECTED)
result=dict(schema_version=1,source=P8,source_tree=actual['tree']['sha'],source_parents=[P7],base=old['base'],
            previous_review_sha256=sha(r7raw),counts=dict(product=1095,BASE_delta=75,validation=142,mode_blob_inputs=1237),
            two_changes=two,complete_inputs=complete,paths=delta,validation_inputs=old['validation_inputs'],
            actual_input_mode_blob_inventory=inventory,exact_tree_from_P7B_changing_only_two_leaf_OIDs=updated[''],
            original_directory_objects_rehashed_without_network=13,all_other_paths_modes_and_four_payload_files_unchanged=True,
            execution_credit='none; source identity assertions only')
out=HERE/'actual-P8B-complete-source-bridge.json'
with out.open('xb') as f:f.write((json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
print(json.dumps(dict(source=P8,tree=updated[''],counts=result['counts'],bytes=out.stat().st_size,sha256=sha(out.read_bytes()))))
