from pathlib import Path
import json,hashlib,ast,re,datetime
D=Path(__file__).resolve().parent
C=Path('/dev/shm/pr-triage-round23-wide-dirty-candidate');m=json.loads((C/'source-manifest.json').read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
files=[]
for x in m['files']:
 p=C/'candidate'/x['path'];b=p.read_bytes();assert(len(b),sha(b),oid(b))==(x['bytes'],x['sha256'],x['git_blob']);files.append(x|{'local_path':str(p)})
orig=json.loads((C/'original-copy-manifest.json').read_text());g=json.loads(Path('/dev/shm/pr-triage-round21-P8B-source-review/actual-P8B-complete-source-bridge.json').read_text())
for x in orig['files']:
 b=(C/'original'/x['path']).read_bytes();assert(len(b),sha(b))==(x['bytes'],x['sha256']);assert g['validation_inputs'][x['path']]==sha(b)
for name in ['scripts/p7_build_identity.py','.github/workflows/p8-scale.yml']:
 assert(C/'candidate'/name).read_bytes()==(C/'original'/name).read_bytes()
a=(C/'original/scripts/p8_scale_matrix.py').read_text();b=(C/'candidate/scripts/p8_scale_matrix.py').read_text()
def funcs(s):return {n.name:n for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
af,bf=funcs(a),funcs(b);assert af.keys()==bf.keys();changed=[n for n in af if ast.dump(af[n])!=ast.dump(bf[n])]
assert sorted(changed)==sorted(['capacity_contract','registered_plan','run_shard','check_parity','inspect_raw','validate_shard','combine','main'])
assert ast.dump(af['capacity_contract'].body[0])==ast.dump(bf['capacity_contract'].body[-1])
ot=(C/'original/scripts/tests/test_p8_scale_matrix.py').read_text();nt=(C/'candidate/scripts/tests/test_p8_scale_matrix.py').read_text();start=nt.index('class WideDirtyControls(unittest.TestCase):');end=nt.index('class PortableBuildOriginControls(unittest.TestCase):',start);assert nt[:start]+nt[end:]==ot
oldtests=[n.name for n in ast.walk(ast.parse(ot)) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')];newtests=[n.name for n in ast.walk(ast.parse(nt)) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')];assert(len(oldtests),len(newtests))==(39,44)
ow=(C/'original/.github/workflows/p8-scale.yml').read_text();nw=(C/'candidate/.github/workflows/p8-scale-wide-dirty.yml').read_text()
def normalize(s):return '\n'.join(x for x in s.splitlines() if not x.lstrip().startswith('#'))
normalized=nw.replace('P8 wide dirty complete scale measurements','P8 complete scale measurements').replace('p8-scale-wide-dirty-','p8-scale-').replace('scale_wide_dirty_v1','scale_capacity_v1').replace('matrix.WIDE_DIRTY_PROFILE','matrix.CAPACITY_PROFILE');assert normalize(normalized)==normalize(ow)
cp=C/'python-controls-attempt01';receipt=json.loads((cp/'exit-code.json').read_text());stderr=(cp/'stderr').read_text();assert receipt['exit_code']==0 and receipt['source_sha256']==sha(b.encode());assert 'Ran 44 tests in 1.984s\n\nOK\n' in stderr
ok_lines=[line for line in stderr.splitlines() if line.endswith(' ... ok')];assert len(ok_lines)==44
report={'schema':'wide-dirty-python-workflow-nonauthor-static-review-v1','observed_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/todo_audit','verdict':'accepted_scoped_source_and_retained_python_controls','unresolved_blockers':[],'scope':'exact four frozen Python/workflow/docs paths; native interface approval pending separate native diff. No product/study execution by reviewer.','source_base':m['base'],'files':files,'mechanical_checks':{'original_four_validation_files_match_G8_map':True,'original_workflow_and_build_identity_helper_bytes_unchanged':True,'original39_python_test_file_bytes_preserved_by_one_inserted_class':True,'old_capacity_contract_return_dictionary_AST_unchanged':True,'modified_driver_functions':changed,'workflow_normalizes_exactly_to_old_after_only_name_namespace_workprofile_and_comments':True},'semantic_findings':[
 'Namedwork contract differs onlyid/main4096 plus explicit oracle_capacity_profile oldphysicaltag. Originalcall default still produces original200 contract exactly; unregisteredplan remains8/128.',
 'registered_plan selects exact4096/1024 only for newprofile, keepsrelease/one-repetition-shard/N30 and registered5h. run_shard passes actualwork name and preserves strictsource/build/configbinding.',
 'check_parity requires oldphysicaltag for both explicitworkprofiles; all15tables,rowmultiplicity/fullValue reports and originaldisk limits/cache/layout remain. Newworkprofile cannot masquerade as physicalparityprofile.',
 'inspect_raw retains actualruntimeconfiguration, all9mainstages, everyresume report, noresumeaftercomplete, independentconfigfact/fullcontrol, fullparity and actualfanout8/128 pressure. Only membershipcheck expanded to newworkprofile.',
 'validate_shard reconstructs exactregisteredplan and exactselectedcontract; combine rejectsmixedworkprofiles/parameters/source/binary/corpus, requiresall150shards/50groups/N30, retainsallfailures andheterogeneousstrata; noactualincompletefanout remainsrejected.',
 'Newworkflow adds independentlabel/artifact/outputnamespace only. Sameexacteventhead checkout,releasebuild,5originalrep0 then145,aggregatealwaysafterbuild,uploads withalways andnosample substitutions. Existingworkflow unchanged.',
 'No original physicalcapacity/productiondefault/C05 behavior is changed in these four files. Ordinarycandidate correctness and measuredwideperformance remain unproven by Pythonfixtures.'
 ],'observed_author_execution':{'kind':'syntheticPythonprotocol controls, not native workload','argv':receipt['argv'],'cwd':receipt['cwd'],'exit_code':receipt['exit_code'],'qualified_ok_lines':len(ok_lines),'new_controls':5,'all_controls':44,'original_stdio':{n:{'path':str(cp/n),'bytes':(cp/n).stat().st_size,'sha256':sha((cp/n).read_bytes())} for n in ['exit-code.json','stdout','stderr']},'reviewer_reexecuted':False},'nonblocking_documentation_note':'At reviewed docs L9, defaultprofile8/128 means unregisteredbenchmarkCLI; clarify productiondefault200 to avoid confusion. Not a correctnessblocker or reason for additional44tests.', 'boundaries':{'native_Rust': 'not_run_by_reviewer_and_pending_native_diff','actualnewstudy': 'not_run','TODOcredit':0,'remaining':29,'newnetworkrequests':0,'sourcewrites':0,'imports_of_candidate':0},'read_only_inspection_note':'One exploratory sed attempted nonexistent receipt.json; actualexit-code.json was subsequently read. This was a read-only locator error, not productvalidation failure/retry.'}
p=D/'python-workflow-independent-review.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'report':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'verdict':report['verdict'],'originaltests_reexecuted':False}))
