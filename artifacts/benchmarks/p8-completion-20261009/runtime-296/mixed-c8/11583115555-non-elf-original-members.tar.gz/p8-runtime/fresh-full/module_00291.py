def stable_00291():
    return 291
