def stable_00349():
    return 349
