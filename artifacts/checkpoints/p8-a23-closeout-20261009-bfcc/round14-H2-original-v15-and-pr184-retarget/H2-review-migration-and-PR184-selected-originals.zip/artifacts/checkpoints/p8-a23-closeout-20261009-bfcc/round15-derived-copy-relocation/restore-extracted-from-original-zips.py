"""Optional restoration after loss of the transient RAM copy; never run by this migration."""
from pathlib import Path,PurePosixPath
import sys,json,hashlib,zipfile,stat,shutil,os
ROOT=Path(__file__).resolve().parent
assert len(sys.argv)==2,'supply exactly one recorded artifact ID'
manifest=json.loads((ROOT/'migration-plan-and-content-manifest.json').read_text())
plan=next(p for p in manifest['plans'] if str(p['artifact_id'])==sys.argv[1])
old=Path(plan['source']);ram=Path(plan['destination']);original=Path(plan['original_zip']['path'])
assert old.is_symlink() and os.readlink(old)==str(ram),'refuse any changed original-path state'
assert not ram.exists(),'verified RAM copy still exists; no restoration needed'
assert shutil.disk_usage(old.parent).free>plan['source_allocated_bytes']+128*1024*1024,'insufficient room for complete restored derivative'
h=hashlib.sha256()
with original.open('rb') as f:
 for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
assert original.stat().st_size==plan['original_zip']['bytes'] and h.hexdigest()==plan['original_zip']['sha256']
staging=old.parent/'extracted.round15-restore-new';assert not staging.exists();staging.mkdir()
expected={r['path']:r for r in plan['files']};seen=set()
with zipfile.ZipFile(original) as z:
 for zi in z.infolist():
  n=zi.orig_filename;p=PurePosixPath(n)
  assert n==zi.filename and '\0' not in n and '\\' not in n and not p.is_absolute() and '..' not in p.parts and n==str(p) and n not in seen
  assert not zi.is_dir() and not stat.S_ISLNK(zi.external_attr>>16) and n in expected
  seen.add(n);row=expected[n];b=z.read(zi);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
  dest=staging/n;dest.parent.mkdir(parents=True,exist_ok=True)
  with dest.open('xb') as f:f.write(b)
  dest.chmod(row['mode']);os.utime(dest,ns=(row['mtime_ns'],row['mtime_ns']))
assert seen==set(expected)
# Remove only the already-validated broken compatibility link, then publish verified derivative.
assert old.is_symlink() and os.readlink(old)==str(ram) and not ram.exists()
old.unlink();staging.rename(old)
print(json.dumps({'restored_artifact':plan['artifact_id'],'path':str(old),'files':len(expected),'original_zip_unchanged':True}))
