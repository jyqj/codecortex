"""Authorized one-time receipt reader + one unchanged validate_build call.

No workload/build is started. The original validator invokes ELF --hash-file.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time
import zipfile

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'round33-PR200-build-capacity-original-intake/attempt01'
PREP = ROOT / 'round32-100k-diagnostic-intake-preparation'
BINDING = ROOT / 'round32-100k-diagnostic-intake-bound-9cc6-run38012409915/binding.json'
SOURCE = ROOT / 'round32-capture-context-admission/guard-view'
META = ROOT / 'round33-PR199-and-diagnostic-0125-official-snapshot.json'
REGISTRATION = ROOT / 'round32-diagnostic-workflow-context-independent-review/root-PR200-corrected-diagnostic-original-registration.json'
EXPECTED = {
    11655760884: ('build', 'p8-100k-diagnostic-build-38012409915-1-original.zip', 9236921, '0bd905610d8e67f48b5adc7b17a664175d0232692f006db33029a6f5c5011bca'),
    11655381046: ('capacity', 'p8-100k-diagnostic-capacity-38012409915-1-original.zip', 783, '1a36abc17bf4c1522743e33031314126f27fbbfaffbf295879cf6568830223b1'),
}

def digest(path):
    return hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()

def write(path, value):
    with path.open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

def unwrap(path):
    return {r['url']: json.loads(r['value']['structuredContent']['content'])
            for r in json.loads(path.read_text())['requests'] if r['status'] == 'fulfilled'}

def command(label, argv):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    with (OUT / (label + '.stdout')).open('xb') as stdout, (OUT / (label + '.stderr')).open('xb') as stderr:
        result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr,
                                env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'GIT_NO_LAZY_FETCH': '1'}, check=False)
    receipt = {'argv': argv, 'cwd': str(ROOT), 'started_utc': started,
               'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'duration_seconds': time.monotonic() - tick, 'exit_code': result.returncode,
               'stdout_sha256': digest(OUT / (label + '.stdout')),
               'stderr_sha256': digest(OUT / (label + '.stderr'))}
    write(OUT / (label + '.execution.json'), receipt)
    return result.returncode

def snapshot(binding, extracted):
    paths = {str(SOURCE / p) for p in binding['product_inputs']}
    paths |= {str(SOURCE / p) for p in binding['driver_inputs']}
    paths |= {str(SOURCE / p) for p in binding['observer_inputs']}
    paths |= {str(p) for p in extracted.rglob('*') if p.is_file()}
    paths |= {str(BINDING), str(PREP / 'read-original-diagnostic.py'), str(PREP / 'call-original-validator-once.py')}
    rows = {}
    for name in sorted(paths):
        p = Path(name)
        assert p.is_file() and not p.is_symlink(), name
        rows[name] = {'bytes': p.stat().st_size, 'sha256': digest(p), 'posix_mode': oct(stat.S_IMODE(p.stat().st_mode))}
    return {'source_HEAD': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip(),
            'rows': rows, 'count': len(rows)}

OUT.mkdir(parents=True, exist_ok=False)
binding = json.loads(BINDING.read_text())
official = unwrap(META)
registered = unwrap(REGISTRATION)
run = registered['https://api.github.com/repos/jyqj/codecortex/actions/runs/38012409915']
jobs = official['https://api.github.com/repos/jyqj/codecortex/actions/runs/38012409915/jobs?per_page=100']['jobs']
artifacts = official['https://api.github.com/repos/jyqj/codecortex/actions/runs/38012409915/artifacts?per_page=100']['artifacts']
rows = []
for aid, (kind, filename, size, sha) in EXPECTED.items():
    artifact = next(a for a in artifacts if a['id'] == aid)
    assert artifact['size_in_bytes'] == size and artifact['digest'] == 'sha256:' + sha
    rows.append({'kind': kind, 'artifact': artifact, 'run_attempt': 1,
                 'zip_path': str(ROOT / 'round33-diagnostic-original-artifacts' / filename),
                 'official_original_reference': {'path': str(META), 'sha256': digest(META)}})
index = {'schema': 'p8-independent-100k-official-artifact-index-v1', 'run': run, 'jobs': jobs,
         'artifacts': rows, 'metadata_observation_boundary': 'Run identity from initial registration; jobs/artifact original snapshot from 01:25. No current-run status invented.'}
write(OUT / 'official-index.json', index)
code = command('offline-reader', ['python3', '-B', str(PREP / 'read-original-diagnostic.py'), '--binding', str(BINDING),
                                '--official-index', str(OUT / 'official-index.json'), '--output', str(OUT / 'reader')])
if code:
    write(OUT / 'terminal.json', {'status': 'reader_failed_originals_retained', 'reader_exit': code,
                                'original_validate_build': 'not_run', 'no_sample_credit': True})
    sys.exit(code)

report = json.loads((OUT / 'reader/report.json').read_text())
extracted = OUT / 'extracted'
extracted.mkdir()
for record in report['artifacts']:
    target = extracted / record['kind']
    target.mkdir()
    with zipfile.ZipFile(record['zip_path']) as archive:
        for name, entry in record['members'].items():
            dest = target / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            with dest.open('xb') as output:
                output.write(archive.read(name))
            os.chmod(dest, int(entry['zip_posix_mode'], 8))
            assert dest.stat().st_size == entry['bytes'] and digest(dest) == entry['sha256'], name
before = snapshot(binding, extracted)
assert before['source_HEAD'] == binding['G']
write(OUT / 'source-evidence-before.json', before)
code = command('original-validate-build', ['python3', '-B', str(PREP / 'call-original-validator-once.py'), 'build',
                                         '--binding', str(BINDING), '--source-root', str(SOURCE),
                                         '--build-directory', str(extracted / 'build'),
                                         '--output', str(OUT / 'original-validate-build-result.json')])
after = snapshot(binding, extracted)
write(OUT / 'source-evidence-after.json', after)
assert before == after, 'source or extracted originals changed'
write(OUT / 'terminal.json', {'status': 'build_predicate_complete' if code == 0 else 'build_predicate_failed_originals_retained',
                            'reader_exit': 0, 'original_validate_build_exit': code,
                            'original_function_calls': {'validate_build': 1, 'validate_shard': 0, 'inspect_raw': 0},
                            'ELF_mode': 'original native_digest --hash-file only; no workload',
                            'source_and_extracted_originals_before_after_equal': True,
                            'snapshot_count': before['count'], 'capacity_semantic_review': 'pending_readonly_receipt_review',
                            'checkpoints': 0, 'native_outcome': 'unknown',
                            'accepted_cohort_shards': 0, 'accepted_cohort_samples': 0, 'task_completion_credit': 0})
print(json.dumps({'reader_exit': 0, 'original_validate_build_exit': code, 'output': str(OUT), 'source_unchanged': True}))
sys.exit(code)
