def stable_00395():
    return 395
