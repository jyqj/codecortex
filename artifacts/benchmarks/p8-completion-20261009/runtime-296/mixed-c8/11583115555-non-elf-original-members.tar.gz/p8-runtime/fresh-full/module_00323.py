def stable_00323():
    return 323
