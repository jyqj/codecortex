def stable_00210():
    return 210
