def stable_00096():
    return 96
