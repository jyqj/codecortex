#!/usr/bin/env python3
"""Verify original artifact bytes and safely extract a bounded review copy only."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import zipfile

if sys.flags.optimize:
 raise RuntimeError("optimized Python disables required transport assertions")

BASE=Path(__file__).resolve().parent
OWNED_DIRS=(BASE/"platform",BASE/"recovery-rollback")
OWNED_LIMIT=2*1024**3
RESERVE=512*1024**2

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  while block:=f.read(1024**2):h.update(block)
 return h.hexdigest()

def verify(archive,out,expected_bytes,expected_sha,skip_recovery_binaries=False):
 archive=archive.resolve(strict=True)
 assert any(archive.is_relative_to(d) for d in OWNED_DIRS)
 assert any(out.resolve().is_relative_to(d) for d in OWNED_DIRS)
 assert archive.stat().st_size==expected_bytes and sha(archive)==expected_sha
 skipped={f'p8-full-recovery/product-{p}/codecortex' for p in ('default','semantic','semantic-http','previous')}
 skipped|={f'p8-full-recovery/fault-test-{n:02}/fault-test' for n in range(7)}
 skipped|={f'p8-full-recovery/actual-version-pair/{p}-product/codecortex' for p in ('current','previous')}
 if not skip_recovery_binaries:skipped=set()
 with zipfile.ZipFile(archive) as z:
  infos=z.infolist();names={i.filename for i in infos}
  assert len(infos)==len(names) and all(not i.is_dir() for i in infos)
  assert skipped<=names
  for i in infos:
   p=PurePosixPath(i.filename)
   assert not p.is_absolute() and '..' not in p.parts and str(p)==i.filename and '\\' not in i.filename
   assert not stat.S_ISLNK(i.external_attr>>16) and not(i.flag_bits&1)
  expanded=sum(i.file_size for i in infos)
  extract_bytes=sum(i.file_size for i in infos if i.filename not in skipped)
  owned=sum(p.stat().st_size for d in OWNED_DIRS for p in d.rglob('*') if p.is_file())
  s=os.statvfs(BASE);free=s.f_bavail*s.f_frsize
  assert expanded<=OWNED_LIMIT and owned+extract_bytes<=OWNED_LIMIT and free>=extract_bytes+RESERVE
  out.mkdir(exist_ok=False,parents=True)
  members={}
  for i in infos:
   dst=None
   if i.filename not in skipped:
    p=out/i.filename;p.parent.mkdir(parents=True,exist_ok=True);dst=p.open('xb')
   h=hashlib.sha256();size=0
   try:
    with z.open(i) as source:
     while block:=source.read(1024**2):
      h.update(block);size+=len(block)
      if dst:dst.write(block)
   finally:
    if dst:dst.close()
   assert size==i.file_size
   members[i.filename]={'bytes':size,'sha256':h.hexdigest(),'crc32':f'{i.CRC:08x}','extracted_nonbinary':i.filename not in skipped}
  assert sha(archive)==expected_sha
  return {'status':'original_transport_bytes_verified','archive':str(archive),'zip_bytes':expected_bytes,'zip_sha256':expected_sha,'members':members,'central_directory_bytes':expanded,'extracted_bytes':extract_bytes,'stream_verified_not_extracted':sorted(skipped),'preflight':{'free_bytes':free,'owned_bytes':owned,'reserve_bytes':RESERVE,'owned_limit_bytes':OWNED_LIMIT}}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('output',type=Path);p.add_argument('bytes',type=int);p.add_argument('sha256');p.add_argument('manifest',type=Path);p.add_argument('--skip-recovery-binaries',action='store_true');a=p.parse_args()
 if not any(a.manifest.resolve().is_relative_to(d) for d in OWNED_DIRS):
  raise ValueError('transport manifest must remain in an owned evidence directory')
 result=verify(a.archive,a.output,a.bytes,a.sha256,a.skip_recovery_binaries)
 with a.manifest.open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
 print(json.dumps({'status':result['status'],'members':len(result['members']),'expanded_bytes':result['central_directory_bytes'],'extracted_bytes':result['extracted_bytes'],'manifest_sha256':sha(a.manifest)}))
