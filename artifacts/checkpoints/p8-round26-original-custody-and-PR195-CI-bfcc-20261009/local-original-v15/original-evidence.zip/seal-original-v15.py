from pathlib import Path
import json,hashlib,platform,subprocess,datetime,zipfile,stat
B=Path(__file__).resolve().parent;D=B/'original-v15-attempt01';O=B/'sealed-original-v15';O.mkdir(exist_ok=False)
def meta(p):
 b=p.read_bytes();return {'local_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'mode':oct(stat.S_IMODE(p.stat().st_mode))}
r=json.loads((D/'receipt.json').read_text());before=json.loads((D/'inputs-before.json').read_text());after=json.loads((D/'inputs-after.json').read_text());assert r['exit_code']==int((D/'exit-code.txt').read_text())
assert before['git']['HEAD'].strip()=='34dc4e14dc96d077eae6173ab6885370323eff3f';assert before['git']['tree'].strip()=='74233d3b797162da63547afa04df2358acffe320'
classification=json.loads((B/'materialized-domain-classification.json').read_text());assert classification['actual_entries']==1434 and not classification['extras'] and not classification['missing']
stdout=(D/'stdout').read_bytes();stderr=(D/'stderr').read_bytes();assert hashlib.sha256(stdout).hexdigest()==r['stdout_sha256'];assert hashlib.sha256(stderr).hexdigest()==r['stderr_sha256']
accepted=r['exit_code']==0 and r['source_entries_equal'] and r['git_equal'] and r['index_equal']
parsed=json.loads(stdout) if r['exit_code']==0 else None
if accepted:assert parsed['status']=='passed' and parsed['complete_inputs']==1095 and parsed['product_source']=='58a890857a6b6c2da874491817beb6d561897a9a' and parsed['review_source']=='b39fdd8c858755d1a92c176efc5340907f4a3757'
report={'schema':'GCW3-original-v15-execution-v1','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'passed_original_v15_only' if accepted else 'original_cli_or_source_check_failed','source':'34dc4e14dc96d077eae6173ab6885370323eff3f','tree':'74233d3b797162da63547afa04df2358acffe320','product':'58a890857a6b6c2da874491817beb6d561897a9a','review':'b39fdd8c858755d1a92c176efc5340907f4a3757','actual_cli_invocations':1,'execution':r,'stdout_json':parsed,'materialized_domain':classification,'inputs_before':meta(D/'inputs-before.json'),'inputs_after':meta(D/'inputs-after.json'),'runtime':{'platform':platform.platform(),'python':platform.python_version()},'preparation':{'kind':'Real isolated sparse Git checkout; actual fetched commit and detached HEAD, full index tree; no forged Git identity.','read_only_alternates':'/workspace/scratch/bfccb8494ba0/todo-audit-round25-50k-recovery/git-object-cache/objects','history':'Only original declared61 immutable script refs and original two catalogue sets hydrated; original helper relative, no-lazy-fetch, file and byte limits unchanged;236 current protected paths.','prior_auxiliary_read_failures':'One initial rg referenced nonexistent scripts/reviewed_source_git.py (exit2); later auxiliary ps could not see childPID across exec contexts (exit1). Neither called or retried v15; raw tool observations retained in session.'},'limitations':['This proves the original selected source-admission CLI only.','No181-test suite, Rust, benchmark, source performance gate, or fullscale study ran here.','Sparse tree materialization1434 is the complete required product/validation/history union, not all repository files.','The earlier G9 500ms fixture failure remains unchanged.'],'newly_completed_todos':0,'remaining_todos':29}
(O/'execution-review.json').write_text(json.dumps(report,indent=2)+'\n')
paths=[B/'prepare-initial.py',B/'prepare-history.py',B/'run-original-v15.py',B/'seal-original-v15.py',B/'declared-script-ref-list.json',B/'original-history-catalogue-paths.json',B/'historical-catalogues-and-objects.json',B/'materialized-domain-classification.json',O/'execution-review.json']
paths+=sorted((B/'prepare-commands').glob('*'))+sorted((B/'history-prep').glob('*'))+sorted(D.glob('*'))
entries=[{**meta(p),'member_path':p.relative_to(B).as_posix()} for p in paths]
sel={'schema':'selected-original-v15-evidence-v1','entries':entries,'files':len(entries),'total_bytes':sum(x['bytes'] for x in entries),'excluded':'No source checkout, Git object store, previousstudy or ZIP duplicated.'}
(O/'archive-selection.json').write_text(json.dumps(sel,indent=2)+'\n')
with zipfile.ZipFile(O/'original-GCW3-v15-evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in paths:z.write(p,p.relative_to(B).as_posix())
 z.write(O/'archive-selection.json','sealed-original-v15/archive-selection.json')
# A newly generated seal is checked once by its author, not an extra acceptance gate.
with zipfile.ZipFile(O/'original-GCW3-v15-evidence.zip') as z:
 assert z.testzip() is None
 for e in entries:assert hashlib.sha256(z.read(e['member_path'])).hexdigest()==e['sha256']
manifest={'schema':'root-upload-plan-v1','source':report['source'],'scope':report['verdict'],'entries':[meta(O/n) for n in ['execution-review.json','archive-selection.json','original-GCW3-v15-evidence.zip']]}
(O/'upload-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest))
