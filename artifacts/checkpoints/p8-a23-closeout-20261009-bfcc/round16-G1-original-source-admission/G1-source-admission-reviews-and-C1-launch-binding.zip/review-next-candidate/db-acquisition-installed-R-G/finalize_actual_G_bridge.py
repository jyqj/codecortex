import datetime, hashlib, json, pathlib
ROOT=pathlib.Path('/workspace/scratch/bfccb8494ba0')
OUT=ROOT/'scale-intake-primary/installed-db-acquisition-R-G-review'
def load(p):return json.loads(p.read_text())
def ident(p):
 b=p.read_bytes();return {'local_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def norm(xs):return sorted([{k:x[k] for k in ['path','mode','type','sha']} for x in xs],key=lambda x:x['path'])
def tree_hash(items):
 b=b''.join(x['mode'].lstrip('0').encode()+b' '+x['path'].encode()+b'\0'+bytes.fromhex(x['sha']) for x in sorted(items,key=lambda x:(x['path']+('/' if x['type']=='tree' else '')).encode()))
 return hashlib.sha1(b'tree '+str(len(b)).encode()+b'\0'+b).hexdigest()
actual=load(ROOT/'root-round15/final-G-official-commit.json')
pending=load(OUT/'independent-two-G-bindings-review.pending-actual-G.json')
assert actual['sha']=='d7f21ab52ee2068c45ab5f7781e9e1db57f613de'
assert [p['sha'] for p in actual['parents']]==[pending['actual_parent_R']]
assert actual['tree']['sha']==pending['expected_G_tree']
readbacks={}
for kind in ['root','scripts']:
 p=OUT/f'G-official-{kind}.json';x=load(p)['result'];x=x.get('structuredContent',x);d=json.loads(x['content'])
 assert d['truncated']==False and tree_hash(d['tree'])==d['sha']
 readbacks[kind]=d
assert readbacks['root']['sha']==pending['expected_G_tree']
assert readbacks['scripts']['sha']==pending['expected_scripts_tree']
parent_root=load(ROOT/'root-round15/final-R-official-read-2.json')
assert norm([x for x in parent_root['tree'] if x['path']!='scripts'])==norm([x for x in readbacks['root']['tree'] if x['path']!='scripts'])
cached=load(pathlib.Path('/dev/shm/todo-audit-p8007-lock-observation-review/actual-P-review-inputs/actual-P-complete-derived-Git-tree.json'))
old={x['path'][8:]:{**x,'path':x['path'][8:]} for x in cached['tree'] if x['path'].startswith('scripts/') and '/' not in x['path'][8:]}
assert tree_hash(list(old.values()))==next(x['sha'] for x in parent_root['tree'] if x['path']=='scripts')
new={x['path']:x for x in readbacks['scripts']['tree']}
assert old.keys()==new.keys()
changed=sorted(p for p in old if norm([old[p]])!=norm([new[p]]))
assert changed==['reviewed-source-registry-v15.json','verify_reviewed_source_v15.py']
for f in pending['files']:
 name=pathlib.Path(f['path']).name
 assert new[name]['sha']==f['git_blob'] and new[name]['size']==f['bytes'] and new[name]['mode']=='100644'
report={**pending,'actual_G':actual['sha'],'actual_G_tree':actual['tree']['sha'],'actual_G_sole_parent_R':actual['parents'][0]['sha'],'verdict':'accepted_exact_actual_G_is_R_plus_two_bindings','reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'official_root_and_scripts_trees_rehashed':True,'actual_changed_leaf_paths':['scripts/'+p for p in changed],'all_other_root_subtrees_and_script_entries_unchanged':True,'official_commit':ident(ROOT/'root-round15/final-G-official-commit.json'),'official_tree_readbacks':[ident(OUT/f'G-official-{k}.json') for k in ['root','scripts']],'pending_binding_review_retained':ident(OUT/'independent-two-G-bindings-review.pending-actual-G.json'),'source_admission_executed_by_this_reviewer':False,'root_original_v15_execution':'Separate root-owned native job; no result asserted here.'}
p=OUT/'independent-actual-G-installation-review.json'
with p.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
files=[]
for src in sorted(OUT.iterdir()):
 if src.is_file() and src.name!='archive-selection.json':files.append({**ident(src),'repository_path':'review-next-candidate/db-acquisition-installed-R-G/'+src.name})
for src in [ROOT/'root-round15/final-R-official-read-0.json',ROOT/'root-round15/final-R-official-read-1.json',ROOT/'root-round15/final-R-official-read-2.json',ROOT/'root-round15/final-G-official-commit.json',ROOT/'scale-intake-primary/db-wait-cleanup-P-bb29-independent/prepare_installed_R_bridge.py']:
 files.append({**ident(src),'repository_path':'review-next-candidate/db-acquisition-installed-R-G/'+src.name})
selection={'schema_version':1,'scope':'Thin exact installed R/G bridge; no new admission, workload or TODO credit. All source/semantic/native originals remain in earlier R artifacts.','files':files,'file_count':len(files),'total_bytes':sum(x['bytes'] for x in files)}
with (OUT/'archive-selection.json').open('x') as f:json.dump(selection,f,indent=2);f.write('\n')
print(json.dumps({'report':ident(p),'selection':ident(OUT/'archive-selection.json'),'files':len(files),'selected_bytes':selection['total_bytes']},indent=2))
