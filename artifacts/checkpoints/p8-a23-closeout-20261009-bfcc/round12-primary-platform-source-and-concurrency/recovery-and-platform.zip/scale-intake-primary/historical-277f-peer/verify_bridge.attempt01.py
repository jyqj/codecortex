import datetime
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).parent
PEER = Path('/workspace/scratch/bfccb8494ba0/todo-audit-round12/recovery-platform-Gc8')
API = PEER / 'historical-source-api'
RPATH = Path('/workspace/scratch/bfccb8494ba0/pr-triage-primary-recovery/runtime-review-Gc8/exact-canonical-R.json')
RAW = Path('/workspace/scratch/bfccb8494ba0/pr-triage-primary-recovery/raw-pr178-c8be5afa/11604900056/attempt01/extracted/p8-full-recovery')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_bytes())
def objhash(kind, data): return hashlib.sha1(kind.encode() + b' ' + str(len(data)).encode() + b'\0' + data).hexdigest()
def json_bytes(value): return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
def meta(p): return dict(path=str(p), bytes=p.stat().st_size, sha256=digest(p))
assert digest(RPATH) == 'c38d10f1b0d5935384039a6af7df6e8d222bc351a68d3137b09e664735ee9404'
R = read(RPATH)
F = OUT / 'actual-P-complete-product-validation-inputs.json'
assert digest(F) == R['provenance']['supporting_artifacts']['actual_P_full_map']['sha256'] == '0f9512d6c37946db2f82a9f6b7f377125db6bcf03b8c64330e5bd4ab79ae883d'
full = read(F)
assert full['source'] == R['source'] == '35a7b3412e5fdee9e8ff88951735c06b0e371465'
assert full['tree'] == R['reviewed_product_tree']
FM = {r['path']: r for r in full['files']}
assert len(FM) == len(full['files']) == 1235
review = read(PEER / 'historical-source-bridge-review.json')
for name, m in review['official_api'].items():
    p = API / name
    assert m == dict(bytes=p.stat().st_size, sha256=digest(p))
def tree_data(rows):
    rows = sorted(rows, key=lambda x: (x['path'] + ('/' if x['type'] == 'tree' else '')).encode())
    return b''.join((x['mode'].lstrip('0') + ' ' + x['path']).encode() + b'\0' + bytes.fromhex(x['sha']) for x in rows)
def inventory(prefix, expected_root):
    root = read(API / (prefix + '-root-tree-api.json'))
    crates = read(API / (prefix + '-crates-tree-api.json'))
    assert root['truncated'] is False and crates['truncated'] is False
    assert root['sha'] == objhash('tree', tree_data(root['tree'])) == expected_root
    assert next(x for x in root['tree'] if x['path'] == 'crates')['sha'] == crates['sha']
    groups = {'': []}
    expected = {'': crates['sha']}
    for row in crates['tree']:
        parent, _, name = row['path'].rpartition('/')
        groups.setdefault(parent, []).append(dict(row, path=name))
        if row['type'] == 'tree':
            groups.setdefault(row['path'], [])
            expected[row['path']] = row['sha']
    for parent, rows in groups.items():
        assert objhash('tree', tree_data(rows)) == expected[parent], parent
    rows = [x for x in root['tree'] if x['path'] in ('Cargo.toml', 'Cargo.lock')]
    rows += [dict(x, path='crates/' + x['path']) for x in crates['tree'] if x['type'] != 'tree']
    assert all(x['type'] == 'blob' and x['mode'] in ('100644', '100755') for x in rows)
    assert len({x['path'] for x in rows}) == len(rows)
    return {x['path']: x for x in rows}, len(groups) + 1
pc = read(API / 'previous-commit-api.json')
assert pc['sha'] == review['previous_commit'] == '277f2490fad3fa30f2812b5547bad033867c9ea5'
assert pc['tree']['sha'] == review['previous_tree'] == '992e3310f2e5595d53f66b05e9f1e8319273119e'
old, old_trees = inventory('previous', pc['tree']['sha'])
cur, cur_trees = inventory('current', '9b031be22a430e51e153cce6e80770ed885818e3')
assert len(old) == 704 and len(cur) == 1090 and set(cur) == set(R['complete_inputs'])
for path, row in cur.items():
    assert row['sha'] == FM[path]['git_blob'] and row['mode'] == FM[path]['mode'] == R['source_modes'][path]
    assert row['size'] == FM[path]['bytes'] and FM[path]['sha256'] == R['complete_inputs'][path]
derived, entries, common, differing = {}, [], [], []
for path, row in sorted(old.items()):
    equal = path in cur and all(cur[path][k] == row[k] for k in ('mode', 'type', 'sha', 'size'))
    if equal:
        h = R['complete_inputs'][path]
        common.append(path)
    else:
        data = (PEER / 'historical-source-blobs' / row['sha']).read_bytes()
        assert len(data) == row['size'] and objhash('blob', data) == row['sha']
        h = hashlib.sha256(data).hexdigest()
        differing.append(path)
    derived[path] = h
    entries.append(dict(path=path, mode=row['mode'], git_blob=row['sha'], sha256=h))
assert len(common) == 613 and len(differing) == 91
assert len({old[p]['sha'] for p in differing}) == 91
assert entries == [{k: e[k] for k in ('path','mode','git_blob','sha256')} for e in review['entries']]
identity = read(PEER / 'historical-source-identity.json')
assert derived == identity['inputs']
manifest = hashlib.sha256(json_bytes(derived)).hexdigest()
assert manifest == identity['manifest_sha256'] == review['manifest_sha256'] == 'aa075bde61e9aca29b43492bdf5d69009a7abc4fbde302eb7b48c40fa38d83a9'
assert derived == read(RAW / 'product-previous/source-inputs.json') == read(RAW / 'actual-version-pair/previous-product/source-inputs.json')
receipt = read(RAW / 'product-previous/build-receipt.json')
assert receipt['source_before'] == receipt['source_after']
assert {k:v for k,v in receipt['source_before'].items() if k != 'source_root'} == {k:v for k,v in identity.items() if k != 'inputs'}
result = dict(schema_version=1, reviewer='/root/execution_recon', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), verdict='accepted_exact_historical_source_identity_only', previous_commit=pc['sha'], previous_tree=pc['tree']['sha'], current_commit=review['current_commit'], current_tree=review['current_tree'], previous_product_count=704, canonical_current_product_count=1090, common_path_mode_type_size_blob=613, independently_rehashed_old_blobs=91, recursively_reconstructed_previous_tree_objects=old_trees, recursively_reconstructed_current_tree_objects=cur_trees, historical_manifest_sha256=manifest, reviewed_author_report=meta(PEER/'historical-source-bridge-review.json'), historical_identity=meta(PEER/'historical-source-identity.json'), canonical_R=meta(RPATH), published_actual_P_fullmap=meta(F), fullmap_url='https://raw.githubusercontent.com/jyqj/codecortex/c8be5afaac568ffd40ef86d3795423c3b73c9f39/artifacts/checkpoints/p8-ready-signal-bfcc-20261009/actual-P-complete-product-validation-inputs.json', checks={'all_current_1090_Git_blobs_modes_sizes_match_actual_P_fullmap_and_R_SHA256':True,'all_recursive_Git_tree_objects_recomputed':True,'all_91_old_blobs_Git_SHA1_and_SHA256_recomputed':True,'all_704_equal_both_current_artifact_previous_product_maps':True,'historical_build_source_before_after_equal':True}, limits=['Identity bridge only; old binary not executed and no build or benchmark started.','Uses retained official API responses and raw historical blobs provided by todo_audit; no duplicate blob download.','One public exact-P fullmap was retrieved and matched the SHA already bound in canonical R, explicitly linking current Git blob IDs to reviewed SHA256 values.','No old execution, recovery, performance, fullscale, release or TODO credit transferred.'], task_credit=0, remaining_todos=29)
output=OUT/'independent-review.json'
with output.open('x') as f:
    json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(meta(output)))
