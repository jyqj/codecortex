"""One frozen-reader intake of new08 only; accepted00-07 are continuity dependencies."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'round39-diagnostic-checkpoint-08-intake/attempt01'
OLD = ROOT / 'round38-diagnostic-checkpoint-07-intake/attempt01'
OFFICIAL = ROOT / 'round38-0340-baseline-and-studies-observation/diagnostic-artifacts.original.json'
BINDING = ROOT / 'round32-100k-diagnostic-intake-bound-9cc6-run38012409915/binding.json'
READER = ROOT / 'round32-100k-diagnostic-intake-preparation/read-original-diagnostic.py'
NEW_ID = 11658656645
OLD_IDS = [11655358015, 11655694522, 11656371239, 11656517936, 11656209993, 11656794128, 11657318324, 11658151472]

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save(name, value):
    with (OUT / name).open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

OUT.mkdir(parents=True, exist_ok=False)
assert sha(READER) == 'ae7945e5f7150b350ae856a1fd22d7ad92e157c74ae73c8ab3e3799a857bca23'
assert sha(BINDING) == '12819cd48434ac181d4aaac0eb020ba936c9a48e39d02683766f5dd5f07c17cb'
previous = json.loads((OLD / 'checkpoint07-prefix-review.json').read_text())
assert previous['verified_prefixes']['shard/native/raw.jsonl']['end_exclusive'] == 14714549
index = json.loads((OLD / 'official-index.json').read_text())
official = json.loads(OFFICIAL.read_text())
artifact = next(x for x in official['artifacts'] if x['id'] == NEW_ID)
assert artifact['size_in_bytes'] == 134200
assert artifact['digest'] == 'sha256:65aeb54e3b4ff2fbda73ebfd57a1cd9121d54c692e5c89781931e578f86f5099'
assert [x['index'] for x in index['artifacts']] == [7]
assert [x['artifact']['id'] for x in index['artifacts']] == [11658151472]
index['artifacts'] = [{'kind': 'checkpoint', 'index': 8, 'artifact': artifact, 'run_attempt': 1,
    'zip_path': str(ROOT / 'round39-diagnostic-original-artifacts/p8-100k-diagnostic-progress-38012409915-1-08-original.zip'),
    'official_original_reference': {'path': str(OFFICIAL), 'sha256': sha(OFFICIAL)}}]
index['time_boundary'] = 'Run identity and prior job status remain historical snapshots, not current diagnostic status. New08 metadata is the 2026-10-10 03:40:12 UTC official observation. This frozen-reader call receives only new08; prior00-07 remain small-report/manifest dependencies for a separately labelled derived continuity bridge, not new receptions or ZIP rereads. Later PR merge does not change fixed9cc6 source.'
index['new_artifact_observed_at'] = '2026-10-10 03:40:12 UTC'
index['continuity_dependency'] = {'artifact_ids': OLD_IDS,
    'previous_report': str(OLD / 'checkpoint07-prefix-review.json'),
    'sha256': sha(OLD / 'checkpoint07-prefix-review.json'),
    'accepted_prefix_bytes': 14714549, 'new_artifact_ids': [NEW_ID]}
save('official-index.json', index)
argv = ['python3', '-B', str(READER), '--binding', str(BINDING), '--official-index', str(OUT / 'official-index.json'), '--output', str(OUT / 'reader')]
start, tick = datetime.datetime.now(datetime.timezone.utc).isoformat(), time.monotonic()
with (OUT / 'reader.stdout').open('xb') as o, (OUT / 'reader.stderr').open('xb') as e:
    r = subprocess.run(argv, cwd=ROOT, stdout=o, stderr=e, check=False)
save('reader.execution.json', {'argv': argv, 'cwd': str(ROOT), 'started_utc': start,
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'duration_seconds': time.monotonic() - tick, 'exit_code': r.returncode,
    'stdout_sha256': sha(OUT / 'reader.stdout'), 'stderr_sha256': sha(OUT / 'reader.stderr'),
    'reader_sha256': sha(READER), 'new_artifact_ids': [NEW_ID], 'continuity_old_artifact_ids': OLD_IDS,
    'validate_build_calls': 0, 'validate_shard_calls': 0, 'inspect_raw_calls': 0, 'ELF_calls': 0,
    'new_downloads': 0, 'old_ZIPs_read_by_this_call': 0, 'prior_ACK_reader_validation': 'not performed by this new-only call; see separately derived bridge', 'accepted_samples': 0, 'task_credit': 0})
print(json.dumps({'reader_exit': r.returncode, 'output': str(OUT)}))
raise SystemExit(r.returncode)
