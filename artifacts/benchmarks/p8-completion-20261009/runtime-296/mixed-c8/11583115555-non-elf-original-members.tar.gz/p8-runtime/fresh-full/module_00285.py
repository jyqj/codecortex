def stable_00285():
    return 285
