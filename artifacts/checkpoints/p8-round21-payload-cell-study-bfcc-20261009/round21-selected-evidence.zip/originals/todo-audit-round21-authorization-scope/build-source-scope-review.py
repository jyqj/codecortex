#!/usr/bin/env python3
"""Quote already retained task/protocol text. No tests, workload or network calls."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent
PROTO=Path('/dev/shm/todo-audit-pr-refresh-175-179/protocol')
DEFS=Path('/dev/shm/todo-audit-round17-original-ten-critical-path/current-main-original-ten-definition-extract.json')
def ident(p):
 b=p.read_bytes();return {'local_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def quote(file,start,end):
 p=PROTO/file;ls=p.read_text().splitlines();return {'repository_path':'docs/roadmap/code-index-v2/'+file,'retained_copy':ident(p),'line_start':start,'line_end':end,'verbatim':'\n'.join(ls[start-1:end])}
def save(n,x):(B/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
quotes={
 'immutable_outputs':quote('P8-SCALE.md',65,67),
 'release_N':quote('P8-SCALE.md',29,29),
 'incomplete_closure':quote('P8-SCALE.md',45,45),
 'exit_boundaries':quote('P8-SCALE.md',81,89),
 'old_shard_arrangement':quote('P8-SCALE.md',101,110),
 'old_30_shards':quote('P8-SCALE.md',128,138),
 'fixed_driver_identity':quote('P8-SCALE.md',145,147),
 'aggregate_full_population':quote('P8-SCALE.md',149,156),
 'scale_separate_from_ordinary_PR':quote('P8-SCALE.md',184,189),
 'new_explicit_protocol_preserves_old_failures':quote('P8-SCALE.md',199,210),
 'capacity_protocol_parameters':quote('P8-SCALE.md',212,234),
 'capacity_strata':quote('P8-SCALE.md',250,256),
 'first_cohort_failure':quote('P8-SCALE.md',261,276),
 'new_complete_execution_identity':quote('P8-SCALE.md',278,281),
 'input_lock':quote('09-BENCHMARK.md',128,136),
 'design_sampling_lock':quote('09-BENCHMARK.md',169,177),
 'registered_gate':quote('09-BENCHMARK.md',181,185),
 'PR_nightly_release_split':quote('09-BENCHMARK.md',187,191),
 'V20':quote('06-VALIDATION.md',42,42),
 'G8_and_engineering_scope':quote('06-VALIDATION.md',58,67),
}
d=json.loads(DEFS.read_bytes());tasks={t['id']:t for t in d['tasks']}
selected={k:{f:tasks[k][f] for f in ['id','status','depends_on','steps','acceptance','validations']+(['acceptance_subgates'] if k=='P8-005' else [])} for k in ['P8-005','P8-006','P8-008']}
save('verbatim-existing-source-extracts.json',{'provenance':'Existing cached repository originals plus previously materialized task semantic extract; not a new fresh-main GET. Task materialization is parsed/reserialized, not original Git blob bytes.','protocol_quotes':quotes,'task_field_source':ident(DEFS),'task_field_excerpts':selected})
report={
 'schema_version':1,'scope':'Bounded authorization/acceptance/engineering-merge interpretation of already retained sources only',
 'user_instruction':{'verbatim':'管理一下pr，然后多轮multi subagent去继续推进todo。至少推10个todo到完全完成。每一轮都告诉我还剩余多少todo。',
  'source':'Visible initiating user message; whitespace normalized only','finding':'No explicit blanket prohibition on future scale studies, reruns, budgets, N or workload, and no requirement to ask the user for every new independent run. This does not authorize rewriting original acceptance or pretending failures passed.'},
 'delegation_instructions':[
  {'verbatim':'禁止源码修改、commit/push/新study。','origin':'Root delegated actual fixed Mac G source verification scope','applicability':'This subagent operation and named frozen sources; not a repository-wide user approval requirement.'},
  {'verbatim':'不要运行CLI或测试。','origin':'Current root G6B two-binding mechanical generation task','applicability':'Binding preparation only; this agent must not launch execution. Root may separately assign/authorize necessary execution.'},
  {'verbatim':'不新GET不执行，不修改ledger。','origin':'Current root source-scope review task','applicability':'Read retained sources and write this interpretation only; not a global ban on future authorized work.'}],
 'AGENTS':{'current_retained_original_available':False,'scope_of_absence':'No readable AGENTS copy found in the known own/peer caches consulted; old Mac merge-boundary artifacts currently unavailable.',
  'conclusion':'No prohibition is attributed to AGENTS without its original text. This is not a claim that the repository has no AGENTS or that an unread rule does not exist.'},
 'operation_boundaries':[
  {'operation':'Overwrite/relabel an existing run or failed primary','original_sources':['immutable_outputs','aggregate_full_population','new_complete_execution_identity'],
   'answer':'Prohibited by immutable-evidence/input-lock and aggregate rules. Preserve failure, source identity and original denominator.'},
  {'operation':'Automatically rerun a failed primary or fill skipped145 in that same study','original_sources':['first_cohort_failure','aggregate_full_population'],
   'answer':'The selected workflow explicitly stops after any failed first shard, does not automatically retry, and rejects missing/failed/duplicate records. No infrastructure exemption or replacement entitlement was found. Code ability to rerun/overwrite artifacts is not protocol permission.'},
  {'operation':'Launch a distinct future fixed-source study','original_sources':['new_complete_execution_identity','immutable_outputs','scale_separate_from_ordinary_PR'],
   'answer':'No blanket prohibition or universal new-user-approval requirement in these sources. L278 explicitly describes each new complete execution. Use a new immutable identity/output and its own source/build receipts; previous failures remain. Current subagent no-execution delegation still binds this task.'},
  {'operation':'Change N/budget/workload of an already locked study or silently lower the existing done contract','original_sources':['input_lock','capacity_protocol_parameters','first_cohort_failure','aggregate_full_population','registered_gate'],
   'answer':'Not permitted. Existing C3ff/Gc8 registration and capacity_v1 requirements remain fixed. The resulting changed population cannot replace or repair the original primary study or masquerade as the original acceptance.'},
  {'operation':'Design a different future diagnostic/profile','original_sources':['design_sampling_lock','new_explicit_protocol_preserves_old_failures','capacity_protocol_parameters'],
   'answer':'Not prohibited globally: the original docs themselves retain old plans and describe an explicit separately registered capacity protocol. This is not an authorization to reduce the currently accepted completion standard after observing failure. A new profile needs an honest separate manifest/method/scope; no existing lower-N complete method was found, so it cannot currently substitute for005/006done.'},
  {'operation':'Paid/private/live provider work','original_sources':['PR_nightly_release_split','G8_and_engineering_scope'],
   'answer':'Explicit separate/manual enabling and authorization appear here for paid/private/real-provider scope; do not transplant that requirement to every local synthetic scale execution.'}],
 'task_acceptance_answers':{
  'P8_005_row':'steps: fixedseed/release1k/5k/10k/50k/100k and chunk/edge/vector; acceptance requires honest comparable workload and related old-feature regression; full five-scale acceptance_subgate=open. No literal150,1500 orN>=30 in the task fields.',
  'P8_006_row':'steps: no-op/body/API/config/batch and over-budget closure; phase counts; acceptance: attributable timing and full parity after closure, explicit incomplete status; dependenciesP7-020/P8-001/P8-005; validationsV07,V20. No literal150 orN>=30 in the task fields.',
  'N30_origin':'P8-SCALE L29 and103 explicitly enforce release at least30.09 §9 L173 says starting per-layer30, formal-tail200 and originalP0 resource locking; cannot equate every task with200 or stablep99. Current chosen release method remainsN>=30; no accepted alternative lower lock is present.',
  '150_origin':'P8-SCALE capacity_v1 L217+267–274:5scales×30single-rep shards=150; all150+1500 are required for these registered studies. Same document L128–138 describes earlier5×6=30shards withN30, proving150GitHub jobs is not a universal task-row requirement.',
  'what_done_still_requires':'Complete trustworthy original task population and relevantregression under its applicable locked method. Partial sixparities/1002builds/4successfulshards cannot satisfy that. A valid complete combined study may support005 and006; do not add a duplicate006study.'},
 'PR180_engineering_merge':{
  'answer':'Original scale failure/open005006 does not by itself prohibit ordinary engineering integration. Keep actual engineering/source/related-correctness requirements and review rules; do not label the integration fullscale/G8/release/taskdone.',
  'direct_support':['P8-SCALE L184–189:ordinaryPRdoesnotautomaticallytriggermatrix;completionstillrequiresactualrecords+independenttaskacceptance.',
   '09-BENCHMARK L189:PRfast vsNightly vsRelease;100k/soak/platform/holdout assignedRelease.',
   '06-VALIDATION L65:knownhardcorrectness/compile/basic-test/input-lock failures block; openperformancepopulationisnot evidence those engineering checks passed.',
   '06-VALIDATION L58/G8 andL61 distinguish whole-release gate and engineering integration scope.'],
  'current_state_limit':'Root reports actualG6B normalFF inPR180 and new CI pending. This report does not fresh-read statuses or branch protection and is not an instruction to merge while its actual required engineering checks are unmet.',
  'historical_support_not_reread':'Earlier nonauthor review reported07-ROLLOUT L56 puts100k innightly/release, not ordinaryPR. The old Mac original is currently unavailable, so this is contextual prior finding, not a newly verified verbatim quote.'},
 'counts':{'done':163,'remaining':29,'newly_done':0},
 'actions_performed':{'new_GET':0,'product_or_test_or_CLI_execution':0,'remote_write':0,'ledger_change':0},
 'important_non_equivalence':'A new independently authorized study is different from rerunning/replacing a failed primary in an already locked study. Engineering merge is different from original TODO or release certification. No global approval flow is invented from task-specific agent limits.'}
save('authorization-acceptance-merge-boundary-review.json',report)
md='''# 原授权、验收与工程合并边界核查

没有从现有原文找到“所有未来 scale 实验均禁止，或每次必须再向用户请求许可”的规则。禁止改写原研究、降低原验收，与禁止一切未来独立实验，是不同命题。

| 问题 | 原文来源与范围 | 结论 |
|---|---|---|
| 用户有没有禁止新研究？ | 用户原请求是管理PR并继续推进至少10项TODO，没有全局禁令。根代理多次对本子任务说“不要dispatch/新study”“不要运行CLI或测试”。 | 后者是当前委派边界，我不能自行启动；不能转述成用户要求所有未来新实验再次许可。 |
| AGENTS有没有额外禁令？ | 现有可读缓存未找到AGENTS原件；旧Mac原件暂不可读。 | 不虚构来自AGENTS的禁令，也不反向声明仓库不存在规则。 |
| 原run能否修改、替换失败样本？ | P8-SCALE L67“原 run 不覆盖，旧失败不重写”；L149–154拒绝缺片/截断/失败/不同锁；L272–276首片失败停145，非自动重跑。 | 不能。C3ff/Gc8失败、来源和分母必须保留，不能借新输出补位旧primary。 |
| 能否另起一个未来完整研究？ | L278–281“每次完整执行应先固定最终的完整Git SHA”，新提交另建构建收据，保留旧失败；L184–185按明确dispatch/label触发。 | 原文没有永久禁令，也没写每次必须用户再批准。应独立新identity/output/source/build，并满足实际委派授权。 |
| 能否改已锁N/预算/工作量？ | 09 L130把timeout/budget等放入输入锁；P8-SCALE L212–222及267–274固定capacity_v1参数；L250–256保留源/二进制/配置和全部检查。 | 不可更改已锁研究，也不可悄悄降低现有done标准。新的不同profile只能另立方法、范围和原件，不能重标旧研究成功。 |
| 005/006任务字段是否直接写150/N30？ | 005 steps要求固定seed/release五容量和chunk/edge/vector，full_scale子门open；006要求增量/batch/fanout/归因/闭包后fullparity。二者字段无字面150/N30。 | 不能把150GitHubjobs冒称任务行原文；完整五容量和增量总体仍是实质原要求。 |
| N30与150到底来自哪里？ | P8-SCALE L29/103硬性release≥30；capacity_v1 L217及267–274固定5×30片；同文L128–138旧方案是5×6片仍N30。 | 当前选定release方法不能降N；150是已锁capacity协议的分片安排，不是所有未来合理执行布局的普遍定义。 |
| scale失败时能否工程合并PR180？ | 09 L189分PRfast/Nightly/Release；P8-SCALE L184–189将普通PR与大矩阵/任务验收分开；06 L65仍阻断真实硬正确性、编译、基础测试等失败。 | 可以在实际所需工程CI/source/相关回归与审查满足的范围内集成，保留005/006open和失败。不能把merge称规模、任务或G8通过。 |

当前G6B新CI仍是root报告pending，本报告没有fresh读CI或分支保护，不授权绕过实际所需工程检查。普通工程合并不是关闭原任务；仅6个阶段parity或1002build不能变成完整总体。付费/私有源/真实provider的显式启用要求见09 L189，不能泛化成所有本地合成实验的新许可流程。

精确逐行原文与task字段放在verbatim-existing-source-extracts.json；解释和来源类型放在authorization-acceptance-merge-boundary-review.json。仅读已存在材料，未新GET、未运行产品/测试/CLI、未修改账本。仍163done/29remaining。
'''
(B/'boundary-summary.md').write_text(md)
print(json.dumps({'scope':'existing_sources_only','quotes':len(quotes),'task_rows':len(selected),'new_GET':0,'tests':0,'ledger_changes':0}))
