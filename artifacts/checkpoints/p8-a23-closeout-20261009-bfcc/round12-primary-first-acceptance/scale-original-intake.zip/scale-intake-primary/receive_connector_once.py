import datetime, hashlib, importlib.util, json, re, sys, traceback, urllib.error, urllib.request
from pathlib import Path

BASE = Path(__file__).resolve().parent
OUT = BASE / 'raw/37902429727/11603522248/attempt-01'
SCRIPT = BASE / 'published-preparation/intake_once.v2.py'
assert hashlib.sha256(SCRIPT.read_bytes()).hexdigest() == '61f4ae48bc84dbc9f90862a80d06a8268ec4aa93f83c75582b716bc32f4c3369'
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('unchanged_receiver_v2', SCRIPT)
v2 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v2)

def put(name, value):
    v2.write_new(OUT / name, value)

def bytes_new(name, data):
    with (OUT / name).open('xb') as f:
        f.write(data)

record = {'platform': 'primary Linux x86_64; GitHub connector download reference then HTTPS GET', 'receiver_pure_function_sha256': v2.sha(SCRIPT), 'started_at': v2.utc(), 'automatic_retry': False, 'sleep_or_poll_loop': False, 'dispatch_or_rerun': False, 'measurement_or_todo_credit': False, 'status': 'started'}
code = 1
try:
    inputs = json.loads((OUT / 'connector-inputs.json').read_text())
    binding = v2.checked_binding(BASE / 'actual-run-37902429727/receiver-binding.actual-run.json')
    before_bytes = inputs['run_before']['content'].encode()
    bytes_new('run-before.raw.json', before_bytes)
    v2.verify_run(json.loads(before_bytes), binding)
    list_bytes = inputs['artifact_list']['content'].encode()
    bytes_new('artifacts-list.raw.json', list_bytes)
    matches = [x for x in json.loads(list_bytes)['artifacts'] if x['id'] == inputs['artifact_id']]
    assert len(matches) == 1
    meta = matches[0]
    put('github-artifact-derived-metadata.json', meta)
    origin = meta['workflow_run']
    assert origin['id'] == binding['run_id'] and origin['head_sha'] == binding['source_G']
    assert not meta['expired']
    assert meta['name'] == 'p8-scale-build-' + str(binding['run_id'])
    record['file_reference'] = inputs['file_reference']
    record['artifact_id'] = meta['id']
    url = sys.argv[1]
    assert url.startswith(inputs['file_reference']['download_origin'] + inputs['file_reference']['download_path'] + '?')
    part = OUT / 'original.zip.part'
    with part.open('xb') as output:
        try:
            with urllib.request.urlopen(urllib.request.Request(url, method='GET'), timeout=120) as response:
                put('download-http-response.json', {'status': response.status, 'headers': list(response.headers.raw_items())})
                while True:
                    block = response.read(1024 * 1024)
                    if not block:
                        break
                    output.write(block)
        except urllib.error.HTTPError as error:
            bytes_new('download-http-error.body', error.read())
            put('download-http-error.json', {'status': error.code, 'reason': str(error.reason), 'headers': list(error.headers.raw_items())})
            raise
    original = OUT / 'original.zip'
    part.rename(original)
    digest, verified = v2.verify_zip_identity(original, meta, OUT)
    members = v2.extract_original(original, OUT / 'extracted')
    put('members.json', {'members': members, 'total_uncompressed_bytes': sum(x.get('bytes', 0) for x in members)})
    assert v2.sha(original) == digest
    record.update(status='zip_extracted_pending_post_run_identity', original_zip_sha256=digest, official_digest_verified=verified, member_count=len(members), semantic_validation='not executed')
    code = 0
except Exception as error:
    record.update(status='failed_retained', error=repr(error))
    traceback.print_exc()
record.update(finished_at=v2.utc(), actual_controller_exit=code)
put('connector-transport-receipt.json', record)
print(json.dumps({'status': record['status'], 'exit_code': code, 'output': str(OUT)}))
sys.exit(code)
