def stable_00130():
    return 130
