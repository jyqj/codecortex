def stable_00450():
    return 450
