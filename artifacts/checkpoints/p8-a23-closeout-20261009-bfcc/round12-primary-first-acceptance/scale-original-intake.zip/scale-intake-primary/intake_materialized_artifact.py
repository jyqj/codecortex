import hashlib,importlib.util,json,re,sys,traceback
from pathlib import Path
BASE=Path(__file__).resolve().parent
SCRIPT=BASE/'published-preparation/intake_once.v2.py'
assert hashlib.sha256(SCRIPT.read_bytes()).hexdigest()=='61f4ae48bc84dbc9f90862a80d06a8268ec4aa93f83c75582b716bc32f4c3369'
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('receiver_v2_unchanged',SCRIPT);v2=importlib.util.module_from_spec(spec);spec.loader.exec_module(v2)
artifact_id=int(sys.argv[1]);payload_path=Path(sys.argv[2]);run_path=Path(sys.argv[3])
payload=json.loads(payload_path.read_text())
descriptor=next(x for x in payload['descriptors'] if x['artifact_id']==artifact_id)
OUT=BASE/'raw/37902429727'/descriptor['relative_directory']
receipt={'started_at':v2.utc(),'artifact_id':artifact_id,'receiver_v2_sha256':v2.sha(SCRIPT),'transport':'Root authorized prepare_materialize workspace placement; original resolved GitHub file_id','file_id':descriptor['file_id'],'new_download_requested':False,'measurement_or_todo_credit':False,'semantic_validation':'pending'}
code=1
try:
 binding=v2.checked_binding(BASE/'actual-run-37902429727/receiver-binding.actual-run.json')
 run_raw=json.loads(run_path.read_text())['content'].encode()
 v2.verify_run(json.loads(run_raw),binding)
 matches=[x for x in json.loads(payload['artifact_list']['content'])['artifacts'] if x['id']==artifact_id]
 assert len(matches)==1
 meta=matches[0];origin=meta['workflow_run']
 assert origin['id']==binding['run_id'] and origin['head_sha']==binding['source_G'] and not meta['expired']
 assert re.fullmatch(r'p8-scale-(?:build|matrix|(?:shard|capacity)-(?:1000|5000|10000|50000|100000)-(?:[0-9]|[12][0-9]))-'+str(binding['run_id']),meta['name'])
 original=OUT/descriptor['file_name']
 digest,verified=v2.verify_zip_identity(original,meta,OUT)
 members=v2.extract_original(original,OUT/'extracted')
 v2.write_new(OUT/'members.json',{'members':members,'total_uncompressed_bytes':sum(x.get('bytes',0) for x in members)})
 assert v2.sha(original)==digest
 v2.write_new(OUT/'github-artifact-derived-metadata.json',meta)
 with (OUT/'run-after-materialize.raw.json').open('xb') as f:f.write(run_raw)
 receipt.update(status='transport_received',zip_sha256=digest,github_digest_verified=verified,member_count=len(members),total_uncompressed_bytes=sum(x.get('bytes',0) for x in members),post_materialize_run_identity_equal=True)
 code=0
except Exception as error:
 receipt.update(status='failed_retained',error=repr(error));traceback.print_exc()
receipt.update(finished_at=v2.utc(),actual_exit=code)
v2.write_new(OUT/'materialized-intake-receipt.json',receipt)
print(json.dumps(receipt));sys.exit(code)
