def stable_00221():
    return 221
