def stable_00294():
    return 294
