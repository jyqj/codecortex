from pathlib import Path
import hashlib,json,zipfile,subprocess,base64,datetime,sys,time
root=Path.cwd();out=root/'artifacts/benchmarks/p8-bfccb8494ba0/native-public-api-merge-P-c92e-evidence'
(out/'package-controller.py').write_bytes(Path(sys.argv[0]).read_bytes())
receipts=json.loads((out/'controls-progress.json').read_text());assert len(receipts)==6
assert all(r['exit_code']==0 and r['nonzero_test_check_passed'] for r in receipts)
assert sum(s['passed'] for r in receipts for s in r['test_summaries'])==29
assert all(r['source_P']=='c92eb5ac7ece70d1f62271d7e2dacac513c285b5' and r['before']['entries']==1245 and r['after']['entries']==1245 for r in receipts)
files=[]
for p in sorted(out.iterdir()):
 if p.is_file():
  b=p.read_bytes();files.append({'path':p.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={'schema_version':1,'source_P':'c92eb5ac7ece70d1f62271d7e2dacac513c285b5','scope':'complete preparation and six actual native engineering controls, 29 passed tests, workspace fmt and cc-db strict Clippy exit0; exact 1245 selected inputs before/after; cached target, no cold/performance or original Gc8 sample transfer','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files}
mb=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
zip_path=out.parent/'native-public-api-merge-P-c92e-controls.zip';assert not zip_path.exists()
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in files:z.writestr(f['path'],(out/f['path']).read_bytes())
 z.writestr('archive-manifest.json',mb)
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None and len(z.infolist())==len(files)+1
 for f in files:
  b=z.read(f['path']);assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
raw=zip_path.read_bytes();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();text=base64.b64encode(raw).decode()
transport={'zip_path':str(zip_path),'zip_bytes':len(raw),'zip_sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'members':len(files)+1,'selected_files':len(files),'expanded_bytes':sum(f['bytes'] for f in files)+len(mb),'base64_chars':len(text),'base64_sha256':hashlib.sha256(text.encode()).hexdigest()}
for label,content,encoding in [('binary',text,'base64'),('base64-transport',text,'utf-8')]:
 body=json.dumps({'content':content,'encoding':encoding}).encode()
 cmd=['/opt/homebrew/bin/gh','api','-X','POST','repos/jyqj/codecortex/git/blobs','--input','-']
 start=time.monotonic();p=subprocess.run(cmd,input=body,capture_output=True)
 transport[label]={'command':cmd,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}
 if p.returncode!=0:
  print(p.stderr.decode(errors='replace'));(out.parent/'native-public-api-merge-P-c92e-transport.json').write_text(json.dumps(transport,indent=2)+'\n');sys.exit(p.returncode)
 response=json.loads(p.stdout);transport[label]['sha']=response['sha']
 expected=blob if encoding=='base64' else hashlib.sha1(b'blob '+str(len(text)).encode()+b'\0'+text.encode()).hexdigest()
 assert response['sha']==expected,(label,response,expected)
 (out.parent/'native-public-api-merge-P-c92e-transport.json').write_text(json.dumps(transport,indent=2)+'\n')
print(json.dumps(transport),flush=True)
