#!/usr/bin/env python3
"""Read-only identity audit; never imports or executes repository code."""
import ast
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
def read(path):
    return json.loads((ROOT / path).read_bytes())
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def oid(raw, kind='blob'):
    return hashlib.sha1(f'{kind} {len(raw)}\0'.encode()+raw).hexdigest()
def tree_oid(rows, prefix=''):
    children = [e for e in rows if e['path'].startswith(prefix) and '/' not in e['path'][len(prefix):]]
    children.sort(key=lambda e:(e['path'][len(prefix):]+('/' if e['type']=='tree' else '')).encode())
    payload=b''.join(f"{e['mode'].lstrip('0')} {e['path'][len(prefix):]}\0".encode()+bytes.fromhex(e['sha']) for e in children)
    return oid(payload,'tree')

maps=read('input-official-file-maps.json')
tree_checks=[]
for p in sorted((ROOT/'official').glob('*.json')):
    j=json.loads(p.read_bytes())
    if not isinstance(j,dict) or not isinstance(j.get('tree'),list):
        continue
    assert not j.get('truncated',False), p
    actual=tree_oid(j['tree'])
    assert actual==j['sha'], (str(p),actual,j['sha'])
    nested=0
    if p.name.startswith('subtree-') or p.name=='shared-tests-recursive-tree.json':
        for e in j['tree']:
            if e['type']=='tree':
                assert tree_oid(j['tree'],e['path']+'/')==e['sha'], (str(p),e['path'])
                nested+=1
    tree_checks.append({'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p.read_bytes()),'tree':actual,'nested_trees_rehashed':nested})

result={'scope':'readonly_received_source_and_metadata_only','repository_code_executed':False,'tree_checks':tree_checks,'heads':{}}
for key in ('p175_old','p175_new','p179_old','p179_new'):
    local=ROOT/'source'/key
    guard_raw=(local/'verify_reviewed_source_v15.py').read_bytes()
    reg_raw=(local/'reviewed-source-registry-v15.json').read_bytes()
    guard=ast.parse(guard_raw)
    pins={node.targets[0].id:ast.literal_eval(node.value) for node in guard.body if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and node.targets[0].id in ('BASE','PRODUCT','REVIEW','REVIEW_PATH','REGISTRY_SHA256')}
    reg=json.loads(reg_raw)
    assert sha(reg_raw)==pins['REGISTRY_SHA256']
    assert reg['base_source']==pins['BASE'] and reg['product_source']==pins['PRODUCT'] and reg['review_source']==pins['REVIEW']
    for path,raw in [('scripts/verify_reviewed_source_v15.py',guard_raw),('scripts/reviewed-source-registry-v15.json',reg_raw)]:
        assert oid(raw)==maps[key][path]['sha'] and len(raw)==maps[key][path]['size']
    product={p for p in maps[key] if p.startswith('crates/') or p in ('Cargo.toml','Cargo.lock')}
    validation={p for p in maps[key] if p.startswith(('scripts/','.github/workflows/','tests/source_integrity/')) and p not in ('scripts/verify_reviewed_source_v15.py','scripts/reviewed-source-registry-v15.json','.github/workflows/ci.yml') and not ('__pycache__' in Path(p).parts and p.endswith('.pyc'))}
    assert product==set(reg['complete_inputs']) and validation==set(reg['validation_inputs'])
    row={'pins':pins,'registry_bytes':len(reg_raw),'registry_sha256':sha(reg_raw),'guard_bytes':len(guard_raw),'guard_sha256':sha(guard_raw),'product_count':len(product),'validation_count':len(validation),'delta_count':len(reg['delta'])}
    if key.endswith('_new'):
        review_raw=(local/'independent-source-review.json').read_bytes()
        r=json.loads(review_raw)
        assert sha(review_raw)==reg['review_sha256']
        assert r['source']==pins['PRODUCT'] and r['base']==pins['BASE']
        assert r['complete_inputs']==reg['complete_inputs'] and r['validation_inputs']==reg['validation_inputs'] and r['paths']==reg['delta']
        assert sha(json.dumps(r['complete_inputs'],sort_keys=True,separators=(',',':')).encode())==r['source_manifest_sha256']
        for domain,expected in [('source',product),('validation',validation)]:
            inv=r['actual_input_mode_blob_inventory'][domain]
            assert set(inv)==expected
            for path,e in inv.items():
                g=maps[key][path]
                assert (e['mode'],e['type'],e['blob'],e['bytes'])==(g['mode'],g['type'],g['sha'],g['size']),path
        p=read(f'official/{key}-PRODUCT-commit.json');rv=read(f'official/{key}-REVIEW-commit.json');g=read(f'official/{key}-commit.json')
        assert p['sha']==pins['PRODUCT'] and rv['sha']==pins['REVIEW']
        assert [e['sha'] for e in rv['parents']]==[p['sha']] and [e['sha'] for e in g['parents']]==[rv['sha']]
        assert r['source_tree']==p['tree']['sha'] and r['source_parents']==[e['sha'] for e in p['parents']]
        old=(ROOT/'source'/key.replace('_new','_old')/'verify_reviewed_source_v15.py').read_text()
        normalize=lambda s: re.sub(r'^(PRODUCT|REVIEW|REVIEW_PATH|REGISTRY_SHA256)\s*=.*$',r'\1 = <PIN>',s,flags=re.M)
        assert normalize(guard_raw.decode())==normalize(old)
        row.update(review_bytes=len(review_raw),review_sha256=sha(review_raw),review_git_blob=oid(review_raw),P_tree=p['tree']['sha'],P_parents=[e['sha'] for e in p['parents']],R_tree=rv['tree']['sha'],G=g['sha'],G_tree=g['tree']['sha'],canonical_maps_match_actual_complete_domains=True,source_manifest_sha256=r['source_manifest_sha256'],guard_only_four_pin_changes=True)
    result['heads'][key]=row

result['old_to_new_nonartifact_delta']={}
for pr in (175,179):
    a,b=maps[f'p{pr}_old'],maps[f'p{pr}_new']
    result['old_to_new_nonartifact_delta'][str(pr)]=[{'path':p,'before':a.get(p),'after':b.get(p)} for p in sorted(a.keys()|b.keys()) if (a.get(p,{}).get('sha'),a.get(p,{}).get('mode'))!=(b.get(p,{}).get('sha'),b.get(p,{}).get('mode'))]
    assert len(result['old_to_new_nonartifact_delta'][str(pr)])==6
result['current_head_job_snapshot']={}
for pr in (175,179):
    prs=read(f'official/pr-{pr}-at-093400.json')
    runs=read(f'official/pr-{pr}-current-head-runs.json')
    jobs=[]
    for r in runs['workflow_runs']:
        assert r['head_sha']==prs['head']['sha'] and r['run_attempt']==1
        js=read(f"official/run-{r['id']}-jobs-at-093400.json")
        assert js['total_count']==len(js['jobs'])
        assert all(j['head_sha']==prs['head']['sha'] for j in js['jobs'])
        jobs.extend({'run_id':r['id'],'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'head_sha':j['head_sha']} for j in js['jobs'])
    counts={k:sum((j['conclusion'] if j['status']=='completed' else j['status'])==k for j in jobs) for k in ('success','failure','cancelled','in_progress','queued')}
    result['current_head_job_snapshot'][str(pr)]={'observed_utc':'2026-10-09T09:34:00Z','head':prs['head']['sha'],'base_at_observation':prs['base']['sha'],'state':prs['state'],'merged':prs['merged'],'merged_at':prs['merged_at'],'merged_by':prs['merged_by']['login'],'merge_commit':prs['merge_commit_sha'],'materialized_jobs':len(jobs),'counts':counts,'jobs':jobs,'all_checks_passed':False}

(ROOT/'computed-identity-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'passed_readonly_identity_comparisons','tree_objects':sum(1+e['nested_trees_rehashed'] for e in tree_checks),'new_heads':{k:{x:v for x,v in d.items() if x in ['product_count','validation_count','delta_count','review_sha256','registry_sha256']} for k,d in result['heads'].items() if k.endswith('_new')},'current_checks':{k:v['counts'] for k,v in result['current_head_job_snapshot'].items()}},ensure_ascii=False))
