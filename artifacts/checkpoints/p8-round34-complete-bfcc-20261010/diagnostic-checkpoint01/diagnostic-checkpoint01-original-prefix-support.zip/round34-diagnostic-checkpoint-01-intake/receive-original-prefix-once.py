"""First reception of diagnostic checkpoint01; checkpoint00 is continuity input.

No build ZIP, original validator, ELF or workload is executed. The unchanged
frozen reader rereads the already accepted checkpoint00 to bind ACK/offsets.
"""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'round34-diagnostic-checkpoint-01-intake/attempt01'
OLD = ROOT / 'round33-diagnostic-checkpoint-00-intake/attempt01'
OFFICIAL = ROOT / 'round34-diagnostic-checkpoint01-official-originals.json'
BINDING = ROOT / 'round32-100k-diagnostic-intake-bound-9cc6-run38012409915/binding.json'
READER = ROOT / 'round32-100k-diagnostic-intake-preparation/read-original-diagnostic.py'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save(name, value):
    with (OUT / name).open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

OUT.mkdir(parents=True, exist_ok=False)
assert sha(READER) == 'ae7945e5f7150b350ae856a1fd22d7ad92e157c74ae73c8ab3e3799a857bca23'
assert sha(BINDING) == '12819cd48434ac181d4aaac0eb020ba936c9a48e39d02683766f5dd5f07c17cb'
index = json.loads((OLD / 'official-index.json').read_text())
official = json.loads(OFFICIAL.read_text())
artifact = next(x for x in json.loads(official['original']['structuredContent']['content'])['artifacts'] if x['id'] == 11655694522)
assert artifact['size_in_bytes'] == 133079 and artifact['digest'] == 'sha256:c95db6ac09b99d1f91043bd4a96a55965999da4dfbb95d932bdad4de85165b3b'
index['artifacts'].append({'kind': 'checkpoint', 'index': 1, 'artifact': artifact, 'run_attempt': 1,
    'zip_path': str(ROOT / 'round34-diagnostic-original-artifacts/p8-100k-diagnostic-progress-38012409915-1-01-original.zip'),
    'official_original_reference': {'path': str(OFFICIAL), 'sha256': sha(OFFICIAL)}})
index['time_boundary'] = 'Original run identity and prior job status retained from checkpoint00 index, not asserted current. New artifact index observed 01:54:42. Checkpoint00 is a previously accepted continuity dependency, not a new reception or sample.'
index['continuity_dependency'] = {'artifact_id': 11655358015, 'previous_report': str(OLD / 'checkpoint-prefix-review.json'),
    'sha256': sha(OLD / 'checkpoint-prefix-review.json'), 'new_artifact_ids': [11655694522]}
save('official-index.json', index)
argv = ['python3', '-B', str(READER), '--binding', str(BINDING), '--official-index', str(OUT / 'official-index.json'), '--output', str(OUT / 'reader')]
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
tick = time.monotonic()
with (OUT / 'reader.stdout').open('xb') as o, (OUT / 'reader.stderr').open('xb') as e:
    r = subprocess.run(argv, cwd=ROOT, stdout=o, stderr=e, check=False)
save('reader.execution.json', {'argv': argv, 'cwd': str(ROOT), 'started_utc': start,
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'duration_seconds': time.monotonic() - tick,
    'exit_code': r.returncode, 'stdout_sha256': sha(OUT / 'reader.stdout'), 'stderr_sha256': sha(OUT / 'reader.stderr'),
    'reader_sha256': sha(READER), 'new_artifact_ids': [11655694522], 'continuity_old_artifact_ids': [11655358015],
    'validate_build_calls': 0, 'validate_shard_calls': 0, 'inspect_raw_calls': 0, 'ELF_calls': 0,
    'new_downloads': 0, 'accepted_samples': 0, 'task_credit': 0})
print(json.dumps({'reader_exit': r.returncode, 'output': str(OUT)}))
raise SystemExit(r.returncode)
