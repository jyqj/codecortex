"""One materialized GW4 shard; unchanged receiver and original validate_shard.

Usage: python3 intake-original-shard-once.py DESCRIPTOR.json NEW_OUTPUT_DIRECTORY
No API, download, workload, retry, aggregate, or automatic acceptance-ledger update.
"""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import subprocess
import sys
import time

sys.dont_write_bytecode = True
BASE = Path('/workspace/scratch/bfccb8494ba0/GW4-original-build-intake')
ROOT = BASE / 'source-exact-GW4'
SOURCE = '008f1ec0ae16b9b6aff9f20d033b17b2219168f8'
RUN = 37982220020
RECEIVER = Path('/workspace/scratch/bfccb8494ba0/todo-audit-round25-50k-recovery/support/driver-reconstruction/intake_once.v2.py')
PINS = {
    str(RECEIVER): '61f4ae48bc84dbc9f90862a80d06a8268ec4aa93f83c75582b716bc32f4c3369',
    str(ROOT / 'scripts/p8_scale_matrix.py'): '116e8634bead6629a3ea411555dfcf0609c058a03c433acc37115be4ba3c8b85',
    str(ROOT / 'scripts/p7_build_identity.py'): '5003305105464936edf8f444fc0b93cd14a5d5f074dc650f16de2259e86f1cc5',
}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def child(descriptor_path, output):
    descriptor = json.loads(descriptor_path.read_text())
    save(output / 'descriptor.original.json', descriptor)
    run = descriptor['official_run']
    artifact = descriptor['official_artifact']
    assert run['id'] == RUN and run['run_attempt'] == 1 and run['head_sha'] == SOURCE
    assert artifact['id'] == descriptor['artifact_id'] and isinstance(artifact['id'], int)
    assert artifact['workflow_run']['id'] == RUN
    if artifact['workflow_run'].get('head_sha') is not None:
        assert artifact['workflow_run']['head_sha'] == SOURCE
    assert artifact['name'] == descriptor['expected_artifact_name']
    scale, repetition = descriptor['scale'], descriptor['repetition']
    assert scale in (1000, 5000, 10000, 50000, 100000) and type(repetition) is int and 0 <= repetition < 30
    original_zip = Path(descriptor['materialized_original_zip']).resolve(strict=True)
    actual_zip = {'path': str(original_zip), 'bytes': original_zip.stat().st_size, 'sha256': sha(original_zip)}
    official_digest = artifact.get('digest')
    actual_zip['official_digest'] = official_digest
    actual_zip['official_digest_verified'] = bool(official_digest and official_digest == 'sha256:' + actual_zip['sha256'])
    save(output / 'original-zip-receipt.json', actual_zip)
    assert actual_zip['bytes'] == artifact['size_in_bytes']
    if official_digest is not None:
        assert actual_zip['official_digest_verified']
    for path, expected in PINS.items():
        assert sha(path) == expected, path
    spec = importlib.util.spec_from_file_location('original_receiver', RECEIVER)
    receiver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(receiver)
    members = receiver.extract_original(original_zip, output / 'extracted')
    save(output / 'original-zip-members.json', members)
    sys.path.insert(0, str(ROOT / 'scripts'))
    import p8_scale_matrix as driver
    prior = json.loads((BASE / 'original-validation-attempt01/inputs-after.json').read_text())
    build_review = json.loads((BASE / 'original-validation-attempt01/independent-build-review.json').read_text())
    build = Path(build_review['retained_build_directory'])
    binary = build / 'p8-scale'
    record = json.loads((build / 'build.json').read_text())
    assert record == json.loads((BASE / 'original-validation-attempt01/original-validate-build-output.json').read_text())
    before = {'source': driver.source_snapshot(ROOT), 'observer': driver.driver_snapshot(ROOT),
              'build_inventory': driver.inventory(build), 'zip_sha256': sha(original_zip)}
    save(output / 'inputs-before.json', before)
    for key in ('source', 'observer', 'build_inventory'):
        assert before[key] == prior[key], key
    directories = [path.parent for path in (output / 'extracted').rglob('shard.json')]
    assert len(directories) == 1
    shard = directories[0]
    plan = json.loads((shard / 'registered-plan.json').read_text())
    assert plan['capacity_profile'] == 'scale_wide_dirty_v1'
    assert plan['files'] == [scale] and plan['shard'] == {'index': repetition, 'count': 30}
    result = driver.validate_shard(shard, record, binary, sha(build / 'build.json'))
    save(output / 'original-validate-shard-output.json', result)
    after = {'source': driver.source_snapshot(ROOT), 'observer': driver.driver_snapshot(ROOT),
             'build_inventory': driver.inventory(build), 'zip_sha256': sha(original_zip)}
    save(output / 'inputs-after.json', after)
    assert after == before
    save(output / 'independent-shard-intake-review.json', {
        'status': 'original_validate_shard_passed', 'source': SOURCE, 'run_id': RUN, 'run_attempt': 1,
        'artifact_id': artifact['id'], 'scale': scale, 'repetition': repetition,
        'capacity_profile': plan['capacity_profile'], 'original_function_calls': 1,
        'original_build_revalidated': False, 'new_workload_executions': 0,
        'original_binary_operations': 'original validate_shard --hash-file only',
        'source_input_count': before['source']['input_count'], 'inputs_unchanged': True,
        'measurement_count': len(result['measurements']), 'original_zip': actual_zip,
        'status_limit': 'one shard; no aggregate/release/TODO credit and no ledger mutation',
    })
    print(json.dumps({'status': 'original_validate_shard_passed', 'artifact_id': artifact['id'],
                      'scale': scale, 'repetition': repetition, 'measurements': len(result['measurements'])}))


def main():
    if len(sys.argv) == 4 and sys.argv[1] == '--child':
        child(Path(sys.argv[2]).resolve(strict=True), Path(sys.argv[3]).resolve(strict=True))
        return 0
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    descriptor = Path(sys.argv[1]).resolve(strict=True)
    output = Path(sys.argv[2]).resolve()
    output.mkdir(parents=True, exist_ok=False)
    command = [sys.executable, str(Path(__file__).resolve()), '--child', str(descriptor), str(output)]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    with (output / 'stdout').open('xb') as stdout, (output / 'stderr').open('xb') as stderr:
        process = subprocess.run(command, stdout=stdout, stderr=stderr, check=False)
    receipt = {'command': command, 'started_utc': started,
               'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'wall_seconds': time.monotonic() - clock, 'exit_code': process.returncode,
               'stdout_sha256': sha(output / 'stdout'), 'stderr_sha256': sha(output / 'stderr'),
               'descriptor_sha256': sha(descriptor), 'controller_sha256': sha(__file__)}
    save(output / 'receipt.json', receipt)
    print(json.dumps(receipt))
    return process.returncode


if __name__ == '__main__':
    raise SystemExit(main())
