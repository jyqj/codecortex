import sys,os,json,hashlib,subprocess,re
from pathlib import Path
sys.dont_write_bytecode=True
base=Path.cwd()
sys.path.insert(0,str(base/'todo-audit-round12/recovery-platform-Gc8'))
from provenance_adapter import SOURCE as source, CURRENT as current, artifact, observer_from_archive, COMMIT as commit, OUT as out, json_bytes
sys.path.insert(0,str(source/'scripts'))
from p8_cold_build import digest,verify_observer_archive
from p8_recovery import full_evidence_manifest,FAULT_TESTS
previous=json.loads((out/'historical-source-identity.json').read_text())
assert previous['input_count']==704 and previous['source_commit']=='277f2490fad3fa30f2812b5547bad033867c9ea5'
def observation(record,directory):
 assert record['status']=='passed' and type(record['exit_code']) is int and record['exit_code']==0
 assert json.loads((directory/'command.json').read_text())==record
 for n,h in record['logs_sha256'].items():assert digest(directory/n)==h
 return [json.loads(l) for l in (directory/'stdout.log').read_text().splitlines() if l.strip().startswith('{')]
def fault(record,directory):
 assert record['status']=='passed' and record['source']==current
 assert json.loads((directory/'test-receipt.json').read_text())==record
 messages=observation(record['build'],directory/'build')
 a=record['cargo_artifact'];assert a['reason']=='compiler-artifact' and a['profile']['test'] is True and messages.count(a)==1
 assert all(x in record['build']['command'] for x in ['--locked','--offline','--no-run'])
 assert any(m.get('reason')=='build-finished' and m.get('success') is True for m in messages)
 assert digest(directory/'fault-test')==record['executable_sha256']
 observation(record['execution'],directory/'execution')
 cmd=record['execution']['command'];assert cmd==[record['retained_executable'],'--exact',record['test_name'],'--nocapture','--test-threads=1']
 stdout=(directory/'execution/stdout.log').read_text()
 assert 'test '+record['test_name']+' ... ok' in stdout
 assert re.search(r'test result: ok\. 1 passed; 0 failed; 0 ignored;',stdout)
 return {'test_name':record['test_name'],'package':record['package'],'target':record['target'],'test_binary_sha256':record['executable_sha256'],'cargo_fresh':a['fresh'],'actual_test_exit_code':record['execution']['exit_code'],'stdout_sha256':digest(directory/'execution/stdout.log')}
raw,meta=artifact(11604900056,37901931021);home=raw/'p8-full-recovery';j=json.loads((home/'full-recovery.json').read_text())
assert j['source']==current and j['status']=='passed_declared_fault_matrix'
assert json.loads((home/'source-inputs.json').read_text())==current['inputs']
assert full_evidence_manifest(home)==j['evidence_files_sha256']
actual_observer=observer_from_archive(source,'full');assert j['observer_before']==j['observer_after']
assert dict(j['observer_before'],source_root=actual_observer['source_root'])==actual_observer
assert j['observer_binding']=='required_git_and_loaded_source';verify_observer_archive(home,j['observer_before'])
for n,h in j['runner_files_sha256'].items():assert digest(source/'scripts'/n)==h
products={}
for kind,r in j['products'].items():
 h=home/Path(r['binary_path']).parent.name;s=previous if kind=='previous-default' else current
 expected_identity={k:v for k,v in s.items() if k!='inputs'}
 expected_identity['source_root']=str(Path(r['cargo_artifact']['manifest_path']).parents[2])
 assert r['status']=='passed' and r['build_exit_code']==0 and r['source_before']==r['source_after']==expected_identity
 assert r['cold_build_claim'] is False and r['release_certified'] is False
 assert json.loads((h/'build-receipt.json').read_text())==r
 assert json.loads((h/'source-inputs.json').read_text())==s['inputs']
 assert digest(h/'codecortex')==r['binary_sha256'] and (h/'codecortex').stat().st_size==r['binary_bytes']
 messages=observation(r['build_observation'],h/'build');a=r['cargo_artifact']
 assert messages.count(a)==1 and a['target']['name']=='codecortex' and a['target']['kind']==['bin'] and a['profile']['test'] is False
 assert a['features']==({'default':[],'previous-default':[],'semantic':['semantic'],'semantic-http':['semantic','semantic-http']}[kind])
 assert any(m.get('reason')=='build-finished' and m.get('success') is True for m in messages)
 assert all(x in r['build_command'] for x in ['--locked','--offline']) and r['build_command']==r['build_observation']['command']
 products[kind]={'source_commit':s['source_commit'],'source_input_count':s['input_count'],'binary_sha256':r['binary_sha256'],'binary_bytes':r['binary_bytes'],'features':a['features'],'build_exit_code':0,'cold_build_claim':False}
assert [(x['package'],x['target'],x['test_name']) for x in j['executions']]==list(FAULT_TESTS)
tests=[fault(r,home/('fault-test-%02d'%i)) for i,r in enumerate(j['executions'])]
result={'schema_version':1,'status':'accepted_source_observers_products_and_original_fault_test_execution','source_commit':commit,'source_tree':current['source_tree'],'input_count':1090,'artifact_id':11604900056,'original_zip_digest':meta['digest'],'evidence_files':len(j['evidence_files_sha256']),'source_observer_inputs':len(actual_observer['inputs']),'products':products,'original_tests':tests,'remaining_scope':['Independent raw RPC/HTTP semantic event checks','Immutable DB/config/rollback snapshot checks'],'limitations':j['limitations'],'todo_status_change':False}
(out/'recovery-provenance-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'recovery_products':len(products),'recovery_original_fault_tests':len(tests),'source_commit':commit,'status':'accepted_declared_original_provenance_and_test_exits_no_task_closure'}))
