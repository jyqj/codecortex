def stable_00240():
    return 240
