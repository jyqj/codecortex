"""Remove only two root-authorized, byte-proved, completed review extractions."""
import datetime
import hashlib
import json
import pathlib
import shutil
import stat
import sys
import zipfile

BASE = pathlib.Path(__file__).resolve().parent
EXPECTED = {
    "11611743908": "6b8718eaba251bb71e77cd16fabb49a7e82cc5b68b79cbc0d4c811d5c9a4135b",
    "11612256751": "ae80133510856df3cf08cfd20c3e335caf53dff543aa2fb1ed65421b12eb2138",
}


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def snapshot(path):
    value = path.lstat()
    assert stat.S_ISREG(value.st_mode) and not path.is_symlink(), str(path)
    return dict(bytes=value.st_size, sha256=sha(path), mode=stat.S_IMODE(value.st_mode),
                inode=value.st_ino, device=value.st_dev, nlink=value.st_nlink,
                mtime_ns=value.st_mtime_ns, ctime_ns=value.st_ctime_ns,
                allocated_bytes=value.st_blocks * 512)


def write_new(path, value):
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + "\n")


def main():
    artifact = sys.argv[1]
    assert artifact in EXPECTED
    area = BASE / "artifacts" / artifact
    extracted = area / "extracted"
    archive = area / (artifact + ".zip")
    candidate = area / "round30-derived-reclamation-candidate.json"
    execution = area / "round30-derived-reclamation-execution.json"
    assert not candidate.exists() and not execution.exists()
    assert extracted.is_dir() and not extracted.is_symlink()
    assert sha(archive) == EXPECTED[artifact]
    preflight = json.loads((area / "preflight-and-extraction.json").read_text())
    accepted = json.loads((area / "actual-acceptance-execution.json").read_text())
    assert all(row["exit_code"] == 0 for row in accepted["commands"])
    assert accepted["original_zip_sha256_after"] == EXPECTED[artifact]
    files = {row["path"]: row for row in preflight["extraction"]["extracted_files"]}
    assert len(files) == 2129
    directories = {parent.as_posix() for name in files
                   for parent in pathlib.PurePosixPath(name).parents if str(parent) != "."}
    entries = {path.relative_to(extracted).as_posix(): path for path in extracted.rglob("*")}
    assert set(entries) == set(files) | directories, "Unknown or missing derived paths"
    for name in directories:
        assert entries[name].is_dir() and not entries[name].is_symlink()
    rows = []
    with zipfile.ZipFile(archive) as original:
        infos = [info for info in original.infolist() if not info.is_dir()]
        assert len(infos) == len(files) and {info.filename for info in infos} == set(files)
        for info in infos:
            path = extracted / info.filename
            current = snapshot(path)
            with original.open(info) as stream:
                original_hash = hashlib.file_digest(stream, "sha256").hexdigest()
            assert current["bytes"] == info.file_size == files[info.filename]["bytes"]
            assert current["sha256"] == original_hash == files[info.filename]["sha256"]
            assert current["mode"] == 0o444 and current["nlink"] == 1, info.filename
            rows.append(dict(path=info.filename, zip_external_mode=info.external_attr >> 16,
                             **current))
    assert sha(archive) == EXPECTED[artifact]
    review = BASE / "accepted" / ("artifact-" + artifact + "-3ffcefc3-independent-final")
    protected_paths = [path for path in area.iterdir() if path.is_file()]
    protected_paths += [path for path in review.rglob("*") if path.is_file()]
    protected_paths += [BASE / "accepted" / ("runtime-3ffcefc3-independent-" + artifact + ".json")]
    protected_paths += [pathlib.Path(name) for name in accepted["helper_inputs_after"]]
    protected_paths += [BASE / "helpers-C3ff-v1" / "adaptation-manifest.json",
                        BASE / "run_mixed_originals_round30_once.py", pathlib.Path(__file__).resolve()]
    # Some manifest filenames are fixed by the wrapper rather than this storage routine.
    protected_paths = sorted({path for path in protected_paths if path.exists()})
    protected = {str(path): snapshot(path) for path in protected_paths}
    record = dict(schema="C-mixed-round30-derived-candidate-v1", artifact_id=int(artifact),
                  directory=str(extracted), original_zip=dict(path=str(archive),
                  bytes=archive.stat().st_size, sha256=EXPECTED[artifact]), files=rows,
                  selected_file_count=len(rows), selected_content_bytes=sum(row["bytes"] for row in rows),
                  selected_allocated_file_bytes=sum(row["allocated_bytes"] for row in rows),
                  directories=sorted(directories), protected_before=protected,
                  activity="This task's original replay processes have exited. No task-owned current or future reader/writer depends on this extraction; no system-wide PID claim.",
                  stat_scope="Preflight fixed bytes/hash and mode0444; current inode/nlink/times captured here and checked again before unlink. Original preflight did not retain inode history.",
                  authorization="Root authorized these two exact extractions only after complete original ZIP/member and protected-file checks. All other directories are excluded.",
                  created_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    write_new(candidate, record)
    protected[str(candidate)] = snapshot(candidate)
    assert set(path.relative_to(extracted).as_posix() for path in extracted.rglob("*")) == set(entries)
    for row in rows:
        assert snapshot(extracted / row["path"]) == {key: value for key, value in row.items()
                                                       if key not in ("path", "zip_external_mode")}
    for name, before in protected.items():
        assert snapshot(pathlib.Path(name)) == before
    receipt = dict(schema="C-mixed-round30-derived-execution-v1", artifact_id=int(artifact),
                   candidate=str(candidate), candidate_sha256=sha(candidate),
                   selected_files=len(rows), selected_content_bytes=record["selected_content_bytes"],
                   protected_before=protected, free_bytes_before=shutil.disk_usage(area).free,
                   started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   status="all_original_bytes_and_protected_stat_verified_before_unlink")
    write_new(execution, receipt)
    for row in rows:
        (extracted / row["path"]).unlink()
    for name in sorted(directories, key=lambda name: len(pathlib.PurePosixPath(name).parts), reverse=True):
        (extracted / name).rmdir()
    extracted.rmdir()
    after = {name: snapshot(pathlib.Path(name)) for name in protected}
    assert after == protected
    receipt.update(status="only_verified_derived_extraction_removed", protected_after=after,
                   all_protected_stat_and_bytes_unchanged=True,
                   removed_directory=str(extracted), free_bytes_after=shutil.disk_usage(area).free,
                   finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    execution.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    for path in (candidate, execution):
        print(json.dumps(dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))))
    print(json.dumps(dict(removed_files=len(rows), removed_bytes=record["selected_content_bytes"],
                          free_bytes_after=receipt["free_bytes_after"])))


if __name__ == "__main__":
    main()
