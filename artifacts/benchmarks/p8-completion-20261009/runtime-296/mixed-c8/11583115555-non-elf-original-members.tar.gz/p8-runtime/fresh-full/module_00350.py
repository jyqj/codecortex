def stable_00350():
    return 350
