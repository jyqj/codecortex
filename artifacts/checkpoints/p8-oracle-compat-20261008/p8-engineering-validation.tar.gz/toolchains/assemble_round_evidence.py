#!/usr/bin/env python3
"""Package exact session evidence; do not reinterpret execution outcomes."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

SESSION = Path('/workspace/scratch/031390cf22eb')
OUTPUT = SESSION / 'round-evidence-stage'
OUTPUT.mkdir(exist_ok=True)


def package(name, roots, extra=()):
    rows = {}
    for root_name in roots:
        root = SESSION / root_name
        for path in sorted(root.rglob('*')):
            if not path.is_file() or path.is_symlink():
                continue
            relative = path.relative_to(root)
            if 'binaries' in relative.parts or 'cache' in relative.parts:
                continue
            if path.suffix not in {'.json', '.jsonl', '.log', '.md', '.rs', '.py', '.sh', '.stderr'}:
                continue
            rows[root_name + '/' + relative.as_posix()] = path.read_bytes()
    for path in extra:
        rows[path] = (SESSION / path).read_bytes()
    archive = OUTPUT / (name + '.tar.gz')
    with archive.open('wb') as target:
        with gzip.GzipFile(filename='', mode='wb', fileobj=target, mtime=0) as zipped:
            with tarfile.open(mode='w', fileobj=zipped, format=tarfile.PAX_FORMAT) as packed:
                for path, raw in sorted(rows.items()):
                    item = tarfile.TarInfo(path)
                    item.size = len(raw)
                    item.mode = 0o644
                    item.mtime = 0
                    packed.addfile(item, io.BytesIO(raw))
    manifest = {
        'schema_version': 1,
        'scope': 'exact session records; each receipt retains its original source, status, command and limitations',
        'archive': archive.name,
        'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
        'archive_bytes': archive.stat().st_size,
        'member_count': len(rows),
        'uncompressed_bytes': sum(map(len, rows.values())),
        'files': {path: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
                  for path, raw in sorted(rows.items())},
    }
    (OUTPUT / (name + '-manifest.json')).write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    with tarfile.open(archive, mode='r:gz') as packed:
        assert set(packed.getnames()) == set(rows)
        for path, original in rows.items():
            assert packed.extractfile(path).read() == original
    print(json.dumps({key: manifest[key] for key in ('archive', 'archive_bytes', 'member_count', 'uncompressed_bytes')}))


package('pr148-independent-validation', ['validation-pr148'], [
    'pr148-review/README.md', 'pr148-review/CI-FINAL.md',
    'pr148-review/github-snapshot.json', 'pr148-review/ci-final-observation.json',
    'pr148-review/independent-review.json', 'pr148-review/historical43-classification.json',
    'pr148-review/manifest-288-verification.json', 'pr148-review/executed-source-continuity.json',
    'pr148-review/task-ledger-verification.json',
])
package('p8-engineering-validation', [
    'validation-scale', 'validation-integration', 'validation-forwarding',
    'pr148-review/v14-template',
], [
    'pr148-review/source-guard-plan.json',
    'pr148-review/scalable-content-review.json',
    'pr148-review/scalable-signed-zero-control.rs',
    'pr148-review/scalable-signed-zero-before-fix.log',
    'pr148-review/scalable-resource-control.rs',
    'pr148-review/scalable-resource-control.log',
    'pr148-review/df140ad1-component-review.json',
    'pr148-review/df140ad1-component-review.md',
    'toolchains/record_scale_validation.py',
    'toolchains/assemble_round_evidence.py',
    'toolchains/finalize_p8_evidence.py',
])
