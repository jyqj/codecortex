"""Freeze explicit final receipts/logs/raw and inventory mismatches without editing originals."""
from pathlib import Path
from collections import Counter
import datetime,hashlib,json,shutil
ROOT=Path('/workspace/scratch/28fef0db5e01');RUN=ROOT/'runtime-review/m5-local-mixed';OUT=Path(__file__).resolve().parent/'failed-originals';OUT.mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def freeze(rel):
 src=RUN/rel;dest=OUT/rel
 if not src.is_file():return {'path':rel,'present':False}
 dest.parent.mkdir(parents=True,exist_ok=True)
 data=src.read_bytes()
 with dest.open('xb') as f:f.write(data)
 return {'path':rel,'present':True,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'source_size_after':src.stat().st_size,'source_sha256_after':sha(src)}
r={'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'original_mixed_matrix_failed_cli_and_verification','root_execution_directory_modified':False,'frozen':[],'cells':[]}
for p in ['execution-receipt.json','run_original_mixed_matrix.py']:r['frozen'].append(freeze(p))
receipt=json.loads((OUT/'execution-receipt.json').read_bytes());assert receipt['status']=='failed'
for c in [1,4,8,16]:
 folder=RUN/f'c{c}/runtime';cell=next(x for x in receipt['cells'] if x['concurrency']==c)
 for name in ['mixed.log','verify.log']:r['frozen'].append(freeze(f'c{c}/{name}'))
 for name in ['report.json','plan.json','seal.json','raw.jsonl','parity.json','statistics.json','statistics-replay.json','statistics-execution.json','product/process.json','product/rpc.jsonl','product/product-stderr.log','product/product-stdout.log','full-product/process.json','full-product/rpc.jsonl','full-product/product-stderr.log','full-product/product-stdout.log']:
  r['frozen'].append(freeze(f'c{c}/runtime/{name}'))
 report=json.loads((folder/'report.json').read_bytes());paths=sorted(p for p in folder.rglob('*') if p.is_file());actual={};errors=[];changed=[]
 for p in paths:
  if p.name=='seal.json' and p.parent==folder:continue
  name=p.relative_to(folder).as_posix()
  try:
   before=p.stat();h=sha(p);after=p.stat();actual[name]={'bytes':after.st_size,'sha256':h}
   if (before.st_size,before.st_mtime_ns,before.st_ino)!=(after.st_size,after.st_mtime_ns,after.st_ino):changed.append(name)
  except OSError as e:errors.append({'path':name,'error':str(e)})
 expected=json.loads((folder/'seal.json').read_bytes())['artifact_inventory'] if (folder/'seal.json').is_file() else None
 diff=None if expected is None else {'missing':sorted(set(expected)-set(actual)),'added':sorted(set(actual)-set(expected)),'changed':[{'path':n,'expected':expected[n],'actual':actual[n]} for n in sorted(set(actual)&set(expected)) if actual[n]!=expected[n]]}
 raw=[json.loads(l) for l in (folder/'raw.jsonl').read_bytes().splitlines()];ops=[x for x in raw if x['kind']=='operation']
 item={'c':c,'cli_phases':[{'name':p['name'],'exit_code':p['exit_code'],'status':p['status']} for p in cell['phases']],'report_status':report['status'],'report_exit_code':report['exit_code'],'owned_cleanup':report['owned_cleanup'],'parity_exit':report['parity_exit_code'],'terminal_rows':len(ops),'terminal_statuses':dict(Counter(x['status'] for x in ops)),'actual_inventory_files':len(actual),'inventory_errors':errors,'changed_during_hash':changed,'seal_present':expected is not None,'seal_inventory_difference':diff,'report_cannot_override_cli':True}
 inv=OUT/f'c{c}/actual-inventory-at-failure-read.json';inv.write_text(json.dumps(actual,indent=2)+'\n');item['actual_inventory_sha256']=sha(inv);r['cells'].append(item)
r['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();r['cause']='unresolved; no attribution to product or environment';(OUT/'failure-readback.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'state':r['state'],'cells':r['cells'],'frozen_files':sum(x['present'] for x in r['frozen']),'report_sha256':sha(OUT/'failure-readback.json')},indent=2))
