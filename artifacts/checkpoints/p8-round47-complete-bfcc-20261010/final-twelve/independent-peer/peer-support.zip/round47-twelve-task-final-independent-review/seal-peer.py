from pathlib import Path
import json,hashlib,zipfile
R=Path('/workspace/scratch/bfccb8494ba0');O=Path(__file__).parent
def ident(p):
 b=p.read_bytes();return {'local_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def w(p,j):
 with p.open('x') as f:json.dump(j,f,ensure_ascii=False,indent=2);f.write('\n')
extras=['round47-final-twelve-application/47-clause-acceptance.final.json','round47-final-twelve-application/TWELVE-TASK-ACCEPTANCE.final.md','round46-twelve-task-application-preparation/original-192-task-preservation-baseline.json','round47-complete45-figures/root-figure-files.actual.json','round47-figures-independent-peer/independent-original45-figures-review.json','round47-figures-independent-peer/actual-create-blob.json','round47-complete45-aggregate-independent-review/upload-manifest.actual.json','round47-descriptive-draft-independent-peer/upload-manifest.actual.json','round47-aggregate-failure-independent-review/upload-manifest.actual.json','round47-final45-raw-custody/complete-45-raw-custody.prepublication.json']
ps=sorted(set([p for p in O.iterdir() if p.is_file()]+[R/p for p in extras]));rows=[{'archive_path':str(p.relative_to(R)),**ident(p)} for p in ps]
w(O/'publication-selection.json',{'schema':'final12-original47-peer-selection-v1','files':rows,'original_raw_ZIP_ELF_and_large_aggregate_not_reembedded':True,'task_statuses_modified':False})
with zipfile.ZipFile(O/'peer-support.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for r in rows:z.write(r['local_path'],r['archive_path'])
 z.write(O/'publication-selection.json','publication-selection.json')
with zipfile.ZipFile(O/'peer-support.zip') as z:
 assert z.testzip() is None and set(z.namelist())=={r['archive_path'] for r in rows}|{'publication-selection.json'}
 for r in rows:assert hashlib.sha256(z.read(r['archive_path'])).hexdigest()==r['sha256']
prefix='artifacts/checkpoints/p8-round47-complete-bfcc-20261010/final-twelve/independent-peer/'
w(O/'upload-manifest.prepared.json',{'repository_full_name':'jyqj/codecortex','files':[{'repository_path':prefix+n,**ident(O/n)} for n in ['independent-original47-clause-twelve-task-review.json','peer-support.zip','publication-selection.json']]});print((O/'upload-manifest.prepared.json').read_text())
