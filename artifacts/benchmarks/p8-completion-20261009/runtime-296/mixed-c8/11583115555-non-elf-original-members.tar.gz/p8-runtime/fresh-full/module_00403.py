def stable_00403():
    return 403
