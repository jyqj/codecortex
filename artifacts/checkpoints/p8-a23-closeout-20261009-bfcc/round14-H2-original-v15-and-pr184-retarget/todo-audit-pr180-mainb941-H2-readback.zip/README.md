# Actual H2 source identity and preservation audit

This archive records the read-only integration of main b9412406e11422d7cf914458a8bfbbd58cf94eaa into H399a. Actual H2 is e5640904298febdf8dc951e0baddb2819f930c0b, tree 73b93b60865daf5d9b6b02afa8974688c64191a4, ordered parents [399a71a4c11e7041ce9946fba4d3f72200c47155, b9412406e11422d7cf914458a8bfbbd58cf94eaa].

The original public snapshot and dependency fix remain bound to actual P c92eb5ac7ece70d1f62271d7e2dacac513c285b5 and independent R f89d5feec91ae611d52614b8fe217bcd7fd5cf64. All 1093 product inputs, 59 review deltas, 139 validation inputs, selected CI, guard, registry and canonical R are unchanged. The original 236 current-root protected historical records remain mode/blob-identical to H and the immutable BASE whitelist; the original historical catalogue remains 302 records.

H2 adds 242 main artifacts and selects six updated main documentation/ledger files. It deletes nothing and preserves every old H artifact and every new main artifact. The only new-main snapshot difference is the already-reviewed H call to write_file_data_for_rebuild; the other three empty-input source files were already mode/blob-identical.

The main evidence entry point is actual-H2-readback.json. Its original local controller, stdout, stderr and integer exit 0 are retained. This execution was metadata and complete Git object reconstruction only. Root separately owns the original v15 CLI execution at actual H2; no CLI, Rust, performance, source-integrity test or task success is inferred here. The 29 unfinished TODO statuses remain unchanged; the P8-007 DB lock wait gap and fixed Gc8 study keep their separate identities.

The three failed audit script versions and their preparation receipts are retained. preparation-failures-tool-transcription.json also records an unsuccessful diagnostic inspection command. These were local audit preparation failures, not failures of the original repository verifier. Transcribed tool output is explicitly distinguished from directly captured process log files.

All current archive members are listed by exact bytes and SHA256 in archive-selection.json. Earlier immutable data and helper dependencies are referenced with complete hashes in external-input-manifest.json rather than copied again. mainb941-complete-derived-tree.json is retained because the actual readback directly consumed its full leaf mapping. The small official changed-tree objects and their origin map retain the derivation route. No product source, remote ref, guard, registry or task status was changed by this auditor.
