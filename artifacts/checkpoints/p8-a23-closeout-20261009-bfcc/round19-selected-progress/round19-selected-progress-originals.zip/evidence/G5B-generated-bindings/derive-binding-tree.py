#!/usr/bin/env python3
"""Read-only identity reconstruction and two-binding installation request."""
import argparse, ast, copy, hashlib, json, difflib
from pathlib import Path
HERE=Path(__file__).resolve().parent
PREP=Path('/dev/shm/todo-audit-P5B-G5B-binding-preparation')
OLD=Path('/dev/shm/todo-audit-b2-G3-forward-plan')
RDIR=Path('/dev/shm/pr-triage-P5B-preselect-format-source-review')
def read(p): return json.loads(Path(p).read_bytes())
def sha(b): return hashlib.sha256(b).hexdigest()
def oid(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def save(n,d): (HERE/n).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
def rebuild_R():
    source=(OLD/'derive-nonloss-plan.py').read_text().split('sql_paths = ',1)[0]
    tree=ast.parse(source)
    assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='save' for n in ast.walk(tree))
    ns={'__file__':str(OLD/'derive-nonloss-plan.py')}
    exec(compile(tree,'<retained-read-only-tree-functions>','exec'),ns)
    leaves=copy.deepcopy(ns['b2']);tree_oid=ns['tree_oid']
    assert tree_oid(leaves)=='8e82c2c60188148f91c2c8bfa58c1e158a94b8af'
    pp=read(PREP/'P5B-official-commit.json')
    req=read('/dev/shm/execution-recon-recovery-20261009/PR180-preselect-format-fix-P5B/P5B-one-leaf-create-tree-request.json')
    assert req['base_tree']==tree_oid(leaves) and len(req['tree'])==1
    for e in req['tree']:leaves[e['path']]={k:e[k] for k in ('mode','type','sha')}
    assert tree_oid(leaves)==pp['tree']['sha']=='7fb46257805e9da89737ef7a6a05574b83f50d79'
    assert pp['sha']=='d21e140ca9ebb5a73294358d64a839466c5a0076'
    assert [p['sha'] for p in pp['parents']]==['b2a17adc188338c48b95d01761836916e5d0fcdb']
    before=copy.deepcopy(leaves);manifest=read(RDIR/'upload-manifest.json')
    assert manifest['source_P']==pp['sha'] and len(manifest['files'])==2
    outputs=[]
    for row in manifest['files']:
        b=Path(row['local_path']).read_bytes()
        assert len(b)==row['bytes'] and sha(b)==row['sha256'] and oid(b)==row['git_blob']
        path=row['repository_path'];assert path not in leaves and path.startswith('artifacts/checkpoints/p8-preselect-ci-format-bfcc-20261009/')
        leaves[path]={'mode':row['mode'],'type':'blob','sha':row['git_blob']};outputs.append(row)
    rr=read(HERE/'R5B-official-commit.json')
    assert rr['sha']=='cef789c9072e659e2026c33b537833edeaf775c9'
    assert [x['sha'] for x in rr['parents']]==[pp['sha']]
    assert tree_oid(leaves)==rr['tree']['sha']=='185d1284974711c4c1927e1f5525257fa65ab8c6'
    assert all(leaves[p]==v for p,v in before.items())
    receipt={'scope':'Official actual R5B full-tree reconstruction; not review authorship or source execution','actual_P5B':pp['sha'],'actual_R5B':rr['sha'],'actual_R5B_tree':rr['tree']['sha'],'R5B_sole_parent_verified':pp['sha'],'exact_added_leaves':outputs,'all_existing_P5B_leaves_unchanged':True,'full_tree_reconstructed_matches_official':True,'product_validation_counts':[1095,71,142]}
    return leaves,tree_oid,receipt
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--generated',type=Path);args=ap.parse_args()
    leaves,tree_oid,r=rebuild_R()
    if args.generated is None:
        save('actual-R5B-two-leaf-readback.json',r);print(json.dumps({'actual_R5B':r['actual_R5B'],'tree':r['actual_R5B_tree'],'added_leaves':2,'result':'identity_verified_source_not_executed'},sort_keys=True));return
    before=copy.deepcopy(leaves);items=[]
    for path in ['scripts/reviewed-source-registry-v15.json','scripts/verify_reviewed_source_v15.py']:
        local=args.generated/path;b=local.read_bytes()
        assert before[path]['mode']=='100644'
        leaves[path]={'mode':before[path]['mode'],'type':'blob','sha':oid(b)}
        items.append({'repository_path':path,'local_path':str(local),'mode':'100644','bytes':len(b),'sha256':sha(b),'git_blob':oid(b)})
    old_reg=read(PREP/'seed-b2-registry.json');new_reg=read(args.generated/'scripts/reviewed-source-registry-v15.json')
    changes=sorted(k for k in old_reg.keys()|new_reg.keys() if old_reg.get(k)!=new_reg.get(k))
    assert changes==['complete_inputs','delta','product_source','review_sha256','review_source']
    maps=read(PREP/'actual-P5B-mechanical-input-maps.json')
    assert new_reg['complete_inputs']==maps['complete_inputs'] and new_reg['delta']==maps['paths'] and new_reg['validation_inputs']==maps['validation_inputs']
    assert new_reg['product_source']==r['actual_P5B'] and new_reg['review_source']==r['actual_R5B']
    for k in ('complete_inputs','delta'):
        assert [p for p in old_reg[k] if old_reg[k][p]!=new_reg[k][p]]==['crates/cc-search/src/preselect.rs']
    old=(PREP/'seed-b2-guard.py').read_text();new=(args.generated/'scripts/verify_reviewed_source_v15.py').read_text()
    a,b=old.splitlines(),new.splitlines();assert len(a)==len(b)
    changed=[x.split(' = ')[0] for x,y in zip(a,b) if x!=y]
    assert set(changed)=={'PRODUCT','REVIEW','REVIEW_PATH','REGISTRY_SHA256'} and len(changed)==4
    assert set(p for p in leaves if leaves[p]!=before[p])=={e['repository_path'] for e in items}
    req={'base_tree':r['actual_R5B_tree'],'tree':[{'path':e['repository_path'],'mode':e['mode'],'type':'blob','sha':e['git_blob']} for e in items]}
    save('two-binding-create-tree-request.json',req)
    (HERE/'guard-four-pin.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='b2/scripts/verify_reviewed_source_v15.py',tofile='prospective-G5B/scripts/verify_reviewed_source_v15.py')))
    report={'scope':'Mechanical actual P5B/R5B binding and prospective G5B tree, no remote mutation or execution','actual_P5B':r['actual_P5B'],'actual_R5B':r['actual_R5B'],'actual_R5B_tree':r['actual_R5B_tree'],'actual_G5B':None,'required_G5B_sole_parent':r['actual_R5B'],'expected_G5B_tree':tree_oid(leaves),'counts':{'product':1095,'BASE_delta':71,'validation':142},'outputs':items,'guard_changed_lines':changed,'registry_actual_changed_fields':changes,'complete_inputs_changed_paths':['crates/cc-search/src/preselect.rs'],'delta_changed_paths':['crates/cc-search/src/preselect.rs'],'all142_validation_unchanged':True,'all1237_domain_mode_blob_unchanged_from_P5B':True,'BASE_FROZEN_historical_algorithm_CI_unchanged':True,'G4_SQL_not_introduced':True,'review_source_only_runtime':'not_run','product_formatter_source_gate_or_measurement_executed_here':False}
    save('allowlisted-delta-and-installation-manifest.json',report)
    print(json.dumps(report,sort_keys=True))
if __name__=='__main__':main()
