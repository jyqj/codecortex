from pathlib import Path
import json,hashlib,difflib
p=Path(__file__).resolve().parent
old=(p/'exact-retained-G9f-lifecycle-independent-review-v4.py').read_text()
new=old.replace('import sys,json,hashlib,collections,datetime,math','import sys,json,hashlib,collections,datetime,math,subprocess')
new=new.replace("source=(root/'candidate-combined').resolve()","source=(root/'runtime-review-Gc8/restored-observer-source').resolve()")
new=new.replace('from p7_build_identity import source_snapshot,verify_release_profile','from p7_build_identity import json_bytes,verify_release_profile')
new=new.replace("base=root/'raw-pr178-9f7b16f'/str(artifact_id)/'extracted'","base=root/'raw-pr178-c8be5afa'/str(artifact_id)/'attempt01/extracted'")
new=new.replace("sha(root/'raw-pr178-9f7b16f'/str(artifact_id)/'original.zip')", "sha(Path(read(base.parent/'transport-receipt.json')['original_zip_path']))")
new=new.replace("snap=source_snapshot(source);inputs=snap.pop('inputs')", """canonical_path=root/'runtime-review-Gc8/exact-canonical-R.json'
check(sha(canonical_path)=='c38d10f1b0d5935384039a6af7df6e8d222bc351a68d3137b09e664735ee9404','fixed_canonical_R_digest')
canonical=read(canonical_path);inputs=canonical['complete_inputs']
check(canonical['source']=='35a7b3412e5fdee9e8ff88951735c06b0e371465' and canonical['verdict']=='accepted_scoped' and len(inputs)==1090,'reviewed_P_complete_map')
snap=dict(source_commit='c8be5afaac568ffd40ef86d3795423c3b73c9f39',source_tree='9b031be22a430e51e153cce6e80770ed885818e3',input_count=len(inputs),manifest_sha256=hashlib.sha256(json_bytes(inputs)).hexdigest())
check(sha(base/'product/source-inputs.json')==snap['manifest_sha256'],'actual_original_source_manifest_bytes')
cli=subprocess.run([sys.executable,'-B',str(source/'scripts/p8_lifecycle.py'),'verify','--output-dir',str(m)],capture_output=True,text=True,timeout=60)
check(cli.returncode==0,'original_lifecycle_verify_cli')""")
new=new.replace("'9f7b16f0758eb79f306cf44605b84550f02de441'","'c8be5afaac568ffd40ef86d3795423c3b73c9f39'")
new=new.replace(" check(sha(source/relative)==digest,'original_observer_hash')", """ check(sha(source/relative)==digest==canonical['validation_inputs'][relative.as_posix()],'original_observer_hash')
 check(format((source/relative).stat().st_mode & 0o777,'o')==canonical['validation_modes'][relative.as_posix()][-3:],'restored_observer_mode')
 name=relative.as_posix().removeprefix('scripts/').removesuffix('.py').replace('/','.')
 if name.endswith('.__init__'):name=name.removesuffix('.__init__')
 module=sys.modules.get(name)
 if module is not None:check(Path(module.__file__).resolve()==(source/relative).resolve(),'loaded_exact_original_observer')""")
new=new.replace("'run_id':37896539337", "'run_id':37901930818")
oldscope='Original Linux workload and original native evaluator ran twice there; this Mac review independently reran original source/inventory/release/cache/usage verifiers and raw associations. No primary workload was repeated. Original Linux ELF evaluator was not executed on macOS; original Rust BLAKE3 normalizer result retained and bound, raw source spans independently checked. No task closure or dependency bypass.'
newscope='Original Gc8 Linux workload and original native evaluator ran twice on GitHub. This separate Linux primary review reran exact original inventory/verify CLI/release/cache/usage pure verifiers and raw associations, binding all1090 raw source inputs to fixedGc8 tree and canonical exact-P review, and all7 restored observer source bytes/modes to original receipt and canonical139 map. Original source_snapshot is not called on the partial restored host, and no original function is monkeypatched. No primary workload, Rust native evaluator, compiler or new timing sample was executed by this review; original Rust BLAKE3 normalizer results remain bound to original native bytes/receipts while raw source spans are independently checked. No task closure or dependency bypass.'
assert oldscope in new
new=new.replace(oldscope,newscope)
new=new.replace("'source':snap,'review_status'", "'source':snap,'local_full_source_snapshot_executed':False,'original_verify_cli':{'actual_exit':cli.returncode,'stdout':cli.stdout,'stderr':cli.stderr},'review_status'")
new=new.replace("dest=root/'review-pr/pr178-ci-observation/raw-review';dest.mkdir(exist_ok=True)","dest=root/'runtime-review-Gc8';dest.mkdir(exist_ok=True)")
new=new.replace("+'-review-v4.json'","+'-primary-review-v1.json'")
out=p/'primary-lifecycle-reviewer-v1.py'
with out.open('x') as f:f.write(new)
with (p/'lifecycle-v4-to-primary-v1.diff').open('x') as f:f.write(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='retained-G9f-lifecycle-v4.py',tofile='primary-Gc8-lifecycle-v1.py')))
print(out,len(new.encode()),hashlib.sha256(new.encode()).hexdigest())
