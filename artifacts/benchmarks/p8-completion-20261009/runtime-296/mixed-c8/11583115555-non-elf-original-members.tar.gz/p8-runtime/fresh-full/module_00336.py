def stable_00336():
    return 336
