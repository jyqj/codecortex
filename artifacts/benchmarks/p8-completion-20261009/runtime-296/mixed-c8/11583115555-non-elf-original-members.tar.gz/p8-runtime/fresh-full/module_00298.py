def stable_00298():
    return 298
