from pathlib import Path
import subprocess,json,hashlib,datetime,time,os,sys,re
root=Path.cwd();base_out=root.parent/'native-db-observation-combined-P1-bb29-evidence';out=base_out/'continuation-canonical-temp';out.mkdir(exist_ok=False);P='bb290be2deaf4334863e09dbf47fe4ccc9625f2b'
baseline=json.loads((base_out/'before-domain-receipt.json').read_text());expected={e['path']:e for e in baseline['entries']};assert baseline['source_P']==P and len(expected)==1250
assert not (out/'controls-progress.json').exists()
p0out=root.parent/'native-db-observation-combined-P-3ced-evidence'
p0=json.loads((p0out/'before-domain-receipt.json').read_text());p0map={e['path']:e for e in p0['entries']}
assert set(p0map)==set(expected)
changed=sorted(k for k in expected if p0map[k]!=expected[k])
assert changed==['crates/cc-db/src/lock_observation.rs','crates/cc-server/tests/p8_db_lock_observation.rs']
fetch_receipt=json.loads((p0out/'locked-dependency-fetch-receipt.json').read_text());assert fetch_receipt['exit_code']==0
dependency_paths=['Cargo.lock','Cargo.toml','crates/cc-db/Cargo.toml','crates/cc-eval/Cargo.toml','crates/cc-server/Cargo.toml']
assert all(p0map[k]==expected[k] for k in dependency_paths)
(out/'unchanged-locked-dependency-fetch-bridge.json').write_text(json.dumps({'source_P0':p0['source_P'],'source_P1':P,'changed_selected_paths':changed,'unchanged_dependency_inputs':{k:expected[k] for k in dependency_paths},'fetch_executed_at_P0':fetch_receipt,'scope':'P1 changes only the two test-expression wraps; existing locked dependencies fetched successfully at P0, fetch is not relabelled as a P1 execution. All as-yet unexecuted controls below run on actual P1.'},indent=2)+'\n')
(out/'controls-controller.py').write_bytes(Path(sys.argv[0]).read_bytes())
def head(where):return subprocess.check_output(['/usr/bin/git','-c','core.commitGraph=false','rev-parse','HEAD'],cwd=where).decode().strip()
parent_head=head(root.parents[3]);assert head(root)==P
def snapshot(label,phase):
 rows=[]
 for name,e in sorted(expected.items()):
  p=root/name;b=p.read_bytes();row={'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'mode':'100755' if p.stat().st_mode&0o111 else '100644'}
  assert row==e,(label,phase,name);rows.append(row)
 assert head(root)==P
 data=(json.dumps({'source_P':P,'tree':baseline['tree'],'phase':phase,'label':label,'entries':rows},indent=2,sort_keys=True)+'\n').encode();p=out/(label+'-input-'+phase+'.json');p.write_bytes(data)
 return {'path':p.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'entries':len(rows)}
env=os.environ.copy();env['PATH']='/Users/jin/.cargo/bin:'+env.get('PATH','')
env.update({'SDKROOT':'/Library/Developer/CommandLineTools/SDKs/MacOSX15.4.sdk','RUSTUP_TOOLCHAIN':'1.95.0','CARGO_TERM_COLOR':'never','CARGO_INCREMENTAL':'0','CARGO_BUILD_JOBS':'2','PYTHONDONTWRITEBYTECODE':'1'})
count=int(env.get('GIT_CONFIG_COUNT','0'));env['GIT_CONFIG_KEY_'+str(count)]='core.commitGraph';env['GIT_CONFIG_VALUE_'+str(count)]='false';env['GIT_CONFIG_COUNT']=str(count+1)
target=root.parent/'targets/db-observation-combined-P1-bb29-controls-1.95-sdk154-round15';assert target.is_dir()
env['CARGO_TARGET_DIR']=str(target)
prior=json.loads((base_out/'controls-progress.json').read_text())
assert len(prior)==5 and all(x['exit_code']==0 for x in prior[:4]) and prior[4]['label']=='all-original-runtime-python-controls' and prior[4]['exit_code']==1
temp=root.parent/'tmp/p1-runtime-controls-canonical-round15'
assert not temp.exists();temp.mkdir(parents=True,mode=0o700);assert temp.resolve(strict=True)==temp
original_tmp=env.get('TMPDIR');env['TMPDIR']=str(temp)
(out/'canonical-temp-provision-and-continuation.json').write_text(json.dumps({'source_P':P,'old_TMPDIR_observed_in_controller':original_tmp,'new_TMPDIR':str(temp),'resolved_new_TMPDIR':str(temp.resolve()),'owned_directory_created':True,'prior_commands':[{k:x.get(k) for k in ['label','exit_code','rust_test_summaries','python_test_count']} for x in prior],'scope':'Same P1, same exact 1250 selected inputs, original tests/guards unchanged. Continue with the full failed 77-method runtime suite and 50 not-yet-executed Rust controls using a canonical temp directory. The 10 passing Rust observations and initial failed Python attempt remain separately recorded; no rerun of passing observations or new source.'},indent=2)+'\n')
cargo=['/Users/jin/.cargo/bin/cargo','+1.95.0']
commands=[
 ('all-original-runtime-python-controls',['python3','-m','unittest','discover','-s','scripts/tests','-p','test_p8_runtime*.py','-v'],9,'python'),
 ('canonical-direct-writer-controls',cargo+['test','--locked','--offline','-p','cc-db','--lib','direct_writer::tests'],11,'rust'),
 ('canonical-migration-controls',cargo+['test','--locked','--offline','-p','cc-db','--lib','index_migrate::tests'],5,'rust'),
 ('canonical-schema-guard-controls',cargo+['test','--locked','--offline','-p','cc-db','--test','ci_schema_guard_contract'],5,'rust'),
 ('public-resolution-store',cargo+['test','--locked','--offline','-p','cc-db','--test','p2b_resolution_store'],7,'rust'),
 ('snapshot-binder-dependency-unit',cargo+['test','--locked','--offline','-p','cc-db','--lib','index_db_snapshot_insert::'],14,'rust'),
 ('snapshot-leaf-owner-control',cargo+['test','--locked','--offline','-p','cc-index','--test','snapshot_leaf_batching'],6,'rust'),
 ('integrated-installer-cli',cargo+['test','--locked','--offline','-p','cc-server','--test','installer_cli'],2,'rust'),
 ('cc-db-default-strict-clippy',cargo+['clippy','--locked','--offline','-p','cc-db','--all-targets','--','-D','warnings'],0,'none'),
 ('cc-db-observation-strict-clippy',cargo+['clippy','--locked','--offline','-p','cc-db','--all-targets','--features','p8-db-lock-observation','--','-D','warnings'],0,'none')
]
receipts=[];total_start=time.monotonic()
for label,cmd,expected_count,kind in commands:
 before=snapshot(label,'before');start=time.monotonic()
 r={'schema_version':1,'label':label,'source_P':P,'tree':baseline['tree'],'cwd':str(root),'command':cmd,'expected_test_count':expected_count if kind=='rust' else None,'test_kind':kind,'before':before,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'actual combined P ordinary engineering controls; 1250 exact selected inputs; cached owned target. Diagnostic runtime/cold study and old-source executions are separate.','environment':{k:env.get(k) for k in ['SDKROOT','RUSTUP_TOOLCHAIN','CARGO_TERM_COLOR','CARGO_INCREMENTAL','CARGO_BUILD_JOBS','PYTHONDONTWRITEBYTECODE','CARGO_TARGET_DIR','TMPDIR','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CC','CXX']}}
 sp=out/(label+'.stdout');ep=out/(label+'.stderr');rp=out/(label+'-receipt.json')
 with sp.open('wb') as so,ep.open('wb') as se:
  child=subprocess.Popen(cmd,cwd=root,env=env,stdout=so,stderr=se);r['pid']=child.pid;rp.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'started':label,'pid':child.pid,'command':cmd}),flush=True)
  try:code=child.wait(timeout=max(1,5400-(time.monotonic()-total_start)))
  except subprocess.TimeoutExpired:child.kill();code=child.wait();r['controller_budget_seconds']=5400
 r.update(exit_code=code,elapsed_seconds=time.monotonic()-start,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),after=snapshot(label,'after'))
 text=''
 for stream,q in [('stdout',sp),('stderr',ep)]:
  b=q.read_bytes();r[stream]={'path':q.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};text+=b.decode(errors='replace')
 counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 r['rust_test_summaries']=[{'passed':int(a),'failed':int(b),'ignored':int(c)} for a,b,c in counts]
 if kind=='rust':valid=sum(int(a) for a,b,c in counts)==expected_count and all(int(b)==0 and int(c)==0 for a,b,c in counts)
 elif kind=='python':
  n=re.findall(r'Ran (\d+) tests? in ',text);r['python_test_count']=int(n[-1]) if n else None;r['python_skipped']=sum(map(int,re.findall(r'skipped=(\d+)',text)));valid=bool(n) and int(n[-1])>=expected_count and r['python_skipped']==0 and re.search(r'^OK\s*$',text,re.M) is not None
 else:valid=True
 r['nonzero_test_check_passed']=valid;rp.write_text(json.dumps(r,indent=2)+'\n');receipts.append(r);(out/'controls-progress.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print(json.dumps({'finished':label,'exit_code':code,'elapsed_seconds':r['elapsed_seconds'],'rust_test_summaries':r['rust_test_summaries'],'python_test_count':r.get('python_test_count'),'nonzero_test_check_passed':valid}),flush=True)
 if code!=0 or not valid:
  print(text[-12000:],flush=True);sys.exit(code if code>0 else 1)
assert head(root.parents[3])==parent_head
print(json.dumps({'all_controls_passed':len(receipts),'source_P':P,'rust_passed':sum(s['passed'] for r in receipts for s in r['rust_test_summaries']),'python_passed':sum(r.get('python_test_count') or 0 for r in receipts),'parent_HEAD_unchanged':parent_head}),flush=True)
