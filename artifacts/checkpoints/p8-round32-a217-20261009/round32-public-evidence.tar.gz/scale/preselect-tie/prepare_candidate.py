#!/usr/bin/env python3
"""Prepare one isolated source candidate; do not build, publish or edit G4."""
import datetime
import difflib
import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path('/dev/shm/a217aaae3bde/pr180-M4-832f-validated')
OUT = pathlib.Path('/workspace/scratch/a217aaae3bde/preselect-pr3-tie-candidate')
SOURCE = '832f79b8702c6cdfb567b7cf949508cd4589f286'
REL = 'crates/cc-search/src/preselect.rs'
original = (ROOT / REL).read_bytes()
assert subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip() == SOURCE
old = original.decode()
before = 'result.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));'
after = '''result.sort_by(|a, b| {
        b.1.partial_cmp(&a.1)
            .unwrap_or(std::cmp::Ordering::Equal)
            .then_with(|| a.0.cmp(&b.0))
    });'''
assert old.count(before) == 1
new = old.replace(before, after)
tests = r'''
    /// Four incoming files share one seed, so the separate top-20 seed policy
    /// cannot affect this fixture. All five possible edges fit the DAO limit.
    fn db_with_tied_graph_neighbors(reverse: bool, stronger_z: bool) -> (TempDir, IndexDb) {
        let tmp = TempDir::new().unwrap();
        let db = IndexDb::open(&tmp.path().join("graph_ties.db")).unwrap().0;
        let conn = crate::test_seed::seed_conn(&db);
        conn.execute_batch(
            "INSERT INTO files(file_path,language,content_hash,mtime,size,indexed_at)
                 VALUES('src/seed.rs','Rust','seed',1.0,100,'2024-01-01');
             INSERT INTO symbols(symbol_id,symbol_uid,file_path,name,kind,start_line,end_line)
                 VALUES('seed','uid:seed','src/seed.rs','seed','function',1,10);",
        )
        .unwrap();
        let mut files = ["src/a.rs", "src/b.rs", "src/c.rs", "src/z.rs"];
        if reverse {
            files.reverse();
        }
        for file in files {
            conn.execute(
                "INSERT INTO files(file_path,language,content_hash,mtime,size,indexed_at)
                     VALUES(?1,'Rust','neighbor',1.0,100,'2024-01-01')",
                [file],
            )
            .unwrap();
            let uid = format!("uid:{file}");
            conn.execute(
                "INSERT INTO symbols(symbol_id,symbol_uid,file_path,name,kind,start_line,end_line)
                     VALUES(?1,?2,?1,'neighbor','function',1,10)",
                (file, &uid),
            )
            .unwrap();
            let calls = if stronger_z && file == "src/z.rs" { 2 } else { 1 };
            for line in 1..=calls {
                let edge = format!("{file}:{line}");
                conn.execute(
                    "INSERT INTO call_edges(edge_id,file_path,caller_symbol,callee_symbol,line,
                         caller_symbol_uid,callee_symbol_uid,resolution_kind,resolution_confidence)
                         VALUES(?1,?2,'neighbor','seed',?3,?4,'uid:seed','resolved',1.0)",
                    (&edge, file, line, &uid),
                )
                .unwrap();
            }
        }
        drop(conn);
        (tmp, db)
    }

    #[test]
    fn graph_neighbor_ties_select_file_order_before_truncation() {
        for reverse in [false, true] {
            let (_tmp, db) = db_with_tied_graph_neighbors(reverse, false);
            let scores = HashMap::from([("src/seed.rs".to_string(), 2.0)]);
            for _ in 0..8 {
                let result =
                    score_graph_neighbors(&db, &scores, 2, &RankingConfig::default()).unwrap();
                let paths: Vec<_> = result.iter().map(|(path, _)| path.as_str()).collect();
                assert_eq!(paths, ["src/a.rs", "src/b.rs"]);
                assert!(result.iter().all(|(_, score)| (*score - 0.8).abs() < 1e-12));
            }
        }
    }

    #[test]
    fn graph_neighbor_score_precedes_file_order_at_the_cutoff() {
        for reverse in [false, true] {
            let (_tmp, db) = db_with_tied_graph_neighbors(reverse, true);
            let scores = HashMap::from([("src/seed.rs".to_string(), 2.0)]);
            for _ in 0..8 {
                let result =
                    score_graph_neighbors(&db, &scores, 2, &RankingConfig::default()).unwrap();
                let paths: Vec<_> = result.iter().map(|(path, _)| path.as_str()).collect();
                assert_eq!(paths, ["src/z.rs", "src/a.rs"]);
                assert!((result[0].1 - 0.9).abs() < 1e-12);
                assert!((result[1].1 - 0.8).abs() < 1e-12);
            }
        }
    }
'''
assert new.endswith('\n}\n')
new = new[:-2] + tests + '}\n'
assert new.split('#[cfg(test)]\nmod tests {')[0] == old.split('#[cfg(test)]\nmod tests {')[0].replace(before, after)

def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}

expected = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', f'{SOURCE}:{REL}'], text=True).strip()
assert identity(original)['git_blob'] == expected
target = OUT / REL
assert not target.exists()
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(new)
(OUT / 'original-G4-preselect.rs').write_bytes(original)
patch = ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='a/' + REL, tofile='b/' + REL))
(OUT / 'candidate.patch').write_text(patch)
assert (ROOT / REL).read_bytes() == original
facts = {
 'schema': 'PR3-specific-graph-neighbor-tie-candidate-v1',
 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'base': SOURCE, 'path': REL, 'base_identity': identity(original), 'candidate_identity': identity(target.read_bytes()),
 'patch_identity': identity(patch.encode()),
 'authorization_scope': 'Parent root requested one isolated candidate; no shared checkout, Git object/ref, workflow or scale study is modified.',
 'production_change': 'Exactly one existing final neighbor sort gains filepath ordering when the original descending partial_cmp comparison returns Equal; scores, preselection, DAO queries, limits, filtering and truncation remain unchanged.',
 'legacy_source': {'pr': 3, 'head': '9619641903f0b9f397007ebbe85893ce8f6b5f97', 'hunk': 'preselect.rs score_graph_neighbors result.sort_by before expansion_limit'},
 'new_controls': [
    {'name': 'graph_neighbor_ties_select_file_order_before_truncation', 'meaning': 'Real SQLite graph has four equal-scored caller files, one seed and limit two. Both DB insertion orders and independent calls must select a,b; all scores remain 0.8.'},
    {'name': 'graph_neighbor_score_precedes_file_order_at_the_cutoff', 'meaning': 'A second real incoming edge raises z to 0.9; score must win over filepath a at 0.8, while the remaining tie chooses a. Five edges fit the unchanged per-seed DAO limit.'}
 ],
 'not_changed': ['top-20 seed score ties are a separate known point', 'all original tests and assertion bodies', 'all scale sources, budgets, repetitions and evidence'],
 'validation': {'static_candidate_construction_and_fixed_source_byte_checks': 'passed', 'cargo_fmt': 'not_run: no Rust toolchain in current local environment', 'compilation': 'not_run', 'new_and_original_Rust_controls': 'not_run', 'native_measurement': 'not_run'},
 'performance_claim': None, 'formal_completion': False, 'remaining_todos': 29,
}
(OUT / 'candidate-manifest.json').write_text(json.dumps(facts, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
print(json.dumps({'candidate': str(target), **identity(target.read_bytes()), 'manifest': str(OUT / 'candidate-manifest.json'), 'manifest_identity': identity((OUT / 'candidate-manifest.json').read_bytes())}))
