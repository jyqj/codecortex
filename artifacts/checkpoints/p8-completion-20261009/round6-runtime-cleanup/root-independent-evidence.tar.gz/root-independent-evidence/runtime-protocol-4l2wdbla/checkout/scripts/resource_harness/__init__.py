# committed protocol-control fixture: scripts/resource_harness/__init__.py
