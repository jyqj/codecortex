def admission_review(directory, build, built, matrix, replay_root):
    """Replay actual admission originals; metadata receipts alone cannot pass."""
    controller = directory / "p8-d0-controller"
    observed = directory / "p8-d0-admission"
    upstream = directory / "p8-d0-upstream"
    require({p.name for p in directory.iterdir()} ==
            {"p8-d0-controller", "p8-d0-admission", "p8-d0-upstream"}, "admission top-level layout differs")
    require({p.name for p in controller.iterdir()} == {"admit.py", "registration.json", "controller-inputs.json"},
            "controller copied input set differs")
    require({p.name for p in observed.iterdir()} == {"admit.py", "registration.json", "controller-inputs.json",
            "metadata-receipt.json", "verify-receipt.json", "upstream-run.json", "upstream-jobs.json", "upstream-artifacts.json"},
            "admission original observation set differs")
    registration = read_json(controller / "registration.json")
    require(digest(controller / "registration.json") == REGISTRATION_SHA256,
            "fixed registration bytes changed")
    require(registration["source"] == SOURCE and registration["upstream_run"] == UPSTREAM_RUN and
            registration["upstream_attempt"] == ATTEMPT and registration["repository"] == "jyqj/codecortex",
            "registration source/upstream differs")
    for folder in (controller, observed):
        require(digest(folder / "registration.json") == REGISTRATION_SHA256 and
                digest(folder / "admit.py") == CONTROLLER_SCRIPT_SHA256,
                "published controller/registration copies changed")
        require(read_json(folder / "controller-inputs.json") == {
            "source_commit": CONTROLLER, "registration_sha256": REGISTRATION_SHA256,
            "script_sha256": CONTROLLER_SCRIPT_SHA256, "measured_source": SOURCE,
            "upstream_run": UPSTREAM_RUN, "new_primary_measurements_started": False},
            "controller and measured source were conflated")
    metadata = read_json(observed / "metadata-receipt.json")
    verified = read_json(observed / "verify-receipt.json")
    for record, phase, status in ((metadata, "metadata", "metadata_passed_original_successful_upstream"),
            (verified, "verify", "original_prerequisites_passed_for_new_registered_study")):
        require(record.get("phase") == phase and record.get("status") == "passed" and
                record.get("source") == SOURCE and record.get("registration_sha256") == REGISTRATION_SHA256 and
                record.get("controller_sha256") == CONTROLLER_SCRIPT_SHA256 and
                record.get("result", {}).get("status") == status and
                record["result"].get("new_measurements_performed") is False,
                "actual original admission phase did not pass")
    meta = metadata["result"]
    require(meta.get("controller_source") == CONTROLLER and meta.get("controller_run_id") == RUN and
            meta.get("measured_source") == SOURCE and meta.get("upstream_run") == UPSTREAM_RUN,
            "actual admission run/source differs")
    run = read_json(observed / "upstream-run.json")
    require(run.get("id") == UPSTREAM_RUN and run.get("head_sha") == SOURCE and
            run.get("run_attempt") == ATTEMPT and run.get("status") == "completed" and run.get("conclusion") == "success" and
            run.get("event") == "push" and run.get("head_branch") == "task/p8-prefix-window-engineering-20261009" and
            run.get("path") == ".github/workflows/p8-prefix-window-engineering.yml",
            "original upstream run was not the registered successful first attempt")
    jobs = read_json(observed / "upstream-jobs.json")
    require(jobs.get("total_count") == len(jobs.get("jobs", [])) == 3 and
            [{"id": j["id"], "name": j["name"]} for j in sorted(jobs["jobs"], key=lambda j: j["id"])] == registration["upstream_jobs"] and
            all(j.get("run_id") == UPSTREAM_RUN and j.get("head_sha") == SOURCE and
                j.get("status") == "completed" and j.get("conclusion") == "success" for j in jobs["jobs"]),
            "original upstream jobs differ or did not pass")
    artifacts = read_json(observed / "upstream-artifacts.json")
    require(artifacts.get("total_count") == len(artifacts.get("artifacts", [])) == 6 and
            len({a["id"] for a in artifacts["artifacts"]}) == 6 and
            [{"id": a["id"], "name": a["name"], "bytes": a["size_in_bytes"], "sha256": a["digest"].removeprefix("sha256:")}
             for a in sorted(artifacts["artifacts"], key=lambda a: a["id"])] == registration["upstream_artifacts"] and
            all(a.get("expired") is False and a.get("workflow_run", {}).get("id") == UPSTREAM_RUN and
                a["workflow_run"].get("head_sha") == SOURCE for a in artifacts["artifacts"]),
            "six original upstream artifacts differ")
    require({p.name for p in upstream.iterdir()} == {a["name"] for a in registration["upstream_artifacts"]
            if a["id"] != registration["build"]["artifact_id"]}, "upstream original bundle set differs")
    snapshot = matrix.source_snapshot(replay_root)
    require(snapshot["source_commit"] == SOURCE and snapshot["source_tree"] == registration["source_tree"] and
            snapshot["input_count"] == 1087 and snapshot["inputs"] == registration["complete_source_inputs"] and
            snapshot["manifest_sha256"] == registration["source_manifest_sha256"] and
            matrix.driver_snapshot(replay_root)["inputs"] == registration["scale_observer_inputs"],
            "current complete D0 source/observer inputs differ")
    build_sha = digest(build / "build.json")
    require(build_sha == registration["build"]["receipt_sha256"] and
            built["binary_sha256"] == registration["build"]["binary_sha256"] and
            built["binary_blake3"] == registration["build"]["binary_blake3"], "registered original build changed")
    # validate_build has already checked the original six-member Cargo/copy seal.
    require(set(matrix.inventory(build)) == {"build.json", "cargo.jsonl", "cargo.stderr", "p8-scale",
            "source-before.json", "source-after.json"}, "original build member set changed")
    control = upstream / registration["controls"]["artifact_name"]
    controls = read_json(control / "receipt.json")
    require(digest(control / "receipt.json") == registration["controls"]["receipt_sha256"] and
            controls["files"] == matrix.inventory(control, ("receipt.json",)), "original control receipt/files changed")
    commands = registration["controls"]["commands"]
    require(len(commands) == 12 and controls["commands"] == commands and
            [r["argv"] for r in controls["results"]] == commands and all(r["exit_code"] == 0 for r in controls["results"]) and
            controls["status"] == "commands_completed" and controls["exit_code"] == 0 and
            controls["source_unchanged"] is True and controls["not_run_command_indices"] == [] and
            read_json(control / "source-before.json") == read_json(control / "source-after.json") == snapshot,
            "original twelve controls/source did not pass")
    diagnostics = []
    for item in registration["diagnostics"]:
        raw = upstream / item["artifact_name"]
        require(digest(raw / "shard.json") == item["receipt_sha256"], "original diagnostic receipt changed")
        value = matrix.validate_shard(raw, built, build / "p8-scale", build_sha)
        require(matrix.exact_equal(value["plan"], matrix.registered_plan(item["scale"], 0, 30, 30, 12648430,
                18000000, matrix.CAPACITY_PROFILE)), "original diagnostic plan differs")
        diagnostics.append({"scale": item["scale"], "receipt_sha256": item["receipt_sha256"],
                            "original_full_raw_validation_passed": True})
    require([d["scale"] for d in diagnostics] == [1000, 10000] and diagnostics == verified["result"]["diagnostics"] and
            verified["result"].get("source") == SOURCE and verified["result"].get("original_validate_build_passed") is True and
            verified["result"].get("original_controls") == 12 and verified["result"].get("new_primary_cells") == 150,
            "actual admission verify result differs from original raw replay")
    plans = [{"scale": scale, "shard_index": index, "plan": matrix.registered_plan(scale, index, 30, 30,
             12648430, 18000000, matrix.CAPACITY_PROFILE)} for scale in reversed(SCALES) for index in range(30)]
    require(matrix.exact_equal(plans, registration["primary_cells"]), "fixed complete150 original plans differ")
    require(matrix.source_snapshot(replay_root) == snapshot, "source changed during prerequisite replay")
    return {"status": "actual_admission_and_original_prerequisites_passed", "metadata_receipt_sha256": digest(observed / "metadata-receipt.json"),
            "verify_receipt_sha256": digest(observed / "verify-receipt.json"), "registration_sha256": REGISTRATION_SHA256,
            "original_controls": 12, "diagnostics": diagnostics, "diagnostics_not_new_primary_samples": True}, registration


