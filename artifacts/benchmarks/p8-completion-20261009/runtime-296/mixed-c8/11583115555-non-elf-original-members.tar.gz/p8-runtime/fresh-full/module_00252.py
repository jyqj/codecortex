def stable_00252():
    return 252
