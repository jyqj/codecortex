def stable_00483():
    return 483
