"""Derived accepted00-09 bridge and new10 emitted events only; no old ZIP reads."""
import collections,datetime,hashlib,json,struct,zipfile,zlib
from pathlib import Path
R=Path('/workspace/scratch/bfccb8494ba0');O=R/'round40-diagnostic-checkpoint-10-intake/attempt01';P=R/'round40-diagnostic-checkpoint-09-intake/attempt01'
def sha(b):return hashlib.sha256(b).hexdigest()
def ident(p):
 b=p.read_bytes();return {'local_path':str(p),'bytes':len(b),'sha256':sha(b),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def save(name,d):
 with (O/name).open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
reader=json.loads((O/'reader/report.json').read_text());execution=json.loads((O/'reader.execution.json').read_text());oldpath=P/'checkpoint09-prefix-review.json'
old=json.loads(oldpath.read_text());oldreader=json.loads((P/'reader/report.json').read_text());oldindex=json.loads((P/'official-index.json').read_text())
assert old['verified_prefixes']['shard/native/raw.jsonl']['end_exclusive']==15396320
assert execution['exit_code']==0 and len(reader['artifacts'])==1
new=reader['artifacts'][0];assert new['id']=='11658489665' and new['official_digest_verified'] and new['crc_and_member_sha_checked']
assert new['bytes']==63250 and new['sha256']=='3e38fee52b72f85f81722904b0fb3d4bd4719e30ee92a8693b8a408304dc4498'
selected=O/'selected-originals';selected.mkdir(exist_ok=False)
# Copy only new original bytes after frozen reader performed sole member CRC pass.
with zipfile.ZipFile(new['zip_path']) as central,open(new['zip_path'],'rb') as f:
 assert set(central.namelist())==set(new['members'])
 for entry in central.infolist():
  assert entry.compress_type in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED)
  f.seek(entry.header_offset);header=f.read(30);assert header[:4]==b'PK\x03\x04'
  n,e=struct.unpack_from('<HH',header,26);f.seek(n+e,1);compressed=f.read(entry.compress_size)
  data=compressed if entry.compress_type==zipfile.ZIP_STORED else zlib.decompress(compressed,-15)
  m=new['members'][entry.filename];assert len(data)==m['bytes'] and sha(data)==m['sha256']
  path=selected/entry.filename;assert path.parent==selected;path.write_bytes(data);path.chmod(int(m['zip_posix_mode'],8))
manifest=json.loads((selected/'manifest.json').read_text());assert manifest['index']==10
assert (selected/'configuration.json.snapshot').read_bytes()==(P/'selected-originals/configuration.json.snapshot').read_bytes()
accepted_artifacts=old['derived_continuity_bridge']['accepted_prior_artifact_records']+oldreader['artifacts']
accepted_official=old['derived_continuity_bridge']['accepted_prior_official_artifact_rows']+oldindex['artifacts']
ids=[11655358015,11655694522,11656371239,11656517936,11656209993,11656794128,11657318324,11658151472,11658656645,11658523401]
assert [x['artifact']['id'] for x in accepted_official]==ids
by_id={str(a['id']):a for a in accepted_artifacts};assert len(by_id)==10
chunks={k:dict(v) for k,v in old['derived_continuity_bridge']['accepted_prior_chunk_records'].items()}
for stream in oldreader['streams'].values():
 for c in stream['chunks']:
  if c['name'] in chunks:
   prior=chunks[c['name']];assert {k:v for k,v in prior.items() if k!='retained_locations'}=={k:v for k,v in c.items() if k!='retained_locations'}
   for loc in c['retained_locations']:
    if loc not in prior['retained_locations']:prior['retained_locations'].append(loc)
  else:chunks[c['name']]=dict(c)
small={}
for path in R.glob('round*-diagnostic-checkpoint-*-intake/attempt01/selected-originals/manifest.json'):
 if path==selected/'manifest.json':continue
 d=json.loads(path.read_text())
 if d['index']<=9:
  assert d['index'] not in small;small[d['index']]=(path,d)
assert set(small)==set(range(10))
cp=reader['checkpoints'][0];assert cp['index']==10 and len(cp['acknowledgements'])==10
assert all(a['retained_original_and_official_digest_verified'] is False for a in cp['acknowledgements'])
acks=[]
for a in cp['acknowledgements']:
 p,m=small[a['checkpoint']];orig=by_id[str(a['artifact_id'])];official=next(x['artifact'] for x in accepted_official if str(x['artifact']['id'])==str(a['artifact_id']))
 assert ident(p)['sha256']==orig['members']['manifest.json']['sha256']==a['manifest_sha256']
 assert m['included_chunk_names']==a['included_chunk_names']
 assert orig['sha256']==official['digest'].removeprefix('sha256:')==a['artifact_digest'] and orig['official_digest_verified'] is True
 acks.append({'ack':a,'small_manifest':ident(p),'prior_original_ZIP_artifact_id':official['id'],'prior_official_ZIP_sha256':orig['sha256'],'derived_bridge_verified':True,'prior_ZIP_reopened':False})
prefixes={};newchunks=[]
for name,s in reader['streams'].items():
 pos=0
 for c in s['chunks']:
  assert c['start']==pos
  if c['name'] in chunks:
   prior=chunks[c['name']];assert prior['retained_locations']
   assert {k:v for k,v in c.items() if k!='retained_locations'}=={k:v for k,v in prior.items() if k!='retained_locations'}
  else:
   assert c['retained_locations'] and all(x['artifact_id']==new['id'] for x in c['retained_locations']);newchunks.append((name,c))
  pos=c['end']
 assert pos==s['highest_declared_offset'] and pos>=old['verified_prefixes'][name]['end_exclusive']
 prefixes[name]={'start':0,'end_exclusive':pos,'highest_declared_offset':s['highest_declared_offset'],'unknown_tail_bytes':None,'EOF_claimed':False,'verification_scope':'derived accepted00-09 records/small manifests plus new-only10 reader; no old ZIP reread'}
assert len(newchunks)==1 and newchunks[0][0]=='shard/native/raw.jsonl';chunk=newchunks[0][1]
assert chunk['start']==15396320 and old['new_raw_interval']['partial_tail_bytes']==0
raw=(selected/chunk['name']).read_bytes();assert len(raw)==chunk['bytes'] and sha(raw)==chunk['sha256']
events=[];intervals=[];failures=[];offset=chunk['start'];lines=raw.splitlines(keepends=True)
for i,line in enumerate(lines):
 row={'new_line_index':i,'start':offset,'end':offset+len(line),'bytes':len(line),'sha256':sha(line),'complete_newline':line.endswith(b'\n')};offset+=len(line)
 if not row['complete_newline']:row['status']='partial_tail_not_complete_event'
 else:
  try:
   e=json.loads(line);events.append(e);row.update(event=e.get('event'),label=e.get('label'),status='complete_original_event')
  except (ValueError,UnicodeError) as error:row.update(status='complete_line_parse_error',error=str(error));failures.append(row)
 intervals.append(row)
assert offset==chunk['end']
counts=collections.Counter(e.get('event') for e in events);total=collections.Counter(old['new_raw_interval']['cumulative_complete_event_counts'])+counts
unfinished=list(old['started_but_not_finished_in_retained_prefix']);finished=[]
for e in events:
 if e.get('event')=='build_started':unfinished.append(e)
 elif e.get('event')=='build_finished':
  unfinished=[x for x in unfinished if x['label']!=e['label']]
  fields=('elapsed_ms','phase_timing','build_timing','files_scanned','files_added','files_updated','files_removed','files_skipped','files_parsed','symbols_total','chunks_total','parse_errors','resolution_freshness')
  finished.append({**{k:e.get(k) for k in ('label','full','start_us','end_us','wall_us','process_snapshot')},'original_report_fields':{k:e['report'].get(k) for k in fields}})
bridge={'scope':'Derived custody reuse; frozen reader old-ACK false/prefix0 remains unchanged.','prior_reader_report':ident(P/'reader/report.json'),'prior_index':ident(P/'official-index.json'),'prior_accepted_report':ident(oldpath),'accepted_prior_artifact_records':accepted_artifacts,'accepted_prior_official_artifact_rows':accepted_official,'accepted_prior_chunk_records':chunks,'ACKs':acks,'old_ZIPs_opened':0,'old_ZIPs_CRC_rechecked':0,'all_declared_old_chunks_equal_prior_accepted_records':True,'new_chunk_start_matches_prior_end':True,'new_chunks':len(newchunks)}
report={'schema':'p8-original-diagnostic-checkpoint10-prefix-review-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':old['source'],'run_id':38012409915,'attempt':1,'scope':'One frozen reader invocation for new10 only; separately derived accepted00-09 bridge. No complete-run or semantic acceptance.','new_original_artifact':new,'old_continuity_artifact_ids':ids,'previous_accepted_review':ident(oldpath),'frozen_reader_execution':ident(O/'reader.execution.json'),'reader_exit_code':0,'frozen_reader_new_only_stream_result':reader['streams'],'verified_prefixes':prefixes,'derived_continuity_bridge':bridge,'accepted_diagnostic_build_reused_without_revalidation':old['accepted_diagnostic_build_reused_without_revalidation'],'new_raw_interval':{**chunk,'ends_in_newline':raw.endswith(b'\n'),'original_line_intervals':intervals,'new_complete_event_counts':dict(counts),'cumulative_complete_event_counts':dict(total),'complete_line_parse_errors':failures,'partial_tail_bytes':0 if not lines or lines[-1].endswith(b'\n') else len(lines[-1])},'new_original_non_build_records':[e for e in events if e.get('event') not in ('build_started','build_finished')],'new_finished_build_records':finished,'started_but_not_finished_in_retained_prefix':unfinished,'visible_frontier':{'last_complete_original_record':{k:events[-1].get(k) for k in ('event','label','stage','full','start_us','end_us','wall_us')} if events else None,'current_hidden_execution_phase':'unknown: only retained emitted events establish the boundary'},'cold_parity_events':total.get('cold_parity',0),'stage_finished_events':total.get('stage_finished',0),'frozen_reader_checkpoint10_ACKs_unverified_within_new_only_input':cp['acknowledgements'],'own_ACK_boundary':'10 snapshot precedes its own upload; no later local10 ACK supplied. Official10 ZIP custody independently verified.','capture_faults_observed':reader['capture_faults'],'metadata_parse_unknown':reader['metadata_parse_unknown'],'observer_before_seen_and_bound':reader['observer_before_seen'],'observer_after_seen':reader['observer_after_seen'],'supervisor_terminal_seen':bool(reader['supervisor_receipts']),'native_report_seen':bool(reader['native_reports']),'reported_native_outcome':reader['reported_native_outcome'],'custody_status':reader['custody_status'],'local_metadata_materialization':'New members copied from original compressed bytes after frozen reader CRC pass; size/SHA checked, no second CRC pass, no old ZIP or raw stream opened.','original_function_calls':{'validate_build':0,'validate_shard':0,'inspect_raw':0,'check_parity':0,'ELF':0},'full_cohort_run_not_mixed':38013753078,'original_semantic_validation':'not_run; emitted records do not replace original complete-evidence predicates','timing_boundary':'Original counters only. Nested phase timers are not summed. No hidden-phase cause, speedup, stalled-process or EOF claim.','accepted_cohort_shards':0,'accepted_samples':0,'TODO_credit':0}
save('checkpoint10-prefix-review.json',report)
save('incremental-facts-summary.json',{k:report[k] for k in ['schema','source','run_id','attempt','new_raw_interval','visible_frontier','new_original_non_build_records','new_finished_build_records','capture_faults_observed','reported_native_outcome','accepted_samples','TODO_credit']})
print(json.dumps({'report':ident(O/'checkpoint10-prefix-review.json'),'new_events':dict(counts),'new_raw_bytes':len(raw),'derived_contiguous_raw_bytes':prefixes['shard/native/raw.jsonl']['end_exclusive'],'derived_ACKs_verified':len(acks),'native_outcome':reader['reported_native_outcome'],'last_event':report['visible_frontier'],'unfinished_labels':[x['label'] for x in unfinished]}))
