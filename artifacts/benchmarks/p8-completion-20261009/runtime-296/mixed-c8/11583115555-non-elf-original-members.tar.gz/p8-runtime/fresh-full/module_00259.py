def stable_00259():
    return 259
