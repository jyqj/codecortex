import hashlib,json,os,shutil,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'p8-cold-only-integration/guard-view'
BARE=HERE.parent/'C8-resume-diagnostic/source.git'
VIEW=HERE/'guard-view'
HEAD='10ec828beb94200ec679302c45115760ebd55ee9'
def git(*args,**kw):
    return subprocess.run(['git','-C',str(VIEW),*args],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,**kw).stdout
assert not VIEW.exists()
shutil.copytree(OLD,VIEW,ignore=shutil.ignore_patterns('.git','__pycache__','*.pyc'))
subprocess.run(['git','init','-q',str(VIEW)],check=True)
(VIEW/'.git/objects/info/alternates').write_text(str(OLD/'.git/objects')+'\n'+str(BARE/'objects')+'\n')
shallow=set()
for p in [OLD/'.git/shallow',BARE/'shallow']:
    if p.exists():shallow.update(p.read_text().splitlines())
(VIEW/'.git/shallow').write_text('\n'.join(sorted(shallow))+'\n')
git('remote','add','origin','https://github.com/jyqj/codecortex.git')
git('config','remote.origin.promisor','true');git('config','remote.origin.partialclonefilter','blob:none');git('config','core.autocrlf','false')
for p in (HERE/'after').rglob('*'):
    if p.is_file():
        dest=VIEW/p.relative_to(HERE/'after');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for e in json.loads((HERE/'review-file-plan.json').read_text()):
    dest=VIEW/e['path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(e['source'],dest)
for p in (HERE/'scripts').iterdir():shutil.copy2(p,VIEW/'scripts'/p.name)
files=[p for p in VIEW.rglob('*') if p.is_file() and '.git' not in p.relative_to(VIEW).parts]
git('hash-object','-w','--stdin-paths',input=('\n'.join(str(p) for p in files)+'\n').encode())
git('update-ref','HEAD',HEAD);git('read-tree',HEAD)
reg=json.loads((VIEW/'scripts/reviewed-source-registry-v15.json').read_text())
names=set(reg['complete_inputs'])|set(reg['validation_inputs'])|{'scripts/reviewed-source-registry-v15.json','scripts/verify_reviewed_source_v15.py'}|{e['path'] for e in json.loads((HERE/'review-file-plan.json').read_text())}
actual=[]
for p in sorted(names):
    raw=(VIEW/p).read_bytes();oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    line=git('ls-tree',HEAD,'--',p).decode().strip();mode,kind,expected=line.split('\t')[0].split()
    assert mode in ('100644','100755') and kind=='blob' and oid==expected,(p,line,oid)
    assert bool((VIEW/p).stat().st_mode & 0o111)==(mode=='100755'),(p,mode,oct((VIEW/p).stat().st_mode))
    actual.append({'path':p,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':oid,'mode':mode})
assert git('rev-parse','HEAD').decode().strip()==HEAD
record={'scope':'required-file materialized projection, not full archive checkout; real private HEAD/index; read-only old object alternates','head':HEAD,'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'complete_inputs':len(reg['complete_inputs']),'delta':len(reg['delta']),'validation_inputs':len(reg['validation_inputs']),'index_sha256':hashlib.sha256((VIEW/'.git/index').read_bytes()).hexdigest(),'files':actual}
(HERE/'private-view-actual-source-proof.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='files'}),flush=True)
