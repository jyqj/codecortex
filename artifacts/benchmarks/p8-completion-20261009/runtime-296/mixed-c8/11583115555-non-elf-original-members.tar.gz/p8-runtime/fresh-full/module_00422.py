def stable_00422():
    return 422
