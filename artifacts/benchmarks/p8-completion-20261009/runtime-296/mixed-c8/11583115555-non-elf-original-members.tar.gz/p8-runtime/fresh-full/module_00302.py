def stable_00302():
    return 302
