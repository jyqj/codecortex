#!/usr/bin/env python3
"""Independent two-leaf metadata/byte bridge only; no source CLI or tests."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import re

B = Path(__file__).resolve().parent
A = Path('/dev/shm/todo-audit-G6B-22975e49-binding')
C = Path('/dev/shm/todo-audit-P6B-crash-ready-source-review/final-R6B')
P = '5534ebf38cc31efec1590d132ca57c30e2f77f1b'
R = '22975e49107b3832f438f85b17275110fc0afa02'
G = '88d5f547bb0fae273f4270742503fd1fd5e70bc2'
def read(p): return json.loads(p.read_bytes())
def sha(data): return hashlib.sha256(data).hexdigest()
def blob(data): return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
def unwrap(name): return json.loads(read(A / name)['structuredContent']['content'])
def tree(rows):
    data = b''
    for row in sorted(rows, key=lambda x: (x['path'] + ('/' if x['type'] == 'tree' else '')).encode()):
        mode = '40000' if row['mode'] == '040000' else row['mode']
        data += mode.encode() + b' ' + row['path'].encode() + b'\0' + bytes.fromhex(row['sha'])
    return hashlib.sha1(b'tree ' + str(len(data)).encode() + b'\0' + data).hexdigest()
meta = read(A / 'R6B-official-commit.json')
assert meta['sha'] == R and [x['sha'] for x in meta['parents']] == [P]
assert meta['tree']['sha'] == '6538f382443f8975d252b4ff084ef32688f31ac1'
comp = unwrap('R6B-install-compare-tool-response.json')
assert comp['base_commit']['sha'] == P and comp['total_commits'] == 1 and comp['commits'][0]['sha'] == R
manifest = read(C / 'upload-manifest.json')
installed = {x['repository_path']: x for x in manifest['files']}
assert len(installed) == len(comp['files']) == 2
for f in comp['files']:
    item = installed[f['filename']]; data = Path(item['local_path']).read_bytes()
    assert f['status'] == 'added' and f['sha'] == blob(data) == item['git_blob']
    assert len(data) == item['bytes'] and sha(data) == item['sha256'] and item['mode'] == '100644'
review_bytes = (C / 'independent-source-review.json').read_bytes()
assert sha(review_bytes) == 'b1bd27baa86c7beb38b92f29d36723fa715f72498646a796d12916a5a9bccd13'
review = json.loads(review_bytes)
old = read(A / 'prepared/seed-M7F-registry.json')
reg_bytes = (A / 'generated/scripts/reviewed-source-registry-v15.json').read_bytes()
reg = json.loads(reg_bytes)
assert sorted(k for k in old.keys() | reg.keys() if old.get(k) != reg.get(k)) == ['complete_inputs','delta','product_source','review_sha256','review_source']
assert reg['complete_inputs'] == review['complete_inputs'] and reg['delta'] == review['paths']
assert reg['validation_inputs'] == old['validation_inputs'] == review['validation_inputs']
assert (len(reg['complete_inputs']),len(reg['delta']),len(reg['validation_inputs'])) == (1095,72,142)
assert reg['product_source'] == review['source'] == P and reg['review_source'] == R and reg['review_sha256'] == sha(review_bytes)
changed_product = [k for k in reg['complete_inputs'] if old['complete_inputs'][k] != reg['complete_inputs'][k]]
assert changed_product == ['crates/cc-semantic/tests/p7_crash_preparation.rs']
assert set(reg['delta']) - set(old['delta']) == set(changed_product)
assert all(reg['delta'][k] == v for k,v in old['delta'].items())
old_guard = (A / 'prepared/seed-M7F-guard.py').read_text()
guard = (A / 'generated/scripts/verify_reviewed_source_v15.py').read_text()
names = ('PRODUCT','REVIEW','REVIEW_PATH','REGISTRY_SHA256')
normalize = lambda s: re.sub(r'^(PRODUCT|REVIEW|REVIEW_PATH|REGISTRY_SHA256) = .*$',r'\1 = <PIN>',s,flags=re.M)
assert normalize(old_guard) == normalize(guard)
assert len(old_guard.splitlines()) == len(guard.splitlines())
assert sum(a != b for a,b in zip(old_guard.splitlines(),guard.splitlines())) == 4
pins = {name: ast.literal_eval(re.search(r'^'+name+r' = (.+)$',guard,re.M)[1]) for name in names}
assert pins == {'PRODUCT':P,'REVIEW':R,'REVIEW_PATH':'artifacts/checkpoints/p8-crash-ready-publication-bfcc-20261009/independent-source-review.json','REGISTRY_SHA256':sha(reg_bytes)}
roots = unwrap('R6B-root-tree-tool-response.json'); scripts = unwrap('R6B-scripts-tree-tool-response.json')
assert not roots['truncated'] and not scripts['truncated']
assert tree(roots['tree']) == roots['sha'] == meta['tree']['sha']
assert tree(scripts['tree']) == scripts['sha'] == next(x['sha'] for x in roots['tree'] if x['path'] == 'scripts')
request = read(A / 'G6B-two-leaf-create-tree-request.json')
assert request['base_tree'] == roots['sha'] and len(request['tree']) == 2
new_scripts = copy.deepcopy(scripts['tree']); files = []
for row in request['tree']:
    path = row['path']; data = (A / 'generated' / path).read_bytes()
    seed = 'seed-M7F-registry.json' if path.endswith('.json') else 'seed-M7F-guard.py'
    old_data = (A / 'prepared' / seed).read_bytes()
    original = next(x for x in new_scripts if x['path'] == path.split('/',1)[1])
    assert original['sha'] == blob(old_data) and row['sha'] == blob(data)
    assert row['mode'] == original['mode'] == '100644' and row['type'] == original['type'] == 'blob'
    original['sha'] = row['sha']
    files.append({'path':path,'mode':row['mode'],'git_blob':row['sha'],'bytes':len(data),'sha256':sha(data)})
new_root = copy.deepcopy(roots['tree'])
next(x for x in new_root if x['path'] == 'scripts')['sha'] = tree(new_scripts)
expected_tree = tree(new_root)
assert expected_tree == 'e039a817291934b15cc018fd74d2c83982bb7f37'
actual = read(B / 'actual-G6B.original.json')
assert actual['sha'] == G and actual['tree']['sha'] == expected_tree and [x['sha'] for x in actual['parents']] == [R]
actual_comp = read(B / 'actual-R6B-to-G6B.original.json')
assert actual_comp['base_commit']['sha'] == R and actual_comp['total_commits'] == 1 and actual_comp['commits'][0]['sha'] == G
assert len(actual_comp['files']) == 2 and {x['filename']:x['sha'] for x in actual_comp['files']} == {x['path']:x['git_blob'] for x in files}
assert all(x['status'] == 'modified' for x in actual_comp['files'])
out = {'schema_version':1,'reviewer':'/root/pr_triage','verdict':'accepted_scoped_R6B_installation_G6B_bindings_and_actual_object_bridge',
    'actual_P':P,'actual_R':R,'actual_G':G,'actual_G_tree':expected_tree,'G_sole_parent':R,
    'R_exact_two_added_artifact_leaves':list(installed.values()),'G_exact_two_modified_binding_leaves':files,
    'registry_only_five_fields_changed':True,'guard_only_four_pin_lines_changed':pins,
    'canonical_maps_equal':{'product':1095,'BASE_delta':72,'validation':142},
    'prior_71_BASE_deltas_unchanged':True,'ordinary_validation_142_unchanged':True,
    'sole_product_map_change_from_M7F':'crates/cc-semantic/tests/p7_crash_preparation.rs',
    'M7F_preselect_fix_preserved':True,'BASE_FROZEN_CI_and_guard_logic_byte_preserved_after_four_pin_normalization':True,
    'source_review_signer':review['independent_reviewers'],'current_signer_scope':'Binding/install bridge only; source semantics remain the independently signed canonical R6B scope.',
    'map_scope':'Compared existing exact canonical registry maps; did not reread1095 source blobs or add a new full-domain gate.',
    'execution':'No source CLI, Rust, CI, native workload or measurement run performed. New G execution credit remains pending.',
    'publication':'Only root may decide a fresh expected-head normal FF. No ref mutation performed here.',
    'TODO_newly_done':0,'TODO_remaining':29}
with (B / 'independent-installed-R6B-G6B-review.json').open('x') as f: json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({'verdict':out['verdict'],'actual_G':G,'tree':expected_tree,'files':files}))
