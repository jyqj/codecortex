def stable_00003():
    return 3
