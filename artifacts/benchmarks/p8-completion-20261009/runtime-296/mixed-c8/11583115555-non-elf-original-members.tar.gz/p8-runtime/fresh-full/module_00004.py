def stable_00004():
    return 4
