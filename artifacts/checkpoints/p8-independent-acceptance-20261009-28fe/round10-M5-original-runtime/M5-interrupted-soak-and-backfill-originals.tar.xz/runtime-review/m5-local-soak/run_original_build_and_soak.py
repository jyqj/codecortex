from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source'
COMMIT = 'fec0698c7fa4d76076b828cc17cf277ad8b307e0'
TOOLCHAIN = Path('/workspace/scratch/2eaa00d0f93a/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
INPUTS = {
    'scripts/p8_runtime.py': 'bc33ed073a2e035912a4d6f1794ceec8b836243c2bbb46c8a4dddfcdda791559',
    'scripts/tests/test_p8_runtime_cache.py': 'c4ec698532f033f6364441cad4f6f41a19b3b020ffd0845b4d0e3eebb8c281d2',
    'scripts/tests/test_p8_runtime.py': '7443e63377f34f6f2340270425c61106e9a8a4ffa4d354cbfa47d6703db543b7',
}

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def source_identity():
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE).decode().strip()
    inputs = {p: hashlib.sha256((SOURCE / p).read_bytes()).hexdigest() for p in INPUTS}
    if head != COMMIT or inputs != INPUTS:
        raise RuntimeError('Frozen M5 source identity changed')
    return {'head': head, 'inputs': inputs}

def write_receipt():
    (ROOT / 'execution-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')

environment = os.environ.copy()
environment.update(PATH=str(TOOLCHAIN) + os.pathsep + environment.get('PATH', ''),
                   CARGO_HOME=str(ROOT / 'cargo-home'), CARGO_TARGET_DIR=str(ROOT / 'private-target'),
                   CARGO_TERM_COLOR='never', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2',
                   CARGO_NET_OFFLINE='true', PYTHONDONTWRITEBYTECODE='1')
if (ROOT / 'private-target').exists() or (ROOT / 'build').exists() or (ROOT / 'runtime').exists():
    raise RuntimeError('Original build and execution directories must be absent')
receipt = {
    'schema_version': 1, 'kind': 'original_fixed_M5_local_build_and_cache_soak',
    'started_at_utc': utc(), 'source': source_identity(), 'source_directory': str(SOURCE),
    'status': 'running', 'phases': [],
    'environment_selection': {k: environment[k] for k in ('CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_TERM_COLOR', 'CARGO_INCREMENTAL', 'CARGO_BUILD_JOBS', 'CARGO_NET_OFFLINE', 'PYTHONDONTWRITEBYTECODE')},
    'toolchain_directory': str(TOOLCHAIN), 'disk_free_before': shutil.disk_usage(ROOT).free,
    'execution_scope': 'Owned synthetic project with semantic disabled; original local hybrid result-cache reuse protocol. No live or paid provider.',
    'preserved_plan': {'profile': 'soak', 'concurrency_cap': 4, 'operations': 3601, 'offered_reads': 2400, 'files': 1000, 'interval_ms': 1000, 'duration_seconds': 3600, 'raw_budget_bytes': 536870912},
    'limits': ['No benchmark denominator is pooled with another source or run.', 'Original resource, terminal, cache and complete no-repair parity gates determine the actual result.', 'Task completion and aggregate scale acceptance are separate requirements.'],
}
write_receipt()

def run_phase(name, argv):
    phase = {'name': name, 'argv': argv, 'cwd': str(SOURCE), 'started_at_utc': utc(), 'source_before': source_identity(), 'status': 'running'}
    receipt['phases'].append(phase)
    write_receipt()
    started = time.monotonic()
    log_path = ROOT / (name + '.log')
    with log_path.open('xb') as log:
        result = subprocess.run(argv, cwd=SOURCE, env=environment, stdout=log, stderr=subprocess.STDOUT)
    raw = log_path.read_bytes()
    phase.update(exit_code=result.returncode, elapsed_seconds=time.monotonic() - started,
                 finished_at_utc=utc(), source_after=source_identity(),
                 log_path=str(log_path), log_bytes=len(raw), log_sha256=hashlib.sha256(raw).hexdigest(),
                 status='passed' if result.returncode == 0 else 'failed')
    write_receipt()
    print(json.dumps({'phase': name, 'exit_code': result.returncode, 'elapsed_seconds': phase['elapsed_seconds']}), flush=True)
    return result.returncode

try:
    build_code = run_phase('build', ['python3', '-B', 'scripts/p8_runtime_build.py', '--output', str(ROOT / 'build')])
    if build_code != 0:
        receipt.update(status='failed_build', runtime_status='not_run', finished_at_utc=utc())
        write_receipt()
        raise SystemExit(build_code)
    binary_args = ['--binary', str(ROOT / 'build' / 'codecortex'), '--oracle', str(ROOT / 'build' / 'p8-oracle'),
                   '--statistics', str(ROOT / 'build' / 'p8-runtime-statistics'), '--build-receipt', str(ROOT / 'build' / 'build-receipt.json')]
    run_code = run_phase('soak', ['python3', '-B', 'scripts/p8_runtime.py', *binary_args,
                                '--profile', 'soak', '--concurrency', '4', '--operations', '3601',
                                '--files', '1000', '--interval-ms', '1000', '--output', str(ROOT / 'runtime')])
    verify_code = run_phase('verify', ['python3', '-B', 'scripts/p8_runtime.py', 'verify', '--output', str(ROOT / 'runtime'), '--build-output', str(ROOT / 'build')])
    receipt.update(status='passed' if run_code == 0 and verify_code == 0 else 'failed_runtime_or_verification',
                   runtime_exit_code=run_code, verification_exit_code=verify_code,
                   finished_at_utc=utc(), disk_free_after=shutil.disk_usage(ROOT).free)
    write_receipt()
    raise SystemExit(run_code or verify_code)
except Exception as error:
    receipt.update(status='execution_infrastructure_failed', error=f'{type(error).__name__}: {error}', finished_at_utc=utc())
    write_receipt()
    raise
