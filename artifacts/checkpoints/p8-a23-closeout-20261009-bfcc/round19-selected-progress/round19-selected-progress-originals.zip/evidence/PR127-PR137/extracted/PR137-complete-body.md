固定 Requests public DEV native 全零中，candidate 的 159/249 个有答案执行行已有 path/name/v2 kind/source proof/span 同时匹配，但 171 个实际 hit 只因 qname namespace 严格相等失败。作者、owner、v2 独审保留模块前缀；产品传递 dotted lexical qname。报告区分这项 contract mismatch、另 90 行/255 个 group 未召回，以及 no-answer 的 Partial 失败，未裁定 gold 错误。

逐 1044 行原 raw 通过未改 normalizer/source verifier/scorer 重放，全部 hit/status/逐行 Scores 精确一致。独立微型实际子进程 MCP→原 scorer 复现词法 expectation 为 1、模块 expectation 为 0；nested hybrid miss 原样保留。1118 个归档文件、73 source、两侧 384/387 个源码 binding 二次核验通过。

只新增 artifacts/diagnostics/requests-native-zero-20261004/ 与一个 scoped test。无产品/gold/scorer/原 raw/排名/budget 变更，无 merge/deploy；旧 quality FAIL 不覆盖。locked build、2 scoped tests、新增 test rustfmt、diff --check 通过。历史 worker binaries 不在安全归档，未冒充重新核验其运行字节。

固定报告 commit: bc4e5602e10841258fb5583138419335bc9098dd
报告 README SHA256: 0a2301f90ebf96cd3325333ebc8a4d26a859d256cce90ca5efcd052315032f51

Base 选固定证据分支 dev-paired-requests-20261004；本 draft 仅用于诊断审阅，字段契约及产品后续修改交 root 决策。

## 2026-10-07 整合后处理

此 PR 保持开放，等待独立范围审查。固定 head：`bc4e5602e10841258fb5583138419335bc9098dd`；已合入 main 的比较源：`886f90a542a6174a037c79eebbb4f74848fb1f53`（整合 PR #142）。

固定源无祖先关系；delta 路径 0 同字节、0 演进、18 缺失、0 删除仍缺失、0 删除后重现；unique 非 merge 提交 0/3 有 raw-delta 匹配，unique merge 0 个。独立未集成的 Requests native-zero/qname 诊断能力及 18 条路径；parser qname 与 gold namespace 契约未闭合，历史 head CI 失败。保留诊断，不能借用其旧数字认证当前质量。

完整采用关系、缺口和处置快照记录在 `artifacts/checkpoints/pr-management-20261007/`，随当前推进批 PR #143 保存。后续按尚未采用的具体意图拆分迁移；旧 head 的 CI 与测量继续按原来源解释。
