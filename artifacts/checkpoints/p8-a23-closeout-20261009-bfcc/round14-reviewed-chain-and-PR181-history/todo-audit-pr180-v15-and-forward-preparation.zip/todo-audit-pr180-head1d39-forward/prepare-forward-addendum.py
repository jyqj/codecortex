import ast,copy,hashlib,json
from pathlib import Path
OUT=Path(__file__).resolve().parent
PLAN=Path('/dev/shm/todo-audit-pr180-merge-plan')
RAW=Path('/workspace/scratch/bfccb8494ba0/root-round13/current-merge-trees-transfer/extracted/pr180head4652.json')
module=ast.parse((PLAN/'audit-complete-trees.py').read_text())
exec(compile(ast.Module(body=[x for x in module.body if isinstance(x,ast.FunctionDef)],type_ignores=[]),str(PLAN/'audit-complete-trees.py'),'exec'))
rows=json.loads(RAW.read_text())['tree'];by_path={x['path']:x for x in rows}
request=json.loads(Path('/dev/shm/todo-audit-pr180-tree-elements/create-tree-request.json').read_text())
for item in request['tree_elements']:
 p=item['path'];by_path[p]=item
 parts=p.split('/')
 for i in range(1,len(parts)):
  d='/'.join(parts[:i]);by_path.setdefault(d,{'path':d,'mode':'040000','type':'tree','sha':'0'*40})
computed=compute_trees(list(by_path.values()))['']
assert computed=='9ae248f8e0c42a8a7389e26e3f44710dfb029640'
P=leafmap(list(by_path.values()))
ext=json.loads((OUT/'head1d39-complete-derived-tree.json').read_text());compute_trees(ext['tree'],'7a87a8e335de5c09d041b01f8802973ea96cd595');E=leafmap(ext['tree'])
changed=different(P,E)
bindings=['scripts/reviewed-source-registry-v15.json','scripts/verify_reviewed_source_v15.py']
fix=['crates/cc-db/src/index_db_write_batch.rs','crates/cc-db/src/snapshot_write_txn.rs','crates/cc-db/tests/p2b_resolution_store.rs']
added=sorted(E.keys()-P.keys());assert len(added)==7
prefix='artifacts/checkpoints/p8-main55-integration-28fe-20261009/'
assert all(x.startswith(prefix) and x.endswith(('.json','.md')) for x in added)
assert set(changed)==set(bindings+fix+added)
assert set(P)<=set(E)
assert not [x for x in P if x.startswith('docs/') or x=='README.md' if identity(P[x])!=identity(E[x])]
elements=[dict(path=p,**{k:E[p][k] for k in ['mode','type','sha']}) for p in added]
addition_data={'kind':'seven_exact_remote_history_artifact_additions_only','external_head':'1d39f382d4e08e702a55693c9c614fa477bf7e0c','base_tree_sha':'BIND_TO_ACTUAL_COMPLETED_OUR_G_TREE_BEFORE_CREATE_TREE','tree_elements':elements,'expected_publication_parents':['1d39f382d4e08e702a55693c9c614fa477bf7e0c','ACTUAL_OUR_G'],'do_not_create_from_null_or_empty_base':True}
addition_receipt=write('publication-additions.json',addition_data)
guard_before=(PLAN/'180guard.raw').read_text();guard_ext=(OUT/'guard.raw').read_text()
import re
norm=lambda s:re.sub(r'^(PRODUCT|REVIEW|REVIEW_PATH|REGISTRY_SHA256) = .*$',r'\1 = <PIN>',s,flags=re.M)
assert norm(guard_before)==norm(guard_ext)
reg=json.loads((OUT/'registry.raw').read_text());ours=json.loads((PLAN/'prospective-55aa-product-input-maps.json').read_text());assert reg['validation_inputs']==ours['validation_inputs']
assert set(reg['complete_inputs'])==set(ours['complete_inputs'])
assert sorted(p for p in reg['complete_inputs'] if reg['complete_inputs'][p]!=ours['complete_inputs'][p])==sorted(fix)
report={
 'schema':'PR180-external-head-forward-preservation-v1',
 'reviewed_at_utc':'2026-10-09 10:52:00 UTC',
 'scope':'Read-only source identities and original v15 contract; no new admission/runtime execution or remote mutation',
 'our_actual_P':'c92eb5ac7ece70d1f62271d7e2dacac513c285b5','our_P_tree':computed,
 'external':{'G':'1d39f382d4e08e702a55693c9c614fa477bf7e0c','G_tree':'7a87a8e335de5c09d041b01f8802973ea96cd595','R':'43128cdb18e39b9754dfd6614bc41c8ec5dab043','P':'7dbd126dd07f178d2bcc83da1aa47d55e4ee2436','P_parents':['4652cad11dde4b41126544a38fddf25eb2fb7474','55aa2bcf355441585bcf980e1d6f4fab8eebe59d']},
 'counts':{'product':1093,'delta':59,'validation':139},
 'full_repository_leaf_differences':{p:{'our_P':P.get(p),'external_G':E.get(p)} for p in changed},
 'product_difference_only_exact_three_v2_fixes':True,'validation139_mode_blob_and_SHA_equal':True,
 'README_all_docs_tasks_and_all_prior_artifact_files_equal':True,
 'new_external_artifacts':elements,
 'original_v15_allows_additive_archive_forward_merge':{
  'source_guard_logic': 'unchanged, external and branch guards differ only four pins',
  'v15_lines_143_201':'Reconstructs approved BASE→fixed PRODUCT and fixed REVIEW; verifies exact delta, complete product inputs, validation inputs and canonical R bytes.',
  'v15_lines_225_241':'Compares current tracked crates/Cargo and reviewed validation domain with the fixed reconstruction; checks exact CI selector. Does not require HEAD to equal PRODUCT or a designated G commit.',
  'history_lines_152_157':'Protects the fixed historical catalogue entries by bytes; does not authorize HEAD or scan every artifact archive as a new source input.',
  'bottom_level_v1_verify_tree':'Only current tracked product inventory, crates disk inventory, symlinks, and exact expected product bytes are checked.',
  'seven_new_paths':'New evidence-only JSON/Markdown in their own checkpoint; no product/validation/CI/old historical or our canonical review path changed.',
  'limits':'This source-level contract finding does not replace running original CI/v15 at actual published H. All execution records retain their real checkout identities.'},
 'minimal_forward_plan':[
  'Keep actual P c92 and let execution_recon finish its own independent R; root finishes actual G with only original four pins and registry.',
  'Create H as a merge descendant of the fresh existing PR180 head and completed ourG. For frozen external1d39 use ordered parents[1d39,ourG].',
  'Construct H tree from actual ourG tree plus exactly the seven immutable artifact additions in publication-additions.json; keep our completed G guard/registry and all original c92 product/validation bytes.',
  'Verify H product/139 validation/CI/canonical R and every existing ourG file remain byte/mode identical, and H additions are exactly seven external artifacts. Preserve external P/R/G through merge ancestry; do not overwrite old source-review records.',
  'Use ordinary fast-forward update only after asserting actual remote PR head lease. If head advanced again, reconcile the newly observed delta; never force reset it.',
  'Run/inspect original source-integrity/v15 CI at actual H, recording actual checkout and domain mapping. No extra N30 requirement is added, and no G/P or Gc8 sample is relabelled as an H execution.'
 ],
 'no_need_to_regenerate_P_R_G_if_only_these_seven_archive_files_are_added':True,
 'do_not_use_old_4652_lease_for_remote_update':True,
 'H_new_source_review_needed_if_product_validation_or_CI_changes':True,
 'P8_007_DB_acquisition_wait_gap_remains_open':True,
 'remaining_original_TODO':29,
 'helper_contract':'The installation helper may assert exact P→R→G ancestry as a local assembly expectation; that is not an original v15 restriction on a later archive-only H descendant.'
}
receipt=write('forward-preservation-and-v15-contract-review.json',report)
print(json.dumps({'report':receipt,'additions':addition_receipt,'full_leaf_difference_count':len(changed),'product_difference_count':len(fix)},indent=2))
