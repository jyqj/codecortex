def stable_00038():
    return 38
