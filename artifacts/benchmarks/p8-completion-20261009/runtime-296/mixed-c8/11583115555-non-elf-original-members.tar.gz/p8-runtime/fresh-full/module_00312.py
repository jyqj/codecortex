def stable_00312():
    return 312
