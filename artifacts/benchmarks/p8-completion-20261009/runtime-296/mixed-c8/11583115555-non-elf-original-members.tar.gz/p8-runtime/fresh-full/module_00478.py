def stable_00478():
    return 478
