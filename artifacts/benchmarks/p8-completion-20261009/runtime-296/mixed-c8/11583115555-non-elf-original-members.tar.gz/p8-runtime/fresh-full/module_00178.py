def stable_00178():
    return 178
