#!/usr/bin/env python3
"""Inspect retained original decoded job logs; never rerun any CI command."""
from pathlib import Path
import hashlib
import json
import re

ROOT=Path(__file__).resolve().parent
def read_response(name):
    x=json.loads((ROOT/name).read_bytes())['structuredContent']
    return json.loads(x['content']) if isinstance(x.get('content'),str) else x
def metadata(path):
    raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
                git_blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest())
def log(id):
    p=ROOT/f'{id}.original-decoded.log'
    return p,p.read_text(encoding='utf-8').splitlines()
def find(lines,text):
    hits=[dict(line=i+1,text=line) for i,line in enumerate(lines) if text in line]
    assert hits,text
    return hits
main_path,main=log(113902806069)
close_path,close=log(113902806369)
checks=read_response('checks.original.json')['check_runs']
mainjobs=read_response('main-jobs.original.json')['jobs']
closejobs=read_response('closeout-jobs.original.json')['jobs']
for name in ['main-run.original.json','closeout-run.original.json']:
    r=read_response(name)
    assert r['head_sha']=='88d5f547bb0fae273f4270742503fd1fd5e70bc2' and r['run_attempt']==1
    assert r['status']=='completed' and r['conclusion']=='success'
assert all(j['conclusion']=='success' for j in mainjobs+closejobs)
merge_path=Path('/dev/shm/pr-triage-round20-G6B-first-CI/merge-commit.original.json')
merge=json.loads(merge_path.read_bytes())
if 'structuredContent' in merge:merge=json.loads(merge['structuredContent']['content'])
assert merge['sha']=='4406b85f2abed05bc375aa38f3a90cf691380860'
assert merge['tree']['sha']=='e039a817291934b15cc018fd74d2c83982bb7f37'
assert '88d5f547bb0fae273f4270742503fd1fd5e70bc2' in [p['sha'] for p in merge['parents']]
find(main,'HEAD is now at 4406b85f Merge 88d5f547')
find(close,'HEAD is now at 88d5f547')
proof_line=next(x for x in main if '"schema_version": 10' in x and '"status": "passed"' in x)
proof=json.loads(proof_line[proof_line.index('{'):])
assert proof['product_source']=='5534ebf38cc31efec1590d132ca57c30e2f77f1b'
assert proof['review_source']=='22975e49107b3832f438f85b17275110fc0afa02'
assert proof['complete_inputs']==1095 and proof['executed_previous_proof']=='p8-oracle-compat-source-20261008-v14'
unit=find(main,'Ran 181 tests in 521.779s')[0]
assert main[unit['line']+1].endswith('OK')
pid=find(close,'test isolated_sigkill_reopen_replay_preparation ... ok')[0]
assert '1 passed; 0 failed; 1 ignored;' in close[pid['line']+1]
for lines in [main,close]:
    assert not any('test result: FAILED' in x or 'Process completed with exit code' in x for x in lines)
evidence={
    'main_checkout':find(main,'HEAD is now at 4406b85f'),
    'main_toolchain':find(main,'rustc 1.99.0'),
    'formatter':find(main,'##[group]Run cargo fmt --all -- --check'),
    'Clippy':find(main,'##[group]Run cargo clippy --workspace --all-targets -- -D warnings'),
    'compile':find(main,'##[group]Run cargo test --workspace --all-targets --locked --no-run'),
    'default_regression':find(main,'##[group]Run cargo test --workspace --all-targets --exclude cc-semantic --locked'),
    'source_tests181':unit,
    'selected_v15':dict(line=main.index(proof_line)+1,text=proof_line),
    'fixture_command':find(main,'##[group]Run cargo test -p cc-eval -- integration_fixtures_and_corpus --nocapture'),
    'fixture_pass':find(main,'test integration_tests::integration_fixtures_and_corpus ... ok'),
    'closeout_checkout':find(close,'HEAD is now at 88d5f547'),
    'closeout_toolchain':find(close,'rustc 1.95.0'),
    'PID_parent_test':pid,
    'PID_result':dict(line=pid['line']+2,text=close[pid['line']+1]),
    'owned_child_ignored_entry':find(close,'test crash_child ... ignored, child entry'),
    'source_before_after_assertion':find(close,"assert json.loads((out / 'source-before.json').read_text()) == after")}
report=dict(schema_version=1,observed_utc='2026-10-09T16:35:20Z',source_G6B='88d5f547bb0fae273f4270742503fd1fd5e70bc2',
            reviewer='/root/pr_triage',runs=dict(main=37954897576,closeout=37954897631),
            original_logs=[metadata(main_path),metadata(close_path)],
            log_transport='Purpose-built GitHub job-log connector downloaded each complete decoded log once; original UTF-8 including BOM/newline retained, byte lengths independently matched connector text. Not claimed as original HTTP compressed bytes.',
            actual_checkout=dict(main='4406b85f2abed05bc375aa38f3a90cf691380860',main_tree=merge['tree']['sha'],
              closeout='88d5f547bb0fae273f4270742503fd1fd5e70bc2',merge_object=metadata(merge_path)),
            main_jobs=mainjobs,closeout_jobs=closejobs,source_CLI_actual_output=proof,evidence=evidence,
            count=dict(total=len(checks),success=sum(x['conclusion']=='success' for x in checks),
                       in_progress=sum(x['status']=='in_progress' for x in checks)),
            remaining=[dict(id=x['id'],name=x['name'],status=x['status'],conclusion=x['conclusion']) for x in checks if x['conclusion']!='success'],
            engineering_assessment=dict(ready_for_review=True,observed_engineering_blockers=[],
              merge_recommendation='Eligible for normal engineering merge decision under actual repository checks; the original full150 study is not added as an engineering merge prerequisite.',
              pending_soak='Original G6B soak still running at observation, so not all checks green. Root owns final merge and any required-check enforcement.',
              distinction='Actual main CI runs the recorded all-targets default command, not a claim that an unrecorded literal cargo test --workspace or ignored real-workspace benchmark ran.',
              failure_history='Original b2 Empty PID failure remains a failure; this is the corrected fixed-source Linux regression passing, not erasure of that run.'),
            not_granted=['new P7B execution','oracle/payload candidate speedup','full scale acceptance','release acceptance','task completion'],
            task_ledger=dict(done=163,remaining=29,newly_completed=0))
out=ROOT/'independent-G6B-engineering-terminal-review.json'
with out.open('xb') as f:f.write((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps(dict(report=metadata(out),checks=report['count'],verdict='engineering_results_verified_soak_pending')))
