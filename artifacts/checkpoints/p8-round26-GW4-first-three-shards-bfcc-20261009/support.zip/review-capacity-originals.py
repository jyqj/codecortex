from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
B = Path(__file__).resolve().parent
R = B.parent / 'todo-audit-round25-50k-recovery/support/driver-reconstruction/intake_once.v2.py'
assert hashlib.sha256(R.read_bytes()).hexdigest() == '61f4ae48bc84dbc9f90862a80d06a8268ec4aa93f83c75582b716bc32f4c3369'
spec = importlib.util.spec_from_file_location('original_receiver', R)
receiver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(receiver)
records = []
for entry in json.loads((B / 'transfers.public-derived.json').read_text())['originals']:
    metadata = entry['metadata']
    if '-capacity-' not in metadata['name']:
        continue
    original = Path(entry['workspace_path'])
    digest = hashlib.sha256(original.read_bytes()).hexdigest()
    assert original.stat().st_size == metadata['size_in_bytes']
    assert 'sha256:' + digest == metadata['digest']
    assert metadata['workflow_run']['id'] == 37982220020
    assert metadata['workflow_run']['head_sha'] == '008f1ec0ae16b9b6aff9f20d033b17b2219168f8'
    output = B / ('capacity-' + str(metadata['id']))
    members = receiver.extract_original(original, output)
    with (output / 'original-zip-members.json').open('x') as stream:
        json.dump(members, stream, indent=2)
        stream.write('\n')
    report = json.loads((output / 'receipt.json').read_text())
    assert report['source_commit'] == metadata['workflow_run']['head_sha']
    assert report['context']['GITHUB_RUN_ID'] == '37982220020'
    assert report['context']['GITHUB_RUN_ATTEMPT'] == '1'
    assert report['status'] == 'capacity_available' and report['exit_code'] == 0
    assert report['profile'] == 'scale_capacity_v1'
    assert metadata['name'] == f"p8-scale-wide-dirty-capacity-{report['scale']}-0-37982220020"
    assert report['final']['free_bytes'] >= report['required_free_bytes']
    records.append({'artifact_id': metadata['id'], 'scale': report['scale'], 'repetition': 0,
                    'original_zip_sha256': digest, 'receipt': report, 'sample_credit': 0})
assert len(records) == 3 and {r['scale'] for r in records} == {1000, 5000, 10000}
with (B / 'capacity-original-intake-review.json').open('x') as stream:
    json.dump({'status': 'original_receipts_bound', 'samples': 0, 'records': records}, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': 'original_receipts_bound', 'receipts': len(records), 'samples': 0}))
