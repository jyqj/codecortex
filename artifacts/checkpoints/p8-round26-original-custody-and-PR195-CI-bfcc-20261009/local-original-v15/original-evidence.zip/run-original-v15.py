import datetime,hashlib,json,os,pathlib,stat,subprocess,time
base=pathlib.Path(__file__).resolve().parent;r=base/'source';out=base/'original-v15-attempt01';out.mkdir(exist_ok=False)
def digest(b):return hashlib.sha256(b).hexdigest()
def capture(label):
 entries={}
 for p in sorted(r.rglob('*')):
  if '.git' in p.relative_to(r).parts:continue
  if p.is_file():
   assert not p.is_symlink(),str(p)
   b=p.read_bytes();entries[p.relative_to(r).as_posix()]={'bytes':len(b),'sha256':digest(b),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'posix_mode':oct(stat.S_IMODE(p.stat().st_mode))}
 git={}
 for key,args in [('HEAD',['rev-parse','HEAD']),('tree',['rev-parse','HEAD^{tree}']),('status',['status','--porcelain=v1']),('product_tracked',['ls-files','--','crates','Cargo.toml','Cargo.lock']),('validation_tracked',['ls-files','--','scripts','.github/workflows','tests/source_integrity'])]:
  p=subprocess.run(['git',*args],cwd=r,capture_output=True,check=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});git[key]=p.stdout.decode()
 index=(r/'.git/index').read_bytes();result={'source':str(r),'entries':entries,'git':git,'index_sha256':digest(index)}
 (out/f'inputs-{label}.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 return result
argv=['python3','scripts/verify_reviewed_source_v15.py','--source-version','p8-completion-source-20261009-v15']
before=capture('before');assert before['git']['HEAD'].strip()=='34dc4e14dc96d077eae6173ab6885370323eff3f';assert before['git']['status']==''
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','GIT_OPTIONAL_LOCKS':'0'}
started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
(out/'started.json').write_text(json.dumps({'argv':argv,'cwd':str(r),'started_at':started,'environment_overrides':{'PYTHONDONTWRITEBYTECODE':'1','GIT_OPTIONAL_LOCKS':'0'},'count':len(before['entries'])},indent=2)+'\n')
print('started original v15 '+started+' entries '+str(len(before['entries'])),flush=True)
with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:
 p=subprocess.Popen(argv,cwd=r,env=env,stdout=so,stderr=se);(out/'pid.json').write_text(json.dumps({'pid':p.pid})+'\n');code=p.wait()
ended=datetime.datetime.now(datetime.timezone.utc).isoformat();elapsed=time.monotonic()-t
after=capture('after')
receipt={'argv':argv,'cwd':str(r),'started_at':started,'ended_at':ended,'duration_seconds':elapsed,'exit_code':code,'source_entries_equal':before['entries']==after['entries'],'git_equal':before['git']==after['git'],'index_equal':before['index_sha256']==after['index_sha256'],'entries':len(before['entries']),'stdout_bytes':(out/'stdout').stat().st_size,'stdout_sha256':digest((out/'stdout').read_bytes()),'stderr_bytes':(out/'stderr').stat().st_size,'stderr_sha256':digest((out/'stderr').read_bytes()),'scope':'original source admission CLI only; no benchmark/Rust or task completion'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');(out/'exit-code.txt').write_text(str(code)+'\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(code)
