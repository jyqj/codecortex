#!/usr/bin/env python3
import argparse, datetime, hashlib, json, pathlib, stat, sys, zipfile, zlib

parser=argparse.ArgumentParser()
parser.add_argument('--artifact',type=int,required=True)
parser.add_argument('--scale',type=int,choices=[1000,10000],required=True)
parser.add_argument('--zip-sha256',required=True)
args=parser.parse_args()
OUT=pathlib.Path('/dev/shm/p8-D0-diagnostic-validation')/str(args.artifact)
OUT.mkdir(exist_ok=False)
SOURCE='d0cb69c601e530dcef738af0c2dffb8d3b8bcf28'
ROOT=pathlib.Path('/workspace/scratch/2eaa00d0f93a/p8-D0-exact-source')
BUILD=pathlib.Path('/workspace/scratch/2eaa00d0f93a/p8-D0-build-11582571291/original')
RECEIVED=pathlib.Path('/dev/shm/p8-engineering-shard-reception')
ZIP=RECEIVED/(str(args.artifact)+'.zip')
SHARD=RECEIVED/str(args.artifact)
sys.path.insert(0,str(ROOT/'scripts'))
import p8_scale_matrix as original

before=original.source_snapshot(ROOT); driver_before=original.driver_snapshot(ROOT)
assert before['source_commit']==SOURCE
zip_digest=original.file_sha256(ZIP)
assert zip_digest==args.zip_sha256
members={}
with zipfile.ZipFile(ZIP) as z:
    for i in z.infolist():
        name=pathlib.PurePosixPath(i.filename)
        assert not name.is_absolute() and '..' not in name.parts
        assert i.filename not in members and not i.is_dir()
        assert stat.S_ISREG(i.external_attr>>16)
        body=z.read(i)
        assert len(body)==i.file_size and (zlib.crc32(body)&0xffffffff)==i.CRC
        digest=hashlib.sha256(body).hexdigest()
        assert original.file_sha256(SHARD/i.filename)==digest
        members[i.filename]={'bytes':len(body),'sha256':digest,'crc32':i.CRC}
inventory=original.inventory(SHARD)
assert inventory=={k:{'bytes':v['bytes'],'sha256':v['sha256']} for k,v in members.items()}
built,binary=original.validate_build(BUILD,ROOT)
build_inventory=original.inventory(BUILD)
receipt_digest=original.file_sha256(BUILD/'build.json')
validated=original.validate_shard(SHARD,built,binary,receipt_digest)
assert validated['plan']==original.registered_plan(args.scale,0,30,30,12648430,18000000,original.CAPACITY_PROFILE)
assert validated['engine']['engine_head_observed']==SOURCE
after=original.source_snapshot(ROOT);driver_after=original.driver_snapshot(ROOT)
assert before==after and driver_before==driver_after
assert original.inventory(SHARD)==inventory and original.inventory(BUILD)==build_inventory
assert original.file_sha256(ZIP)==zip_digest
native=original.read_json(SHARD/'native/report.json')
summary=original.read_json(SHARD/'native/worker-summary.json')
report={'schema':'p8-D0-original-diagnostic-independent-validation-v1',
 'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/acceptance_audit',
 'status':'accepted_scoped_one_original_engineering_diagnostic',
 'source':SOURCE,'artifact_id':args.artifact,'scale':args.scale,'zip_path':str(ZIP),
 'zip_sha256':zip_digest,'zip_bytes':ZIP.stat().st_size,'members':members,
 'shard_directory':str(SHARD),'shard_receipt_sha256':original.file_sha256(SHARD/'shard.json'),
 'original_validate_build_passed':True,'original_validate_shard_passed':True,
 'build_receipt_sha256':receipt_digest,'binary_sha256':built['binary_sha256'],'binary_blake3':built['binary_blake3'],
 'source_manifest_sha256':before['manifest_sha256'],'driver_snapshot':driver_before,
 'source_driver_ZIP_shard_and_build_all_unchanged_after_validation':True,
 'plan':validated['plan'],'engine':validated['engine'],'environment':validated['environment'],
 'sample_count':len(validated['measurements']),'groups':summary['groups'],
 'native_exit':native['exit_code'],'native_worker_exit':native['worker_exit_code'],
 'fixture_cleanup':native['fixture_cleanup'],'native_status':native['status'],
 'native_hash_only_calls':'Original validate_build binary digest; original validate_shard plan/raw digests.',
 'new_native_workload_executed':False,'Cargo_executed':False,
 'limits':['Engineering repetition0 only. This does not complete N30, replace a new study primary, or repair priorG/local study.',
 'Original entire scale raw, provenance, disk budget, phase coverage,15table oracle and fanout gates were unchanged.'],
 'TODO_closed':0,'TODO_remaining':29}
for name,body in [('source-before',before),('source-after',after),('validated',validated),('review',report)]:
    (OUT/(name+'.json')).write_bytes(original.json_bytes(body))
print(json.dumps({'status':report['status'],'artifact_id':args.artifact,'scale':args.scale,'groups':len(summary['groups']),
                  'samples':len(validated['measurements']),'review_sha256':original.file_sha256(OUT/'review.json')}))
