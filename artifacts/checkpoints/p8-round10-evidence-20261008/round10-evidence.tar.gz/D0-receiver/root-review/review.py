#!/usr/bin/env python3
"""Independent fixed-source/member-guard review; never invokes a native binary."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parent
RECEIVER = Path('/dev/shm/p8-D0-sequential-receiver/receive.py')
EXPECTED = '1c4b18b53c3dd3933b4dae822427f97fa4db803ed891ffe432457859047e1729'
MEMBERS_SHA = '190ccc4d9853aa076954494f2a1ae5fbb95b214a0745524bd182656787f49abc'
D0 = 'd0cb69c601e530dcef738af0c2dffb8d3b8bcf28'
CONTROLLER = 'ca72a2dde363e35203f7b3cb30ed00729d460fd7'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    assert sha(RECEIVER) == EXPECTED
    manifest_path = RECEIVER.with_name('upstream-members.json')
    assert sha(manifest_path) == MEMBERS_SHA
    manifest = json.loads(manifest_path.read_text())
    registration_path = Path('/dev/shm/p8-D0-full-study-controller-root/registration.json')
    assert sha(registration_path) == '4a56e31e9838f0db1d83a3efd4a10d0a51f8b443dbce4413e68253881740eebc'
    registration = json.loads(registration_path.read_text())
    assert sorted((bundle['artifact'] for bundle in manifest['bundles']), key=lambda row: row['id']) == registration['upstream_artifacts']
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location('root_reviewed_D0_receiver', RECEIVER)
    receiver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(receiver)
    assert receiver.SOURCE == D0 and receiver.CONTROLLER == CONTROLLER and receiver.RUN == 37854240827
    assert receiver.ATTEMPT == 1 and len(receiver.expected_names()) == 303
    required = receiver.expected_names() - {'p8-scale-matrix-37854240827'}
    assert len(required) == 302
    assert sum(name.startswith('p8-scale-shard-') for name in required) == 150
    assert sum(name.startswith('p8-scale-capacity-') for name in required) == 150
    repo = Path('/workspace/scratch/2eaa00d0f93a/p8-D0-exact-source')
    matrix, identities, observer = receiver.load_driver(repo)
    original = Path('/workspace/scratch/2eaa00d0f93a/p8-D0-full-study-reception/first-admission-expanded/expanded')
    upstream = original / 'p8-scale-admission-37854240827/p8-d0-upstream'
    build = original / 'p8-scale-build-37854240827'
    actual = receiver.verify_upstream_members(upstream, build, matrix)
    assert actual == {'manifest_sha256': MEMBERS_SHA, 'original_bundles': 6, 'original_members': 67}
    assert sha(RECEIVER) == EXPECTED and sha(manifest_path) == MEMBERS_SHA
    report = dict(status='accepted_scoped_D0_receiver_identity_and_original_member_guard',
                  reviewer='/root', receiver_sha256=EXPECTED, fixed_upstream_manifest_sha256=MEMBERS_SHA,
                  measured_source=D0, controller_source=CONTROLLER, run_id=37854240827, run_attempt=1,
                  complete_required_artifacts=302, optional_original_matrix_artifact=1,
                  primary_shards=150, primary_capacity_artifacts=150,
                  admission_diagnostics_are_not_primary=True, actual_upstream_member_verification=actual,
                  six_original_artifact_metadata_exact_registration=True,
                  immutable_original_driver_sha256=identities, original_capacity_observer_sha256=observer,
                  reviewed_constraints=['Artifact metadata belongs to the controller while native source/build/shards remain D0.',
                                        'Every original primary plan equals one fixed registration entry; all original combine rules remain.',
                                        'Full reception retains the mandatory admission and all 150 capacity/shard pairs before completion.',
                                        'The added member guard now binds both old capacity receipts alongside controls, diagnostics and build.',
                                        'Only new owned expansions may be reclaimed after complete original ZIP/inode/member proof; originals are retained.'],
                  scope='Read-only Git and all67 actual retained member inventories; no Cargo, native hash invocation or product measurement.',
                  remaining_validation='Original13 transport controls and peer second review are separate; no full150 primary reception was executed.',
                  TODO_closed=0, TODO_remaining=29)
    output = ROOT / 'review.json'
    output.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
    print(json.dumps(dict(status=report['status'], review_sha256=sha(output), actual_original_members=67, TODO_closed=0)))

if __name__ == '__main__':
    main()
