def stable_00000():
    return 0
