import ast,datetime,hashlib,json,collections
from pathlib import Path
OUT=Path(__file__).resolve().parent
PREVIOUS=OUT.parent/'db-wait-cleanup-P-3ced-independent'
API=OUT/'github-api'
P='bb290be2deaf4334863e09dbf47fe4ccc9625f2b'
# Reuse only our standalone metadata/hash functions, never the previous audit's top-level execution.
module=ast.parse((PREVIOUS/'audit_actual_P.py').read_text())
functions=ast.Module(body=[node for node in module.body if isinstance(node,ast.FunctionDef)],type_ignores=[])
exec(compile(functions,str(PREVIOUS/'audit_actual_P.py'),'exec'))
commit=api('commit.json');root=api('root-tree.json');crates=api('crates-tree.json')
before=load(PREVIOUS/'actual-P-complete-source-audit.json')
assert commit['sha']==P and [e['sha'] for e in commit['parents']]==[before['source']]
assert root['sha']==commit['tree']['sha']=='4dbe8ee3d09701c8563f42695b483ae104da0a2a'
assert tree_hash(root['tree'])==root['sha']
oldroot=json.loads(load(PREVIOUS/'github-api/root-tree.json')['content']);oldroots={e['path']:e for e in oldroot['tree']}
assert set(oldroots)=={e['path'] for e in root['tree']}
for e in root['tree']:
    if e['path']!='crates':assert all(e[k]==oldroots[e['path']][k] for k in ('mode','type','sha')),e['path']
assert next(e['sha'] for e in root['tree'] if e['path']=='crates')==crates['sha']
tree_count=1+verify_tree(crates)
raw='tree '+root['sha']+'\nparent '+before['source']+'\n'
for role in ['author','committer']:
    d=commit[role];stamp=int(datetime.datetime.fromisoformat(d['date'].replace('Z','+00:00')).timestamp())
    raw+=f"{role} {d['name']} <{d['email']}> {stamp} +0800\n"
raw+='\n'+commit['message'];assert git('commit',raw.encode())==P
(OUT/'actual-P1.commit').write_bytes(raw.encode())
v2=Path('/dev/shm/todo-audit-p8007-lock-observation-review/format-v2')
manifest=load(v2/'format-v2-manifest.json');changes={r['path']:r for r in manifest['files']}
inventory={p:dict(row) for p,row in before['actual_input_mode_blob_inventory'].items()}
actual_crates={'crates/'+e['path']:e for e in crates['tree'] if e['type']!='tree'}
assert set(actual_crates)=={p for p in inventory if p.startswith('crates/')}
for path,e in actual_crates.items():
    prior=inventory[path]
    if path in changes:
        r=changes[path];raw=Path(r['local_path']).read_bytes()
        assert e['mode']==prior['mode']=='100644' and e['type']==prior['type']=='blob'
        assert len(raw)==e['size']==r['after']['bytes'] and git('blob',raw)==e['sha']==r['after']['git_blob']
        assert sha256(raw)==r['after']['sha256'] and prior['sha256']==r['before']['sha256']
        dst=OUT/'source'/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw)
        inventory[path]={**{k:e[k] for k in ('mode','type','sha','size')},'sha256':sha256(raw)}
    else:assert all(prior[k]==e[k] for k in ('mode','type','sha','size')),path
complete={p:inventory[p]['sha256'] for p in before['complete_inputs']}
validation={p:inventory[p]['sha256'] for p in before['validation_inputs']}
delta={p:dict(d,sha256=complete[p]) for p,d in before['paths'].items()}
plan=load(v2/'prospective-P1-input-maps.json')
assert complete==plan['complete_inputs'] and validation==plan['validation_inputs'] and delta==plan['paths']
assert len(complete)==1095 and len(validation)==142 and len(delta)==67
assert all(set(d)=={'before_sha256','sha256'} for d in delta.values())
out={'schema_version':1,'scope':'Non-author actual P1 source identity bridge; no original source admission or native execution by this reviewer','source':P,'tree':root['sha'],'parents':[before['source']],'integration_parents_at_P0':before['parents'],'base':before['base'],'raw_commit_sha_independently_reconstructed':True,'official_root_and_crate_tree_objects_rehashed':tree_count,'all_non_crate_root_subtrees_mode_type_blob_equal_P0':True,'complete_inputs':complete,'validation_inputs':validation,'paths':delta,'actual_input_mode_blob_inventory':inventory,'counts':{'product':1095,'validation':142,'BASE_delta':67,'P0_to_P1_changed_product':2,'all_validation_unchanged':142},'P0_full_domain_audit':identity(PREVIOUS/'actual-P-complete-source-audit.json'),'two_test_whitespace_independent_review':identity(PREVIOUS/'two-test-whitespace-independent-review.json'),'P1_raw_source_manifest':identity(v2/'format-v2-manifest.json'),'historical_execution_boundary':{'P0_fetch':0,'P0_fmt':1,'P0_Rust_tests_started':False,'P0_receipts_verified_by_this_report':False,'P1_controls':'pending actual execution and retained-original peer review'},'no_original_TODO_or_scale_credit':True}
f=OUT/'actual-P1-complete-source-audit.json'
with f.open('x') as stream:json.dump(out,stream,indent=2);stream.write('\n')
print(json.dumps({'report':identity(f),'source':P,'counts':out['counts'],'trees':tree_count}))
