#!/usr/bin/env python3
"""Restore exact frozen helper bytes from published R31; no measurements."""
import hashlib,json,os,tarfile
from pathlib import Path
ROOT=Path("/workspace/scratch/a217aaae3bde")
HERE=ROOT/"original-LG2-runtime/recovery-input"
archive=HERE/"round31-public-evidence.tar.gz"
inventory=HERE/"round31-public-evidence-inventory.json"
def sha(b): return hashlib.sha256(b).hexdigest()
def oid(b): return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
raw=inventory.read_bytes()
assert len(raw)==104259 and oid(raw)=="b1bdd33d8a708a63f8bfd8e292ca9ecda0228543"
inv=json.loads(raw)
data=archive.read_bytes()
assert len(data)==2263977 and sha(data)=="bca9f1017421de6947b9a44bb4ce068e80f99ec907437aeb7e3fba42855b4c40"
assert oid(data)=="a46f45c47112fb2f212863ea02107b29a95efa44"
prefix="runtime/LG2-intake/"
selected=[x for x in inv["files"] if x["target"].startswith(prefix) and "/monitor-initial/" not in x["target"]]
records=[]
with tarfile.open(archive,"r:gz") as tf:
    members=tf.getmembers()
    assert len({m.name for m in members})==len(members)==inv["file_count"]
    table={m.name:m for m in members}
    for x in selected:
        m=table[x["target"]]
        assert m.isreg() and not m.pax_headers and m.mode==x["tar_mode"]
        b=tf.extractfile(m).read()
        assert len(b)==x["bytes"] and sha(b)==x["sha256"] and oid(b)==x["git_blob"]
        rel=Path(x["source"])
        assert not rel.is_absolute() and ".." not in rel.parts and rel.parts[0]=="original-LG2-runtime"
        dest=ROOT/rel
        if dest.exists():
            assert dest.is_file() and dest.read_bytes()==b and dest.stat().st_mode & 0o777 == m.mode
            action="verified_existing_unchanged"
        else:
            dest.parent.mkdir(parents=True,exist_ok=True)
            with dest.open("xb") as f: f.write(b)
            os.chmod(dest,m.mode)
            assert dest.read_bytes()==b
            action="restored_exact_published_bytes"
        records.append(dict(x,absolute_destination=str(dest),action=action))
result={"schema":"lg2-frozen-helper-recovery-v1","source_commit":"8a8cc951d6c198d0ea28c01eaaaaf12df903ab77","archive_path":"artifacts/checkpoints/p8-round31-a217-20261009/round31-public-evidence.tar.gz","archive_sha256":sha(data),"archive_git_blob":oid(data),"inventory_git_blob":oid(raw),"files":records,"no_original_acceptance_receipt_fabricated":True,"native_or_acceptance_execution":False}
out=HERE/"frozen-helper-recovery-receipt.json"
with out.open("x") as f: json.dump(result,f,ensure_ascii=False,sort_keys=True,indent=2);f.write("\n")
print(json.dumps({"files":len(records),"receipt":str(out),"sha256":sha(out.read_bytes())}))
