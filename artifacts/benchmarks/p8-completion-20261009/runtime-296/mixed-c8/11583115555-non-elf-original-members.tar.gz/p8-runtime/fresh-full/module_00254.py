def stable_00254():
    return 254
