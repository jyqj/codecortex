def stable_00297():
    return 297
