def stable_00412():
    return 412
