## Round 10 evidence checkpoint; round 11 continues

**Original task ledger: 192 total / 163 done / 16 in progress / 12 todo / 1 blocked. Newly completed original TODOs: 0. Remaining: 29.** The target remains ten original TODOs, P8-005 through P8-013 plus P8-016; scoped evidence or review controls are not counted as task completion.

The immutable [round 10 checkpoint](https://github.com/jyqj/codecortex/tree/64230c8a628813d4f4f7c733e9779f17e85606b8/artifacts/checkpoints/p8-round10-evidence-20261008) is published on a separate evidence branch. Its commit has G4 `260f596582f2d82b8d7c707b61a6b8b6a43b069f` as its sole parent and changes four artifact files only. The packet contains 428 members (7,315,292 uncompressed bytes), a complete member/hash manifest, receiver code, original records, and scoped independent reviews. Large original ZIPs remain separately identified by their GitHub artifact IDs, sizes and digests; the checkpoint is not a replacement for those raw archives.

### Actual G4 evidence received

- [Lifecycle run 37854847926](https://github.com/jyqj/codecortex/actions/runs/37854847926): successful original job and ZIP, all 2,391 members checked. The original evaluator and retained Rust statistics replay passed with byte-identical output: 1,230 observations, 431 sessions, 400 distinct PIDs, 1,261 resource observations and a complete bidirectional inventory of 90 physical storage objects. Cold-start upper-tail and OS page-cache limitations remain explicit.
- [Failure-gate run 37854847767](https://github.com/jyqj/codecortex/actions/runs/37854847767): all 337 original members checked; the six original Rust controls passed with zero ignored tests. Two library controls and four CLI test functions preserve five distinct comparison outputs and six actual CLI invocations, including nonzero quality/latency/inconclusive/lock/policy outcomes.
- Both received datasets retain their actual G4 source, original Cargo/build/observer identities, transport logs and independent audits. They do not close P8-008/009/013 while preceding dependencies remain open.

### CI failure is preserved and being repaired

[G4 CI 37854847836](https://github.com/jyqj/codecortex/actions/runs/37854847836) is **not passing**. Security passed; the check job passed all 372 P8 Python controls and all 181 source-integrity tests, then failed the unchanged historical-integration guard because main had reintroduced the excluded historical paired directory. Later steps did not run. The complete original failure log and audit are in the checkpoint.

Existing [PR #165](https://github.com/jyqj/codecortex/pull/165) addresses that archive-path conflict. A separate independent tree review verified all 188 original files, nested tree IDs, blob IDs and modes are preserved, with unchanged historical failure/inconclusive status and zero new acceptance. Its actual required CI was still queued at the latest observation; this is not a merge-ready or CI-pass claim.

### Scale and remaining work

The separately registered [D0 full-scale study 37854240827](https://github.com/jyqj/codecortex/actions/runs/37854240827) keeps measured source D0 and controller source ca72 distinct. Admission, the re-uploaded original build and the first capacity checks were received and independently verified. At the latest round 11 observation, 4 of the 150 primary measurement jobs had started, 146 were queued and none had a terminal measurement result. The complete receiver has passed all 15 controls and two independent reviews; no partial matrix has been accepted.

The original G study's 100k/index-1 runner shutdown, exit 143 and missing raw upload are preserved in this checkpoint. No original study has been rerun, cancelled, replaced, pooled with D0 or omitted from reporting.

Round 11 continues with the full scale matrix, actual G4 runtime/soak/platform/recovery evidence and required CI. **This PR remains a draft; no original TODO status changed.**
