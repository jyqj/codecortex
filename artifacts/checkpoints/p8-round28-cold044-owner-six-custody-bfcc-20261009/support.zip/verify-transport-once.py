from pathlib import Path, PurePosixPath
import datetime, hashlib, json, stat, zipfile

B = Path(__file__).resolve().parent
OUT = B / 'transport-verification-attempt01'
OUT.mkdir(exist_ok=False)
SOURCE = '044c008c9459cfa61e7701db2eb868342c508a39'
RUN = 37954851017
EXPECTED = {(100000, n) for n in [4, 5, 6, 7, 8, 11]}
ROOT = B.parent

def load(p):
    return json.loads(p.read_bytes())

def identities(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}

def write(name, value):
    p = OUT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')
    return {'path': str(p), **identities(p.read_bytes())}

selection = load(B / 'official-original-selection.json')
references = load(B / 'download-references.public-derived.json')
old_ledger_path = ROOT / 'cold044-original-intake/initial-claim-and-official-ledger.json'
old_ledger = load(old_ledger_path)['ledger']
assert selection['source'] == SOURCE and selection['run_id'] == RUN and selection['attempt'] == 1
assert selection['new_slot_count'] == 0 and selection['previously_accepted_custody_slots'] == 6
assert {(s['scale'], s['repetition']) for s in selection['slots']} == EXPECTED
assert {(s['scale'], s['repetition']) for s in old_ledger['excluded_owner_unpublished']} == EXPECTED
items = references['items']
assert len(items) == 12 and len({it['artifact']['id'] for it in items}) == 12
officials = {a['official']['id']: a['official'] for s in selection['slots'] for a in s['artifacts']}
build_before = load(ROOT / 'cold044-original-intake/original-build-validation-attempt01/source-before.json')
assert build_before['source']['source_commit'] == SOURCE
progress = []
for it in items:
    a = it['artifact']
    assert a == officials[a['id']]
    assert a['workflow_run']['head_sha'] == SOURCE and a['workflow_run']['id'] == RUN
    zip_path = ROOT / it['relative_directory'] / it['file_name']
    data = zip_path.read_bytes()
    before = identities(data)
    assert before['bytes'] == a['size_in_bytes'] and 'sha256:' + before['sha256'] == a['digest']
    records = []
    json_payloads = {}
    with zipfile.ZipFile(zip_path) as z:
        names = set()
        for member in z.infolist():
            assert '\x00' not in member.orig_filename
            path = PurePosixPath(member.filename)
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in member.filename
            assert member.filename not in names
            names.add(member.filename)
            mode = member.external_attr >> 16
            assert not stat.S_ISLNK(mode)
            if member.is_dir():
                continue
            raw = z.read(member)  # The one authorized transport CRC check, not an original study validator.
            row = {'path': member.filename, 'zip_crc32': member.CRC, 'zip_mode': oct(mode), **identities(raw)}
            records.append(row)
            if member.filename.endswith('.json'):
                json_payloads[member.filename] = raw
    byname = {r['path']: r for r in records}
    identity = None
    if it['kind'] == 'shard':
        outer = json.loads(json_payloads['cold-shard.json'])
        native = json.loads(json_payloads['native-shard/shard.json'])
        plan = json.loads(json_payloads['native-shard/native/plan.json'])
        report = json.loads(json_payloads['native-shard/native/report.json'])
        assert native['source_commit'] == SOURCE and outer['driver_source']['source_commit'] == SOURCE
        assert outer['study'] == {'protocol': 'p8-cold-only-study-v1', 'run_attempt': 1, 'run_id': str(RUN)}
        assert plan['files'] == [it['scale']] and plan['shard'] == {'count': 30, 'index': it['repetition']}
        assert plan['stage_scope'] == 'cold_only_v1' and plan['capacity_profile'] == 'scale_capacity_v1'
        assert native['plan'] == plan
        assert json_payloads['native-shard/source-before.json'] == json_payloads['native-shard/source-after.json']
        assert json.loads(json_payloads['native-shard/source-before.json']) == build_before['source']
        assert native['binary_sha256'] == '09ef70915331298bbb2fcda3e2526a89757c1385ef3c8e7926c39c73bf8ecdae'
        for name, declared in outer['files'].items():
            assert byname[name]['bytes'] == declared['bytes'] and byname[name]['sha256'] == declared['sha256']
        identity = {'source': SOURCE, 'study': outer['study'], 'scale': it['scale'], 'repetition': it['repetition'],
                    'stage_scope': plan['stage_scope'], 'capacity_profile': plan['capacity_profile'],
                    'native_original_exit_code': report['exit_code'], 'outer_original_status': outer['status'],
                    'same_build_binary_sha256': native['binary_sha256'], 'source_before_after_same_original_build': True,
                    'outer_seal_matches_original_member_bytes': True, 'new_validation_or_sample_credit': 0}
        # Preserve small original metadata and exact source manifests; raw.jsonl stays in the unchanged whole ZIP.
        keep = ['cold-shard.json', 'native-shard/shard.json', 'native-shard/native/plan.json',
                'native-shard/native/report.json', 'native-shard/source-before.json', 'native-shard/source-after.json']
        for name in keep:
            p = OUT / 'metadata' / str(a['id']) / name
            p.parent.mkdir(parents=True, exist_ok=True)
            with p.open('xb') as f:
                f.write(json_payloads[name])
    else:
        assert it['kind'] == 'capacity' and len(records) == 1 and records[0]['path'] == 'receipt.json'
        p = OUT / 'metadata' / str(a['id']) / 'receipt.json'
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open('xb') as f:
            f.write(json_payloads['receipt.json'])
    after = identities(zip_path.read_bytes())
    assert before == after
    member_receipt = write('members/' + str(a['id']) + '.json', records)
    progress.append({'artifact': a, 'kind': it['kind'], 'slot': {'scale': it['scale'], 'repetition': it['repetition']},
                     'original_zip': {'local_path': str(zip_path), **before}, 'zip_before_after_equal': True,
                     'crc_complete': True, 'member_count': len(records), 'member_receipt': member_receipt,
                     'source_identity_metadata': identity, 'new_sample_credit': 0})
    write('progress-' + str(a['id']) + '.json', progress[-1])

summary = {'schema': 'cold044-owner-six-custody-recovery-v1', 'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'source': SOURCE, 'run_id': RUN, 'attempt': 1, 'original_zip_count': 12,
           'previously_accepted_slots': [{'scale': a, 'repetition': b} for a, b in sorted(EXPECTED)],
           'reason': selection['scope'], 'owner_head_observed_unchanged': selection['owner_head'],
           'prior_ledger': {'path': str(old_ledger_path), **identities(old_ledger_path.read_bytes()),
                            'excluded_owner_unpublished': old_ledger['excluded_owner_unpublished'], 'claim_comment': old_ledger['claim_comment']},
           'recovery_coordination_comment': 'https://github.com/jyqj/codecortex/pull/189#issuecomment-6089457882',
           'transport_recovery_calls': 12, 'transport_failures': 0,
           'original_validate_build_executions': 0, 'original_validate_shard_executions': 0,
           'workload_executions': 0, 'newly_accepted_samples': 0,
           'accepted_population_unchanged_by_this_recovery': True, 'custody_slots_recovered': 6,
           'aggregate_function_not_executed_here': True, 'aggregate_identity_bridge': 'Owned separately by /root/pr_triage; link separately when received.',
           'originals': progress, 'newly_completed_todos': 0, 'remaining_todos': 29}
print(json.dumps(write('summary.json', summary)))
