"""Synthetic transport controls; original files and product executables are untouched."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import receive
from test_receive import matrix


class UpstreamMemberControls(unittest.TestCase):
    def test_all67_members_capacity_mutation_missing_extra_and_manifest_tamper_rejected(self):
        # Real tiny files exercise set/bytes/hash logic. The expected manifest is
        # explicitly synthetic; only its immutable pin/location are substituted.
        original = receive.read_json(Path(receive.__file__).with_name('upstream-members.json'))
        with tempfile.TemporaryDirectory(prefix='D0-member-contract-') as temporary:
            root = Path(temporary)
            upstream, build = root/'upstream', root/'build'
            manifest = copy.deepcopy(original)
            capacity_paths = []
            for bundle in manifest['bundles']:
                item = bundle['artifact']
                folder = build if item['id'] == 11582571291 else upstream/item['name']
                for name in bundle['files']:
                    path = folder/name
                    path.parent.mkdir(parents=True, exist_ok=True)
                    value = ('SYNTHETIC '+item['name']+'/'+name).encode()
                    path.write_bytes(value)
                    bundle['files'][name] = dict(bytes=len(value), sha256=hashlib.sha256(value).hexdigest())
                    if 'capacity' in item['name']:
                        capacity_paths.append(path)
            self.assertEqual(len(capacity_paths), 2)
            manifest_path = root/'upstream-members.json'
            manifest_path.write_text(json.dumps(manifest, sort_keys=True))
            pinned = receive.digest(manifest_path)
            with mock.patch.object(receive, '__file__', str(root/'receive.py')), \
                 mock.patch.object(receive, 'UPSTREAM_MEMBERS_SHA256', pinned):
                check = lambda: receive.verify_upstream_members(upstream, build, matrix)
                self.assertEqual(check()['original_members'], 67)
                for path in capacity_paths:
                    original_bytes = path.read_bytes()
                    path.write_bytes(original_bytes+b'changed')
                    with self.assertRaisesRegex(ValueError, 'member bytes/set changed'):
                        check()
                    path.write_bytes(original_bytes)
                    path.unlink()
                    with self.assertRaisesRegex(ValueError, 'member bytes/set changed'):
                        check()
                    path.write_bytes(original_bytes)
                extra = build/'unexpected'
                extra.write_bytes(b'extra')
                with self.assertRaisesRegex(ValueError, 'member bytes/set changed'):
                    check()
                extra.unlink()
                self.assertEqual(check()['original_bundles'], 6)
                manifest_path.write_text(json.dumps(manifest, sort_keys=True)+' ')
                with self.assertRaisesRegex(ValueError, 'manifest changed'):
                    check()


class IdentityControls(unittest.TestCase):
    def test_source_controller_registration_attempt_and_missing_admission_fail_closed(self):
        with tempfile.TemporaryDirectory(prefix='D0-identity-contract-') as temporary:
            root = Path(temporary)
            artifacts = []
            names = receive.expected_names()-{f'p8-scale-matrix-{receive.RUN}'}
            for number, name in enumerate(sorted(names), 1):
                path = root/(name+'.zip')
                path.write_bytes(b'SYNTHETIC metadata population only')
                artifacts.append(dict(id=number, name=name, size_in_bytes=path.stat().st_size,
                    digest='sha256:'+receive.digest(path), expired=False,
                    workflow_run=dict(id=receive.RUN, head_sha=receive.CONTROLLER), archive_path=path.name))
            inventory = dict(schema='p8-fixed-D0-scale-download-set-v1', run_id=receive.RUN,
                run_attempt=1, source_commit=receive.SOURCE, controller_commit=receive.CONTROLLER,
                registration_sha256=receive.REGISTRATION_SHA256, artifacts=artifacts)
            self.assertEqual(len(receive.artifact_set(inventory, root)), 302)
            for key, wrong in [('source_commit',receive.CONTROLLER),('controller_commit',receive.SOURCE),
                               ('registration_sha256','f'*64),('run_attempt',2)]:
                changed = copy.deepcopy(inventory)
                changed[key] = wrong
                with self.subTest(key=key), self.assertRaises(ValueError):
                    receive.artifact_set(changed, root)
            changed = copy.deepcopy(inventory)
            changed['artifacts'][0]['workflow_run']['head_sha'] = receive.SOURCE
            with self.assertRaisesRegex(ValueError, 'another source'):
                receive.artifact_set(changed, root)
            changed = copy.deepcopy(inventory)
            changed['artifacts'] = [a for a in changed['artifacts'] if a['name'] != receive.ADMISSION_NAME]
            with self.assertRaisesRegex(ValueError, '302'):
                receive.artifact_set(changed, root)


if __name__ == '__main__':
    unittest.main(verbosity=2)
