def stable_00320():
    return 320
