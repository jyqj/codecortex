"""Read-only original archive integrity review, not the four-cell acceptance."""
from pathlib import Path, PurePosixPath
from collections import Counter
import datetime
import hashlib
import json
import stat
import sys
import zipfile
import zlib

ROOT = Path(__file__).resolve().parent
SOURCE_ROOT = Path('/workspace/scratch/2eaa00d0f93a/p8-G4-exact-source')
SOURCE = '260f596582f2d82b8d7c707b61a6b8b6a43b069f'
RUN = 37854847820
JOB = 113576446998
ARTIFACT = 11588372461
sys.path.insert(0, str(SOURCE_ROOT / 'scripts'))
import p7_build_identity as identity
import p8_runtime_build as original_build

def require(value, message):
    if not value:
        raise AssertionError(message)

def load(path):
    return json.loads(path.read_text())

def write(path, value):
    with path.open('xb') as output:
        output.write((json.dumps(value, sort_keys=True, indent=2) + '\n').encode())

source_before = identity.source_snapshot(SOURCE_ROOT)
observer_before = original_build.observer_snapshot(SOURCE_ROOT)
require(source_before['source_commit'] == SOURCE, 'source differs')
run, job, meta = load(ROOT/'run.json'), load(ROOT/'C16-job.json'), load(ROOT/'C16-artifact-metadata.json')
require(run['id'] == RUN and run['head_sha'] == SOURCE and run['run_attempt'] == 1, 'run differs')
require(job['id'] == JOB and job['run_id'] == RUN and job['head_sha'] == SOURCE and job['run_attempt'] == 1, 'job differs')
require(job['name'] == 'mixed (16)' and job['status'] == 'completed' and job['conclusion'] == 'success', 'job not successful')
require(meta['id'] == ARTIFACT and meta['name'] == 'p8-mixed-c16-' + SOURCE and not meta['expired'], 'artifact differs')
require(meta['workflow_run']['id'] == RUN and meta['workflow_run']['head_sha'] == SOURCE, 'artifact origin differs')
archive_path = ROOT / f'C16-artifact-{ARTIFACT}.zip'
archive_hash = identity.file_sha256(archive_path)
require(meta['size_in_bytes'] == archive_path.stat().st_size and meta['digest'] == 'sha256:' + archive_hash, 'original ZIP/API digest differs')
members = {}
with zipfile.ZipFile(archive_path) as archive:
    infos = archive.infolist()
    require(len(infos) == 2125 and sum(x.file_size for x in infos) == 72044678, 'received central directory differs')
    for info in infos:
        name = PurePosixPath(info.filename)
        require(not name.is_absolute() and '..' not in name.parts and str(name) == info.filename, 'unsafe member')
        require(not info.is_dir() and stat.S_ISREG(info.external_attr >> 16) and info.filename not in members, 'nonregular or duplicate member')
        count, crc, h = 0, 0, hashlib.sha256()
        with archive.open(info) as content:
            for block in iter(lambda: content.read(1024 * 1024), b''):
                count += len(block)
                h.update(block)
                crc = zlib.crc32(block, crc)
        require(count == info.file_size and crc & 0xffffffff == info.CRC, 'member bytes/CRC differs')
        members[info.filename] = {'bytes': count, 'sha256': h.hexdigest(), 'crc32': info.CRC, 'extracted': False}
    def read(name):
        return json.loads(archive.read(name))
    def inventory(prefix):
        return {name[len(prefix) + 1:]: {'bytes': row['bytes'], 'sha256': row['sha256']}
                for name, row in members.items() if name.startswith(prefix + '/') and name != prefix + '/seal.json'}
    for prefix in ('p8-build', 'p8-runtime'):
        require(read(prefix + '/seal.json')['artifact_inventory'] == inventory(prefix), 'original seal inventory differs')
    receipt = read('p8-build/build-receipt.json')
    plan = read('p8-runtime/plan.json')
    report = read('p8-runtime/report.json')
    require(receipt['status'] == 'passed' and receipt['build_exit_code'] == 0, 'original build did not pass')
    require(receipt['source_before'] == receipt['source_after'] == source_before, 'complete source binding differs')
    require(receipt['observer_before'] == receipt['observer_after'] == observer_before, 'observer binding differs')
    require(plan['build_identity']['source'] == source_before and plan['build_identity']['observer'] == observer_before, 'plan identity differs')
    require(report['final_build_verification'] == plan['build_identity'], 'final identity differs')
    require(report['status'] == 'passed_observation' and report['exit_code'] == 0 and report['artifact_seal_status'] == 'sealed', 'original runtime report did not pass')
    require(report['raw_sha256'] == members['p8-runtime/raw.jsonl']['sha256'] and report['plan_sha256'] == members['p8-runtime/plan.json']['sha256'], 'raw/plan binding differs')
    require(plan['profile'] == 'mixed' and plan['concurrency'] == 16 and plan['operations'] == 900 and plan['files'] == 1000, 'original population differs')
    require(plan['offer_interval_ms'] == 500 and plan['queue_capacity'] == 128 and plan['request_timeout_seconds'] == 60, 'original schedule/bounds differ')
    raw = [json.loads(line) for line in archive.read('p8-runtime/raw.jsonl').splitlines()]
    operations = [row for row in raw if row['kind'] == 'operation']
    require(len(operations) == 900 and sorted(row['id'] for row in operations) == list(range(900)), 'offered denominator differs')
    outcomes = dict(Counter(row['status'] for row in operations))
    require(outcomes == report['outcomes'] == {'success': 900}, 'actual terminal outcomes differ')
    require(Counter(row['operation'] for row in operations) == {'read': 600, 'build': 300}, 'primary strata differ')
    mutation_counts = dict(Counter(row['mutation']['action'] for row in operations if row['operation'] == 'build'))
    require(len(mutation_counts) == 6 and set(mutation_counts.values()) == {50}, 'mutation strata differ')
    parity = read('p8-runtime/parity.json')
    tables = parity['comparison']['tables']
    require(parity['exit_code'] == 0 and parity['error'] is None and parity['comparison']['equal'] is True and not parity['comparison']['different_tables'], 'original parity failed')
    require(len(tables) == 15 and [row['table'] for row in tables] == parity['tables'], 'original table population differs')
    require(all(row['equal'] and row['different_row_count'] == 0 and row['full_rows'] == row['incremental_rows'] and row['full_digest'] == row['incremental_digest'] for row in tables), 'original per-table parity differs')
    require(report['parity_sha256'] == members['p8-runtime/parity.json']['sha256'], 'parity binding differs')
    require(archive.read('p8-runtime/statistics.json') == archive.read('p8-runtime/statistics-replay.json'), 'original producer statistics replays differ')
require(identity.file_sha256(archive_path) == archive_hash, 'ZIP changed during inspection')
require(identity.source_snapshot(SOURCE_ROOT) == source_before and original_build.observer_snapshot(SOURCE_ROOT) == observer_before, 'source or observer changed')
write(ROOT/'C16-member-hashes.json', {'members': members, 'zip_sha256': archive_hash, 'status': 'all_original_members_streamed_and_retained_in_original_ZIP'})
result = {'status': 'accepted_original_C16_archive_integrity_only', 'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'run_id': RUN, 'job_id': JOB, 'artifact_id': ARTIFACT, 'source_commit': SOURCE, 'member_count': len(members),
          'zip_sha256': archive_hash, 'zip_bytes': archive_path.stat().st_size, 'expanded_bytes': sum(row['bytes'] for row in members.values()),
          'primary_N': {'read': 600, 'build': 300}, 'outcomes': outcomes, 'mutation_N': mutation_counts,
          'original_parity_tables': 15, 'source_and_observer_unchanged': True, 'new_TODO_done': 0, 'TODO_remaining': 29,
          'not_yet_accepted': ['The fixed C1/C4/C8/C16 four-cell set is not complete.', 'The original independent Rust statistics replay and complete mixed collector have not been run.'],
          'execution_scope': 'All archive members streamed for CRC and SHA; no extraction, Cargo, product, oracle or native statistics execution.'}
write(ROOT/'C16-integrity-review.json', result)
print(json.dumps(result))
