"""One frozen C recovery evidence replay; never executes fault workloads."""
import datetime,hashlib,json,os,pathlib,subprocess,sys,time
B=pathlib.Path(__file__).resolve().parent;A=B/'artifacts/11611995300';H=B/'recovery-helpers-C3ff-v1';S=B.parent/'scale-original-c3ff';HEAD='3ffcefc3b28ee1a4ed80caecebd7208a45c3e302';O=B/'accepted/recovery-11611995300-3ffcefc3-independent'
record=A/'actual-acceptance-execution.json';assert not record.exists() and not (A/'extracted').exists() and not O.exists()
def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def snap():return {str(p):sha(p) for p in sorted(H.glob('*.py'))}
m=json.loads((A/'artifact-metadata.json').read_text());z=A/'11611995300.zip'
assert m['id']==11611995300 and m['workflow_run']['id']==37908825722 and m['workflow_run']['head_sha']==HEAD
assert z.stat().st_size==m['size_in_bytes'] and sha(z)==m['digest'].removeprefix('sha256:')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==HEAD
peer=B.parent/'original-C3ff-platform-gates/C-recovery-helper-adaptation-independent-review.json';assert sha(peer)=='6563383efdd3c3e29c4648cb72abee4e4e3150cf88d3b1d1f70ae8932a0534b7'
r=dict(schema='C-recovery-original-acceptance-execution-v1',source=HEAD,workflow_run=37908825722,artifact_id=m['id'],started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_zip_sha256_before=sha(z),original_zip_bytes=z.stat().st_size,helper_inputs_before=snap(),peer_review=dict(path=str(peer),sha256=sha(peer)),commands=[],status='started',new_native_workload=False)
def save():record.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
def run(label,argv):
 row=dict(label=label,command=argv,cwd=str(B),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat());r['commands'].append(row);save();start=time.monotonic()
 with (A/(label+'.stdout')).open('xb') as out,(A/(label+'.stderr')).open('xb') as err:
  try:q=subprocess.run(argv,cwd=B,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','GIT_NO_LAZY_FETCH':'1'},stdout=out,stderr=err,timeout=900);row['exit_code']=q.returncode
  finally:row['elapsed_seconds']=time.monotonic()-start;save()
 row.update(stdout=dict(path=str(A/(label+'.stdout')),bytes=(A/(label+'.stdout')).stat().st_size,sha256=sha(A/(label+'.stdout'))),stderr=dict(path=str(A/(label+'.stderr')),bytes=(A/(label+'.stderr')).stat().st_size,sha256=sha(A/(label+'.stderr'))));save();assert q.returncode==0,label
try:
 run('preflight',[sys.executable,'-B',str(H/'preflight_recovery_zip.py'),str(z),str(A/'artifact-metadata.json'),str(A/'extracted'),str(A/'preflight-and-extraction.json'),'--extract'])
 for name in ['review-recovery-e.py','review-recovery-e-011.py']:run(name,[sys.executable,'-B',str(H/name)])
 r['helper_inputs_after']=snap();assert r['helper_inputs_after']==r['helper_inputs_before']
 r['original_zip_sha256_after']=sha(z);assert r['original_zip_sha256_after']==r['original_zip_sha256_before']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==HEAD
 r['reviews']=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in [O/'recovery-C3ff-review.json',O/'recovery-C3ff-011-review.json']];r['status']='accepted_scoped_original_C_recovery_and_rollback'
except BaseException as e:r['status']='failed_or_blocked_original_review';r['exception']=repr(e);raise
finally:r['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(dict(status=r['status'],receipt=str(record),sha256=sha(record),reviews=r.get('reviews'))))
