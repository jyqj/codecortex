def stable_00280():
    return 280
