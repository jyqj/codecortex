"""Synthetic run-boundary controls; never product/one-hour performance evidence.
Formal 3601/2400/1000-ms plan is unchanged; scheduler sleeps alone are accelerated
and interrupted after a bounded prefix. No cache/soak acceptance is patched.
"""
import json,hashlib,sys,time,threading,shutil
from pathlib import Path
from types import SimpleNamespace
from unittest import mock
from contextlib import ExitStack
from concurrent.futures import ThreadPoolExecutor
BASE=Path(__file__).resolve().parent
CANDIDATE=BASE.parents[1]/'pr-audit/cache-observer-candidate/candidate'
sys.path[:0]=[str(CANDIDATE/'scripts'),str(CANDIDATE/'scripts/tests')]
import p8_runtime as rt
from test_p8_runtime import RuntimeDriverControls
from test_p8_runtime_cache import ProtocolProduct
REAL_TIME=time
RESULTS=[]
for case in ('keyboard_interrupt_after_cache_prefix','keyboard_interrupt_during_hybrid'):
 out=BASE/'synthetic-run-boundaries'/case
 out.mkdir(parents=True,exist_ok=False)
 helper=RuntimeDriverControls();args,identity=helper.prepare_control(0)
 args.profile='soak';args.operations=3601;args.interval_ms=1000;args.concurrency=4
 entered=threading.Event();killed=threading.Event();futures=[];products=[];sleeps=[];calls=[]
 class SyntheticProduct(ProtocolProduct):
  def __init__(self,identity,project,output,cache):
   super().__init__(project);self.output=output;output.mkdir();(output/'product-stderr.log').write_text('synthetic protocol only\n')
   self.closed=False;self.builds=0;self.pid=9001;self.process=SimpleNamespace(pid=self.pid,poll=lambda:0 if self.closed or killed.is_set() else None,kill=lambda:killed.set())
   self.transport=SimpleNamespace(reader=SimpleNamespace(is_alive=lambda:False),exit_watcher=SimpleNamespace(is_alive=lambda:False));products.append(self)
  def initialize(self):return 14
  def close(self):
   self.closed=True;(self.output/'process.json').write_text(json.dumps({'synthetic':True,'closed':True}))
  def tool(self,name,arguments,timeout=45):
   if killed.is_set():raise RuntimeError('synthetic owned process killed')
   if name=='index':
    if not arguments.get('full'):
     self.builds+=1
     if self.builds%6!=0:self.epoch+=1
    return dict(parse_errors=[],resolution_freshness=dict(complete=True,index_epoch=self.epoch))
   if name=='status':return self.status()
   calls.append(dict(name=name,arguments=arguments,timeout=timeout,thread=threading.current_thread().name))
   if arguments['mode']=='hybrid' and case.endswith('during_hybrid'):
    entered.set()
    if not killed.wait(3):raise RuntimeError('bounded synthetic cleanup failure')
    raise RuntimeError('synthetic owned process killed while hybrid in flight')
   return super().tool(name,arguments,timeout)
 class TrackedPool(ThreadPoolExecutor):
  def submit(self,*a,**kw):
   f=super().submit(*a,**kw);futures.append(f);return f
 def sleep(seconds):
  sleeps.append(seconds)
  if case.endswith('during_hybrid') and len(sleeps)==3:
   assert entered.wait(3),'hybrid never entered'
   raise KeyboardInterrupt('explicit bounded soak hybrid interruption')
  if case.endswith('after_cache_prefix') and len(sleeps)==12:
   # Wait for all already offered work to settle. This is a control barrier,
   # not production scheduling or elapsed evidence.
   deadline=REAL_TIME.monotonic()+3
   while not all(f.done() for f in futures) and REAL_TIME.monotonic()<deadline:REAL_TIME.sleep(.005)
   assert all(f.done() for f in futures)
   raise KeyboardInterrupt('explicit bounded soak prefix interruption')
  REAL_TIME.sleep(.03)
 try:
  with ExitStack() as stack:
   for obj,key,replacement in ((rt,'Product',SyntheticProduct),(rt,'verify_build',lambda *a,**k:identity),(rt,'verify_receipt',lambda *a,**k:identity['build_identity']),
      (rt,'ThreadPoolExecutor',TrackedPool),(rt,'time',SimpleNamespace(monotonic_ns=REAL_TIME.monotonic_ns,sleep=sleep))):
    stack.enter_context(mock.patch.object(obj,key,replacement))
   report=rt.run(args)
  raw=[json.loads(l) for l in (args.output/'raw.jsonl').read_text().splitlines()]
  rows=[r for r in raw if r['kind']=='operation'];reads=[r for r in rows if r['operation']=='read']
  plan=json.loads((args.output/'plan.json').read_text())
  assert plan['operations']==3601 and plan['offer_interval_ms']==1000 and plan['read_protocol']['offered_read_operations']==2400
  assert report['status']=='failed' and report['exit_code']==2 and report['interrupted'] is True
  assert 'KeyboardInterrupt' in report['error'] and report['cache_reuse']['passed'] is False
  assert report['cache_reuse']['expected_offered_reads']==2400 and report['cache_reuse']['recorded_offered_reads']==len(reads)
  assert sorted(r['id'] for r in rows)==list(range(len(sleeps)))
  assert len(rows)==len(futures) and all(f.done() for f in futures)
  assert report['cache_reuse']['scope']=='partial failure; quarter origin unavailable; not certification'
  assert not (args.output/'statistics.json').exists() and report['artifact_seal_status']=='sealed'
  count=sum(len(r.get('cache_probe',{}).get('requests',[])) for r in reads)
  counted=sum(sum(v.values()) for v in report['cache_reuse']['request_counts'].values())
  assert counted==count
  if case.endswith('during_hybrid'):
   attempted=[r for r in reads if r.get('cache_probe')];assert len(attempted)==1
   prefix=attempted[0]['cache_probe']['requests'];assert [r['role'] for r in prefix]==['before_status','symbol','hybrid']
   assert [r['status'] for r in prefix]==['success','success','error'] and count==3
   assert report['work_cleanup']['still_running']==0 and report['work_cleanup']['cleanup_bound_seconds']==70
  else:
   assert all(r['status']=='success' for r in rows)
   assert report['cache_reuse']['validated_reads']==len(reads) and count==4*len(reads)
   assert report['cache_reuse']['observed']['hit']>0 and report['cache_reuse']['observed']['miss']>0
  rt.verify_output(args.output)
  shutil.copytree(args.output,out/'original-run')
  results=dict(case=case,passed=True,scope='Synthetic protocol product, mocked build admission, accelerated then interrupted scheduler only; no product execution or elapsed certification',planned_operations=3601,planned_reads=2400,planned_interval_ms=1000,offered_terminal_rows=len(rows),read_rows=len(reads),read_rpc_attempts=count,report_status=report['status'],exit_code=2,all_futures_done=True,raw_seal_verified=True,statistics_created=False,cache_passed=False,cache_counts=report['cache_reuse']['request_counts'],original_error=report['error'],source_sha256=hashlib.sha256((CANDIDATE/'scripts/p8_runtime.py').read_bytes()).hexdigest())
  (out/'result.json').write_text(json.dumps(results,indent=2)+'\n');RESULTS.append(results)
 finally:
  killed.set();helper.doCleanups()
(BASE/'synthetic-run-boundaries/result.json').write_text(json.dumps(RESULTS,indent=2)+'\n')
print(json.dumps(RESULTS,indent=2))
