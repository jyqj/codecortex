#!/usr/bin/env python3
"""Mechanical bindings for an actual reviewed capture-only source; no CLI execution."""
import copy,hashlib,json,pathlib,re
ROOT=pathlib.Path(__file__).resolve().parent
SEED_G='4786c1457b47c5baf4c09d32b96048795e863111'
FIELDS={'product_source','review_source','review_sha256','validation_inputs'}
def load(name):return json.loads((ROOT/name).read_text())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def blob(raw):return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def tree(entries):
    ordered=sorted(entries,key=lambda e:(e['path']+('/' if e['type']=='tree' else '')).encode())
    raw=b''.join((('40000' if e['type']=='tree' else e['mode'])+' '+e['path']).encode()+b'\0'+bytes.fromhex(e['sha']) for e in ordered)
    return hashlib.sha1(b'tree '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def write(name,data):
    f=ROOT/name;f.parent.mkdir(exist_ok=True,parents=True)
    with f.open('xb') as stream:stream.write(data)
def main():
    cfg=load('actual-R-binding-input.json')
    P,R=cfg['product'],cfg['review'];assert all(re.fullmatch('[0-9a-f]{40}',v) for v in [P,R])
    added=set(cfg['three_new_validation_paths']);assert len(added)==3
    assert sum(x.startswith('.github/workflows/') for x in added)==1
    assert sum(x.startswith('scripts/tests/') for x in added)==1
    assert sum(x.startswith('scripts/') and not x.startswith('scripts/tests/') for x in added)==1
    pc=load('official/actual-P-commit.json');pd=load('official/actual-P-compare.json')
    # Preserve both actual source versions: seed -> v2 P -> final v3 P.
    # The net compare is seed-to-final; each intermediate edge is separately exact.
    chain=cfg['product_source_chain'];assert len(chain)==2
    assert chain[0]=='5ce1ed4306ddf1a791f12da45d5892383e453d65' and chain[-1]==P
    prior=SEED_G
    for index,current in enumerate(chain):
        assert re.fullmatch('[0-9a-f]{40}',current)
        commit=load('official/source-chain-'+str(index)+'-commit.json')
        delta=load('official/source-chain-'+str(index)+'-compare.json')
        assert commit['sha']==current and [x['sha'] for x in commit['parents']]==[prior]
        assert delta['base_commit']['sha']==prior and delta['merge_base_commit']['sha']==prior
        expected=added if index==0 else {'scripts/p8_scale_diagnostic_capture.py','scripts/tests/test_p8_scale_diagnostic_capture.py'}
        assert len(delta['files'])==len(expected) and {x['filename'] for x in delta['files']}==expected
        assert all(x['status']==('added' if index==0 else 'modified') for x in delta['files'])
        if index==len(chain)-1:assert commit==pc
        prior=current
    assert pd['base_commit']['sha']==SEED_G and pd['merge_base_commit']['sha']==SEED_G
    assert pc['sha']==P and len(pd['files'])==3 and {x['filename'] for x in pd['files']}==added
    assert all(x['status']=='added' for x in pd['files'])
    rc=load('official/actual-R-commit.json');rd=load('official/actual-R-compare.json')
    assert rc['sha']==R and [x['sha'] for x in rc['parents']]==[P]
    assert len(rd['files'])==len(cfg['installed_artifact_paths'])
    assert {x['filename'] for x in rd['files']}==set(cfg['installed_artifact_paths']) and all(x['status']=='added' for x in rd['files'])
    raw=(ROOT/'independent-source-review.json').read_bytes();review=json.loads(raw)
    assert review['source']==P and review['source_tree']==pc['tree']['sha']
    assert review['review_path']==cfg['review_path'] and review['unresolved_blockers']==[] and review['verdict']=='accepted_scoped'
    assert review['independent_reviewers'] and all(isinstance(x,str) and x.strip() for x in review['independent_reviewers'])
    assert blob(raw)==cfg['canonical_git_blob']==next(x['sha'] for x in rd['files'] if x['filename']==cfg['review_path'])
    seed=load('seed-G4786-registry.json')
    assert review['base']==seed['base_source'] and review['scope']==seed['scope']
    assert review['complete_inputs']==seed['complete_inputs'] and review['paths']==seed['delta']
    assert set(review['validation_inputs'])==set(seed['validation_inputs'])|added
    assert all(review['validation_inputs'][p]==h for p,h in seed['validation_inputs'].items())
    inventory=review['actual_input_mode_blob_inventory']
    assert set(inventory)==set(review['complete_inputs'])|set(review['validation_inputs'])
    for path,h in {**review['complete_inputs'],**review['validation_inputs']}.items():
        row=inventory[path];assert row['type']=='blob' and row['mode'] in ['100644','100755'] and row['sha256']==h,path
    for change in pd['files']:assert inventory[change['filename']]['sha']==change['sha']
    registry=copy.deepcopy(seed)
    registry.update(product_source=P,review_source=R,review_sha256=sha(raw),validation_inputs=review['validation_inputs'])
    changed={k for k in seed if seed[k]!=registry[k]};assert changed==FIELDS and set(seed)==set(registry)
    rr=(json.dumps(registry,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode()
    before=(ROOT/'seed-G4786-guard.py').read_text();after=before;old={}
    pins={'PRODUCT':P,'REVIEW':R,'REVIEW_PATH':cfg['review_path'],'REGISTRY_SHA256':sha(rr)}
    for key,value in pins.items():
        pattern='^'+key+r' = "([^"]+)"$';values=re.findall(pattern,after,re.M);assert len(values)==1;old[key]=values[0]
        after,n=re.subn(pattern,lambda m:key+' = "'+value+'"',after,flags=re.M);assert n==1
    restored=after
    for key,value in old.items():restored,n=re.subn('^'+key+r' = "([^"]+)"$',lambda m:key+' = "'+value+'"',restored,flags=re.M);assert n==1
    assert restored==before
    gr=after.encode();rt=load('official/actual-R-root-tree.json');st=load('official/actual-R-scripts-tree.json')
    assert not rt['truncated'] and not st['truncated']
    assert tree(rt['tree'])==rt['sha']==rc['tree']['sha']
    assert tree(st['tree'])==st['sha']==next(x['sha'] for x in rt['tree'] if x['path']=='scripts')
    for name,local in [('reviewed-source-registry-v15.json','seed-G4786-registry.json'),('verify_reviewed_source_v15.py','seed-G4786-guard.py')]:
        assert next(x['sha'] for x in st['tree'] if x['path']==name)==blob((ROOT/local).read_bytes())
    payloads={'scripts/reviewed-source-registry-v15.json':rr,'scripts/verify_reviewed_source_v15.py':gr};elements=[]
    for path,data in payloads.items():
        write('generated/'+path,data);elements.append(dict(path=path,mode='100644',type='blob',sha=blob(data)))
    scripts=copy.deepcopy(st['tree'])
    for e in elements:next(x for x in scripts if x['path']==e['path'].split('/')[-1])['sha']=e['sha']
    root=copy.deepcopy(rt['tree']);next(x for x in root if x['path']=='scripts')['sha']=tree(scripts)
    report=dict(schema='capture-only-actual-R-binding-generation-v2',product_source_chain=chain,source=P,review=R,actual_G=None,expected_G_tree=tree(root),expected_G_parent=R,registry_changed_fields=sorted(changed),guard_changed_pins=pins,all_other_guard_bytes_unchanged=True,complete_product_and_BASE_delta_unchanged=True,existing_validation_unchanged=True,new_validation_paths=sorted(added),counts=dict(product=len(review['complete_inputs']),BASE_delta=len(review['paths']),validation=len(review['validation_inputs']),inventory=len(inventory)),files=[dict(path=p,bytes=len(b),sha256=sha(b),git_blob=blob(b)) for p,b in payloads.items()],execution_boundary='Mechanical binding generation only. No source CLI, Rust, product or scale execution.')
    write('generation-manifest.json',(json.dumps(report,indent=2)+'\n').encode())
    write('two-binding-create-tree-request.json',(json.dumps(dict(repository_full_name='jyqj/codecortex',base_tree_sha=rt['sha'],tree_elements=elements),indent=2)+'\n').encode())
    print(json.dumps(report,sort_keys=True))
if __name__=='__main__':main()
