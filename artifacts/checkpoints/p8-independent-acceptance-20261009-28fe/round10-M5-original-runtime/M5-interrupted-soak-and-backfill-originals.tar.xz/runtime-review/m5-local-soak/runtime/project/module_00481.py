def stable_00481():
    return 481
