from pathlib import Path
import subprocess,json,hashlib,datetime,time,sys,os,shutil,traceback
root=Path.cwd();out=root.parent/'native-public-api-merge-H2-e564-admission';parent=root.parents[3]
source='e5640904298febdf8dc951e0baddb2819f930c0b'
(out/'run-original-v15-controller.py').write_bytes(Path(sys.argv[0]).read_bytes())
assert not (out/'original-v15-command-receipt.json').exists()
baseline=json.loads((out/'complete-domain-before-v15.json').read_text())
assert baseline['source_H']==source and baseline['combined_selected_count']==1435
def head(where):
 return subprocess.check_output(['/usr/bin/git','-c','core.commitGraph=false','rev-parse','HEAD'],cwd=where).decode().strip()
def snapshot(label):
 rows=[]
 for expected in baseline['entries']:
  p=root/expected['path'];b=p.read_bytes()
  actual={'path':expected['path'],'mode':'100755' if p.stat().st_mode&0o111 else '100644','git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
  assert actual==expected,(expected['path'],actual,expected)
  rows.append(actual)
 data=(json.dumps({'source_H2':source,'head':head(root),'entries':rows,'scope':'actual selected source, validation, CI, binding, canonical review and original historical protected paths'},indent=2,sort_keys=True)+'\n').encode()
 assert head(root)==source
 p=out/(label+'.json');p.write_bytes(data)
 return {'path':p.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'count':len(rows)}
before=snapshot('original-v15-domain-before');parent_before=head(parent)
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
count=int(env.get('GIT_CONFIG_COUNT','0'));env['GIT_CONFIG_KEY_'+str(count)]='core.commitGraph';env['GIT_CONFIG_VALUE_'+str(count)]='false';env['GIT_CONFIG_COUNT']=str(count+1)
argv=['python3','scripts/verify_reviewed_source_v15.py','--source-version','p8-completion-source-20261009-v15']
r={'source_H2':source,'product_P':'c92eb5ac7ece70d1f62271d7e2dacac513c285b5','review_R':'f89d5feec91ae611d52614b8fe217bcd7fd5cf64','guard_G':'b2bbd5817ce00367cea52696b098c6eafe4aa0a6','argv':argv,'resolved_python3':shutil.which('python3'),'cwd':str(root),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment_overrides':{'PYTHONDONTWRITEBYTECODE':'1','command_local_git_core_commitGraph':'false'},'original_cli_and_budgets_unchanged':True,'domain_before':before,'parent_head_before':parent_before,'scope':'actual original selected v15 execution only; not the 181 test suite, Rust tests, scale study or original TODO completion'}
sp=out/'original-v15.stdout';ep=out/'original-v15.stderr';started=time.monotonic();code=None
try:
 with sp.open('wb') as so,ep.open('wb') as se:
  p=subprocess.Popen(argv,cwd=root,env=env,stdout=so,stderr=se);r['pid']=p.pid
  try: code=p.wait(timeout=2700)
  except subprocess.TimeoutExpired:
   p.kill();code=p.wait();r['controller_timeout_seconds']=2700
 r['exit_code']=code
 r['domain_after']=snapshot('original-v15-domain-after')
 r['parent_head_after']=head(parent)
 assert r['parent_head_after']==parent_before
except BaseException as exc:
 r['controller_exception']=repr(exc);r['controller_traceback']=traceback.format_exc()
finally:
 r['elapsed_seconds']=time.monotonic()-started;r['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 for k,path in [('stdout',sp),('stderr',ep)]:
  if path.exists():
   b=path.read_bytes();r[k]={'path':path.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 data=(json.dumps(r,indent=2,sort_keys=True)+'\n').encode();(out/'original-v15-command-receipt.json').write_bytes(data)
 print(json.dumps(r),flush=True)
 for path in [sp,ep]:
  if path.exists() and path.stat().st_size:print(path.name+' '+path.read_text(errors='replace')[-6000:],flush=True)
sys.exit(0 if code==0 and 'controller_exception' not in r else 1)
