#!/usr/bin/env python3
"""Read fixed original maps and derive ONLY two Git tree elements, without Git mutation."""
import ast
import copy
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
def read(path):
    return json.loads(Path(path).read_bytes())
def save(name, value):
    (HERE / name).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')
source = Path('/dev/shm/todo-audit-P3-H-d22-candidate-plan/verify-prospective-plan.py').read_text()
functions = ast.parse(source)
namespace = {'hashlib': hashlib}
exec(compile(ast.Module(body=[n for n in functions.body if isinstance(n, ast.FunctionDef) and n.name in {'oid', 'tree_oid', 'leaf_map'}], type_ignores=[]), '<pure original Git tree helpers>', 'exec'), namespace)
oid, tree_oid, leaf_map = (namespace[n] for n in ['oid', 'tree_oid', 'leaf_map'])
leaves = leaf_map(read('/dev/shm/todo-audit-p8007-final-main-integration/actual-P2/actual-P2-complete-derived-Git-tree.json'))
def artifact_manifest(path, expected):
    for row in read(path)['files']:
        assert row['repository_path'] not in leaves
        raw = Path(row['local_path']).read_bytes() if 'local_path' in row and Path(row['local_path']).exists() else None
        if raw is not None:
            assert oid('blob', raw) == row['git_blob']
            assert hashlib.sha256(raw).hexdigest() == row['sha256']
        leaves[row['repository_path']] = {'mode': row.get('mode', '100644'), 'type': 'blob', 'sha': row['git_blob']}
    assert tree_oid(leaves) == expected
def apply_request(path, expected):
    data = read(path)
    assert data['base_tree'] == tree_oid(leaves)
    for row in data['tree']:
        leaves[row['path']] = {k: row[k] for k in ['mode', 'type', 'sha']}
    assert tree_oid(leaves) == expected
artifact_manifest('/dev/shm/execution-recon-recovery-20261009/final-R2/upload-manifest.json', '90d4c0aec835c9b5fff9d809c433d353d409dcf8')
apply_request('/dev/shm/todo-audit-G2-cd68-binding/two-binding-create-tree-request.json', '41a1708082eb49432e8e22aac2c0400f80337cfb')
apply_request('/dev/shm/todo-audit-G2-cd68-binding/future-H-20-artifact-create-tree-request.json', '9755e717368ffb51bc084c3348c1715b00b34d0d')
apply_request('/dev/shm/todo-audit-P3-H-d22-candidate-plan/prospective-P3-create-tree-request.json', '5ac4d3fb96cfb11433d529b8292d1e7652471036')
apply_request('/dev/shm/todo-audit-H-dependency-exclusion-v3/P3f-create-tree-request.json', 'c61707e398739be23b01570af025c412a723689c')
artifact_manifest('/dev/shm/execution-recon-recovery-20261009/final-R3/upload-manifest.json', '11db88d8c60b6be658f40d419dd46c915c716b93')
apply_request('/dev/shm/todo-audit-G3-4ec7543d-binding/two-binding-create-tree-request.json', 'e7a7f5a685c44aee34b8716377308f0af8782fdd')
apply_request('/dev/shm/execution-recon-recovery-20261009/PR188-original-rustfmt-fix-v4/P4-one-leaf-create-tree-request.json', '9a96f4bcda2407927154b91f5a77c54d5f7670f4')
P4 = copy.deepcopy(leaves)
review_meta = read(HERE / 'R4-official-commit.json')
assert review_meta['sha'] == 'b4ad0852fb0f164f89ba194409e2a78578f5413f'
assert [x['sha'] for x in review_meta['parents']] == ['1930b8e37e24031c3779553e3fc5b95e8e946d50']
artifact_manifest('/dev/shm/pr-triage-P4-original-rustfmt-source-review/upload-manifest.json', review_meta['tree']['sha'])
R4 = copy.deepcopy(leaves)
assert len(set(R4)-set(P4)) == 2 and all(R4[p] == P4[p] for p in P4)
rows, output = [], []
for path in ['scripts/reviewed-source-registry-v15.json', 'scripts/verify_reviewed_source_v15.py']:
    local = HERE / 'generated' / path
    raw = local.read_bytes()
    row = {'path': path, 'mode': '100644', 'type': 'blob', 'sha': oid('blob', raw)}
    rows.append(row)
    output.append({**row, 'local_path': str(local), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    leaves[path] = {k: row[k] for k in ['mode', 'type', 'sha']}
assert sorted(p for p in leaves if leaves[p] != R4.get(p)) == sorted(row['path'] for row in rows)
request = {'base_tree': review_meta['tree']['sha'], 'tree': rows}
save('two-binding-create-tree-request.json', request)
prep = Path('/dev/shm/todo-audit-P4-G4-binding-preparation')
before_registry = read(prep / 'seed-G3-registry.json')
after_registry = read(HERE / 'generated/scripts/reviewed-source-registry-v15.json')
actual_fields = sorted(k for k in before_registry.keys() | after_registry.keys() if before_registry.get(k) != after_registry.get(k))
assert actual_fields == ['complete_inputs', 'delta', 'product_source', 'review_sha256', 'review_source']
assert before_registry['validation_inputs'] == after_registry['validation_inputs']
test_path = 'crates/cc-db/tests/p2b_resolution_store.rs'
assert [p for p in before_registry['complete_inputs'] if before_registry['complete_inputs'][p] != after_registry['complete_inputs'][p]] == [test_path]
assert [p for p in before_registry['delta'] if before_registry['delta'][p] != after_registry['delta'][p]] == [test_path]
before_guard = (prep / 'seed-G3-guard.py').read_text()
after_guard = (HERE / 'generated/scripts/verify_reviewed_source_v15.py').read_text()
changed_lines = [a.split(' = ')[0] for a,b in zip(before_guard.splitlines(), after_guard.splitlines()) if a != b]
assert changed_lines == ['PRODUCT', 'REVIEW', 'REVIEW_PATH', 'REGISTRY_SHA256']
(HERE / 'guard-four-pin.diff').write_text(''.join(difflib.unified_diff(before_guard.splitlines(keepends=True), after_guard.splitlines(keepends=True), fromfile='actual-G3-guard', tofile='prepared-G4-guard')))
maps = read(prep / 'actual-P4-1237-mode-blob-input-map.json')
assert all({k: v[k] for k in ['mode','type','sha']} == leaves[p] for p,v in maps.items())
manifest = {'scope': 'actual P4/R4 author-side mechanical two-binding generation only', 'actual_P4': '1930b8e37e24031c3779553e3fc5b95e8e946d50', 'actual_P4_tree': tree_oid(P4), 'actual_R4': review_meta['sha'], 'actual_R4_tree': tree_oid(R4), 'actual_G4': None, 'required_G4_sole_parent': review_meta['sha'], 'expected_G4_tree': tree_oid(leaves), 'counts': {'product': 1095, 'BASE_delta': 70, 'validation': 142}, 'guard_changed_lines': changed_lines, 'registry_actual_changed_fields': actual_fields, 'complete_inputs_changed_paths': [test_path], 'delta_changed_paths': [test_path], 'all142_validation_unchanged': True, 'all1237_domain_mode_blob_unchanged_from_P4': True, 'BASE_FROZEN_historical_algorithm_CI_unchanged': True, 'reviewer': '/root/pr_triage', 'review_source_only_runtime': 'not_run', 'product_formatter_source_gate_or_measurement_executed_here': False, 'remote_mutation': False, 'outputs': output}
save('allowlisted-delta-and-installation-manifest.json', manifest)
print(json.dumps(manifest, sort_keys=True))
