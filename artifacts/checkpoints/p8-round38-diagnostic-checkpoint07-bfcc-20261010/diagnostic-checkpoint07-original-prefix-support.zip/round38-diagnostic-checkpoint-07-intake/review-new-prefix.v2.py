"""Read newly received checkpoint07, preserving uncertainty and original bytes."""
import collections
import datetime
import hashlib
import json
from pathlib import Path
import stat
import zipfile

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'round38-diagnostic-checkpoint-07-intake/attempt01'
OLD = ROOT / 'round37-diagnostic-checkpoint-06-intake/attempt01'
BUILD = ROOT / 'round33-PR200-build-capacity-original-intake/attempt01'
BINDING = ROOT / 'round32-100k-diagnostic-intake-bound-9cc6-run38012409915/binding.json'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def identity(p):
    b = p.read_bytes()
    return {'local_path': str(p), 'bytes': len(b), 'sha256': sha(b),
            'git_blob': hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest(),
            'posix_mode': oct(stat.S_IMODE(p.stat().st_mode))}

reader = json.loads((OUT / 'reader/report.json').read_text())
execution = json.loads((OUT / 'reader.execution.json').read_text())
old = json.loads((OLD / 'checkpoint06-prefix-review.json').read_text())
binding = json.loads(BINDING.read_text())
assert execution['exit_code'] == 0
assert all(execution[k] == 0 for k in ('validate_build_calls', 'validate_shard_calls', 'inspect_raw_calls', 'ELF_calls'))
assert {a['id'] for a in reader['artifacts']} == {'11658151472'}
new = next(a for a in reader['artifacts'] if a['id'] == '11658151472')
selected = OUT / 'selected-originals'
# Reuse the new07 originals extracted before the first derived bridge type mismatch.
# No reader rerun and no further ZIP read.
manifest = json.loads((selected / 'manifest.json').read_text())
chunks = [c for c in reader['streams']['shard/native/raw.jsonl']['chunks']
          if any(x['artifact_id'] == new['id'] for x in c['retained_locations'])]
assert len(chunks) == 1
chunk = chunks[0]
location = next(x for x in chunk['retained_locations'] if x['artifact_id'] == new['id'])
raw = (selected / location['member']).read_bytes()
assert len(raw) == chunk['bytes'] and sha(raw) == chunk['sha256']
assert (selected / 'configuration.json.snapshot').read_bytes() == (OLD / 'selected-originals/configuration.json.snapshot').read_bytes()
config = json.loads((selected / 'configuration.json.snapshot').read_text())
assert config['original_build_receipt_sha256'] == identity(BUILD / 'extracted/build/build.json')['sha256']
assert config['original_driver_sha256'] == binding['driver_inputs']['scripts/p8_scale_matrix.py']
assert chunk['start'] == old['verified_prefixes']['shard/native/raw.jsonl']['end_exclusive']
assert old['new_raw_interval']['partial_tail_bytes'] == 0
events, intervals, failures = [], [], []
offset = chunk['start']
lines = raw.splitlines(keepends=True)
for number, line in enumerate(lines):
    row = {'new_line_index': number, 'start': offset, 'end': offset + len(line), 'bytes': len(line),
           'sha256': sha(line), 'complete_newline': line.endswith(b'\n')}
    offset += len(line)
    if not row['complete_newline']:
        row['status'] = 'partial_tail_not_a_complete_event'
    else:
        try:
            event = json.loads(line)
            events.append(event)
            row.update(event=event.get('event'), label=event.get('label'), status='complete_original_event')
        except (ValueError, UnicodeError) as error:
            row.update(status='complete_line_parse_error', error=str(error))
            failures.append(row)
    intervals.append(row)
new_counts = collections.Counter(e.get('event') for e in events)
total_counts = collections.Counter(old['new_raw_interval']['cumulative_complete_event_counts']) + new_counts
unfinished = list(old['started_but_not_finished_in_retained_prefix'])
finished = []
for e in events:
    if e.get('event') == 'build_started':
        unfinished.append(e)
    elif e.get('event') == 'build_finished':
        unfinished = [x for x in unfinished if x['label'] != e['label']]
        fields = ('elapsed_ms', 'phase_timing', 'build_timing', 'files_scanned', 'files_added', 'files_updated',
                  'files_removed', 'files_skipped', 'files_parsed', 'symbols_total', 'chunks_total',
                  'parse_errors', 'resolution_freshness')
        finished.append({**{k:e[k] for k in ('label', 'full', 'start_us', 'end_us', 'wall_us', 'process_snapshot')},
                         'original_report_fields': {k:e['report'].get(k) for k in fields}})
current = next(x for x in reader['checkpoints'] if x['index'] == 7)
assert len(current['acknowledgements']) == 7 and all(x['retained_original_and_official_digest_verified'] is False for x in current['acknowledgements'])
# Evidence reuse bridge: no prior ZIP is opened or re-CRC-checked here.
old_reader_path = OLD / 'reader/report.json'
old_reader = json.loads(old_reader_path.read_text())
old_index = json.loads((OLD / 'official-index.json').read_text())
assert [a['artifact']['id'] for a in old_index['artifacts']] == [11655358015,11655694522,11656371239,11656517936,11656209993,11656794128,11657318324]
old_by_id = {a['id']:a for a in old_reader['artifacts']}
small_manifests = {}
for path in ROOT.glob('round*-diagnostic-checkpoint-*-intake/attempt01/selected-originals/manifest.json'):
    if path == selected / 'manifest.json':
        continue
    value = json.loads(path.read_text())
    if value['index'] <= 6:
        assert value['index'] not in small_manifests
        small_manifests[value['index']] = (path, value)
assert set(small_manifests) == set(range(7))
bridged_acks = []
for ack in current['acknowledgements']:
    path, value = small_manifests[ack['checkpoint']]
    original = old_by_id[str(ack['artifact_id'])]
    official = next(x['artifact'] for x in old_index['artifacts'] if str(x['artifact']['id']) == str(ack['artifact_id']))
    original_sha = original['members']['manifest.json']['sha256']
    assert identity(path)['sha256'] == original_sha == ack['manifest_sha256']
    assert value['included_chunk_names'] == ack['included_chunk_names']
    assert original['sha256'] == ack['artifact_digest'] == official['digest'].removeprefix('sha256:')
    assert original['official_digest_verified'] is True
    bridged_acks.append({'ack':ack, 'small_manifest':identity(path),
        'prior_original_ZIP_artifact_id':official['id'], 'prior_official_ZIP_sha256':original['sha256'],
        'derived_bridge_verified':True, 'prior_ZIP_reopened':False})
old_chunks = {c['name']:c for stream in old_reader['streams'].values() for c in stream['chunks']}
bridged_prefixes = {}
for stream, value in reader['streams'].items():
    position = 0
    for c in value['chunks']:
        assert c['start'] == position
        if c['name'] in old_chunks:
            oldc = old_chunks[c['name']]
            assert {k:v for k,v in c.items() if k!='retained_locations'} == {k:v for k,v in oldc.items() if k!='retained_locations'}
            assert oldc['retained_locations']
        else:
            assert c['retained_locations'] and all(x['artifact_id']==new['id'] for x in c['retained_locations'])
        position = c['end']
    assert position >= old['verified_prefixes'][stream]['end_exclusive']
    bridged_prefixes[stream] = {'start':0,'end_exclusive':position,'highest_declared_offset':value['highest_declared_offset'],
        'unknown_tail_bytes':None,'EOF_claimed':False, 'verification_scope':'derived: prior accepted records/small manifests + new-only frozen reader; not a new complete-old-ZIP check'}
bridge = {'scope':'Derived custody continuity only; frozen reader new-only output is unchanged.',
    'prior_reader_report':identity(old_reader_path), 'prior_index':identity(OLD/'official-index.json'),
    'ACKs':bridged_acks, 'old_ZIPs_opened':0, 'old_ZIPs_CRC_rechecked':0,
    'all_declared_old_chunks_equal_prior_accepted_records':True, 'new_chunk_start_matches_prior_end':True}
report = {'schema': 'p8-original-diagnostic-checkpoint07-prefix-review-v1',
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source': binding['G'], 'run_id': binding['run_id'], 'attempt': 1,
    'scope': 'New07 custody only. Frozen reader received only new07 and did not re-read prior ZIPs. A separately labelled derived bridge reuses accepted06 reader records plus00-06 small original manifests. Later PR merge does not change original run source or parameters.',
    'new_original_artifact': new, 'old_continuity_artifact_ids': [11655358015,11655694522,11656371239,11656517936,11656209993,11656794128,11657318324],
    'old_small_manifests_read_not_ZIPs': True, 'previous_accepted_review': identity(OLD / 'checkpoint06-prefix-review.json'),
    'frozen_reader_execution': identity(OUT / 'reader.execution.json'), 'reader_exit_code': 0,
    'accepted_diagnostic_build_reused_without_revalidation': {'result': identity(BUILD / 'original-validate-build-result.json'),
        'receipt': identity(BUILD / 'extracted/build/build.json'), 'configuration_receipt_exact': True,
        'configuration_bytes_identical_to_checkpoint06': True, 'not_full_cohort_build': True},
    'verified_prefixes': bridged_prefixes,
    'frozen_reader_new_only_stream_result': reader['streams'],
    'derived_continuity_bridge': bridge,
    'first_derived_bridge_failure': 'review.execution.json exit1: prior official artifact integer vs ACK string ID comparison; original reader remained exit0; v2 uses str identity comparison and only extracted new bytes, no ZIP/reader retry',
    'new_raw_interval': {**chunk,'ends_in_newline':raw.endswith(b'\n'),'original_line_intervals':intervals,
        'new_complete_event_counts':dict(new_counts),'cumulative_complete_event_counts':dict(total_counts),
        'complete_line_parse_errors':failures,'partial_tail_bytes':0 if not lines or lines[-1].endswith(b'\n') else len(lines[-1])},
    'frozen_reader_checkpoint07_ACKs_unverified_within_new_only_input':current['acknowledgements'],
    'own_ACK_boundary':'Checkpoint07 snapshot precedes its own upload. Later local ACK is not supplied; official custody is independently verified.',
    'capture_faults_observed':reader['capture_faults'],'metadata_parse_unknown':reader['metadata_parse_unknown'],
    'observer_before_seen_and_bound':reader['observer_before_seen'],'observer_after_seen':reader['observer_after_seen'],
    'new_finished_build_records':finished,'started_but_not_finished_in_retained_prefix':unfinished,
    'visible_frontier': {'last_complete_original_record': {k:events[-1].get(k) for k in ('event','label','stage','full','start_us','end_us','wall_us')} if events else None, 'current_hidden_execution_phase':'unknown; only the emitted retained events below are observed'},
    'new_original_non_build_records':[e for e in events if e.get('event') not in ('build_started','build_finished')],
    'cold_parity_events':total_counts.get('cold_parity',0),'stage_finished_events':total_counts.get('stage_finished',0),
    'supervisor_terminal_seen':bool(reader['supervisor_receipts']),'native_report_seen':bool(reader['native_reports']),
    'reported_native_outcome':reader['reported_native_outcome'],'custody_status':reader['custody_status'],
    'timing_boundary':'Original counters only; full_staging is nested in prepare and timers are not added. No speedup forecast or hidden-phase attribution.',
    'original_function_calls':{'validate_build':0,'validate_shard':0,'inspect_raw':0,'check_parity':0,'ELF':0},
    'original_semantic_validation':'not_run; emitted records are not a substitute for the original complete-evidence predicates',
    'full_cohort_run_not_mixed':38013753078,'accepted_cohort_shards':0,'accepted_samples':0,'TODO_credit':0}
with (OUT / 'checkpoint07-prefix-review.json').open('x') as f:
    json.dump(report,f,ensure_ascii=False,indent=2)
    f.write('\n')
print(json.dumps({'report':identity(OUT/'checkpoint07-prefix-review.json'),'new_events':dict(new_counts),
    'derived_raw_contiguous_bytes':bridged_prefixes['shard/native/raw.jsonl']['end_exclusive'],
    'native_outcome':reader['reported_native_outcome']}))
