def stable_00445():
    return 445
