#!/usr/bin/env python3
"""Archive only the explicitly enumerated, completed engineering observations.

Original files are never rewritten. Large native executables and Cargo targets
are deliberately omitted; their original receipts retain their identities.
"""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import tarfile
import tempfile

BASE = Path('/workspace/scratch/2eaa00d0f93a')
REPO = BASE / 'codecortex'
OUT = Path(__file__).resolve().parent
BASE_COMMIT = '7354db236c9d9850a75f31672697ae9eab44565e'
FORBIDDEN = re.compile(r'hold[-_]?out|held[-_]?out', re.I)
OMIT_DIRS = {'.git', '__pycache__', 'target', 'cargo-target'}
NATIVE = {b'\x7fELF', b'\xfe\xed\xfa\xce', b'\xfe\xed\xfa\xcf', b'\xce\xfa\xed\xfe', b'\xcf\xfa\xed\xfe'}
PROVENANCE = {}
EXCLUDED = []
GROUPS = []
COPIED = 0


def sha_bytes(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def git(*args, cwd=REPO, input=None):
    return subprocess.check_output(['git', *args], cwd=cwd, input=input, stderr=subprocess.PIPE)


def write_json(relative, value, category='archive_metadata'):
    path = OUT / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        stream.write(json.dumps(value, sort_keys=True, ensure_ascii=False, indent=2) + '\n')
    PROVENANCE[relative] = {'category': category, 'origin': 'generated archival description; not an original execution result'}


def put_bytes(relative, raw, origin, category):
    path = OUT / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)
    PROVENANCE[relative] = {'category': category, 'origin': origin}


def copy_file(source, relative, category):
    global COPIED
    source = Path(source)
    assert not FORBIDDEN.search(str(source)), 'protected path refused before opening'
    before = source.lstat()
    assert stat.S_ISREG(before.st_mode), f'nonregular input: {source}'
    with source.open('rb') as stream:
        magic = stream.read(4)
    if magic in NATIVE or magic[:2] == b'MZ':
        EXCLUDED.append({'source': str(source), 'bytes': before.st_size,
                         'reason': 'native executable intentionally excluded; original identity remains in its receipt'})
        return
    assert before.st_size <= 16 * 1024 * 1024, f'unexpected large non-executable input: {source}'
    raw = source.read_bytes()
    after = source.lstat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), f'source changed during copy: {source}'
    assert digest(source) == sha_bytes(raw), f'source bytes changed: {source}'
    COPIED += len(raw)
    assert COPIED <= 256 * 1024 * 1024, 'archive input byte bound'
    put_bytes(relative, raw, str(source), category)
    assert digest(OUT / relative) == sha_bytes(raw)
    os.utime(OUT / relative, ns=(before.st_atime_ns, before.st_mtime_ns))


def copy_tree(source, relative, category):
    source = Path(source)
    assert source.is_dir() and not source.is_symlink()
    for parent, directories, names in os.walk(source, followlinks=False):
        parent = Path(parent)
        selected = []
        for name in sorted(directories):
            path = parent / name
            assert not FORBIDDEN.search(str(path)), 'protected path refused before traversal'
            assert not path.is_symlink(), f'symlink directory: {path}'
            if name in OMIT_DIRS:
                EXCLUDED.append({'source': str(path), 'reason': 'disposable target, repository metadata or bytecode directory; not traversed'})
            else:
                selected.append(name)
        directories[:] = selected
        for name in sorted(names):
            path = parent / name
            copy_file(path, str(Path(relative) / path.relative_to(source)), category)


def add_group(key, source, destination, classification, details, *, tree=True):
    if tree:
        copy_tree(source, destination, key)
    else:
        copy_file(source, destination, key)
    GROUPS.append({'id': key, 'original': str(source), 'archive': destination,
                   'classification': classification, **details})


def observer_sources(label, raw_root, *, git_ref=None, snapshot=None):
    receipt = json.loads((Path(raw_root) / 'receipt.json').read_text())
    restored, missing = {}, []
    for original, expected in receipt.get('observer_sha256', {}).items():
        relative = original.split('/scripts/', 1)[1]
        assert not FORBIDDEN.search(relative)
        candidates = []
        if git_ref:
            try:
                candidates.append((f'git:{git_ref}:scripts/{relative}', git('show', f'{git_ref}:scripts/{relative}')))
            except subprocess.CalledProcessError:
                pass
        if snapshot:
            path = Path(snapshot) / relative
            if path.is_file():
                candidates.append((str(path), path.read_bytes()))
        found = next(((origin, raw) for origin, raw in candidates if sha_bytes(raw) == expected), None)
        if found is None:
            missing.append({'recorded_path': original, 'sha256': expected,
                            'status': 'original bytes unavailable; never substituted with a later version'})
            continue
        origin, raw = found
        destination = f'observer-source/{label}/{relative}'
        put_bytes(destination, raw, origin, 'exact_observed_source')
        restored[relative] = {'archive': destination, 'sha256': expected, 'bytes': len(raw)}
    return {'restored': restored, 'missing': missing}


def build_bundle():
    rows = git('for-each-ref', '--format=%(refname) %(objectname)', 'refs/heads/task/').decode().splitlines()
    refs = dict(row.split() for row in rows if row.split()[0].startswith('refs/heads/task/p8-'))
    assert len(refs) == 7
    for commit in refs.values():
        git('merge-base', '--is-ancestor', BASE_COMMIT, commit)
    tips = sorted(set(refs.values()))
    objects = git('rev-list', '--objects', *tips, '^' + BASE_COMMIT).decode().splitlines()
    # Only object names are inspected here. No protected corpus body is opened.
    assert not any(FORBIDDEN.search(row.partition(' ')[2]) for row in objects), 'protected incremental object path'
    put_bytes('git/incremental-object-paths.txt', ('\n'.join(objects) + '\n').encode(),
              'git rev-list --objects fixed task tips ^' + BASE_COMMIT, 'git_object_metadata')
    commits = git('rev-list', '--topo-order', *tips, '^' + BASE_COMMIT).decode().splitlines()
    metadata = []
    for commit in commits:
        raw = git('show', '-s', '--format=%H%x00%P%x00%T%x00%ct%x00%s', commit).decode().strip()
        oid, parents, tree, timestamp, subject = raw.split('\0')
        metadata.append({'commit': oid, 'parents': parents.split(), 'tree': tree,
                         'committed_unix_seconds': int(timestamp), 'subject': subject})
    bundle = OUT / 'git/local-p8-task-branches.bundle'
    bundle.parent.mkdir(exist_ok=True)
    objects_root = Path(git('rev-parse', '--git-path', 'objects').decode().strip())
    if not objects_root.is_absolute():
        objects_root = (REPO / objects_root).resolve(strict=True)
    with tempfile.TemporaryDirectory(prefix='p8-archive-bundle-', dir=BASE) as temporary:
        private = Path(temporary)
        subprocess.run(['git', 'init', '--bare', '--quiet', str(private)], check=True)
        (private / 'objects/info/alternates').write_text(str(objects_root) + '\n')
        updates = ''.join(f'update {ref} {commit}\n' for ref, commit in sorted(refs.items())).encode()
        git('update-ref', '--stdin', cwd=private, input=updates)
        result = subprocess.run(['git', 'bundle', 'create', '--version=2', str(bundle),
                                 *sorted(refs), '^' + BASE_COMMIT], cwd=private, capture_output=True, check=True)
        put_bytes('git/bundle-create.stdout', result.stdout, 'actual private-repository git bundle create stdout', 'git_verification_log')
        put_bytes('git/bundle-create.stderr', result.stderr, 'actual private-repository git bundle create stderr', 'git_verification_log')
    heads = dict(line.split(maxsplit=1)[::-1] for line in git('bundle', 'list-heads', str(bundle)).decode().splitlines())
    assert heads == refs, 'bundle head snapshot differs'
    checked = subprocess.run(['git', 'bundle', 'verify', str(bundle)], cwd=REPO, capture_output=True, check=True)
    put_bytes('git/bundle-verify.stdout', checked.stdout, 'actual git bundle verify stdout', 'git_verification_log')
    put_bytes('git/bundle-verify.stderr', checked.stderr, 'actual git bundle verify stderr', 'git_verification_log')
    PROVENANCE['git/local-p8-task-branches.bundle'] = {'category': 'incremental_git_history',
        'origin': 'fixed local task branch refs; baseline-reachable objects excluded; requires existing baseline history'}
    record = {'schema_version': 1, 'repository': 'https://github.com/jyqj/codecortex',
        'baseline_excluded': BASE_COMMIT, 'branch_tips_at_snapshot': refs,
        'commits_after_baseline': metadata, 'incremental_object_count': len(objects),
        'bundle': 'git/local-p8-task-branches.bundle', 'bundle_bytes': bundle.stat().st_size,
        'bundle_sha256': digest(bundle), 'verified': True, 'contains_baseline_history': False,
        'prerequisite': 'An existing checkout/object database containing the baseline and its reachable history is required.',
        'scope': 'Local engineering provenance only. A later flat GitHub publication has a different commit identity.'}
    write_json('git/branch-and-commit-map.json', record)
    return record


def main():
    assert set(path.name for path in OUT.iterdir()) == {'build_archive.py'}, 'use a new archive directory'
    PROVENANCE['build_archive.py'] = {'category': 'archive_builder', 'origin': 'this explicit archival procedure; not an execution harness'}
    de04 = 'de04d4c1ab61972c606f9cc454ca2042ec189356'
    old = '277f2490fad3fa30f2812b5547bad033867c9ea5'
    scale = '99f95742aacfe3efa6ccc7070b47abde0c0cbde5'
    add_group('full_recovery', BASE/'p8-platform-full-first', 'recovery/full-matrix-de04',
              'completed engineering fault matrix; no final-source or release attestation',
              {'product_source': de04, 'recorded_status': 'passed_declared_fault_matrix',
               'coverage': 'three local faults, three fixed seeds of four active stdio/HTTP/cache/replacement faults, seven original Rust persistence controls, original limited rollback',
               'paid_provider': 'loopback fake provider only; no paid external-provider evidence'})
    add_group('historical_build', BASE/'p8-rollback-historical-first', 'rollback/historical-build-277',
              'actual unmodified historical public source build; executable omitted from this compact archive',
              {'product_source': old, 'schema': 24, 'released_package_claim': False})
    for suffix, label, harness in [
        ('first', 'initial engineering version-pair run', {'runner_sha256': '76485362d732845ecc1e2f338cc927a3265af18a636db807b2d3b35fa8c336cc', 'runner_commit': None, 'runner_original_bytes': 'unavailable in retained committed versions; original hash retained'}),
        ('closing-regression', 'actual regression after explicit SQLite connection closing', {'runner_sha256': '5247ffaba63c43f5373227fa202991912ff070328ad194688ebfc2605c543829', 'runner_commit': 'e5172ec97c7886dc9e2fd6f64fce3718803d0887'})]:
        add_group('version_pair_' + suffix, BASE/('p8-actual-version-pair-' + suffix), 'rollback/version-pair-' + suffix,
                  label, {'current_product_source': de04, 'previous_product_source': old,
                          'phases': '25 -> 24 -> 25 -> original 25 backup; four real stdio processes',
                          'recorded_status': 'passed_actual_source_version_pair', **harness})
    add_group('retained_fault_executable_mapping', BASE/'p8-platform-first-test-binaries/archive.json',
              'recovery/retained-fault-executable-map.json', 'original hash mapping; native executables intentionally omitted', {}, tree=False)
    lifecycle = [
        ('initial-debug', Path('/tmp/p8-lifecycle-correctness-dk7hyta1'), None, None),
        ('final-debug-1775', Path('/tmp/p8-lifecycle-final-correctness-m8wc5y58'), '1775d1156cb4efd3804ac3a127cae388d5c5e1f1', None),
        ('post-close-debug', BASE/'p8-lifecycle-review-correctness-sr89tk_j', None,
         BASE/'p8-lifecycle-postfix-independent-review/observed-runner-source')]
    observer_map = {}
    for label, root, commit, snapshot in lifecycle:
        receipt = json.loads((root/'receipt.json').read_text())
        add_group('lifecycle_' + label, root, 'lifecycle/' + label,
                  'actual 10-sample direct-Driver debug engineering smoke; no original Cargo release build receipt',
                  {'recorded_status': receipt['status'], 'recorded_product_source': None,
                   'product_sha256': receipt['product']['binary_sha256'],
                   'evaluator_sha256': receipt['evaluator_sha256'], 'sample_counts': receipt['sample_counts'],
                   'known_limitation': 'The two earlier runs retain the real 32 KiB SHM accounting gap; only the post-close run has final 733184-byte physical accounting and a 29-file seal.'})
        if label == 'initial-debug':
            GROUPS[-1]['missing_originals'] = [
                {'kind': 'initial lifecycle observer source', 'sha256': 'b501b0e929fc51ce252e3f88ddb7e680d7ca26a8d513ce6ca6d045cdf691c36b', 'status': 'unavailable; owner confirmed the iterative source was not frozen'},
                {'kind': 'initial evaluator executable', 'sha256': '63c73d68fe5292c85d9e712bf38df10721a60e69a506bd2335add0a9f6c62a58', 'status': 'unavailable; later debug executable is a different version'}]
        # The initial resource module is shared exactly; the missing initial
        # lifecycle body is expressly left absent, never replaced with 1775.
        observer_map[label] = observer_sources(label, root,
            git_ref=commit or ('1775d1156cb4efd3804ac3a127cae388d5c5e1f1' if label == 'initial-debug' else None), snapshot=snapshot)
    write_json('observer-source/recorded-sha-to-original-source.json', observer_map)
    add_group('debug_binary_identity', BASE/'p8-lifecycle-development-binaries/identity.json',
              'lifecycle/debug-binary-identity.json', 'original retained final-debug binary identity; large binaries omitted', {}, tree=False)
    add_group('lifecycle_first_independent_review', BASE/'lifecycle-1775d115-independent-review.json',
              'reviews/lifecycle-1775d115-independent-review.json', 'original independent raw/source/statistical audit', {}, tree=False)
    add_group('lifecycle_postfix_independent_review', BASE/'p8-lifecycle-postfix-independent-review',
              'reviews/lifecycle-postfix', 'original scoped review of 7f7d389b and its separately limited engineering smoke',
              {'reviewed_source': '7f7d389b29d454d81303068b0fefa7336f4246db'})
    scale_root = BASE/'validation-scale-20261009'
    for name in ('targeted-started.json', 'targeted-source-before.json', 'targeted-source-after.json',
                 'targeted-tests.log', 'targeted-tests.json', '99f9574-p8_scale_matrix.py',
                 '99f9574-p7_build_identity.py', 'preflight.py'):
        copy_file(scale_root/name, 'scale/' + name, 'scale_targeted')
    GROUPS.append({'id': 'scale_targeted', 'original': str(scale_root), 'archive': 'scale/',
        'classification': '22 actual release test passes at historical engineering source; not a final population performance result',
        'product_source': scale, 'test_count': 22, 'log_sha256': 'e451b6137a2442a289debf79e7e4a2192d89ea0d240fdcaeeaf5cde8d7a32c9e'})
    add_group('scale_actual60', scale_root/'actual60-shard', 'scale/actual60-shard',
              'real 60-file smoke shard: ten samples; not the full registered scale population',
              {'product_source': scale, 'observed_seconds': 6.678, 'raw_bytes': 698418, 'recorded_status': 'passed'})
    add_group('scale_1000_failure', scale_root/'preflight-1000-one-global-sample',
              'scale/preflight-1000-one-global-sample', 'original failed 1000-file engineering preflight; failure intentionally retained',
              {'product_source': scale, 'exit_code': 2, 'observed_seconds': 16.328,
               'failure': 'reexport_depth_budget_exceeded', 'fixed_result_claim': False})
    EXCLUDED.append({'source': str(scale_root/'fixed-build-803773e4'), 'reason': 'active later build outside this completed-observation archive; not traversed'})
    EXCLUDED.append({'source': str(scale_root/'p8-scale-99f9574'), 'reason': 'separately retained large native executable; receipt SHA retained'})
    bundle = build_bundle()
    write_json('classifications.json', {'schema_version': 1, 'groups': GROUPS,
        'all_original_files_copied_byte_for_byte': True, 'source_and_runner_versions_kept_separate': True,
        'final_ci_source': None, 'final_ci_results': 'not included; belong to a later frozen publication',
        'todo_closure_claim': False, 'release_certification': False})
    write_json('excluded-items.json', {'schema_version': 1, 'items': EXCLUDED,
        'policy': 'No Cargo targets, large native executable copies, active later builds, repository metadata or protected corpus bodies.'})
    readme = '''# P8 工程验证原件档案\n\n本档案保留已经完成的历史工程验证；不改原始文件内容，不把旧源码结果重标为最终 CI 的源码。\n\n## 内容与版本\n\n- recovery/full-matrix-de04：de04d4c 的真实恢复矩阵、原 Rust 故障执行日志、stdio/HTTP raw、数据库与 runner 源码快照。\n- rollback：原公开源码 277f2490 的构建回执，以及当前 de04/schema25 与历史 schema24 的两次真实四阶段版本回滚。第一次 runner 仅存 SHA，未冒用后版代码；closing-regression 精确对应 e5172ec。\n- lifecycle：三份各10样本的原始 debug smoke。第一版 observer/evaluator 原件部分缺失，详见 observer-source 映射。第二份与 post-close 的实际 observer 字节按记录 SHA 恢复。前两份32KiB SHM统计缺口原样保留；post-close 的733184字节终态与29文件封存保留。均不认证 actual release CLI。\n- scale：99f95742 的22项真实 release tests、60文件/10样本烟测原件，以及1000文件预检的 reexport_depth_budget_exceeded 原始失败；新修复不冒充这些旧执行已通过。\n- reviews：独立审查报告及其准确范围。\n- git：仅本轮7个本地 task 分支的固定快照增量 bundle，排除7354db23及其可达历史。\n\n完整分类、原路径映射及每个文件 SHA/长度见 classifications.json、manifest.json 与 SHA256SUMS。manifest.json 自身的 SHA 在 SHA256SUMS；校验表不包含自身。原回执中的绝对路径保持原样；读取归档文件时按 manifest 的 origin 映射定位。\n\n## Git 复核\n\n先准备包含基线7354db236c9d9850a75f31672697ae9eab44565e及其历史的 codecortex checkout，再运行：\n\n```bash\ngit bundle verify /absolute/path/git/local-p8-task-branches.bundle\ngit bundle list-heads /absolute/path/git/local-p8-task-branches.bundle\ngit fetch /absolute/path/git/local-p8-task-branches.bundle 'refs/heads/task/*:refs/remotes/p8-engineering-archive/*'\n```\n\nbranch-and-commit-map.json 保存快照时7个分支、全部本轮提交及父提交/树身份。GitHub插件的平铺发布可以产生另一个 P；本 bundle 保存原本地来源，不将二者混同。\n\n大二进制和 Cargo target 按要求不包含在紧凑档案内。此档案可审阅原始观测与代码来历，不能在缺少这些外部前提时声称完全自包含重跑。只遍历明确列出的合成夹具证据目录；不读取或复制 heldout corpus body。\n'''
    put_bytes('README.md', readme.encode(), 'generated archival guide', 'archive_metadata')
    inventory = {}
    for path in sorted(OUT.rglob('*')):
        if path.is_file():
            relative = path.relative_to(OUT).as_posix()
            inventory[relative] = {'bytes': path.stat().st_size, 'sha256': digest(path), **PROVENANCE[relative]}
    manifest = {'schema_version': 1, 'created_utc': datetime.now(timezone.utc).isoformat(),
        'archive_kind': 'historical_engineering_originals_and_local_git_provenance',
        'baseline': BASE_COMMIT, 'file_count_excluding_manifest_and_checksum_file': len(inventory),
        'payload_bytes': sum(row['bytes'] for row in inventory.values()), 'files': inventory,
        'complete_delivery_scope': 'every archived regular file except this manifest and SHA256SUMS; omitted native binaries/targets explicitly listed',
        'final_source_attestation': False, 'todo_complete': False}
    write_json('manifest.json', manifest)
    checksums = ''.join(f"{row['sha256']}  {path}\n" for path, row in sorted(inventory.items()))
    checksums += f'{digest(OUT / "manifest.json")}  manifest.json\n'
    put_bytes('SHA256SUMS', checksums.encode(), 'generated complete payload+manifest SHA list', 'archive_metadata')
    archive = OUT.with_suffix('.tar.gz')
    assert not archive.exists()
    with archive.open('xb') as sink, gzip.GzipFile(filename='', mode='wb', fileobj=sink, mtime=0, compresslevel=9) as zipped:
        with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.PAX_FORMAT) as tar:
            for path in sorted(OUT.rglob('*')):
                if not path.is_file():
                    continue
                info = tar.gettarinfo(str(path), arcname=OUT.name + '/' + path.relative_to(OUT).as_posix())
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                with path.open('rb') as stream:
                    tar.addfile(info, stream)
    expected = {path: row['sha256'] for path, row in inventory.items()}
    expected['manifest.json'] = digest(OUT/'manifest.json')
    expected['SHA256SUMS'] = digest(OUT/'SHA256SUMS')
    with tarfile.open(archive, 'r:gz') as tar:
        members = tar.getmembers()
        assert len(members) == len(expected)
        for member in members:
            relative = str(Path(member.name).relative_to(OUT.name))
            assert member.isfile() and sha_bytes(tar.extractfile(member).read()) == expected[relative]
    delivery = {'archive': str(archive), 'archive_bytes': archive.stat().st_size, 'archive_sha256': digest(archive),
        'manifest': str(OUT/'manifest.json'), 'manifest_bytes': (OUT/'manifest.json').stat().st_size,
        'manifest_sha256': digest(OUT/'manifest.json'), 'bundle': str(OUT/bundle['bundle']),
        'bundle_bytes': bundle['bundle_bytes'], 'bundle_sha256': bundle['bundle_sha256'],
        'branch_tips': bundle['branch_tips_at_snapshot'], 'local_commits': len(bundle['commits_after_baseline']),
        'archived_files': len(expected), 'payload_bytes': manifest['payload_bytes'],
        'tar_members_independently_rehashed': len(expected), 'excluded_items': len(EXCLUDED)}
    (BASE/'p8-rounds-engineering-archive-delivery.json').write_text(json.dumps(delivery, sort_keys=True, indent=2)+'\n')
    print(json.dumps(delivery, sort_keys=True))


if __name__ == '__main__':
    main()
