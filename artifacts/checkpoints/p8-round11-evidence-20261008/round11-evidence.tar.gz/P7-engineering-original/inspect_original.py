#!/usr/bin/env python3
"""Offline reception of an original merge-checkout engineering CI artifact."""
from pathlib import Path,PurePosixPath
import hashlib
import json
import re
import stat
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parent
REPO='/workspace/scratch/2eaa00d0f93a/p8-G4-exact-source'
HEAD='260f596582f2d82b8d7c707b61a6b8b6a43b069f'
MEASURED='5b7858cf584d1bfdbfaa89027b05bb4d7cb1cd49'
TREE='ab22c2c7995d051b2334f7267dd9bf747393113b'
RUN,JOB,ARTIFACT=37854847924,113576447291,11584817623
def sha(b):return hashlib.sha256(b).hexdigest()
def require(ok,msg):
    if not ok:raise ValueError(msg)
def read(name):return json.loads((ROOT/name).read_bytes())

run,jobs,artifacts=map(read,('run.json','jobs.json','artifacts.json'))
require(run['id']==RUN and run['head_sha']==HEAD and run['run_attempt']==1 and run['status']=='completed' and run['conclusion']=='success','run')
require(jobs['total_count']==len(jobs['jobs'])==1 and artifacts['total_count']==len(artifacts['artifacts'])==1,'complete populations')
job=jobs['jobs'][0];artifact=artifacts['artifacts'][0]
require(job['id']==JOB and job['name']=='engineering' and job['run_id']==RUN and job['head_sha']==HEAD and job['conclusion']=='success','job')
require(artifact['id']==ARTIFACT and artifact['name']=='p7-engineering-'+MEASURED and artifact['workflow_run']['id']==RUN and artifact['workflow_run']['head_sha']==HEAD and artifact['expired'] is False,'artifact')
archive=ROOT/f'artifact-{ARTIFACT}.zip';zip_sha=sha(archive.read_bytes())
require(archive.stat().st_size==artifact['size_in_bytes']==270863 and artifact['digest']=='sha256:'+zip_sha and zip_sha=='e4ec4d912fc329a9ea7c9004b38fd0d267636a8f40f4490d1395965fbe04d947','ZIP')
log=(ROOT/f'job-{JOB}.log').read_text()
require(re.search(r'git log -1 --format=%H\n[^\n]*'+MEASURED,log) and 'HEAD is now at 5b7858c Merge '+HEAD+' into 341db995e5f092fd95aed35af84cbc8b69e1af40' in log,'actual merge checkout')
require('1.95.0-x86_64-unknown-linux-gnu installed - rustc 1.95.0' in log,'actual toolchain')
inventory={};test_groups={};ignored=[];source=None
with zipfile.ZipFile(archive) as z:
    require(len(z.infolist())==len(set(z.namelist()))==26,'original member population')
    for info in z.infolist():
        p=PurePosixPath(info.filename)
        require(not info.is_dir() and not p.is_absolute() and p.as_posix()==info.filename and '..' not in p.parts and '\\' not in info.filename and not info.flag_bits&1 and stat.S_IFMT(info.external_attr>>16) in (0,stat.S_IFREG),'member')
        with z.open(info) as f:h=hashlib.file_digest(f,'sha256').hexdigest()
        inventory[info.filename]={'bytes':info.file_size,'sha256':h,'crc32':f'{info.CRC:08x}'}
        if info.filename.endswith('.log'):
            text=z.read(info).decode()
            groups=[{'passed':int(a),'failed':int(b),'ignored':int(c),'filtered_out':int(d)} for a,b,c,d in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;',text)]
            require(not re.search(r'test result: FAILED|^FAILED \(',text,re.M),'failed original test')
            if info.filename=='input-lock.log':require(re.search(r'Ran 15 tests in [0-9.]+s\s+OK\s*$',text),'original 15 lock controls')
            else:require(bool(groups) and all(x['failed']==0 for x in groups),'original Rust groups')
            test_groups[info.filename]=groups
            ignored.extend(line for line in text.splitlines() if ' ... ignored' in line)
    source=json.loads(z.read('source-before.json'))
    require(source==json.loads(z.read('source-after.json')) and source['source_commit']==MEASURED and source['source_tree']==TREE and source['input_count']==len(source['inputs'])==1087,'original source snapshot equality')
    batch=subprocess.Popen(['git','-C',REPO,'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
    for path,digest in source['inputs'].items():
        batch.stdin.write((HEAD+':'+path+'\n').encode());batch.stdin.flush();header=batch.stdout.readline().decode().split()
        require(len(header)==3 and header[1]=='blob','fixed G4 input')
        body=batch.stdout.read(int(header[2]));require(batch.stdout.read(1)==b'\n' and sha(body)==digest,'original measured input differs from G4 '+path)
    batch.stdin.close();require(batch.wait()==0,'source Git read')
    counts=[]
    for seed in (7,19,43):
        prefix=f'worker-contention/seed-{seed}/';protocol=json.loads(z.read(prefix+'protocol.json'))
        require(protocol['seed']==seed and protocol['concurrency_cells']==[1,4,8,16] and protocol['samples_per_cell']==32 and protocol['phases']==['quiet','held'] and protocol['full_task_acceptance'] is False and protocol['performance_sla'] is None,'original synthetic protocol scope')
        for phase in ('quiet','held'):
            rows=json.loads(z.read(prefix+phase+'-requests.json'))
            require(len(rows)==128,'retained phase request count')
            counts.append({'seed':seed,'phase':phase,'requests':len(rows)})
    life={}
    for file in ('local-cancel','model-switch'):
        rows=json.loads(z.read('lifecycle/'+file+'.json'));require([x['seed'] for x in rows]==[7,19,43],'original lifecycle seeds')
        require(all(x['scope']=='in-process synthetic functional contention; not full V20 performance certification' for x in rows),'lifecycle scope')
        life[file]=len(rows)
passed=sum(x['passed'] for group in test_groups.values() for x in group);ignore=sum(x['ignored'] for group in test_groups.values() for x in group)
require(passed==95 and ignore==1,'original executed Rust population')
bridge=Path('/dev/shm/p8-P5-review-preparation-pr-audit/G4-published-identity-bridge.json')
result={'status':'accepted_scoped_original_P7_engineering_CI_evidence','run_id':RUN,'job_id':JOB,'artifact_id':ARTIFACT,'run_head':HEAD,'actual_measured_source':MEASURED,'actual_measured_tree':TREE,'original_source_before_after_equal':True,'full_1087_production_inputs_byte_identical_to_G4':True,'source_manifest_sha256':source['manifest_sha256'],'existing_merge_root_bridge_sha256':sha(bridge.read_bytes()),'source_bridge_boundary':'Actual PR merge has main341 artifact-only additions. Product inputs and scripts/workflow root tree bytes match G4, but original source/receipt identity remains5b7858; no measured commit relabel.','artifact_sha256':zip_sha,'artifact_bytes':archive.stat().st_size,'members':len(inventory),'member_bytes':sum(x['bytes'] for x in inventory.values()),'all_member_CRC_SHA_verified':True,'Rust_passed_executions':passed,'Rust_ignored':ignore,'ignored_lines':ignored,'Python_input_lock_tests_passed':15,'test_groups':test_groups,'worker_original_phase_requests':counts,'retained_lifecycle_seed_rows':life,'job_log_sha256':sha((ROOT/f'job-{JOB}.log').read_bytes()),'limitations':['Engineering dev-profile tests and synthetic protocols; not a release build attestation or fullP7/P8 acceptance.','This existing workflow retains Cargo/test logs and source snapshots, not binary copies or full Cargo JSON executable receipts; no independent release binary digest claim.','Worker configured C1/4/8/16 and768 functional request receipts do not establish observed C peaks, homogeneous tail performance, quality or a new SLA.','Lifecycle resource snapshots explicitly combine in-process runner/server/provider and do not establish whole-process-tree sampled peak.','Original single ignored test is preserved, not reported executed.','No local Cargo/product/native execution, new workload or heldout corpus body read.','Original CI historical-integration failure remains separate; this success does not override it.'],'TODO_closed':0,'TODO_remaining':29}
(ROOT/'member-hashes.json').write_text(json.dumps(inventory,indent=2,sort_keys=True)+'\n')
(ROOT/'inspection.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':result['status'],'sha256':sha((ROOT/'inspection.json').read_bytes()),'Rust_passed':passed,'Rust_ignored':ignore}))
