def stable_00416():
    return 416
