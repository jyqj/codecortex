from pathlib import Path
import datetime, hashlib, json, re

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = Path(__file__).resolve().parent
HEAD = 'f97c5068d056969705e8387ba1f37d83847f5bee'

def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}

def dump(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n')

def unwrap(value):
    if isinstance(value, dict):
        if 'jobs' in value:
            return value
        if 'structuredContent' in value:
            content = value['structuredContent'].get('content')
            if isinstance(content, str):
                parsed = json.loads(content)
                if 'jobs' in parsed:
                    return parsed
        for sub in value.values():
            found = unwrap(sub)
            if found is not None:
                return found
    elif isinstance(value, list):
        for sub in value:
            found = unwrap(sub)
            if found is not None:
                return found

log = ROOT/'round41-PR201-ordinary-CI-original-logs/114135223961-original-closeout.log'
original = identity(log)
assert original['bytes'] == 1916891
assert original['sha256'] == '5541ef7a6ef6a7d7cc0222619cc4ffc66db87aaf1d10e21db630b07357c10688'
assert original['git_blob'] == '703de5825d10906a0fb8e19e9f28f971357955a7'
text = log.read_text()
lines = text.splitlines()
ansi = re.compile(r'\x1b\[[0-9;]*m')
def excerpt(start, end):
    return [{'line': i, 'text': ansi.sub('', lines[i-1])} for i in range(start,end+1)]

assert lines[194].endswith(HEAD)
assert 'test loopback::ready_publication_status_keeps_request_policy_and_per_query_coverage_distinct ... ok' in lines[3697]
assert '12 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in lines[3937]
assert '##[error]' not in text
footer_re = re.compile(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;')
footers, ignored, warnings = [], [], []
last_target = None
for n,line in enumerate(lines,1):
    if ' Running ' in line or 'Doc-tests ' in line:
        last_target = {'line':n, 'text':line}
    match = footer_re.search(line)
    if match:
        state,*counts = match.groups()
        counts = list(map(int,counts))
        assert state == 'ok' and counts[1] == 0
        footers.append({'line':n, 'nearest_logged_target':last_target, 'raw_footer':line,
                        **dict(zip(['passed','failed','ignored','measured','filtered_out'],counts)),
                        'nested_child_or_repeated_configuration_not_deduplicated': True})
    if re.search(r'test .* \.\.\. ignored',line):
        ignored.append({'line':n,'text':line})
    if 'Warning' in line or '##[warning]' in line:
        warnings.append({'line':n,'text':line})

jobs_path = OUT/'jobs-38025451825.official-original.json'
job = next(j for j in unwrap(json.loads(jobs_path.read_text()))['jobs'] if j['id']==114135223961)
assert job['head_sha']==HEAD and job['conclusion']=='success' and job['status']=='completed'
assert job['run_attempt']==1
new_methods = [
    'borrowed_cursor_text_matches_owned_conversion_and_row_storage',
    'borrowed_cursor_pair_preserves_both_rows_duplicates_and_asymmetric_eof',
    'borrowed_cursor_pair_keeps_original_step_and_conversion_error_order',
    'task_descriptive_scope_is_explicit_n1_without_weakening_old_n30',
    'task_descriptive_scope_rejects_changed_identity_and_registered_budgets',
    'task_descriptive_cli_does_not_launch_a_n30_or_mixed_scope_plan',
]
assert all(name not in text for name in new_methods)
assert 'verify_reviewed_source_v15' not in text and 'code_index_plan.py' not in text
report = {
    'schema_version':1, 'reviewer':'pr_triage',
    'scope':'Independent read-only original closeout log review; no Actions download, artifact read, product or test rerun.',
    'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source':HEAD, 'run_id':38025451825, 'run_attempt':1, 'job_id':114135223961,
    'original_full_log':original, 'official_job':job,
    'conclusion':'accepted_scoped_original_closeout_success_not_all_CI_or_new_scale_execution',
    'actual_checkout':{'sha':HEAD,'evidence':excerpt(192,195),'direct_head_not_testmerge':True},
    'command_groups':[
        {'scope':'cc-db library and five semantic lifecycle integrations; cc-semantic all targets', 'original':excerpt(479,487)},
        {'scope':'cc-server default, semantic, semantic-http wiring and HTTP library; cc-model filtered semantic controls', 'original':excerpt(1518,1532)},
        {'scope':'fresh debug semantic-http server producer, source equality, exact original lifecycle driver hash and driver execution', 'original':excerpt(3959,4008)},
        {'scope':'original fault lifecycle real stdio wrapper using bound server', 'original':excerpt(4021,4027)},
        {'scope':'cc-eval one filtered self-resource library control and three named semantic integrations', 'original':excerpt(4065,4072)},
    ],
    'v18':{
        'default_parameter_contract':{'footer_line':2311,'passed':8,'failed':0},
        'semantic_parameter_contract':{'footer_line':2635,'passed':9,'failed':0},
        'semantic_http_parameter_contract':{'footer_line':3938,'passed':12,'failed':0,'ignored':0,'filtered_out':0},
        'fixed_barrier_method':excerpt(3698,3698),
        'counts_are_configuration_occurrences_not_unique_method_sum':True,
    },
    'source_preservation':{
        'initial_source_snapshot':excerpt(458,467),
        'after_compilation_assertion':excerpt(3969,3974),
        'terminal_source_snapshot_and_equality_assertion':excerpt(4143,4152),
        'boundary':'Original commands completed in successful job; source snapshot and producer bytes inside uploaded artifact were not separately downloaded or revalidated here.',
        'v15_or_task_plan_not_invoked_in_this_job':True,
    },
    'fault_lifecycle_final':excerpt(4064,4064),
    'test_result_footers':footers, 'ignored_named_lines':ignored,
    'footer_count':len(footers),
    'footer_scope':'All logged footer occurrences retained including subprocess targets and repeated feature configurations. No aggregate unique-test count claimed.',
    'new_six_methods_not_executed_by_this_closeout_job':new_methods,
    'filtered_eval_lib_evidence':excerpt(4104,4110),
    'upload_observed':{
        'artifact_id':11659934936, 'name':'p7-closeout-'+HEAD,
        'bytes':20521066,'sha256':'d08be02b434643e137b0bdbb1de593c1e2b90708679815142826abf4a7692d1c',
        'announced_file_count':95,'original':excerpt(4186,4199),
        'not_downloaded_or_independently_CRC_member_verified_by_this_review':True,
    },
    'warnings':warnings,
    'limitations':[
        'Node action deprecation warnings are preserved; no failed Rust footer or GitHub error annotation in this original log.',
        'Passing closeout does not prove all 26 ordinary gates, the six new cursor/scope methods, a release 45-plan invocation, or any task-study sample.',
        'Prior G750 formatter failure remains separate and immutable; no historical execution was relabeled.',
    ],
}
dump(OUT/'independent-original-closeout-review.json',report)

main_path = ROOT/'round41-0506-main-jobs-original.json'
main_raw = json.loads(main_path.read_text())
main_job = next(j for j in unwrap(main_raw)['jobs'] if j['id']==114135224079)
assert main_job['head_sha']==HEAD
step8 = next(s for s in main_job['steps'] if s['number']==8)
assert step8['conclusion']=='success' and step8['started_at']=='2026-10-10T05:00:24Z' and step8['completed_at']=='2026-10-10T05:05:07Z'
ci_path = ROOT/'round32-capture-context-admission/guard-view/.github/workflows/ci.yml'
ci = ci_path.read_text()
command = 'cargo test --workspace --all-targets --exclude cc-semantic --locked'
assert command in ci
workflow_path = ROOT/'round40-task-profile-workflow-candidate/candidate/.github/workflows/p8-task-profile.yml'
workflow = workflow_path.read_text()
assert 'task_descriptive_scope_is_explicit_n1_without_weakening_old_n30' in workflow and '--release' in workflow
launch = {
    'schema_version':1,'reviewer':'pr_triage','recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source':HEAD, 'scope':'Immediate study-launch readiness assessment; neither study launch nor merge/task-completion approval.',
    'root_latest_original_jobs':identity(main_path), 'actual_main_job_id':114135224079,
    'actual_default_regression_step':step8,
    'original_command':command,'command_source':identity(ci_path),
    'selected_new_unique_method_names':new_methods,
    'selection_basis':'Original unfiltered default workspace all-targets command includes cc-eval library and p8_scale integration target; six methods have no ignore or test-name filter. Method-level log confirmation awaits root unique terminal log intake.',
    'already_verified_source_selection_report':identity(OUT/'independent-finite-CI-observation.json'),
    'recommendation':'A single fixed-G2 study may be launched now while ordinary hoursoak continues; no known critical blocker in observed fmt/clippy/default compilation/default regression and successful closeout.',
    'original_workflow_source':identity(workflow_path),
    'retained_inside_study_gate':'Fresh release build and exact release 45-plan test must pass before matrix measurements. Ordinary debug test success is not the positive release admission.',
    'no_requirement_found_for_ordinary_hoursoak_before_launch':'Task workflow depends on its own build job; no ordinary-CI or hoursoak dependency is encoded. This is bounded source review, not a new exception to merge requirements.',
    'separate_outcomes':{
        'engineering_merge':'All original 26 ordinary gates remain required according to existing review scope.',
        'task_study_acceptance':'Original complete 45 cells / 85 records and registered source/build/limits, full original raw/parity and independent acceptance remain required.',
        'task_done':'Unchanged original definitions/dependencies and actual accepted evidence decision; no task update here.',
    },
    'not_claimed':['main job terminal success','six named method log lines already read','local Rust execution','positive release 45-plan execution','study triggered','study sample accepted','new original TODO completion'],
}
dump(OUT/'study-launch-readiness-after-default-success.json',launch)
print(json.dumps({'status':'accepted_scoped','closeout_footers':len(footers),'ignored_lines':len(ignored),'warnings':len(warnings),
                  'closeout_report':identity(OUT/'independent-original-closeout-review.json'),
                  'launch_report':identity(OUT/'study-launch-readiness-after-default-success.json')},ensure_ascii=False))
