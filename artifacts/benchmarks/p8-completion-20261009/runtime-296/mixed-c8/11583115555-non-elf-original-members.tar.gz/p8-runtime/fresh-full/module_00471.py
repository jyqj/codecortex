def stable_00471():
    return 471
