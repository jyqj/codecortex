#!/usr/bin/env python3
"""Independent original-byte reception audit; only original --hash-file may execute."""
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile
import zlib

OUT = Path(__file__).resolve().parent
ROOT = Path('/dev/shm/p8-staging-engineering-reception')
SOURCE_ROOT = Path('/workspace/scratch/2eaa00d0f93a/p8-staging-engineering-exact-source')
SOURCE = '8e542e644b06a83fc82d18d9896cf82f5b2d796e'
RUN, JOB = 37863581678, 113604866890
sys.path.insert(0, str(SOURCE_ROOT/'scripts'))
import p8_scale_matrix as original

def require(ok, message):
    if not ok: raise ValueError(message)

def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f, 'sha256').hexdigest()

def read(path):return json.loads(path.read_bytes())

def main():
    begun=datetime.datetime.now(datetime.timezone.utc).isoformat()
    before=original.source_snapshot(SOURCE_ROOT)
    driver=original.driver_snapshot(SOURCE_ROOT)
    require(before['source_commit']==SOURCE and before['source_tree']=='28a35d538f11613e98e645f37d8bbd4946d754ac' and before['input_count']==1087,'source identity')
    summaries=[]
    for artifact,kind in ((11587252940,'controls'),(11587547695,'build')):
        directory=ROOT/str(artifact);target=directory/'original'
        meta=read(directory/'expected-artifact.json');run=read(directory/'run.json');job=read(directory/'job.json');inspection=read(directory/'inspection.json');execution=read(directory/'receiver-execution.json')
        require(meta['id']==artifact and meta['workflow_run']['id']==RUN and meta['workflow_run']['head_sha']==SOURCE and meta['expired'] is False,'artifact provenance')
        require(run['id']==RUN and run['head_sha']==SOURCE and run['run_attempt']==1 and run['event']=='push','run provenance')
        require(job['id']==JOB and job['name']=='controls_and_build' and job['head_sha']==SOURCE and job['run_id']==RUN and job['run_attempt']==1 and job['status']=='completed' and job['conclusion']=='success','actual completed job')
        zip_path=directory/'original.zip';zip_digest=sha(zip_path)
        require(meta['size_in_bytes']==zip_path.stat().st_size and meta['digest']=='sha256:'+zip_digest,'API ZIP identity')
        require(inspection['source']==SOURCE and inspection['run_id']==RUN and inspection['kind']==kind and inspection['source_and_driver_unchanged'] is True and inspection['status'].startswith('accepted_scoped'),'inspection identity')
        require(execution['actual_exit_code']==0 and execution['argv'][2:]==['--kind',kind,'--artifact-directory',str(directory)],'actual receiving process exit/argv')
        require(execution['argv'][1]=='/workspace/scratch/2eaa00d0f93a/p8-staging-engineering-publication-root/receive_engineering.py','receiver path')
        require(sha(Path(execution['argv'][1]))=='7fc8afcf5ecf03db093eac97517a77b5d08287961169364c1a8e55b774b33f86','receiver changed')
        stdout=read(directory/'receiver.stdout.log')
        require(stdout['inspection_sha256']==sha(directory/'inspection.json') and stdout['status']==inspection['status'] and (directory/'receiver.stderr.log').read_bytes()==b'','actual receiving output differs')
        inventory={}
        with zipfile.ZipFile(zip_path) as archive:
            for info in archive.infolist():
                name=PurePosixPath(info.filename)
                require(not name.is_absolute() and '..' not in name.parts and str(name)==info.filename and not info.is_dir() and stat.S_ISREG(info.external_attr>>16) and info.filename not in inventory,'ZIP member')
                count,crc,d=0,0,hashlib.sha256()
                with archive.open(info) as f:
                    for b in iter(lambda:f.read(1024*1024),b''):count+=len(b);crc=zlib.crc32(b,crc);d.update(b)
                require(count==info.file_size and (crc&0xffffffff)==info.CRC,'ZIP CRC/bytes')
                inventory[info.filename]={'bytes':count,'sha256':d.hexdigest()}
        require(inventory==original.inventory(target),'all expanded originals differ')
        require(inventory=={n:{'bytes':v['bytes'],'sha256':v['sha256']} for n,v in inspection['reception']['members'].items()},'original reception member map differs')
        require(read(target/'source-before.json')==read(target/'source-after.json')==before,'actual original source snapshots')
        summaries.append(dict(artifact_id=artifact,kind=kind,zip_bytes=zip_path.stat().st_size,zip_sha256=zip_digest,member_count=len(inventory),expanded_bytes=sum(x['bytes'] for x in inventory.values()),inspection_sha256=sha(directory/'inspection.json'),actual_receiver_exit_code=0,receiver_execution_sha256=sha(directory/'receiver-execution.json')))
    target=ROOT/'11587252940/original';receipt=read(target/'receipt.json')
    expectation=Path('/dev/shm/p8-staging-engineering-test-expectations/expectations.json')
    require(sha(expectation)=='468379420a6258344f4e0082a6be0e5cd5a04aab175eef6a3204f747db02379d','own independent static population')
    exp=read(expectation)
    require(receipt['files']==original.inventory(target,('receipt.json',)) and receipt['status']=='commands_completed' and receipt['exit_code']==0 and receipt['source_unchanged'] is True and receipt['not_run_command_indices']==[],'actual complete controls seal')
    require(receipt['commands']==[c['argv'] for c in exp['commands']] and len(receipt['results'])==13,'13 original commands')
    actual_tests=[]
    for c,r in zip(exp['commands'],receipt['results']):
        require(r['argv']==c['argv'] and r['exit_code']==0 and r['stdout']==c['stdout_file'] and r['stderr']==c['stderr_file'],'command exit/logs')
        stdout=(target/r['stdout']).read_text()
        names=re.findall(r'^test (.+?) \.\.\. ok$',stdout,re.M)
        results=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',stdout,re.M)
        running=re.findall(r'^running (\d+) tests?$',stdout,re.M)
        wanted=[x['harness_name'] for x in c['tests']]
        if c['expected_executed']==0:
            require(not names and not results and not running,'fmt/clippy unexpected harness');continue
        require(len(names)==len(set(names))==len(wanted) and set(names)==set(wanted),'exact names missing/duplicated')
        require(len(results)==len(running)==1 and list(map(int,results[0][:4]))==[len(wanted),0,0,0] and int(running[0])==len(wanted),'actual test outcomes')
        require(c['kind']!='integration' or int(results[0][4])==0,'integration was filtered')
        actual_tests.append({'command_index':c['command_index'],'names':names,'passed':len(names),'failed':0,'ignored':0,'filtered_out':int(results[0][4])})
    require(sum(t['passed'] for t in actual_tests)==41,'actual41')
    built,binary=original.validate_build(ROOT/'11587547695/original',SOURCE_ROOT)
    require(original.source_snapshot(SOURCE_ROOT)==before and original.driver_snapshot(SOURCE_ROOT)==driver,'source changed during independent replay')
    for artifact in (11587252940,11587547695):
        d=ROOT/str(artifact);seal=read(d/'reception.json')
        require(sha(d/'original.zip')==seal['zip_sha256'] and original.inventory(d/'original')=={n:{'bytes':v['bytes'],'sha256':v['sha256']} for n,v in seal['members'].items()},'originals changed during independent replay')
    report=dict(status='accepted_scoped_actual_auxiliary_controls_and_release_build',reviewer='/root/pr_audit',started_utc=begun,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source=SOURCE,tree=before['source_tree'],input_count=1087,source_manifest_sha256=before['manifest_sha256'],run_id=RUN,job_id=JOB,artifacts=summaries,commands=receipt['commands'],actual_test_results=actual_tests,actual_passed=41,actual_failed=0,actual_selected_ignored=0,original_validate_build_passed=True,binary_sha256=built['binary_sha256'],binary_blake3=built['binary_blake3'],binary_bytes=binary.stat().st_size,build_receipt_sha256=sha(ROOT/'11587547695/original/build.json'),source_and_driver_unchanged=True,Cargo_executed_by_reviewer=False,native_call_scope='Only one original validate_build -> p8-scale --hash-file identity invocation; no new product workload.',limits=['Actual auxiliary controls and source-built release identity only.','No 1k/10k/100k diagnostic is accepted by this report.','No full N30, causal performance gain, canonical source approval or TODO closure.'],new_TODO_done=0,TODO_remaining=29)
    with (OUT/'actual-controls-build-review.json').open('x') as f:json.dump(report,f,sort_keys=True,indent=2);f.write('\n')
    print(json.dumps({'status':report['status'],'tests':41,'artifacts':summaries,'review_sha256':sha(OUT/'actual-controls-build-review.json')}))

if __name__=='__main__':main()
