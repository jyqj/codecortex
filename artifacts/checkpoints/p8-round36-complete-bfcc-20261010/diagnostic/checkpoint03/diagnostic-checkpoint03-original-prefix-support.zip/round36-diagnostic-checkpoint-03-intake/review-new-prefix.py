"""Read newly received checkpoint03, preserving uncertainty and original bytes."""
import collections
import datetime
import hashlib
import json
from pathlib import Path
import stat
import zipfile

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'round36-diagnostic-checkpoint-03-intake/attempt01'
OLD = ROOT / 'round35-diagnostic-checkpoint-02-intake/attempt01'
BUILD = ROOT / 'round33-PR200-build-capacity-original-intake/attempt01'
BINDING = ROOT / 'round32-100k-diagnostic-intake-bound-9cc6-run38012409915/binding.json'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def identity(p):
    b = p.read_bytes()
    return {'local_path': str(p), 'bytes': len(b), 'sha256': sha(b),
            'git_blob': hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest(),
            'posix_mode': oct(stat.S_IMODE(p.stat().st_mode))}

reader = json.loads((OUT / 'reader/report.json').read_text())
execution = json.loads((OUT / 'reader.execution.json').read_text())
old = json.loads((OLD / 'checkpoint02-prefix-review.json').read_text())
binding = json.loads(BINDING.read_text())
assert execution['exit_code'] == 0
assert all(execution[k] == 0 for k in ('validate_build_calls', 'validate_shard_calls', 'inspect_raw_calls', 'ELF_calls'))
assert {a['id'] for a in reader['artifacts']} == {'11655358015', '11655694522', '11656371239', '11656517936'}
new = next(a for a in reader['artifacts'] if a['id'] == '11656517936')
selected = OUT / 'selected-originals'
selected.mkdir(exist_ok=False)
with zipfile.ZipFile(new['zip_path']) as z:
    data = z.read('manifest.json')
    manifest = json.loads(data)
    (selected / 'manifest.json').write_bytes(data)
    for item in manifest['metadata_snapshots']:
        data = z.read(item['file'])
        assert len(data) == item['bytes'] and sha(data) == item['sha256']
        (selected / item['file']).write_bytes(data)
    chunks = [c for c in reader['streams']['shard/native/raw.jsonl']['chunks']
              if any(x['artifact_id'] == new['id'] for x in c['retained_locations'])]
    assert len(chunks) == 1
    chunk = chunks[0]
    location = next(x for x in chunk['retained_locations'] if x['artifact_id'] == new['id'])
    raw = z.read(location['member'])
    assert len(raw) == chunk['bytes'] and sha(raw) == chunk['sha256']
    (selected / location['member']).write_bytes(raw)
assert (selected / 'configuration.json.snapshot').read_bytes() == (OLD / 'selected-originals/configuration.json.snapshot').read_bytes()
config = json.loads((selected / 'configuration.json.snapshot').read_text())
assert config['original_build_receipt_sha256'] == identity(BUILD / 'extracted/build/build.json')['sha256']
assert config['original_driver_sha256'] == binding['driver_inputs']['scripts/p8_scale_matrix.py']
assert chunk['start'] == old['verified_prefixes']['shard/native/raw.jsonl']['end_exclusive']
assert old['new_raw_interval']['partial_tail_bytes'] == 0
events, intervals, failures = [], [], []
offset = chunk['start']
lines = raw.splitlines(keepends=True)
for number, line in enumerate(lines):
    row = {'new_line_index': number, 'start': offset, 'end': offset + len(line), 'bytes': len(line),
           'sha256': sha(line), 'complete_newline': line.endswith(b'\n')}
    offset += len(line)
    if not row['complete_newline']:
        row['status'] = 'partial_tail_not_a_complete_event'
    else:
        try:
            event = json.loads(line)
            events.append(event)
            row.update(event=event.get('event'), label=event.get('label'), status='complete_original_event')
        except (ValueError, UnicodeError) as error:
            row.update(status='complete_line_parse_error', error=str(error))
            failures.append(row)
    intervals.append(row)
new_counts = collections.Counter(e.get('event') for e in events)
total_counts = collections.Counter(old['new_raw_interval']['cumulative_complete_event_counts']) + new_counts
unfinished = list(old['started_but_not_finished_in_retained_prefix'])
finished = []
for e in events:
    if e.get('event') == 'build_started':
        unfinished.append(e)
    elif e.get('event') == 'build_finished':
        unfinished = [x for x in unfinished if x['label'] != e['label']]
        fields = ('elapsed_ms', 'phase_timing', 'build_timing', 'files_scanned', 'files_added', 'files_updated',
                  'files_removed', 'files_skipped', 'files_parsed', 'symbols_total', 'chunks_total',
                  'parse_errors', 'resolution_freshness')
        finished.append({**{k:e[k] for k in ('label', 'full', 'start_us', 'end_us', 'wall_us', 'process_snapshot')},
                         'original_report_fields': {k:e['report'].get(k) for k in fields}})
current = next(x for x in reader['checkpoints'] if x['index'] == 3)
assert len(current['acknowledgements']) == 3 and all(x['retained_original_and_official_digest_verified'] is True for x in current['acknowledgements'])
report = {'schema': 'p8-original-diagnostic-checkpoint03-prefix-review-v1',
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source': binding['G'], 'run_id': binding['run_id'], 'attempt': 1,
    'scope': 'New03 custody only; accepted00/01/02 reread only for unchanged frozen-reader continuity/ACK predicates. Later PR merge does not change original run source or parameters.',
    'new_original_artifact': new, 'old_continuity_artifact_ids': [11655358015,11655694522,11656371239],
    'old_bytes_reread_not_new_reception': True, 'previous_accepted_review': identity(OLD / 'checkpoint02-prefix-review.json'),
    'frozen_reader_execution': identity(OUT / 'reader.execution.json'), 'reader_exit_code': 0,
    'accepted_diagnostic_build_reused_without_revalidation': {'result': identity(BUILD / 'original-validate-build-result.json'),
        'receipt': identity(BUILD / 'extracted/build/build.json'), 'configuration_receipt_exact': True,
        'configuration_bytes_identical_to_checkpoint02': True, 'not_full_cohort_build': True},
    'verified_prefixes': {n:{'start':0,'end_exclusive':v['verified_retained_contiguous_chunk_prefix_bytes'],
        'highest_declared_offset':v['highest_declared_offset'],'unknown_tail_bytes':None,'EOF_claimed':False}
        for n,v in reader['streams'].items()},
    'new_raw_interval': {**chunk,'ends_in_newline':raw.endswith(b'\n'),'original_line_intervals':intervals,
        'new_complete_event_counts':dict(new_counts),'cumulative_complete_event_counts':dict(total_counts),
        'complete_line_parse_errors':failures,'partial_tail_bytes':0 if not lines or lines[-1].endswith(b'\n') else len(lines[-1])},
    'checkpoint03_ACKs_of_00_01_02':current['acknowledgements'],
    'own_ACK_boundary':'Checkpoint03 snapshot precedes its own upload. Later local ACK is not supplied; official custody is independently verified.',
    'capture_faults_observed':reader['capture_faults'],'metadata_parse_unknown':reader['metadata_parse_unknown'],
    'observer_before_seen_and_bound':reader['observer_before_seen'],'observer_after_seen':reader['observer_after_seen'],
    'new_finished_build_records':finished,'started_but_not_finished_in_retained_prefix':unfinished,
    'visible_frontier':'The latest record finishes no_op/full_control. No no_op stage_finished/parity-completion or subsequent stage event is retained. The current hidden execution phase after this record remains unknown.',
    'cold_parity_events':total_counts.get('cold_parity',0),'stage_finished_events':total_counts.get('stage_finished',0),
    'supervisor_terminal_seen':bool(reader['supervisor_receipts']),'native_report_seen':bool(reader['native_reports']),
    'reported_native_outcome':reader['reported_native_outcome'],'custody_status':reader['custody_status'],
    'timing_boundary':'Original counters only; full_staging is nested in prepare and timers are not added. No speedup forecast or hidden-phase attribution.',
    'original_function_calls':{'validate_build':0,'validate_shard':0,'inspect_raw':0,'check_parity':0,'ELF':0},
    'original_semantic_validation':'not_run; emitted records are not a substitute for the original complete-evidence predicates',
    'full_cohort_run_not_mixed':38013753078,'accepted_cohort_shards':0,'accepted_samples':0,'TODO_credit':0}
with (OUT / 'checkpoint03-prefix-review.json').open('x') as f:
    json.dump(report,f,ensure_ascii=False,indent=2)
    f.write('\n')
print(json.dumps({'report':identity(OUT/'checkpoint03-prefix-review.json'),'new_events':dict(new_counts),
    'raw_contiguous_bytes':reader['streams']['shard/native/raw.jsonl']['verified_retained_contiguous_chunk_prefix_bytes'],
    'native_outcome':reader['reported_native_outcome']}))
