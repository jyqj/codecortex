import datetime, hashlib, json
from pathlib import Path
ROOT=Path('/workspace/scratch/bfccb8494ba0');OUT=Path(__file__).resolve().parent;BASE=ROOT/'round45-post-nine-scope-followup'
inputs=[]
def read(p):
 b=p.read_bytes();inputs.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()});return b
def load(p):return json.loads(read(p))
def save(n,v):
 with (OUT/n).open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
claim=load(BASE/'original/claim-to-original-evidence-map.json');owner=load(BASE/'original/ownership-older-scoped-review.json');pub=load(BASE/'original/R35-publication-bridge.json');later=load(BASE/'original/R39-post-nine-addendum.json');baseline=load(BASE/'original/baseline-terminal-review.json');bp=load(BASE/'original/baseline-peer.json');archive=load(BASE/'original/archive-final-peer.json')
named=load(BASE/'current-G2-named-control-excerpts.json');fa=load(BASE/'current-G2-facts-and-archive-excerpts.json');tree=load(BASE/'current-G2-exact-relevant-tree.json')
tasks=load(ROOT/'round43-final-nine-application/recovered/tasks.original.json')
def walk(v):
 if isinstance(v,dict):
  if v.get('id') in ['P8-017','P8-018','P8-019']:yield v
  for x in v.values():yield from walk(x)
 elif isinstance(v,list):
  for x in v:yield from walk(x)
definitions=list(walk(tasks));assert len(definitions)==3
for old in claim['definitions']:
 t=next(v for v in definitions if v['id']==old['id'])
 for k in ['steps','acceptance','depends_on','validations']:assert old[k]==t[k]
assert tree['source']=='f97c5068d056969705e8387ba1f37d83847f5bee' and tree['tree']=='39a053ae49b486764751a570d164e7cd41d7ff29'
for path,oid in tree['expected_comparison'].items():assert tree['rows'][path]['git_blob']==oid
assert pub['publication']['three_document_blobs']=={k:tree['rows'][k]['git_blob'] for k in pub['publication']['three_document_blobs']}
assert bp['historical_document']['git_blob']==tree['rows']['docs/TEST_PLAN.md']['git_blob']
assert baseline['original_execution']['returncode']==0 and len(baseline['original_execution']['drift_lines_emitted'])==3
assert not bp['historical_document']['current_false_claim_found'] and bp['execution']['exit_code']==0
assert bp['execution']['cargo_argv']==['cargo','test','--workspace','--all-targets']
for f in archive['source_files_exactly_hash_checked']:
 path=f['repository_path']
 if path!='docs/roadmap/code-index-v2/P8-RELEASE-EVIDENCE.md':assert tree['rows'][path]['git_blob']==f['git_blob']
log=read(ROOT/'round42-new45-study/114135224079-original-main.log')
assert hashlib.sha1(b'blob '+str(len(log)).encode()+b'\0'+log).hexdigest()=='b42f2f685f4f2caaaa0497db6706399d9f89d998'
lines=log.decode('utf-8-sig').splitlines();checked=[]
for group,rows in named.items():
 for row in rows:
  assert row['current_ok_records']
  for e in row['current_ok_records']:
   assert lines[e['line']-1]==e['text'] and e['text'].endswith(' ... ok') and row['name'] in e['text']
   checked.append({'group':group,'name':row['name'],'line':e['line'],'text':e['text']})
assert len(fa['archive_test_records'])==42
for e in fa['archive_test_records']:assert lines[e['line']-1]==e['text'] and e['text'].endswith(' ... ok')
facts=fa['declared_facts'];assert facts['status']=='passed' and facts['errors']==[] and facts['runtime_certified'] is False
assert json.loads(lines[fa['declared_facts_line']-1].split(' ',1)[1])==facts
assert len(facts['facts']['base_tables'])==30 and len(facts['facts']['fts5_tables'])==5 and len(facts['facts']['mcp_tools'])==14
assert facts['facts']['database_schema']==25 and facts['facts']['default_network'] is False
save('current-original-log-line-crosscheck.json',{'source':tree['source'],'job_id':114135224079,'run_id':38025451919,'log_git':'b42f2f685f4f2caaaa0497db6706399d9f89d998','named_records':checked,'unique_named_methods':len({r['name'] for r in checked}),'archive_test_records':fa['archive_test_records'],'archive_unique_methods':42,'facts_line':fa['declared_facts_line'],'facts':facts,'scope':'Exact original line verification only; duplicate configuration occurrences are not summed as unique tests. No new test/facts/CLI run.'})
ownerrows=[{'path':f['path'],'git_blob':f['git_blob']} for f in owner['source_review']['exact_official_bytes_read']]
assert len(ownerrows)==11
report={'schema':'P8-017-018-019-current-main-independent-conditional-scope-review-v1','reviewer':'/root/pr_triage','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'accepted_existing_own_scope_conditional_on_original_dependency_chain','apply_now':False,'task_credit':0,'source':{'current_product_G2':tree['source'],'actual_merged_main':'0da9a2800d2b3112d584a8bad4f79785e01162a9','whole_tree':tree['tree'],'main_bridge':'round44-nine-application-main-bridge/actual-main-minimal-input-bridge.applyfalse.json; actual Git08aa3635f4a6572fef3bbf2bd82cba1ad527d80c','merged_at':'2026-10-10T06:05:09Z'},'original_definitions':[{k:t[k] for k in ['id','title','scope','depends_on','steps','deliverables','acceptance','validations','conditional','conditional_dependencies']} for t in definitions],'owner_source_bridge':{'method':'Reviewer executed bounded GIT_NO_LAZY_FETCH=1 git ls-tree HEAD -- exactly the 11 paths in the prior independent ownership review, in existing source-exact-G2. Exit0; all output OIDs compared equal. This is metadata observation, not a new source/algorithm execution.','observed_matching_rows':ownerrows,'old_source':owner['source_review']['fixed_original_source'],'new_source':tree['source']},'findings':[
{'task':'P8-017','own_scope':'satisfied_by_existing_exact_implementation_and_regressions','requirements':'Single live facts/algorithm owner; justified duplicate removal; preserve external wire compatibility.','evidence':{'owner_findings':owner['owner_findings'],'deletion':owner['deletion_evidence'],'current_source_11_OIDs_equal':True,'current_V18_V21_named_log_records':'current-original-log-line-crosscheck.json'},'limits':['18 duplicate engine tests removed and17 other tests retained are original source review facts, with later original regressions kept at their own source identities.','The four lane mechanism snapshots remain prepare-only/compiledfalse; they are not counted as executed controls.','Test-only legacy resolver and historical schemas plus compatibility/native public contracts are intentional; no unsupported requirement to delete these is imposed.'],'remaining_condition':'P8-016 must first receive its original formal acceptance; no new concrete self-implementation gap identified.'},
{'task':'P8-018','own_scope':'satisfied_by_published_document_facts_fix_current_controls_and_original_baseline_execution','evidence':{'published_docs':pub['publication']['three_document_blobs'],'current_facts_line':fa['declared_facts_line'],'current_facts_status':'passed/errors[]/runtime_certifiedfalse','current_install_offline_and_tool_controls':'current-original-log-line-crosscheck.json','baseline_source':bp['source'],'baseline_exit':bp['execution']['exit_code'],'baseline_wall_seconds':bp['execution']['wall_seconds'],'three_drifts':bp['three_drifts'],'historical_TEST_PLAN_git':bp['historical_document']['git_blob']},'interpretation':'PR198 fifteen-table correction is actually merged and exact in G2. Current schema25/30base+5FTS/14tools/default-offline declaration passed. Original b9 baseline command really executed; three DRIFT lines compare explicitly historical c86 figures, not a false current-count assertion. 2815/76 are footer sums, not unique methods/all-features. Do not relabel b9 baseline as G2 execution or rewrite its history.','remaining_condition':'After017 closes, no additional own-scope gap identified. No new no-DRIFT or script-rerun gate.'},
{'task':'P8-019','own_scope':'satisfied_by_unchanged_archive_replay_implementation_published_spec_and_current_regressions','evidence':{'archive_source_git':tree['rows']['scripts/p8_release_evidence.py']['git_blob'],'archive_tests_git':tree['rows']['scripts/tests/test_p8_release_evidence.py']['git_blob'],'replay_source_git':tree['rows']['crates/cc-eval/src/benchmark/report.rs']['git_blob'],'current_archive_tests':42,'current_named_native_replay':['raw_replay_reconstructs_identical_metrics','raw_replay_reconstructs_costs_without_inventing_missing_measurements','raw_and_normalized_drift_are_rejected'],'published_replay_directory_clarification':tree['rows']['docs/roadmap/code-index-v2/P8-RELEASE-EVIDENCE.md']['git_blob']},'implementation_boundary':['Exact supplied binary/config/source snapshot/checksums/evidence gate bytes and no-clobber archive are covered; caller build declarations alone do not prove binary provenance.','latest is only a run/archive/candidate pointer and advances only for explicit passed_local plus actual corpus lock; failure/native baseline/metadata-only cannot promote, original run stays unchanged.','Archive verify checks integrity, not numerical replay. Original native replay separately checks raw/normalized and regenerates reports on a writable independent copy, actual run child not suite parent.','Current42 archive controls and native replay/error methods are genuine G2 log records; no new combined end-to-end run is invented or required without original contractual basis.'],'remaining_condition':'After018 closes, no concrete own-scope gap identified; this is archival-function acceptance, not global G8 release approval.'}],
'validation_scope':{'V01':'Existing original fixed source/binary/toolchain/fresh-target platform receipts plus current default/HTTP/stdio/ignored-aware regression are kept at actual source identity; no new current release or all150 prerequisite.','V04':'Current raw replay, missing measurements, cancelled/timeout/error controls; not just archive verification exit0.','V18':'Current14-tool/mode/schema/sanitize/dispatch/status/real-stdio/default offline controls verified line by line.','V21':'Accepted original8 platform/rollback cells and25→24→25/backup remain original275e/277f/dev, complemented by current schema/cache/MSRV facts; no repackaged current-source release certification.'},'exact_conditional_sequence':['Wait for P8-016 actual original acceptance, not merely a draft or study prefix.','Then evaluate017→018→019 with these own-scope facts and retain every old not_run/failure record.','Root controls any final status/doc PR; this report changes nothing.'],'new_operations':{'tests':0,'product_or_replay_or_facts_commands':0,'Actions_downloads':0,'ZIP_or_CRC_or_ELF':0,'refs_or_task_mutations':0},'input_manifest':'read-input-identities.json'}
save('independent-017-019-conditional-scope-review.json',report);save('read-input-identities.json',inputs)
print(json.dumps({'result':report['result'],'named_unique_methods':len({r['name'] for r in checked}),'named_occurrences':len(checked),'current_archive_unique_methods':42,'current_facts_status':facts['status'],'owner_source_paths_unchanged':len(ownerrows),'new_task_credit':0},indent=2))
