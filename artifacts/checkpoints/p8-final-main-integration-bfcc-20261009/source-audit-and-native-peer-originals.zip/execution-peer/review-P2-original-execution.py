"""Independent read-only original ZIP/data review; no product commands run."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import stat
import zipfile

ROOT=Path('/workspace/scratch/bfccb8494ba0/root-round16/native-P2-originals-transfer')
ZIP=ROOT/'native-P2-first-failure-and-complete-continuation-originals.zip'
EX=ROOT/'extracted'
OUT=Path('/dev/shm/pr-triage-round16-P2-execution-peer')
MAP=Path('/dev/shm/execution-recon-recovery-20261009/P2-source-review/actual-P2-independent-source-review.reconstructed.json')
P='b3bf22eab019175774c6c83295620b63a9740888'
TREE='964af30886e142c6284dddab4e4451b4dc5e26cb'
PARENTS=['d7f21ab52ee2068c45ab5f7781e9e1db57f613de','4efbc97eb439a56347e7b32d05b7ea1ab6d34c75','ae033369f015c416cd7995709c1853497773cf6a']
E='P2-native-evidence/'
C=E+'continuation-complete-original-inputs/'
PREP=C+'mechanism-prepare-only/'
BLOCK=1048576

def data_identity(data):
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
def file_identity(path):
    length=path.stat().st_size;sha=hashlib.sha256();git=hashlib.sha1(b'blob '+str(length).encode()+b'\0');n=0
    with path.open('rb') as f:
        for b in iter(lambda:f.read(BLOCK),b''):n+=len(b);sha.update(b);git.update(b)
    assert n==length
    return {'path':str(path),'bytes':n,'sha256':sha.hexdigest(),'git_blob':git.hexdigest()}
def save(name,value):
    with (OUT/name).open('x') as f:json.dump(value,f,indent=2,ensure_ascii=False);f.write('\n')
def safe(n):
    p=PurePosixPath(n);assert n and not p.is_absolute() and '..' not in p.parts and '\\' not in n and '\0' not in n and p.as_posix()==n
def ls_tree(raw):
    result={}
    for entry in raw.split(b'\0'):
        if not entry:continue
        info,path=entry.split(b'\t',1);mode,kind,sha=info.decode().split();path=path.decode();safe(path)
        assert path not in result and kind=='blob' and mode in ['100644','100755']
        result[path]={'mode':mode,'git_blob':sha}
    return result

zip_id=file_identity(ZIP)
assert zip_id['bytes']==25744293 and zip_id['sha256']=='ff5d3ae9bb81189bbe3714f783ef11c8bd4c84d0c8774cb41b7e83e07232e27e' and zip_id['git_blob']=='102956bbc16a1138f4bb3abf3cc6190f7f699e27'
source_id=file_identity(MAP)
assert source_id['bytes']==424955 and source_id['sha256']=='2a5511c31d02ea0401d169db614830edd0359bfbdc717930cd5179899db184f1'
source=json.loads(MAP.read_bytes())
assert (source['source'],source['tree'],source['source_parents'])==(P,TREE,PARENTS)
assert len(source['complete_inputs'])==1095 and len(source['validation_inputs'])==142

with zipfile.ZipFile(ZIP) as z:
    def raw(n):return z.read(n)
    def j(n):return json.loads(raw(n))
    manifest=j('archive-manifest.json')
    assert manifest['source_P2']==P and manifest['tree']==TREE
    originals={x['path']:x for x in manifest['files']};directories={x['path']:x for x in manifest['directories']}
    assert len(originals)==len(manifest['files'])==5553 and len(directories)==len(manifest['directories'])==1070
    assert sum(x['bytes'] for x in originals.values())==manifest['total_file_bytes']==101422524
    expected=set(originals)|{x+'/' for x in directories}|{'archive-manifest.json'}
    infos=z.infolist();assert len(infos)==len(expected)==6624
    seen=set();member_rows=[];identities={};file_count=0;expanded_bytes=0;extracted_permission_differences=[]
    for info in infos:
        n=info.filename;assert info.orig_filename==n and n not in seen;seen.add(n)
        assert n in expected;safe(n[:-1] if info.is_dir() else n)
        kind=stat.S_IFMT(info.external_attr>>16);mode=stat.S_IMODE(info.external_attr>>16)
        assert kind!=stat.S_IFLNK
        sha=hashlib.sha256();git=hashlib.sha1(b'blob '+str(info.file_size).encode()+b'\0');count=0
        with z.open(info) as f:
            for b in iter(lambda:f.read(BLOCK),b''):count+=len(b);sha.update(b);git.update(b)
        assert count==info.file_size
        item={'path':n,'bytes':count,'sha256':sha.hexdigest(),'git_blob':git.hexdigest(),'zip_crc32':f'{info.CRC:08x}','mode':format(mode,'04o'),'directory':info.is_dir()}
        disk=EX/n
        assert not disk.is_symlink()
        if info.is_dir():
            assert kind==stat.S_IFDIR and count==0 and disk.is_dir()
            assert mode==int(directories[n[:-1]]['mode'],8)==stat.S_IMODE(disk.stat().st_mode)
        else:
            assert (kind==stat.S_IFREG or n=='archive-manifest.json' and kind==0) and disk.is_file();file_count+=1;expanded_bytes+=count
            disk_id=file_identity(disk)
            assert all(disk_id[k]==item[k] for k in ['bytes','sha256','git_blob'])
            if n!='archive-manifest.json':
                want=originals[n];assert all(item[k]==want[k] for k in ['bytes','sha256','git_blob'])
                assert mode==int(want['mode'],8)
                extracted_mode=stat.S_IMODE(disk.stat().st_mode)
                if mode!=extracted_mode:
                    extracted_permission_differences.append({'path':n,'original_ZIP_manifest_mode':format(mode,'04o'),'current_extracted_mode':format(extracted_mode,'04o'),'raw_bytes_SHA_Gitblob_equal':True,'Git_executable_mode_equal':bool(mode&0o111)==bool(extracted_mode&0o111)})
                assert bool(mode&0o111)==bool(extracted_mode&0o111)
            identities[n]=item
        member_rows.append(item)
    assert seen==expected and file_count==5554 and expanded_bytes==105480723
    assert identities['packaging/packaging-controller.py']['sha256']=='7e40723dfc52373016c0ba9cd4784b57e0300bb6fd9f18ec2eed9bb2c57efc1c'
    assert identities[C+'controls-controller.py']['sha256']=='ea86aa3a94a40f9031eceb4e59748e03893bc42be4b6fcfd0ab1160722a2fd91'
    commit=raw(E+'actual-P-object.stdout')
    assert hashlib.sha1(b'commit '+str(len(commit)).encode()+b'\0'+commit).hexdigest()==P
    header=commit.split(b'\n\n',1)[0].decode().splitlines()
    assert header[0]=='tree '+TREE and [x[7:] for x in header if x.startswith('parent ')]==PARENTS
    initial_doc=j(E+'before-domain-receipt.json');expanded_doc=j(E+'additional-original-compile-inputs/complete-domain-with-declared-compile-inputs.json')
    assert initial_doc['source_P']==expanded_doc['source_P']==P and initial_doc['tree']==expanded_doc['tree']==TREE
    assert initial_doc['ordered_parents']==PARENTS
    initial={x['path']:x for x in initial_doc['entries']};expanded={x['path']:x for x in expanded_doc['entries']}
    assert len(initial)==len(initial_doc['entries'])==1250 and len(expanded)==len(expanded_doc['entries'])==1256
    assert all(expanded[p]==v for p,v in initial.items())
    original_tree=ls_tree(raw(E+'official-domain-ls-tree.stdout'))
    assert set(original_tree)==set(initial)
    for p,row in initial.items():assert {k:row[k] for k in ['mode','git_blob']}==original_tree[p]
    inv=source['actual_input_mode_blob_inventory']
    assert len(inv)==1237
    for domain in ['complete_inputs','validation_inputs']:
        for p,sha in source[domain].items():
            row=initial[p];assert row['sha256']==sha and row['mode']==inv[p]['mode'] and row['git_blob']==inv[p]['sha']
            if 'size' in inv[p]:assert row['bytes']==inv[p]['size']
    added=sorted(set(expanded)-set(initial))
    assert len(added)==6 and set(added)=={x['path'] for x in expanded_doc['additional_declared_compile_inputs']}
    six_tree=ls_tree(raw(E+'additional-original-compile-inputs/actual-P2-six-ls-tree.bin'))
    declared=j(E+'additional-original-compile-inputs/declared-six-inputs.json')
    assert declared['source']==P and declared['tree']==TREE and {x['path'] for x in declared['entries']}==set(added)==set(six_tree)
    for row in declared['entries']:
        p=row['path'];actual=identities['selected-original-compile-inputs/'+p]
        assert all(actual[k]==row[k]==expanded[p][k] for k in ['bytes','sha256','git_blob'])
        assert row['mode']==expanded[p]['mode']==six_tree[p]['mode']
        assert row['git_blob']==six_tree[p]['git_blob']
        assert ('100755' if int(actual['mode'],8)&0o111 else '100644')==row['mode']
    checkout=j(E+'additional-original-compile-inputs/checkout-receipt.json')
    assert type(checkout['exit_code']) is int and checkout['exit_code']==0 and checkout['source_P2']==P
    for stream in ['stdout','stderr']:assert identities[E+'additional-original-compile-inputs/checkout.'+stream]['sha256']==checkout[stream+'_sha256']
    assert checkout['argv'][checkout['argv'].index('--')+1:]==[x['path'] for x in declared['entries']]
    for rec in j(E+'preparation-receipts.json'):
        assert type(rec['exit_code']) is int and rec['exit_code']==0
        for stream in ['stdout','stderr']:
            assert all(identities[E+rec[stream]['path']][k]==rec[stream][k] for k in ['bytes','sha256'])

    cwd='/Users/jin/Desktop/codecortex-rust/artifacts/benchmarks/p8-bfccb8494ba0/candidate-final-main-combined-P2-b3bf'
    cargo=['/Users/jin/.cargo/bin/cargo','+1.95.0']
    argv={
      'workspace-format':cargo+['fmt','--all','--','--check'],
      'new-lane-query-policy-lib-controls':cargo+['test','--locked','--offline','-p','cc-search','--lib'],
      'mechanism-source-anchor-control':cargo+['test','--locked','--offline','-p','cc-eval','--lib','fixed_controls_match_current_product_source_once'],
      'changed-search-eval-strict-clippy':cargo+['clippy','--locked','--offline','-p','cc-search','-p','cc-eval','--all-targets','--','-D','warnings']}
    actual_prepare_root=manifest['prepare_only']['original_prepared_document']['build']['reference_source'].removesuffix('/reference')
    argv['mechanism-four-variants-prepare-only']=['python3','-B','scripts/p7_mechanism_build.py','--source',cwd,'--expected-head',P,'--output',actual_prepare_root,'--prepare-only']
    initial_progress=j(E+'controls-progress.json');continuation=j(C+'controls-progress.json')
    assert [x['exit_code'] for x in initial_progress]==[0,101] and len(initial_progress)==2
    assert [x['exit_code'] for x in continuation]==[0,0,0,0] and len(continuation)==4
    commands=[];rust_names=[];snapshot_count=0;common_env=None
    for phase,prefix,progress,baseline in [('initial-missing-inputs',E,initial_progress,initial),('same-P2-complete-input-continuation',C,continuation,expanded)]:
        for index,rec in enumerate(progress):
            label=rec['label'];assert rec==j(prefix+label+'-receipt.json')
            assert (rec['source_P'],rec['tree'],rec['cwd'])==(P,TREE,cwd)
            assert type(rec['exit_code']) is int and 'controller_budget_seconds' not in rec
            assert rec['command']==argv[label]
            assert rec['environment']['RUSTUP_TOOLCHAIN']=='1.95.0'
            assert rec['environment']['SDKROOT']=='/Library/Developer/CommandLineTools/SDKs/MacOSX15.4.sdk'
            assert rec['environment']['CARGO_INCREMENTAL']=='0' and rec['environment']['CARGO_BUILD_JOBS']=='2'
            if common_env is None:common_env=rec['environment']
            assert rec['environment']==common_env
            for side in ['before','after']:
                ref=rec[side];assert all(identities[prefix+ref['path']][k]==ref[k] for k in ['bytes','sha256'])
                domain=j(prefix+ref['path']);assert domain['source_P']==P and domain['tree']==TREE
                assert {x['path']:x for x in domain['entries']}==baseline and len(domain['entries'])==len(baseline)==ref['entries']
                snapshot_count+=1
            for stream in ['stdout','stderr']:
                ref=rec[stream];assert all(identities[prefix+ref['path']][k]==ref[k] for k in ['bytes','sha256'])
            text=raw(prefix+rec['stdout']['path']).decode()+raw(prefix+rec['stderr']['path']).decode()
            summaries=[dict(passed=int(a),failed=int(b),ignored=int(c),measured=int(d),filtered_out=int(e)) for a,b,c,d,e in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text)]
            named=re.findall(r'^test (\S+) \.\.\. ok$',text,re.M)
            if phase=='initial-missing-inputs' and rec['test_kind']=='rust':
                assert rec['exit_code']==101 and not summaries and not named and not rec['rust_test_summaries']
                assert text.count('error: couldn\'t read `')==5 and 'due to 5 previous errors' in text
            elif rec['test_kind']=='rust':
                assert rec['exit_code']==0 and len(summaries)==1
                assert summaries[0]['passed']==rec['expected_test_count']==len(named)
                assert summaries[0]['failed']==summaries[0]['ignored']==summaries[0]['measured']==0
                rust_names.extend(named)
            else:assert not summaries and not named
            commands.append({'phase':phase,'receipt_member':prefix+label+'-receipt.json',
                             'receipt_identity':identities[prefix+label+'-receipt.json'],
                             'actual_receipt':rec,'independently_counted_rust':summaries,'named_rust_tests':named})
    assert snapshot_count==12 and len(rust_names)==len(set(rust_names))==304
    assert continuation[0]['command']==initial_progress[1]['command']
    assert 'workspace-format' not in [x['label'] for x in continuation]
    clone=j(E+'target-clone-receipt.json');assert clone['exit_code']==0 and clone['command'][:2]==['/bin/cp','-cR']
    assert clone['command'][-1]==common_env['CARGO_TARGET_DIR']
    assert 'cached' in clone['scope']
    assert raw(E+'parent-head-before.stdout')==raw(E+'parent-head-after.stdout')==b'ff458bc591b4e7e444af4464d6eef2513cdb335c\n'

    reference={n[len(PREP+'reference/'):]:v for n,v in identities.items() if n.startswith(PREP+'reference/')}
    assert len(reference)==1095 and set(reference)==set(source['complete_inputs'])
    ref_inventory=j(PREP+'reference-inventory.json')
    assert ref_inventory=={p:v['sha256'] for p,v in reference.items()}==source['complete_inputs']
    for p,v in reference.items():
        assert all(v[k]==initial[p][k] for k in ['bytes','sha256','git_blob'])
        assert ('100755' if int(v['mode'],8)&0o111 else '100644')==initial[p]['mode']
    prep_binding=j(PREP+'source-binding.json')
    assert prep_binding['source_commit']==P and prep_binding['selected_tracked_roots']==['Cargo.toml','Cargo.lock','crates']
    assert prep_binding['build_input_worktree_clean'] is True
    compact=hashlib.sha256(json.dumps(ref_inventory,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    assert prep_binding['reference_inventory_sha256']==compact
    controls=j(PREP+'reference/crates/cc-eval/src/benchmark/ablation/mechanism_controls.json')
    assert [x['id'] for x in controls]==['local_retrieval','semantic_dense']
    prepared=j(PREP+'prepared-snapshots.json');assert prepared['compiled'] is False
    assert prepared['build']['source_commit']==P and prepared['build']['controls']==controls
    assert prepared['build']['reference_source']==actual_prepare_root+'/reference'
    factors={'none':[],'local':['local_retrieval'],'dense_only':['semantic_dense'],'hybrid':['local_retrieval','semantic_dense']}
    variants=[]
    for (name,enabled),decl in zip(factors.items(),prepared['build']['variants']):
        assert decl['id']==name and decl['enabled']==enabled and decl['source_root']==actual_prepare_root+'/sources/'+name
        variant={n[len(PREP+'sources/'+name+'/'):]:v for n,v in identities.items() if n.startswith(PREP+'sources/'+name+'/')}
        assert set(variant)==set(reference) and len(variant)==1095
        registered=j(PREP+'builds/'+name+'/source-inventory.json')
        assert registered=={p:v['sha256'] for p,v in variant.items()}
        changes=[]
        for p,ref in reference.items():
            disabled=[c for c in controls if c['path']==p and c['id'] not in enabled]
            if disabled:
                data=raw(PREP+'reference/'+p).decode()
                for control in disabled:
                    assert data.count(control['on_text'])==1
                    data=data.replace(control['on_text'],control['off_text'],1)
                want=data_identity(data.encode());changes.append(p)
                assert all(variant[p][k]==want[k] for k in ['bytes','sha256','git_blob'])
            else:assert all(variant[p][k]==ref[k] for k in ['bytes','sha256','git_blob'])
            assert variant[p]['mode']==ref['mode']
        assert decl['binary']==actual_prepare_root+'/products/'+name and decl['build_receipt']==actual_prepare_root+'/builds/'+name+'/receipt.json'
        assert PREP+'products/'+name not in identities and PREP+'builds/'+name+'/receipt.json' not in identities
        assert not any(n.startswith(PREP+'targets/'+name+'/') for n in identities)
        variants.append({'id':name,'enabled':enabled,'regular_files':len(variant),'exact_registered_replacement_paths':sorted(changes),'all_other_source_bytes_and_modes_equal_reference':True,'inventory_json':identities[PREP+'builds/'+name+'/source-inventory.json']})
    assert len(prepared['build']['variants'])==4
    generated=[n for n in identities if n.startswith(PREP) and not n.startswith(PREP+'reference/') and not n.startswith(PREP+'sources/')]
    assert sorted(n[len(PREP):] for n in generated)==sorted(['reference-inventory.json','source-binding.json','prepared-snapshots.json']+['builds/'+name+'/source-inventory.json' for name in factors])
    assert raw(C+'mechanism-four-variants-prepare-only.stdout').decode()==actual_prepare_root+'/prepared-snapshots.json\n'
    assert identities[C+'mechanism-four-variants-prepare-only.stderr']['bytes']==0
    assert PREP+'mechanism-build.json' not in identities
    assert initial['scripts/p7_mechanism_build.py']['sha256']=='48b5ade14f450eca004d07a4559af4caef2e8f0352746689c8a21b85ebc5cc76'
    terminal_path=ROOT/'P2-original-terminal-tool-observation.json';terminal=json.loads(terminal_path.read_bytes())
    item=terminal['structuredContent']['output']['items'][0]
    assert item['job_id']=='wc_job_5mvtMmV6MtTQ2mnY' and item['terminal'] is True and item['exit_code']==0 and item['command_execution_state']=='completed'
    lines=[json.loads(s) for s in item['stdout_tail'].splitlines()]
    done=lines[-1];assert done=={'all_controls_passed':4,'source_P':P,'rust_passed':304,'python_passed':0,'parent_HEAD_unchanged':'ff458bc591b4e7e444af4464d6eef2513cdb335c'}
    finished=[x for x in lines if 'finished' in x];assert len(finished)==4
    for observed,rec in zip(finished,continuation):
        assert observed['finished']==rec['label'] and observed['exit_code']==rec['exit_code'] and observed['rust_test_summaries']==rec['rust_test_summaries']

assert file_identity(ZIP)==zip_id
save('original-ZIP-member-verification.json',{'schema_version':1,'zip':zip_id,'regular_files':5554,'directories':1070,'members':6624,'expanded_bytes':105480723,'all_original_ZIP_CRC_SHA_Gitblob_and_manifest_modes_verified':True,'all_extracted_bytes_and_Git_executable_modes_match':True,'current_extracted_nonexec_permission_differences':extracted_permission_differences,'rows':member_rows})
save('command-and-test-identity-verification.json',{'schema_version':1,'source_P2':P,'tree':TREE,'commands':commands,'actual_Rust_tests':304,'unique_test_names':304,'initial_compile_failure_executed_Rust_tests':0,'snapshots_verified':12,'first_snapshot_size':1250,'continuation_snapshot_size':1256,'common_recorded_environment':common_env,'target_clone':clone,'six_added_original_input_rows':[expanded[x] for x in added],'source_map':source_id,'native_terminal':file_identity(terminal_path)})
report={
 'schema_version':1,'reviewer':'/root/pr_triage','verdict':'accepted_scoped_actual_P2_focused_engineering_and_prepare_only_with_initial_failure_preserved',
 'source_P2':P,'tree':TREE,'ordered_parents':PARENTS,'scope':'Independent read-only byte/receipt/source/stdio review; no original test, compiler, validator or measurement rerun.',
 'original_zip':zip_id,'archive_counts':{'members':6624,'regular_files':5554,'directories':1070,'expanded_bytes':105480723},
 'extracted_copy_permission_observation':{'differences':extracted_permission_differences,'boundary':'Original ZIP/manifest retain full original permissions, and all extracted bytes match. One current extracted copy differs only in group-write permission; no original ZIP or extracted file was edited by this reviewer. Source Git mode is normalized by executable bits (100644/100755), not by concatenating full POSIX permission digits.','initial_audit_failure':'First helper invocation stopped on an over-strict extracted full-POSIX-mode assertion before writing any acceptance. The first helper is preserved; corrected review records actual copy permissions and verifies original ZIP modes separately. No original execution failed here.'},
 'actual_source_audit':source_id,'source_domain':{'products':1095,'validation':142,'historical_BASE_delta':70,'native_initial_selected':1250,'native_continuation_selected':1256,'original1250_unchanged':True,'six_added_original_inputs':added,'before_after_snapshots_verified':12,'input_entry_arrays_unchanged_within_each_command':True,'whole_snapshot_files_byte_identical_claimed':False},
 'first_attempt':{'format_exit':0,'cc_search_compile_exit':101,'Rust_tests_executed':0,'cause_supported_by_original_stderr':'Five missing include_str! artifact paths; compiler stopped before the 303-test binary could execute. This is an input-preparation compilation failure, not303 failed tests.','remaining_anchor_clippy_prepare':'not started in first attempt','error_original':identities[E+'new-lane-query-policy-lib-controls.stderr']},
 'same_P2_continuation':{'checkout_six_original_inputs_exit':0,'original_four_child_exits':[0,0,0,0],'cc_search_lib_passed':303,'cc_eval_mechanism_anchor_passed':1,'Rust_failed':0,'Rust_ignored':0,'Rust_unique_passed':304,'strict_clippy_scope':'cc-search and cc-eval --all-targets --locked --offline -- -D warnings','format_pass_not_repeated':True,'command_identity_detail':file_identity(OUT/'command-and-test-identity-verification.json')},
 'actual_prepare_only':{'exit_code':0,'started_at':continuation[-1]['started_at'],'ended_at':continuation[-1]['ended_at'],'elapsed_seconds':continuation[-1]['elapsed_seconds'],'compiled':False,'reference_regular_files':1095,'variants':variants,'source_regular_files_total':5475,'metadata_JSON_files':7,'regular_files_total':5482,'source_binding':prep_binding,'canonical_compact_reference_inventory_SHA256':compact,'full_reference_mode_blob_SHA_equal_actual_P2_products':True,'four_variant_exact_changes_and_all_other_bytes_checked':True,'no_binary_build_receipts_or_compiler_logs_or_final_mechanism_build_manifest':True,'future_binary_receipt_strings_not_execution_credit':True},
 'execution_environment':{'recorded_common_environment':common_env,'ordinary_APFS_cloned_cached_target':clone,'native_terminal':file_identity(terminal_path),'continuation_job':'wc_job_5mvtMmV6MtTQ2mnY','parent_HEAD_confirmed_by_original_controller_terminal':done['parent_HEAD_unchanged'],'original_packager_version':'v1 18581bytes SHA7e40723dfc52373016c0ba9cd4784b57e0300bb6fd9f18ec2eed9bb2c57efc1c; later unexecuted v2 is not used or credited'},
 'boundaries':['Initial fmt0/compile101 originals and original1250 baseline remain failures/preparation history; only the unchanged actualP2 with six declared immutable inputs added has the successful continuation.','P2 has304 successful Rust tests here. No priorP1 60 Rust/77Python results, G1 source admission, or G1 C1 workload results are relabeled as P2 executions.','The selected source/validation domain is verified; this is not whole repository checkout cleanliness or a full workspace test/Clippy gate.','prepare-only materializes five complete source trees and registers exact on/off source controls. It performs no four-variant compilation, ABBA run, measurement or full ablation acceptance.','The dependency fetch in prior-input-and-fetch-bridge is the older actualP0 invocation with unchanged lock/manifests. It remains old-source fetch evidence; no newP2 fetch is invented.','Cached APFS target and recorded durations do not establish cold or performance results.','P2 original source admission under newly bound R2/G2 remains a separate later action; existing G1 binding bytes are not newP2 admission.','No original TODO, DB-wait four-cell closure or scale-study completion is granted by this execution review.'],
 'unresolved_blockers_within_this_focused_scope':[], 'task_ledger_unchanged':{'done':163,'remaining':29,'newly_completed':0}}
save('independent-P2-native-execution-review.json',report)
paths=[OUT/'independent-P2-native-execution-review.json',OUT/'command-and-test-identity-verification.json',OUT/'original-ZIP-member-verification.json',Path(__file__)]
selection={'schema_version':1,'file_count':len(paths),'total_bytes':sum(p.stat().st_size for p in paths),
 'files':[{'local_path':str(p),'repository_path':'review-pr/round16-P2-native-execution-peer/'+p.name,**{k:v for k,v in file_identity(p).items() if k!='path'}} for p in paths],
 'original_zip_reference':zip_id,'outside_selection_source_audit':source_id,'outside_selection_native_terminal':file_identity(terminal_path),
 'scope':'Minimum independent peer evidence only; retain original ZIP at its fixed Git blob rather than duplicating it here.'}
save('archive-selection.json',selection)
for name in ['independent-P2-native-execution-review.json','archive-selection.json']:print(json.dumps(file_identity(OUT/name)))
