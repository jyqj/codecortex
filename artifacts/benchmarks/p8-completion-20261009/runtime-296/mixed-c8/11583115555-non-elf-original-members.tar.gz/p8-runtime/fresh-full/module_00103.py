def stable_00103():
    return 103
