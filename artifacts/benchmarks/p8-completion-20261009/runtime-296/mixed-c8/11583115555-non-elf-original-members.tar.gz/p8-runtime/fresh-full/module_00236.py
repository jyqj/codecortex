def stable_00236():
    return 236
