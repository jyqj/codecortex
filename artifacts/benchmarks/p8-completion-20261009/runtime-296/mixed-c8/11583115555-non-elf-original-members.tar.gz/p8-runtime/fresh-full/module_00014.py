def stable_00014():
    return 14
