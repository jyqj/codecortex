def stable_00181():
    return 181
