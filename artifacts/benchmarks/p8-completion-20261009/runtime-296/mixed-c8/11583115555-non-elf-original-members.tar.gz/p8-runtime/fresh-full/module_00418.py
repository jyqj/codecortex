def stable_00418():
    return 418
