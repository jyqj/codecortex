import ast, datetime, difflib, hashlib, json, pathlib
ROOT=pathlib.Path('/workspace/scratch/bfccb8494ba0')
OUT=ROOT/'scale-intake-primary/installed-db-acquisition-R-G-review'
NEW=pathlib.Path('/dev/shm/todo-audit-p8007-lock-observation-review/G51d5binding')
OLD=pathlib.Path('/dev/shm/todo-audit-pr180-generated-G-f89d5fee/staged')
def load(p):return json.loads(p.read_text())
def ident(p):
 d=p.read_bytes();return {'path':str(p),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()}
def tree_hash(items):
 raw=b''.join(x['mode'].lstrip('0').encode()+b' '+x['path'].encode()+b'\0'+bytes.fromhex(x['sha']) for x in sorted(items,key=lambda x:(x['path']+('/' if x['type']=='tree' else '')).encode()))
 return hashlib.sha1(b'tree '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
Rpath=ROOT/'scale-intake-primary/db-wait-cleanup-P-bb29-independent/independent-source-review.json'
R=load(Rpath)
old_registry=load(OLD/'scripts/reviewed-source-registry-v15.json');registry=load(NEW/'scripts/reviewed-source-registry-v15.json')
changed=sorted(k for k in old_registry.keys()|registry.keys() if old_registry.get(k)!=registry.get(k))
assert changed==sorted(['complete_inputs','delta','product_source','review_sha256','review_source','validation_inputs'])
assert registry['complete_inputs']==R['complete_inputs'] and registry['delta']==R['paths'] and registry['validation_inputs']==R['validation_inputs']
assert registry['product_source']==R['source']=='bb290be2deaf4334863e09dbf47fe4ccc9625f2b'
assert registry['review_source']=='51d5ed91e14ddb13eccb93ebd28311a3235075cc'
assert registry['review_sha256']==ident(Rpath)['sha256']
old_guard=(OLD/'scripts/verify_reviewed_source_v15.py').read_text();guard=(NEW/'scripts/verify_reviewed_source_v15.py').read_text()
pins=['PRODUCT','REVIEW','REVIEW_PATH','REGISTRY_SHA256']
strip=lambda s:'\n'.join(line for line in s.split('\n') if not any(line.startswith(pin+' = ') for pin in pins))
assert strip(old_guard)==strip(guard)
def values(s):
 return {n.targets[0].id:ast.literal_eval(n.value) for n in ast.parse(s).body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in pins}
pin_values=values(guard)
assert pin_values=={'PRODUCT':R['source'],'REVIEW':registry['review_source'],'REVIEW_PATH':'artifacts/checkpoints/p8-db-acquisition-cleanup-bfcc-20261009/independent-source-review.json','REGISTRY_SHA256':ident(NEW/'scripts/reviewed-source-registry-v15.json')['sha256']}
request=load(NEW/'create-tree-request.json');assert request['base_tree']=='580814d03f9c32215811632040f00cef29384ec7' and len(request['tree_elements'])==2
old_snapshot=load(ROOT/'root-round15/native-controls-transfer/extracted/P1-controls/workspace-format-input-before.json')
entries={x['path']:x for x in old_snapshot['entries']}
for e in request['tree_elements']:
 p=e['path'];assert p in ['scripts/verify_reviewed_source_v15.py','scripts/reviewed-source-registry-v15.json']
 assert e['mode']=='100644' and e['type']=='blob' and ident(NEW/p)['git_blob']==e['sha']
 assert ident(OLD/p)['sha256']==entries[p]['sha256'] and ident(OLD/p)['git_blob']==entries[p]['git_blob']
cached=load(pathlib.Path('/dev/shm/todo-audit-p8007-lock-observation-review/actual-P-review-inputs/actual-P-complete-derived-Git-tree.json'))
items={x['path']:x for x in cached['tree']}
scripts=[{k:(path[len('scripts/'): ] if k=='path' else e[k]) for k in ['path','mode','type','sha']} for path,e in items.items() if path.startswith('scripts/') and '/' not in path[len('scripts/'):]]
assert tree_hash(scripts)==items['scripts']['sha']
for e in request['tree_elements']:
 name=e['path'][len('scripts/'):]
 scripts=[x for x in scripts if x['path']!=name]+[{**e,'path':name}]
script_tree=tree_hash(scripts)
Rroot=load(ROOT/'root-round15/final-R-official-read-2.json')
assert next(x['sha'] for x in Rroot['tree'] if x['path']=='scripts')==items['scripts']['sha']
expected_root=[x for x in Rroot['tree'] if x['path']!='scripts']+[{'path':'scripts','mode':'040000','type':'tree','sha':script_tree}]
Gtree=tree_hash(expected_root)
manifest=load(NEW/'two-file-manifest.json')
assert Gtree==manifest['expected_G_tree']=='23f0f69fef9d62229fd947e7747aefdfea78d024'
assert script_tree==manifest['expected_scripts_subtree']=='6c114bfb6ef13463593b3f7a8af90672a1109dea'
diff=''.join(difflib.unified_diff(old_guard.splitlines(True),guard.splitlines(True),fromfile='exact-P1-v15',tofile='prospective-G-v15'))
with (OUT/'G-four-pin.diff').open('x') as f:f.write(diff)
result={'schema_version':1,'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/execution_recon','verdict':'accepted_scoped_two_binding_files_only','actual_G':None,'actual_parent_R':registry['review_source'],'parent_R_tree':Rroot['sha'],'expected_G_tree':Gtree,'expected_scripts_tree':script_tree,'counts':{'product':1095,'validation':142,'delta':67},'guard_changed_pins':pin_values,'all_guard_bytes_other_than_four_pin_lines_equal_exact_P1':True,'registry_only_changed_fields':changed,'registry_maps_equal_actual_independent_R':True,'files':[ident(NEW/e['path']) for e in request['tree_elements']],'original_P1_bindings_authenticated_by_actual1250_snapshot':True,'protected_source_validation_tree_content_unchanged':True,'source_admission_executed':False,'TODO_or_workload_credit':False,'canonical_R':ident(Rpath),'tree_request':ident(NEW/'create-tree-request.json'),'expected_G_root_recomputed_from_exact_R_and_only_two_blob_replacements':True}
p=OUT/'independent-two-G-bindings-review.pending-actual-G.json'
with p.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(ident(p)))
