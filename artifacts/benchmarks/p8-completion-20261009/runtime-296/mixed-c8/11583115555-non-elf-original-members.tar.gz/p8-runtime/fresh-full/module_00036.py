def stable_00036():
    return 36
