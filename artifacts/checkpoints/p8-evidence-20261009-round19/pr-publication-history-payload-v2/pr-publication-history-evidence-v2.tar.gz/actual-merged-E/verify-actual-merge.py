from pathlib import Path
import json,hashlib,datetime
P=Path('/dev/shm/a217aaae3bde/platform-review/round19-actual-E-merge')
def read(n):return json.loads((P/n).read_text())
def capture(prefix):
 files=[p for p in P.glob(prefix+'-*.json') if p.name[len(prefix)+1:-5].isdigit()];assert len(files)==1;return json.loads(files[0].read_text())['data']
def tree(es):
 b=b''.join(e['mode'].lstrip('0').encode()+b' '+e['path'].encode()+b'\0'+bytes.fromhex(e['sha']) for e in sorted(es,key=lambda e:(e['path']+('/' if e['type']=='tree' else '')).encode()));return hashlib.sha1(b'tree '+str(len(b)).encode()+b'\0'+b).hexdigest()
def inv(n):return {e['path']:{k:e[k] for k in ['path','mode','type','sha']} for e in read(n)['tree']}
c=capture('merge');assert c['sha']=='b21cce4c8661589267ad5719f850accbec088d2f';assert [x['sha'] for x in c['parents']]==['4775bf44dc09c11cea88211e06ccec97c4de44aa','a23bb72d3c954f385b99fe81ce9189885c208557']
obj=(P/'actual-merge-commit-object.txt').read_bytes();assert hashlib.sha1(b'commit '+str(len(obj)).encode()+b'\0'+obj).hexdigest()==c['sha']
checks=[]
for n in ['M-root','E-root','parent-main-root','M-artifacts','E-artifacts','parent-main-artifacts','M-checkpoints','E-checkpoints','parent-main-checkpoints']:
 d=read(n+'.json');assert d['truncated'] is False
 expected=read('parent-main-commit.json')['tree']['sha'] if n=='parent-main-root' else d['sha'];assert tree(d['tree'])==expected
 checks.append({'path':n+'.json','tree_sha':expected,'entries':len(d['tree'])})
a=inv('M-root.json');e=inv('E-root.json');assert a.keys()==e.keys() and [k for k in a if a[k]!=e[k]]==['artifacts']
for n in ['E-artifacts.json','parent-main-artifacts.json']:
 other=inv(n);m=inv('M-artifacts.json');assert m.keys()==other.keys() and [k for k in m if m[k]!=other[k]]==['checkpoints']
m=inv('M-checkpoints.json');e=inv('E-checkpoints.json');old=inv('parent-main-checkpoints.json');assert len(m)==191 and len(e)==len(old)==190
assert all(m[k]==v for k,v in e.items()) and all(m[k]==v for k,v in old.items());assert m=={**old,**e}
for n,count in [('preserved-main-archive-recursive',188),('preserved-E-review-recursive',15)]:
 d=read(n+'.json');assert d['truncated'] is False and sum(x['type']=='blob' for x in d['tree'])==count
 for par,oid in [('',d['sha'])]+[(x['path'],x['sha']) for x in d['tree'] if x['type']=='tree']:
  kids=[{**x,'path':Path(x['path']).name} for x in d['tree'] if ('' if str(Path(x['path']).parent)=='.' else str(Path(x['path']).parent))==par];assert tree(kids)==oid
assert capture('main')['object']['sha']==c['sha']
pr=capture('pr167');assert pr['merged'] is True and pr['state']=='closed' and pr['merge_commit_sha']==c['sha'] and pr['head']['sha']=='a23bb72d3c954f385b99fe81ce9189885c208557'
runs=capture('runs');assert runs['total_count']==len(runs['workflow_runs'])==5 and read('runs-page2.json')['workflow_runs']==[]
assert all(x['head_sha']==c['sha'] and x['event']=='push' for x in runs['workflow_runs'])
result={'schema':'actual-E-engineering-merge-independent-proof-v1','reviewer':'/root/pr_audit','decision':'accepted_scoped_actual_merge_identity_and_input_preservation','captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_merge':c['sha'],'actual_tree':c['tree']['sha'],'parents':[x['sha'] for x in c['parents']],'fresh_main_and_PR_merged_confirmed':True,'signed_commit_object_reconstructed_Git_SHA_matches':True,'signed_commit_object_sha256':hashlib.sha256(obj).hexdigest(),'all_nonartifacts_root_entries_equal_E':True,'nonartifacts_entries':{k:v for k,v in a.items() if k!='artifacts'},'input_applicability':'Entire crates/Cargo and scripts/tests/.github subtree mode/OID equality to fixed E preserves all 1087 product, 138 validation, nine observer and exact current/historical guard bytes. No native measurement rerun or relabel.','artifacts_union':{'all_four_other_artifact_subtrees_equal_both_parents':True,'parent_main_checkpoint_siblings':190,'E_checkpoint_siblings':190,'merged_exact_union_siblings':191,'all_parent_siblings_preserved':True,'parent_main_independent_archive':{'tree':'9218884b59000ecc9a7cf82bbeb6157d229bf250','files':188},'E_source_review_archive':{'tree':'c83502258af470f5027149fec4d727779823b3a1','files':15}},'tree_hash_recomputations':checks,'new_actual_main_push_runs':[{'id':x['id'],'name':x['name'],'head_sha':x['head_sha'],'event':x['event'],'status_at_capture':x['status'],'conclusion_at_capture':x['conclusion']} for x in runs['workflow_runs']],'old_execution_identities_retained':{'P8_measurements':'a23bb72d3c954f385b99fe81ce9189885c208557','CI_and_engineering_actual_checkout':'75649f8cb08dcd5427e7e58b1ca2b8fa67c9d037','new_main_results':'separate runs above; not yet accepted from metadata'},'scale_original_run_preserved':37872522779,'native_or_guard_executions':0,'remote_mutations':False,'formal_task_completion':False,'counts':{'done':163,'remaining':29,'newly_completed':0},'unresolved_blockers':[]}
f=P/'independent-review.json';f.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');b=f.read_bytes();print(json.dumps({'path':str(f),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}))
