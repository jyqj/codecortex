def stable_00381():
    return 381
