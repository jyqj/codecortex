import json,hashlib,datetime,sys
from pathlib import Path
payload=json.loads(sys.stdin.read())
base=Path.cwd()
study=base/"published-preparation"
out=base/"actual-run-37902429727"
out.mkdir(exist_ok=False)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def put(name,obj):
 p=out/name
 with p.open("x") as f: json.dump(obj,f,indent=2,ensure_ascii=False); f.write("\n")
 return p
raw=payload["body"].encode("utf-8")
with (out/"run-initial.raw.json").open("xb") as f:f.write(raw)
r=json.loads(raw)
G="c8be5afaac568ffd40ef86d3795423c3b73c9f39"
expected={"id":37902429727,"head_sha":G,"run_attempt":1,"event":"workflow_dispatch","head_branch":"task/p8-combined-engineering-bfcc-20261009","path":".github/workflows/p8-scale.yml"}
assert all(r.get(k)==v for k,v in expected.items()),"Unexpected actual run identity"
assert r["head_commit"]["tree_id"]=="9b031be22a430e51e153cce6e80770ed885818e3"
pre=study/"study-registration.public-G-pre-dispatch.json"
assert sha(pre)=="e0886c66c25b70d34df068eaa6a17615388a8d98e6718ceb0adb3cc2cb68b561"
receiver=study/"intake_once.v2.py"
assert sha(receiver)=="61f4ae48bc84dbc9f90862a80d06a8268ec4aa93f83c75582b716bc32f4c3369"
pending=study/"receiver-binding.public-G-pending-run.json"
assert sha(pending)=="2054c711546d35611cc12af3c6091292416f7b265b77bb92700b5dd73c1740eb"
b=json.loads(pending.read_text()); assert b["source_G"]==G and b["run_id"] is None
b.update(run_id=r["id"],status="actual_original_run_bound",run_binding_basis="official GET metadata; root reported one dispatch; native dispatch integer exit remains unknown here")
put("receiver-binding.actual-run.json",b)
put("primary-execution-context.json",{"platform":__import__("platform").platform(),"python":sys.version,"primary_root":str(base),"mac_writer_result":"404 tunnel_client_not_connected without job ID; write success unverified; no receiver/download was submitted","this_action":"Append metadata/registration only; no native benchmark, CLI, ZIP transfer, dispatch, or rerun","receiver_unchanged":True,"native_cli_path_is_mac_specific":True,"next_transport":"Use authenticated GitHub artifact download connector if necessary; validate actual bytes through unchanged v2 pure validation functions; preserve transport implementation distinction"})
put("run-initial-receipt.json",{"method":"GET","url":payload["url"],"observed_at":payload["observed_at"],"source":"GitHub connector unchanged structuredContent.content","bytes":len(raw),"sha256":sha(out/"run-initial.raw.json"),"expected":expected,"all_expected_identity_fields_equal":True,"actual_status":r["status"],"actual_conclusion":r["conclusion"],"queued_is_not_running_or_measurement_success":True})
registration={"version":1,"status":"original_study_dispatched_and_actual_run_bound","created_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"source_G":G,"source_tree":r["head_commit"]["tree_id"],"review_R":"a9706a90a72226cb59c3bfd374ef9c1e3d66cbcb","product_P":"35a7b3412e5fdee9e8ff88951735c06b0e371465","run":{k:r[k] for k in ["id","html_url","run_attempt","event","head_branch","head_sha","path","created_at","status","conclusion"]},"preregistered_protocol":{"path":str(pre.relative_to(base)),"bytes":pre.stat().st_size,"sha256":sha(pre),"public_archive_commit":"7e37aad7f347598b77d76c060ce154ce55d8eb94","all_original_parameters_unchanged":True},"receiver":{"path":str(receiver.relative_to(base)),"sha256":sha(receiver),"binding":str((out/"receiver-binding.actual-run.json").relative_to(base))},"dispatch":{"owner":"root","reported_requests":1,"native_job":"wc_job_vtXvZKR3sbt5-k0C","native_exit_code":None,"native_exit_evidence":"not yet supplied; official actual run existence is independently verified","receiver_dispatched":False},"acceptance":{"accepted_shards":0,"accepted_native_samples":0,"new_original_todo_completions":0,"transport_is_not_semantic_validation":True},"preservation":"All pending/public pre-dispatch files and failed prior studies preserved unchanged."}
put("study-registration.actual-run.json",registration)
files=[]
for p in sorted(out.iterdir()):
 if p.is_file():files.append({"path":str(p.relative_to(base)),"bytes":p.stat().st_size,"sha256":sha(p)})
selection=put("actual-run-selection.json",{"version":1,"scope":"Actual original run binding only; no new execution or acceptance gate","files":files,"file_count":len(files),"total_bytes":sum(x["bytes"] for x in files)})
print(json.dumps({"selection":str(selection.relative_to(base)),"bytes":selection.stat().st_size,"sha256":sha(selection),"files":files,"binding":str((out/"receiver-binding.actual-run.json").relative_to(base))}))
