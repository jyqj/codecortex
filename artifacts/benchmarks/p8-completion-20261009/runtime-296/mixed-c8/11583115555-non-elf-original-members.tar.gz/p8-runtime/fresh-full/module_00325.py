def stable_00325():
    return 325
