import ast,hashlib,json,pathlib,re,subprocess,datetime,os
base=pathlib.Path(__file__).resolve().parent;repo=base/'source';records=base/'history-prep';records.mkdir(exist_ok=False)
def run(args,data=None):
 n=len(list(records.glob('*.receipt.json')))+1;pfx=records/f'{n:04d}';start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p=subprocess.run(['git',*args],input=data,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=240)
 pfx.with_suffix('.stdout').write_bytes(p.stdout);pfx.with_suffix('.stderr').write_bytes(p.stderr)
 pfx.with_suffix('.receipt.json').write_text(json.dumps({'argv':['git',*args],'stdin_sha256':hashlib.sha256(data).hexdigest() if data else None,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()},indent=2)+'\n')
 if p.returncode:print(p.stderr.decode(errors='replace'),flush=True);raise SystemExit(p.returncode)
 return p.stdout
refs=set();prefixes=('verify_current_source','verify_reviewed_source','verify_historical_integrations','v14_historical','v15_historical','p0_historical')
for p in (repo/'scripts').glob('*.py'):
 if p.name.startswith(prefixes):
  for n in ast.walk(ast.parse(p.read_text())):
   if isinstance(n,ast.Constant) and isinstance(n.value,str) and re.fullmatch('[0-9a-f]{40}',n.value):refs.add(n.value)
(base/'declared-script-ref-list.json').write_text(json.dumps(sorted(refs),indent=2)+'\n')
print('fetch declared refs',len(refs),flush=True)
run(['fetch','--no-tags','--filter=blob:none','origin',*sorted(refs)])
print('refs fetched',flush=True)
# The only current extra materialization derives from original v15 catalogue rules.
sysrc=(repo/'scripts/v15_historical_context.py').read_text();parsed=ast.parse(sysrc);const={}
for n in parsed.body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
  try:const[n.targets[0].id]=ast.literal_eval(n.value)
  except (ValueError,TypeError):pass
ref=const['HISTORICAL_HEAD'];records_paths=set(const['EXPLICIT_RECORDS'])
def valid(path):
 assert isinstance(path,str) and path and not path.startswith('/') and '\\' not in path and all(p not in ('','.','..','.git') for p in path.split('/'))
 assert path in const['EXPLICIT_RECORDS'] or not re.search('hold[-_]?out|held[-_]?out',path,re.I),path
 return path
for path in const['REGISTRIES']:
 reg=json.loads(run(['show',f'{ref}:{path}']))
 records_paths.update(reg.get('records',{}));records_paths.update(r['review_path'] for r in reg.get('deltas',{}).values())
rows=run(['ls-tree','-r','-z',ref,'--',*const['VALIDATION_ROOTS']]);names=set()
for row in rows.split(b'\0'):
 if row:names.add(valid(row.split(b'\t',1)[1].decode()))
names.update(valid(p) for p in records_paths)
protected=records_paths|{p for p in names if p.startswith(('tests/source_integrity/','scripts/source_snapshots/')) or (p.startswith('scripts/') and pathlib.Path(p).name.startswith(('verify_','current-source-','reviewed-source-','v14_historical_'))) or p=='scripts/p0_historical_corpus.py'}
assert len(protected)==236,(len(protected),len(names))
(base/'original-history-catalogue-paths.json').write_text(json.dumps({'base':ref,'names':sorted(names),'protected':sorted(protected)},indent=2)+'\n')
pattern=repo/'.git/info/sparse-checkout';old=pattern.read_text();pattern.write_text(old+''.join('/'+p+'\n' for p in sorted(protected) if '/'+p+'\n' not in old))
run(['read-tree','-mu','HEAD'])
# List and hydrate only original catalogue inputs at both fixed historical contexts.
extra_refs=set();objects={};catalogues={}
for helper in ['v15_historical_context.py','v14_historical_context.py']:
 module=ast.parse((repo/'scripts'/helper).read_text());c={}
 for n in module.body:
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
   try:c[n.targets[0].id]=ast.literal_eval(n.value)
   except (ValueError,TypeError):pass
 ref=c['HISTORICAL_HEAD']; paths=set(c['EXPLICIT_RECORDS'])
 tree={}
 for row in run(['ls-tree','-r','-z',ref]).split(b'\0'):
  if row:
   meta,path=row.split(b'\t',1);mode,kind,oid=meta.decode().split();tree[path.decode()]={'mode':mode,'type':kind,'git_oid':oid}
 for p in c['REGISTRIES']:
  r=json.loads(run(['show',ref+':'+p]));paths.update(r.get('records',{}));paths.update(v['review_path'] for v in r.get('deltas',{}).values())
  for value in re.findall(r'"([0-9a-f]{40})"',json.dumps(r)):extra_refs.add(value)
 paths.update(p for p in tree if p.startswith(tuple(x+'/' for x in c['VALIDATION_ROOTS'])))
 for p in paths:
  assert p in c['EXPLICIT_RECORDS'] or not re.search('hold[-_]?out|held[-_]?out',p,re.I),p
  objects[tree[p]['git_oid']]=p
 catalogues[ref]=sorted(paths)
for start in range(0,len(objects),200):
 batch=sorted(objects)[start:start+200];run(['fetch','--no-tags','--filter=blob:none','origin',*batch])
print('original catalogue objects hydrated',len(objects),flush=True)
(base/'historical-catalogues-and-objects.json').write_text(json.dumps({'catalogues':catalogues,'objects':objects,'additional_registry_refs':sorted(extra_refs)},indent=2)+'\n')
