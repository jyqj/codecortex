def stable_00150():
    return 150
