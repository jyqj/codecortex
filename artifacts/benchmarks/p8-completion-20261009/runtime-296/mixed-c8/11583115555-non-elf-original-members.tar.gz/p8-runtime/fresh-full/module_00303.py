def stable_00303():
    return 303
