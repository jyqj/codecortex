#!/usr/bin/env python3
"""Read-only review of one newly created archive expansion; never unlinks."""
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import zipfile
import zlib

OUT = Path(__file__).resolve().parent
PLAN = Path('/dev/shm/p8-G4-lifecycle-expansion-reclaim-root/plan.json')
PLAN_SHA = '570a03e01ff434c8fa11fbbb66fc3a914bda0657ed33fda772fa289900f76d19'
TARGET = Path('/workspace/scratch/2eaa00d0f93a/p8-formal-evidence-G4/lifecycle/files')
ARCHIVE = TARGET.parent / 'original-artifact.zip'
ZIP_SHA = '81756f7d1990147961c87f905625c33da69b57d703f8eb4afa7e0f690ca52c31'

def require(value, message):
    if not value:
        raise ValueError(message)

def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def identity(path):
    s = path.lstat()
    return dict(allocated_bytes=s.st_blocks * 512, bytes=s.st_size,
                device=s.st_dev, gid=s.st_gid, inode=s.st_ino, links=s.st_nlink,
                mode=s.st_mode, mtime_ns=s.st_mtime_ns, uid=s.st_uid)

def scan(root):
    dirs = {'.': identity(root)}
    files = {}
    for current, child_dirs, child_files in os.walk(root, followlinks=False):
        for name in child_dirs:
            path = Path(current) / name
            value = identity(path)
            require(stat.S_ISDIR(value['mode']), 'non-directory below exact target')
            dirs[path.relative_to(root).as_posix()] = value
        for name in child_files:
            path = Path(current) / name
            value = identity(path)
            require(stat.S_ISREG(value['mode']), 'nonregular below exact target')
            files[path.relative_to(root).as_posix()] = value
    return dirs, files

def kept_inventory():
    result = {}
    for root, dirs, files in os.walk(TARGET.parent, followlinks=False):
        if Path(root) == TARGET.parent:
            dirs.remove('files')
        for name in dirs:
            require(not (Path(root) / name).is_symlink(), 'aliased kept directory')
        for name in files:
            path = Path(root) / name
            value = identity(path)
            require(stat.S_ISREG(value['mode']), 'nonregular kept file')
            result[path.relative_to(TARGET.parent).as_posix()] = value | {'sha256': digest(path)}
    return result

def main():
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    require(digest(PLAN) == PLAN_SHA, 'plan pin changed')
    plan = json.loads(PLAN.read_bytes())
    require(plan['target'] == str(TARGET) and plan['zip_to_keep'] == str(ARCHIVE), 'wrong exact paths')
    require(plan['zip_sha256'] == ZIP_SHA and plan['TODO_newly_completed'] == 0 and plan['TODO_remaining'] == 29, 'identity or scope changed')
    for path in (TARGET, *TARGET.parents):
        require(stat.S_ISDIR(path.lstat().st_mode), 'aliased/non-directory target ancestor')
    require(TARGET not in ARCHIVE.parents, 'original ZIP in deletion scope')
    keep_before = kept_inventory()
    require(identity(ARCHIVE) == plan['zip_identity'] and digest(ARCHIVE) == ZIP_SHA, 'original ZIP mismatch')
    for key in ('original_receiver', 'existing_acceptance_review'):
        path = Path(plan[key]['path'])
        require(TARGET not in path.parents and digest(path) == plan[key]['sha256'], 'protected original receipt mismatch')
    expected = json.loads((TARGET.parent / 'expected-artifact.json').read_bytes())
    require(expected['sha256'] == ZIP_SHA and expected['members'] == 2391 and expected['bytes'] == 49348679 and expected['expanded_bytes'] == 372943883, 'original transport counts differ')
    require(expected['source'] == '260f596582f2d82b8d7c707b61a6b8b6a43b069f' and expected['run_id'] == 37854847926 and expected['job_id'] == 113576451817 and expected['artifact_id'] == 11585181176 and expected['run_attempt'] == 1, 'original G4 provenance differs')
    for relative, value in expected['metadata_sha256'].items():
        require(digest(TARGET.parent / relative) == value, 'original API metadata differs')
    original_members = json.loads((TARGET.parent / 'member-hashes.json').read_bytes())
    dirs_before, files_before = scan(TARGET)
    require(dirs_before == plan['directories'] and dirs_before['.'] == plan['target_identity'], 'directory inode set differs')
    require(set(files_before) == set(plan['files']), 'file set differs')
    for name, value in files_before.items():
        expected_file = {k: plan['files'][name][k] for k in value}
        require(value == expected_file and value['links'] == 1 and value['device'] == dirs_before['.']['device'], 'file inode/identity differs')
    seen = set()
    with zipfile.ZipFile(ARCHIVE) as archive:
        require(len(archive.infolist()) == 2391, 'ZIP member population differs')
        for item in archive.infolist():
            name = PurePosixPath(item.filename)
            require(str(name) == item.filename and not name.is_absolute() and '..' not in name.parts and '\\' not in item.filename and not item.is_dir() and stat.S_ISREG(item.external_attr >> 16) and item.filename not in seen, 'noncanonical/nonregular/duplicate ZIP member')
            seen.add(item.filename)
            row = plan['files'][item.filename]
            count, crc, sha = 0, 0, hashlib.sha256()
            with archive.open(item) as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    count += len(block); crc = zlib.crc32(block, crc); sha.update(block)
            require(count == item.file_size == row['bytes'] and crc & 0xffffffff == item.CRC == row['zip_crc32'] and item.external_attr >> 16 == row['zip_mode'], 'ZIP stream size/CRC/mode differs')
            require(sha.hexdigest() == row['sha256'] == digest(TARGET / item.filename), 'ZIP/plan/current file bytes differ')
            require(original_members[item.filename] == {'bytes': count, 'sha256': sha.hexdigest(), 'crc32': f'{item.CRC:08x}'}, 'original received member receipt differs')
    require(seen == set(plan['files']) == set(original_members), 'bidirectional member set differs')
    require(sum(r['bytes'] for r in files_before.values()) == plan['expanded_bytes'] == 372943883, 'expanded bytes differ')
    require(sum(r['allocated_bytes'] for r in files_before.values()) == plan['expanded_allocated_bytes'] == 380137472, 'allocated file bytes differ')
    require(scan(TARGET) == (dirs_before, files_before), 'inode inventory changed while independently reading')
    require(identity(ARCHIVE) == plan['zip_identity'] and digest(ARCHIVE) == ZIP_SHA, 'protected original ZIP changed')
    require(kept_inventory() == keep_before and digest(PLAN) == PLAN_SHA, 'protected sibling originals changed')
    with (OUT / 'protected-sibling-inventory.json').open('x') as f:
        json.dump(keep_before, f, sort_keys=True, indent=2); f.write('\n')
    result = dict(schema='independent-owned-expansion-reclaim-plan-v1', status='accepted_scoped_plan_pending_executor_review', started_utc=started, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), reviewer='/root/pr_audit', plan_sha256=PLAN_SHA,
                  target=str(TARGET), target_inode=dirs_before['.']['inode'], target_device=dirs_before['.']['device'], regular_single_link_files=2391, directories_including_target=len(dirs_before), expanded_bytes=372943883, allocated_file_bytes=380137472,
                  original_zip=str(ARCHIVE), original_zip_sha256=ZIP_SHA, original_zip_bytes=49348679, full_original_zip_stream_crc_sha_and_live_bytes_equal=True, complete_live_inode_inventory_equal_before_after=True,
                  protected_sibling_files=len(keep_before), protected_sibling_inventory_sha256=digest(OUT/'protected-sibling-inventory.json'),
                  ownership_evidence='Pinned original receive_archive.py requires absent files directory, creates it, and exclusively writes all members. Pinned expected-artifact/member-hashes and successful original inspection match the live expansion and preserved ZIP.',
                  conditions=['Only this exact receiver-created expansion may be reclaimed after separately reviewed enumerated executor rechecks this pinned plan and all live identities.','Keep original ZIP, original API metadata, logs, source and reviews; no old native measurement workspace or other directory included.','No claim that cleanup or additional product testing has executed.'], deletion_executed=False, Cargo_executed=False, native_executed=False, new_TODO_done=0, TODO_remaining=29)
    with (OUT/'plan-review.json').open('x') as f:
        json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
    print(json.dumps(result,sort_keys=True))

if __name__ == '__main__':
    main()
