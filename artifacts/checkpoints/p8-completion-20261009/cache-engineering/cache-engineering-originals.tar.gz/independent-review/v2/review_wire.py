from pathlib import Path
import zipfile,json,hashlib,sys
c=Path('/dev/shm/p8-soak-cache-candidate-G2');p=Path(__file__).resolve().parent
sys.path.insert(0,str(c/'scripts/tests'));sys.path.insert(0,str(c/'scripts'))
import test_p8_runtime_cache as t
status=None;member_hash=hashlib.sha256()
with zipfile.ZipFile('/dev/shm/p8-formal-G-soak-acceptance/artifact-11576468006.zip') as z:
 with z.open('p8-runtime/product/rpc.jsonl') as f:
  for line in f:
   member_hash.update(line)
   if status is None:
    v=json.loads(line)
    if v.get('event')=='response' and v.get('payload',{}).get('id')==4:
     status=v['payload']['result']['structuredContent']['result']
assert member_hash.hexdigest()==t.FIXTURE_ORIGIN['status']['member_sha256']
f=Path('/workspace/scratch/2eaa00d0f93a/p8-formal-evidence-G/lifecycle/files/measurement/replay-input.json');h=hashlib.sha256()
with f.open('rb') as stream:
 for b in iter(lambda:stream.read(65536),b''):h.update(b)
assert h.hexdigest()==t.FIXTURE_ORIGIN['hybrid']['member_sha256']
buffer='';decoder=json.JSONDecoder()
with f.open() as stream:
 while True:
  chunk=stream.read(4096)
  if not chunk:raise RuntimeError('raw_queries not found')
  buffer+=chunk
  if '"raw_queries"' in buffer:
   buffer=buffer.split('"raw_queries"',1)[1];buffer=buffer[buffer.index('[')+1:];break
  if len(buffer)>8192:buffer=buffer[-8192:]
 while True:
  try:query,_=decoder.raw_decode(buffer.lstrip());break
  except json.JSONDecodeError:
   chunk=stream.read(4096)
   if not chunk:raise
   buffer+=chunk
hybrid=query['response']
def canonical(v):return json.dumps(v,sort_keys=True,ensure_ascii=False).encode()
statussha=hashlib.sha256(canonical(status)).hexdigest();hybridsha=hashlib.sha256(canonical(hybrid)).hexdigest()
assert statussha==t.FIXTURE_ORIGIN['status']['response_canonical_sha256']
assert hybridsha==t.FIXTURE_ORIGIN['hybrid']['response_canonical_sha256']
def projection(got,original):
 if isinstance(got,dict):return isinstance(original,dict) and all(k in original and projection(v,original[k]) for k,v in got.items())
 if isinstance(got,list):return isinstance(original,list) and len(got)==len(original) and all(projection(a,b) for a,b in zip(got,original))
 return type(got)==type(original) and got==original
assert projection(t.G_STATUS_SHAPE,status);assert projection(t.G_HYBRID_SHAPE,hybrid)
(p/'actual-status-body.json').write_text(json.dumps(status,indent=2)+'\n')
(p/'actual-hybrid-body.json').write_text(json.dumps(hybrid,indent=2)+'\n')
report={'scope':'Read-only independent original wire member/response hashes and exact recursive subset projection; no new product execution','canonical_serialization':'json.dumps(body, sort_keys=True, ensure_ascii=False) with default separators; UTF-8','status_member_sha256':member_hash.hexdigest(),'status_canonical_response_sha256':statussha,'hybrid_member_sha256':h.hexdigest(),'hybrid_canonical_response_sha256':hybridsha,'status_projection_exact':True,'hybrid_projection_exact':True,'status_actual_cache_identity':t.runtime.cache_identity(status),'lifecycle_entity_not_soak_entity':'Only fixture ProtocolProduct explicitly maps original lifecycle coordinates/text to owned stable.py; original response remains unchanged in this record.','prior_attempt':'Initial reviewer used compact separators for the canonical hash and stopped at assertion. Default-separator hashes are the recorded author format; both now independently equal. No product or source mutation occurred.'}
(p/'wire-projection-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
