"""Package selected new07 intake evidence, never nesting original checkpoint ZIPs."""
from pathlib import Path
import hashlib
import json
import stat
import zipfile

ROOT = Path('/workspace/scratch/bfccb8494ba0')
HERE = ROOT / 'round38-diagnostic-checkpoint-07-intake'
OUT = HERE / 'sealed'
OUT.mkdir(exist_ok=False)
PREFIX = 'artifacts/checkpoints/p8-round38-diagnostic-checkpoint07-bfcc-20261010/'

def meta(path):
    b = path.read_bytes()
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()}

selected = [HERE / n for n in ('receive-original-prefix-once.py', 'review-new-prefix.py',
    'receive-original-prefix-once.py.adaptation.diff', 'review-new-prefix.py.adaptation.diff', 'review-new-prefix.v2.py', 'derived-bridge-type-adaptation.diff', 'seal-support.py')]
selected += sorted((HERE / 'attempt01').rglob('*'))
selected = [p for p in selected if p.is_file() and p.name != 'checkpoint07-prefix-review.json']
selected += [ROOT / 'round32-100k-diagnostic-intake-preparation/read-original-diagnostic.py',
             ROOT / 'round38-0325-dual-study-observation/diagnostic-artifacts.original.json']
selected += [ROOT / 'round37-diagnostic-checkpoint-06-intake/attempt01/reader/report.json', ROOT / 'round37-diagnostic-checkpoint-06-intake/attempt01/official-index.json', ROOT / 'round37-diagnostic-checkpoint-06-intake/attempt01/checkpoint06-prefix-review.json']
selected += sorted(p for p in ROOT.glob('round*-diagnostic-checkpoint-*-intake/attempt01/selected-originals/manifest.json') if p != HERE/'attempt01/selected-originals/manifest.json')
files = [{'local_path':str(p), 'archive_path':str(p.relative_to(ROOT)),
          'posix_mode':oct(stat.S_IMODE(p.stat().st_mode)), **meta(p)} for p in selected]
selection = {'schema':'selected-new07-intake-originals-v1', 'files':files,
    'excluded_original_ZIPs':'00-06 are accepted prior-record/small-manifest dependencies; no old ZIP was reread; new07 originalZIP has separate root custody and is not nested here.',
    'scope':'No workload, ELF or original semantic validator executed. Prefix custody and emitted JSONL records only.',
    'new_original_artifact_id':11658151472,'new_original_zip_sha256':'428368d66bc8850fed73486e80a1c61d3c097564877ff4e542762330424e02f3',
    'new_original_zip_bytes':61771, 'accepted_samples':0,'TODO_credit':0}
sel = OUT / 'archive-selection.json'
sel.write_text(json.dumps(selection,indent=2)+'\n')
zpath = OUT / 'diagnostic-checkpoint07-original-prefix-support.zip'
with zipfile.ZipFile(zpath,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p,f in zip(selected,files):
        zi=zipfile.ZipInfo(f['archive_path'],date_time=(2026,10,10,0,0,0))
        zi.create_system=3; zi.external_attr=(stat.S_IFREG|stat.S_IMODE(p.stat().st_mode))<<16
        zi.compress_type=zipfile.ZIP_DEFLATED; z.writestr(zi,p.read_bytes())
    zi=zipfile.ZipInfo('archive-selection.json',date_time=(2026,10,10,0,0,0))
    zi.create_system=3;zi.external_attr=(stat.S_IFREG|0o644)<<16;zi.compress_type=zipfile.ZIP_DEFLATED
    z.writestr(zi,sel.read_bytes())
with zipfile.ZipFile(zpath) as z:
    assert len(z.infolist())==len(files)+1
    for f in files:
        b=z.read(f['archive_path'])
        assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
        assert oct((z.getinfo(f['archive_path']).external_attr>>16)&0o777)==f['posix_mode']
    assert z.read('archive-selection.json')==sel.read_bytes()
assert zpath.stat().st_size<=8*1024*1024
report=HERE/'attempt01/checkpoint07-prefix-review.json'
uploads=[{'local_path':str(p),'repository_path':PREFIX+name,**meta(p)} for p,name in [
    (report,'checkpoint07-prefix-review.json'),(zpath,zpath.name),(sel,sel.name)]]
(OUT/'upload-manifest.json').write_text(json.dumps({'files':uploads,'support_members':len(files)+1,
    'support_archive_crc_sha_modes_verified':True,'source_reader_rerun':False},indent=2)+'\n')
print(json.dumps({'files':uploads,'support_members':len(files)+1}))
