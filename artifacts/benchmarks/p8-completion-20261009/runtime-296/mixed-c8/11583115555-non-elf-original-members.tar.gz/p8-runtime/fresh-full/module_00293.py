def stable_00293():
    return 293
