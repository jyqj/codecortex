# CodeCortex benchmark baseline

Suite: `V19 Requests protocol-v1 candidate dev native`
Adapter: `mcp-stdio`
Scoring: `Native`
Measurement profile: `quality`

Status: **gate_failed** (exit 1)

Queries: 91; measured rows: 273.
Mean Top-1: 0.000000; mean nDCG@10: 0.000000.

These are baseline observations, not a release quality certificate.
Latency: Distribution { samples: 0, p50_us: None, p95_us: None, max_us: None, tail_claim: "insufficient_for_tail_claim" }; samples are retained, not best-of.
Source evidence: 0 invalid, 0 unverified hits.

| Case | Top-1 | nDCG@10 | Repetitions |
|---|---:|---:|---:|
| v19.requests.f0001.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0002.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0003.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0004.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0006.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0007.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0008.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0009.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0010.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0012.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0013.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0014.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0015.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0016.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0017.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0022.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0023.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0025.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0026.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0027.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0028.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0029.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0033.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0034.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0037.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0038.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0039.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0040.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0042.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0046.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0047.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0048.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0049.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0050.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0051.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0053.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0054.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0055.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0056.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0058.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0059.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0060.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0061.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0063.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0064.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0065.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0066.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0067.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0068.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0069.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0071.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0073.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0074.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0078.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0079.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0080.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0082.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0083.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0084.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0086.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0087.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0089.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0090.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0091.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0092.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0093.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0094.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0101.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0102.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0103.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0104.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0105.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0108.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0109.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0110.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0111.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0112.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0113.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0114.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0115.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0116.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0117.en01 | 0.000000 | 0.000000 | 3 |
| v19.requests.f0120.en01 | 0.000000 | 0.000000 | 3 |

## Failures

- v19.requests.f0010.en01 Partial
- v19.requests.f0091.en01 Partial
- v19.requests.f0050.en01 Partial
- v19.requests.f0038.en01 Partial
- v19.requests.f0079.en01 Partial
- v19.requests.f0104.en01 Partial
- v19.requests.f0033.en01 Partial
- v19.requests.f0046.en01 Partial
- v19.requests.f0117.en01 Partial
- v19.requests.f0098.en01 Partial
- v19.requests.f0098.en01 no-answer failure
- v19.requests.f0009.en01 Partial
- v19.requests.f0060.en01 Partial
- v19.requests.f0014.en01 Partial
- v19.requests.f0003.en01 Partial
- v19.requests.f0051.en01 Partial
- v19.requests.f0047.en01 Partial
- v19.requests.f0065.en01 Partial
- v19.requests.f0110.en01 Partial
- v19.requests.f0019.en01 Partial
- v19.requests.f0019.en01 no-answer failure
- v19.requests.f0116.en01 Partial
- v19.requests.f0058.en01 Partial
- v19.requests.f0099.en01 Partial
- v19.requests.f0099.en01 no-answer failure
- v19.requests.f0084.en01 Partial
- v19.requests.f0056.en01 Partial
- v19.requests.f0089.en01 Partial
- v19.requests.f0063.en01 Partial
- v19.requests.f0034.en01 Partial
- v19.requests.f0102.en01 Partial
- v19.requests.f0053.en01 Partial
- v19.requests.f0097.en01 Partial
- v19.requests.f0097.en01 no-answer failure
- v19.requests.f0100.en01 Partial
- v19.requests.f0100.en01 no-answer failure
- v19.requests.f0066.en01 Partial
- v19.requests.f0042.en01 Partial
- v19.requests.f0008.en01 Partial
- v19.requests.f0017.en01 Partial
- v19.requests.f0022.en01 Partial
- v19.requests.f0026.en01 Partial
- v19.requests.f0087.en01 Partial
- v19.requests.f0109.en01 Partial
- v19.requests.f0004.en01 Partial
- v19.requests.f0054.en01 Partial
- v19.requests.f0027.en01 Partial
- v19.requests.f0064.en01 Partial
- v19.requests.f0023.en01 Partial
- v19.requests.f0039.en01 Partial
- v19.requests.f0113.en01 Partial
- v19.requests.f0012.en01 Partial
- v19.requests.f0049.en01 Partial
- v19.requests.f0101.en01 Partial
- v19.requests.f0025.en01 Partial
- v19.requests.f0037.en01 Partial
- v19.requests.f0078.en01 Partial
- v19.requests.f0083.en01 Partial
- v19.requests.f0086.en01 Partial
- v19.requests.f0002.en01 Partial
- v19.requests.f0103.en01 Partial
- v19.requests.f0013.en01 Partial
- v19.requests.f0082.en01 Partial
- v19.requests.f0074.en01 Partial
- v19.requests.f0090.en01 Partial
- v19.requests.f0028.en01 Partial
- v19.requests.f0073.en01 Partial
- v19.requests.f0071.en01 Partial
- v19.requests.f0112.en01 Partial
- v19.requests.f0055.en01 Partial
- v19.requests.f0094.en01 Partial
- v19.requests.f0067.en01 Partial
- v19.requests.f0111.en01 Partial
- v19.requests.f0048.en01 Partial
- v19.requests.f0015.en01 Partial
- v19.requests.f0040.en01 Partial
- v19.requests.f0096.en01 Partial
- v19.requests.f0096.en01 no-answer failure
- v19.requests.f0020.en01 Partial
- v19.requests.f0020.en01 no-answer failure
- v19.requests.f0018.en01 Partial
- v19.requests.f0018.en01 no-answer failure
- v19.requests.f0092.en01 Partial
- v19.requests.f0114.en01 Partial
- v19.requests.f0006.en01 Partial
- v19.requests.f0115.en01 Partial
- v19.requests.f0069.en01 Partial
- v19.requests.f0007.en01 Partial
- v19.requests.f0016.en01 Partial
- v19.requests.f0068.en01 Partial
- v19.requests.f0059.en01 Partial
- v19.requests.f0105.en01 Partial
- v19.requests.f0108.en01 Partial
- v19.requests.f0001.en01 Partial
- v19.requests.f0093.en01 Partial
- v19.requests.f0029.en01 Partial
- v19.requests.f0061.en01 Partial
- v19.requests.f0120.en01 Partial
- v19.requests.f0080.en01 Partial
- v19.requests.f0073.en01 Partial
- v19.requests.f0064.en01 Partial
- v19.requests.f0117.en01 Partial
- v19.requests.f0074.en01 Partial
- v19.requests.f0006.en01 Partial
- v19.requests.f0093.en01 Partial
- v19.requests.f0027.en01 Partial
- v19.requests.f0098.en01 Partial
- v19.requests.f0098.en01 no-answer failure
- v19.requests.f0120.en01 Partial
- v19.requests.f0103.en01 Partial
- v19.requests.f0050.en01 Partial
- v19.requests.f0110.en01 Partial
- v19.requests.f0065.en01 Partial
- v19.requests.f0012.en01 Partial
- v19.requests.f0017.en01 Partial
- v19.requests.f0002.en01 Partial
- v19.requests.f0089.en01 Partial
- v19.requests.f0083.en01 Partial
- v19.requests.f0099.en01 Partial
- v19.requests.f0099.en01 no-answer failure
- v19.requests.f0114.en01 Partial
- v19.requests.f0105.en01 Partial
- v19.requests.f0040.en01 Partial
- v19.requests.f0091.en01 Partial
- v19.requests.f0100.en01 Partial
- v19.requests.f0100.en01 no-answer failure
- v19.requests.f0015.en01 Partial
- v19.requests.f0010.en01 Partial
- v19.requests.f0048.en01 Partial
- v19.requests.f0020.en01 Partial
- v19.requests.f0020.en01 no-answer failure
- v19.requests.f0039.en01 Partial
- v19.requests.f0042.en01 Partial
- v19.requests.f0049.en01 Partial
- v19.requests.f0025.en01 Partial
- v19.requests.f0007.en01 Partial
- v19.requests.f0033.en01 Partial
- v19.requests.f0115.en01 Partial
- v19.requests.f0108.en01 Partial
- v19.requests.f0054.en01 Partial
- v19.requests.f0013.en01 Partial
- v19.requests.f0094.en01 Partial
- v19.requests.f0080.en01 Partial
- v19.requests.f0066.en01 Partial
- v19.requests.f0063.en01 Partial
- v19.requests.f0092.en01 Partial
- v19.requests.f0102.en01 Partial
- v19.requests.f0067.en01 Partial
- v19.requests.f0047.en01 Partial
- v19.requests.f0055.en01 Partial
- v19.requests.f0056.en01 Partial
- v19.requests.f0059.en01 Partial
- v19.requests.f0016.en01 Partial
- v19.requests.f0034.en01 Partial
- v19.requests.f0101.en01 Partial
- v19.requests.f0004.en01 Partial
- v19.requests.f0113.en01 Partial
- v19.requests.f0090.en01 Partial
- v19.requests.f0008.en01 Partial
- v19.requests.f0001.en01 Partial
- v19.requests.f0087.en01 Partial
- v19.requests.f0003.en01 Partial
- v19.requests.f0068.en01 Partial
- v19.requests.f0116.en01 Partial
- v19.requests.f0069.en01 Partial
- v19.requests.f0084.en01 Partial
- v19.requests.f0038.en01 Partial
- v19.requests.f0109.en01 Partial
- v19.requests.f0058.en01 Partial
- v19.requests.f0112.en01 Partial
- v19.requests.f0026.en01 Partial
- v19.requests.f0018.en01 Partial
- v19.requests.f0018.en01 no-answer failure
- v19.requests.f0022.en01 Partial
- v19.requests.f0096.en01 Partial
- v19.requests.f0096.en01 no-answer failure
- v19.requests.f0071.en01 Partial
- v19.requests.f0046.en01 Partial
- v19.requests.f0014.en01 Partial
- v19.requests.f0097.en01 Partial
- v19.requests.f0097.en01 no-answer failure
- v19.requests.f0029.en01 Partial
- v19.requests.f0061.en01 Partial
- v19.requests.f0082.en01 Partial
- v19.requests.f0051.en01 Partial
- v19.requests.f0028.en01 Partial
- v19.requests.f0019.en01 Partial
- v19.requests.f0019.en01 no-answer failure
- v19.requests.f0086.en01 Partial
- v19.requests.f0023.en01 Partial
- v19.requests.f0009.en01 Partial
- v19.requests.f0079.en01 Partial
- v19.requests.f0037.en01 Partial
- v19.requests.f0104.en01 Partial
- v19.requests.f0111.en01 Partial
- v19.requests.f0060.en01 Partial
- v19.requests.f0053.en01 Partial
- v19.requests.f0078.en01 Partial
- v19.requests.f0084.en01 Partial
- v19.requests.f0051.en01 Partial
- v19.requests.f0103.en01 Partial
- v19.requests.f0033.en01 Partial
- v19.requests.f0058.en01 Partial
- v19.requests.f0016.en01 Partial
- v19.requests.f0096.en01 Partial
- v19.requests.f0096.en01 no-answer failure
- v19.requests.f0060.en01 Partial
- v19.requests.f0009.en01 Partial
- v19.requests.f0039.en01 Partial
- v19.requests.f0114.en01 Partial
- v19.requests.f0002.en01 Partial
- v19.requests.f0034.en01 Partial
- v19.requests.f0113.en01 Partial
- v19.requests.f0089.en01 Partial
- v19.requests.f0086.en01 Partial
- v19.requests.f0097.en01 Partial
- v19.requests.f0097.en01 no-answer failure
- v19.requests.f0019.en01 Partial
- v19.requests.f0019.en01 no-answer failure
- v19.requests.f0050.en01 Partial
- v19.requests.f0055.en01 Partial
- v19.requests.f0087.en01 Partial
- v19.requests.f0038.en01 Partial
- v19.requests.f0099.en01 Partial
- v19.requests.f0099.en01 no-answer failure
- v19.requests.f0078.en01 Partial
- v19.requests.f0007.en01 Partial
- v19.requests.f0026.en01 Partial
- v19.requests.f0040.en01 Partial
- v19.requests.f0071.en01 Partial
- v19.requests.f0049.en01 Partial
- v19.requests.f0065.en01 Partial
- v19.requests.f0066.en01 Partial
- v19.requests.f0017.en01 Partial
- v19.requests.f0003.en01 Partial
- v19.requests.f0110.en01 Partial
- v19.requests.f0014.en01 Partial
- v19.requests.f0004.en01 Partial
- v19.requests.f0053.en01 Partial
- v19.requests.f0067.en01 Partial
- v19.requests.f0100.en01 Partial
- v19.requests.f0100.en01 no-answer failure
- v19.requests.f0079.en01 Partial
- v19.requests.f0047.en01 Partial
- v19.requests.f0013.en01 Partial
- v19.requests.f0069.en01 Partial
- v19.requests.f0074.en01 Partial
- v19.requests.f0012.en01 Partial
- v19.requests.f0061.en01 Partial
- v19.requests.f0092.en01 Partial
- v19.requests.f0102.en01 Partial
- v19.requests.f0093.en01 Partial
- v19.requests.f0001.en01 Partial
- v19.requests.f0073.en01 Partial
- v19.requests.f0117.en01 Partial
- v19.requests.f0068.en01 Partial
- v19.requests.f0064.en01 Partial
- v19.requests.f0101.en01 Partial
- v19.requests.f0094.en01 Partial
- v19.requests.f0046.en01 Partial
- v19.requests.f0010.en01 Partial
- v19.requests.f0112.en01 Partial
- v19.requests.f0108.en01 Partial
- v19.requests.f0105.en01 Partial
- v19.requests.f0116.en01 Partial
- v19.requests.f0048.en01 Partial
- v19.requests.f0059.en01 Partial
- v19.requests.f0028.en01 Partial
- v19.requests.f0111.en01 Partial
- v19.requests.f0022.en01 Partial
- v19.requests.f0025.en01 Partial
- v19.requests.f0109.en01 Partial
- v19.requests.f0023.en01 Partial
- v19.requests.f0083.en01 Partial
- v19.requests.f0020.en01 Partial
- v19.requests.f0020.en01 no-answer failure
- v19.requests.f0008.en01 Partial
- v19.requests.f0029.en01 Partial
- v19.requests.f0090.en01 Partial
- v19.requests.f0018.en01 Partial
- v19.requests.f0018.en01 no-answer failure
- v19.requests.f0080.en01 Partial
- v19.requests.f0098.en01 Partial
- v19.requests.f0098.en01 no-answer failure
- v19.requests.f0027.en01 Partial
- v19.requests.f0115.en01 Partial
- v19.requests.f0054.en01 Partial
- v19.requests.f0015.en01 Partial
- v19.requests.f0056.en01 Partial
- v19.requests.f0120.en01 Partial
- v19.requests.f0037.en01 Partial
- v19.requests.f0006.en01 Partial
- v19.requests.f0082.en01 Partial
- v19.requests.f0104.en01 Partial
- v19.requests.f0063.en01 Partial
- v19.requests.f0042.en01 Partial
- v19.requests.f0091.en01 Partial