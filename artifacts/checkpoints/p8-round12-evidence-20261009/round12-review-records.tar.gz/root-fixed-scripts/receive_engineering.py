#!/usr/bin/env python3
"""Receive exact auxiliary evidence; never run Cargo or a product workload.

The unmodified original scale validators may invoke the original binary only
with --hash-file, as in the previous independently reviewed D0 intake.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import zipfile
import zlib

HERE = Path(__file__).resolve().parent
RECEPTION = Path('/dev/shm/p8-staging-engineering-reception')
SOURCE_ROOT = Path('/workspace/scratch/2eaa00d0f93a/p8-staging-engineering-exact-source')
SOURCE = '8e542e644b06a83fc82d18d9896cf82f5b2d796e'
TREE = '28a35d538f11613e98e645f37d8bbd4946d754ac'
RUN = 37863581678
HEADROOM = 512 * 1024 ** 2
OWNED_BUDGET = 1024 ** 3
EXPECTATIONS_SHA = '468379420a6258344f4e0082a6be0e5cd5a04aab175eef6a3204f747db02379d'
WORKFLOW_SHA = 'b68a2601e5c6577c54dce435eb2baba05b8588d09dcd35e5af574746be96735a'

sys.path.insert(0, str(SOURCE_ROOT / 'scripts'))
import p8_scale_matrix as original
require = original.require

def sha(path):
    return original.file_sha256(path)

def owned_bytes():
    return sum(p.stat().st_size for p in RECEPTION.rglob('*') if p.is_file() and not p.is_symlink())

def receive(directory):
    """Keep the original ZIP and materialize only a fresh owned directory."""
    source = directory / 'original.zip'
    meta = original.read_json(directory / 'expected-artifact.json')
    run = original.read_json(directory / 'run.json')
    job = original.read_json(directory / 'job.json')
    require(run['id'] == RUN and run['head_sha'] == SOURCE and run['run_attempt'] == 1 and run['event'] == 'push', 'wrong run/source/attempt/event')
    require(job['run_id'] == RUN and job['head_sha'] == SOURCE and job.get('run_attempt') == 1, 'wrong job source or attempt')
    require(meta['workflow_run']['id'] == RUN and meta['workflow_run']['head_sha'] == SOURCE and not meta['expired'], 'wrong or expired artifact provenance')
    digest = sha(source)
    require(source.stat().st_size == meta['size_in_bytes'], 'ZIP byte count differs from original API metadata')
    require(meta.get('digest') == 'sha256:' + digest, 'ZIP digest differs from original API metadata')
    target = directory / 'original'
    require(not target.exists(), 'fresh owned expansion required; preserve existing reception')
    members = {}
    with zipfile.ZipFile(source) as archive:
        infos = archive.infolist()
        require(infos and len(infos) <= 20000, 'empty or unbounded artifact inventory')
        total = sum(info.file_size for info in infos)
        require(total <= OWNED_BUDGET and owned_bytes() + total <= OWNED_BUDGET, 'owned reception byte budget')
        require(shutil.disk_usage(RECEPTION).free - total >= HEADROOM, 'receiver headroom would be lost')
        for info in infos:
            name = PurePosixPath(info.filename)
            require(not name.is_absolute() and '..' not in name.parts and '.' not in name.parts and str(name) == info.filename, 'noncanonical ZIP member')
            require(not info.is_dir() and stat.S_ISREG(info.external_attr >> 16) and info.filename not in members, 'nonregular or duplicate ZIP member')
            members[info.filename] = {'bytes': info.file_size, 'crc32': info.CRC, 'zip_mode': info.external_attr >> 16}
        target.mkdir()
        for info in infos:
            path = target / info.filename
            path.parent.mkdir(parents=True, exist_ok=True)
            checksum, count, digest_member = 0, 0, hashlib.sha256()
            with archive.open(info) as source_member, path.open('xb') as output:
                for block in iter(lambda: source_member.read(1024 * 1024), b''):
                    count += len(block)
                    require(count <= info.file_size, 'expanded member exceeds declared bytes')
                    output.write(block)
                    digest_member.update(block)
                    checksum = zlib.crc32(block, checksum)
            require(count == info.file_size and checksum & 0xffffffff == info.CRC, 'ZIP member size/CRC differs')
            members[info.filename]['sha256'] = digest_member.hexdigest()
    inventory = {name: {'bytes': row['bytes'], 'sha256': row['sha256']} for name, row in members.items()}
    require(original.inventory(target) == inventory and sha(source) == digest, 'ZIP/expansion changed')
    proof = {'artifact': meta, 'zip_sha256': digest, 'zip_bytes': source.stat().st_size,
             'members': members, 'expanded_bytes': sum(row['bytes'] for row in members.values()),
             'run_id': RUN, 'job_id': job['id'], 'job_status': job['status'], 'job_conclusion': job['conclusion']}
    (directory / 'reception.json').write_bytes(original.json_bytes(proof))
    return target, proof, run, job

def inspect_controls(target):
    expectations = HERE / 'test-expectations.json'
    require(sha(expectations) == EXPECTATIONS_SHA, 'static test population changed')
    expected = original.read_json(expectations)
    require(expected['published_source'] == SOURCE and expected['published_tree'] == TREE, 'test population uses another source')
    commands = expected['commands']
    require(len(commands) == 13 and sum(c['expected_executed'] for c in commands) == 41, 'wrong fixed test population')
    record = original.read_json(target / 'receipt.json')
    require(record['status'] == 'commands_completed' and record['exit_code'] == 0 and record['source_unchanged'] is True, 'controls did not complete successfully')
    require(record['expected_source'] == SOURCE and record['not_run_command_indices'] == [], 'partial or wrong-source controls')
    require(record['commands'] == [c['argv'] for c in commands] and len(record['results']) == 13, 'control command list differs')
    require(record['files'] == original.inventory(target, ('receipt.json',)), 'control sealed inventory differs')
    tests = []
    for command, result in zip(commands, record['results']):
        index = command['command_index']
        require(result['argv'] == command['argv'] and result['exit_code'] == 0, 'command arguments or exit differ')
        require(result['stdout'] == command['stdout_file'] and result['stderr'] == command['stderr_file'], 'command log binding differs')
        require(type(result['elapsed_ns']) is int and result['elapsed_ns'] >= 0, 'invalid command elapsed time')
        stdout = (target / result['stdout']).read_text()
        summaries = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', stdout, re.M)
        names = re.findall(r'^test (.+?) \.\.\. ok$', stdout, re.M)
        running = re.findall(r'^running (\d+) tests?$', stdout, re.M)
        if command['expected_executed'] == 0:
            require(not summaries and not names and not running, 'non-test command claims test results')
            continue
        expected_names = [test['harness_name'] for test in command['tests']]
        require(len(summaries) == 1 and len(running) == 1, 'missing or repeated nonempty test summary')
        counts = list(map(int, summaries[0]))
        require(counts[:4] == [len(expected_names), 0, 0, 0] and int(running[0]) == len(expected_names), 'actual tests failed, ignored, missing or zero')
        require(len(names) == len(expected_names) and len(set(names)) == len(names) and set(names) == set(expected_names), 'actual test names differ from fixed source population')
        require(not re.findall(r'^test .+? \.\.\. (?:ignored|FAILED)', stdout, re.M), 'failed or ignored selected test')
        if command['kind'] == 'integration':
            require(counts[4] == 0, 'complete integration target was filtered')
        tests.append({'command_index': index, 'passed_names': names, 'passed': counts[0], 'failed': 0, 'ignored': 0, 'filtered_out': counts[4]})
    require(sum(row['passed'] for row in tests) == 41, 'incomplete selected test population')
    return {'status': 'accepted_scoped_actual_engineering_controls', 'commands': [c['argv'] for c in commands],
            'tests': tests, 'passed': 41, 'ignored_selected': 0, 'receipt_sha256': sha(target / 'receipt.json')}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--kind', choices=('controls', 'build', 'diagnostic'), required=True)
    parser.add_argument('--artifact-directory', type=Path, required=True)
    parser.add_argument('--scale', type=int, choices=(1000, 10000, 100000))
    parser.add_argument('--build-directory', type=Path)
    args = parser.parse_args()
    directory = args.artifact_directory.resolve(strict=True)
    require(directory.parent == RECEPTION.resolve(strict=True), 'artifact is outside the fixed owned reception root')
    require(not (directory / 'inspection.json').exists(), 'preserve the existing inspection; a fresh attempt directory is required')
    before = original.source_snapshot(SOURCE_ROOT)
    driver_before = original.driver_snapshot(SOURCE_ROOT)
    require(before['source_commit'] == SOURCE and before['source_tree'] == TREE and before['input_count'] == 1087, 'local actual source identity differs')
    require(before == original.read_json(HERE / 'actual-source-snapshot.json'), 'local actual source inventory changed')
    workflow = subprocess.check_output(['git', '-C', str(SOURCE_ROOT), 'show', SOURCE + ':.github/workflows/p8-staging-cache-engineering.yml'])
    require(hashlib.sha256(workflow).hexdigest() == WORKFLOW_SHA, 'actual original workflow changed')
    result = {'kind': args.kind, 'status': 'rejected_or_partial', 'source': SOURCE, 'run_id': RUN,
              'new_TODO_done': 0, 'TODO_remaining': 29, 'Cargo_executed': False, 'new_native_workload_executed': False}
    pending_status, verification_complete = None, False
    try:
        target, proof, run, job = receive(directory)
        result['reception'] = proof
        require(job['status'] == 'completed' and job['conclusion'] == 'success', 'actual job has not completed successfully')
        if args.kind in ('controls', 'build'):
            require(job['id'] == 113604866890 and job['name'] == 'controls_and_build', 'wrong controls/build job')
            expected_artifact = f'p8-staging-controls-{RUN}' if args.kind == 'controls' else f'p8-staging-scale-build-{RUN}'
        else:
            require(args.scale is not None and args.build_directory is not None, 'diagnostic scale/build binding missing')
            expected_name = f'engineering scale {args.scale} repetition 0 only'
            require(job['name'] == expected_name, 'wrong fixed auxiliary scale job')
            expected_artifact = f'p8-staging-shard-{args.scale}-0-{RUN}'
        require(proof['artifact']['name'] == expected_artifact, 'wrong artifact kind or scale')
        source_before = original.read_json(target / 'source-before.json')
        require(source_before == original.read_json(target / 'source-after.json') == before, 'artifact source snapshots differ from complete actual Git input inventory')
        if args.kind == 'controls':
            controls = inspect_controls(target)
            pending_status = controls.pop('status')
            result.update(controls)
        elif args.kind == 'build':
            (target / 'p8-scale').chmod(0o755)
            built, binary = original.validate_build(target, SOURCE_ROOT)
            pending_status = 'accepted_scoped_actual_original_release_build'
            result.update(binary_sha256=built['binary_sha256'],
                          binary_blake3=built['binary_blake3'], build_receipt_sha256=sha(target / 'build.json'))
        else:
            build_dir = args.build_directory.resolve(strict=True)
            require(build_dir.parent.parent == RECEPTION and build_dir.name == 'original', 'build outside fixed reception')
            build_before = original.inventory(build_dir)
            built, binary = original.validate_build(build_dir, SOURCE_ROOT)
            validated = original.validate_shard(target, built, binary, sha(build_dir / 'build.json'))
            require(validated['plan'] == original.registered_plan(args.scale, 0, 30, 30, 12648430, 18000000, original.CAPACITY_PROFILE), 'auxiliary plan differs')
            require(validated['engine']['engine_head_observed'] == SOURCE, 'measured engine source differs')
            require(original.inventory(build_dir) == build_before, 'original build files changed during replay')
            (directory / 'validated.json').write_bytes(original.json_bytes(validated))
            pending_status = 'accepted_scoped_one_original_auxiliary_diagnostic'
            result.update(scale=args.scale,
                          original_validate_build_passed=True, original_validate_shard_passed=True,
                          plan=validated['plan'], samples=len(validated['measurements']),
                          native_report=original.read_json(target / 'native/report.json'),
                          build_receipt_sha256=sha(build_dir / 'build.json'), binary_sha256=built['binary_sha256'])
        require(original.inventory(target) == {name: {'bytes': r['bytes'], 'sha256': r['sha256']} for name, r in proof['members'].items()}, 'original evidence bytes changed during verification')
        require(sha(directory / 'original.zip') == proof['zip_sha256'], 'original ZIP changed during verification')
        result['native_call_scope'] = 'None for controls; unmodified original --hash-file only for build/diagnostic identity. No new measurement.'
        result['scope_limits'] = ['Auxiliary engineering only, not N30 or a primary replacement.', 'Every old failed or missing execution remains in its original study.']
        verification_complete = True
    except BaseException as error:
        verification_complete = False
        result['status'] = 'rejected_or_partial'
        result['error'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        result['observed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        try:
            result['source_and_driver_unchanged'] = original.source_snapshot(SOURCE_ROOT) == before and original.driver_snapshot(SOURCE_ROOT) == driver_before
        except BaseException as error:
            result['source_and_driver_unchanged'] = False
            result['final_source_check_error'] = f'{type(error).__name__}: {error}'
        result['status'] = pending_status if verification_complete and result['source_and_driver_unchanged'] else 'rejected_or_partial'
        result['receiver_exit_requirement'] = 'This verdict is usable only with the separately captured actual receiver exit code zero.'
        with (directory / 'inspection.json').open('xb') as stream:
            stream.write(original.json_bytes(result))
    require(result['source_and_driver_unchanged'], 'receiver changed source or observer')
    require(result['status'].startswith('accepted_scoped'), 'receiver verification did not finish')
    print(json.dumps({'status': result['status'], 'kind': args.kind, 'inspection_sha256': sha(directory / 'inspection.json'), 'new_TODO_done': 0, 'TODO_remaining': 29}))

if __name__ == '__main__':
    main()
