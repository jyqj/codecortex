def stable_00225():
    return 225
