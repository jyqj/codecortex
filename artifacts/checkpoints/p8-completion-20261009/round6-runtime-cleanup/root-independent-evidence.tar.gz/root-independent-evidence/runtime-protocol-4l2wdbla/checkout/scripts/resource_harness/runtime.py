# committed protocol-control fixture: scripts/resource_harness/runtime.py
