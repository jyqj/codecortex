def stable_00197():
    return 197
