#!/usr/bin/env python3
"""Read-only immutable Git-tree reconstruction; no remote mutation or execution."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PLAN = Path('/dev/shm/todo-audit-b2-G3-forward-plan')
H = '0e6b07c75183da79c5a6679d4c2b66c65f7db663'
B2 = 'b2a17adc188338c48b95d01761836916e5d0fcdb'
B2_TREE = '8e82c2c60188148f91c2c8bfa58c1e158a94b8af'
PR_HEAD = '883230f2b44ebcf09495870db8c0e31d61270331'

def load(path):
    value = json.loads(path.read_text())
    return json.loads(value['response_content']) if 'response_content' in value else value

def record(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

helper = ROOT.parent/'P3-source-review/verify-actual-P3-tree-and-inputs.py'
module = ast.parse(helper.read_text())
cut = next(i for i, stmt in enumerate(module.body) if isinstance(stmt, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'spec' for t in stmt.targets))
namespace = {'__file__': str(helper)}
exec(compile(ast.Module(body=module.body[:cut], type_ignores=[]), str(helper), 'exec'), namespace)
leaves = namespace['leaves']
assert namespace['roots']['H'] == '9755e717368ffb51bc084c3348c1715b00b34d0d'
original_h_leaves = dict(leaves)
comparison_path = PLAN/'official-H-to-b2-compare.json'
comparison = load(comparison_path)
assert comparison['base_commit']['sha'] == H
assert comparison['commits'][-1]['sha'] == B2
assert len(comparison['files']) == 42
assert set(f['status'] for f in comparison['files']) == {'added', 'modified'}
for file in comparison['files']:
    path = file['filename']
    if file['status'] == 'added':
        assert path not in leaves
    else:
        assert leaves[path]['mode'] == '100644' and leaves[path]['type'] == 'blob'
    leaves[path] = {'mode': '100644', 'type': 'blob', 'sha': file['sha']}
assert namespace['hash_leaves'](leaves)[''] == B2_TREE
pr = load(ROOT/'official-PR184.json')
files = load(ROOT/'official-PR184-files.json')
refresh = load(ROOT/'official-b356-to-current184.json')
assert pr['number'] == 184 and pr['head']['sha'] == PR_HEAD
assert pr['state'] == 'open' and pr['draft'] is True and pr['merged'] is False
assert pr['changed_files'] == len(files) == 16
assert refresh['commits'][-1]['sha'] == PR_HEAD and len(refresh['files']) == 4
bindings = {'scripts/reviewed-source-registry-v15.json', 'scripts/verify_reviewed_source_v15.py'}
rows = []
for file in files:
    path = file['filename']
    actual = leaves.get(path)
    assert actual is not None
    identical = actual['mode'] == '100644' and actual['type'] == 'blob' and actual['sha'] == file['sha']
    assert identical == (path not in bindings), path
    rows.append({'path': path, 'PR184_git_blob': file['sha'], 'b2_git_blob': actual['sha'], 'b2_mode': actual['mode'], 'b2_type': actual['type'], 'exact_blob_mode_match': identical, 'kind': 'identity_binding' if path in bindings else 'product' if path.startswith('crates/') else 'preserved_evidence'})
assert sum(r['kind'] == 'product' for r in rows) == 7
assert sum(r['kind'] == 'preserved_evidence' for r in rows) == 7
assert sum(r['exact_blob_mode_match'] for r in rows) == 14
report = {
    'schema': 'PR184-current-head-engineering-absorption-review-v1',
    'reviewer': '/root/execution_recon',
    'verdict': 'current_PR184_engineering_and_evidence_scope_fully_absorbed_in_b2',
    'PR184': {'url': pr['html_url'], 'state': pr['state'], 'draft': pr['draft'], 'merged': pr['merged'], 'head': PR_HEAD, 'base': pr['base']['sha'], 'mergeable': pr['mergeable'], 'mergeable_state': pr['mergeable_state'], 'updated_at': pr['updated_at'], 'fresh_observation': json.loads((ROOT/'official-PR184.json').read_text())['retrieved_at']},
    'target': {'PR': 180, 'source': B2, 'tree': B2_TREE, 'source_kind': 'existing_PR_head_at_review_scope', 'not_a_main_merge_claim': True},
    'proof': {'H_tree_reconstructed': namespace['roots']['H'], 'official_H_to_b2_changed_leaves': 42, 'all_directory_objects_rehashed_to_b2_tree': True, 'b2_total_leaves': len(leaves), 'fresh_PR184_paths': 16, 'exact_product_paths': 7, 'exact_evidence_paths': 7, 'source_specific_binding_paths_intentionally_distinct': 2, 'rows': rows},
    'binding_boundary': 'The registry and four-pin guard are source-specific identities. Their different bytes are expected: b2 retains its broader source/validation binding. Copying PR184 bindings over b2 would replace the target identity rather than preserve engineering scope. This is not a literal sixteen-file equality claim.',
    'new_since_old_b356': [{'path': f['filename'], 'status': f['status'], 'git_blob': f['sha']} for f in refresh['files']],
    'recommendation': 'PR184 may be closed as superseded by PR180 at immutable b2 for engineering scope: all seven product files and all seven evidence files are already preserved there byte-for-byte. Preserve the original branch and immutable evidence references. Closure is administrative deduplication; it neither merges b2 nor accepts unobserved current-head execution or any P8 TODO.',
    'execution_boundary': {'no_native_or_Rust_or_collector_execution': True, 'no_PR184_checks_polled': True, 'current_PR184_body_execution_claims_not_independently_adopted': True, 'mergeable_state_unstable_is_not_a_specific_test_result': True, 'no_Gc8_or_G3_or_fourC_execution_transferred': True, 'TODO_count_unchanged': 29},
    'method': 'Official immutable PR/file/compare records were read once; complete b2 Git tree was independently reconstructed from retained verified P2/R2/G2/H leaves and the complete official forty-two-leaf H-to-b2 comparison. Every directory Git object hash was recomputed. This derived tree is not described as a fresh recursive GitHub API response.',
    'inputs': [record(p) for p in [helper, comparison_path, ROOT/'official-PR184.json', ROOT/'official-PR184-files.json', ROOT/'official-b356-to-current184.json']],
}
out = ROOT/'independent-current-PR184-absorption-review.json'
with out.open('x') as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'verdict': report['verdict'], 'exact_product': 7, 'exact_evidence': 7, 'bindings_distinct': 2, 'actual_b2_tree': B2_TREE, 'report': record(out)}, sort_keys=True))
