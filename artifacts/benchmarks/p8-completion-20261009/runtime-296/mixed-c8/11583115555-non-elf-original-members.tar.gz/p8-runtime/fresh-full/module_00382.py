def stable_00382():
    return 382
