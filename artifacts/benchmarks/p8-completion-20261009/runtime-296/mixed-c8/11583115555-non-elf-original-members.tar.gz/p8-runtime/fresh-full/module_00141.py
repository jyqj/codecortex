def stable_00141():
    return 141
