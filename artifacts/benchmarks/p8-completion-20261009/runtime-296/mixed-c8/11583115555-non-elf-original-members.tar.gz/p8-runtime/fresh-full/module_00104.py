def stable_00104():
    return 104
