#!/usr/bin/env python3
"""Prepare future ledger inputs from already accepted records. No ledger writes or validation execution."""
import copy
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
OUT.mkdir(exist_ok=True)
LEDGER = Path('/dev/shm/a217aaae3bde/pr180-M6-b2a1-validated/docs/roadmap/code-index-v2/tasks.json')
TEN = ['P8-%03d' % n for n in range(5, 14)] + ['P8-016']
EIGHT = TEN[2:]
GC8 = 'c8be5afaac568ffd40ef86d3795423c3b73c9f39'
PUB56 = '56cf243df673a0745644ff17351353c8e416d349'
PUB16 = '16ce2a5623b51b6dc4ae23df4912f939791fe7d8'
PUB18 = '3548736f0dd42304e6b5f06f40007a756df6a361'
PUBSOAK = 'b66afc3a4967d7047b038fa8e6f9e20118018b5c'
PREFIX = 'artifacts/checkpoints/p8-a23-closeout-20261009-bfcc/'

def read(path):
    return json.loads(Path(path).read_text())

def digest(path):
    p = Path(path); b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest(),
                git_blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())

def dump(name, value):
    (OUT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)+'\n')

def gitlink(commit, path, directory=False):
    return 'https://github.com/jyqj/codecortex/'+('tree' if directory else 'blob')+'/'+commit+'/'+path

ledger_id = digest(LEDGER)
assert ledger_id['git_blob'] == '959a25ba851ff88f286bab0fa14167878129b1dd'
ledger = read(LEDGER); tasks = {x['id']:x for x in ledger['tasks']}
assert len(tasks) == 192 and sum(t['status']=='done' for t in tasks.values()) == 163
assert all(tasks[x]['status']=='in_progress' for x in TEN)
assert all(tasks[x]['status']=='done' for x in ['P8-004','P8-001','P7-020'])
definition_keys = ['id','title','status','scope','steps','acceptance','acceptance_subgates','depends_on','validations','conditional','conditional_dependencies','required_for']
definitions = {i:{k:copy.deepcopy(tasks[i][k]) for k in definition_keys if k in tasks[i]} for i in TEN}
dump('original-ten-definitions-selected.json', {'ledger_identity':ledger_id,'source_main':'23eab8a7ea1fdfd6333c2e5a001cfb41e2a10d69','exact_original_fields_by_ID':definitions,'scope':'Selected original task fields, not a reserialized original-file identity.'})

runtime_path = '/dev/shm/pr-triage-bfcc-c8be5afa/runtime-review-Gc8/mixed-lifecycle-backfill-soak-terminal-evidence-v2.json'
runtime = read(runtime_path)
g2_path = '/dev/shm/pr-triage-G2-db-lock-cohort-37930392164/complete-four-C-cohort/complete-G2-four-C-independent-review.json'
g2 = read(g2_path)
assert runtime['source']==GC8 and g2['complete_Cs']==[1,4,8,16] and not g2['missing_Cs']
assert g2['source_G']=='4d18dcdb34b5d7a277566b57801cc882d8b1eb61'
assert g2['per_C_denominator']==900 and g2['run_conclusion']=='success'
assert runtime['soak']['actual_work_nanoseconds']==3600054553094
assert [m['configured_concurrency'] for m in runtime['mixed']]==[1,4,8,16]
prior = read('/dev/shm/todo-audit-round21-original-ten-decision/original-ten-minimal-decision.json')
assert all(r['own_scope_complete_only_at_declared_component_sources'] for r in prior['rows'] if r['id'] in EIGHT)

pub56 = read('/dev/shm/root-round22/56cf-original-commit-file-list.json')
pub56 = json.loads(pub56['structuredContent']['content'])
assert pub56['sha']==PUB56
published56 = {f['filename']: f['sha'] for f in pub56['files']}
recovery_zip = PREFIX+'round12-primary-platform-source-and-concurrency/recovery-and-platform.zip'
ci_gates_zip = PREFIX+'round12-primary-platform-source-and-concurrency/original-CI-and-gates-reviews.zip'
mixed_zip = PREFIX+'round12-primary-platform-source-and-concurrency/concurrency-C8-C4-reviews.zip'
assert published56[recovery_zip]=='7e347fd2391070c506fbbf39334a85357bdaf88d'
assert published56[ci_gates_zip]=='dd75ae4b9faaddf4a66a1b6f78c83051c5c173eb'
assert published56[mixed_zip]=='6d32340a712063a67a10f434ca10408dd863d6a0'
pub18 = read('/dev/shm/root-round18/checkpoint-publication-original.json')
assert pub18['created_commit']['structuredContent']['sha']==PUB18
pack18=read('/dev/shm/todo-audit-round18-selected-checkpoint/sealed-attempt02/final-root-upload-manifest.json')
pack18zip=next(f for f in pack18['files'] if f['repository_path'].endswith('.zip'))
members18=read('/dev/shm/todo-audit-round18-selected-checkpoint/sealed-attempt02/selected-file-manifest.json')
g2member=next(f for f in members18['files'] if f['source_path']==g2_path)
assert g2member['sha256']==digest(g2_path)['sha256']
soak_index=read('/dev/shm/pr-triage-bfcc-c8be5afa/runtime-review-Gc8/publication-bundles-round13/upload-index.json')
soak_zip=next(f for f in soak_index['files'] if f['repository_path'].endswith('/soak-review-evidence.zip'))

index = {
 'gc8_runtime_terminal_map':{'source':GC8,'run_id':37901930897,'review':digest(runtime_path),
    'durable':{'commit':PUBSOAK,'url':gitlink(PUBSOAK,soak_zip['repository_path']),'zip_git_blob':soak_zip['git_blob'],'zip_sha256':soak_zip['sha256'],
    'member':'runtime-review-Gc8/mixed-lifecycle-backfill-soak-terminal-evidence-v2.json'},
    'accepted_scope':'Four C mixed + independent lifecycle/backfill and one-hour soak components, retaining each original source/run; original old closure-reason is superseded by the later G2 DB acquisition evidence and current dependency decisions.'},
 'gc8_mixed_C8_C4':{'source':GC8,'run_id':37901930897,'durable':{'commit':PUB56,'url':gitlink(PUB56,mixed_zip),'git_blob':published56[mixed_zip]},'accepted_scope':'Original C8/C4 raw and reviews; not new workload execution.'},
 'gc8_C1_platform_final':{'source':GC8,'runs':[37901930897,37901931021], 'durable':{'commit':PUB16,'url':gitlink(PUB16,PREFIX+'round12-primary-platform-complete-and-C1',True)},'accepted_scope':'Final C1 and eighth platform cell/collector selected evidence; original48file selection was accepted and published.'},
 'gc8_lifecycle_backfill':{'source':GC8,'runs':[37901930818,37901930897],'artifacts':[11604870469,11604162920],
    'durable':{'commit':'da00e2802bd9304de698b263be9924e2dc96242f','url':'https://github.com/jyqj/codecortex/commit/da00e2802bd9304de698b263be9924e2dc96242f','internal_member':None},
    'accepted_scope':'1230 lifecycle samples/431 sessions; three-seed fake backfill768 requests. Immutable publication and accepted terminal map reused; unknown archive-internal member is not guessed.'},
 'gc8_soak':{'source':GC8,'run_id':37901930897,'job_id':113726259431,'artifact_id':11609019055,
    'durable':{'commit':PUBSOAK,'url':gitlink(PUBSOAK,soak_zip['repository_path']),'git_blob':soak_zip['git_blob'],
    'members':['runtime-review-Gc8/runtime-11609019055-primary-review-v2.json','runtime-review-Gc8/soak-11609019055-stdio-binding-review.json']},
    'accepted_scope':'3600.054553094s,3601operations,1201builds,2400compound reads; original resource/cache/branch/catalog controls and complete15table endpoint accepted.'},
 'gc8_recovery_platform_rollback':{'source':GC8,'run_id':37901931021,'recovery_artifact_id':11604900056,'collector_artifact_id':11605154697,
    'durable':{'commit':PUB56,'url':gitlink(PUB56,recovery_zip),'git_blob':published56[recovery_zip],'internal_member':None},
    'final_matrix_durable':{'commit':PUB16,'url':gitlink(PUB16,PREFIX+'round12-primary-platform-complete-and-C1',True)},
    'accepted_scope':'Original recovery matrix/backup and historical277f schema24↔Gc8 schema25, plus all8 cold platform cells and original collector. Local recovery not_run entries stay not_run and are not rewritten as passed.'},
 'gc8_related_CI_and_gates':{'source':GC8,'CI_run_id':37901930820,'gate_run_id':37901930843,'gate_artifact_id':11603892263,
    'actual_CI_checkout':None,'durable':{'commit':PUB56,'url':gitlink(PUB56,ci_gates_zip),'git_blob':published56[ci_gates_zip],'internal_member':None},
    'accepted_scope':'Original CI/source-proof checkout bridge and six original gate Rust tests plus seven retained comparison CLI outcomes1/1/1/1/2/2/2, already accepted. Full checkout identity is retained inside original archive and not guessed from a prefix here.'},
 'g2_complete_actual_acquisition':{'source':g2['source_G'],'product_P':g2['product_P'],'review_R':g2['review_R'],'run_id':g2['run_id'],'attempt':g2['run_attempt'],
    'feature_scope':'explicitly_enabled_db_lock_observation; separate from default-build latency cohorts',
    'cells':[ {k:c[k] for k in ['configured_C','actual_call_peak','original_operations','artifact_id','job_id']} for c in g2['cells']],
    'review':digest(g2_path),'durable':{'commit':PUB18,'url':gitlink(PUB18,pack18zip['repository_path']),'zip_sha256':pack18zip['sha256'],'zip_git_blob':pack18zip['expected_git_blob'],'member':g2member['member']},
    'accepted_scope':'All C1/4/8/16 actual mixed acquisition counters, all900 operations per cell, original collector success and independent peer. Does not imply pure blocked-time/SQLite busy attribution or mandatory full saturation.'}
}

component_keys={
 'P8-007':['gc8_runtime_terminal_map','gc8_mixed_C8_C4','gc8_C1_platform_final','gc8_lifecycle_backfill','g2_complete_actual_acquisition','gc8_related_CI_and_gates'],
 'P8-008':['gc8_lifecycle_backfill','gc8_runtime_terminal_map','gc8_related_CI_and_gates'],
 'P8-009':['gc8_runtime_terminal_map','gc8_lifecycle_backfill','gc8_soak','gc8_related_CI_and_gates'],
 'P8-010':['gc8_soak','gc8_related_CI_and_gates'],
 'P8-011':['gc8_recovery_platform_rollback','gc8_lifecycle_backfill','gc8_related_CI_and_gates'],
 'P8-012':['gc8_recovery_platform_rollback','gc8_C1_platform_final','gc8_related_CI_and_gates'],
 'P8-013':['gc8_related_CI_and_gates'],
 'P8-016':['gc8_recovery_platform_rollback','gc8_related_CI_and_gates']}
summaries={
 'P8-007':'Gc8 four-C mixed/read/build/queue/tail/error and three-seed fake-backfill components accepted; separateG2 fullfour-C actualDB acquisition component now accepted. No deadlock/starvation was hidden in the observed scope.',
 'P8-008':'Gc8 lifecycle retains30 cold+400 reopen+400 uncached+400 cache-hit=1230samples,431sessions; originalN/distributions/CI all retained, no best-of. OS page cache not cleared and upper tail CI may be null.',
 'P8-009':'Accepted original client/server/process-tree roles, physical artifact/FTS accounting and reported/estimated/unavailable columns. Overlapping roles are not summed; unavailable/whole-tree-peak/billing remain unavailable rather than zero.',
 'P8-010':'Original one-hour workload3600.054553094s;3601operations=1201build+2400compoundread, real edits/deletes/branch switches/catalog compaction/cache reuse, original growth checks and15table endpoint accepted.',
 'P8-011':'Accepted original process-kill/network/cache-corruption/database-busy/replacement components with raw failures retained and fake-provider recovery/cost boundaries. Local subreport3passed/4not_run stays unchanged; distinct active/production controls are cited with their own coverage.',
 'P8-012':'Original8 cold cells Linux/macOS×Rust1.95/stable×default/semantic and final originalcollector all accepted; absent/fresh target and actual SDK/toolchain/binary receipts retained.',
 'P8-013':'Six original Rust failure contracts plus seven retained compareCLI outcomes[1,1,1,1,2,2,2] accepted. Quality/performance/lock failure and inconclusive/invalid states remain non-passes; raw/report preservation verified.',
 'P8-016':'Accepted controlled25→24→25/backup restoration using real277f2490fad3fa30f2812b5547bad033867c9ea5 andGc8, cache namespace/version isolation and default/semantic fallback; user source/config preserved. Historical dev binary is not a published release tag.'}
limitations={
 'P8-007':['Do not pool defaultGc8 and featureG2 latency distributions.','Actualpeaks1/4/7/12 are not claimed to equal configuredC at every point.','No new G1C8/C16 run, new1hour-per-C test or SQLite internalbusy attribution is required.'],
 'P8-008':['OS page cache state remains explicitly uncontrolled.','N30 cold tail bounds are allowed to remain null; no stablep99 or physical-cold-disk claim.'],
 'P8-009':['Provider-disabled cost/token fields remain null or unavailable.','No continuouswhole-process-treepeak claim and no newpeak gate.','When005/006results are accepted, append their own resource accounting under their actual sources without replacing prior component ledgers.'],
 'P8-010':['No continuousqueueoccupancy claim beyond recorded checks.','Do not multiply compoundread internalRPCs into samplecount.'],
 'P8-011':['Do not relabel localnot_run cases or claim physical powerloss coverage.','Original components were already accepted collectively; no new globalrecovery rerun is added solely because main advanced.'],
 'P8-012':['Not a claim that currentG8 has been measured on8 platforms.','CachedCI cannot replace these recordedcoldbuilds.'],
 'P8-013':['Deterministicfailurefixtures are not fullquality/holdout/provider performancecertification.'],
 'P8-016':['Keep actualschema pair,binary hashes andsource identities.','No publishedreleasepackage/tag or latestmain rollbackcertification is inferred.']}
rows=[]
for i in EIGHT:
 t=tasks[i]
 # Supplemental records already admitted into the original ledger are inherited, not re-audited here.
 inherited=[copy.deepcopy(e) for e in t.get('evidence',[]) if e.get('status')=='own_component_evidence_accepted_hard_dependencies_open']
 row={'task_id':i,'current_status':t['status'],'original_steps':t['steps'],'original_acceptance':t['acceptance'],
      'original_validations':t['validations'],'hard_dependencies':t['depends_on'],
      'unmet_direct_hard_dependencies_now':[d for d in t['depends_on'] if tasks[d]['status']!='done'],
      'already_done_direct_hard_dependencies':[d for d in t['depends_on'] if tasks[d]['status']=='done'],
      'own_scope':'already_accepted_components_at_their_declared_sources','accepted_summary':summaries[i],
      'evidence_index_keys':component_keys[i],'supplemental_previously_accepted_ledger_evidence':inherited,
      'remaining_known_own_scope_blockers':[],
      'new_missing_original_gate_found':False,'limitations_to_preserve':limitations[i],
      'pending_closure':{'actual_closure_date_utc':None,'fresh_ledger_commit':None,'closing_review_locator':None,
         'actual_dependency_acceptance_evidence':{d:None for d in t['depends_on'] if tasks[d]['status']!='done'},
         'set_status_only_after_original_dependencies_and_actual_closing_review':'done',
         'append_evidence':{'status':'accepted_original_task_with_source_scoped_components_after_dependencies','date':None,'source_and_run_refs':component_keys[i],
           'summary':summaries[i],'scope':'Original task scope; no source relabelling, pooledcohort, latesthead blanketperformance or release certification.'},
         'append_implementation_note_template':'[actual date] 原任务自身组件按所列真实source/run与不可变证据范围已接受，原依赖已逐项完成。保留原失败/not_run/unavailable及历史实现说明；不将各组件重标当前head，不扩大为发布或全局性能认证。'},
      'task_status_modified':False}
 rows.append(row)
dump('eight-task-pending-closeout-fields.json',{'schema_version':1,'apply_now':False,'current_counts':{'total':192,'done':163,'remaining':29},'rows':rows})
dump('reused-accepted-evidence-index.json',{'schema_version':1,'scope':'Previously accepted component scope and exact existing durable locators; no new full re-review.',
 'records':index,'source_proof_null_policy':'A missing local archive-internal member or fullcheckout string is null, not fabricated. A confirmed immutable archive/directory link is sufficient location and is not an added gate.',
 'definition_and_reuse_inputs':[ledger_id,digest(runtime_path),digest(g2_path),digest('/dev/shm/todo-audit-round21-original-ten-decision/original-ten-minimal-decision.json'),digest('/dev/shm/root-round22/56cf-original-commit-file-list.json')],
 'prior_interpretations_superseded':['The old decision saying005and006must share one study is superseded by the accepted independentcold005 plus separateG8fullstage006scope review.','Gc8terminalmap old onlyscale shorthand is supplemented by later acceptedG2 actualDBacquisition evidence; do not erase either history.']})

oldprep=Path('/dev/shm/todo-audit-round21-005-006-acceptance-preparation')
for n in ['P8-005-pending-fields.json','P8-006-pending-fields.json']:
 (OUT/n).write_bytes((oldprep/n).read_bytes())
study_binding=read('/dev/shm/execution-recon-recovery-20261009/round21-G8B-study-37962416564/binding.actual-G8B-run37962416564.json')
updates=[]
for number,i in enumerate(TEN,1):
 t=tasks[i]
 updates.append({'task_id':i,'selector':'tasks entry with id == task_id; never array offset',
  'expected_current_status':'in_progress','required_done_IDs':t['depends_on'],
  'definition_sha256':hashlib.sha256(json.dumps({k:t[k] for k in ['steps','acceptance','depends_on']},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
  'fields_input':('P8-005-pending-fields.json' if i=='P8-005' else 'P8-006-pending-fields.json' if i=='P8-006' else 'eight-task-pending-closeout-fields.json#'+i),
  'conditional_status_change':{'from':'in_progress','to':'done'},'apply_now':False,
  'actual_acceptance_review':None,'actual_dependency_closeout_checked':None,
  'expected_counts_after_this_update_if_no_external_changes':{'done':163+number,'remaining':29-number},
  'preserve':['steps','acceptance','scope','depends_on','validations','required_for','all existingevidence/implementation_notes','all conditional tasks not activated']})
combined={'schema_version':1,'artifact_kind':'pending_ID_selected_update_input_not_applied_patch','apply_now':False,
 'observed_ledger':ledger_id,'counts_now':{'total':192,'done':163,'remaining':29},
 'ordered_original_IDs':TEN,'updates':updates,
 'selected_studies':{'P8-005':{'source':'044c008c9459cfa61e7701db2eb868342c508a39','run_id':37954851017,'attempt':1,'acceptance':None},
 'P8-006':{'source':'4fe927488d5cb7f26bd27c7624745fb1b6ca202b','run_id':37962416564,'attempt':1,'binding_original_record':study_binding,'acceptance':None}},
 'timing_rule':'005 may close once its own complete independentcold evidence and originaldependencies are accepted, without waiting006. Every subsequentupdate waits its originaldependencies; no automaticbulk done.',
 'cohort_rule':'Distinct complete component dossiers may use their actual sources. Within either selectedstudy its fixedsource/binary/driver/population stay exact. Do not poolcold044/G8/Gc8/C3ff or turn partialfailed samples into acceptedpopulation.',
 'fresh_write_rule':['Read freshmain tasks.json and preserve every externalnote/evidence/definition.','MatchIDs and verifyoriginaldefinitions/dependencies remain unchanged; resolve actualchanges rather than overwrite.','Fill actualaccepted outcomes and durablelocators only; pendingnull values are not accepted evidence.','Append evidence/implementation_notes and only then change eligible originalstatus/subgate.','Recompute counts and navigation from actualledger, not this prospectivecountcolumn.'],
 'original_derived_view_commands_after_real_acceptance':['python3 scripts/code_index_plan.py --write','python3 scripts/code_index_plan.py'],
 'original_view_files':['docs/roadmap/code-index-v2/05-TODO.md','README.md','docs/roadmap/code-index-v2/README.md','docs/roadmap/code-index-v2/08-HANDOFF.md'],
 'task_state_modified':False,'product_tests_or_measurements_run':False,'new_acceptance_requirements_added':False}
dump('ten-task-dependent-update-input.json',combined)
print(json.dumps({'status':'prepared_not_applied','tasks':len(TEN),'eight_component_rows':len(rows),'new_own_scope_blockers_found':0,'done':163,'remaining':29,'maximum_future_done_if_allten_originalaccepted':173},sort_keys=True))
