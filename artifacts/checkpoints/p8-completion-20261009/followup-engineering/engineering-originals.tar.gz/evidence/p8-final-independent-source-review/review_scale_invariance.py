"""Read-only fixed Git input comparison; does not relabel original execution."""
import hashlib
import json
from pathlib import Path
import subprocess

out = Path(__file__).resolve().parent
repo = out.parent / 'codecortex-runtime-followup-sparse'
old = 'bb9a96d71622458c39a143055360cc97f0d11d78'
new = 'd0fe84a3e3f556c4f5907cc62190b20902a9f84d'
reviewed = '570b2afb33d19cb56e110fa0130b529541327fdd'
def git(*args): return subprocess.check_output(['git', '-C', str(repo), *args])
def tree(ref):
    result = {}
    for line in git('ls-tree', '-r', '-z', ref).split(b'\0'):
        if line:
            metadata, path = line.split(b'\t', 1)
            mode, kind, oid = metadata.decode().split()
            result[path.decode()] = {'mode': mode, 'kind': kind, 'git_blob': oid}
    return result
trees = {ref: tree(ref) for ref in (old, new, reviewed)}
delta = sorted(path for path in set(trees[old]) | set(trees[new]) if trees[old].get(path) != trees[new].get(path))
expected = ['scripts/p8_backfill.py', 'scripts/p8_cold_build.py', 'scripts/p8_runtime.py',
            'scripts/tests/test_p8_platform.py', 'scripts/tests/test_p8_runtime.py']
assert delta == expected
product = sorted(path for path in trees[old] if path.startswith('crates/') or path in ('Cargo.toml', 'Cargo.lock'))
intake = json.loads((out / 'intake-570b2afb.json').read_text())
assert len(product) == 1087 and set(product) == set(intake['complete_inputs'])
assert all(trees[old][path] == trees[new][path] == trees[reviewed][path] for path in product)
critical = ['.github/workflows/p8-scale.yml', 'scripts/p8_scale_matrix.py', 'scripts/p7_build_identity.py',
            'scripts/p8_runner_capacity.py', 'scripts/tests/test_p8_scale_matrix.py',
            'scripts/tests/test_p8_runner_capacity.py',
            'crates/cc-eval/Cargo.toml', 'crates/cc-eval/src/bin/p8-scale.rs',
            'crates/cc-eval/src/bin/p8-oracle.rs', 'crates/cc-eval/src/benchmark/p8_scale.rs',
            'crates/cc-eval/src/benchmark/oracle.rs', 'crates/cc-eval/src/benchmark/oracle/streaming.rs',
            'crates/cc-eval/src/benchmark/mutation_case.rs', 'crates/cc-eval/src/benchmark/mutations.rs',
            'crates/cc-eval/src/benchmark/runner.rs', 'crates/cc-eval/src/benchmark/sampler.rs',
            'crates/cc-eval/src/benchmark/manifest.rs', 'crates/cc-eval/src/runner.rs',
            'crates/cc-eval/src/synth.rs']
critical_records = {}
for path in critical:
    assert trees[old][path] == trees[new][path]
    body = git('show', old + ':' + path)
    critical_records[path] = trees[old][path] | {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
changed = {}
for path in delta:
    changed[path] = {ref: trees[ref][path] | {'sha256': hashlib.sha256(git('show', ref + ':' + path)).hexdigest()}
                     for ref in (old, new)}
manifest = intake['complete_inputs']
manifest_hash = hashlib.sha256((json.dumps(manifest, sort_keys=True, ensure_ascii=False, indent=2) + '\n').encode()).hexdigest()
record = {
    'schema_version': 1, 'verdict': 'accepted_scoped_input_invariance_only',
    'original_execution_source': old, 'candidate_source': new,
    'original_execution_tree': git('rev-parse', old + '^{tree}').decode().strip(),
    'candidate_tree': git('rev-parse', new + '^{tree}').decode().strip(),
    'original_run_id': 37830173594,
    'method': 'Independent full Git ls-tree mode/path/blob comparison. Product SHA256s reuse this reviewer earlier exact 570 intake only after every old/new/reviewed Git blob is proven identical. Named observer/workflow/native module bytes were read directly from fixed Git objects and hashed.',
    'heldout_corpus_bodies_read': False,
    'changed_files': changed,
    'unchanged_complete_crate_cargo_input_count': len(product),
    'unchanged_complete_crate_cargo_manifest_sha256': manifest_hash,
    'unchanged_complete_crate_cargo_inputs': {path: trees[old][path] | {'sha256': manifest[path]} for path in product},
    'unchanged_critical_inputs': critical_records,
    'dependency_review': {
        'python_driver_local_imports': ['scripts/p7_build_identity.py'],
        'driver_source_inventory': ['scripts/p8_scale_matrix.py', 'scripts/p7_build_identity.py'],
        'capacity_script_local_imports': [],
        'scale_workflow_entrypoints': ['scripts/p8_scale_matrix.py', 'scripts/p8_runner_capacity.py'],
        'native_scope': 'All production and evaluator Rust, build scripts, crate manifests, Cargo.toml and Cargo.lock remain byte and mode identical; this includes actual CodeIndexBackend, generator, full fifteen-table oracle and controls.',
        'five_changes_outside_scale_execution': 'Backfill Cargo feature flag; mixed/soak runtime failure cleanup/statistics; platform collector failure-receipt main branch; corresponding two Python test files. The scale driver/capacity/workflow do not import these changed Python modules.'},
    'unchanged_protocol': {
        'scales': [1000, 5000, 10000, 50000, 100000], 'repetitions': 30, 'shards_per_scale': 30,
        'total_shards': 150, 'groups': 50, 'total_measurements': 1500,
        'capacity_profile': 'scale_capacity_v1', 'scale_dirty_budget': 200,
        'scale_max_resume_builds': 1024, 'fanout_dirty_budget': 8, 'fanout_max_resume_builds': 128,
        'deadline_ms': 18000000, 'workflow_measure_timeout_minutes': 350,
        'raw_limit_bytes': 536870912, 'canonical_limit_bytes': 17179869184,
        'scratch_limit_bytes': 8589934592, 'max_rows_per_table': 5000000,
        'max_row_bytes': 1048576, 'sorting_cache_kib': 2048,
        'free_bytes_rule': 'files * 262144 + 4294967296',
        'all_fifteen_tables_full_value_equality_duplicates_and_complete_closure': 'unchanged',
        'heterogeneous_environment_policy': 'heterogeneous_stratified_coverage_v1',
        'pooled_latency_or_stable_tail_claim': False,
        'success_protocol': 'unchanged strict validate_build -> every complete validate_shard/inspect_raw -> combine; all exact source/binary/raw identities and 1500 denominators required'},
    'boundaries': [
        'This is static source-input invariance, not success of the pending original G 150-shard run.',
        'Original build executable, observed engine head, driver_source, source_commit/tree, receipts, raw and capacity evidence remain G; no rewrite to d0 or a future published P3.',
        'Strict scale validator binds driver_source source_commit as well as bytes. Replay original G build/shards from exact G, not from the newer checkout.',
        'Identical source inputs do not assert independently rebuilt binaries or execution provenance are identical; actual executable and source identity remain separately bound.',
        'No missing, failed, not_run or peer-source shard can fill the G population; all capacity artifacts and raw still require independent complete verification.',
        'Any later use of original G observations for task evidence must explicitly cite original G and this bounded change-impact review; it is not a new-source execution attestation or automatic TODO/release approval.'
    ],
}
target = out / 'scale-input-invariance-G-to-d0fe84a3.json'
target.write_text(json.dumps(record, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
print(json.dumps({'review': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
                  'unchanged_product_inputs': len(product), 'critical_paths': len(critical_records), 'changed_paths': len(delta)}))
