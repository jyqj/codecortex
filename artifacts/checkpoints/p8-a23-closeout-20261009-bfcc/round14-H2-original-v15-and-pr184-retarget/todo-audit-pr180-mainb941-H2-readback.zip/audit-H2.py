import ast,copy,difflib,hashlib,json
from pathlib import Path
OUT=Path(__file__).resolve().parent
PLAN=Path('/dev/shm/todo-audit-pr180-merge-plan')
module=ast.parse((PLAN/'audit-complete-trees.py').read_text())
exec(compile(ast.Module(body=[x for x in module.body if isinstance(x,ast.FunctionDef)],type_ignores=[]),'reused-tree-object-functions','exec'))
def updated(rows, entries):
 r=copy.deepcopy(rows)
 for item in entries:
  p=item['path'];r[p]=item
  parts=p.split('/')
  for i in range(1,len(parts)):
   d='/'.join(parts[:i]);r.setdefault(d,{'path':d,'mode':'040000','type':'tree','sha':'0'*40})
 return r
old=json.loads(Path('/workspace/scratch/bfccb8494ba0/root-round13/current-merge-trees-transfer/extracted/pr180head4652.json').read_text())
base={r['path']:r for r in old['tree']}
P=updated(base,json.loads(Path('/dev/shm/todo-audit-pr180-tree-elements/create-tree-request.json').read_text())['tree_elements'])
assert compute_trees(list(P.values()))['']=='9ae248f8e0c42a8a7389e26e3f44710dfb029640'
installation=json.loads(Path('/dev/shm/todo-audit-pr180-generated-G-f89d5fee/prepared-R9-G2-H7-installation-map.json').read_text())
R=updated(P,installation['R']['only_added_leaves'])
G=updated(R,installation['G']['only_changed_leaves'])
H=updated(G,installation['H']['only_added_leaves'])
assert compute_trees(list(H.values()))['']=='50fbb7abde9de3535b91beb3265cedc30ff86681'
main55=json.loads((PLAN/'new-main55aa-complete-derived-tree.json').read_text())
main=json.loads((OUT/'mainb941-complete-derived-tree.json').read_text())
assert compute_trees(main['tree'], '6ed5ad8ed24aa6563184b737a36c4e2fe5d87de8')['']=='6ed5ad8ed24aa6563184b737a36c4e2fe5d87de8'
Pm,Hm,Bm,Mm=(leafmap(v) for v in [list(P.values()),list(H.values()),main55['tree'],main['tree']])
is_product=lambda p:p.startswith('crates/') or p in ('Cargo.toml','Cargo.lock')
product_changes_55_main=[p for p in different(Bm,Mm) if is_product(p)]
product_main_H=[p for p in different(Mm,Hm) if is_product(p)]
assert product_changes_55_main==sorted(['crates/cc-index/src/dispatch_synthesis/interface_dispatch.rs','crates/cc-index/src/dispatch_synthesis/interface_dispatch_tests.rs','crates/cc-index/src/indexer_phases/snapshot.rs','crates/cc-index/tests/full_snapshot_empty_config.rs'])
previous_product_55_H=[p for p in different(Bm,Hm) if is_product(p)]
expected_main_H=sorted((set(previous_product_55_H)-set(product_changes_55_main))|{'crates/cc-index/src/indexer_phases/snapshot.rs'})
assert product_main_H==expected_main_H
for p in product_changes_55_main:
 if not p.endswith('indexer_phases/snapshot.rs'): assert identity(Mm[p])==identity(Hm[p])
snap={}
for who,commit in [('main','b9412406e11422d7cf914458a8bfbbd58cf94eaa'),('H','399a71a4c11e7041ce9946fba4d3f72200c47155')]:
 x=json.loads((OUT/('snapshot-'+commit+'.json')).read_text());b=x['content'].encode();p='crates/cc-index/src/indexer_phases/snapshot.rs'
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==({'main':Mm,'H':Hm}[who][p]['sha'])
 snap[who]=x['content']
assert snap['main'].replace('txn.write_file_data(write_units, chunk_blobs)?;', 'txn.write_file_data_for_rebuild(write_units, chunk_blobs)?;',1)==snap['H']
(OUT/'mainb941-to-H-snapshot.diff').write_text(''.join(difflib.unified_diff(snap['main'].splitlines(keepends=True),snap['H'].splitlines(keepends=True),fromfile='mainb941/snapshot.rs',tofile='H399a/snapshot.rs')))
input_map=json.loads(Path('/dev/shm/todo-audit-pr180-v15-binding-preparation/actual-P-mechanical-review-inputs.json').read_text())
inventory=input_map['actual_input_mode_blob_inventory']
assert len(input_map['complete_inputs'])==1093 and len(input_map['validation_inputs'])==139
assert len(input_map['paths'])==59
assert set(inventory)==set(input_map['complete_inputs'])|set(input_map['validation_inputs'])
assert all(identity(Hm[p])==identity(v) for p,v in inventory.items())
validation_main_H=[p for p in input_map['validation_inputs'] if identity(Mm.get(p))!=identity(Hm[p])]
assert not validation_main_H
main_changes=different(Bm,Mm)
docs=[p for p in main_changes if p=='README.md' or p.startswith('docs/')]
assert all(identity(Hm.get(p))==identity(Bm.get(p)) for p in docs)
bindings=['scripts/reviewed-source-registry-v15.json','scripts/verify_reviewed_source_v15.py']
assert set(main_changes)==set(product_changes_55_main)|set(docs)|set(bindings)|{p for p in main_changes if p.startswith('artifacts/')}
artifact_conflicts=[p for p in Mm.keys()&Hm.keys() if p.startswith('artifacts/') and identity(Mm[p])!=identity(Hm[p])]
assert not artifact_conflicts, artifact_conflicts
artifact_adds=sorted(p for p in Mm if p.startswith('artifacts/') and p not in Hm)
elements=[dict(path=p,**{k:Mm[p][k] for k in ['mode','type','sha']}) for p in sorted(docs+artifact_adds)]
H2=updated(H,elements);H2m=leafmap(list(H2.values()));tree=compute_trees(list(H2.values()))['']
assert all(identity(H2m[p])==identity(v) for p,v in inventory.items())
assert all(identity(H2m[p])==identity(Hm[p]) for p in bindings+['.github/workflows/ci.yml'])
assert all(identity(H2m[p])==identity(v) for p,v in Hm.items() if p not in docs)
assert all(identity(H2m[p])==identity(v) for p,v in Mm.items() if p.startswith('artifacts/'))
assert all(identity(H2m[p])==identity(Mm[p]) for p in docs)
assert len(H2m)==len(Hm)+len(artifact_adds)
assert different(Hm,H2m)==sorted(docs+artifact_adds)
retained_different=sorted(p for p in Mm if identity(H2m[p])!=identity(Mm[p]))
assert retained_different==sorted([p for p in expected_main_H if p in Mm]+bindings)
request={'repository_full_name':'jyqj/codecortex','base_tree_sha':'50fbb7abde9de3535b91beb3265cedc30ff86681','tree_elements':elements}
request_receipt=write('H2-create-tree-request.json',request)
report={
 'kind':'read_only_complete_tree_nonloss_forward_merge_plan',
 'observation':'Official commit and immutable Git tree data; no mutation, execution or task change.',
 'H':{'commit':'399a71a4c11e7041ce9946fba4d3f72200c47155','tree':'50fbb7abde9de3535b91beb3265cedc30ff86681'},
 'new_main':{'commit':'b9412406e11422d7cf914458a8bfbbd58cf94eaa','tree':main['sha'],'parents':['55aa2bcf355441585bcf980e1d6f4fab8eebe59d','d7426175ae21a9619cbcb393e41ec535695972d1']},
 'H2':{'commit':None,'predicted_tree':tree,'ordered_parents':['399a71a4c11e7041ce9946fba4d3f72200c47155','b9412406e11422d7cf914458a8bfbbd58cf94eaa'],'create_tree_request':request_receipt},
 'counts':{'main55_to_b941_total_changes':len(main_changes),'main55_to_b941_artifact_changes':sum(p.startswith('artifacts/') for p in main_changes),'H2_added_artifacts':len(artifact_adds),'H2_updated_docs':len(docs),'H2_tree_elements':len(elements),'H2_deletes':0,'product':1093,'delta':59,'validation':139},
 'product_changes_55aa_to_b941':product_changes_55_main,
 'three_of_four_181_product_mode_blobs_already_exact_H':True,
 'snapshot_only_difference':'At current line119, main uses txn.write_file_data; H retains txn.write_file_data_for_rebuild. All remaining bytes including deferred empty-input preparation equal; retaining H preserves prior opt-in rebuild contract.',
 'main_product_vs_H_exact_differences':{p:{'main':Mm.get(p),'H':Hm.get(p)} for p in product_main_H},
 'main55_vs_H_preexisting_product_differences':previous_product_55_H,
 'all_current_validation_input_mode_blobs_equal_main_and_H':True,
 'all_1093_product_and_139_validation_inputs_H2_equal_actual_P_c92':True,
 'bindings_CI_and_canonical_R_unchanged_from_H':True,
 'canonical_R':{'source':'c92eb5ac7ece70d1f62271d7e2dacac513c285b5','review':'f89d5feec91ae611d52614b8fe217bcd7fd5cf64','path':'artifacts/checkpoints/p8-public-api-merge-bfcc-20261009/independent-source-review.json','sha256':'9fa93a69e2e4be49f1262ff349fcddad18967a5c8e732144292456a24751208f'},
 'docs_updated_to_new_main':docs,'artifact_additions':artifact_adds,'artifact_content_conflicts':artifact_conflicts,
 'all_prior_H_artifact_mode_blobs_preserved':True,'all_new_main_artifact_mode_blobs_preserved':True,
 'only_main_mode_blobs_intentionally_not_selected':retained_different,
 'source_contract':'Original v15 admits fixed P/R product/validation bytes, protected history, selected CI and guard/registry; current HEAD is not required to equal P or G. H2 is a publication-only descendant with unchanged admitted domains. No new R/G is logically required by original guard; run the original CLI at actual H2 once. Do not label old H execution as H2.',
 'history_preservation':'H2 parent H retains external1d39 P/R/G history and our P/R/G; second parent b941 retains external181 P/R/G history and merge. New archival R artifacts coexist.',
 'no_new_product_semantic_review_claim':True,
 'pending':['Root must create actual H2 and verify tree and ordered parents','Root original v15 execution at actual clean H2','Original PR CI at actual final checkout; no migrated execution credit','Original P8-007 DB-lock-wait gap and fixed Gc8 scale acceptance remain independently open'],
}
receipt=write('nonloss-H2-plan-and-source-identity.json',report)
print(json.dumps({'report':receipt,'request':request_receipt,'predicted_tree':tree,'counts':report['counts'],'docs':docs,'retained_main_differences':retained_different},indent=2))
