import hashlib, json, pathlib

ROOT = pathlib.Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'scale-intake-primary/installed-db-acquisition-R-G-review'
OUT.mkdir(exist_ok=True)
def load(p): return json.loads(p.read_text())
def tree_hash(items):
    parts=[]
    for item in sorted(items, key=lambda x: (x['path'] + ('/' if x['type']=='tree' else '')).encode()):
        mode=item['mode'].lstrip('0')
        parts.append(mode.encode()+b' '+item['path'].encode()+b'\0'+bytes.fromhex(item['sha']))
    raw=b''.join(parts)
    return hashlib.sha1(b'tree '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def normalized(items): return sorted([{k:e[k] for k in ['path','mode','type','sha']} for e in items], key=lambda x:x['path'])
parent_root = json.loads(load(ROOT/'scale-intake-primary/db-wait-cleanup-P-bb29-independent/github-api/root-tree.json')['content'])
actual = load(ROOT/'root-round15/final-R-official-read-0.json')
actual_root=load(ROOT/'root-round15/final-R-official-read-2.json')
assert actual['sha']=='51d5ed91e14ddb13eccb93ebd28311a3235075cc'
assert [x['sha'] for x in actual['parents']]==['bb290be2deaf4334863e09dbf47fe4ccc9625f2b']
assert actual['tree']['sha']==actual_root['sha']=='580814d03f9c32215811632040f00cef29384ec7'
assert tree_hash(parent_root['tree'])==parent_root['sha']
assert tree_hash(actual_root['tree'])==actual_root['sha']
assert normalized([x for x in parent_root['tree'] if x['path']!='artifacts'])==normalized([x for x in actual_root['tree'] if x['path']!='artifacts'])
cached=load(pathlib.Path('/dev/shm/todo-audit-p8007-lock-observation-review/actual-P-review-inputs/actual-P-complete-derived-Git-tree.json'))
items={x['path']:x for x in cached['tree']}
assert items['artifacts']['sha']==next(x['sha'] for x in parent_root['tree'] if x['path']=='artifacts')
def children(prefix):
    return normalized([{**x,'path':p[len(prefix)+1:]} for p,x in items.items() if p.startswith(prefix+'/') and '/' not in p[len(prefix)+1:]])
newdir='artifacts/checkpoints/p8-db-acquisition-cleanup-bfcc-20261009'
assert newdir not in items
manifest=load(ROOT/'scale-intake-primary/db-wait-cleanup-P-bb29-independent/upload-manifest.json')
new_children=[]
for f in manifest['files']:
    assert str(pathlib.PurePosixPath(f['repository_path']).parent)==newdir
    raw=pathlib.Path(f['local_path']).read_bytes()
    assert len(raw)==f['bytes'] and hashlib.sha256(raw).hexdigest()==f['sha256']
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==f['git_blob']
    new_children.append({'path':pathlib.PurePosixPath(f['repository_path']).name,'mode':'100644','type':'blob','sha':f['git_blob']})
derived={newdir: {'sha':tree_hash(new_children),'tree':normalized(new_children)}}
for parent,child in [('artifacts/checkpoints',newdir),('artifacts','artifacts/checkpoints')]:
    old=children(parent)
    assert tree_hash(old)==items[parent]['sha']
    entries=[x for x in old if x['path']!=pathlib.PurePosixPath(child).name]
    entries.append({'path':pathlib.PurePosixPath(child).name,'mode':'040000','type':'tree','sha':derived[child]['sha']})
    derived[parent]={'sha':tree_hash(entries),'tree':normalized(entries),'parent_tree_sha':items[parent]['sha']}
expected_root=[x for x in normalized(parent_root['tree']) if x['path']!='artifacts']+[{'path':'artifacts','mode':'040000','type':'tree','sha':derived['artifacts']['sha']}]
assert tree_hash(expected_root)==actual_root['sha']
assert normalized(expected_root)==normalized(actual_root['tree'])
report={'schema_version':1,'actual_R':actual['sha'],'R_tree':actual_root['sha'],'sole_parent':actual['parents'][0]['sha'],'parent_tree':parent_root['sha'],'only_added_artifact_blobs':manifest['files'],'derived_three_changed_branches':derived,'all_other_root_subtrees_unchanged':True,'expected_R_tree_from_exact_parent_and_only_three_blobs_matches_official':True,'official_subtree_readback_pending':True}
with (OUT/'R-three-branch-preparation.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({'requests':[{'path':k,'sha':v['sha'],'url':'https://api.github.com/repos/jyqj/codecortex/git/trees/'+v['sha']} for k,v in derived.items()],'derived_R_root_matches':True}))
