"""Read-only independent identity checks and review receipt generation."""
import ast,hashlib,json,subprocess,datetime
from pathlib import Path
BASE=Path(__file__).resolve().parent
REPO=BASE.parents[1]/'codecortex';CANDIDATE=BASE.parents[1]/'pr-audit/cache-observer-candidate/candidate-fixed'
M4='d381f413bee3606bdc7410a73be855a0aab4aabb';G3='24b0cba53178d14ef6c02355ee271fa0067be3e0'
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def sha(b):return hashlib.sha256(b).hexdigest()
def snapshot(commit):
 result={}
 for line in git('ls-tree','-r',commit,'--','scripts').decode().splitlines():
  prefix,name=line.split('\t');mode,kind,blob=prefix.split();assert kind=='blob'
  result[name]=dict(mode=mode,sha256=sha(git('show',commit+':'+name)),blob=blob)
 return result
baseline=snapshot(M4)
changes=[];inputs={}
for n,old in baseline.items():
 b=(CANDIDATE/n).read_bytes();inputs[n]=dict(bytes=len(b),sha256=sha(b),baseline=old)
 if sha(b)!=old['sha256']:changes.append(n)
assert changes==['scripts/p8_runtime.py']
added='scripts/tests/test_p8_runtime_cache.py';b=(CANDIDATE/added).read_bytes()
owner_test=git('show',G3+':'+added)
new_test_ast=ast.parse(b)
new_test_ast.body=[node for node in new_test_ast.body if not (isinstance(node,ast.ClassDef) and node.name=='CacheTerminalRetentionTests')]
assert ast.dump(new_test_ast,include_attributes=False)==ast.dump(ast.parse(owner_test),include_attributes=False)
inputs[added]=dict(bytes=len(b),sha256=sha(b),origin=G3,origin_sha256=sha(owner_test),added_regression_class='CacheTerminalRetentionTests')
assert inputs['scripts/p8_runtime.py']['sha256']=='bc33ed073a2e035912a4d6f1794ceec8b836243c2bbb46c8a4dddfcdda791559'
assert inputs[added]['sha256']=='c4ec698532f033f6364441cad4f6f41a19b3b020ffd0845b4d0e3eebb8c281d2'
expected=set(baseline)|{added}
actual={p.relative_to(CANDIDATE).as_posix() for p in (CANDIDATE/'scripts').rglob('*') if p.is_file() and '__pycache__' not in p.parts}
assert actual==expected
oldtree=ast.parse(git('show',M4+':scripts/p8_runtime.py'));g3tree=ast.parse(git('show',G3+':scripts/p8_runtime.py'));newtree=ast.parse((CANDIDATE/'scripts/p8_runtime.py').read_text())
def defs(t):return {n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b,c=defs(oldtree),defs(g3tree),defs(newtree)
helpers=['cache_identity','cache_lookup','require_stable_hybrid','validate_cache_probe','soak_read','soak_cache_summary']
assert set(c)==set(a)|set(helpers)|{'terminal_operation_metadata'}
assert all(c[n]==b[n] for n in helpers)
unchanged=[n for n in a if n!='run'];assert all(c[n]==a[n] for n in unchanged)
sourceproof=dict(schema_version=1,base=M4,cache_origin=G3,baseline_script_count=len(baseline),candidate_script_count=len(expected),modified=changes,added=[added],all_other_scripts_exact=True,all_other_top_level_functions_and_classes_unchanged=unchanged,cache_helpers_ast_equal_owner=helpers,new_metadata_only_helper='terminal_operation_metadata',owner_cache_test_ast_unchanged_except_two_added_regressions=True,files=inputs)
(BASE/'integrated-source-independent-proof.json').write_text(json.dumps(sourceproof,indent=2)+'\n')
report=dict(schema_version=1,reviewer='/root/runtime_review',author='/root/pr_audit',reviewed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),conclusion='accepted_scoped_minimal_M4_plus_G3_observer_integration',blocking_findings=[],resolved_findings=[dict(severity='P2',path='scripts/p8_runtime.py',description='Nested cache response bodies bypassed the raw budget via terminal sidecar; fixed by separate metadata-only projection with omitted-body markers and without mutating original rows.',before='retention-budget-before/result.json',after='retention-budget-after/result.json',original_raw_retention_error_preserved=True)],base=M4,cache_origin=G3,owner_product='f5518ca6d21f54cfd324e33edc3b739608ae28b8',owner_review='5463095d9650402161a23a332c2505b15c4d88b6',runtime_sha256=inputs['scripts/p8_runtime.py']['sha256'],cache_test_sha256=inputs[added]['sha256'],source_proof='integrated-source-independent-proof.json',
controls=dict(existing_unmodified_unittest_command="python -m unittest discover -s scripts/tests -p 'test_p8_runtime*.py' -v",working_directory=str(CANDIDATE),test_count=61,exit_code=0,elapsed_seconds=20.399,output_retention='fixed-runtime-controls.log; full original unittest stdout/stderr retained. Earlier59/control results retain their b794 source and are not relabeled.',additional_independent_run_controls='synthetic-run-boundaries/result.json',additional_count=2,additional_fixed_source_retention_run='retention-budget-after/result.json',run_control_log='run-boundary-controls.log',scope='Synthetic control execution only; not actual native product throughput or one-hour certification'),
original_probe='original-probe-independent-result.json',original_probe_validator_applicability='Original replay binds b794; the six validator/helper ASTs are independently identical in final bc33. No execution identity is relabeled.',
findings=[
 dict(severity='info',path='scripts/p8_runtime.py',lines=[596,613,626,637],result='Soak read/build share the original write admission lock; mutation, cache_previous and preceding_mutation update while held. Finished_ns is recorded before release; replay sorts actual call_start and completed builds, retaining admission wait. Mixed continues the original parallel path.'),
 dict(severity='info',path='scripts/p8_runtime.py',lines=[160,183,236,317],result='A retained before/after native PID plus full generation isolates exactly one real hybrid lookup counter delta. Each accepted cache response has the exact current owned stable.py entity/span bytes; generation changes require miss/refill then subsequent same-generation hit. No-op generation retains hit.'),
 dict(severity='info',path='scripts/p8_runtime.py',lines=[492,500,307,366],result='Formal planned 3601 operations and 2400 compound reads remain. Four RPCs belong to one latency/outcome sample, not four samples. Limits are explicit 30/60/60/30, sum180 before admission wait; 60 remains maximum single-RPC timeout, so old symbol-only latency is not directly comparable.'),
 dict(severity='info',path='scripts/p8_runtime.py',lines=[357,371,793,798],result='Four cache quarters use actual hybrid completion and actual build completion. First and last offered timestamps alone cannot certify coverage. Existing >=1h actual work, RSS trend/coverage, compaction, branch switches and all original outcome gates remain.'),
 dict(severity='info',path='scripts/p8_runtime.py',lines=[647,683,716,820,838,847],result='M4 constructor-pending, rejected-submit admission gate, KeyboardInterrupt preservation, terminal-retention and all-owned-writers seal predicate remain intact outside reviewed cache inserts and the new sidecar metadata-only projection. Independent partial run controls preserve original failure and actual prefix counts, no statistics and no cache success.'),
 dict(severity='info',path='scripts/p8_runtime.py',lines=[748,759,780],result='Original independent full-control build, no-repair 15-table oracle invocation and product-vs-infrastructure exit1/2 distinction retained. Original raw replay runs once per offered operation; no endpoint validation was removed.')],
limits=[
 'This accepts the observer integration and engineering controls, not original P8-010 completion. No long Actions or native product execution was launched by this reviewer.',
 'The actual 14-read probe is original bb9 native product with P4-equivalent observer, 0.648456145 s; binary was read and hashed only. It does not prove M4/integrated product or one-hour behavior.',
 'Shared server PID and query pool counters prove process/pool reuse at this scope; individual OS-thread or semantic-worker identity is not claimed.',
 'The immutable stable target checks current bytes across surrounding project generations. This alone is not a changed-query-result invalidation test; the full fixture mutation and 15-table endpoint gates remain necessary.',
 'Partial cache summary on infrastructure failure is diagnostic and explicitly not certification. Its temporal origin differs; overall exit2/report status is authoritative. Receiver must not treat an isolated nested summary as task success.',
 'The two earlier interrupted-run controls remain bound to b794; final bc33 independently passes61 controls and the real run/Raw retention regression, with the cache helper AST unchanged.',
 'Final source/review/pins chain must bind these exact two changed files and reviewed controls. Existing G3 one-hour original run37846051479 must be independently read at its actual source; do not relabel it as the final integration.',
 'No roadmap status changed; original TODO remains29 and this scoped review adds no task closure.'
 ],task_complete=False,new_original_todos_complete=0,original_remaining=29)
(BASE/'independent-integration-review.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'conclusion':report['conclusion'],'script_inputs':len(expected),'baseline_scripts':len(baseline),'runtime_sha256':report['runtime_sha256'],'review_sha256':sha((BASE/'independent-integration-review.json').read_bytes()),'source_proof_sha256':sha((BASE/'integrated-source-independent-proof.json').read_bytes())},indent=2))
