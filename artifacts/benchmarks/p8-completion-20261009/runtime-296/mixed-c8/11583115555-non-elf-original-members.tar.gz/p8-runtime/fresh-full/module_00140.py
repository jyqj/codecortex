def stable_00140():
    return 140
