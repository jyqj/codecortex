import pathlib,json,hashlib,re
R=pathlib.Path('/workspace/scratch/bfccb8494ba0/pr180181-readonly')
O=pathlib.Path('/dev/shm/execution-recon-bfcc/pr180181')
F=json.load(open('/workspace/scratch/bfccb8494ba0/scale-intake-primary/historical-277f-peer/actual-P-complete-product-validation-inputs.json'))
old={x['path']:x for x in F['files']}
oldroot=json.load(open('/workspace/scratch/bfccb8494ba0/todo-audit-round12/recovery-platform-Gc8/historical-source-api/current-root-tree-api.json'))
def digest(b):return hashlib.sha256(b).hexdigest()
def gitblob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def data(sha):
    for root in [R,O]:
        p=root/'blobs'/sha
        if p.exists():
            b=p.read_bytes();assert gitblob(b)==sha,(sha,'blob mismatch');return b
    raise AssertionError(('missing',sha))
def read(name):
    for root in [O,R]:
        p=root/(name+'.json')
        if p.exists():return json.load(open(p))
    raise AssertionError(name)
def leaves(root,crates):
    a=read(root);b=read(crates);assert b['truncated'] is False
    return {**{v['path']:v for v in a['tree'] if v['path'] in ['Cargo.toml','Cargo.lock']},**{'crates/'+v['path']:v for v in b['tree'] if v['type']=='blob'}}
def tree_map(tree):return {v['path']:v for v in tree['tree']}
def delta(a,b):return [{'path':p,'before':a.get(p),'after':b.get(p)}for p in sorted(set(a)|set(b)) if (a.get(p,{}).get('sha'),a.get(p,{}).get('mode'))!=(b.get(p,{}).get('sha'),b.get(p,{}).get('mode'))]
base=leaves('rootbase','cratesbase');main=leaves('rootmain','cratesmain')
summary={};inventories={}
def stripped_guard(raw):return re.sub(r'^(PRODUCT|REVIEW|REVIEW_PATH|REGISTRY_SHA256) = .*$',lambda m:m.group(1)+' = PIN',raw,flags=re.M)
oldguard=data('1d0ef393a39839bb3d7c23f16a5202bf18bfb895').decode()
for n in ['180','181']:
    product=leaves('root'+n,'crates'+n);reg=read('registry'+n);review=read('review'+n)
    assert set(product)==set(reg['complete_inputs'])==set(review['complete_inputs'])
    actual={};reused=read_new=0
    for p,v in product.items():
        if p in old and v['sha']==old[p]['git_blob'] and v['mode']==old[p]['mode']:
            actual[p]=old[p]['sha256'];reused+=1
        else:
            actual[p]=digest(data(v['sha']));read_new+=1
    assert actual==reg['complete_inputs']==review['complete_inputs']
    for key in ['Cargo.toml','Cargo.lock','crates']:
        assert tree_map(read('rootP'+n))[key]==tree_map(read('rootR'+n))[key]==tree_map(read('root'+n))[key]
    r=read('root'+n);rt=tree_map(r);og=tree_map(oldroot)
    for p in ['.github','tests']:
        assert rt[p]['sha']==og[p]['sha'] and rt[p]['mode']==og[p]['mode']
    scripts=read('scripts180-head' if n=='180' else 'scripts181');sm={'scripts/'+x['path']:x for x in scripts['tree'] if x['type']=='blob'}
    val={};vchanged=[]
    for p,expect in reg['validation_inputs'].items():
        if p.startswith('scripts/'):
            v=sm[p]
            if v['sha']==old[p]['git_blob'] and v['mode']==old[p]['mode']:val[p]=old[p]['sha256']
            else:val[p]=digest(data(v['sha']));vchanged.append(p)
        else:val[p]=old[p]['sha256']
        assert val[p]==expect
    assert val==review['validation_inputs']; assert len(val)==139
    guard=(R/('guard'+n+'.py')).read_bytes();registry=(R/('registry'+n+'.json')).read_bytes();rr=(R/('review'+n+'.json')).read_bytes()
    assert gitblob(guard)==sm['scripts/verify_reviewed_source_v15.py']['sha']
    assert gitblob(registry)==sm['scripts/reviewed-source-registry-v15.json']['sha']
    assert digest(rr)==reg['review_sha256']
    assert stripped_guard(guard.decode())==stripped_guard(oldguard)
    pins={k:re.search(r'^'+k+r' = "([^"]+)"',guard.decode(),re.M).group(1) for k in ['PRODUCT','REVIEW','REVIEW_PATH','REGISTRY_SHA256']}
    assert pins['PRODUCT']==reg['product_source'] and pins['REVIEW']==reg['review_source'] and pins['REGISTRY_SHA256']==digest(registry)
    summary[n]={'product_count':len(product),'same_Gc8_path_mode_blob_reused_sha_count':reused,'different_new_blob_read_count':read_new,'validation_count':139,'validation_changed_vs_Gc8':vchanged,'base_product_delta_count':len(delta(base,product)),'main_f7_product_delta_count':len(delta(main,product)),'pins':pins,'registry_sha256':digest(registry),'review_sha256':digest(rr),'guard_logic_equal_after_only_four_pin_normalization':True,'P_R_public_head_product_domains_equal':True}
    inventories[n]={'product':[{**v,'path':p,'sha256':actual[p]} for p,v in sorted(product.items())],'validation':val,'base_delta':delta(base,product),'main_f7_delta':delta(main,product)}
for p in ['crates/cc-eval/src/benchmark/statistics.rs','crates/cc-eval/src/bin/p8-runtime-statistics.rs','crates/cc-index/src/resolver/catalog.rs','crates/cc-index/src/resolver/helpers.rs']:
    assert next(x for x in inventories['180']['product'] if x['path']==p)['sha']==main[p]['sha']
summary['main_175_179_four_product_paths_all_exact_in_180']=True
(O/'inventory-audit.json').write_text(json.dumps({'summary':summary,'inventories':inventories},indent=2)+'\n')
print(json.dumps(summary,indent=2))
