def stable_00391():
    return 391
