import datetime
import hashlib
import json
from pathlib import Path
import re

B = Path('/workspace/scratch/bfccb8494ba0')
O = B / 'todo-audit-round12/gates-Gc8'
A = B / 'pr-triage-primary-recovery/raw-pr178-c8be5afa/11603892263'
ROOT = A / 'attempt01/extracted'
RPATH = B / 'pr-triage-primary-recovery/runtime-review-Gc8/exact-canonical-R.json'
G = 'c8be5afaac568ffd40ef86d3795423c3b73c9f39'


def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def load(p):
    return json.loads(p.read_bytes())


def rec(p):
    return dict(path=str(p), bytes=p.stat().st_size, sha256=digest(p))


meta = load(A / 'github-metadata.json')
transport = load(A / 'attempt01/transport-receipt.json')
assert meta['workflow_run']['head_sha'] == G and meta['workflow_run']['id'] == 37901930843
assert transport['run_attempt'] == 1 and transport['status'] == 'transport_verified'
zip_path = Path(transport['original_zip_path'])
assert zip_path.stat().st_size == meta['size_in_bytes'] == 33020495
assert digest(zip_path) == meta['digest'].removeprefix('sha256:')
assert digest(RPATH) == 'c38d10f1b0d5935384039a6af7df6e8d222bc351a68d3137b09e664735ee9404'
review = load(RPATH)
report = load(ROOT / 'report.json')
source = report['source']
assert source['inputs'] == review['complete_inputs'] and len(source['inputs']) == source['input_count'] == 1090
assert source['source_commit'] == G and source['source_tree'] == '9b031be22a430e51e153cce6e80770ed885818e3'
assert hashlib.sha256((json.dumps(source['inputs'], ensure_ascii=False, sort_keys=True, indent=2)+'\n').encode()).hexdigest() == source['manifest_sha256']
assert report['exit_code'] == 0 and report['status'] == 'passed_original_failure_gates'
assert report['task_complete'] is False and report['release_approval'] is False
actual = {p.relative_to(ROOT).as_posix(): digest(p) for p in ROOT.rglob('*') if p.is_file()}
assert len(actual) == 337 and {k: v for k, v in actual.items() if k != 'report.json'} == report['files']
expected_names = ['unmeasurable_latency_cannot_pass_comparison', 'zero_measurement_gate_is_invalid', 'cli_quality_and_latency_failures_are_nonzero_and_keep_raw', 'cli_inconclusive_is_nonzero', 'cli_lock_failure_preserves_machine_readable_failure_and_raw', 'cli_bad_policy_is_recorded_without_overwriting_existing_report']
assert [c['test_name'] for c in report['cases']] == expected_names
summaries = []
cli_artifacts = []
for i, name in enumerate(expected_names):
    directory = ROOT / f'case-{i:02d}'
    case = load(directory / 'test-receipt.json')
    assert case == report['cases'][i]
    assert case['source'] == source and case['status'] == 'passed'
    assert case['package'] == 'cc-eval' and case['target'] == 'benchmark_cli'
    assert digest(directory / 'fault-test') == case['executable_sha256']
    for kind in ['build', 'execution']:
        step = case[kind]
        assert type(step['exit_code']) is int and step['exit_code'] == 0 and step['status'] == 'passed'
        for log, value in step['logs_sha256'].items():
            assert digest(directory / kind / log) == value
        command = load(directory / kind / 'command.json')
        assert command['command'] == step['command']
    assert case['execution']['command'][1:] == ['--exact', name, '--nocapture', '--test-threads=1']
    text = (directory / 'execution/stdout.log').read_text()
    assert f'test {name} ... ok' in text
    assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in text
    assert '--ignored' not in case['execution']['command']
    build_command = case['build']['command']
    assert build_command[1:] == ['test', '-p', 'cc-eval', '--locked', '--offline', '--no-run', '--message-format=json-render-diagnostics', '--test', 'benchmark_cli']
    cargo = [json.loads(line) for line in (directory / 'build/stdout.log').read_text().splitlines()]
    candidates = [x for x in cargo if x.get('reason') == 'compiler-artifact' and x.get('target', {}).get('name') == 'benchmark_cli' and x.get('executable')]
    assert len(candidates) == 1 and candidates[0] == case['cargo_artifact']
    assert candidates[0]['profile']['test'] is True and candidates[0]['target']['kind'] == ['test']
    assert candidates[0]['target']['src_path'].endswith('/crates/cc-eval/tests/benchmark_cli.rs')
    assert [x for x in cargo if x.get('reason') == 'build-finished'] == [dict(reason='build-finished', success=True)]
    cli_artifacts.extend(x for x in cargo if x.get('reason') == 'compiler-artifact' and x.get('target', {}).get('name') == 'cc-eval' and x.get('executable'))
    summaries.append(dict(index=i, name=name, build_exit=case['build']['exit_code'], test_exit=case['execution']['exit_code'], actual_argv=case['execution']['command'], source_inputs_equal_canonical_R=True, cargo_fresh=candidates[0]['fresh'], test_executable_sha256=case['executable_sha256'], original_stdout=rec(directory / 'execution/stdout.log'), original_stderr=rec(directory / 'execution/stderr.log')))
assert any(c == report['cli']['cargo_artifact'] for c in cli_artifacts)
assert report['cli']['cargo_artifact']['fresh'] is False
assert report['cli']['cargo_artifact']['profile']['test'] is False
assert digest(ROOT / 'cc-eval') == report['cli']['executable_sha256'] == 'e21fa0863c18ea447cf060384fc15ffe502ecb24f9a2627e2248c0373b037e9e'
assert {p.relative_to(ROOT).as_posix(): digest(p) for p in ROOT.rglob('*') if p.is_file()} == actual
result = dict(schema_version=1, kind='Gc8_original_six_failure_controls_static_independent_audit', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_commit=G, artifact_id=11603892263, run_id=37901930843, run_attempt=1, verdict='accepted_scoped', errors=[], canonical_R=rec(RPATH), complete_source_inputs=1090, original_report=rec(ROOT / 'report.json'), original_zip=rec(zip_path), retained_CLI=rec(ROOT / 'cc-eval'), original_file_count=337, all_original_hashes_unchanged=True, cases=summaries, original_controls=report['observed_controls'], seven_retained_cli_replays='separate_pending_execution', new_builds=0, new_Rust_test_runs=0, task_credit=0, remaining=29)
raw=(json.dumps(result,sort_keys=True,indent=2)+'\n').encode()
p=O/'original-six-independent-review.json'
with p.open('xb') as f:f.write(raw)
print(json.dumps(dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())))
