def stable_00404():
    return 404
