def stable_00133():
    return 133
