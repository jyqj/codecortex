import hashlib
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
from provenance_adapter import OUT, R, R_PATH, R_SHA, HOME, COMMIT, TREE, digest, json_bytes

api = OUT / 'historical-source-api'
previous_commit = '277f2490fad3fa30f2812b5547bad033867c9ea5'
pc = json.loads((api / 'previous-commit-api.json').read_text())
assert pc['sha'] == previous_commit
previous_tree = pc['tree']['sha']

def inventory(prefix):
    root = json.loads((api / (prefix + '-root-tree-api.json')).read_text())
    subtree = json.loads((api / (prefix + '-crates-tree-api.json')).read_text())
    assert root['truncated'] is False and subtree['truncated'] is False
    crates = next(x for x in root['tree'] if x['path'] == 'crates')
    assert crates['type'] == 'tree' and crates['sha'] == subtree['sha']
    rows = [x for x in root['tree'] if x['path'] in ('Cargo.toml', 'Cargo.lock')]
    rows += [dict(x, path='crates/' + x['path']) for x in subtree['tree'] if x['type'] != 'tree']
    assert all(x['type'] == 'blob' and x['mode'] in ('100644', '100755') for x in rows)
    assert len({x['path'] for x in rows}) == len(rows)
    return {x['path']: x for x in rows}

old, current = inventory('previous'), inventory('current')
assert len(old) == 704 and len(current) == 1090
assert set(current) == set(R['complete_inputs'])
assert all(current[p]['mode'] == R['source_modes'][p] for p in current)
derived, rows = {}, []
for path, row in sorted(old.items()):
    same = path in current and all(row[k] == current[path][k] for k in ('sha', 'mode', 'type'))
    if same:
        sha = R['complete_inputs'][path]
        method = 'canonical_R_SHA256_reuse_after_official_exact_path_mode_Git_blob_equality'
    else:
        raw = (OUT / 'historical-source-blobs' / row['sha']).read_bytes()
        assert len(raw) == row['size']
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == row['sha']
        sha = hashlib.sha256(raw).hexdigest()
        method = 'official_Git_blob_API_original_bytes_SHA256_and_Git_blob_recomputed'
    derived[path] = sha
    rows.append(dict(path=path, mode=row['mode'], git_blob=row['sha'], sha256=sha, method=method))

same = sum(x['method'].startswith('canonical') for x in rows)
assert same == 613 and len(rows) - same == 91
receipt = json.loads((HOME / 'product-previous/build-receipt.json').read_text())
identity = dict(source_commit=previous_commit, source_tree=previous_tree, input_count=704,
                manifest_sha256=hashlib.sha256(json_bytes(derived)).hexdigest(), inputs=derived)
assert derived == json.loads((HOME / 'product-previous/source-inputs.json').read_text())
assert derived == json.loads((HOME / 'actual-version-pair/previous-product/source-inputs.json').read_text())
assert receipt['source_before'] == receipt['source_after']
assert {k:v for k,v in receipt['source_before'].items() if k != 'source_root'} == {k:v for k,v in identity.items() if k != 'inputs'}
(OUT / 'historical-source-identity.json').write_bytes(json_bytes(identity))
result = dict(schema_version=1, status='accepted_exact_704_source_identity_bridge',
    previous_commit=previous_commit, previous_tree=previous_tree,
    current_commit=COMMIT, current_tree=TREE,
    canonical_R=dict(path=str(R_PATH),sha256=R_SHA),
    same_path_mode_blob=613, independently_received_original_difference_blobs=91,
    product_inputs=704, all_704_match_new_artifact_maps=True,
    manifest_sha256=identity['manifest_sha256'], entries=rows,
    official_api={p.name:dict(bytes=p.stat().st_size,sha256=digest(p)) for p in sorted(api.iterdir())},
    scope='Source identity only; no old product execution, build, runtime, rollback or task credit transferred.',
    todo_status_change=False)
(OUT / 'historical-source-bridge-review.json').write_bytes(json_bytes(result))
print(json.dumps({k:result[k] for k in ('status','previous_commit','previous_tree','product_inputs','same_path_mode_blob','independently_received_original_difference_blobs','manifest_sha256')}))
