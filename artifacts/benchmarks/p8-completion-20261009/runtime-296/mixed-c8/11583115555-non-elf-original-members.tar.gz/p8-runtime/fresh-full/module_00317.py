def stable_00317():
    return 317
