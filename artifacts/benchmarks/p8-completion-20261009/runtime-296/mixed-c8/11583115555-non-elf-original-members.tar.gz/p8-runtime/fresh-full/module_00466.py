def stable_00466():
    return 466
