from pathlib import Path
import hashlib,json,subprocess,re,datetime
root=Path('/workspace/scratch/2eaa00d0f93a/p8-staging-engineering-exact-source');out=Path(__file__).resolve().parent;source='8e542e644b06a83fc82d18d9896cf82f5b2d796e'
g=lambda *a:subprocess.check_output(['git',*a],cwd=root,stderr=subprocess.PIPE)
before={'head':g('rev-parse','HEAD').decode().strip(),'status':g('status','--porcelain=v1').decode()}
assert before['head']==source and not g('diff','--name-only','HEAD')
paths=['crates/cc-db/src/index_db_multi_insert.rs','crates/cc-db/src/index_db_write_batch.rs','crates/cc-db/src/snapshot_write_txn.rs','crates/cc-db/src/symbol_identity_store.rs','crates/cc-db/src/index_db_rebuild.rs','crates/cc-db/src/direct_writer.rs','crates/cc-db/src/sql/index_v1.sql']
manifest={};bodies={}
for p in paths:
 b=g('show',source+':'+p);bodies[p]=b.decode();assert b==(root/p).read_bytes();manifest[p]={'sha256':hashlib.sha256(b).hexdigest(),'git_blob':g('rev-parse',source+':'+p).decode().strip(),'bytes':len(b)}
writer=bodies[paths[1]];full=writer.split('    fn insert_file_data_impl(',1)[1]
multi=bodies[paths[0]];tables={'symbols':25,'symbol_refs':18,'call_edges':30,'routes':19,'semantic_edges':10,'dispatch_sites':11};checks={}
for table,cols in tables.items():
 scope=writer.split('    fn insert_symbol_refs_on(',1)[1].split('    /// Update only',1)[0] if table=='symbol_refs' else full
 pat='INSERT OR REPLACE INTO '+table+r'\(([^)]*)\) VALUES'
 old=re.findall(pat,scope);new=re.findall(pat,multi);assert len(old)==1 and len(new)==1 and old==new and len(old[0].split(','))==cols
 checks[table]={'columns':cols,'head_and_column_order_equal':True,'parameters_at_64':64*cols}
design=Path('/workspace/scratch/2eaa00d0f93a/p8-staging-cached-review-41236c3e/per-file-batching-design.md');b=design.read_bytes();review=(out/'review.md').read_bytes()
after={'head':g('rev-parse','HEAD').decode().strip(),'status':g('status','--porcelain=v1').decode()};assert after==before
x={'schema':'p8-per-file-batching-nonauthor-design-review-v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/acceptance_audit','status':'accepted_scoped_design_direction_with_mandatory_implementation_conditions','design':{'path':str(design),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)},'fixed_source':source,'fixed_tree':g('rev-parse','HEAD^{tree}').decode().strip(),'source_before':before,'source_after':after,'source_inputs_read':manifest,'six_binder_headers':checks,'review':{'path':str(out/'review.md'),'sha256':hashlib.sha256(review).hexdigest(),'bytes':len(review)},'mandatory_conditions':['Only SnapshotWriteTxn/full-specific new entry point; leave shared incremental/config path and globalmulti_insert unchanged.','Preserve independent WAL/FK and DirectWriter journalOFF/FK contracts; fail-closed publication is not proof of private physicalrollback.','symbols bothPK andsymbol_uidUNIQUE collisions, trigger/FTS and identitysurvivor at8/64 boundaries and acrossfiles.','Atmost64borrowedrefs and64KiB actualboundpayload with checked arithmetic, preflush and legaloversizedsingle fallback.','Actual old-vs-new complete rows/FTS/rowid/document/identity/failure tests plus original rebuild/scaleregessions before codeadmission.'],'author_concurrence':'scale_engineering message agrees full-only, two UNIQUE/FTS/survivor, and adapter-specific originalpragma/failure scope; original design byte unchanged.','unresolved_fatal_design_counterexample':None,'implementation_or_CI_approval':False,'actual_Cargo_SQLite_product_or_benchmark_execution':False,'preparation_attempt_note':'First inline header extractor failed because symbol_refs SQL is in its original called helper instead of textually inside full method; corrected to inspect that helper. Not a product/test failure; no candidate mutation or execution.','source_modified':False,'performance_claim':None,'TODO_closed':0,'TODO_remaining':29}
f=out/'review.json';f.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n');print('review_sha256',hashlib.sha256(f.read_bytes()).hexdigest());print('design_sha256',hashlib.sha256(b).hexdigest());print('static_six_header_checks',checks)
