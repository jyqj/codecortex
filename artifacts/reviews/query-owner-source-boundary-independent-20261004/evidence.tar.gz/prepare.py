from pathlib import Path
import json
r=Path('/workspace/independent-boundary-review');author=r/'author';s=(author/'boundary_driver.rs').read_text(); controls=json.loads((author/'control-contract.json').read_text()); extra=[]
def add(q,contract,explanation):extra.append({'query':q,'contract':contract,'explanation':explanation})
for phrase in ['(rather than Sink)','(instead of Sink)','“rather than Sink”','‘instead of Sink’','"rather than Sink"',"'rather than Sink'",'(RATHER\tTHAN Sink)','(rather than the Sink)','(instead of the Sink)']:
 add(f'Which Beacon API {phrase} accepts state?','comparative','Whole comparative clause has one matched prose wrapper; names/intent unchanged.')
for phrase in ['(rather than)','(instead of)','‘rather than’','"instead of"','RATHER\u00a0THAN','(rather, than)']:
 add(f'Which Beacon API {phrase} Sink accepts state?','comparative','Supported pair punctuation/case/whitespace extension.')
for phrase in ['rather:: than::','@rather @than','rather() than','rather than()','"rather" than','rather "than"','((rather) (than))','[rather] [than]','`rather()` than','rather `than()`','ratherThan insteadOf','rather‐than','rather\u200bthan']:
 add(f'Which Beacon API calls {phrase} with Commit?','owner','Separate code/identifier spellings or non-whitespace boundary must not become comparison.')
# Keep every original case and expected/scorer entry byte-for-byte, append only new no-gold cases.
existing=set(controls['queries']);extra=[x for x in extra if x['query'] not in existing]
insert=''.join('        ('+json.dumps(x['query'],ensure_ascii=False)+', None),\n' for x in extra)
s=s.replace('    ];\n    let mut result',insert+'    ];\n    let mut result')
(r/'driver.rs').write_text(s); controls['independent_additions']=extra;controls['queries']+= [x['query'] for x in extra];(r/'controls.json').write_text(json.dumps(controls,ensure_ascii=False,indent=2))
# Direct production modules, no candidate edit or mirror of recognizer logic.
probes=[{'query':q,'contract':'comparative','explanation':'Original author positive, unchanged'} for q in controls['genuine_phrases']]+[{'query':q,'contract':'owner','explanation':'Original code reference negative, unchanged'} for q in controls['code_reference_negatives']]+extra
(r/'probes.json').write_text(json.dumps(probes,ensure_ascii=False,indent=2))
for arm,src in [('delivery',Path('/workspace/codecortex')),('rejected',r/'rejected'),('candidate',r/'candidate')]:
 text=f'''#[path = "{src}/crates/cc-search/src/dsl.rs"] mod dsl;
#[path = "{src}/crates/cc-search/src/query_target.rs"] mod query_target;
fn main() {{
let rows: serde_json::Value=serde_json::from_str(include_str!("{r}/probes.json")).unwrap(); let mut out=Vec::new();
for row in rows.as_array().unwrap() {{ let q=row["query"].as_str().unwrap(); let parsed=dsl::parse_search_dsl(q); let t=query_target::QueryTarget::parse(&parsed);let ctx=query_target::NameBonusContext::parse(&parsed,&t);let kinds=["class","interface","type_alias","enum","module","namespace","method","function","unknown"];let flags:Vec<_>=kinds.iter().map(|k|serde_json::json!({{"kind":k,"owner":ctx.permits("Beacon",Some(k)),"other":ctx.permits("Sink",Some(k))}})).collect();out.push(serde_json::json!({{"query":q,"dsl":parsed.text,"target":format!("{{:?}}",t),"context":format!("{{:?}}",ctx),"flags":flags,"contract":row["contract"]}})); }}
println!("{{}}",serde_json::to_string_pretty(&out).unwrap()); }}
'''
 (r/f'probe-{arm}.rs').write_text(text)
print('Original queries',len(existing),'additions',len(extra),'total queries',len(controls['queries']),'direct probes',len(probes))
