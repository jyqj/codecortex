"""Prepared read-only audit; execute only after original collector artifact exists.

Replays the unchanged original collect_cells body against all eight original
exports. Only its receiver Git snapshot access uses the reviewed canonical-R
transport adapter. This is not another cold build or product/stdio execution.
"""
import json
import hashlib
from pathlib import Path
import sys
sys.dont_write_bytecode = True
BASE = Path('/workspace/scratch/bfccb8494ba0')
PREVIOUS = BASE / 'todo-audit-round12/recovery-platform-Gc8'
OUT = BASE / 'todo-audit-round12/platform-final-Gc8'
sys.path.insert(0, str(PREVIOUS))
from provenance_adapter import SOURCE, RAW, COMMIT, TREE, R, digest, json_bytes, observer_from_archive, artifact
import p8_cold_build as cold

def main(artifact_id):
    original, meta = artifact(artifact_id)
    candidates = list(original.rglob('matrix.json'))
    assert len(candidates) == 1
    matrix_path = candidates[0]
    matrix = json.loads(matrix_path.read_text())
    assert matrix['schema_version'] == 2 and matrix['status'] == 'passed' and matrix['exit_code'] == 0
    assert matrix['expected_commit'] == COMMIT and matrix['task'] == 'P8-012'
    assert matrix['runner_sha256'] == digest(SOURCE / 'scripts/p8_cold_build.py')
    expected_ids = [11604775379,11604252892,11604777455,11605445357,
                    11605395767,11604784110,11605680909,11606000257]
    expected_bundles = {RAW / str(i) / 'attempt01/extracted/bundle.json' for i in expected_ids}
    assert set(RAW.rglob('bundle.json')) == expected_bundles
    manifest = json.loads((next(iter(expected_bundles)).parent / 'source-inputs.json').read_text())
    assert {x['path']: x['sha256'] for x in manifest} == R['complete_inputs']
    assert {x['path']: x['git_mode'] for x in manifest} == R['source_modes']
    fullmap_path = BASE / 'scale-intake-primary/historical-277f-peer/actual-P-complete-product-validation-inputs.json'
    assert digest(fullmap_path) == '0f9512d6c37946db2f82a9f6b7f377125db6bcf03b8c64330e5bd4ab79ae883d'
    fullmap = {x['path']:x for x in json.loads(fullmap_path.read_text())['files']}
    for row in manifest:
        x = fullmap[row['path']]
        assert row == dict(path=x['path'], size=x['bytes'], sha256=x['sha256'], git_blob=x['git_blob'], git_mode=x['mode'])
    identity = dict(source_root=str(SOURCE), source_commit=COMMIT, source_tree=TREE,
                    input_count=1090, manifest_sha256=hashlib.sha256(json_bytes(manifest)).hexdigest())
    def reviewed_source_identity(root, expected_commit=None):
        assert Path(root).resolve() == SOURCE and expected_commit == COMMIT
        observer_from_archive(SOURCE, 'full')
        return identity, manifest
    cold.source_identity = reviewed_source_identity
    cold.observer_snapshot = observer_from_archive
    replay = cold.collect_cells(RAW, SOURCE, COMMIT)
    normalized = dict(matrix)
    normalized['source'] = dict(matrix['source'], source_root=str(SOURCE))
    assert all(normalized[k] == value for k, value in replay.items())
    assert replay['counts'] == dict(passed=8,failed=0,not_run=0)
    (OUT / 'original-collector-function-output.json').write_bytes(json_bytes(replay))
    report = dict(schema_version=1,status='accepted_original_eight_cell_collector',
        source_commit=COMMIT,source_tree=TREE,artifact_id=artifact_id,
        original_zip_digest=meta['digest'],original_matrix_sha256=digest(matrix_path),
        source_product_inputs=1090,counts=replay['counts'],cells=replay['cells'],
        original_function_source_sha256=digest(SOURCE / 'scripts/p8_cold_build.py'),
        receiver_provenance='Only source_identity and observer_snapshot use explicit exact canonicalR + reviewed fullmap + original Git tree/blob transport adapter; collect_cells body unchanged.',
        original_collector_and_receiver_results_equal=True,normalization='source_root receiver path only',
        product_execution_on_receiver=False,task_dependencies_separate=True,task_credit=False,remaining_todos=29)
    (OUT / 'independent-final-collector-review.json').write_bytes(json_bytes(report))
    print(json.dumps(dict(status=report['status'],artifact_id=artifact_id,counts=replay['counts'])))

if __name__ == '__main__':
    assert len(sys.argv) == 2, 'Original collector artifact ID required; do not execute while pending.'
    main(int(sys.argv[1]))
