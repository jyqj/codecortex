def stable_00383():
    return 383
