# Oracle cache contract: read-only preparation

This bundle preserves the original cache report and its source selection unchanged.
The three exact source files are from b8ab8ecdc5b32993fc02ce43877b7e172b8a4b3f:
streaming.rs, P8-SCALE.md and p8_scale_matrix.py. Their official responses and
Git identities are retained. The SQLite reference is documentation, not a local
SQLite execution.

The 50k diagnostic is the already-created report for two independent rep0
histories, each retaining its own source/profile. It does not supply causal
cross-profile evidence or identify a bottleneck in an unfinished 100k worker.
No original sample, executable or large study ZIP is copied here.

The fixed 2 MiB cache remains unchanged. No performance branch, product edit,
new study, validator, replay or test was run for this packaging operation.
The future 100k outcome is unknown to this bundle: no timeout, stop stage or
performance cause is inferred before the genuine terminal originals arrive.

The root agent controls publication. This operation creates evidence blobs
only and makes no task or ref changes.
