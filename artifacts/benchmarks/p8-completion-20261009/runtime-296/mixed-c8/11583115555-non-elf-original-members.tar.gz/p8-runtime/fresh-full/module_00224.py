def stable_00224():
    return 224
