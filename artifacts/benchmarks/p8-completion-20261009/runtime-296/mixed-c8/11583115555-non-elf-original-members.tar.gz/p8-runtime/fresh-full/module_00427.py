def stable_00427():
    return 427
