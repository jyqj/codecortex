#!/usr/bin/env python3
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

here = Path(__file__).resolve().parent
argv = [sys.executable, str(here/'diagnostic.py')]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
timed_out = False
with (here/'child.stdout').open('xb') as out, (here/'child.stderr').open('xb') as err:
    child = subprocess.Popen(argv, cwd=here, stdout=out, stderr=err)
    try:
        code = child.wait(timeout=45)
    except subprocess.TimeoutExpired:
        timed_out = True
        child.kill()
        code = child.wait()
receipt = dict(argv=argv, cwd=str(here), pid=child.pid, started_UTC=started,
               ended_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               elapsed_seconds=time.monotonic()-clock, child_exit_code=code,
               timed_out=timed_out, timeout_seconds=45,
               scope='One finite Python/SQLite diagnostic only; no Rust/native/primary/validator execution.')
for stream in ('stdout','stderr'):
    data=(here/f'child.{stream}').read_bytes()
    receipt[stream]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
with (here/'child-receipt.json').open('x') as f:
    json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt,sort_keys=True))
sys.exit(0 if code==0 and not timed_out else 1)
