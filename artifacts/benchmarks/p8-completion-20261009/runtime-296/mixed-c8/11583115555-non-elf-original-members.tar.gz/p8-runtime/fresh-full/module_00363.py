def stable_00363():
    return 363
