def stable_00267():
    return 267
