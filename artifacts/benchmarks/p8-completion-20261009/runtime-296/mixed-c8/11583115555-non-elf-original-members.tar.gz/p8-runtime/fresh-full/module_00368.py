def stable_00368():
    return 368
