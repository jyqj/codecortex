"""Additional read-only receipt and retained-byte checks; executes no product."""
import hashlib
import json
import re
import sys
from pathlib import Path

if sys.flags.optimize:
    raise SystemExit("optimized Python disables evidence assertions")
HERE = Path(__file__).resolve().parent
RAW = HERE / "nonbinary-originals" / "p8-full-recovery"
def load(p): return json.loads(p.read_text())
def sha(p):
    h = hashlib.sha256()
    with p.open("rb") as f:
        while b := f.read(1024 * 1024): h.update(b)
    return h.hexdigest()
busy = load(RAW / "local-recovery/database_busy/receipt.json")["result"]
b = busy["busy"]
assert b == load(RAW / "local-recovery/database_busy/busy-observation.json")
assert b["lock_probe"]["blocked"] is True and b["lock_probe"]["sqlite_errorcode"] == 5
assert 0 < b["held_seconds"] <= b["hold_budget_seconds"] == 6
assert b["new_symbol_rows_while_locked"] == 0 and b["request_while_locked"]["kind"] == "error"
assert busy["incremental"]["resolution_freshness"]["complete"] is True
assert busy["query"]["check"]["matching_symbols"] == 1
kill = load(RAW / "local-recovery/kill_restart/receipt.json")["result"]
k = kill["kill"]
assert k == load(RAW / "local-recovery/kill_restart/kill-observation.json")
assert k["exit_code"] == -9 and k["stop_observed"] is True
assert k["stop_observation_method"] == "waitpid_owned_child_WUNTRACED_SIGSTOP"
assert k["request"]["kind"] == "error" and k["request"]["event"]["kind"] == "stdout_eof"
for label, result in (("kill_restart", kill), ("database_busy", busy)):
    home = RAW / "local-recovery" / label / "fixture"
    assert {name: sha(home / name) for name in result["expected_source_after"]} == result["expected_source_after"]
rollback = load(RAW / "rollback/rollback.json")
cases = {r["id"]: r for r in rollback["cases"]}
c = cases["source_and_config_integrity"]
assert c["status"] == "passed"
assert sha(RAW / "rollback/fixture/.codecortex.json") == c["config_sha256"] == sha(RAW / "rollback/backups/config-before.json")
assert {name: sha(RAW / "rollback/fixture" / name) for name in c["source_manifest"]} == c["source_manifest"]
future = cases["operator_cache_version_roots"]
assert future["status"] == "passed" and future["rollback_root_created"] is False
assert {name: sha(RAW / "rollback/semantic-cache/future-format-999" / name) for name in future["future_files_unchanged"]} == future["future_files_unchanged"]
controls = HERE / "nonbinary-originals/p8-recovery-preparation/controls.log"
text = controls.read_text()
assert re.search(r"Ran 24 tests in [\d.]+s\n\nOK\s*$", text)
assert len(re.findall(r"^test_.* \.\.\. ok$", text, re.M)) == 24
members = load(HERE / "member-hashes.json")
assert sha(HERE / "11588128186.zip") == members["zip_sha256"]
assert all(sha(HERE / "nonbinary-originals" / name) == r["sha256"] for name, r in members["members"].items() if r["extracted_nonbinary"])
report = {"status": "passed_read_only_supplement", "source_commit": "260f596582f2d82b8d7c707b61a6b8b6a43b069f", "artifact_id": 11588128186,
    "local_fault_receipts": {"busy": b, "post_unlock_actual_incremental_complete": True, "post_unlock_matching_symbols": 1, "sigkill": k},
    "rollback_source_config_and_future_vector_bytes": {"checked": True, "cases": [{x: r[x] for x in ("id", "status", "scope", "reason") if x in r} for r in rollback["cases"]]},
    "original_preparation_controls": {"count": 24, "sha256": sha(controls)}, "all_originals_unchanged": True, "TODO_closed": 0}
out = HERE / "supplementary-raw-checks.json"
with out.open("x") as f: json.dump(report, f, indent=2); f.write("\n")
print(json.dumps({"status": report["status"], "sha256": sha(out)}))
