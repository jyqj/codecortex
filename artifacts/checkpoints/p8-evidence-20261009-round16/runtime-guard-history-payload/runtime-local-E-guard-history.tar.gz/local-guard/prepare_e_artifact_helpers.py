#!/usr/bin/env python3
"""Create separately versioned original-artifact auditors for exact E."""
import ast,difflib,hashlib,json,pathlib
BASE=pathlib.Path('/dev/shm/a217aaae3bde/runtime-review')
OLD=BASE/'e95-artifact-review';NEW=BASE/'e-a23-artifact-review'
assert not NEW.exists();NEW.mkdir()
HEAD='a23bb72d3c954f385b99fe81ce9189885c208557';RUN=37871838957;LIFE_RUN=37871838975
MANIFEST='4e0aa6bbfd4d5bea00416bca2cd99318d865ffc526fdcb45897c4d300de3ac00'
expected={'review_e95_runtime_original.py':'48b61298749342288e7ea5e6ab1fdd24c349d77c56b02dae69500e6e2b9613a1','review_e95_backfill_original.py':'324e0cc7b5daf2cece30ea74bb043b8011851999c93758edf6283241be25c804','e95_raw_cache_audit.py':'3cef309c035178028dd355b161e67fd9e6941002d7d99ba4911d9ef341cbd786','preflight_e95_zip.py':'bcd6c9ba2ae9e3b058f780855852a9221c4145d095c447891a54ca19db3be356'}
for p,h in expected.items():assert hashlib.sha256((OLD/p).read_bytes()).hexdigest()==h
changes={}
def produce(old_path,new_name,transform):
    old=old_path.read_text();new=transform(old)
    ast.parse(new);(NEW/new_name).write_text(new)
    (NEW/(new_name+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(old_path),tofile=new_name)))
    assertions=lambda text:[ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(text)) if isinstance(n,ast.Assert)]
    a,b=assertions(old),assertions(new)
    changes[new_name]={'prior':str(old_path),'prior_sha256':hashlib.sha256(old.encode()).hexdigest(),'sha256':hashlib.sha256(new.encode()).hexdigest(),'prior_assertions':len(a),'current_assertions':len(b),'prior_assertions_byte_ast_preserved':sum(x in b for x in a),'removed_or_replaced_assertions':[x for x in a if x not in b]}

def core(text):
    return text.replace('original e95 runtime evidence','original combined E runtime evidence').replace("HEAD = 'e95fd750d2f5052d0308c970cd5032c48b765cde'",f"HEAD = '{HEAD}'").replace('RUN = 37859755918',f"RUN = {RUN}\nLIFECYCLE_RUN = {LIFE_RUN}\nPRODUCT_MANIFEST = '{MANIFEST}'")
produce(OLD/'e95_raw_cache_audit.py','e_raw_cache_audit.py',core)
def runtime(text):
    text=text.replace('from e95_raw_cache_audit import HEAD, RUN,','from e_raw_cache_audit import HEAD, RUN, PRODUCT_MANIFEST,').replace('exact e95 execution only','exact combined E execution only')
    needle=" assert plan['source']['input_count']==1087 and plan['source']['manifest_sha256']==hashlib.sha256(owner.json_bytes(plan['source']['inputs'])).hexdigest()"
    assert needle in text
    return text.replace(needle,needle+"\n assert plan['source']['manifest_sha256']==PRODUCT_MANIFEST, 'combined product manifest differs'")
produce(OLD/'review_e95_runtime_original.py','review_e_runtime_original.py',runtime)
def backfill(text):
    text=text.replace('from e95_raw_cache_audit import HEAD, RUN,','from e_raw_cache_audit import HEAD, RUN, PRODUCT_MANIFEST,').replace('exact e95 execution only','exact combined E execution only')
    needle="assert r['source_before']['input_count']==1087 and r['source_before']['manifest_sha256']==hashlib.sha256(b.json_bytes(r['source_before']['inputs'])).hexdigest()"
    assert needle in text
    return text.replace(needle,needle+"\nassert r['source_before']['manifest_sha256']==PRODUCT_MANIFEST, 'combined product manifest differs'")
produce(OLD/'review_e95_backfill_original.py','review_e_backfill_original.py',backfill)
produce(OLD/'preflight_e95_zip.py','preflight_e_runtime_zip.py',lambda s:s.replace('from e95_raw_cache_audit import','from e_raw_cache_audit import'))
def life_preflight(text):
    text=text.replace('from e95_raw_cache_audit import HEAD,RUN,file_hash','from e_raw_cache_audit import HEAD,LIFECYCLE_RUN as RUN,file_hash')
    a="replay_copy=sum(m['bytes'] for m in members if m['path'].startswith(('p8-runtime/project/','p8-runtime/fresh-full/')) or m['path'] in ('p8-build/p8-oracle','p8-build/p8-runtime-statistics'))"
    assert a in text
    return text.replace(a,"replay_copy=sum(m['bytes'] for m in members if m['path']=='p8-measurements')")
produce(OLD/'preflight_e95_zip.py','preflight_e_lifecycle_zip.py',life_preflight)
def lifecycle(text):
    text=text.replace('Usage: python review_lifecycle_fixed_source.py manifest.json artifact-root 40hexHEAD','Usage: python review_e_lifecycle_original.py manifest.json artifact-root 40hexHEAD exact-checkout review-output-root')
    a="base=pathlib.Path('/dev/shm/a217aaae3bde');repo=base/'codecortex-round5-frozen';head=sys.argv[3]"
    b="from e_raw_cache_audit import HEAD,LIFECYCLE_RUN,PRODUCT_MANIFEST,file_hash\nfrom lifecycle_cargo_audit import verify_original_cargo\nassert len(sys.argv)==6, 'manifest artifact-root exact-head exact-checkout review-output-root required'\nbase=pathlib.Path(sys.argv[5]).resolve(strict=True);repo=pathlib.Path(sys.argv[4]).resolve(strict=True);head=sys.argv[3]\nassert head==HEAD, 'helper frozen for exact combined E execution only'\nassert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head, 'frozen checkout HEAD differs'"
    assert a in text;text=text.replace(a,b).replace("h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()","h=file_hash")
    a="and metadata['digest']=='sha256:'+manifest['zip_sha256']";assert a in text;text=text.replace(a,a+" and metadata['run_id']==LIFECYCLE_RUN")
    text=text.replace("out=base/'runtime-review'/('lifecycle-'+str(aid)+'-'+head[:8]+'-independent')","out=base/('lifecycle-'+str(aid)+'-'+head[:8]+'-independent')")
    a="assert r['product']['source']['source_commit']==head";assert a in text
    text=text.replace(a,a+"\nassert r['product']['source']['source_tree']==subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=repo,text=True).strip()\nassert r['product']['source']['input_count']==1087 and r['product']['source']['manifest_sha256']==PRODUCT_MANIFEST")
    a="assert len(r['observer_sha256'])==7";assert a in text
    text=text.replace(a,a+"\nassert {name.split('/scripts/',1)[1] for name in r['observer_sha256']}==set(life.OBSERVER_FILES), 'lifecycle observer inventory differs'")
    a="assert [x for x in messages if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='p8-measurements']==[replay['artifact']]";assert a in text
    text=text.replace(a,a+"\nproduct_messages=[json.loads(line) for line in (root/'product/cargo-build.jsonl').open()]\ncargo_review=verify_original_cargo(product,replay,product_messages,messages)\nassert set(r['observer_sha256'])=={str(producer/'scripts'/name) for name in life.OBSERVER_FILES}, 'lifecycle observer producer differs'\ncargo_review.update(product_log_sha256=h(root/'product/cargo-build.jsonl'),evaluator_log_sha256=h(root/'replay-build.jsonl'))")
    a="life.verify_artifact_inventory(m,r)\nreview=";assert a in text
    text=text.replace(a,"life.verify_artifact_inventory(m,r)\nassert archive.stat().st_size==manifest['zip_bytes'] and h(archive)==manifest['zip_sha256'], 'original ZIP changed during review'\nreview=")
    a="(out/'independent-review.json').write_text";assert a in text
    text=text.replace(a,"review.update(cargo_selection=cargo_review,helper={'path':str(pathlib.Path(__file__).resolve()),'sha256':h(pathlib.Path(__file__))})\n"+a)
    return text
produce(BASE/'review_lifecycle_fixed_source.py','review_e_lifecycle_original.py',lifecycle)
def control(text):
    text=text.replace("str(HERE.parent/'cache-gap-e95/controls-view/scripts/tests'),str(HERE.parent/'cache-gap-e95/controls-view/scripts')","'/dev/shm/a217aaae3bde/codecortex-combined-guard-view/scripts/tests','/dev/shm/a217aaae3bde/codecortex-combined-guard-view/scripts'")
    return text.replace('import e95_raw_cache_audit as audit','import e_raw_cache_audit as audit').replace('import preflight_e95_zip as preflight','import preflight_e_runtime_zip as preflight').replace("prefix='e95-","prefix='combined-E-")
produce(OLD/'test_helper_controls.py','test_helper_controls.py',control)
(NEW/'prior-assertion-comparison.json').write_text(json.dumps(changes,sort_keys=True,indent=2)+'\n')
print(str(NEW))
