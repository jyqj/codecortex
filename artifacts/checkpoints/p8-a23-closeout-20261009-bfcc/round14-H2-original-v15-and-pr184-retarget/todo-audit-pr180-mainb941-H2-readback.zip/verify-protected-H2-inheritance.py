import ast,copy,hashlib,json
from pathlib import Path
OUT=Path(__file__).resolve().parent
mod=ast.parse((OUT/'audit-H2.py').read_text())
exec(compile(ast.Module(body=[x for x in mod.body if isinstance(x,ast.FunctionDef)],type_ignores=[]),'audit-update-function','exec'))
helper=ast.parse(Path('/dev/shm/todo-audit-pr180-merge-plan/audit-complete-trees.py').read_text())
exec(compile(ast.Module(body=[x for x in helper.body if isinstance(x,ast.FunctionDef)],type_ignores=[]),'tree-object-functions','exec'))
x=json.loads(Path('/workspace/scratch/bfccb8494ba0/root-round13/current-merge-trees-transfer/extracted/pr180head4652.json').read_text())
rows={r['path']:r for r in x['tree']}
rows=updated(rows,json.loads(Path('/dev/shm/todo-audit-pr180-tree-elements/create-tree-request.json').read_text())['tree_elements'])
install=json.loads(Path('/dev/shm/todo-audit-pr180-generated-G-f89d5fee/prepared-R9-G2-H7-installation-map.json').read_text())
for name,key in [('R','only_added_leaves'),('G','only_changed_leaves'),('H','only_added_leaves')]: rows=updated(rows,install[name][key])
H=leafmap(list(rows.values()))
rows=updated(rows,json.loads((OUT/'H2-create-tree-request.json').read_text())['tree_elements'])
H2=leafmap(list(rows.values()));tree=compute_trees(list(rows.values()))['']
p=Path('/workspace/scratch/bfccb8494ba0/scale-intake-primary/H-historical-input-preparation/protected-input-whitelist.json')
raw=p.read_bytes();x=json.loads(raw)
checks=[]
for item in x['protected_inputs']:
 path=item['path']; assert H[path]['sha']==item['git_blob'] and H[path]['mode']==item['mode']
 assert identity(H2[path])==identity(H[path])
 checks.append({'path':path,'mode':item['mode'],'git_blob':item['git_blob']})
assert len(checks)==236
receipt=write('H2-historical-protected-mode-blob-bridge.json',{'scope':'Predicted H2 complete-tree mode/blob inheritance only, not byte read or original CLI execution','whitelist':{'path':str(p),'sha256':sha(raw),'bytes':len(raw)},'H_commit':'399a71a4c11e7041ce9946fba4d3f72200c47155','H2_commit':None,'predicted_H2_tree':tree,'all_236_current_root_protected_records_unchanged':True,'unchanged_original_historical_catalogue_count':x['catalogue_count'],'immutable_BASE':x['historical_head'],'records':checks})
print(json.dumps(receipt))
