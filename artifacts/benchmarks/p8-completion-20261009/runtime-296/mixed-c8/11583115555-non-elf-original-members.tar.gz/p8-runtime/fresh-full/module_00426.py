def stable_00426():
    return 426
