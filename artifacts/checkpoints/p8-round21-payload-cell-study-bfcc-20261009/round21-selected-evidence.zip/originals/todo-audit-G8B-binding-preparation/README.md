# G8B preparation only

Actual P8B 44e624 is a two-leaf successor of P7B 8831, which has G6B 88d5 as sole parent.
The six-path net delta, 1095 product hashes, 75 BASE deltas and 142 unchanged validation
hashes are mechanical input facts. Non-author R8B has not yet been installed; no placeholder
review or binding output has been generated. This tool does not grant source admission,
Rust, performance or task credit and never runs the original validator.

Seeds are the exact original G6B registry and guard. Require actual R8B sole P8B parent,
artifact-only installation, original canonical SHA256/Git blob and pr_triage's real scoped
review before generator execution. The original four pins and five registry fields are
its only output changes. Old G7B preparation and P7B/R7B evidence remain frozen history.
No local 181/v15 run is a new prerequisite; original CI and the original new-study event
may proceed in parallel under root ownership after final actual source binding.
