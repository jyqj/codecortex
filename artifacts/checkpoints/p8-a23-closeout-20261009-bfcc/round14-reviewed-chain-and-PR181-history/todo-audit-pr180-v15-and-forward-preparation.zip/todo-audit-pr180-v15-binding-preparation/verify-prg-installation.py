#!/usr/bin/env python3
"""Read-only P/R/G installation checks. This is not the original v15 CLI."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('binding_generator', HERE / 'generate-g-bindings.py')
binding = importlib.util.module_from_spec(spec)
spec.loader.exec_module(binding)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--review', required=True)
    p.add_argument('--guard', required=True)
    p.add_argument('--review-file', type=Path, required=True)
    p.add_argument('--publication-head', help='optional later archive-only merge H; does not replace G')
    a = p.parse_args()
    calls = []
    for name, value in [('review', a.review), ('guard', a.guard), ('publication', a.publication_head)]:
        if value is not None:
            binding.required(binding.re.fullmatch('[0-9a-f]{40}', value) is not None,
                             name + ' must be an immutable full commit SHA')

    def git(*argv):
        command = ['git', '-C', str(a.repo), *argv]
        r = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
        calls.append({'argv': command, 'exit_code': r.returncode,
                      'stdout_bytes': len(r.stdout), 'stdout_sha256': hashlib.sha256(r.stdout).hexdigest(),
                      'stderr': r.stderr.decode(errors='replace')})
        if r.returncode:
            raise RuntimeError('read-only Git call failed: ' + json.dumps(calls[-1]))
        return r.stdout

    def commit(sha):
        raw = git('cat-file', '-p', sha).decode()
        header = raw.split('\n\n', 1)[0].splitlines()
        return {'tree': next(x[5:] for x in header if x.startswith('tree ')),
                'parents': [x[7:] for x in header if x.startswith('parent ')]}

    def leaves(sha):
        result = {}
        for row in git('ls-tree', '-r', '-z', sha).split(b'\0'):
            if not row:
                continue
            meta, path = row.split(b'\t', 1)
            mode, kind, blob = meta.decode().split()
            result[path.decode()] = (mode, kind, blob)
        return result

    required = binding.required
    actual_P, actual_R, actual_G = commit(binding.PRODUCT), commit(a.review), commit(a.guard)
    required(actual_P['tree'] == binding.PRODUCT_TREE, 'P tree changed')
    required(actual_P['parents'] == ['4652cad11dde4b41126544a38fddf25eb2fb7474',
                                     '55aa2bcf355441585bcf980e1d6f4fab8eebe59d'], 'wrong ordered P parents')
    required(actual_R['parents'] == [binding.PRODUCT], 'R must have actual P as sole parent')
    required(actual_G['parents'] == [a.review], 'G must have actual R as sole parent')
    P, R, G = leaves(binding.PRODUCT), leaves(a.review), leaves(a.guard)
    required(set(P) <= set(R) and all(R[x] == P[x] for x in P),
             'R changed or lost an existing P product/document/artifact/validation input')
    additions = sorted(set(R) - set(P))
    directory = binding.REVIEW_PATH.rsplit('/', 1)[0] + '/'
    required(binding.REVIEW_PATH in additions and all(x.startswith(directory) for x in additions),
             'R must append the new review archive only, preserving all previous R records')
    changed = sorted(x for x in R.keys() | G.keys() if R.get(x) != G.get(x))
    required(changed == ['scripts/reviewed-source-registry-v15.json', 'scripts/verify_reviewed_source_v15.py'],
             'G differs beyond its two allowed binding files')
    actual_review = git('show', a.review + ':' + binding.REVIEW_PATH)
    required(actual_review == a.review_file.read_bytes(), 'actual R Git blob differs from independently completed canonical file')
    registry, guard, generated = binding.prepare(a.review_file, a.review)
    required(git('show', a.guard + ':scripts/reviewed-source-registry-v15.json') == registry,
             'actual G registry bytes differ from prepared exact binding')
    required(git('show', a.guard + ':scripts/verify_reviewed_source_v15.py') == guard,
             'actual G guard bytes differ beyond four original pin lines')
    publication = None
    if a.publication_head:
        external = '1d39f382d4e08e702a55693c9c614fa477bf7e0c'
        actual_H = commit(a.publication_head)
        required(actual_H['parents'] == [external, a.guard], 'unexpected publication merge parents')
        H = leaves(a.publication_head)
        expected = dict(G)
        publication_additions = json.loads((HERE / 'publication-additions.json').read_bytes())['tree_elements']
        for row in publication_additions:
            required(row['path'] not in G, 'external archive addition unexpectedly collides with our G')
            expected[row['path']] = (row['mode'], row['type'], row['sha'])
        required(H == expected, 'H is not exactly our G plus the seven preserved external artifacts')
        publication = {'head': a.publication_head, 'commit': actual_H,
                       'exactly_seven_additive_external_artifacts': True,
                       'all_existing_G_product_validation_CI_review_and_artifact_blobs_preserved': True,
                       'original_CI_source_steps_still_required_at_actual_H': True}
    result = {'status': 'passed_installation_identity_preflight_only',
              'P': binding.PRODUCT, 'R': a.review, 'G': a.guard,
              'commits': {'P': actual_P, 'R': actual_R, 'G': actual_G},
              'R_added_archive_paths': additions, 'G_changed_paths': changed,
              'latest_main_docs_tasks_artifacts_and_all_P_existing_files_preserved': True,
              'binding': generated, 'read_only_Git_calls': calls,
              'optional_publication_merge': publication,
              'original_v15_or_source_integrity_executed': False,
              'runtime_performance_task_release_credit': False}
    print(json.dumps(result, indent=2, sort_keys=True))

if __name__ == '__main__':
    main()
