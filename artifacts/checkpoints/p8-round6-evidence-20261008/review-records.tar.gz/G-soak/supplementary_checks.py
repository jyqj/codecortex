"""Independent raw interval, RPC, queue, cache and original SQLite cross-checks."""
import collections, contextlib, hashlib, json, os, sqlite3, sys, zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/2eaa00d0f93a/codecortex-platform-replay-G')
sys.path.insert(0, str(REPO / 'scripts'))
import p7_build_identity as identity
import p8_runtime as runtime
import p8_runtime_build as build

def load(p): return json.loads(p.read_text())
def write(p, x): p.write_text(json.dumps(x, sort_keys=True, indent=2)+'\n')
def sha(p): return identity.file_sha256(p)
def norm(v): return json.dumps(v, sort_keys=True, separators=(',', ':'))
def ensure(v, m):
    if not v: raise AssertionError(m)

source = identity.source_snapshot(REPO)
observer = build.observer_snapshot(REPO)
write(ROOT/'source-before.json', source)
write(ROOT/'observer-before.json', observer)
run = ROOT/'originals/p8-runtime'
hashes = load(ROOT/'member-hashes.json')['members']
raw = [json.loads(line) for line in (run/'raw.jsonl').read_text().splitlines()]
ops = sorted((r for r in raw if r['kind']=='operation'), key=lambda r:r['id'])
samples = [r for r in raw if r['kind']=='resources']
report = load(run/'report.json')
plan = load(run/'plan.json')
last_terminal = max(r['finished_ns'] for r in ops)
end = report['resource_time_coverage']['work_end_ns']
start = ops[0]['scheduled_ns']
ensure(last_terminal-start >= 3_600_000_000_000 and report['observed_work_ns'] >= 3_600_000_000_000 and end >= last_terminal, 'actual >=1h terminal work and controller span')
ensure(report['resource_time_coverage']['work_start_ns']==start and report['resource_time_coverage']['work_end_ns']==end, 'resource boundary exact work interval')
ensure(runtime.sample_coverage(samples,start,end)==report['resource_time_coverage'] and report['resource_time_coverage']['passed'], 'all sample gaps including edges')
rss = [r['server']['resident_bytes'] for r in samples]
q = len(rss)//4
warm = sorted(rss[q:2*q])[q//2]
tail = sorted(rss[3*q:])[len(rss[3*q:])//2]
ensure(warm==report['rss']['warmed_median_bytes'] and tail==report['rss']['tail_median_bytes'], 'independent Q2/Q4 medians')
ensure(tail<=warm+warm//4+32*1024**2==report['rss']['allowed_bytes'], 'unmodified RSS rule')
compactions = (run/'product/product-stderr.log').read_text().count(runtime.COMPACTION_EVENT)
branches = [r for r in ops if r.get('mutation',{}).get('action')=='real_git_branch_switch']
ensure(compactions==report['observed_catalog_compactions']>0 and len(branches)==report['real_branch_switches']>=2, 'actual compaction/branch receipts')
ensure(all(r['mutation'].get('before')!=r['mutation'].get('after') for r in branches) if 'before' in branches[0]['mutation'] else True, 'branch transition')
expected_build = collections.Counter(norm(r['response']) for r in ops if r['operation']=='build')
expected_build.update(norm(r['report']) for r in raw if r['kind']=='initial_build')
expected_read = collections.Counter(norm(r['response']) for r in ops if r['operation']=='read')
expected_read.update(norm(r['incremental']) for r in raw if r['kind']=='endpoint_public')
expected_status = collections.Counter(norm({'server':r['server'],'query_execution':r['query_execution'],'search_cache':r['search_cache']}) for r in samples)
expected_status.update(norm({'server':r['response']['process_resources'],'query_execution':r['response']['query_execution'],'search_cache':r['response']['search_cache']}) for r in raw if r['kind']=='endpoint_status')
observed = {k:collections.Counter() for k in ('index','search','status')}
rpc_methods = collections.Counter()
pending = {}
with zipfile.ZipFile(ROOT/'artifact-11576468006.zip') as z:
    with z.open('p8-runtime/product/rpc.jsonl') as stream:
        for line in stream:
            row=json.loads(line)
            if row['event'] not in ('request','response'): continue
            p=row['payload']
            if row['event']=='request':
                pending[p['id']]=p
            elif row['event']=='response':
                req=pending.pop(p['id'])
                ensure('error' not in p, 'RPC transport error')
                if req['method']!='tools/call': continue
                name=req['params']['name'];rpc_methods[name]+=1
                ensure(p['result'].get('isError') is False, 'tool result error')
                v=p['result']['structuredContent'];v=v.get('result',v)
                if name=='status':
                    v=v['diagnostics'];v={'server':v['process_resources'],'query_execution':v['query_execution'],'search_cache':v['search_cache']}
                if name in observed: observed[name].update([norm(v)])
ensure(not pending, 'RPC pending at end')
ensure(observed['index']==expected_build and observed['search']==expected_read and observed['status']==expected_status, 'all raw workload and native samples correspond to exact MCP response bodies')
timeline=[]
for r in ops:
    timeline.extend([(r['offered_ns'],1),(r['finished_ns'],-1)])
outstanding=0;peak=0
for _,delta in sorted(timeline):outstanding+=delta;peak=max(peak,outstanding)
ensure(outstanding==0 and peak<=plan['queue_capacity']+plan['concurrency'], 'bounded outstanding complete denominator')
dispatch=[r['started_ns']-r['offered_ns'] for r in ops]
cache_fields=('result_hits','result_misses','graph_hits','graph_misses')
cache={k:{'first':samples[0]['search_cache'][k],'last':samples[-1]['search_cache'][k],'maximum':max(r['search_cache'][k] for r in samples)} for k in cache_fields}
execution_keys=('async_admitted','async_in_flight','cpu_admitted','cpu_in_flight','completed','rejected')
execution={k:{'first':samples[0]['query_execution'][k],'last':samples[-1]['query_execution'][k],'maximum':max(r['query_execution'][k] for r in samples)} for k in execution_keys}
queue={'outstanding_peak':peak,'outstanding_final':outstanding,'rejected':sum(r['status']=='queue_rejected' for r in ops),'dispatch_wait_max_ns':max(dispatch),'dispatch_wait_quarter_maxima_ns':[max(dispatch[i*len(dispatch)//4:(i+1)*len(dispatch)//4]) for i in range(4)],'backend_execution_samples':execution,'sampling_limit':'Instantaneous backend counters at ~1Hz do not identify individual worker threads or measure every transient admission.'}

# Preserve original database bytes/header; ordinary immutable read-only SQLite.
dbdir=ROOT/'owned-readonly-databases';dbdir.mkdir()
db_records=[];connections=[]
try:
    with zipfile.ZipFile(ROOT/'artifact-11576468006.zip') as z:
        for side in ('project','fresh-full'):
            member=f'p8-runtime/{side}/.codecortex/index.sqlite3'
            p=dbdir/(side+'.sqlite3')
            with z.open(member) as src, p.open('xb') as dst:
                for b in iter(lambda:src.read(1024*1024),b''): dst.write(b)
            ensure(sha(p)==hashes[member]['sha256'] and p.stat().st_size==hashes[member]['bytes'], 'DB copy original bytes')
            c=sqlite3.connect(p.as_uri()+'?mode=ro&immutable=1',uri=True)
            connections.append(c)
            c.execute('BEGIN DEFERRED TRANSACTION')
            ensure(c.execute('PRAGMA integrity_check').fetchall()==[('ok',)],'DB integrity')
            ensure(c.execute('PRAGMA foreign_key_check').fetchall()==[],'DB foreign keys')
            db_records.append({'side':side,'member':member,'sha256':sha(p),'bytes':p.stat().st_size})
    parity=load(run/'parity.json'); tables=[]
    for table in parity['tables']:
        rows=[];cols=[];types=[]
        for c in connections:
            names=[r[1] for r in c.execute(f'PRAGMA table_info("{table}")') if not (table=='files' and r[1] in ('mtime','indexed_at') or table=='imports' and r[1]=='id')]
            ensure(bool(names),'original table columns')
            cols.append(names)
            select=','.join('"'+n.replace('"','""')+'"' for n in names)
            counts=collections.Counter();kinds=collections.Counter()
            for row in c.execute(f'SELECT {select} FROM "{table}"'):
                typed=[]
                for value in row:
                    kind=type(value).__name__;kinds[kind]+=1
                    typed.append((kind,value))
                counts[tuple(typed)]+=1
            rows.append(counts);types.append(dict(kinds))
        ensure(cols[0]==cols[1] and rows[0]==rows[1], 'all projected values/types/duplicate multiplicities differ: '+table)
        original=next(x for x in parity['comparison']['tables'] if x['table']==table)
        ensure(sum(rows[0].values())==original['full_rows']==original['incremental_rows'],'original oracle denominator')
        tables.append({'table':table,'columns':cols[0],'rows_each':sum(rows[0].values()),'duplicate_rows_each':sum(n-1 for n in rows[0].values()),'sqlite_types_each':types[0],'equal':True})
finally:
    for c in connections:c.close()
for row in db_records:
    p=dbdir/(row['side']+'.sqlite3');ensure(sha(p)==row['sha256'],'readonly DB bytes changed')
sqlite_result={'equal':True,'tables':tables,'databases':db_records,'method':'Original15-table projection; explicit SQLite value types and exact BLOB bytes; Counter preserves duplicate multiplicity; excluded files.mtime/indexed_at and imports.id only. No product/oracle/rebuild executed.','handles_closed':True,'copies_retained_under_owned_budget':True}
write(ROOT/'independent-sqlite-comparison.json',sqlite_result)
source_after=identity.source_snapshot(REPO);observer_after=build.observer_snapshot(REPO)
ensure(source==source_after and observer==observer_after,'source/observer changed')
write(ROOT/'source-after.json',source_after);write(ROOT/'observer-after.json',observer_after)
ensure(all(sha(ROOT/'originals'/name)==row['sha256'] for name,row in hashes.items() if row['extracted']), 'extracted raw changed')
owned=sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())
ensure(owned<=150*1024**2,'owned budget')
result={'source_commit':source['source_commit'],'controller_resource_span_ns':end-start,'reported_observed_work_ns':report['observed_work_ns'],'last_terminal_minus_first_schedule_ns':last_terminal-start,'controller_end_after_last_terminal_ns':end-last_terminal,'intervals':report['resource_time_coverage'],'rss':report['rss'],'catalog_compactions':compactions,'real_git_branch_switches':len(branches),'branch_mutation_example':branches[0]['mutation'],'rpc_response_body_matches_all_raw_operations_and_resources':True,'rpc_method_counts':dict(rpc_methods),'queue':queue,'search_cache_observations':cache,'long_duration_cache_hits_demonstrated':False,'semantic_worker_enabled':False,'worker_scope':'Symbol search uses the shared run_cpu path in exactG context.rs; one server remains alive for the full run and sampled completed counters progress. No individual worker identity/lifetime receipt or semantic backfill is claimed.','sqlite':{'equal':True,'tables':len(tables),'rows_each':sum(t['rows_each'] for t in tables)},'owned_bytes_before_this_report':owned,'budget_bytes':150*1024**2,'source_before_after_identical':True,'product_or_Cargo_runs':0,'TODO_closed':0}
write(ROOT/'supplementary-review.json',result)
print(json.dumps(result,indent=2))
