from pathlib import Path
import subprocess,json,hashlib,datetime,time,sys
root=Path.cwd();base=root/'artifacts/benchmarks/p8-bfccb8494ba0';out=base/'native-public-api-merge-H2-e564-admission';wt=base/'candidate-public-api-merge-H2-e564'
assert not wt.exists();out.mkdir(exist_ok=False);(out/'prepare-controller.py').write_bytes(Path(sys.argv[0]).read_bytes())
H='e5640904298febdf8dc951e0baddb2819f930c0b';receipts=[]
def run(label,args,timeout=180,cwd=root):
 sp=out/(label+'.stdout');ep=out/(label+'.stderr');start=time.monotonic();r={'label':label,'argv':args,'cwd':str(cwd),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with sp.open('wb') as so,ep.open('wb') as se:
  p=subprocess.Popen(args,cwd=str(cwd),stdout=so,stderr=se);r['pid']=p.pid
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:p.kill();code=p.wait();r['controller_timeout_seconds']=timeout
 r.update(exit_code=code,elapsed_seconds=time.monotonic()-start,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
 for k,q in [('stdout',sp),('stderr',ep)]:
  b=q.read_bytes();r[k]={'path':q.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
  if b and label!='official-initial-domain-ls-tree':print(label+' '+k+' '+b.decode(errors='replace')[-2000:],flush=True)
 receipts.append(r);(out/'initial-preparation-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(r),flush=True)
 if code:sys.exit(code if code>0 else 1)
 return sp.read_bytes()
old=run('parent-head-before',['/usr/bin/git','-c','core.commitGraph=false','rev-parse','HEAD'])
raw=run('actual-H-object',['/usr/bin/git','-c','core.commitGraph=false','cat-file','-p',H])
assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==H
assert raw.startswith(b'tree 73b93b60865daf5d9b6b02afa8974688c64191a4\nparent 399a71a4c11e7041ce9946fba4d3f72200c47155\nparent b9412406e11422d7cf914458a8bfbbd58cf94eaa\n')
run('create-detached-H-worktree',['/usr/bin/git','-c','core.commitGraph=false','worktree','add','--no-checkout','--detach',str(wt),H])
paths=['Cargo.lock','Cargo.toml','crates','scripts','.github','tests','artifacts/checkpoints/capability-snapshot-optimization-20261003/current-status-under-test.rs','artifacts/checkpoints/capability-snapshot-optimization-20261003/v2-status-checks.rs','artifacts/checkpoints/p8-public-api-merge-bfcc-20261009/independent-source-review.json']
run('checkout-exact-H-initial-inputs',['/usr/bin/git','-c','core.commitGraph=false','checkout',H,'--']+paths,cwd=wt)
data=run('official-initial-domain-ls-tree',['/usr/bin/git','-c','core.commitGraph=false','ls-tree','-r','-z',H,'--']+paths,cwd=wt)
rows=[]
for entry in data.split(b'\0'):
 if not entry:continue
 m,n=entry.split(b'\t',1);mode,kind,oid=m.decode().split();name=n.decode();assert kind=='blob'
 p=wt/name;b=p.read_bytes();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();actualmode='100755' if p.stat().st_mode&0o111 else '100644';assert blob==oid and actualmode==mode
 rows.append({'path':name,'mode':mode,'git_blob':blob,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
assert len(rows)==1246,len(rows)
r={'source_H':H,'tree':'73b93b60865daf5d9b6b02afa8974688c64191a4','product_P':'c92eb5ac7ece70d1f62271d7e2dacac513c285b5','review_R':'f89d5feec91ae611d52614b8fe217bcd7fd5cf64','scope_paths':paths,'entries':rows,'scope':'initial exact selected H checkout; original current historical protection records will be added before running unchanged v15; this is preparation, not source admission'}
b=(json.dumps(r,indent=2,sort_keys=True)+'\n').encode();(out/'initial-domain-receipt.json').write_bytes(b)
assert run('parent-head-after',['/usr/bin/git','-c','core.commitGraph=false','rev-parse','HEAD'])==old
print(json.dumps({'initial_exact_entries':len(rows),'receipt_bytes':len(b),'receipt_sha256':hashlib.sha256(b).hexdigest(),'original_v15_not_started':True}),flush=True)
