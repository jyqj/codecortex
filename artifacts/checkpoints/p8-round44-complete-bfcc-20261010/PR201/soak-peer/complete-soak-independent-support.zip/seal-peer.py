import json,hashlib,zipfile
from pathlib import Path
H=Path(__file__).resolve().parent
def enc(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def identity(p,b):return {'local_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
names=['read-original-soak.py','reader.stdout','reader.stderr','reader-execution.json','original-log-summary-and-controls.json',
 'selected-official-engineering-terminal-evidence.json','independent-soak-engineering-merge-review.json','new10-producer-completion-0601-bridge.json','seal-peer.py']
members=[];zp=H/'complete-soak-independent-support.zip'
with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in names:
  p=H/name;b=p.read_bytes();members.append(identity(p,b)|{'archive_path':name});z.writestr(name,b)
 manifest={'schema':'PR201-original-soak-independent-peer-support-v1','files':members,
  'original_full_log':{'git_blob':'51da3c3ac69c19bd4915666d81a9597eb58753ce','bytes':289033,'sha256':'04def35a76d107effa9776068ba3ec93dbf6db7e5b36e6c0bdec2b812fa41a7a','custody_owner':'root'},
  'original_full_official_response':'Root retains round44-PR201-final-CI/0601-official-originals.json; full identity in selected-official-engineering-terminal-evidence.json',
  'original_Actions_ZIP_not_downloaded_or_nested':True,'product_or_validator_reexecution':False}
 mb=enc(manifest);z.writestr('MANIFEST.json',mb)
selection=manifest|{'support':identity(zp,zp.read_bytes()),'support_members':len(members)+1,'manifest_member_bytes':len(mb),'manifest_member_sha256':hashlib.sha256(mb).hexdigest()}
(H/'archive-selection.json').write_bytes(enc(selection))
prefix='artifacts/checkpoints/p8-round44-complete-bfcc-20261010/PR201/soak-peer/'
paths=[H/'independent-soak-engineering-merge-review.json',zp,H/'archive-selection.json',H/'new10-producer-completion-0601-bridge.json']
u={'files':[identity(p,p.read_bytes())|{'repository_path':prefix+p.name} for p in paths]}
(H/'upload-manifest.pending.json').write_bytes(enc(u));print(json.dumps(u))
