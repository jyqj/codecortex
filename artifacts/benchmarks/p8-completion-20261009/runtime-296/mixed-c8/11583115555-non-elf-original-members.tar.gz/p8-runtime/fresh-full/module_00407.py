def stable_00407():
    return 407
