def stable_00066():
    return 66
