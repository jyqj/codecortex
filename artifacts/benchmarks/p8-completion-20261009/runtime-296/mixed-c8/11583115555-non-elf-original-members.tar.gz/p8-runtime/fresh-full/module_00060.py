def stable_00060():
    return 60
