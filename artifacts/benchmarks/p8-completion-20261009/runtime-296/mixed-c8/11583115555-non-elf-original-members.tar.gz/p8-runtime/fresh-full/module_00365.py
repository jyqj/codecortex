def stable_00365():
    return 365
