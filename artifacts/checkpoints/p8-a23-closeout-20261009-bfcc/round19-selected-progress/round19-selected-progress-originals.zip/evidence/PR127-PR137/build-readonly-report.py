from pathlib import Path
import json, hashlib, datetime, stat

ROOT=Path(__file__).resolve().parent
API=ROOT/'official-responses'
def raw(name): return json.loads((API/(name+'.json')).read_text())
def content(name):
    d=raw(name)
    assert not d.get('isError'), name
    return d['structuredContent']['content']
def obj(name): return json.loads(content(name))
def hashes(b):
    return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def write(name,x):
    p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
    return hashes(p.read_bytes())
def save_text(name,s):
    p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(s.encode('utf-8'));return hashes(p.read_bytes())

main=obj('mainref')['object']['sha']
assert main=='d22d36dddf8b38f1a864c933deefe0b6d3b5baf3'
prs={str(n):obj(str(n)) for n in (127,137)}
expected={'127':'222da64761971a3b546458aa16e2c2c9ea46cea7','137':'bc4e5602e10841258fb5583138419335bc9098dd'}
report={'schema':'readonly-pr-retention-review-v1','created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':'jyqj/codecortex','current_main_observed':main,'scope':'Two existing draft PRs: current metadata and complete body, exact-head latest checks, original scope documents, targeted current-main adoption checks. No global renamed-equivalence or whole-repository scan.','remote_mutations':False,'product_or_test_execution':False,'new_todo_credit':0,'remaining_todos':29,'observed_state_not_a_lease_for_future_mutation':True,'prs':{},'transport_limits':[]}
for n,p in prs.items():
    assert p['head']['sha']==expected[n]
    assert p['state']=='open' and p['draft'] and not p['merged']
    reviews=obj(n+'reviews');assert reviews==[]
    # The current API says no discussion or inline comments. Do not invent history.
    assert p['comments']==0 and p['review_comments']==0
    files=obj(n+'files');assert len(files)==p['changed_files']
    checks=obj(n+'checks');assert checks['total_count']==len(checks['check_runs'])==3
    assert all(c['head_sha']==expected[n] for c in checks['check_runs'])
    body_hash=save_text('extracted/PR'+n+'-complete-body.md',p['body'])
    report['prs'][n]={
        'url':p['html_url'],'title':p['title'],'head':p['head']['sha'],'head_ref':p['head']['ref'],'base':p['base']['sha'],'base_ref':p['base']['ref'],'state':p['state'],'draft':p['draft'],'merged':p['merged'],'updated_at':p['updated_at'],'labels':[x['name'] for x in p['labels']],'mergeable':p['mergeable'],'mergeable_state':p['mergeable_state'],'metadata_commits_count':p['commits'],'changed_files_count':len(files),'complete_body':{'path':'extracted/PR'+n+'-complete-body.md',**body_hash},'discussion':{'current_issue_comments':0,'current_inline_review_comments':0,'current_review_submissions':0,'source':'Current official PR metadata and complete empty reviews response; no nonexistent latest discussion was inferred.'},
        'changed_paths':[{'path':f['filename'],'status':f['status'],'git_blob':f['sha'],'additions':f['additions'],'deletions':f['deletions']} for f in files],
        'exact_head_checks':[{k:c.get(k) for k in ('id','name','head_sha','status','conclusion','started_at','completed_at','details_url')} for c in checks['check_runs']],
        'historical_evidence_not_reexecuted':True,
        'recommendation':'retain_open_draft_not_superseded',
        'reason_not_superseded':'Explicit keep-open migration decision in complete current PR body, and targeted current-main evidence does not establish complete adoption of product plus all evidence.'}

design=content('127design');readme=content('137readme');publish=content('main-publish')
for name,text,oid in [('extracted/PR127-design-at-head.md',design,'8d5a84da6ec3552b1b7b0361087e2350de379b56'),('extracted/PR137-README-at-head.md',readme,'ce7f0f392cf2cc15445b661f805a956e6f1e33f9')]:
    h=save_text(name,text);assert h['git_blob']==oid,(name,h)
    report.setdefault('original_scope_documents',[]).append({'path':name,**h})
hp=save_text('extracted/main-d22-semantic_publish.rs',publish)
assert 'publish_semantic_group' not in publish
report['targeted_current_main']={'source':main,'semantic_publish_owner':{'path':'crates/cc-db/src/semantic_publish.rs','original_content':'extracted/main-d22-semantic_publish.rs',**hp,'literal_publish_semantic_group_occurrences':0},'absent_original_paths':[],'boundary':'HTTP 404 proves only the exact path at this exact main; it is not a whole-repository or renamed-equivalence proof. The successful same-main owner file fetch distinguishes these missing paths from a blanket access failure.'}
for name,path in [('main-group-test','crates/cc-db/src/semantic_publish_group_tests.rs'),('main-group-doc','docs/design/2026-10-03-bounded-db-publication.md'),('main-group-evidence','docs/design/bounded-db-publication-evidence'),('main-requests-evidence','artifacts/diagnostics/requests-native-zero-20261004'),('main-requests-test','crates/cc-eval/tests/requests_native_zero_analogue.rs')]:
    d=raw(name);assert d.get('isError') and '404' in json.dumps(d),name
    report['targeted_current_main']['absent_original_paths'].append({'path':path,'response':'official-responses/'+name+'.json','status':'HTTP_404_exact_path'})

p=report['prs']['127']
p['explicit_current_decision']='2026-10-07 integration addendum: keep open for independent scope review and migrate still-unadopted intentions separately; original head CI/measurements remain tied to their source.'
p['scope_and_retention_reasons']=['An opt-in public IndexDb::publish_semantic_group API, at most four requests, same DB receiver/incarnation/lifecycle, one IMMEDIATE transaction and per-item CAS; not production queue wiring.','Original seven added test/documentation/evidence paths remain absent at their exact main locations; current owner file has no publish_semantic_group symbol.','Historical group/single-publish/lease tests and controlled fault/visibility evidence are valuable but do not establish current-main migration, queue integration, cache validation or performance.','The old scope document preserves an earlier Clippy failure/pending status. Current exact-head check/MSRV/security all completed success in run37148745699, so historical pending is not presented as a current CI failure.']
p['next_actions_without_new_execution']=['Non-author review of the bounded API, current-main migration conflicts, complete test/doc/evidence preservation and callers; retain branch and original evidence until that review decides the intended port.','If the API remains wanted, root can authorize a scoped migration against an explicit new source; production queue integration, cache policy and performance are separate uncompleted work, not automatically new merge gates for this read-only review.']
p['closure_requirement']='A later explicit disposition with complete product and evidence adoption proof, or an explicit decision to abandon this independent API. Neither is present in this bounded review.'

p=report['prs']['137']
steps=raw('137failedsteps')['structuredContent']['steps']
failed=[s for s in steps if s.get('conclusion')=='failure'];assert len(failed)==1 and failed[0]['name']=='Default regression within authorized scope'
p['current_failed_check_details']={'job_id':111327998251,'check_head':expected['137'],'original_job_steps':'official-responses/137failedsteps.json','failed_steps':failed,'preceding_format_clippy_default_compile':'success','later_eval_and_contract_steps':'skipped','failure_root_cause':'Not established by step summaries. No new test or full log download was performed.'}
p['explicit_current_decision']='The complete body describes a diagnosis-only draft, delegates the field contract/product follow-up to root, and explicitly keeps this PR open for independent migration review after the 2026-10-07 integration.'
p['scope_and_retention_reasons']=['Public DEV Requests native-zero/qname diagnostic evidence and one scoped self-authored subprocess analogue test; no product/gold/scorer/raw/ranking/budget changes.','Exact original diagnostic directory and scoped test path are absent from current main. No proof that all 18 original paths and their intended diagnostic conclusion were absorbed was obtained.','The report separates module-prefixed gold namespace versus lexical dotted product qname, remaining retrieval misses and no-answer failures; it does not decide that gold is wrong and does not certify current quality.','No final contract decision was found in the current body or reviews. Current exact-head default regression check is failure; formatting, Clippy and default target compilation succeeded before it, and later evaluation steps were skipped.','The body historical integration note counts three unique non-merge commits in its earlier comparison; current official PR metadata counts two commits. These distinct observations are retained, not silently made equivalent.']
p['next_actions_without_new_execution']=['Keep the diagnosis and original quality FAIL intact; root should decide the intended public field contract (lexical/container identity versus module-qualified identity) before any product or gold change.','Perform a bounded non-author migration/applicability review of the diagnostic package and scoped test against the chosen current source, preserving the original baseline/candidate/product identities and absent historical-binary limitation.','Before proposing a new merge-ready code head, read the actual failing default-regression log to identify its cause. This report only establishes the failed step and does not authorize rerunning public DEV, paid/live providers or holdout.']
p['closure_requirement']='Complete preservation/adoption of the independent diagnosis and test plus an explicit disposition of the namespace-contract question; neither full adoption nor abandonment is demonstrated.'
for name in ('137annotations','137failedjob'):
    d=raw(name);assert d.get('isError')
    report['transport_limits'].append({'attempt':'official-responses/'+name+'.json','outcome':'Generic GitHub fetch rejected this endpoint with INVALID_ARGUMENT; the purpose-built job-steps tool succeeded. This is not CI evidence or a repository failure.'})

write('readonly-retention-review.json',report)
readme='''# Round 19: PR127 and PR137 retention review\n\nBoth PRs should remain open Drafts. This bounded read-only review found explicit keep-open/migration decisions and no complete product-plus-evidence adoption proof. It did not change either PR or any task.\n\n| PR | Fixed head | Current exact-head checks | Reason to retain | Next concrete action |\n|---|---|---|---|---|\n| 127 | 222da64761971a3b546458aa16e2c2c9ea46cea7 | check, MSRV, security succeeded | Independent bounded group-publication API and seven added test/doc/evidence paths are not adopted at their original main paths; no queue integration or performance claim | Non-author scope and migration review, preserving original failure/green evidence; keep queue integration separate |\n| 137 | bc4e5602e10841258fb5583138419335bc9098dd | Default regression failed; MSRV/security succeeded | Diagnosis-only public DEV namespace-contract investigation remains unresolved; diagnostic directory and scoped test absent at their original main paths | Preserve diagnosis and quality FAIL; decide field contract and inspect the actual failed regression before proposing migration |\n\nMain observed: d22d36dddf8b38f1a864c933deefe0b6d3b5baf3. Exact-path absence does not prove that no renamed equivalent exists anywhere. No whole repository scan was used and no closure recommendation relies on such an inference. Both PRs currently have zero issue comments, inline comments and review submissions; the explicit retention decision is in each complete current body.\n\nThe full current body, official metadata, changed-path lists, checks and original scope documents are retained. Two generic endpoint fetch rejections are retained separately; the purpose-built job-steps call established the failed PR137 step without a full log download. Historical tests and diagnostics were not rerun.\n\nRound 19 remains in progress. This review adds zero completed tasks; 29 original TODOs remain.\n'''
save_text('README.md',readme)
entries=[]
for p in sorted(ROOT.rglob('*')):
    if p.is_file() and p.name not in ('archive-selection.json','report-generation.stdout','report-generation.stderr','report-generation.exit'):
        b=p.read_bytes();entries.append({'source_path':str(p),'archive_path':p.relative_to(ROOT).as_posix(),'mode':format(stat.S_IMODE(p.stat().st_mode),'04o'),**hashes(b)})
selection={'schema':'selected-readonly-pr-evidence-v1','root':str(ROOT),'source_domain':'PR127/137 fixed heads and exact main d22 targeted read-only observations','files':entries,'file_count':len(entries),'total_bytes':sum(x['bytes'] for x in entries),'all_selected_files_present':True,'remote_mutations':False,'product_test_execution':False,'round':19,'new_todo_credit':0,'remaining_todos':29}
h=write('archive-selection.json',selection)
print(json.dumps({'report':hashes((ROOT/'readonly-retention-review.json').read_bytes()),'selection':h,'file_count':len(entries),'total_bytes':selection['total_bytes'],'recommendations':{n:v['recommendation'] for n,v in report['prs'].items()}},ensure_ascii=False))
