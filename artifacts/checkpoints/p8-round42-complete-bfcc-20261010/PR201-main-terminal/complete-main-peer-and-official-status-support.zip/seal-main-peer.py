import json,hashlib,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def ident(p,b):return {'local_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
r=json.loads((HERE/'independent-original-main-log-review.json').read_text())
s={k:v for k,v in r.items() if k not in ('all_ignored_observations','all_cargo_result_summaries','commands')}
s['complete_result_and_ignore_preservation']={'all_cargo_target_result_observations':len(r['all_cargo_result_summaries']),
 'all_ignored_method_observations':len(r['all_ignored_observations']),'scope':'Complete original command/target/line summaries retained in detailed support; counts are observations, not unique methods.'}
dump(HERE/'independent-main-terminal-review.json',s)
names=['current-pr.official-original.json','head-checks.official-original.json','runtime-jobs.official-original.json',
 'finite-merge-readiness-review.json','read-original-main-log.py','main-reader.stdout','main-reader.stderr','main-reader-execution.json',
 'independent-original-main-log-review.json','independent-main-terminal-review.json','main-selected-original-lines.json','seal-main-peer.py']
paths=[HERE/n for n in names]
for a in ['main-reader-attempt01','main-reader-attempt02']:paths+=sorted((HERE/a).iterdir())
members=[]
zp=HERE/'complete-main-peer-and-official-status-support.zip'
with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in paths:
  b=p.read_bytes();name=str(p.relative_to(HERE));members.append(ident(p,b)|{'archive_path':name});z.writestr(name,b)
 m={'schema':'selected-original-main-peer-support-v1','files':members,
    'full_original_main_log':r['log'],'full_log_not_nested':True,'old_failed_fmt_history':'G750 original formatter failure preserved by prior immutable P2/R2 source review; not re-downloaded.',
    'no_product_or_validator_execution':True}
 mb=(json.dumps(m,indent=2)+'\n').encode();z.writestr('MANIFEST.json',mb)
dump(HERE/'publication-selection.json',m|{'support':ident(zp,zp.read_bytes()),'support_members':len(members)+1,
 'manifest_member_bytes':len(mb),'manifest_member_sha256':hashlib.sha256(mb).hexdigest()})
prefix='artifacts/checkpoints/p8-round42-complete-bfcc-20261010/PR201-main-terminal/'
manifest={'files':[ident(p,p.read_bytes())|{'repository_path':prefix+p.name} for p in [HERE/'independent-main-terminal-review.json',zp,HERE/'publication-selection.json']]}
dump(HERE/'upload-manifest.pending.json',manifest);print(json.dumps(manifest))
