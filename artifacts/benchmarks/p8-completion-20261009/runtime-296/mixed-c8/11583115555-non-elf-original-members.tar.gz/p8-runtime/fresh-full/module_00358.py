def stable_00358():
    return 358
