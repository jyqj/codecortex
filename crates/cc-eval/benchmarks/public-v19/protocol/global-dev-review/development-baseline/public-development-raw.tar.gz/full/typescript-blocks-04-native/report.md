# CodeCortex benchmark baseline

Suite: `V19 TypeScript 04 codecortex-native-v1 candidate; review/custody pending`
Adapter: `mcp-stdio`
Scoring: `Native`
Measurement profile: `quality`

Status: **gate_failed** (exit 1)

Queries: 14; measured rows: 42.
Mean Top-1: 0.363636; mean nDCG@10: 0.448960.

These are baseline observations, not a release quality certificate.
Latency: Distribution { samples: 0, p50_us: None, p95_us: None, max_us: None, tail_claim: "insufficient_for_tail_claim" }; samples are retained, not best-of.
Source evidence: 0 invalid, 0 unverified hits.

| Case | Top-1 | nDCG@10 | Repetitions |
|---|---:|---:|---:|
| v19.typescript.f0062.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0064.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0065.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0067.en01 | 0.000000 | 0.000000 | 3 |
| v19.typescript.f0068.en01 | 0.000000 | 0.000000 | 3 |
| v19.typescript.f0069.en01 | 0.000000 | 0.469279 | 3 |
| v19.typescript.f0070.en01 | 0.000000 | 0.000000 | 3 |
| v19.typescript.f0072.en01 | 0.000000 | 0.469279 | 3 |
| v19.typescript.f0075.en01 | 0.000000 | 0.000000 | 3 |
| v19.typescript.f0076.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0077.en01 | 0.000000 | 0.000000 | 3 |

## Failures

- v19.typescript.f0078.en01 Partial
- v19.typescript.f0078.en01 no-answer failure
- v19.typescript.f0079.en01 Partial
- v19.typescript.f0079.en01 no-answer failure
- v19.typescript.f0070.en01 Partial
- v19.typescript.f0062.en01 Partial
- v19.typescript.f0069.en01 Partial
- v19.typescript.f0067.en01 Partial
- v19.typescript.f0077.en01 Partial
- v19.typescript.f0068.en01 Partial
- v19.typescript.f0064.en01 Partial
- v19.typescript.f0076.en01 Partial
- v19.typescript.f0080.en01 Partial
- v19.typescript.f0080.en01 no-answer failure
- v19.typescript.f0072.en01 Partial
- v19.typescript.f0075.en01 Partial
- v19.typescript.f0065.en01 Partial
- v19.typescript.f0080.en01 Partial
- v19.typescript.f0080.en01 no-answer failure
- v19.typescript.f0067.en01 Partial
- v19.typescript.f0075.en01 Partial
- v19.typescript.f0076.en01 Partial
- v19.typescript.f0077.en01 Partial
- v19.typescript.f0068.en01 Partial
- v19.typescript.f0078.en01 Partial
- v19.typescript.f0078.en01 no-answer failure
- v19.typescript.f0069.en01 Partial
- v19.typescript.f0065.en01 Partial
- v19.typescript.f0079.en01 Partial
- v19.typescript.f0079.en01 no-answer failure
- v19.typescript.f0070.en01 Partial
- v19.typescript.f0062.en01 Partial
- v19.typescript.f0064.en01 Partial
- v19.typescript.f0072.en01 Partial
- v19.typescript.f0062.en01 Partial
- v19.typescript.f0070.en01 Partial
- v19.typescript.f0076.en01 Partial
- v19.typescript.f0072.en01 Partial
- v19.typescript.f0078.en01 Partial
- v19.typescript.f0078.en01 no-answer failure
- v19.typescript.f0080.en01 Partial
- v19.typescript.f0080.en01 no-answer failure
- v19.typescript.f0075.en01 Partial
- v19.typescript.f0068.en01 Partial
- v19.typescript.f0067.en01 Partial
- v19.typescript.f0079.en01 Partial
- v19.typescript.f0079.en01 no-answer failure
- v19.typescript.f0064.en01 Partial
- v19.typescript.f0069.en01 Partial
- v19.typescript.f0065.en01 Partial
- v19.typescript.f0077.en01 Partial