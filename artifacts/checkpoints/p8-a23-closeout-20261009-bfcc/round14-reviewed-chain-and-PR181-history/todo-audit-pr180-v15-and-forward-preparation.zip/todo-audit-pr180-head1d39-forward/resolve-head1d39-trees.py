import json, hashlib
from pathlib import Path
OUT=Path(__file__).resolve().parent
IN=Path('/workspace/scratch/bfccb8494ba0/root-round13/current-merge-trees-transfer/extracted')
ROOT='7a87a8e335de5c09d041b01f8802973ea96cd595'
trees={}; origins={}
def oid(rows):
 b=b''
 for r in sorted(rows,key=lambda r:(r['path']+('/' if r['type']=='tree' else '')).encode()):
  b+=r['mode'].lstrip('0').encode()+b' '+r['path'].encode()+b'\0'+bytes.fromhex(r['sha'])
 return hashlib.sha1(b'tree '+str(len(b)).encode()+b'\0'+b).hexdigest()
for name in ['mergebase840fa','mainfd9','pr180old3ff','pr180head4652','pr181head4866']:
 x=json.loads((IN/(name+'.json')).read_text());groups={};expected={'':x['sha']}
 for r in x['tree']:
  d,_,base=r['path'].rpartition('/'); rr=dict(r,path=base);groups.setdefault(d,[]).append(rr)
  if r['type']=='tree':expected[r['path']]=r['sha']
 for d,rows in groups.items():
  actual=oid(rows)
  if d:assert actual==expected[d]
  trees[actual]=rows;origins.setdefault(actual,'prior_verified_full_tree:'+name)
for p in sorted(Path('/dev/shm/todo-audit-pr180-merge-plan/new-main-trees').glob('*.json')) + sorted((OUT/'new-head-trees').glob('*.json')):
 x=json.loads(p.read_text());assert x['truncated'] is False;rows=x['tree'];assert all('/' not in r['path'] for r in rows)
 actual=oid(rows);assert actual==p.stem
 trees[actual]=rows;origins[actual]=str(p)
pending={};used={};flat=[]
def walk(s,prefix=''):
 if s not in trees:pending.setdefault(s,[]).append(prefix);return
 used[s]=origins[s]
 for row in trees[s]:
  path=prefix+row['path'];r=dict(row,path=path);flat.append(r)
  if r['type']=='tree':walk(r['sha'],path+'/')
walk(ROOT)
result={'pending':pending,'used_tree_count':len(used),'complete':not pending,'root':ROOT,'leaf_count_if_complete':sum(r['type']!='tree' for r in flat)}
if not pending:
 (OUT/'head1d39-complete-derived-tree.json').write_text(json.dumps({'sha':ROOT,'tree':flat,'truncated':False,'scope':'complete tree composed from official changed-tree objects plus exact immutable unchanged OID reuse'},sort_keys=True)+'\n')
 (OUT/'head1d39-tree-origin-map.json').write_text(json.dumps(used,indent=2,sort_keys=True)+'\n')
print(json.dumps(result))
