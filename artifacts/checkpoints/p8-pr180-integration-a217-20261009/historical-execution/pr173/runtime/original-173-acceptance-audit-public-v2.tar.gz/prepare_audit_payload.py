"""Preserve bounded exact acceptance evidence; never rerun any acceptance."""
from pathlib import Path
import gzip,hashlib,io,json,os,stat,tarfile,zipfile
B=Path(__file__).resolve().parent
O=B/'durable-audit';O.mkdir(exist_ok=False)
HEAD='275e8799d4947d297329073eaa3ca675d3fd0777'
def info(data):
 return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),git_blob_sha1=hashlib.sha1(('blob %d\0'%len(data)).encode()+data).hexdigest())
def fileinfo(path):return dict(path=str(path),**info(path.read_bytes()))
artifacts=json.loads((B/'official-intake-index.json').read_text())['artifacts']
entries=[]
for a in artifacts:
 aid=a['id'];scope=a['name'].removesuffix('-'+HEAD)
 execution=B/'executions'/str(aid)/'execution.json';e=json.loads(execution.read_text())
 assert e['status']=='accepted_scoped_original_evidence' and e['source']==HEAD
 assert all(c['exit_code']==0 for c in e['commands'])
 assert e['original_zip_sha256_before']==e['original_zip_sha256_after']==a['digest'][7:]
 matches=[]
 for folder in (B/'reviews').iterdir():
  if folder.is_dir() and str(aid) in folder.name:
   for f in folder.glob('*.json'):
    if f.name in ('independent-review.json','recovery-173-review.json','recovery-173-011-review.json'):matches.append(f)
 assert len(matches)==(2 if aid==11597639035 else 1)
 entries.append(dict(scope=scope,artifact_id=aid,workflow_run=a['workflow_run']['id'],source_commit=a['workflow_run']['head_sha'],
  original_zip=dict(path=str(B/'artifacts'/str(aid)/(str(aid)+'.zip')),bytes=a['size_in_bytes'],sha256=a['digest'][7:],official_url=a['url']),
  official_metadata=fileinfo(B/'artifacts'/str(aid)/'artifact-metadata.json'),execution=fileinfo(execution),reviews=[fileinfo(p) for p in matches]))
assert len(entries)==8
# The relocated lifecycle replay input is a reproducible path-only derivative.
# Verify its exact reconstruction from the preserved original ZIP once; omit
# this 33 MB duplicate from the compact audit package, retain the local file.
aid=11597589468
z=B/'artifacts'/str(aid)/(str(aid)+'.zip')
derivative=B/'reviews/lifecycle-11597589468-275e8799-independent/relocated-replay-input.json'
with zipfile.ZipFile(z) as original:
 raw=original.read('measurement/replay-input.json');value=json.loads(raw)
 receipt=json.loads(original.read('measurement/receipt.json'))
 command=receipt['replay']['command'];old=Path(command[command.index('--input')+1]).parent
 for q in value['raw_queries']:
  q['source_root']=str(B/'artifacts'/str(aid)/'extracted/measurement'/Path(q['source_root']).relative_to(old))
 rebuilt=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
 assert rebuilt==derivative.read_bytes()
derivation=dict(original_artifact_id=aid,original_zip_sha256=next(a['digest'][7:] for a in artifacts if a['id']==aid),
 original_member='measurement/replay-input.json',original_member_identity=info(raw),derivative=fileinfo(derivative),
 change='Only each of the 1200 raw_queries.source_root prefixes is relocated from receipt replay input parent to retained measurement directory; json.dumps sort_keys=True, indent=2 plus newline.',
 raw_query_count=len(value['raw_queries']),exact_reconstruction_verified=True,local_derivative_retained=True)
assert derivation['raw_query_count']==1200
(O/'lifecycle-derivative-reconstruction.json').write_text(json.dumps(derivation,sort_keys=True,indent=2)+'\n')
index=dict(schema='173-original-runtime-lifecycle-recovery-acceptance-index-v1',source_commit=HEAD,
 source_tree='5859c18f6ead4f8eff5abc3be05d80dfc2fc5b46',source_inputs=1089,
 source_manifest_sha256='593cf443fc914998dd2cb5a30c3caf180eb8d0d7a398a86e4624e3df2ca65e83',
 original_artifacts_admitted=8,entries=entries,measurement_rerun=False,product_rebuild=False,
 actual_replays='Original bound p8-runtime-statistics/p8-oracle/p8-measurements executables replay retained data in separate copies. Recovery only verifies original logs, Git source and immutable read-only SQLite.',
 semantics='These are only fixed 275e observations. No E, 599, 175, 178 or later-source observations are relabelled. 173 still uses the original Python nanosecond summary implementation; the later P8-017 owner migration is not claimed here.',
 limits=['Configured mixed C1/4/8/16 observed maximum 1/4/7/12 respectively; do not substitute configured caps for observations.',
  'Soak offered 3601 operations over 3600 seconds, observed work 3600.053700026s; its workload was serialized at observed maximum 1.',
  'Cache 2400 offered reads each consist of four original RPCs; 9600 protocol requests. Every quarter contains cache hits/misses/invalidations; resource status sampling is separate.',
  'Resource medians/samples cover the recorded finite windows. Lifecycle OS cache remains unknown and unavailable fees remain null.',
  'Backfill fake in-process provider and recovery owned loopback provider do not certify live-provider cost/throughput.',
  'Original limited recovery/rollback not_run records remain intact and have only the explicitly mapped same-source complementary evidence.',
  'Full scale 150 shards/1500 samples and other task dependencies remain independent. No task/release/G8 completion is certified.',
  'This compact audit package omits original ZIP contents; all eight complete original ZIPs remain local and on their exact GitHub artifact URLs. Git parts publication is not claimed here.'],
 formal_task_completion=False,ledger=dict(done=163,remaining=29),status_action='no_change')
(O/'acceptance-index.json').write_text(json.dumps(index,sort_keys=True,indent=2)+'\n')
readme='''# Fixed 275e original evidence acceptance\n\nEight original GitHub artifacts have been independently reviewed at the exact original source. See `acceptance-index.json` for full immutable source, artifact, ZIP, review and execution bindings. The nine full review records, original reader stdout/stderr, preflight inventories, helper source/diffs and independent adaptation reviews are preserved in the audit archive.\n\nThis is an evidence-replay package, not a new workload and not the complete original raw archive. All eight original ZIPs, including native binaries and databases, remain retained at the index paths and official artifact URLs. The reproducible lifecycle relocated input remains local; its exact reconstruction and digest are separately recorded. No raw-publication completion is claimed by this package.\n\nThe old E helper provenance comes from published commit `8aeb66d28d3d14266fc5c5a305e3f2b95a8526c6`, `artifacts/checkpoints/p8-evidence-20261009-round18/runtime-lifecycle-audit-payload/runtime-lifecycle-audit-evidence.tar.gz`, Git blob `38a9de61171c684dfe83a9b9e5325dd61b8e8e2d` (SHA256 `ARCHIVE_SHA256`). Recovery helper provenance is separately retained verbatim.\n\nNo original workload, threshold, helper predicate, task definition or task status was changed. Formal completion remains false: 163 done / 29 remaining.\n'''
# Avoid hand-transcribing a digest: the authoritative known archive value is
# read from its original verified manifest below.
old_manifest=json.loads((B/'recovery-helper-input/payload-manifest.json').read_text())
readme=readme.replace('(SHA256 `ARCHIVE_SHA256`)', '(SHA256 `'+old_manifest['archive']['sha256']+'`)')
(O/'README.md').write_text(readme)
selected={}
def add(p,name=None):
 assert p.is_file() and not p.is_symlink()
 name=name or p.relative_to(B).as_posix()
 assert name not in selected and not name.startswith('/') and '..' not in Path(name).parts
 selected[name]=p
for relative in ['actual-fixed-source-and-observer.json','after-eight-source-and-observer.json','observer-E-to-275e-applicability.json',
 'official-intake-index.json','original-zip-verification-and-inventory.json','recovery-previous-blob-presence.json',
 'synthetic-controls.stdout','synthetic-controls.stderr','synthetic-controls-receipt.json',
 'prepare_identity_adapter.py','prepare_recovery_adapter.py','run_original_review_once.py','prepare_audit_payload.py',
 'recovery-helper-input/payload-manifest.json','recovery-helper-input/restoration-receipt.json','recovery-helpers-275e-v1/preparation-failure.json']:
 add(B/relative)
for folder in ['helpers-275e-v1','recovery-helpers-275e-v2','peer-reviews','executions','reviews']:
 for p in sorted((B/folder).rglob('*')):
  if p.is_file() and p!=derivative and '__pycache__' not in p.parts:add(p)
for a in artifacts:add(B/'artifacts'/str(a['id'])/'artifact-metadata.json')
provenance=Path('/workspace/scratch/a217aaae3bde/original-173-platform-gates/helper-provenance')
for name in ['public-container-provenance.json','review-recovery-e.py','review-recovery-e-011.py']:
 add(provenance/name,'recovery-original-helper-provenance/'+name)
for name in ['README.md','acceptance-index.json','lifecycle-derivative-reconstruction.json']:add(O/name,name)
records=[]
for name,p in sorted(selected.items()):
 data=p.read_bytes();records.append(dict(member=name,source_path=str(p),source_mode=stat.S_IMODE(p.stat().st_mode),archive_mode=0o644,**info(data)))
def serialize():
 out=io.BytesIO()
 with gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0,compresslevel=9) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as tar:
   for row in records:
    data=selected[row['member']].read_bytes();assert info(data)=={k:row[k] for k in ['bytes','sha256','git_blob_sha1']}
    t=tarfile.TarInfo(row['member']);t.size=len(data);t.mode=0o644;t.mtime=0;t.uid=t.gid=0;t.uname=t.gname='';tar.addfile(t,io.BytesIO(data))
 return out.getvalue()
data=serialize();assert data==serialize();archive=O/'original-173-acceptance-audit.tar.gz';archive.write_bytes(data)
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert [m.name for m in members]==[r['member'] for r in records]
 for m,row in zip(members,records):
  assert m.isfile() and m.mode==0o644 and m.mtime==0 and m.size==row['bytes']
  assert tar.extractfile(m).read()==selected[m.name].read_bytes()
manifest=dict(schema='original-173-acceptance-audit-package-v1',source_commit=HEAD,archive=fileinfo(archive),
 members=records,member_count=len(records),uncompressed_bytes=sum(x['bytes'] for x in records),
 sorted_USTAR_gzip_mtime0=True,independent_second_serialization_byte_identical=True,full_reopen_source_byte_equality=True,
 all_original_zips_retained=True,original_zips_in_package=False,reproducible_lifecycle_input_omitted=derivation,
 public_raw_parts_completion_claim=False,measurement_rerun=False,formal_task_completion=False,ledger=dict(done=163,remaining=29))
mp=O/'payload-manifest.json';mp.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps({'archive':fileinfo(archive),'manifest':fileinfo(mp),'index':fileinfo(O/'acceptance-index.json'),'members':len(records),'uncompressed_bytes':manifest['uncompressed_bytes']},indent=2))
