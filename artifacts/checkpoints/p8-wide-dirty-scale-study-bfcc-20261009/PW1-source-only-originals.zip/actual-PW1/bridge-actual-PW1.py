from pathlib import Path
import json,hashlib,datetime,copy
D=Path(__file__).resolve().parent
N=Path('/dev/shm/execution-recon-recovery-20261009/round23-scale-wide-dirty-native-candidate');Y=Path('/dev/shm/pr-triage-round23-wide-dirty-candidate/v2')
R8P=Path('/dev/shm/pr-triage-round21-P8B-source-review/final-R8B/independent-source-review.json');R8=json.loads(R8P.read_text())
P='a17002b1b98f8ea86da43a4e865a87537aae2f65';T='7d5aacde287848981e480decb328cc52180df19d';G8='4fe927488d5cb7f26bd27c7624745fb1b6ca202b'
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(b,kind='blob'):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def decode(x):
 assert not x.get('isError');s=x['structuredContent'];return json.loads(s['content']) if isinstance(s.get('content'),str) else s

def tree_hash(entries):
 rows=sorted(entries,key=lambda e:(e['path']+('/' if e['type']=='tree' else '')).encode())
 return oid(b''.join(e['mode'].lstrip('0').encode()+b' '+e['path'].encode()+b'\0'+bytes.fromhex(e['sha']) for e in rows),'tree')
def rehash(entries,expected=None):
 es={e['path']:copy.deepcopy(e) for e in entries};dirs={''}|{p for p,e in es.items() if e['type']=='tree'}
 for d in sorted(dirs,key=lambda p:p.count('/')+(1 if p else 0),reverse=True):
  pre=d+'/' if d else '';children=[e|{'path':p[len(pre):]} for p,e in es.items() if p.startswith(pre) and '/' not in p[len(pre):] and p!=d];h=tree_hash(children)
  if expected:assert h==(expected if not d else next(e['sha'] for e in entries if e['path']==d)),d
  if d:es[d]['sha']=h
  else:return h
raw=json.loads(Path('/dev/shm/root-round23/PW1-created-objects-original.json').read_text());commit=decode(raw['official_commit']);diff=decode(raw['official_diff']);rt=decode(raw['official_root_tree'])
assert commit['sha']==P and commit['tree']['sha']==T and [x['sha'] for x in commit['parents']]==[G8]
assert rt['sha']==T and rt['truncated'] is False and tree_hash(rt['tree'])==T
assert diff['base_commit']['sha']==G8 and diff['merge_base_commit']['sha']==G8 and diff['ahead_by']==1 and diff['behind_by']==0 and diff['total_commits']==1
changes=[]
for base in [N,Y]:
 for x in json.loads((base/'source-manifest.json').read_text())['files']:
  p=base/'candidate'/x['path'];b=p.read_bytes();assert(len(b),sha(b),oid(b))==(x['bytes'],x['sha256'],x['git_blob']);changes.append(x|{'local_path':str(p),'mode':'100644','type':'blob'})
assert len(changes)==7;fm={x['filename']:x for x in diff['files']};assert set(fm)=={x['path'] for x in changes};assert sorted(x['status'] for x in fm.values())==['added']*2+['modified']*5
for x in changes:assert fm[x['path']]['sha']==x['git_blob']
trees={n:decode(json.loads((D/'github-api'/(n+'-tree-tool-response.json')).read_text())) for n in ['github','scripts','docs','crates','cc-eval']};rc={x['path']:x for x in rt['tree']}
for n,prefix in [('github','.github'),('scripts','scripts'),('docs','docs'),('crates','crates')]:assert trees[n]['sha']==rc[prefix]['sha'] and trees[n]['truncated'] is False
assert trees['cc-eval']['sha']==next(x['sha'] for x in trees['crates']['tree'] if x['path']=='cc-eval')
for n in ['github','scripts','cc-eval']:rehash(trees[n]['tree'],trees[n]['sha'])
for n in ['docs','crates']:assert tree_hash(trees[n]['tree'])==trees[n]['sha']
actual={}
for n,prefix in [('github','.github'),('scripts','scripts'),('cc-eval','crates/cc-eval'),('docs','docs')]:
 for e in trees[n]['tree']:
  if e['type']=='blob':actual[prefix+'/'+e['path']]=e
for x in changes:
 e=actual[x['path']];assert(e['mode'],e['type'],e['sha'],e['size'])==(x['mode'],x['type'],x['git_blob'],x['bytes'])
prod=copy.deepcopy(R8['complete_inputs']);val=copy.deepcopy(R8['validation_inputs']);paths=copy.deepcopy(R8['paths']);inv=copy.deepcopy(R8['actual_input_mode_blob_inventory']);pc=[];vc=[];dc=[]
for x in changes:
 p=x['path'];before=x.get('before_sha256')
 if p.startswith('crates/'):
  assert prod[p]==before and paths[p]['sha256']==before;prod[p]=x['sha256'];paths[p]['sha256']=x['sha256'];pc.append(p)
 elif p.startswith(('scripts/','.github/')):
  assert val.get(p)==before;val[p]=x['sha256'];vc.append(p)
 else:dc.append(p);continue
 inv[p]={'mode':x['mode'],'type':'blob','sha':x['git_blob'],'size':x['bytes'],'sha256':x['sha256']}
assert(len(prod),len(paths),len(val),len(inv),len(pc),len(vc),len(dc))==(1095,75,143,1238,3,3,1)
visible=0
for p,e in inv.items():
 if p in actual:
  a=actual[p];assert(a['mode'],a['type'],a['sha'],a['size'])==(e['mode'],e['type'],e['sha'],e['size']);visible+=1
rev={}
for n,prefix in [('github','.github'),('scripts','scripts'),('cc-eval','crates/cc-eval')]:
 es={x['path']:copy.deepcopy(x) for x in trees[n]['tree']}
 for x in changes:
  if x['path'].startswith(prefix+'/'):
   rel=x['path'][len(prefix)+1:]
   if x.get('before_sha256') is None:del es[rel]
   else:
    old=R8['actual_input_mode_blob_inventory'][x['path']];assert old['sha256']==x['before_sha256'];es[rel].update(mode=old['mode'],type=old['type'],sha=old['sha'],size=old['size'])
 rev[n]=rehash(list(es.values()))
rev['docs']=tree_hash([e for e in trees['docs']['tree'] if 'docs/'+e['path'] not in dc]);cr=copy.deepcopy(trees['crates']['tree']);next(x for x in cr if x['path']=='cc-eval')['sha']=rev['cc-eval'];rev['crates']=tree_hash(cr);back=copy.deepcopy(rt['tree'])
for n,prefix in [('github','.github'),('scripts','scripts'),('docs','docs'),('crates','crates')]:next(x for x in back if x['path']==prefix)['sha']=rev[n]
assert tree_hash(back)=='d8891f547c92044fd40b63165d6ef54cb6de8bab'
bm=json.loads(Path('/dev/shm/todo-audit-G8B-cb57d6e3-binding/allowlisted-delta-and-installation-manifest.json').read_text())
for x in bm['files']:
 a=actual[x['repository_path']];assert(a['sha'],a['mode'],a['size'])==(x['git_blob'],x['mode'],x['bytes'])
r={'schema_version':1,'source':P,'source_tree':T,'source_parents':[G8],'base':R8['base'],'observed_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'previous_review_path':str(R8P),'previous_review_sha256':sha(R8P.read_bytes()),'counts':{'product':1095,'BASE_delta':75,'validation':143,'mode_blob_inputs':1238},'complete_inputs':prod,'paths':paths,'validation_inputs':val,'actual_input_mode_blob_inventory':inv,'official_exact_seven_changes':changes,'actual_root_and_all_fetched_subtrees_rehashed':True,'reverse_exact_seven_changes_recovers_full_G8_tree':tree_hash(back),'directly_visible_input_leaves_verified':visible,'unchanged_remaining_inputs_method':'Complete independently accepted R8 map plus official exact7leaf diff and full reverse-tree equality. All other paths/modes/artifacts preserved.','old_bindings_actual_G8_blobs_preserved':True,'execution_credit':False,'preparation_transport_failure':'Initial longer script creation rejected by exec-server transport before process creation; no file or product execution; recoveredread-onlyprobe0 then this new finitehash audit.'}
p=D/'actual-PW1-complete-source-bridge.json';p.write_text(json.dumps(r,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'counts':r['counts'],'visible':visible,'reverse_tree':tree_hash(back)}))
