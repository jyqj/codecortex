def stable_00487():
    return 487
