Gc8 原十项完成条件映射（只读，未修改任务状态）

固定 source `c8be5afaac568ffd40ef86d3795423c3b73c9f39`，正式规模 run `37902429727` attempt 1。当前 **163 done / 29 remaining**；原规模 **3/150 片、32/1500 样本**。以下均沿用原任务定义及硬依赖。

| 原任务 | 自身证据足够关闭的条件 | 当前仍缺 |
|---|---|---|
| P8-005 完整规模1k到100k | 同一固定Gc8的release构建、五规模各30个原重复、150分片/1500样本及原严格aggregate成功；完整files/symbols/chunks/各edge/向量状态、资源与阶段原raw归属清楚。 | 147个尚未接受的原分片/1468个样本；原全150严格aggregate及其独立原件验收 |
| P8-006 增量规模与fanout曲线 | 同一完整scale总体的no-op/body/API/config/batch1/10/100/1000和1k专属五fanout各N30，闭包完整、每检查点原15表full parity/手写fanout见证及phase计时守恒通过。 | 剩余scale原九阶段及全部fanout N30覆盖；P8-005原完成 |
| P8-007 多并发与混合负载 | 原mixed C1/4/8/16每档完整900投递与全部终态、offer/queue/timeout/tail和C>1真实read/build交叠；另原backfill三seed×两phase×四C完整768请求、持有/恢复/排空。 | P8-006原硬依赖完成 |
| P8-008 冷建/重开/热查分层 | 原lifecycle分离30次真正空index/parse-cache冷建，以及reopen、uncached warm、cache-hit各400query；1230全样本/431进程会话及原统计重放，OS page-cache未清的事实保留。 | P8-007原硬依赖完成 |
| P8-009 内存/磁盘/费用总账 | 原lifecycle/mixed/scale的资源账本按client/server/有凭据process-tree和DB/WAL/SHM/FTS/cache分开，原字节/单位/采样归属与实际费用状态可核；缺失与不适用保持unavailable/null。 | 完整scale总体的原资源/阶段记录闭合；P8-008原硬依赖完成 |
| P8-010 长时soak与连续修改 | 原soak计划和实际工作均至少1小时、3601原操作完整终态、同一进程连续修改/删除/分支/catalog/cache复用、原RSS趋势与全时段coverage门、终点原完整15表full parity和统计重放通过。 | 当前原soak真实成功终态与完整封包验收；P8-009原硬依赖完成 |
| P8-011 端到端故障与恢复认证 | 原故障/恢复矩阵的kill/断网/cache损坏/DB busy/换库负例与原raw、真实stdio恢复和ready/删除不复活、请求/费用边界核验通过。 | P8-007与P8-010原硬依赖完成 |
| P8-012 MSRV与平台冷构建矩阵 | Linux/macOS×声明MSRV/stable×default/semantic八个原fresh-target冷构建+stdio均通过；原8格collector完整通过，SDK范围/实际编译器如实记录。 | P8-011原硬依赖完成 |
| P8-013 指标/门槛与失败退出最终认证 | 原scorer相关回归、六个原Rust失败门和七个retained CLI控制均验证quality/perf/inconclusive/lock/policy/overwrite的原非零退出与raw保留；原V20和上游依赖同时闭合。 | P8-012及其传递V20依赖完成；最终汇总适用V03/V04旧回归与失败门引用 |
| P8-016 数据库/配置/包回滚演练 | 原旧277f/新Gc8真实构建身份和受控schema重建/还原、default/semantic配置与用户源码保全、cache版本隔离/disabled回退、原DB完整性/FK和stdio回滚步骤实测通过。 | P8-012与P8-013原硬依赖完成 |

所有行还需其原硬依赖完成及相关旧功能回归通过。当前两项真正仍在执行的工作是完整规模矩阵和原一小时 soak；平台八格及原 collector、lifecycle、四档 mixed、backfill、故障恢复及失败门已有各 owner 的固定 Gc8 原件审核。完成依赖按原 P8-005→006→007→008→009→010，再到011→012→013/016顺序收口，不能把后段先通过的执行当作依赖已完成。

原 CI 的181 source tests和selected-v15已实际通过；实际checkout是合成merge39ae，其产品/验证/CI/原R目录等于Gc8，整仓树并不相同。没有为本映射重跑任何命令。

P8-005已允许的paired causal not_established和whole-tree peak unknown继续保留；分host描述性统计不变成稳定p99或同host N30要求。向量disabled、费用null、无法测得的资源unavailable等如实分栏。不能补新live/holdout/付费/冷OS-cache门，也不能用重跑替换失败primary。

详细原定义、源文件摘要、每项原依赖及已读证据摘要见 original-ten-task-closeout-map.json。
