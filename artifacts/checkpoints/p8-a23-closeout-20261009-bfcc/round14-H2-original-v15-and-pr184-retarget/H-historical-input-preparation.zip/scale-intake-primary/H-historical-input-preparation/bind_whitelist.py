import hashlib, json, collections, importlib.util, sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).parent
def load(p): return json.loads(p.read_text())
def api(n): return json.loads(load(ROOT/n)['content'])
def digest(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def tree_hash(entries):
    entries=sorted(entries,key=lambda e:(e['path']+('/' if e['type']=='tree' else '')).encode())
    body=b''.join((('40000' if e['mode']=='040000' else e['mode'])+' '+e['path']).encode()+b'\0'+bytes.fromhex(e['sha']) for e in entries)
    return hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).hexdigest()
spec=importlib.util.spec_from_file_location('original_helper',ROOT/'v15_historical_context.py'); h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
initial=load(ROOT/'protected-paths.initial.json')
current_path=Path('/dev/shm/todo-audit-pr180-merge-plan/new-main55aa-complete-derived-tree.json')
current=load(current_path); cm={r['path']:r for r in current['tree']}
children=collections.defaultdict(list)
for e in current['tree']:
    parent,_,name=e['path'].rpartition('/'); children[parent].append({**e,'path':name})
checked_trees={}
def check_subtree(prefix,expected):
    if prefix in checked_trees: assert checked_trees[prefix]==expected; return
    for e in children[prefix]:
        if e['type']=='tree': check_subtree(prefix+'/'+e['path'],e['sha'])
    assert tree_hash(children[prefix])==expected,(prefix,expected)
    checked_trees[prefix]=expected
base_root=api('BASE-root-tree-api.json');assert tree_hash(base_root['tree'])==base_root['sha']
equal_prefixes=[]
for prefix,name in [('artifacts','artifacts'),('docs','docs'),('artifacts/checkpoints','checkpoints')]:
    raw=api('BASE-'+name+'-root-api.json'); assert tree_hash(raw['tree'])==raw['sha']
    if prefix=='artifacts/checkpoints': assert next(e for e in api('BASE-artifacts-root-api.json')['tree'] if e['path']=='checkpoints')['sha']==raw['sha']
    else: assert next(e for e in base_root['tree'] if e['path']==prefix)['sha']==raw['sha']
    for e in raw['tree']:
        path=prefix+'/'+e['path']
        wanted=[x for x in initial['paths'] if x==path or x.startswith(path+'/')]
        if wanted and e['sha']==cm[path]['sha']:
            if e['type']=='tree': check_subtree(path,e['sha'])
            equal_prefixes.append({'path':path,'git_tree':e['sha'],'protected_paths_covered':len(wanted)})
audit=load(ROOT.parent/'round14-actual-P-independent/actual-P-complete-source-audit.json'); inventory=audit['actual_input_mode_blob_inventory']
base_validation=initial['historical_validation_entries']
for prefix,name in [('scripts','scripts'),('.github','github'),('tests','tests')]:
    raw=api('BASE-'+name+'-tree-api.json'); assert not raw['truncated']
    groups=collections.defaultdict(list)
    for e in raw['tree']:
        parent,_,namepart=e['path'].rpartition('/');groups[parent].append({**e,'path':namepart})
    for e in raw['tree']:
        if e['type']=='tree': assert tree_hash(groups[e['path']])==e['sha']
    assert tree_hash(groups[''])==raw['sha']
    assert next(e for e in base_root['tree'] if e['path']==prefix)['sha']==raw['sha']
out=[];catalogue=[]
for path in initial['all_catalogue_paths']:
    h.relative(path)
    if path in base_validation: original=base_validation[path]
    else:
        assert any(path==e['path'] or path.startswith(e['path']+'/') for e in equal_prefixes),path
        original=cm[path]
    assert original['type']=='blob' and original['mode'] in ('100644','100755')
    row={'path':path,'mode':original['mode'],'git_blob':original['sha'],'bytes':original['size'],'current_root_required':path in initial['paths']}
    if path in initial['paths']:
        if path in initial['explicit_records']:
            raw=load(ROOT/'explicit-api'/(original['sha']+'.json'))['content'].encode()
            assert blob(raw)==original['sha'] and len(raw)==original['size'],path
            expected=digest(raw); provenance='Exact official allowlisted explicit-record bytes rehashed in this preparation'
        elif path in initial['declared_hashes']:
            expected=initial['declared_hashes'][path][0]['sha256']; provenance='Expected SHA256 declared by immutable BASE registry; content is not reread here; actual current-root check remains original CLI'
        else:
            actual=inventory[path]
            assert all(actual[k]==original[k] for k in ['mode','type','sha','size']),path
            expected=actual['sha256']; provenance='Previously independently bound canonical P input SHA256; exact path/mode/blob/size equals BASE'
        if path in base_validation: assert all(inventory[path][k]==original[k] for k in ['mode','type','sha','size']),path
        row.update({'expected_sha256':expected,'sha256_provenance':provenance,'holdout_metadata_explicit_allowlist_only':path==h.EXPLICIT_RECORDS[-1]})
        out.append(row.copy())
    catalogue.append(row)
assert len(out)==236 and len(catalogue)==302
assert sum(x['bytes'] for x in catalogue)<=h.MAX_TOTAL and max(x['bytes'] for x in catalogue)<=h.MAX_BLOB
for reg in h.REGISTRIES:
    raw=(ROOT/'registries'/Path(reg).name).read_bytes();assert blob(raw)==base_validation[reg]['sha']
readback_path=Path('/dev/shm/todo-audit-pr180-generated-G-f89d5fee/actual-installed-P-R-G-H-readback.json')
readback=load(readback_path);assert readback['actual_commits']['H']['sha']==initial['current_head']
result={'schema':'original-v15-current-historical-input-preparation-v1','scope':'Exact declared current-root protected whitelist and immutable historical Git-object catalogue; not an execution, full current-root verification, or task credit','current_head':initial['current_head'],'historical_head':h.HISTORICAL_HEAD,'helper_sha256':initial['helper_sha256'],'protected_count':len(out),'catalogue_count':len(catalogue),'catalogue_bytes':sum(x['bytes'] for x in catalogue),'protected_bytes':sum(x['bytes'] for x in out),'current_root_H_inheritance':{'path':str(readback_path),'sha256':digest(readback_path.read_bytes()),'method':'Peer exact P/R/G/H whole-tree reconstruction and all old records preservation, plus our canonical P139 validation binding; H original CLI remains pending'},'metadata_proof':{'BASE_root_tree':base_root['sha'],'same_immutable_subtrees_from_BASE_and_current55aa':equal_prefixes,'derived_subtrees_individually_Git_rehashed':len(checked_trees),'current55aa_metadata_path':str(current_path),'current55aa_metadata_sha256':digest(current_path.read_bytes())},'expected_sha256_provenance_counts':dict(collections.Counter(x['sha256_provenance'] for x in out)),'protected_inputs':out,'historical_catalogue_inputs':catalogue,'safety':{'original_relative_called_for_every_path':True,'unallowlisted_holdout_body_read':False,'original_CLI_or_proof_executed':False,'source_or_original_guard_changed':False,'historical_caps_unchanged':True,'no_lazy_fetch_setting_changed':True},'limitations':['This prepares existing original inputs; it is not a new admission gate.','181 registry-declared SHA256 expectations are not recast as a fresh content audit. Original current-file/hash comparison remains the original CLI responsibility.','Native caller must obtain listed BASE Git blobs explicitly before an offline GIT_NO_LAZY_FETCH proof; no broad corpus/body checkout is authorized by this list.','One earlier metadata-inspection helper assumed inventory list instead of dict and raised TypeError before generating any whitelist binding; corrected here.']}
for name,data in [('protected-input-whitelist.json',result),('historical-catalogue-git-objects.json',{'historical_head':h.HISTORICAL_HEAD,'entries':catalogue})]:
    p=ROOT/name;p.write_text(json.dumps(data,indent=2)+'\n');print(name,p.stat().st_size,digest(p.read_bytes()))
print(json.dumps({k:result[k] for k in ['protected_count','catalogue_count','catalogue_bytes','protected_bytes','expected_sha256_provenance_counts']}))
