def stable_00110():
    return 110
