def stable_00389():
    return 389
