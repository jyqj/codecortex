def stable_00112():
    return 112
