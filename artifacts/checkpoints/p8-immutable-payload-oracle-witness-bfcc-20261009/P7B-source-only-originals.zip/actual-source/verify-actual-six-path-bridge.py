#!/usr/bin/env python3
"""Read-only actual commit/source bridge. Never execute product or modify inputs."""
import argparse
import hashlib
import json
from pathlib import Path

G6 = '88d5f547bb0fae273f4270742503fd1fd5e70bc2'
G6_TREE = 'e039a817291934b15cc018fd74d2c83982bb7f37'
BASE = '7354db236c9d9850a75f31672697ae9eab44565e'
R6_SHA = 'b1bd27baa86c7beb38b92f29d36723fa715f72498646a796d12916a5a9bccd13'
R6 = Path('/dev/shm/todo-audit-P6B-crash-ready-source-review/final-R6B/independent-source-review.json')
AB = Path('/dev/shm/execution-recon-recovery-20261009/round21-payload-reuse-candidate/v2/source-manifest.json')
ORACLE = Path('/dev/shm/todo-audit-round21-oracle-order-witness-peer/attempt02/independent-source-review.json')
ORACLE_ROOT = ORACLE.parent / 'source'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def load(path):
    return json.loads(Path(path).read_bytes())

def response(path):
    value = load(path)
    if 'structuredContent' in value:
        value = value['structuredContent']
    if isinstance(value, dict) and isinstance(value.get('content'), str):
        value = json.loads(value['content'])
    return value

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--commit', required=True)
    ap.add_argument('--compare', required=True)
    ap.add_argument('--source', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()
    out = Path(args.output)
    assert not out.exists(), 'fresh output only'
    oldraw = R6.read_bytes()
    assert sha(oldraw) == R6_SHA
    old = json.loads(oldraw)
    assert old['base'] == BASE and len(old['complete_inputs']) == 1095
    assert len(old['validation_inputs']) == 142 and len(old['paths']) == 72
    assert old['verdict'] == 'accepted_scoped' and old['unresolved_blockers'] == []
    ab = load(AB)
    oracle = load(ORACLE)
    assert ab['base_commit'] == G6 and oracle['blockers'] == []
    assert oracle['verdict'] == 'accepted_scoped_source_pending_original_Rust_validation'
    selected = {}
    for item in ab['files']:
        selected[item['path']] = (Path(item['candidate_path']), item['before'], item['after'])
    for item in oracle['sources']:
        selected[item['path']] = (ORACLE_ROOT / item['path'], item['original'], item['candidate'])
    assert len(selected) == 6
    actual = response(args.commit)
    compare = response(args.compare)
    assert actual['sha'] == args.source
    assert [p['sha'] for p in actual['parents']] == [G6]
    assert compare['base_commit']['sha'] == G6
    assert compare['base_commit']['commit']['tree']['sha'] == G6_TREE
    assert compare['total_commits'] == 1
    assert len(compare['commits']) == 1 and compare['commits'][0]['sha'] == args.source
    assert compare['commits'][0]['commit']['tree']['sha'] == actual['tree']['sha']
    changed = {f['filename']: f for f in compare['files']}
    assert len(compare['files']) == len(changed) == 6 and set(changed) == set(selected)
    complete = dict(old['complete_inputs'])
    inventory = {p: dict(v) for p, v in old['actual_input_mode_blob_inventory'].items()}
    six = []
    for path, (local, before, after) in sorted(selected.items()):
        original = inventory[path]
        assert original['mode'] == '100644' and original['type'] == 'blob'
        assert original['sha256'] == before['sha256'] == complete[path]
        assert original['sha'] == before['git_blob'] and original['size'] == before['bytes']
        raw = local.read_bytes()
        assert len(raw) == after['bytes'] and sha(raw) == after['sha256']
        assert blob(raw) == after['git_blob'] == changed[path]['sha']
        assert changed[path]['status'] == 'modified'
        complete[path] = sha(raw)
        inventory[path] = dict(mode='100644', type='blob', sha=blob(raw), size=len(raw), sha256=sha(raw))
        six.append(dict(path=path, local_path=str(local), before=before, after=after))
    # Reconstruct BASE digests from the immutable complete-domain and canonical
    # before-values, then recalculate the complete historical delta. This does
    # not reuse the prior delta count or append untyped candidate objects.
    base_map = dict(old['complete_inputs'])
    for path, item in old['paths'].items():
        assert set(item) == {'before_sha256', 'sha256'}
        assert item['sha256'] == old['complete_inputs'][path]
        if item['before_sha256'] is None:
            del base_map[path]
        else:
            base_map[path] = item['before_sha256']
    assert set(base_map) <= set(complete)
    delta = {p: dict(before_sha256=base_map.get(p), sha256=s)
             for p, s in complete.items() if base_map.get(p) != s}
    assert len(delta) == 75
    assert all(inventory[p] == old['actual_input_mode_blob_inventory'][p]
               for p in inventory if p not in selected)
    assert all(inventory[p]['sha256'] == s for p, s in old['validation_inputs'].items())
    result = dict(schema_version=1, source=args.source, source_tree=actual['tree']['sha'],
                  source_parents=[G6], base=BASE, previous_review_sha256=R6_SHA,
                  counts=dict(product=len(complete), validation=len(old['validation_inputs']),
                              mode_blob_inputs=len(inventory), BASE_delta=len(delta)),
                  six_changes=six, complete_inputs=complete,
                  validation_inputs=old['validation_inputs'], paths=delta,
                  actual_input_mode_blob_inventory=inventory,
                  all_other_git_paths_preserved_by_official_six_path_compare=True,
                  source_execution='not_run', verification='actual_read_only_assertions_passed')
    with out.open('xb') as f:
        f.write((json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode())
    print(json.dumps(dict(source=args.source, tree=actual['tree']['sha'], counts=result['counts'],
                          bytes=out.stat().st_size, sha256=sha(out.read_bytes()))))

if __name__ == '__main__':
    main()
