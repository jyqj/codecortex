#!/usr/bin/env python3
"""Verify actual diagnostic Git composition and prepare the original v15 checkout."""
import datetime, hashlib, json, os, pathlib, stat, subprocess
ROOT=pathlib.Path("/workspace/scratch/a217aaae3bde")
OUT=ROOT/"p8-db-lock-observation-integration"
REPO=ROOT/"codecortex-recovered"
VIEW=ROOT/"p8-lock-observation-validated"
cfg=json.loads((OUT/"final-composition-inputs.json").read_text())
def git(*args): return subprocess.check_output(["git","-C",str(REPO),*args])
def sha(raw): return hashlib.sha256(raw).hexdigest()
def oid(raw): return hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
def leaves(ref):
    out={}
    for row in git("ls-tree","-r","-z",ref).split(b"\0"):
        if not row: continue
        meta,path=row.decode().split("\t",1); mode,kind,blob=meta.split()
        out[path]={"mode":mode,"type":kind,"sha":blob}
    return out
def exact_commit(ref,tree,parent):
    value=git("show","-s","--format=%T%n%P",ref).decode().splitlines()
    assert value==[tree,parent],(ref,value)
def delta(before,after):
    return {p:after.get(p) for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)}
def expected(rows): return {x["path"]:{k:x[k] for k in ("mode","type","sha")} for x in rows}
def raw_blob(ref,path):
    raw=git("show",ref+":"+path)
    assert oid(raw)==manifests[ref][path]["sha"],path
    return raw
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
refs=[cfg["parent"],cfg["product"],cfg["review"],cfg["guard"]]
manifests={ref:leaves(ref) for ref in refs}
exact_commit(cfg["product"],cfg["product_tree"],cfg["parent"])
exact_commit(cfg["review"],cfg["review_tree"],cfg["product"])
exact_commit(cfg["guard"],cfg["guard_tree"],cfg["review"])
p_delta=delta(manifests[cfg["parent"]],manifests[cfg["product"]])
r_delta=delta(manifests[cfg["product"]],manifests[cfg["review"]])
g_delta=delta(manifests[cfg["review"]],manifests[cfg["guard"]])
assert p_delta==expected(cfg["product_elements"]) and len(p_delta)==15
assert r_delta==expected(cfg["review_elements"]) and len(r_delta)==69
assert all(p.startswith("artifacts/") and p not in manifests[cfg["product"]] for p in r_delta)
assert g_delta==expected(cfg["guard_elements"]) and len(g_delta)==2
checked=[]
for ref,paths in [(cfg["product"],p_delta),(cfg["review"],r_delta),(cfg["guard"],g_delta)]:
    for path in paths:
        raw=raw_blob(ref,path)
        checked.append({"source":ref,"path":path,**manifests[ref][path],"bytes":len(raw),"sha256":sha(raw)})
core=raw_blob(cfg["review"],cfg["core_path"])
assert oid(core)==cfg["core_blob"] and sha(core)==cfg["core_sha256"]
review=json.loads(core)
registry_path="scripts/reviewed-source-registry-v15.json"
verifier_path="scripts/verify_reviewed_source_v15.py"
registry_raw=raw_blob(cfg["guard"],registry_path)
verifier_raw=raw_blob(cfg["guard"],verifier_path)
assert sha(registry_raw)==cfg["registry_sha256"] and sha(verifier_raw)==cfg["verifier_sha256"]
registry=json.loads(registry_raw)
for key,filename in [("complete_inputs","product-domain.json"),("validation_inputs","validation-domain.json"),("delta","historical-delta.json")]:
    value=json.loads((OUT/filename).read_text())
    assert registry[key]==value,(key,"registry")
    assert review["paths" if key=="delta" else key]==value,(key,"review")
assert registry["product_source"]==cfg["product"] and registry["review_source"]==cfg["review"]
assert registry["review_sha256"]==sha(core)
old_verifier=raw_blob(cfg["parent"],verifier_path).decode()
new_verifier=verifier_raw.decode()
replacements={
    "PRODUCT = ": cfg["product"],
    "REVIEW = ": cfg["review"],
    "REVIEW_PATH = ": cfg["core_path"],
    "REGISTRY_SHA256 = ": cfg["registry_sha256"],
}
lines=old_verifier.splitlines(keepends=True)
for prefix,value in replacements.items():
    hits=[i for i,line in enumerate(lines) if line.startswith(prefix)]
    assert len(hits)==1,(prefix,hits)
    lines[hits[0]]=prefix+json.dumps(value)+"\n"
assert "".join(lines)==new_verifier,"guard changes beyond four pins"
old_registry=json.loads(raw_blob(cfg["parent"],registry_path))
allowed_registry={"product_source","review_source","review_sha256","complete_inputs","validation_inputs","delta"}
assert {k for k in old_registry.keys()|registry.keys() if old_registry.get(k)!=registry.get(k)}==allowed_registry
assert review["source"]==cfg["product"] and review["base"]==cfg["base"]
assert review["verdict"]=="accepted_scoped" and review["unresolved_blockers"]==[]
assert len(registry["complete_inputs"])==1094 and len(registry["validation_inputs"])==142
assert VIEW.is_dir() and not VIEW.is_symlink(),"resume the exact prepared worktree only"
assert subprocess.check_output(["git","-C",str(VIEW),"rev-parse","HEAD"]).decode().strip()==cfg["guard"]
assert subprocess.check_output(["git","-C",str(VIEW),"sparse-checkout","list"]).decode().splitlines()==["/*","!/artifacts/"]
subprocess.run(["git","-C",str(VIEW),"read-tree","-m","-u","HEAD"],check=True)
assert subprocess.check_output(["git","-C",str(VIEW),"rev-parse","HEAD"]).decode().strip()==cfg["guard"]
copied=[]
for src in sorted((REPO/"artifacts").rglob("*")):
    if not src.is_file(): continue
    assert not src.is_symlink(),str(src)
    path=src.relative_to(REPO).as_posix()
    leaf=manifests[cfg["guard"]].get(path)
    assert leaf and leaf==manifests[cfg["parent"]].get(path),path
    raw=src.read_bytes()
    assert oid(raw)==leaf["sha"] and leaf["type"]=="blob" and leaf["mode"] in ("100644","100755"),path
    dst=VIEW/path
    assert dst.is_file() and not dst.is_symlink(),path
    assert dst.read_bytes()==raw and stat.S_IMODE(dst.stat().st_mode)==int(leaf["mode"][-3:],8),path
    copied.append({"path":path,**leaf,"bytes":len(raw),"sha256":sha(raw)})
target=VIEW/cfg["core_path"]
assert target.is_file() and not target.is_symlink() and target.read_bytes()==core
assert stat.S_IMODE(target.stat().st_mode)==0o644
for path in list(p_delta)+list(g_delta):
    target=VIEW/path
    assert target.is_file() and not target.is_symlink()
    assert oid(target.read_bytes())==manifests[cfg["guard"]][path]["sha"]
proof={"schema":"p8-db-lock-observation-actual-composition-and-preparation-v1","started_at":started,"finished_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"verdict":"passed_actual_composition_and_preparation","source":cfg["guard"],"parents_and_trees":{k:cfg[k] for k in ("parent","product","product_tree","review","review_tree","guard","guard_tree")},"actual_product_delta":p_delta,"actual_review_delta":r_delta,"actual_guard_delta":g_delta,"actual_blob_reads":checked,"complete_inputs":len(registry["complete_inputs"]),"validation_inputs":len(registry["validation_inputs"]),"historical_delta":len(registry["delta"]),"original_verifier_logic_unchanged":True,"pin_assignments_changed":list(replacements),"registry_changed_keys":sorted(allowed_registry),"verified_original_artifacts_materialized_during_attempt_v1":copied,"additional_artifact_copies_this_attempt":0,"prior_preparation_attempt":"source-worktree-preparation-attempt-v1.json","preparation_recovery":"Explicit read-tree -m -u HEAD materialized the exact sparse LG source; no source, guard, or acceptance predicate edit.","review_materialized":{"path":cfg["core_path"],"sha256":sha(core),"git_blob":oid(core),"bytes":len(core)},"worktree":str(VIEW),"original_source_guard_execution":"pending","rust_or_native_execution":"not_run","todo_closures":0,"todo_remaining":29}
raw=(json.dumps(proof,indent=2,sort_keys=True)+"\n").encode()
(OUT/"root-actual-composition-and-preparation.json").write_bytes(raw)
print(json.dumps({"status":proof["verdict"],"source":cfg["guard"],"checked_blob_reads":len(checked),"verified_preexisting_original_artifacts":len(copied),"verified_preexisting_original_bytes":sum(x["bytes"] for x in copied),"report":str(OUT/"root-actual-composition-and-preparation.json"),"report_bytes":len(raw),"report_sha256":sha(raw),"guard_execution":"pending"}))

