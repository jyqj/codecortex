def stable_00095():
    return 95
