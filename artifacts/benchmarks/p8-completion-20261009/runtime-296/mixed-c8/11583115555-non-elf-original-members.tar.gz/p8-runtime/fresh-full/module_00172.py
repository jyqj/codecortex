def stable_00172():
    return 172
