"""Interpret only newly retained complete event lines, without semantic replay."""
import collections
import datetime
import hashlib
import json
from pathlib import Path
import stat
import zipfile

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'round35-diagnostic-checkpoint-02-intake/attempt01'
OLD = ROOT / 'round34-diagnostic-checkpoint-01-intake/attempt01'
BUILD = ROOT / 'round33-PR200-build-capacity-original-intake/attempt01'
BINDING = ROOT / 'round32-100k-diagnostic-intake-bound-9cc6-run38012409915/binding.json'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def identity(p):
    raw = p.read_bytes()
    return {'local_path': str(p), 'bytes': len(raw), 'sha256': sha(raw),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
            'posix_mode': oct(stat.S_IMODE(p.stat().st_mode))}

def save(p, value):
    with p.open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

reader = json.loads((OUT / 'reader/report.json').read_text())
execution = json.loads((OUT / 'reader.execution.json').read_text())
old = json.loads((OLD / 'checkpoint01-prefix-review.json').read_text())
assert execution['exit_code'] == 0
assert execution['validate_build_calls'] == execution['validate_shard_calls'] == execution['inspect_raw_calls'] == execution['ELF_calls'] == 0
assert {x['id'] for x in reader['artifacts']} == {'11655358015', '11655694522', '11656371239'}
new = next(x for x in reader['artifacts'] if x['id'] == '11656371239')
binding = json.loads(BINDING.read_text())
built = json.loads((BUILD / 'original-validate-build-result.json').read_text())['original_build_record']
selected = OUT / 'selected-originals'
selected.mkdir(exist_ok=False)
with zipfile.ZipFile(new['zip_path']) as z:
    manifest_raw = z.read('manifest.json')
    manifest = json.loads(manifest_raw)
    (selected / 'manifest.json').write_bytes(manifest_raw)
    for item in manifest['metadata_snapshots']:
        value = z.read(item['file'])
        assert len(value) == item['bytes'] and sha(value) == item['sha256']
        (selected / item['file']).write_bytes(value)
    chunks = [c for c in reader['streams']['shard/native/raw.jsonl']['chunks']
              if any(loc['artifact_id'] == '11656371239' for loc in c['retained_locations'])]
    assert len(chunks) == 1
    chunk = chunks[0]
    location = next(x for x in chunk['retained_locations'] if x['artifact_id'] == '11656371239')
    raw = z.read(location['member'])
    assert len(raw) == chunk['bytes'] and sha(raw) == chunk['sha256']
    (selected / location['member']).write_bytes(raw)
config = json.loads((selected / 'configuration.json.snapshot').read_text())
assert config['original_build_receipt_sha256'] == identity(BUILD / 'extracted/build/build.json')['sha256']
assert config['original_driver_sha256'] == built['driver_sha256']
assert (selected / 'configuration.json.snapshot').read_bytes() == (OLD / 'selected-originals/configuration.json.snapshot').read_bytes()
assert chunk['start'] == old['verified_prefixes']['shard/native/raw.jsonl']['end_exclusive']
assert old['new_raw_interval']['partial_tail_bytes'] == 0
events, intervals, failures = [], [], []
offset = chunk['start']
lines = raw.splitlines(keepends=True)
for number, line in enumerate(lines):
    row = {'new_line_index': number, 'start': offset, 'end': offset + len(line), 'bytes': len(line),
           'sha256': sha(line), 'complete_newline': line.endswith(b'\n')}
    offset += len(line)
    if not row['complete_newline']:
        row['status'] = 'partial_tail_not_a_complete_event'
    else:
        try:
            event = json.loads(line)
            events.append(event)
            row.update(event=event.get('event'), label=event.get('label'), status='complete_original_event')
        except (ValueError, UnicodeError) as error:
            row.update(status='complete_line_parse_error', error=str(error))
            failures.append(row)
    intervals.append(row)
new_counts = collections.Counter(x.get('event') for x in events)
total_counts = collections.Counter(old['new_raw_interval']['cumulative_complete_event_counts']) + new_counts
unfinished = list(old['started_but_not_finished_in_retained_prefix'])
for event in events:
    if event.get('event') == 'build_started':
        unfinished.append(event)
    elif event.get('event') == 'build_finished':
        unfinished = [x for x in unfinished if x['label'] != event['label']]
finished = [x for x in events if x.get('event') == 'build_finished']
current = next(x for x in reader['checkpoints'] if x['index'] == 2)
assert len(current['acknowledgements']) == 2 and all(x['retained_original_and_official_digest_verified'] is True for x in current['acknowledgements'])
parity_records = [e for e in events if e.get('event') == 'cold_parity']
parity_summaries = []
for e in parity_records:
    p = e['parity']
    parity_summaries.append({'sample': e['sample'], 'parity_wall_us': e['parity_wall_us'],
        'original_equal': p.get('equal'), 'original_status': p.get('status'),
        'original_table_count': len(p['tables']), 'original_tables': p['tables'],
        'original_different_tables': p.get('different_tables'), 'canonical_bytes': p.get('canonical_bytes'),
        'scratch_peak_bytes': p.get('scratch_peak_bytes'), 'capacity_profile': p.get('capacity_profile'),
        'oracle_mode': p.get('oracle_mode'), 'storage_layout': p.get('storage_layout'),
        'sorting_cache_kib': p.get('sorting_cache_kib'), 'limits': p.get('limits'),
        'independent_config_fact': e.get('independent_config_fact'),
        'boundary': 'These are original emitted report fields; check_parity, inspect_raw and validate_shard were not executed. This summary does not replace their predicates.'})
report = {'schema': 'p8-original-diagnostic-checkpoint02-prefix-review-v1',
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source': binding['G'], 'run_id': binding['run_id'], 'attempt': 1,
    'scope': 'First checkpoint02 custody intake with accepted00/01 read only as frozen-reader continuity and ACK dependencies. No original semantic replay, ELF, measurement or network transport.',
    'new_original_artifact': new,
    'old_continuity_artifact_ids': [11655358015, 11655694522], 'old_bytes_reread_by_frozen_reader': True,
    'previous_accepted_review': identity(OLD / 'checkpoint01-prefix-review.json'),
    'frozen_reader_execution': identity(OUT / 'reader.execution.json'), 'reader_exit_code': 0,
    'accepted_diagnostic_build_reused_without_revalidation': {'result': identity(BUILD / 'original-validate-build-result.json'),
        'receipt': identity(BUILD / 'extracted/build/build.json'), 'configuration_receipt_exact': True,
        'configuration_bytes_identical_to_checkpoint01': True, 'not_full_cohort_build': True},
    'verified_prefixes': {name: {'start': 0, 'end_exclusive': r['verified_retained_contiguous_chunk_prefix_bytes'],
        'highest_declared_offset': r['highest_declared_offset'], 'unknown_tail_bytes': None, 'EOF_claimed': False}
        for name, r in reader['streams'].items()},
    'new_raw_interval': {**chunk, 'ends_in_newline': raw.endswith(b'\n'), 'original_line_intervals': intervals,
        'new_complete_event_counts': dict(new_counts), 'cumulative_complete_event_counts': dict(total_counts),
        'complete_line_parse_errors': failures, 'partial_tail_bytes': 0 if not lines or lines[-1].endswith(b'\n') else len(lines[-1])},
    'checkpoint02_ACKs_of_00_and_01': current['acknowledgements'],
    'checkpoint02_own_ACK_boundary': 'This snapshot precedes its own upload; its later local ACK is not supplied. Official artifact custody is independently verified.',
    'capture_faults_observed': reader['capture_faults'], 'metadata_parse_unknown': reader['metadata_parse_unknown'],
    'observer_before_seen_and_bound': reader['observer_before_seen'], 'observer_after_seen': reader['observer_after_seen'],
    'new_emitted_parity_report_fields': parity_summaries,
    'new_finished_build_records': finished,
    'started_but_not_finished_in_retained_prefix': unfinished,
    'visible_frontier': 'The emitted cold_parity record is followed by no_op mutation and incremental-0 completion, then no_op/full_control start. No corresponding full_control finish or no_op stage_finished appears in the retained prefix. Current hidden execution state is unknown.',
    'cold_parity_events': total_counts.get('cold_parity', 0), 'stage_finished_events': total_counts.get('stage_finished', 0),
    'supervisor_terminal_seen': bool(reader['supervisor_receipts']), 'native_report_seen': bool(reader['native_reports']),
    'reported_native_outcome': reader['reported_native_outcome'], 'custody_status': reader['custody_status'],
    'timing_boundary': 'Original wall/phase/build counters only. Timers overlap and are not added. No predicted speedup or completion is inferred.',
    'original_function_calls': {'validate_build': 0, 'validate_shard': 0, 'inspect_raw': 0, 'check_parity': 0, 'ELF': 0},
    'full_cohort_run_not_mixed': 38013753078, 'accepted_cohort_shards': 0, 'accepted_samples': 0, 'TODO_credit': 0}
save(OUT / 'checkpoint02-prefix-review.json', report)
print(json.dumps({'report': identity(OUT / 'checkpoint02-prefix-review.json'), 'new_events': dict(new_counts),
    'raw_contiguous_bytes': reader['streams']['shard/native/raw.jsonl']['verified_retained_contiguous_chunk_prefix_bytes'],
    'current_native_outcome': reader['reported_native_outcome']}))
