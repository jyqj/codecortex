# committed protocol-control fixture: scripts/p8_cold_build.py
