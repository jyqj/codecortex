#!/usr/bin/env python3
"""Package already-reviewed source bytes; no product/CLI/workload execution."""
from pathlib import Path
import hashlib
import json
import stat
import zipfile

HERE = Path(__file__).resolve().parent
OUT = HERE / 'final-R7B'
PREFIX = 'artifacts/checkpoints/p8-immutable-payload-oracle-witness-bfcc-20261009'
R6PATH = Path('/dev/shm/todo-audit-P6B-crash-ready-source-review/final-R6B/independent-source-review.json')
ABROOT = Path('/dev/shm/execution-recon-recovery-20261009/round21-payload-reuse-candidate')
OROOT = Path('/dev/shm/todo-audit-round21-oracle-order-witness-peer')
PROOT = Path('/dev/shm/pr-triage-round21-immutable-reuse-peer')

def load(p):
    return json.loads(Path(p).read_bytes())

def meta(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                git_blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest())

def dump(p, x):
    data=(json.dumps(x, ensure_ascii=False, indent=2, sort_keys=True)+'\n').encode()
    with p.open('xb') as f:
        f.write(data)
    return meta(data)

assert not OUT.exists(), 'fresh final output only'
OUT.mkdir()
old = load(R6PATH)
bridge = load(HERE/'actual-P7B-complete-source-bridge.json')
trees = load(HERE/'official-tree-mode-verification-receipt.json')
assert trees['exit_code'] == 0
assert bridge['source'] == '8831de11bc8d33735b665efda6c8aa511e4f1660'
assert bridge['source_tree'] == '0d11a30f319703aa528cc997baa5fc7619c8f1ca'
assert bridge['counts'] == dict(product=1095, validation=142, mode_blob_inputs=1237, BASE_delta=75)
abpeer = load(PROOT/'candidate-v2-source-review.json')
oracle = load(OROOT/'attempt02/independent-source-review.json')
assert abpeer['unresolved_source_blockers'] == [] and oracle['blockers'] == []
selected = {}

def add(path, name, expected=None):
    path=Path(path)
    assert path.is_file() and not path.is_symlink()
    raw=path.read_bytes()
    if expected:
        assert len(raw)==expected['bytes'] and meta(raw)['sha256']==expected['sha256']
    assert name not in selected and not name.startswith('/') and '..' not in Path(name).parts
    selected[name]=(path,raw,stat.S_IMODE(path.stat().st_mode))

for root, filename, dest in [(ABROOT,'archive-selection.v2.json','ab-author'),
                            (OROOT,'archive-selection.v2.json','oracle-peer'),
                            (PROOT,'archive-selection.json','payload-peer')]:
    sel=load(root/filename)
    for f in sel.get('entries',sel.get('files',[])):
        local=Path(f.get('local_path') or f['path'])
        relative=local.relative_to(root).as_posix()
        add(local,dest+'/'+relative,f)
    add(root/filename,dest+'/'+filename)
for name in ['verify-actual-six-path-bridge.py','verify-official-tree-modes.py',
             'actual-P7B-complete-source-bridge.json','official-tree-mode-verification-receipt.json',
             'P7B-commit.original.json','G6B-to-P7B-compare.original.json',
             'package-canonical-R7B.py']:
    add(HERE/name,'actual-source/'+name)
for p in sorted((HERE/'git-trees').glob('*.json')):
    add(p,'actual-source/git-trees/'+p.name)
add('/dev/shm/root-round21/P7B-created-objects-original.json','actual-source/root-P7B-created-objects-original.json')
for s in oracle['sources']:
    p=Path('/dev/shm/root-round21/oracle-order-witness/original')/s['path']
    add(p,'oracle-original/'+s['path'],s['original'])
r6meta=meta(R6PATH.read_bytes())
assert r6meta['sha256']=='b1bd27baa86c7beb38b92f29d36723fa715f72498646a796d12916a5a9bccd13'
oldlocator=dict(commit='22975e49107b3832f438f85b17275110fc0afa02',
                path=old['review_path'],source=old['source'],source_tree=old['source_tree'],
                **r6meta, purpose='Immutable complete inherited review; not embedded in this package')
outside=dict(previous_canonical=oldlocator,previous_support=old['review_support'],
             old_measurements='All previous studies/CI keep their own source and terminal records; no old ZIP embedded or relabeled.',
             oracle_python_design_probe='Separately authorized bounded Python/SQLite risk comparison is pending at review preparation; not Rust execution or scale evidence.',
             packaging_preparation='An initial read-only selection inspection used files instead of entries and raised KeyError; no source or selection changed. Final packager reads either documented collection.')
locator_path=OUT/'inherited-original-locators.json'
dump(locator_path,outside)
add(locator_path,'inherited-original-locators.json')
manifest=dict(schema_version=1,scope='selected complete source and reviews; not a full repository or runtime artifact',
              file_count=len(selected), total_bytes=sum(len(v[1]) for v in selected.values()),
              files=[dict(archive_path=k,local_path=str(v[0]),posix_mode=format(v[2],'04o'),**meta(v[1]))
                     for k,v in sorted(selected.items())])
manifest_raw=(json.dumps(manifest,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode()
zip_path=OUT/'P7B-source-only-originals.zip'
with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,(_p,raw,mode) in sorted(selected.items()):
        zi=zipfile.ZipInfo(name,date_time=(2026,10,9,0,0,0));zi.create_system=3
        zi.external_attr=(stat.S_IFREG|mode)<<16;zi.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(zi,raw)
    zi=zipfile.ZipInfo('support-member-manifest.json',date_time=(2026,10,9,0,0,0));zi.create_system=3
    zi.external_attr=(stat.S_IFREG|0o644)<<16;zi.compress_type=zipfile.ZIP_DEFLATED
    z.writestr(zi,manifest_raw)
with zipfile.ZipFile(zip_path) as z:
    assert len(z.infolist())==len(selected)+1 and z.testzip() is None
    for name,(_p,raw,mode) in selected.items():
        info=z.getinfo(name);assert z.read(name)==raw and stat.S_IMODE(info.external_attr>>16)==mode
    assert z.read('support-member-manifest.json')==manifest_raw
zipmeta=meta(zip_path.read_bytes())
assert zipmeta['bytes']<8*1024*1024
(OUT/'support-member-manifest.json').write_bytes(manifest_raw)
canonical=dict(schema_version=1,base=bridge['base'],source=bridge['source'],
               source_tree=bridge['source_tree'],source_parents=bridge['source_parents'],
               scope='independently_reviewed_source_and_validation_inputs',verdict='accepted_scoped',
               independent_reviewers=['/root/pr_triage'],unresolved_blockers=[],
               review_path=PREFIX+'/independent-source-review.json',
               complete_inputs=bridge['complete_inputs'],paths=bridge['paths'],
               validation_inputs=bridge['validation_inputs'],
               actual_input_mode_blob_inventory=bridge['actual_input_mode_blob_inventory'],
               author_independence=dict(current_reviewer='/root/pr_triage',
                   payload_reuse_author='/root/execution_recon',oracle_author_and_commit_creator='/root',
                   oracle_independent_semantic_reviewer='/root/todo_audit',
                   current_reviewer_role='Direct non-author A/B source review; actual combined six-leaf/domain review; inherited oracle semantic review bound to its exact final bytes. No source edits or Git mutations.'),
               primary_review=dict(actual_source_bridge=dict(counts=bridge['counts'],
                   source_bridge_file='actual-source/actual-P7B-complete-source-bridge.json',
                   source_bridge_sha256=meta((HERE/'actual-P7B-complete-source-bridge.json').read_bytes())['sha256'],
                   official_exact_six_modified_paths=[x['path'] for x in bridge['six_changes']],
                   thirteen_official_directory_objects_rehashed=True,
                   reverse_only_six_leaves_recovers_entire_G6B_tree=True,
                   all_other_git_paths_and_modes_preserved=True,
                   old142_validation_and_CI_FROZEN_bindings_preserved=True,
                   BASE_delta_method='Reconstruct immutable BASE hashes from inherited canonical complete domain and before_sha256 values, then recalculate every current after-value. Three previously BASE-equal leaves become deltas; no removals, 75 exact dictionaries.'),
                   payload_reuse_review=dict(path='payload-peer/candidate-v2-source-review.json',
                       **meta((PROOT/'candidate-v2-source-review.json').read_bytes()),findings=abpeer['production_semantics'],
                       v1_fixture_defect_and_v2_correction=abpeer['v1_blocker_resolution']),
                   oracle_review=dict(path='oracle-peer/attempt02/independent-source-review.json',
                       **meta((OROOT/'attempt02/independent-source-review.json').read_bytes()),
                       reviewer='/root/todo_audit',source_findings=oracle['source_findings'],
                       controls=oracle['test_source_assessment'],mechanical_checks=oracle['mechanical_checks']),
                   composition='Six paths are disjoint, all based on the same G6B domain; oracle.rs, workload, drivers, budgets, CI and all validation inputs remain inherited unchanged.'),
               previous_fixed_reviews=[dict(oldlocator,scope='Complete source and validation inheritance only; old execution and negative evidence retain identity.')],
               historical_preservation=dict(whole_tree='All old artifact/source/validation paths except six reviewed product leaves are identical to G6B; reverse tree proof verifies this.',
                   earlier_negatives='Old formatter/test/compile/ready failures, C3ff/Gc8 deadlines, incomplete studies, transport and review-preparation failures are not erased or relabeled.',
                   current_preparation='v1 missing configuration fixture and oracle attempt01 hash mismatch/12-line erratum are retained in original support; none was a Rust execution failure.',
                   unrelated_SQL='PR188 SQL adoption/performance counterevidence is separate and not included in this six-path product.'),
               current_execution=dict(actual_P7B=dict(rustfmt='not_run',Rust_tests='not_run',Clippy='not_run',source_CLI='not_run',runtime_or_scale='not_run'),
                   inherited_execution='G6B and all earlier CI/workload results retain original source; no inherited run is a run of P7B.',
                   mechanical_source_assertions=dict(actual_exit=trees['exit_code'],scope='hash/tree/source identity only'),
                   limited_python_SQLite_design_probe='pending at canonical preparation; separately retained if completed; never Rust or primary performance evidence'),
               review_support=dict(originals_zip_repository_path=PREFIX+'/'+zip_path.name,
                   **zipmeta,selected_files=len(selected),zip_members=len(selected)+1,
                   all_members_CRC_bytes_modes_verified=True,
                   contents='Complete six before/after source paths, original patches/peer reviews, preparation corrections, actual commit/compare/tree objects, full current input bridge and read-only scripts. Prior large canonical/ZIP referenced by immutable locator, not nested.'),
               unresolved_blocker_scope='No remaining source-semantic or identity blocker. Formatting, compilation, Rust tests, Clippy, original source admission and independent performance evaluation remain pending execution and are not waived.',
               task_and_release_boundary=dict(done=163,remaining=29,newly_completed=0,formal_completion=False,release_or_full_scale_pass=False,no_additional_test_or_study_gate=True))
assert set(canonical['complete_inputs'])==set(old['complete_inputs'])
assert canonical['validation_inputs']==old['validation_inputs']
assert all(set(v)=={'before_sha256','sha256'} for v in canonical['paths'].values())
review_path=OUT/'independent-source-review.json'
reviewmeta=dump(review_path,canonical)
uploads=dict(schema_version=1,source=bridge['source'],source_tree=bridge['source_tree'],
             intended_review_parent=bridge['source'],scope='exactly two new artifact paths; no source or bindings mutation',
             files=[dict(local_path=str(review_path),repository_path=PREFIX+'/'+review_path.name,mode='100644',**reviewmeta),
                    dict(local_path=str(zip_path),repository_path=PREFIX+'/'+zip_path.name,mode='100644',**zipmeta)])
manifestmeta=dump(OUT/'upload-manifest.json',uploads)
print(json.dumps(dict(canonical=reviewmeta,support=zipmeta,support_members=len(selected)+1,upload_manifest=manifestmeta)))
