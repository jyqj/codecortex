#!/usr/bin/env python3
import datetime,hashlib,json,subprocess,sys
from pathlib import Path
B=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
argv=[sys.executable,str(B/'package-checkpoint.py')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (B/'package.stdout').open('xb') as o,(B/'package.stderr').open('xb') as e:r=subprocess.run(argv,stdout=o,stderr=e,check=False)
receipt={'argv':argv,'actual_exit_code':r.returncode,'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Evidencepackaging only; no product/validator/tests/network/Git execution','stdout_sha256':sha((B/'package.stdout').read_bytes()),'stderr_sha256':sha((B/'package.stderr').read_bytes())}
write(B/'packaging-command-receipt.json',receipt);print(json.dumps(receipt))
if r.returncode:sys.exit(r.returncode)
out=B/'sealed-attempt01'
for n in ['package.stdout','package.stderr','packaging-command-receipt.json']:(out/n).write_bytes((B/n).read_bytes())
cfg=json.loads((B/'package-inputs.final.json').read_bytes());files=[]
for n in ['round22-selected-evidence.zip','round22-member-index.json','round22-summary.json','round22-formal-closeout.json','README.md','packaging-command-receipt.json','package.stdout','package.stderr']:
 p=out/n;b=p.read_bytes();files.append({'repository_path':cfg['repository_prefix']+n,'local_path':str(p),'mode':'100644','type':'blob','bytes':len(b),'sha256':sha(b),'git_blob':blob(b)})
write(out/'root-upload-manifest.json',{'scope':'Round22 selectedoriginalevidence only','files':files,'file_count':len(files),'remote_objects_created':False,'fresh_publication_lease_required':True})
print(json.dumps({'manifest':str(out/'root-upload-manifest.json'),'file_count':len(files)}))
