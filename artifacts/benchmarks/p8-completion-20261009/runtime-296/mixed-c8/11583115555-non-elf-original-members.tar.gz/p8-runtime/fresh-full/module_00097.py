def stable_00097():
    return 97
