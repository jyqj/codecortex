def stable_00386():
    return 386
