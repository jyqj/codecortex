#!/usr/bin/env python3
"""Seal selected original evidence, without network, source execution, or Git writes."""
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'sealed-attempt01'
OUT.mkdir(exist_ok=False)
REPO_PREFIX = 'artifacts/checkpoints/p8-a23-closeout-20261009-bfcc/round18-closeout'
CHECKPOINT = '3548736f0dd42304e6b5f06f40007a756df6a361'
GROUPS = [
    ('H-original-success', '/dev/shm/execution-recon-recovery-20261009/H-main-CI-terminal-round18/archive-selection.json', '15a05cedf366971d9224e5d860335500ed9e43d1bf647ba4a07b43d04c27a1f2', 10),
    ('G4-preparation', '/dev/shm/todo-audit-P4-G4-binding-preparation/archive-selection.json', 'b6e0aa397706c1c088c93fb1315546011403264daf793d8fd32edd36736022e8', 21),
    ('G4-generation', '/dev/shm/todo-audit-G4-b4ad0852-binding/archive-selection.json', '216dae8b7c87441fd70cd0fd5444193b2c14684ad10c94250be3ba4a701e5775', 13),
    ('R4-G4-installation-peer', '/dev/shm/pr-triage-P4-original-rustfmt-source-review/installed-R4-G4-review/archive-selection.json', '613bb02120067413ce974db87cef35c700a466012b9f528c9a30f614681f3fe6', 14),
    ('G4-first-CI-observation', '/dev/shm/pr-triage-G4-first-published-CI-observation/archive-selection.json', 'b7b7a8c39f806b41d10b34e77992ee068f674ef5bc298952b3239c436b3e1b8e', 12),
]
ROOT_RECEIPTS = [
    'P4-create-commit-original.json', 'P4-create-tree-original.json',
    'PR180-round18-comment-original.json', 'PR184-superseded-close-original.json',
    'checkpoint-publication-original.json',
    'R4-create-commit-original.json', 'R4-create-tree-original.json',
    'G4-create-commit-original.json', 'G4-create-tree-original.json',
    'G4-official-commit-readback.json', 'G4-official-two-leaf-readback.json',
    'PR188-G4-publication-original.json', 'round18-ended-round19-opened.json',
]

def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def js(value): return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2)+'\n').encode()
def file_record(path):
    b = path.read_bytes()
    return {'local_path': str(path), 'bytes': len(b), 'sha256': sha(b), 'git_blob': blob(b), 'mode': '100644'}

payload = {}
members = []
source_records = []
selections = []

def add_bytes(name, raw, mode=0o644):
    p = PurePosixPath(name)
    assert not p.is_absolute() and '..' not in p.parts and '\\' not in name and '\x00' not in name
    assert name not in payload and not name.endswith('.zip')
    payload[name] = (raw, mode)
    members.append({'path': name, 'bytes': len(raw), 'sha256': sha(raw), 'git_blob': blob(raw), 'posix_mode': format(mode, '04o')})

def add_original(path, member, expected=None, origin=None):
    assert path.is_file() and not path.is_symlink()
    before = path.stat()
    assert stat.S_ISREG(before.st_mode)
    raw = path.read_bytes()
    mode = stat.S_IMODE(before.st_mode)
    if expected:
        assert len(raw) == expected['bytes'] and sha(raw) == expected['sha256'], str(path)
        if expected.get('git_blob'):
            assert blob(raw) == expected['git_blob']
        declared = expected.get('posix_mode', expected.get('mode'))
        if declared and len(str(declared)) <= 4:
            assert mode == int(str(declared), 8)
    add_bytes(member, raw, mode)
    source_records.append({'local_path': str(path), 'member': member, 'bytes': len(raw), 'sha256': sha(raw), 'git_blob': blob(raw), 'posix_mode': format(mode,'04o'), 'source_mtime_ns': before.st_mtime_ns, 'selection_origin': origin})

for group, path, expected_sha, count in GROUPS:
    p = Path(path)
    raw = p.read_bytes()
    assert sha(raw) == expected_sha
    selected = json.loads(raw)
    assert len(selected['files']) == selected['file_count'] == count
    assert sum(r['bytes'] for r in selected['files']) == selected['total_bytes']
    selections.append({'group': group, 'path': str(p), 'bytes': len(raw), 'sha256': sha(raw), 'file_count': count, 'selected_bytes': selected['total_bytes']})
    add_original(p, 'selections/'+group+'.json', origin=group)
    for row in selected['files']:
        relative = row.get('archive_path', row.get('relative_path', row.get('repository_path')))
        assert relative
        add_original(Path(row['local_path']), 'evidence/'+group+'/'+relative, row, group)
assert sum(s['file_count'] for s in selections) == 70
root_base = Path('/dev/shm/root-round18')
for name in ROOT_RECEIPTS:
    add_original(root_base/name, 'evidence/root-round18/'+name, origin='root-round18-receipts')

main_manifest = json.loads(Path('/dev/shm/todo-audit-round18-selected-checkpoint/sealed-attempt02/final-root-upload-manifest.json').read_text())
main_zip = next(r for r in main_manifest['files'] if r['repository_path'].endswith('.zip'))
R_manifest = json.loads(Path('/dev/shm/pr-triage-P4-original-rustfmt-source-review/upload-manifest.json').read_text())
R_zip = next(r for r in R_manifest['files'] if r['repository_path'].endswith('.zip'))
locators = {'schema': 'existing-durable-evidence-immutable-locators-v1', 'not_nested_in_this_archive': [
    {'purpose':'round18-main-selected-source-and-four-C-package','commit':CHECKPOINT,'repository_path':main_zip['repository_path'],'bytes':main_zip['bytes'],'sha256':main_zip['sha256'],'git_blob':main_zip['expected_git_blob'],'url':'https://github.com/jyqj/codecortex/blob/'+CHECKPOINT+'/'+main_zip['repository_path']},
    {'purpose':'R4-source-only-64-member-originals','commit':'b4ad0852fb0f164f89ba194409e2a78578f5413f','repository_path':R_zip['repository_path'],'bytes':R_zip['bytes'],'sha256':R_zip['sha256'],'git_blob':R_zip['git_blob'],'ZIP_members':64,'url':'https://github.com/jyqj/codecortex/blob/b4ad0852fb0f164f89ba194409e2a78578f5413f/'+R_zip['repository_path']},
]}
assert main_zip['bytes'] == 4348998 and R_zip['bytes'] == 562491
transition = json.loads((root_base/'round18-ended-round19-opened.json').read_text())
observation = json.loads(Path('/dev/shm/pr-triage-G4-first-published-CI-observation/first-published-G4-CI-observation.json').read_text())
assert transition['round18']['new_original_TODO_completed'] == 0 and transition['round18']['remaining_original_TODO'] == 29
assert observation['source_G'] == 'cc177ddc9e6b8180b8d847539787672e7b689a1a'
assert observation['actual_jobs'] == {'queued':25,'in_progress':0,'success':0,'failure':0,'steps_present':0,'assigned_runner_count':0}
summary = {
    'schema':'round18-closeout-selected-original-evidence-v1',
    'sealed_at_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'round18':{'status':'ended','new_original_TODO_completed':0,'done':163,'remaining':29,'total':192},
    'round19':{'status':'active','initial_remaining':29},
    'source_chain':{'P4':'1930b8e37e24031c3779553e3fc5b95e8e946d50','R4':'b4ad0852fb0f164f89ba194409e2a78578f5413f','G4':observation['source_G'],'G4_tree':observation['source_tree']},
    'G4_CI_at_retained_publication_observation':{'workflow_runs_created':7, **observation['actual_jobs'], 'job_denominator_final':False, 'platform_downstream_collector_not_yet_created':True, 'actual_executed_checkout':None,'test_merge':observation['prospective_merge']['sha'],'test_merge_entire_tree_equals_G4':True,'execution_accepted':False},
    'H_original_CI':{'run':37936553220,'source':'0e6b07c75183da79c5a6679d4c2b66c65f7db663','check_job':113839937923,'conclusion':'success','descendant_fixture_actual_passes':2,'not_transferred_to_G4':True},
    'PR184':{'status':'closed_as_superseded_not_merged','head':'883230f2b44ebcf09495870db8c0e31d61270331','engineering_and_evidence_absorbed_in_PR180_at':'b2a17adc188338c48b95d01761836916e5d0fcdb','product_files':7,'evidence_files':7,'source_specific_bindings_distinct':2,'branch_and_history_retained':True},
    'scope':'Selected original closeout evidence only. Original pending and failure records are preserved byte-for-byte. The prior main checkpoint and R4 originals ZIP are immutable references, not nested copies. No execution or task-credit follows from packaging.',
    'source_selections':selections,'root_receipts':ROOT_RECEIPTS,
    'no_network_native_workload_test_or_remote_write':True,
}
selected_manifest = {'schema':'closeout-original-source-custody-v1','files':source_records,'file_count':len(source_records),'all_declared_hashes_sizes_modes_checked':True}
for name, value in [('immutable-evidence-locators.json',locators),('checkpoint-summary.json',summary),('selected-original-manifest.json',selected_manifest)]:
    raw=js(value)
    (OUT/name).write_bytes(raw)
    add_bytes(name,raw)
add_original(Path(__file__), 'packaging/package-closeout.py', origin='actual-packager')
archive = OUT/'round18-closeout-originals.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name in sorted(payload):
        raw, mode = payload[name]
        info = zipfile.ZipInfo(name, date_time=(2026,10,9,0,0,0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG|mode)<<16
        info.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(info,raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert sorted(z.namelist()) == sorted(payload) and len(z.namelist()) == len(payload)
    for item in z.infolist():
        expected,mode = payload[item.filename]
        assert z.read(item) == expected
        assert stat.S_IMODE(item.external_attr>>16) == mode
for row in source_records:
    p=Path(row['local_path']);raw=p.read_bytes()
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256'] and blob(raw)==row['git_blob']
    assert format(stat.S_IMODE(p.stat().st_mode),'04o')==row['posix_mode']
member_manifest={'schema':'verified-ZIP-member-manifest-v1','ZIP':file_record(archive),'member_count':len(members),'total_uncompressed_bytes':sum(r['bytes']for r in members),'files':sorted(members,key=lambda x:x['path']),'all_member_bytes_SHA_Gitblob_POSIX_modes_and_CRC_verified':True,'source_files_unchanged_after_packaging':True,'ZIP_timestamp_policy':'Fixed container timestamp 2026-10-09 00:00:00; source mtime_ns separately retained; no execution time inferred from ZIP headers.'}
(OUT/'zip-member-manifest.json').write_bytes(js(member_manifest))
receipt={'schema':'actual-closeout-packaging-result-v1','status':'sealed_verified','actual_source_selections':len(GROUPS),'selected_original_files':70,'selection_manifests':5,'root_receipts':len(ROOT_RECEIPTS),'ZIP':file_record(archive),'ZIP_member_count':len(members),'source_integrity_before_after':True,'all_zip_members_CRC_SHA_bytes_mode':True,'remote_uploaded':False,'base_checkpoint_for_root_normal_fast_forward':CHECKPOINT,'nested_prior_ZIPs':0,'product_or_CI_execution':False}
(OUT/'packaging-result.json').write_bytes(js(receipt))
manifest={'schema':'root-upload-closeout-manifest-v1','artifact_only':True,'suggested_parent_checkpoint':CHECKPOINT,'remote_uploaded':False,'files':[]}
for name in ['round18-closeout-originals.zip','zip-member-manifest.json','checkpoint-summary.json','immutable-evidence-locators.json','selected-original-manifest.json','packaging-result.json']:
    row=file_record(OUT/name);row['repository_path']=REPO_PREFIX+'/'+name;manifest['files'].append(row)
(OUT/'upload-manifest.pending-receipt.json').write_bytes(js(manifest))
print(json.dumps(receipt,sort_keys=True))
