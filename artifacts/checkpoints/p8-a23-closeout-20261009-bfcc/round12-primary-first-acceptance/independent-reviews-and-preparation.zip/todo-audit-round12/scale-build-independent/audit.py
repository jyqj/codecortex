import datetime
import hashlib
import json
from pathlib import Path
import struct
import zipfile

BASE = Path('/workspace/scratch/bfccb8494ba0')
OUT = BASE / 'todo-audit-round12/scale-build-independent'
RAW = BASE / 'scale-intake-primary/raw/37902429727/11603522248/attempt-03'
ART = RAW / 'extracted'
REPLAY = BASE / 'scale-intake-primary/build-validation-11603522248'
CANONICAL = BASE / 'pr-triage-primary-recovery/runtime-review-Gc8/exact-canonical-R.json'
G = 'c8be5afaac568ffd40ef86d3795423c3b73c9f39'
P = '35a7b3412e5fdee9e8ff88951735c06b0e371465'
R = 'a9706a90a72226cb59c3bfd374ef9c1e3d66cbcb'


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def record(path):
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def read(path):
    return json.loads(path.read_bytes())


before = {p.name: record(p) for p in ART.iterdir() if p.is_file()}
official = read(OUT / 'official-artifact-job-chain.json')
meta = official['artifact']
zip_path = RAW / 'p8-scale-build-37902429727-original.zip'
assert meta['id'] == 11603522248 and meta['workflow_run']['id'] == 37902429727
assert meta['workflow_run']['head_sha'] == G and not meta['expired']
assert zip_path.stat().st_size == meta['size_in_bytes'] == 9223368
assert sha(zip_path) == meta['digest'].removeprefix('sha256:')
zip_members = []
with zipfile.ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    assert {i.filename for i in archive.infolist() if not i.is_dir()} == set(before)
    for entry in archive.infolist():
        if entry.is_dir():
            continue
        data = archive.read(entry)
        assert data == (ART / entry.filename).read_bytes()
        zip_members.append(dict(name=entry.filename, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), crc32=entry.CRC))

assert sha(CANONICAL) == 'c38d10f1b0d5935384039a6af7df6e8d222bc351a68d3137b09e664735ee9404'
review = read(CANONICAL)
assert review['source'] == P and review['verdict'] == 'accepted_scoped'
assert not review['unresolved_blockers']
assert review['complete_input_count'] == 1090 and review['validation_input_count'] == 139
chain = official['chain']
for key, expected, parent in [('G', G, R), ('R', R, P), ('P', P, '9f7b16f0758eb79f306cf44605b84550f02de441')]:
    assert chain[key]['sha'] == expected and [p['sha'] for p in chain[key]['parents']] == [parent]
assert chain['P']['tree']['sha'] == review['reviewed_product_tree']

source_before = read(ART / 'source-before.json')
assert (ART / 'source-before.json').read_bytes() == (ART / 'source-after.json').read_bytes()
assert source_before['source_commit'] == G
assert source_before['source_tree'] == chain['G']['tree']['sha']
assert source_before['input_count'] == len(source_before['inputs']) == 1090
assert set(source_before['inputs']) == set(review['complete_inputs'])
path_comparison = []
for path, value in sorted(review['complete_inputs'].items()):
    actual = source_before['inputs'][path]
    assert actual == value, path
    path_comparison.append(dict(path=path, review_sha256=value, before_sha256=actual, after_sha256=actual, equal=True))
manifest = (json.dumps(source_before['inputs'], ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
assert hashlib.sha256(manifest).hexdigest() == source_before['manifest_sha256']

build = read(ART / 'build.json')
assert build['source_commit'] == G and build['source_manifest_sha256'] == source_before['manifest_sha256']
assert build['status'] == 'passed' and type(build['exit_code']) is int and build['exit_code'] == 0
assert build['driver_source']['source_commit'] == G
for path, value in build['driver_source']['inputs'].items():
    assert review['validation_inputs'][path] == value
    assert sha(BASE / 'candidate-ready-signal-github' / path) == value
for name, expected in build['files'].items():
    assert expected == {k: before[name][k] for k in ['bytes', 'sha256']}, name
assert build['command'] == ['cargo', 'build', '--release', '--locked', '-p', 'cc-eval', '--bin', 'p8-scale', '--message-format=json', '--target-dir', '/home/runner/work/_temp/p8-scale-cargo']
cargo_rows = [json.loads(line) for line in (ART / 'cargo.jsonl').read_text().splitlines()]
targets = [row for row in cargo_rows if row.get('reason') == 'compiler-artifact' and row.get('target', {}).get('name') == 'p8-scale' and row.get('executable')]
assert len(targets) == 1 and targets[0] == build['cargo_artifact']
target = targets[0]
assert target['fresh'] is False and target['features'] == ['default']
assert target['target']['kind'] == ['bin'] and target['target']['crate_types'] == ['bin']
assert target['target']['src_path'] == build['build_root'] + '/crates/cc-eval/src/bin/p8-scale.rs'
assert target['profile'] == dict(debug_assertions=False, debuginfo=0, opt_level='3', overflow_checks=False, test=False)
assert target['executable'] == build['copy_source']['path'] == build['target_directory'] + '/release/p8-scale'
assert [r for r in cargo_rows if r.get('reason') == 'build-finished'] == [dict(reason='build-finished', success=True)]
assert not [r for r in cargo_rows if r.get('reason') == 'compiler-message' and r.get('message', {}).get('level') == 'error']
binary = ART / 'p8-scale'
assert sha(binary) == build['binary_sha256'] == build['copy_source']['sha256']
assert binary.stat().st_size == build['binary_bytes'] == build['copy_source']['bytes'] == 28276728
with binary.open('rb') as stream:
    header = stream.read(64)
assert header[:4] == b'\x7fELF' and header[4:6] == b'\x02\x01' and struct.unpack_from('<H', header, 18)[0] == 62
assert 'rustc 1.95.0' in build['toolchain']['rustc'] and 'host: x86_64-unknown-linux-gnu' in build['toolchain']['rustc']
assert 'cargo 1.95.0' in build['toolchain']['cargo']
logs = (OUT / 'original-build-job-113727856139.log').read_text()
assert 'git checkout --progress --force ' + G in logs
assert 'git log -1 --format=%H' in logs and G in logs
assert 'python3 scripts/p8_scale_matrix.py build' in logs
assert all(step['conclusion'] == 'success' for step in official['job_steps']['steps'])
validation = read(REPLAY / 'receipt.json')
assert type(validation['actual_exit']) is int and validation['actual_exit'] == 0
assert validation['status'] == 'original_validate_build_passed'
assert validation['source_G'] == G and validation['binary_sha256'] == sha(binary)
assert validation['binary_blake3'] == build['binary_blake3']
assert read(REPLAY / 'original-function-output.json')['build_record'] == build
after = {p.name: record(p) for p in ART.iterdir() if p.is_file()}
assert before == after

report = dict(
    schema_version=1, kind='independent_original_scale_build_and_source_audit', reviewer='/root/todo_audit',
    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), verdict='accepted_scoped', errors=[],
    scope='Original build/source identity only; not CI admission or measurement acceptance.',
    run_id=37902429727, run_attempt=1, job_id=113727856139, artifact_id=11603522248,
    source=dict(G=G, R=R, P=P, G_tree=source_before['source_tree'], P_tree=review['reviewed_product_tree']),
    actual_checkout=dict(kind='direct immutable G checkout', commit=G, evidence=record(OUT / 'original-build-job-113727856139.log')),
    canonical_review=record(CANONICAL), product_input_count=1090, validation_input_count=139,
    source_before_after=record(ART / 'source-before.json'), source_before_after_equal=True,
    complete_product_maps_equal_canonical_R=True, path_comparison_file='product-map-comparison.json',
    driver_inputs=build['driver_source'], build_started_utc=build['started_utc'], build_finished_utc=build['finished_utc'],
    original_command=build['command'], cargo_target=target, toolchain=build['toolchain'], environment=build['environment'],
    binary=dict(**record(binary), format='ELF64 little-endian x86-64', original_recorded_blake3=build['binary_blake3'],
                blake3_scope='Root original validate_build invoked this retained ELF hash function and exited0; this independent audit did not rerun it.'),
    original_validator_receipt=record(REPLAY / 'receipt.json'), original_validator_actual_exit=0,
    original_validator_function_output=record(REPLAY / 'original-function-output.json'),
    original_zip=dict(**record(zip_path), official_digest=meta['digest']), zip_members=zip_members,
    all_original_extracted_files_unchanged=True, original_files=before,
    limits=['No new build, measurement, source CLI or product execution was started by this audit.',
            'Build source map has path/SHA entries; it is not a hermetic compiler-input attestation.',
            'CI181 and selected v15 remain separate pending original CI evidence.',
            'No150/1500 aggregate or TODO completion credit; original29 remaining.',
            'Old G9f or other-source measurements are not substituted.'],
    task_credit=0, remaining=29)
for name, value in [('product-map-comparison.json', path_comparison), ('independent-build-source-review.json', report)]:
    raw = (json.dumps(value, ensure_ascii=True, sort_keys=True, indent=2) + '\n').encode()
    with (OUT / name).open('xb') as stream:
        stream.write(raw)
    print(json.dumps(dict(path=str(OUT / name), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())))
