def stable_00305():
    return 305
