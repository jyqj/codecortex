from pathlib import Path,PurePosixPath
import sys,json,hashlib,zipfile,stat,re,shutil,datetime,platform
zip_path=Path(sys.argv[1]);base=Path(sys.argv[2]);meta_path=Path(sys.argv[3]);a=json.loads(meta_path.read_text());transport_attempt=int(sys.argv[4]);run=json.loads(Path(sys.argv[5]).read_text())
assert transport_attempt>=1 and run['run_attempt']==1 and a['workflow_run']['id']==run['id'] and a['workflow_run']['head_sha']==run['head_sha']=='c8be5afaac568ffd40ef86d3795423c3b73c9f39'
assert run['id'] in (37901930897,37901930818,37901931021,37901930843) and not a['expired']
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(n,j):
 with (base/n).open('x') as f:json.dump(j,f,ensure_ascii=False,indent=2);f.write('\n')
zsha=sha(zip_path);assert zip_path.stat().st_size==a['size_in_bytes'] and a['digest']=='sha256:'+zsha
members=[];seen=set()
with zipfile.ZipFile(zip_path) as z:
 for m in z.infolist():
  raw=m.orig_filename;p=PurePosixPath(raw);normalized=str(p).rstrip('/');mode=(m.external_attr>>16)&0xffff
  assert '\x00' not in raw and raw==m.filename and '\\' not in raw and not p.is_absolute() and '..' not in p.parts and not re.match(r'^[A-Za-z]:',raw)
  assert normalized not in ('','.') and raw.rstrip('/')==normalized and normalized not in seen
  assert stat.S_IFMT(mode) in (0,stat.S_IFREG,stat.S_IFDIR) and not stat.S_ISLNK(mode) and not(m.flag_bits&1)
  seen.add(normalized);members.append({'name':raw,'normalized_name':normalized,'bytes':m.file_size,'compressed_bytes':m.compress_size,'crc32':'%08x'%m.CRC,'mode':mode,'is_directory':m.is_dir(),'sha256':None})
 total=sum(x['bytes'] for x in members);assert shutil.disk_usage(base).free>total+1024**3
 extract=base/'extracted';extract.mkdir()
 for zi,m in zip(z.infolist(),members):
  target=extract/PurePosixPath(m['normalized_name']);assert target.resolve().is_relative_to(extract.resolve())
  if zi.is_dir():
   with z.open(zi) as f:assert f.read()==b'' and zi.file_size==0
   target.mkdir(parents=True,exist_ok=True);continue
  target.parent.mkdir(parents=True,exist_ok=True)
  with z.open(zi) as source,target.open('xb') as output:shutil.copyfileobj(source,output,1048576)
  assert target.stat().st_size==m['bytes'];m['sha256']=sha(target)
  if m['mode']&0o777:target.chmod(m['mode']&0o777)
assert sha(zip_path)==zsha
write('zip-members.json',members)
r={'schema_version':1,'artifact_id':a['id'],'source':a['workflow_run']['head_sha'],'run_id':a['workflow_run']['id'],'run_attempt':1,'status':'transport_verified','transport_attempt':transport_attempt,'original_zip_path':str(zip_path),'zip_bytes':zip_path.stat().st_size,'zip_sha256':zsha,'official_size':a['size_in_bytes'],'official_digest':a['digest'],'members':len(members),'uncompressed_bytes':total,'all_member_crc_reads_completed':True,'all_regular_members_sha256_recorded':True,'original_zip_unchanged':True,'transport_method':'Formal file_id materialize performed by root; this process only reads existing materialized ZIP and extracts to fresh directory.','primary_host':platform.platform(),'extracted_modes':'Archived permission bits restored when present; original ZIP external attributes separately recorded.','verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'semantic_validation':'pending','measurement_or_TODO_credit':False}
write('transport-receipt.json',r);print(json.dumps(r))

