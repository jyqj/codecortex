import pathlib,json,hashlib,zipfile
R=pathlib.Path('/workspace/scratch/bfccb8494ba0');O=pathlib.Path(__file__).parent;D=R/'round47-complete45-original-aggregate-recovery'
def ident(p):
 b=p.read_bytes();return {'local_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def write(p,j):
 with p.open('x') as f:json.dump(j,f,ensure_ascii=False,indent=2);f.write('\n')
paths=[p for p in O.iterdir() if p.is_file()]+[D/n for n in ['original-recovery-execution.json','original-function-call-counts.json','input-identity-comparison.json','inputs-before.json','inputs-after.json','actual-native-hash-child-trace.json','original-return-vs-matrix.json','invoke-original-aggregate-once.py','capture-original-recovery-once.py','bound-complete-inputs.json']]+list(D.glob('child-hash-*.original'))
rows=[{'archive_path':str(p.relative_to(R)),**ident(p)} for p in sorted(set(paths))]
write(O/'publication-selection.json',{'schema':'complete45-original-recovery-peer-selection-v1','files':rows,'large_original_return_matrix_and_whole_raw_not_reembedded':True,'original_execution_artifacts_external':[ident(D/'original-aggregate-return.json'),ident(D/'aggregate-output/task-matrix.json')],'peer_original_functions_calls':0})
with zipfile.ZipFile(O/'peer-support.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for row in rows:z.write(row['local_path'],row['archive_path'])
 z.write(O/'publication-selection.json','publication-selection.json')
with zipfile.ZipFile(O/'peer-support.zip') as z:
 assert z.testzip() is None and set(z.namelist())=={r['archive_path'] for r in rows}|{'publication-selection.json'}
 for row in rows:assert hashlib.sha256(z.read(row['archive_path'])).hexdigest()==row['sha256']
prefix='artifacts/checkpoints/p8-round47-complete-bfcc-20261010/aggregate/recovery-peer/'
write(O/'upload-manifest.prepared.json',{'repository_full_name':'jyqj/codecortex','files':[{'repository_path':prefix+n,**ident(O/n)} for n in ['independent-complete45-aggregate-recovery-review.json','peer-support.zip','publication-selection.json']]})
print((O/'upload-manifest.prepared.json').read_text())
