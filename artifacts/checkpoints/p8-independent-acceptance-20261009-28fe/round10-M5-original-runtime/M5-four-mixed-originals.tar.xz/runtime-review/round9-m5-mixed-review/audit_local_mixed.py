"""Independent complete retained local M5 mixed audit; no native product execution.
Use only after the root-owned wrapper completes original mixed and verify phases.
"""
from pathlib import Path
from types import SimpleNamespace
import datetime,hashlib,json,sys,traceback
import review_mixed_logic as m
import review_helpers as a
ROOT=Path('/workspace/scratch/28fef0db5e01');RUN=ROOT/'runtime-review/m5-local-mixed';BUILD=ROOT/'runtime-review/m5-local-soak/build';SOURCE=ROOT/'runtime-review/m5-local-soak/source';OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(SOURCE/'scripts'))
import p8_runtime_build as build
import p8_runtime as runtime
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
class LocalArchive:
 def __init__(self,paths):self.paths=paths
 def __enter__(self):return self
 def __exit__(self,*args):return False
 def getinfo(self,name):
  p=self.paths[name];return SimpleNamespace(filename=name,file_size=p.stat().st_size)
 def open(self,name):return self.paths[name.filename if hasattr(name,'filename') else name].open('rb')
 def read(self,name):
  with self.open(name) as f:return f.read()
def local_archive(meta):
 c=meta['concurrency'];paths={};hashes={}
 for prefix,folder in [('p8-build/',BUILD),('p8-runtime/',RUN/f'c{c}/runtime')]:
  for p in folder.rglob('*'):
   if p.is_symlink():raise ValueError('symlink original artifact')
   if p.is_file():
    name=prefix+p.relative_to(folder).as_posix();paths[name]=p;hashes[name]={'bytes':p.stat().st_size,'sha256':sha(p)}
 out={'local_original_directory':str(RUN/f'c{c}/runtime'),'source_commit':m.HEAD,'single_shared_build_directory':str(BUILD),'original_file_count':len(paths),'all_original_file_bytes':sum(x['bytes'] for x in hashes.values()),'input_inventory':hashes};m.REPORT['artifacts'][meta['id']]=out
 return LocalArchive(paths),hashes,out
m.a.archive=local_archive
m.REPORT['scope']='Fixed local M5 original mixed C1/4/8/16, each900ops,1000files,500ms; shared original build and host,overlapping M5soak; no reviewer product execution or causal timing inference'
def main():
 receipt_raw=(RUN/'execution-receipt.json').read_bytes();receipt=json.loads(receipt_raw)
 if receipt['status']=='running':raise RuntimeError('Original wrapper still running; final audit refused until original phases settle')
 m.REPORT['started_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();m.REPORT['execution_receipt_sha256']=hashlib.sha256(receipt_raw).hexdigest();m.REPORT['wrapper_sha256']=sha(RUN/'run_original_mixed_matrix.py');m.REPORT['execution_environment']=receipt['execution_environment'];m.REPORT['build_scope']=receipt['build_scope']
 identity=build.verify_receipt(SOURCE,BUILD/'build-receipt.json',{n:BUILD/n for n in build.TARGETS})
 m.check('fixed_shared_M5_build_identity',identity['source']['source_commit']==m.HEAD and receipt['source_and_build_before']==receipt['source_and_build_after'])
 m.check('four_caps_no_extra_cells',sorted(c['concurrency'] for c in receipt['cells'])==[1,4,8,16])
 for cell in receipt['cells']:
  c=cell['concurrency'];m.CURRENT='c'+str(c);m.check('original_cell_and_both_phase_exits',cell['status']=='passed' and [p['name'] for p in cell['phases']]==['mixed','verify'] and all(p['status']=='passed' and p['exit_code']==0 and p['source_and_build_before']==p['source_and_build_after']==receipt['source_and_build_before'] for p in cell['phases']))
  for phase in cell['phases']:
   p=Path(phase['log_path']);m.check('original_phase_log/'+phase['name'],p.stat().st_size==phase['log_bytes'] and sha(p)==phase['log_sha256'])
  if cell['status']!='passed' or any(p['exit_code']!=0 for p in cell['phases']):
   folder=RUN/f'c{c}/runtime';original=json.loads((folder/'report.json').read_bytes())
   m.REPORT.setdefault('blocked_cells',[]).append({'concurrency':c,'cli_status':cell['status'],'phase_exits':{p['name']:p['exit_code'] for p in cell['phases']},'original_report_status':original['status'],'original_report_exit_code':original['exit_code'],'original_report_sha256':sha(folder/'report.json'),'seal_present':(folder/'seal.json').exists(),'diagnostic_snapshot':'failed-originals/failure-readback.json','acceptance':False,'full_success_audit_not_attempted':'Original CLI/verify failed; no seal repair, file exclusion, or reclassification.'})
   continue
  m.runtime({'id':m.CURRENT,'concurrency':c},c)
  folder=RUN/f'c{c}/runtime';report=json.loads((folder/'report.json').read_bytes());plan=json.loads((folder/'plan.json').read_bytes());seal=runtime.verify_output(folder)
  rows=[json.loads(line) for line in (folder/'raw.jsonl').read_bytes().splitlines()];ops=[r for r in rows if r['kind']=='operation'];resources=[r for r in rows if r['kind']=='resources'];cleanup=report['owned_cleanup']
  m.check('M5_owned_writers_and_construction_closed',cleanup=={'unfinished_work':0,'sampler_stopped':True,'product_stopped':True,'comparison_product_stopped':True,'product_construction_pending':False,'comparison_product_construction_pending':False} and report['artifact_seal_status']=='sealed' and report['artifact_seal']=='seal.json')
  m.check('M5_retention_integrity',not (folder/'terminal-retention-failures.json').exists() and 'terminal_retention_failures' not in report and 'unfinished_work' not in report and 'artifact_seal_error' not in report)
  m.check('M5_runtime_build_input_exact',plan['build_identity']==report['final_build_verification']==identity)
  m.check('M5_original_raw_budget',runtime.MAX_RAW_BYTES==536870912 and (folder/'raw.jsonl').stat().st_size<=runtime.MAX_RAW_BYTES)
  coverage=report['resource_time_coverage'];m.check('M5_resource_coverage_reconstructed',runtime.sample_coverage(resources,coverage['work_start_ns'],coverage['work_end_ns'])==coverage)
  m.check('M5_rss_rule_reconstructed',runtime.rss_trend(resources)==report['rss'])
  m.REPORT['artifacts'][m.CURRENT].update(owned_cleanup=cleanup,artifact_seal_sha256=sha(folder/'seal.json'),runtime_pure_verify_output_passed=True,resource_time_coverage=coverage,raw_budget_bytes=runtime.MAX_RAW_BYTES)
 m.REPORT['failed_checks']=[c for c in m.REPORT['checks'] if not c['passed']];m.REPORT['state']='complete_scoped_M5_original_mixed_matrix_verified' if not m.REPORT['failed_checks'] else 'partial_original_observations_audited_matrix_failed';m.REPORT['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();m.REPORT['ledger_unchanged']={'total':192,'completed':163,'remaining':29};m.REPORT['product_executables_invoked_by_reviewer']=0;m.REPORT['statistics_sources_pooled']=False
 (OUT/'execution-receipt-final-original.json').write_bytes(receipt_raw);m.save();print(json.dumps({'state':m.REPORT['state'],'checks':len(m.REPORT['checks']),'failed_checks':m.REPORT['failed_checks'],'cells':[{'cap':x['concurrency_cap'],'offered':x['operations'],'actual_call_peak':x['independent_call_occupancy']['peak'],'actual_executor_peak':x['observed_executor_peak'],'overlap':x['independent_call_occupancy']['read_build_overlap'],'sqlite_tables':len(x['independent_sqlite_comparison']['tables'])} for x in m.REPORT['artifacts'].values()]},indent=2))
 if m.REPORT['failed_checks']:raise SystemExit(1)
if __name__=='__main__':
 try:main()
 except Exception as exc:
  m.REPORT['state']='review_harness_incomplete';m.REPORT['error']=type(exc).__name__+': '+str(exc);m.save();traceback.print_exc();raise SystemExit(2)
