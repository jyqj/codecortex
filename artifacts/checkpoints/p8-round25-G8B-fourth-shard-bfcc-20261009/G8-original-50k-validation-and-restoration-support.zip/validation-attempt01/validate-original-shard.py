from pathlib import Path
import sys,json,hashlib,datetime,collections
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
BASE=D.parent
ROOT=BASE/'source-exact-G8-attempt02'
BUILD=BASE/'build'
sys.path.insert(0,str(ROOT/'scripts'))
import p8_scale_matrix as m
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,j):
    with p.open('x') as f:json.dump(j,f,indent=2);f.write('\n')
assert sha(ROOT/'scripts/p8_scale_matrix.py')=='f169b0f26cf2a87d3e2548d734431c530cbf63d353ac054045ec8be80889f957'
assert sha(ROOT/'scripts/p7_build_identity.py')=='5003305105464936edf8f444fc0b93cd14a5d5f074dc650f16de2259e86f1cc5'
build=m.read_json(BUILD/'build.json');binary=BUILD/'p8-scale'
assert sha(BUILD/'build.json')=='f5f9ac1478739ce658c007fa985ef897f60cefebad2ee471af32c7509ff8fa9e'
assert build['files']==m.inventory(BUILD,('build.json',))
assert sha(binary)==build['binary_sha256']=='39d43ac518d2dc4782e3c75a781c6e8a90982897af4ddd479c00b7505e38cb78'
assert m.driver_snapshot(ROOT)==build['driver_source']
dirs=[p.parent for p in (D/'intake-attempt01/extracted').rglob('shard.json')];assert len(dirs)==1;shard=dirs[0]
before=m.inventory(shard);build_before=m.inventory(BUILD);zip_before=sha(D/'original.zip')
result=m.validate_shard(shard,build,binary,sha(BUILD/'build.json'))
write(D/'original-validate-shard-output.json',result)
assert result['plan']['files']==[50000] and result['plan']['shard']=={'index':0,'count':30}
assert result['plan']['capacity_profile']=='scale_capacity_v1' and result['plan']['dirty_budget']==200
source=m.read_json(shard/'source-before.json');assert source==m.read_json(shard/'source-after.json')
R=BASE/'exact-canonical-R8.json'
assert source['inputs']==m.read_json(R)['complete_inputs'] and len(source['inputs'])==1095
assert source['source_commit']=='4fe927488d5cb7f26bd27c7624745fb1b6ca202b'
assert before==m.inventory(shard) and build_before==m.inventory(BUILD) and zip_before==sha(D/'original.zip')
report={'schema':'G8B-original-50k-shard-independent-acceptance-v1','observed_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'accepted_original_shard','source_G':source['source_commit'],'run_id':37962416564,'attempt':1,'artifact_id':11637747431,'scale':50000,'repetition':0,'original_validate_shard_unmodified':True,'original_inspect_raw_called_by_validate_shard':True,'original_native_hash_file_executed':True,'new_measurement_executed':False,'all1095_source_inputs_equal_R8':True,'source_before_after_equal':True,'original_build_shard_ZIP_bytes_before_after_equal':True,'accepted_shards_this_report':1,'accepted_samples_this_report':len(result['measurements']),'measurements':result['measurements'],'ZIP_sha256':zip_before,'binary_sha256':sha(binary),'remaining_TODO':29,'new_TODO_completed':0}
write(D/'independent-shard-review.json',report)
print(json.dumps({'status':report['status'],'accepted_shards':1,'accepted_samples':report['accepted_samples_this_report'],'original_validate_shard':0,'source':source['source_commit'],'source_inputs':1095,'no_measurement':True}))
