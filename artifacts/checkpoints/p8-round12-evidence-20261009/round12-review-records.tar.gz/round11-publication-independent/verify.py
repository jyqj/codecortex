from pathlib import Path, PurePosixPath
import datetime, hashlib, io, json, re, subprocess, sys, tarfile, urllib.parse, zipfile

ROOT = Path('/workspace/scratch/2eaa00d0f93a/p8-round11-evidence-publication-root')
OUT = Path(__file__).parent
COMMIT = 'b2aede645d76cf44f58d70de1df94de00c32031b'
BASE = '64230c8a628813d4f4f7c733e9779f17e85606b8'

def sha(body):
    return hashlib.sha256(body).hexdigest()

def identity(body):
    return {'bytes': len(body), 'sha256': sha(body)}

def no_private_urls(body):
    text = body.decode('utf-8', errors='ignore')
    for value in re.findall(r'https?://[^\s<>"\x27]+', text):
        query = urllib.parse.urlsplit(value).query
        keys = {key.lower() for key in urllib.parse.parse_qs(query)}
        assert not keys.intersection({'sig', 'x-amz-signature', 'x-amz-credential', 'x-goog-signature', 'se'}), 'signed URL found'

publication = json.loads((OUT / 'public-api-observations.json').read_bytes())
assert publication['commit']['sha'] == COMMIT
assert [row['sha'] for row in publication['commit']['parents']] == [BASE]
assert publication['ref']['object']['sha'] == COMMIT
assert publication['commit']['tree']['sha'] == publication['new_root']['sha']
assert publication['compare']['base'] == BASE
assert publication['compare']['total_commits'] == publication['compare']['ahead_by'] == 1
assert publication['compare']['behind_by'] == 0

def entries(value):
    assert value['truncated'] is False
    return {row['path']: {k: row[k] for k in ['mode', 'type', 'sha']} for row in value['tree']}

old, new = entries(publication['base_root']), entries(publication['new_root'])
assert old.keys() == new.keys() and len(new) == 13
assert [path for path in old if old[path] != new[path]] == ['artifacts']
plan = json.loads((ROOT / 'upload-plan.json').read_bytes())
assert len(plan) == len(publication['compare']['files']) == 7
assert {row['path'] for row in plan} == {row['path'] for row in publication['compare']['files']}
remote = {row['path']: row for row in publication['compare']['files']}
deliverables = {}
for row in plan:
    path = Path(row['local'])
    assert path.parent == ROOT and path.is_file() and not path.is_symlink()
    body = path.read_bytes()
    assert identity(body) == {k: row[k] for k in ['bytes', 'sha256']}
    assert row['mode'] == '100644' and row['type'] == 'blob'
    blob = hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()
    assert blob == row['sha'] == remote[row['path']]['sha']
    assert remote[row['path']]['status'] == 'added'
    assert row['path'].startswith('artifacts/checkpoints/p8-round11-evidence-20261008/')
    deliverables[path.name] = identity(body) | {'git_blob': blob}

manifest = json.loads((ROOT / 'round11-manifest.json').read_bytes())
assert manifest['TODO_closed'] == 0 and manifest['TODO_remaining'] == 29
assert manifest['new_measurement'] is False and manifest['product_or_Cargo_execution'] is False
archive_bytes = (ROOT / manifest['archive']['path']).read_bytes()
assert identity(archive_bytes) == {k: manifest['archive'][k] for k in ['bytes', 'sha256']}
member_bytes = {}
originals = {}
nested_zips = []
with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as tar:
    rows = tar.getmembers()
    assert len(rows) == len({row.name for row in rows}) == 78 == manifest['archive']['members']
    assert set(row.name for row in rows) == set(manifest['member_identities'])
    for item in rows:
        path = PurePosixPath(item.name)
        assert item.isfile() and item.mode == 0o644 and not path.is_absolute() and '..' not in path.parts
        body = tar.extractfile(item).read()
        record = manifest['member_identities'][item.name]
        assert identity(body) == {k: record[k] for k in ['bytes', 'sha256']}
        source = Path(record['source_path'])
        assert source.is_file() and not source.is_symlink()
        assert source.read_bytes() == body
        originals[item.name] = source
        member_bytes[item.name] = body
        if item.name.endswith('.zip'):
            with zipfile.ZipFile(io.BytesIO(body)) as z:
                assert z.testzip() is None
                for zi in z.infolist():
                    no_private_urls(z.read(zi))
                nested_zips.append({'path': item.name, 'members': len(z.infolist()), 'CRC': 'passed'})
        else:
            no_private_urls(body)
assert sum(map(len, member_bytes.values())) == 3902656 == manifest['archive']['uncompressed_bytes']

zip_spec = manifest['original_peer_zip']
parts, offset = [], 0
for row in zip_spec['parts']:
    body = (ROOT / row['path']).read_bytes()
    assert row['offset'] == offset
    assert identity(body) == {k: row[k] for k in ['bytes', 'sha256']}
    parts.append(body)
    offset += len(body)
original_zip = b''.join(parts)
assert offset == len(original_zip) == 5204573 == zip_spec['bytes']
assert sha(original_zip) == zip_spec['sha256'] == 'ebcd2b6f8961c44298862be6a5c03fa364f9e7a7a1cdb887258c1b172ee1470e'
allowlist = json.loads(member_bytes['peer6e3-100k-failed/public-archive-allowlist.json'])
original_row = next(row for row in allowlist['files'] if row['archive_path'].endswith('.zip'))
assert Path(original_row['source_path']).read_bytes() == original_zip
zip_members = json.loads(member_bytes['peer6e3-100k-failed/member-hashes.json'])
with zipfile.ZipFile(io.BytesIO(original_zip)) as z:
    assert len(z.infolist()) == len(set(z.namelist())) == zip_spec['member_count'] == 12
    assert set(z.namelist()) == set(zip_members)
    assert z.testzip() is None
    assert sum(row.file_size for row in z.infolist()) == zip_spec['member_uncompressed_bytes'] == 20425548
    for row in z.infolist():
        body = z.read(row)
        assert identity(body) == {key: zip_members[row.filename][key] for key in ['bytes', 'sha256']}
        assert format(row.CRC, '08x') == zip_members[row.filename]['crc32']
        no_private_urls(body)

restored = OUT / 'restored-peer.original.zip'
command = [sys.executable, str(ROOT / 'restore_peer_zip.py'), '--output', str(restored)]
result = subprocess.run(command, capture_output=True, timeout=30)
(OUT / 'restore.stdout').write_bytes(result.stdout)
(OUT / 'restore.stderr').write_bytes(result.stderr)
assert result.returncode == 0 and restored.read_bytes() == original_zip
second = subprocess.run(command, capture_output=True, timeout=30)
(OUT / 'restore-existing.stdout').write_bytes(second.stdout)
(OUT / 'restore-existing.stderr').write_bytes(second.stderr)
assert second.returncode != 0 and restored.read_bytes() == original_zip
for name, source in originals.items():
    assert source.read_bytes() == member_bytes[name]

readme = (ROOT / 'README.md').read_text()
assert 'completed in this round: **0**' in readme and 'Remaining original TODOs: **29**' in readme
assert 'deadline_exceeded' in readme and 'exit 3' in readme and '143' in readme
assert 'not accepted scale evidence' in readme and 'not acceptable as complete' in readme
for row in plan:
    if Path(row['local']).suffix in {'.json', '.py', '.md'}:
        no_private_urls(Path(row['local']).read_bytes())

report = {
    'schema': 'p8-round11-archive-independent-review-v1',
    'reviewed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer': 'pr_audit; non-author of checkpoint packaging',
    'status': 'accepted_scoped_archive_integrity_and_failure_preservation',
    'commit': COMMIT, 'parent': BASE, 'tree': publication['new_root']['sha'],
    'scope': 'Exactly seven added artifact files; other twelve root entries unchanged. No task/product/observer/workflow change.',
    'deliverables': deliverables,
    'tar': manifest['archive'] | {'actual_all_78_SHA_and_original_bytes_match': True, 'originals_after_unchanged': True},
    'peer_zip': zip_spec | {'all_12_member_CRC_SHA_match': True, 'original_bytes_match': True},
    'nested_zip_controls': nested_zips,
    'restore': {'argv': command, 'exit_code': result.returncode, 'existing_output_exit_code': second.returncode, 'bytes_unchanged_after_refusal': True},
    'signed_private_URLs_found': 0,
    'failure_boundary': ['peer6e3 native deadline exit3 and missing stages remain failed', 'D0 post-start runner shutdown143/missing terminal raw remains incomplete', 'G4 actual merge historical-CI failure retained separately from G3 success', 'P7 dev engineering and old14read probe not renamed formal G4 release/soak'],
    'restoration_scope': 'Reviewed normal documented Python invocation with original fixed manifest; no claim that assert checks run under Python -O or that this is a generic untrusted-archive receiver.',
    'new_product_Cargo_or_benchmark_execution': False,
    'reviewer_tool_correction': 'Initial archive-only check compared a two-field byte/hash identity with a three-field original member identity including crc32; corrected to compare both byte/hash fields and CRC explicitly. No original changed or product executed.',
    'TODO_closed': 0, 'TODO_remaining': 29,
}
(OUT / 'audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'sha256': sha((OUT / 'audit.json').read_bytes()), 'members': len(member_bytes), 'peer_zip_bytes': len(original_zip), 'status': report['status']}))
