from pathlib import Path
import subprocess,hashlib,json,datetime,os
B=Path(__file__).resolve().parent;R=B/'source-exact-GW4';R.mkdir(exist_ok=True);base=B.parent;env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0','GIT_OPTIONAL_LOCKS':'0'};receipts=[]
def git(*args,input=None):
 p=subprocess.run(['git',*args],input=input,cwd=R,env=env,capture_output=True);receipts.append({'argv':['git',*args],'exit_code':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr':p.stderr.decode(errors='replace')});(B/'source-restore-command-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');assert p.returncode==0,receipts[-1];return p.stdout

def put(kind,data,expected=None):
 oid=hashlib.sha1(kind.encode()+b' '+str(len(data)).encode()+b'\0'+data).hexdigest()
 if expected:assert oid==expected,(kind,oid,expected)
 assert git('hash-object','-w','-t',kind,'--stdin',input=data).decode().strip()==oid
 return oid

def tree_bytes(entries):
 rows=sorted(entries,key=lambda e:(e['path']+('/' if e['type']=='tree' else '')).encode());return b''.join((e['mode'].lstrip('0')+' '+e['path']).encode()+b'\0'+bytes.fromhex(e['sha']) for e in rows)

git('init');(R/'.git/objects/info/alternates').write_text(str(base/'round26-GCW3-original-v15/source/.git/objects')+'\n')
# Restore official tree metadata already read by prior independent source reviews.
for file in ['actual-path-trees.json','actual-path-trees-PCW3.json']:
 for oid,t in json.loads((base/'execution-recon-round25-dual-R'/file).read_text())['cache'].items():put('tree',tree_bytes(t['tree']),oid)
binding=base/'round25-GW4-binding';manifest=json.loads((binding/'generation-manifest.json').read_text());script_tree=json.loads((binding/'inputs/scripts.json').read_text());root_tree=json.loads((binding/'inputs/tree.json').read_text())
for e in manifest['files']:
 p=Path(e['local_path']);put('blob',p.read_bytes(),e['sha'])
 for row in script_tree['tree']:
  if row['path']==Path(e['path']).name:row['sha']=e['sha']
script_oid=put('tree',tree_bytes(script_tree['tree']),manifest['expected_scripts_tree'])
for row in root_tree['tree']:
 if row['path']=='scripts':row['sha']=script_oid
put('tree',tree_bytes(root_tree['tree']),manifest['expected_tree'])
# Exact original commit reconstructed from official unsigned Git API header; required SHA equality, no synthetic substitute.
c=json.loads((B/'official-GW4-commit.json').read_text())
def ident(x):return f"{x['name']} <{x['email']}> {int(datetime.datetime.fromisoformat(x['date'].replace('Z','+00:00')).timestamp())} +0000"
raw=('tree '+c['tree']['sha']+'\n'+''.join('parent '+p['sha']+'\n' for p in c['parents'])+'author '+ident(c['author'])+'\ncommitter '+ident(c['committer'])+'\n\n'+c['message']).encode()
# Official Git API normalizes timestamps to UTC and omits original timezone strings.
# Reconstruct only missing timezone spellings; accept exclusively the exact official GitOID.
offsets=[f"{'-' if minutes<0 else '+'}{abs(minutes)//60:02}{abs(minutes)%60:02}" for minutes in range(-12*60,14*60+1,15)]
matched=[]
for atz in offsets:
 for ctz in offsets:
  for lf in ['', '\n']:
   candidate=('tree '+c['tree']['sha']+'\n'+''.join('parent '+p['sha']+'\n' for p in c['parents'])+'author '+ident(c['author']).rsplit(' ',1)[0]+' '+atz+'\ncommitter '+ident(c['committer']).rsplit(' ',1)[0]+' '+ctz+'\n\n'+c['message']+lf).encode()
   if hashlib.sha1(b'commit '+str(len(candidate)).encode()+b'\0'+candidate).hexdigest()==c['sha']:matched.append((candidate,atz,ctz,bool(lf)))
assert len(matched)==1, len(matched)
raw,atz,ctz,lf=matched[0]
(B/'exact-commit-timezone-reconstruction.json').write_text(json.dumps({'actual_sha':c['sha'],'author_timezone':atz,'committer_timezone':ctz,'trailing_lf':lf,'matched_official_git_sha':True,'first_attempt_assumed_UTC_header_failed':True},indent=2)+'\n')
put('commit',raw,c['sha']);(B/'actual-GW4-commit.raw').write_bytes(raw)
git('update-ref','HEAD',c['sha'])
can=json.loads((binding/'inputs/canonical.json').read_text());inventory=can['actual_input_mode_blob_inventory'];paths=sorted(can['complete_inputs'])+['scripts/p8_scale_matrix.py','scripts/p7_build_identity.py']
# Exact scoped index; unrelated repository bodies are intentionally absent.
missing=[]
for path in paths:
 row=inventory[path];p=subprocess.run(['git','cat-file','-e',row['sha']],cwd=R,env=env,capture_output=True)
 if p.returncode:missing.append({'path':path,**row})
(B/'missing-scoped-blobs.json').write_text(json.dumps(missing,indent=2)+'\n')
print(json.dumps({'missing_blobs':len(missing),'paths':len(paths),'commit':c['sha'],'tree':c['tree']['sha']}))
(B/'scoped-restoration-plan.json').write_text(json.dumps({'paths':paths,'inventory':{p:inventory[p] for p in paths},'source':c['sha'],'tree':c['tree']['sha'],'canonical_sha256':hashlib.sha256((binding/'inputs/canonical.json').read_bytes()).hexdigest()},indent=2)+'\n')
