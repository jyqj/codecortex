use cc_eval::benchmark::oracle;
use rusqlite::{params, Connection};
use std::path::Path;

fn fixture(root: &Path) {
    std::fs::create_dir_all(root.join(".codecortex")).unwrap();
    let db = Connection::open(root.join(".codecortex/index.sqlite3")).unwrap();
    for table in oracle::tables() {
        db.execute_batch(&format!("CREATE TABLE \"{table}\"(name TEXT, value)")).unwrap();
    }
    for i in 0..100 {
        db.execute("INSERT INTO symbols VALUES (?1, ?2)", params![i.to_string(), "x".repeat(1000)]).unwrap();
    }
}

fn main() {
    let a = tempfile::tempdir().unwrap();
    let b = tempfile::tempdir().unwrap();
    fixture(a.path());
    fixture(b.path());
    let base = oracle::StreamingLimits::default();
    for (name, limits) in [
        ("rows", oracle::StreamingLimits { max_rows_per_table: 99, ..base }),
        ("canonical", oracle::StreamingLimits { max_canonical_bytes: 100, ..base }),
        ("row_bytes", oracle::StreamingLimits { max_row_bytes: 100, ..base }),
        ("disk", oracle::StreamingLimits { max_scratch_bytes: 64 * 1024, ..base }),
    ] {
        let error = oracle::compare_streaming(a.path(), b.path(), limits).unwrap_err();
        println!("{name}: {error}");
    }
    let limits = oracle::StreamingLimits { max_scratch_bytes: 2 * 1024 * 1024, ..base };
    let report = oracle::compare_streaming(a.path(), b.path(), limits).unwrap();
    println!("bounded_equal={} scratch_peak_bytes={} limit_bytes={} canonical_bytes={}", report["equal"], report["scratch_peak_bytes"], limits.max_scratch_bytes, report["canonical_bytes"]);
    assert!(report["scratch_peak_bytes"].as_u64().unwrap() <= limits.max_scratch_bytes);

    let scratch_dir = tempfile::tempdir().unwrap();
    let db = Connection::open(scratch_dir.path().join("control.sqlite3")).unwrap();
    db.execute_batch("PRAGMA page_size=4096; PRAGMA journal_mode=OFF; PRAGMA synchronous=OFF; PRAGMA temp_store=FILE; PRAGMA cache_size=-2048; PRAGMA mmap_size=0; PRAGMA max_page_count=16; CREATE TABLE canonical_rows(side INTEGER NOT NULL, value TEXT NOT NULL); CREATE INDEX canonical_order ON canonical_rows(side, value COLLATE BINARY);").unwrap();
    let mut statement = db.prepare("EXPLAIN QUERY PLAN SELECT value FROM canonical_rows INDEXED BY canonical_order WHERE side=?1 ORDER BY value COLLATE BINARY").unwrap();
    let plan = statement.query_map([0], |r| r.get::<_, String>(3)).unwrap().collect::<Result<Vec<_>,_>>().unwrap();
    println!("actual_bundled_sqlite_plan={plan:?}");
    assert!(plan.iter().all(|p| !p.contains("TEMP B-TREE")));
    assert!(plan.iter().any(|p| p.contains("COVERING INDEX canonical_order")));
    for pragma in ["page_size", "max_page_count", "cache_size", "mmap_size", "journal_mode", "temp_store"] {
        let value: rusqlite::types::Value = db.query_row(&format!("PRAGMA {pragma}"), [], |r| r.get(0)).unwrap();
        println!("{pragma}={value:?}");
    }
}
