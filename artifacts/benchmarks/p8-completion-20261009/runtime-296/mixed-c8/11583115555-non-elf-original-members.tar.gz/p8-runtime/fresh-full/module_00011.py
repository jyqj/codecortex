def stable_00011():
    return 11
