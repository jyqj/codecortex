import pathlib,subprocess,json,hashlib,datetime,time,os
D=pathlib.Path(__file__).resolve().parent;R=D.parent
argv=['python3','-B',str(D/'invoke-original-aggregate-once.py')]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
p=subprocess.run(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
receipt={'argv':argv,'cwd':str(R),'started_at_utc':started,'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_seconds':time.monotonic()-clock,'exit_code':p.returncode,'child_invocations':1,'retries':0,'kind':'Local complete-input original aggregate recovery; distinct from original Actions 42-input failure.','custody_faults':[]}
for channel in ['stdout','stderr']:
    b=getattr(p,channel);receipt[channel]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
    for name in ['original-aggregate.'+channel,'captured-'+channel+'.frozen-original']:
        try:
            with (D/name).open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
            observed=(D/name).read_bytes()
            if observed!=b:receipt['custody_faults'].append({'path':name,'error':'byte mismatch'})
        except OSError as e:receipt['custody_faults'].append({'path':name,'error':repr(e)})
ret=D/'original-aggregate-return.json'
receipt['return_equals_actual_stdout']=ret.is_file() and ret.read_bytes()==p.stdout
with (D/'original-recovery-execution.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(receipt,indent=2))
raise SystemExit(p.returncode)
