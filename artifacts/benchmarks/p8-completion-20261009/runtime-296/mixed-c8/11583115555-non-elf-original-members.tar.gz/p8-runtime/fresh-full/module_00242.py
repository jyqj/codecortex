def stable_00242():
    return 242
