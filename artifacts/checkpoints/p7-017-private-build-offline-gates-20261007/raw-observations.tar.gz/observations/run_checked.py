#!/usr/bin/env python3
"""Record one actual command against the fixed P7-017 builder/source checkout."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/71bc431c4e4f/codecortex-p7-tooling')
SOURCE = 'a213a4cfab0e0e87198bc279acacda51e4ff62cf'
OUT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
from p7_build_identity import file_sha256, json_bytes, source_snapshot


def main():
    if len(sys.argv) < 3:
        raise SystemExit('new result name and actual command required')
    name, command = sys.argv[1], sys.argv[2:]
    if not name.replace('-', '').replace('_', '').isalnum():
        raise SystemExit('result name must be a simple slug')
    result_path = OUT / (name + '.json')
    log_path = OUT / (name + '.log')
    if result_path.exists() or log_path.exists():
        raise SystemExit('result/log already exists; choose a new name')
    before = source_snapshot(ROOT)
    if before['source_commit'] != SOURCE or before['input_count'] != 768:
        raise SystemExit('fixed P7-017 source changed; command was not run')
    manifest_path = OUT / (name + '-source-inputs.json')
    manifest_path.write_bytes(json_bytes(before['inputs']))
    environment = dict(os.environ, RUSTUP_TOOLCHAIN='1.95.0', CARGO_BUILD_JOBS='2',
                       CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
                       CARGO_INCREMENTAL='0', PYTHONDONTWRITEBYTECODE='1')
    executor_before = file_sha256(__file__)
    original_test = ROOT / 'crates/cc-eval/tests/benchmark_adapters.rs'
    original_test_before = file_sha256(original_test)
    product = environment.get('CODECORTEX_BENCH_BINARY')
    runner = environment.get('P7_017_TEST_RUNNER')
    product_before = file_sha256(product) if product else None
    runner_before = file_sha256(runner) if runner else None
    start = time.monotonic()
    with log_path.open('xb') as log:
        result = subprocess.run(command, cwd=ROOT, env=environment,
                                stdin=subprocess.DEVNULL, stdout=log,
                                stderr=subprocess.STDOUT, close_fds=True)
    after = source_snapshot(ROOT)
    record = {
        'command': command, 'cwd': str(ROOT),
        'source_before': {k: v for k, v in before.items() if k != 'inputs'},
        'source_after': {k: v for k, v in after.items() if k != 'inputs'},
        'source_unchanged': before == after,
        'source_manifest': manifest_path.name,
        'source_manifest_sha256': file_sha256(manifest_path),
        'original_test_sha256_before': original_test_before,
        'original_test_sha256_after': file_sha256(original_test),
        'executor_script_sha256': executor_before,
        'executor_script_unchanged': executor_before == file_sha256(__file__),
        'product_binary_sha256_before': product_before,
        'product_binary_sha256_after': file_sha256(product) if product else None,
        'test_runner_sha256_before': runner_before,
        'test_runner_sha256_after': file_sha256(runner) if runner else None,
        'environment': {key: environment.get(key) for key in (
            'RUSTUP_TOOLCHAIN', 'RUSTUP_HOME', 'CARGO_HOME', 'CARGO_BUILD_JOBS',
            'CARGO_TARGET_DIR', 'CARGO_BUILD_BUILD_DIR', 'CARGO_PROFILE_DEV_DEBUG',
            'CARGO_PROFILE_TEST_DEBUG', 'CARGO_INCREMENTAL', 'RUSTC', 'RUSTC_WRAPPER',
            'RUSTC_WORKSPACE_WRAPPER', 'RUSTFLAGS', 'SDKROOT',
            'CODECORTEX_BENCH_BINARY', 'CODECORTEX_BENCH_OBSERVATIONS',
            'P7_017_PACKAGE_KIND', 'P7_017_BUILD_RECEIPT', 'P7_017_TEST_RUNNER',
            'P7_017_NETWORK_POLICY')},
        'exit_code': result.returncode,
        'elapsed_seconds': round(time.monotonic() - start, 3),
        'log': log_path.name, 'log_sha256': file_sha256(log_path),
        'scope': 'Actual command and fixed local source identity; no result is inferred for other source commits.',
    }
    result_path.write_bytes(json_bytes(record))
    print(json.dumps(record, indent=2), flush=True)
    print(log_path.read_text(errors='replace')[-6000:], flush=True)
    if before != after or not record['executor_script_unchanged']:
        raise SystemExit('inputs changed during execution')
    raise SystemExit(result.returncode)


if __name__ == '__main__':
    main()
