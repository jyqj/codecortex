import datetime,hashlib,json,re
from pathlib import Path
OUT=Path(__file__).resolve().parent
BASE=OUT.parents[1]
PLAN=Path('/dev/shm/todo-audit-pr180-merge-plan')
def read(p):return json.loads(p.read_text())
def identity(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
audit=read(OUT/'actual-P-complete-source-audit.json')
old_review=Path('/workspace/scratch/bfccb8494ba0/pr180181-readonly/review180.json')
old=read(old_review)
main=read(PLAN/'55aa-review-response.json')
main_raw=main['content'].encode();main=json.loads(main_raw)
seven=read(PLAN/'55aa-full-union-audit.json')['latest_main_additional_product_inputs']
v1=Path('/dev/shm/execution-recon-bfcc/pr180-dependency-fix-peer/independent-source-review.json')
v2=Path('/dev/shm/execution-recon-bfcc/pr180-dependency-fix-v2-peer/independent-source-review.json')
native_old=OUT.parent/'pr180-native-peer/independent-execution-review.json'
prior_overall=Path('/dev/shm/execution-recon-bfcc/pr180181/independent-pr180-pr181-review.json')
gaps=OUT.parent/'target-ten-closeout-db-wait-correction/map-correction.json'
specific={
 'crates/cc-db/src/index_db_write_batch.rs':'Dependency batching is a separate explicit boolean from snapshot leaf batching and deferred FTS. Ordinary and old public snapshot callers select false; rebuild-only deferred and noncanonical/autocommit FTS fallback select true. The original per-row dependency path and its first failed statement prefix are preserved for the old API. Existing 64/8/1 and64KiB leaf limits, row order, OR IGNORE behavior, schema/rowid/TEMP fallback and FTS guard remain unchanged. No implicit savepoint, ignored error or altered production budget is added.',
 'crates/cc-db/src/snapshot_write_txn.rs':'The old public write_file_data signature, original408-byte loop and caller catch/commit semantics remain byte-identical. Only explicit write_file_data_for_rebuild admits dependency batches, independently of whether FTS may defer. The FTS fallback uses the dedicated crate-private rebuild helper so custom-trigger cases still exercise batching. New API documents that owners must abandon staging on Err and prevent publication; Rust types do not force rollback and journal-OFF physical rollback is not claimed.',
 'crates/cc-db/tests/p2b_resolution_store.rs':'The two existing bulk/owner controls explicitly call the rebuild-only API without changing the original73-row,key70 trigger or boundary cases. The independent public regression compares old IndexDb insert with public SnapshotWriteTxn on separate raw Connections, catches the second-file error and commits, then reopens and compares exactly keys0..69 and all three relevant tables. It does not share rebuild-owner error recovery. The sole v1-to-v2 change is rustfmt whitespace. Actual old3ff RED64vs70 and corrected v1/v2 GREEN/control results remain historical; the exact newP controls are separately identified below.'
}
path_reviews={}
for p,d in audit['paths'].items():
    item=audit['actual_input_mode_blob_inventory'][p]
    if p in specific:
        scope='direct non-author semantic review of the frozen v2 fix, re-bound to actualP'
        semantic=specific[p];refs=[identity(v1),identity(v2)]
    elif p in seven:
        scope='actual main55aa blob preserved; direct source inspection plus exact published non-author review inheritance'
        semantic=main['source_path_reviewers'][p]['semantic_review']
        refs=[{'repository_path':'artifacts/checkpoints/p8-install-compat-36fea-20261009/published-independent-source-review.json','git_blob':'ec0dc0747ac1c036e249bbf1f22ff472c42aba64','bytes':len(main_raw),'sha256':hashlib.sha256(main_raw).hexdigest(),'inherited_reviewer':main['source_path_reviewers'][p].get('reviewer')}]
    else:
        assert d==old['paths'][p]
        scope='exact retained previously reviewed product path; no new implementation bytes at this path'
        semantic='ActualP path/mode/blob/size/SHA equal the independently verified3ff source map and its fixed canonical BASE delta. Original per-path reviews and their limitations remain applicable. This is source semantic inheritance, not transfer of old CI, timing or sample results. The public dependency side-effect defect identified in that composition is resolved only by the three separately reviewed current paths.'
        refs=[identity(old_review),identity(prior_overall)]
    path_reviews[p]={'reviewer':'/root/execution_recon','review_kind':scope,'before_sha256':d['before_sha256'],'sha256':d['sha256'],'mode':item['mode'],'git_blob':item['sha'],'semantic_review':semantic,'review_references':refs}

raw=Path('/workspace/scratch/bfccb8494ba0/root-round14/native-P-transfer/extracted')
progress=read(raw/'controls-progress.json')
exec_review=[]
for command in progress:
    assert command['source_P']==audit['source'] and command['tree']==audit['tree'] and command['exit_code']==0
    for role in ['before','after','stdout','stderr']:
        m=command[role];f=raw/m['path'];b=f.read_bytes()
        assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256']
    before=read(raw/command['before']['path']);after=read(raw/command['after']['path'])
    assert before['source_P']==after['source_P']==audit['source']
    assert before['entries']==after['entries'] and len(before['entries'])==1245
    entries={x['path']:x for x in before['entries']}
    for p,e in audit['actual_input_mode_blob_inventory'].items():
        x=entries[p]
        assert x['mode']==e['mode'] and x['git_blob']==e['sha'] and x['bytes']==e['size'] and x['sha256']==e['sha256']
    stdout=(raw/command['stdout']['path']).read_text()
    counts=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout)]
    exec_review.append({'label':command['label'],'command':command['command'],'actual_exit':0,'started_at':command['started_at'],'ended_at':command['ended_at'],'input_count':1245,'protected1093plus139_equal_actualP':True,'all1245_before_after_rows_equal':True,'actual_test_summaries_passed_failed_ignored':counts,'original_receipt':identity(raw/(command['label']+'-receipt.json')),'stdout':identity(raw/command['stdout']['path']),'stderr':identity(raw/command['stderr']['path'])})
assert len(exec_review)==6 and sum(sum(s[0] for s in x['actual_test_summaries_passed_failed_ignored']) for x in exec_review)==29
extra=sorted(set(entries)-set(audit['actual_input_mode_blob_inventory']))
assert len(extra)==13
result={'schema_version':1,'scope':'independently_reviewed_source_and_validation_inputs','verdict':'accepted_scoped','source':audit['source'],'source_tree':audit['tree'],'tree':audit['tree'],'source_parent':audit['parents'][0],'source_parents':audit['parents'],'base':audit['base'],'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'independent_reviewers':['/root/execution_recon'],'author_independence':{'fix_author':'/root/todo_audit','source_reviewer':'/root/execution_recon','root_role':'authorizes integration and performs actual native commands','reviewer_authored_current_three_product_changes':False,'mechanical_map_donor':'/root/todo_audit provided a non-verdict map; reviewer independently reconstructed official actualP trees, raw commit and exact protected domains.'},'unresolved_blockers':[],'unresolved_blocker_scope':'No unresolved source-level blocker in this exact implementation/validation domain; task, runtime, study and release acceptance remain separate below.','paths':audit['paths'],'complete_inputs':audit['complete_inputs'],'validation_inputs':audit['validation_inputs'],'complete_input_count':1093,'validation_input_count':139,'changed_source_input_count':59,'source_modes':{p:audit['actual_input_mode_blob_inventory'][p]['mode'] for p in audit['complete_inputs']},'validation_modes':{p:audit['actual_input_mode_blob_inventory'][p]['mode'] for p in audit['validation_inputs']},'actual_input_mode_blob_inventory':audit['actual_input_mode_blob_inventory'],'source_path_reviewers':path_reviews,'validation_path_reviewers':{p:{'reviewer':'/root/execution_recon','sha256':sha,'mode':audit['actual_input_mode_blob_inventory'][p]['mode'],'git_blob':audit['actual_input_mode_blob_inventory'][p]['sha'],'scope':'Exact previously independently reviewed3ff validation bytes; actualP complete path inventory and mode/blob equality checked. Two PR175 observer/statistics files freshly rehashed; other137 immutable source identities retained. No original workload, failure gate, timeout, budget or collector relaxed.'} for p,sha in audit['validation_inputs'].items()},'review_basis':{'source_audit':identity(OUT/'actual-P-complete-source-audit.json'),'method':'Official actualP raw Git commit SHA reconstructed including actual timezone and message bytes; all229 retrieved protected/root trees independently hashed. Complete1093 product and139 validation path/mode/type/blob/size checked.1083 product hashes reused only on exact previously verified3ff immutable identity,7 latest-main blobs and3 frozenv2 raw files independently rehashed; validation137 sameGc8 plus2 actual3ff originals rehashed.59 BASE rows independently reconstructed from prior proven inherited source hashes; each row has exactly before_sha256 and sha256.','full_worktree_materialization_claim':False,'actualP_original_CI':'Original .github/workflows/ci.yml blob8c7325eb88b791f909e72c4b6c79b417185e4386 retained. Selected oldguard/registry are temporary P bindings and require newR/G.','latest_main_preservation':'The7 newmain55aa product blobs are exact. Official root subtrees bind retained docs/README/evidence composition. This reviewer did not inspect holdout/gold contents or pretend all artifact bodies were locally materialized.','prior_reviews':[identity(prior_overall),identity(v1),identity(v2),identity(native_old)],'representation_helper_failures':'Initial helper assumed+0000/trailing newline; actual rawcommit is+0800/no trailing newline and matchesP SHA. A subsequent helper used list-shaped access on prior validation hash dictionary and stopped. Both were reviewer preparation errors, not product executions; final complete source audit exited0.'},'current_execution_support':{'scope':'Read-only thin review of six retained native receipts and all per-command stdio/input hashes; full transport/controller execution peer is separately owned by pr_triage. No Rust rerun by this reviewer.','commands':exec_review,'actual_unique_targeted_tests':29,'source_domain':{'product':1093,'validation':139,'additional_pinned_execution_inputs':13,'total':1245,'additional_paths':extra},'platform':'Mac aarch64, Rust1.95.0, SDKROOT/Library/Developer/CommandLineTools/SDKs/MacOSX15.4.sdk, own APFS-cloned ordinary cached target','limits':['Strict Clippy is cc-db --all-targets, not workspace Clippy.','Four targeted test binaries contain7+14+6+2 tests, all0 failed/0ignored; this is not a full workspace test run.','Formatting uses workspace fmt; no cold-build or performance claim.','Historical3ff RED/GREEN27 controls, Gc8 full engineering and scale samples remain at their original source identities.']},'acceptance_boundary':{'TODO_done':163,'TODO_remaining':29,'TODO_closed':0,'original_scale':{'source_G':'c8be5afaac568ffd40ef86d3795423c3b73c9f39','run_id':37902429727,'run_attempt':1,'accepted_shards':4,'registered_shards':150,'accepted_samples':41,'registered_samples':1500,'credit_to_this_P':False},'P8_007_original_gap':{'status':'pending original actual mixed C1/4/8/16 DB acquisition-wait observation','correction':identity(gaps),'limits':'Existing mixed/backfill component checks passed; client dispatch wait, lock_poison boolean and isolated availability probes do not satisfy actual-load DB lock acquisition wait. No new numeric threshold or fullscale admission gate introduced.'},'runtime_quality_release_claims':'Require separate source-specific evidence and original hard dependencies; no TODO, release, stable-tail, causal-speedup, provider or holdout certification.','new_source_study':'No new workflow dispatch/rerun or measurement authorized or performed by this review.'}}
assert len(result['paths'])==59 and all(set(v)=={'before_sha256','sha256'} for v in result['paths'].values())
assert result['scope']=='independently_reviewed_source_and_validation_inputs' and result['verdict']=='accepted_scoped'
with (OUT/'independent-source-review.json').open('x') as f:json.dump(result,f,ensure_ascii=False,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({'report':identity(OUT/'independent-source-review.json'),'product':1093,'validation':139,'delta':59,'targeted_tests':29,'scope':result['scope'],'verdict':result['verdict']}))
