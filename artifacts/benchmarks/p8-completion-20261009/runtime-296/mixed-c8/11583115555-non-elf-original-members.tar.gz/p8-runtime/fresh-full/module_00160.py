def stable_00160():
    return 160
