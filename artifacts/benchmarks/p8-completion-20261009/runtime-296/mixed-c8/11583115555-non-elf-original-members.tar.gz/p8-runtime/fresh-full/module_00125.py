def stable_00125():
    return 125
