def stable_00261():
    return 261
