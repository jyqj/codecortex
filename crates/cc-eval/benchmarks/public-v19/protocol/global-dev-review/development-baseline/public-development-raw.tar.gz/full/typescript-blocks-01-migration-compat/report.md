# CodeCortex benchmark baseline

Suite: `V19 TypeScript 01-migration oce-compat-v1 candidate; review/custody pending`
Adapter: `mcp-stdio`
Scoring: `OceCompat`
Measurement profile: `quality`

Status: **gate_failed** (exit 1)

Queries: 12; measured rows: 36.
Mean Top-1: 0.916667; mean nDCG@10: 0.830186.

These are baseline observations, not a release quality certificate.
Latency: Distribution { samples: 0, p50_us: None, p95_us: None, max_us: None, tail_claim: "insufficient_for_tail_claim" }; samples are retained, not best-of.
Source evidence: 0 invalid, 0 unverified hits.

| Case | Top-1 | nDCG@10 | Repetitions |
|---|---:|---:|---:|
| v19.typescript.f0001.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0002.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0003.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0004.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0006.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0008.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0009.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0011.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0012.en01 | 1.000000 | 0.722424 | 3 |
| v19.typescript.f0013.en01 | 1.000000 | 0.380094 | 3 |
| v19.typescript.f0015.en01 | 1.000000 | 0.859719 | 3 |
| v19.typescript.f0016.en01 | 0.000000 | 0.000000 | 3 |

## Failures

- v19.typescript.f0015.en01 Partial
- v19.typescript.f0013.en01 Partial
- v19.typescript.f0001.en01 Partial
- v19.typescript.f0012.en01 Partial
- v19.typescript.f0006.en01 Partial
- v19.typescript.f0003.en01 Partial
- v19.typescript.f0016.en01 Partial
- v19.typescript.f0008.en01 Partial
- v19.typescript.f0004.en01 Partial
- v19.typescript.f0011.en01 Partial
- v19.typescript.f0002.en01 Partial
- v19.typescript.f0009.en01 Partial
- v19.typescript.f0012.en01 Partial
- v19.typescript.f0006.en01 Partial
- v19.typescript.f0004.en01 Partial
- v19.typescript.f0013.en01 Partial
- v19.typescript.f0016.en01 Partial
- v19.typescript.f0015.en01 Partial
- v19.typescript.f0009.en01 Partial
- v19.typescript.f0011.en01 Partial
- v19.typescript.f0003.en01 Partial
- v19.typescript.f0001.en01 Partial
- v19.typescript.f0002.en01 Partial
- v19.typescript.f0008.en01 Partial
- v19.typescript.f0001.en01 Partial
- v19.typescript.f0009.en01 Partial
- v19.typescript.f0016.en01 Partial
- v19.typescript.f0012.en01 Partial
- v19.typescript.f0002.en01 Partial
- v19.typescript.f0011.en01 Partial
- v19.typescript.f0015.en01 Partial
- v19.typescript.f0003.en01 Partial
- v19.typescript.f0004.en01 Partial
- v19.typescript.f0008.en01 Partial
- v19.typescript.f0013.en01 Partial
- v19.typescript.f0006.en01 Partial