from pathlib import Path
import json,math,hashlib
root=Path(__file__).resolve().parent
scoped={'Which Harbor API changes the ready state with Seal?','Which method on Harbor changes the ready state with Seal?'}
summary={'status':'candidate_pending','queries_per_variant':16,'variants':['base','receiver','inversion'],'observations':[],'common_hits_checked':0,'changed_name_bonuses':0,'normalization_or_membership_differences':[],'non_name_differences':[],'unexpected_score_or_reason_differences':[]}
for variant in summary['variants']:
 b=json.loads((root/'results'/f'baseline-{variant}'/'results.json').read_text())
 c=json.loads((root/'results'/f'candidate-{variant}'/'results.json').read_text())
 assert b['source_text']==c['source_text']
 for query in b['queries']:
  for api in ['engine','mcp']:
   before=b['queries'][query][api];after=c['queries'][query][api]
   bh=before['raw']['machine_pack']['hits'];ch=after['raw']['machine_pack']['hits']
   bm={h['chunk_id']:h for h in bh};cm={h['chunk_id']:h for h in ch}
   bn={(h['path'],h['start_line'],h['end_line'],h['symbol_name'],h['kind']):h for h in before['normalized']}
   cn={(h['path'],h['start_line'],h['end_line'],h['symbol_name'],h['kind']):h for h in after['normalized']}
   if set(bm)!=set(cm):summary['normalization_or_membership_differences'].append({'variant':variant,'query':query,'api':api,'before_only':sorted(set(bm)-set(cm)),'after_only':sorted(set(cm)-set(bm))})
   for key in set(bn)&set(cn):
    assert bn[key]==cn[key],('normalized identity/source changed',variant,query,api,key)
   for arm,hits in [('before',bh),('after',ch)]:
    for h in hits:
     assert math.isclose(sum(v for _,v in h['score_trace']),h['rerank_score'],rel_tol=0,abs_tol=1e-9)
   for cid in set(bm)&set(cm):
    x,y=bm[cid],cm[cid];summary['common_hits_checked']+=1
    for field in ['symbol_name','symbol_kind','text','start_line','end_line','file_path','breadcrumb','fused_score','lexical_score','grep_score','graph_score']:
     assert x[field]==y[field],('identity/lane drift',variant,query,api,cid,field,x[field],y[field])
    nx=[t for t in x['score_trace'] if t[0]!='boost:symbol-exact'];ny=[t for t in y['score_trace'] if t[0]!='boost:symbol-exact']
    if nx!=ny:summary['non_name_differences'].append({'variant':variant,'query':query,'api':api,'chunk_id':cid,'before':nx,'after':ny})
    expected=query in scoped and x['symbol_name']=='Harbor' and x['symbol_kind']=='class' and 'exact-target' not in x['reasons']
    if expected:
     bx=[v for k,v in x['score_trace'] if k=='boost:symbol-exact'];cy=[v for k,v in y['score_trace'] if k=='boost:symbol-exact']
     assert bx==[.18] and cy==[],('expected owner bonus change',variant,query,api,cid,bx,cy)
     assert [r for r in x['reasons'] if r!='symbol-exact']==y['reasons']
     assert math.isclose(x['rerank_score']-.18,y['rerank_score'],rel_tol=0,abs_tol=1e-9)
     summary['changed_name_bonuses']+=1
    elif x['score_trace']!=y['score_trace'] or x['reasons']!=y['reasons'] or x['rerank_score']!=y['rerank_score']:
     summary['unexpected_score_or_reason_differences'].append({'variant':variant,'query':query,'api':api,'chunk_id':cid,'before':x,'after':y})
   obs={'variant':variant,'query':query,'api':api,'before_top_name':bh[0]['symbol_name'] if bh else None,'after_top_name':ch[0]['symbol_name'] if ch else None,'before_scores':before.get('scores'),'after_scores':after.get('scores'),'before_count':len(bh),'after_count':len(ch)}
   summary['observations'].append(obs)
   if query not in scoped:
    assert [h['chunk_id'] for h in bh]==[h['chunk_id'] for h in ch],('unmatched query ordering changed',variant,query,api)
    assert before.get('scores')==after.get('scores'),('unmatched scorer changed',variant,query,api)
# A previously declared reproduction target, not a blanket all-fixture Top1 claim.
for api in ['engine','mcp']:
 o=next(x for x in summary['observations'] if x['variant']=='receiver' and x['query']=='Which Harbor API changes the ready state with Seal?' and x['api']==api)
 assert o['before_scores']['top1']==0 and o['after_scores']['top1']==1
 assert o['before_scores']['mrr10']==.5 and o['after_scores']['mrr10']==1
summary['status']='passed' if not summary['non_name_differences'] and not summary['unexpected_score_or_reason_differences'] else 'failed'
summary['input_sha256']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('results/*/results.json')}
(root/'results/comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['observations','input_sha256']},indent=2))
assert summary['status']=='passed'
for o in summary['observations']:
 if o['query'] in scoped:
  print(o['variant'],o['api'],o['query'],o['before_scores']['top1'],'->',o['after_scores']['top1'])
