"""Seal completed original receipts; do not execute any source/product command."""
import hashlib,json,pathlib,stat,zipfile
from datetime import datetime,timezone
ROOT=pathlib.Path(__file__).resolve().parent
BASE=ROOT.parent
BIND=BASE/'round31-capture-diagnostic-binding-preparation'
RUN=ROOT/'actual-original-validation-attempt01'
OUT=ROOT/'sealed-original-admission-attempt01'
def meta(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),git_blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest())
def dump(p,j):
 with p.open('x')as f:json.dump(j,f,indent=2,sort_keys=True);f.write('\n')
def main():
 terminal=json.loads((RUN/'terminal.json').read_text());assert terminal['passed'] is True
 expected=json.loads((ROOT/'actual-G-pre-admission-inputs.json').read_text())
 binding=json.loads((BIND/'actual-G-binding.json').read_text())
 assert expected['source']==binding['source']
 records=terminal['records'];assert len(records)==2
 sources=[]
 for rec in records:
  assert type(rec['exit_code']) is int and rec['exit_code']==0 and rec['error'] is None and rec['inputs_unchanged']
  name=rec['name'];before=(RUN/(name+'-inputs-before.json')).read_bytes();after=(RUN/(name+'-inputs-after.json')).read_bytes()
  assert before==after
  snap=json.loads(before);assert snap['head']==binding['source'] and snap['index_tree']==binding['source_tree']
  assert snap['selected_count']==len(expected['selected_entries'])
  for ext in ['stdout','stderr']:assert meta((RUN/(name+'.'+ext)).read_bytes())==rec[ext]
  sources.append(dict(name=name,execution=rec,before_and_after=meta(before)))
 v15=json.loads((RUN/'original-v15.stdout').read_text());plan=json.loads((RUN/'original-task-plan.stdout').read_text())
 assert v15['status']=='passed' and v15['product_source']==binding['product'] and v15['review_source']==binding['review']
 assert v15['complete_inputs']==1096 and v15['executed_previous_proof']=='p8-oracle-compat-source-20261008-v14'
 assert plan['status']=='passed' and plan['task_count']==192 and plan['states']=={'done':164,'blocked':1,'in_progress':15,'todo':12}
 OUT.mkdir()
 report={'schema_version':1,'status':'actual_original_source_and_task_admission_passed','created_at':datetime.now(timezone.utc).isoformat(),
  'actual_binding':binding,'domain':expected['counts'],'selected_count':len(expected['selected_entries']),
  'original_executions':sources,'v15_stdout':v15,'task_plan_stdout':plan,
  'binding_generation_originals_git':'b9e4d58b95a7d657f9027e37c9055fed30f2a765',
  'independent_canonical_git':'1efd2b61d00a9619b70b6d951918076661af9e9d',
  'scope':'Actual original v15 and task-plan CLI on real fixed Git HEAD/index and exact 1444-input projection; includes six original task documents. Full worktree not claimed. No product/native/Rust/scale execution or future CI credit.',
  'timing_boundary':'Receipt started/completed timestamps bracket the original child; receipt wall_seconds also includes post-execution input snapshot. No performance interpretation.',
  'task_credit':0}
 dump(OUT/'actual-original-admission-review.json',report)
 paths=[]
 # No active process output or Git object cache is part of this selection.
 for p in ROOT.iterdir():
  if p.is_file() and p.name!='seal-original-admission.py':paths.append(p)
 for d in [ROOT/'actual-P3-metadata-preparation',RUN]:paths.extend(p for p in d.rglob('*')if p.is_file())
 for p in BIND.rglob('*'):
  if p.is_file() and p.name!='independent-source-review.json':paths.append(p)
 paths.append(pathlib.Path(__file__).resolve())
 selection=[]
 for p in sorted(set(paths)):
  assert not p.is_symlink()
  b=p.read_bytes();selection.append(dict(local_path=str(p),archive_path=p.relative_to(BASE).as_posix(),mode=stat.S_IMODE(p.stat().st_mode),**meta(b)))
 manifest={'schema_version':1,'scope':'Selected complete local original mechanical/input/CLI receipts; not a whole source checkout or performance artifact. Canonical retained separately at actual R.','files':selection}
 dump(OUT/'archive-selection.json',manifest)
 zpath=OUT/'original-source-and-task-admission.zip'
 with zipfile.ZipFile(zpath,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for e in selection:
   p=pathlib.Path(e['local_path']);b=p.read_bytes();assert meta(b)['sha256']==e['sha256']
   zi=zipfile.ZipInfo(e['archive_path']);zi.external_attr=(stat.S_IFREG|e['mode'])<<16;zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,b)
  z.writestr('archive-selection.json',(OUT/'archive-selection.json').read_bytes())
 with zipfile.ZipFile(zpath)as z:
  assert z.testzip() is None and len(z.infolist())==len(selection)+1
  for e in selection:
   b=z.read(e['archive_path']);assert meta(b)=={k:e[k]for k in ['bytes','sha256','git_blob']}
   assert stat.S_IMODE(z.getinfo(e['archive_path']).external_attr>>16)==e['mode']
 for e in selection:assert meta(pathlib.Path(e['local_path']).read_bytes())['sha256']==e['sha256']
 items=[]
 for n in ['actual-original-admission-review.json','original-source-and-task-admission.zip']:
  p=OUT/n;items.append(dict(local_path=str(p),repository_path='artifacts/checkpoints/p8-100k-diagnostic-capture-bfcc-20261009/'+n,**meta(p.read_bytes())))
 dump(OUT/'upload-manifest.json',items)
 print(json.dumps({'status':'sealed','files':len(selection),'items':items},sort_keys=True))
if __name__=='__main__':main()
