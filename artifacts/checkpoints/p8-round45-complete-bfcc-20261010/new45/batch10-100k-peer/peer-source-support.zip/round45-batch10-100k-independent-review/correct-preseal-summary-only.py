import hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent
src=p/'independent-batch10-100k-review.preseal-draft.json'
dst=p/'independent-batch10-100k-review.json'
original=src.read_bytes();r=json.loads(original)
assert r['cumulative']['cells']==40 and r['cumulative']['records']==75
assert r['remaining']=={'cells':6,'records':12,'population':'body/api/config/batch_100/batch_1000/batch_10000 at100k'}
r['remaining']={'cells':45-r['cumulative']['cells'],'records':85-r['cumulative']['records'],'population':'body/api/config/batch_100/batch_1000 at100k'}
r['reader_attempt_history']['preseal_summary_correction']={'original_draft_sha256':hashlib.sha256(original).hexdigest(),'reason':'Broad label adaptation altered the remaining-population label string and missed its old 6/12 counts. Independent evidence checks and cumulative 40/75 were correct. This correction changes derived summary metadata only; original reader, draft, receipt and source/raw are preserved.','new_raw_reads':0,'original_function_reexecutions':0}
with dst.open('x') as f:json.dump(r,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':'corrected_derived_remaining_summary_only','remaining':r['remaining'],'cumulative':r['cumulative']}))
