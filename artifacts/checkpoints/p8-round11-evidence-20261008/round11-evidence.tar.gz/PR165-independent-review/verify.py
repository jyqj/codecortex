#!/usr/bin/env python3
"""Read-only Git-object/mapping audit. No old archive bodies or product execution."""
import hashlib
import json
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
OLD = 'artifacts/checkpoints/localwidth4-100k-paired-20261003'
NEW = 'artifacts/checkpoints/pr-evidence-archive-163/relocated-originals/localwidth4-100k-paired-20261003'
BASE = '341db995e5f092fd95aed35af84cbc8b69e1af40'
HEAD = 'f88a41e6af46ffe67b76f420f1d6b4ef21155946'

def read(name):
    return json.loads((ROOT/name).read_bytes())

def object_hash(kind, body):
    return hashlib.sha1(kind.encode()+b' '+str(len(body)).encode()+b'\0'+body).hexdigest()

def tree_hash(entries):
    ordered = sorted(entries, key=lambda x: (x['path']+('/' if x['type']=='tree' else '')).encode())
    raw = b''.join((x['mode'].lstrip('0')+' '+x['path']).encode()+b'\0'+bytes.fromhex(x['sha']) for x in ordered)
    return object_hash('tree',raw)

def tree(name):
    item = read(name+'.json')
    assert item['truncated'] is False
    assert tree_hash(item['tree']) == item['sha'], name
    return {x['path']:x for x in item['tree']}

def canonical(entries):
    return {p:(x['mode'],x['type'],x['sha']) for p,x in entries.items()}

pull, commit = read('pull.json'), read('head-commit.json')
assert pull['number']==165 and pull['head']['sha']==HEAD and pull['base']['sha']==BASE
assert commit['sha']==HEAD and [p['sha'] for p in commit['parents']]==[BASE]
assert commit['tree']['sha']=='436e5b6d1df432f74fd8c5fab672ef90f9bc9612'
base, head = tree('base-root'),tree('head-root')
assert canonical({p:x for p,x in base.items() if p!='artifacts'}) == canonical({p:x for p,x in head.items() if p!='artifacts'})
ba,ha=tree('base-artifacts'),tree('head-artifacts')
assert base['artifacts']['sha']==read('base-artifacts.json')['sha'] and head['artifacts']['sha']==read('head-artifacts.json')['sha']
assert canonical({p:x for p,x in ba.items() if p!='checkpoints'})==canonical({p:x for p,x in ha.items() if p!='checkpoints'})
bc,hc=tree('base-checkpoints'),tree('head-checkpoints')
assert ba['checkpoints']['sha']==read('base-checkpoints.json')['sha'] and ha['checkpoints']['sha']==read('head-checkpoints.json')['sha']
assert len(bc)==len(hc)==188
assert canonical({p:x for p,x in bc.items() if p!=OLD.split('/')[-1]})==canonical({p:x for p,x in hc.items() if p!='pr-evidence-archive-163'})
assert OLD.split('/')[-1] not in hc
archive, relocated, reviews = tree('new-archive'),tree('relocated-root'),tree('new-reviews')
assert hc['pr-evidence-archive-163']['sha']==read('new-archive.json')['sha']
assert archive['relocated-originals']['sha']==read('relocated-root.json')['sha']
assert archive['reviews']['sha']==read('new-reviews.json')['sha']
assert len(relocated)==1 and canonical(relocated)==canonical({OLD.split('/')[-1]:bc[OLD.split('/')[-1]]})

original=read('original-subtree.json')
assert original['truncated'] is False and original['sha']=='347b848c78278c44622795e1a137987c2ca766aa'
entries={x['path']:x for x in original['tree']}
all_dirs={'':original['sha'],**{p:x['sha'] for p,x in entries.items() if x['type']=='tree'}}
for parent, expected in all_dirs.items():
    direct=[]
    for path,item in entries.items():
        if str(PurePosixPath(path).parent).replace('.','',1) == parent:
            direct.append(dict(item,path=PurePosixPath(path).name))
    assert tree_hash(direct)==expected, parent
files={p:x for p,x in entries.items() if x['type']=='blob'}
assert len(files)==188 and sum(x['size'] for x in files.values())==26428588

metadata={}
for name,entry in {**{p:x for p,x in archive.items() if x['type']=='blob'}, **reviews}.items():
    body=(ROOT/'metadata'/name).read_bytes()
    assert len(body)==entry['size'] and object_hash('blob',body)==entry['sha'], name
    metadata[name]={'bytes':len(body),'git_blob':entry['sha'],'sha256':hashlib.sha256(body).hexdigest()}
assert len(metadata)==5
mapping=read('metadata/proposed-relocation-mapping.json')
assert mapping['from']==OLD and mapping['to']==NEW and mapping['original_subtree']==original['sha']
assert mapping['original_mode']=='040000' and len(mapping['files'])==188
historical=read('history/original-PR163-manifest.json')
historical_rows={x['path']:x for x in historical['original_files'] if x['path'].startswith(OLD+'/')}
assert len(historical_rows)==188
for row in mapping['files']:
    assert row['relocated_path']==NEW+'/'+row['path'].removeprefix(OLD+'/')
    assert {k:v for k,v in row.items() if k!='relocated_path'}==historical_rows[row['path']]
    item=files[row['path'].removeprefix(OLD+'/')]
    assert (row['mode'],row['type'],row['git_blob'],row['bytes'])==(item['mode'],item['type'],item['sha'],item['size'])
assert object_hash('blob',(ROOT/'history/original-PR163-manifest.json').read_bytes())=='33935ca945720cdf6185efa05c2b8112960753a8'
provenance=read('metadata/relocation-provenance.json')
assert provenance['path_map_sha256']==metadata['proposed-relocation-mapping.json']['sha256']
assert provenance['original_content_changes']==provenance['product_changes']==provenance['validation_changes']==provenance['task_changes']==0

imports=read('history/fixed-e3-imported-identity.json')
assert len(imports['files'])==58 and all(not x['path'].startswith(OLD) and not x['path'].startswith(NEW) for x in imports['files'])
assert 'old paired diagnostic directory' in imports['exclusions']
guard=(ROOT/'history/historical-guard.py').read_text()
assert 'require(not os.path.lexists(Path(root) / FORBIDDEN), "excluded historical paired directory present")' in guard
assert '"evidence_content_acceptance": "not_granted_by_this_verifier"' in guard
assert hashlib.sha256(guard.encode()).hexdigest()=='bdf0713772d3514614b4916854c425c1183d31212c1ff115205431bed0f01288'

result={
 'schema':'PR165-independent-preservation-and-acceptance-boundary-review-v1',
 'status':'accepted_scoped_evidence_relocation_pending_actual_required_CI',
 'base':BASE,'head':HEAD,'tree':commit['tree']['sha'],
 'entire_changed_tree_verified_by_independent_Git_tree_recomputation':True,
 'all_other_root_entries_unchanged':True,'other_checkpoint_siblings_unchanged':187,
 'unchanged_moved_subtree':original['sha'],'original_file_count':188,'original_bytes':26428588,
 'all_original_modes_blobs_nested_trees_unchanged':True,
 'mapping_matches_all188_original_PR163_manifest_rows_including_recorded_SHA256':True,
 'original_body_SHA256_independently_rehashed_here':False,
 'reason_body_not_rehashed':'No 26MB original archive/heldout body was downloaded or read; unchanged Git tree/blob identities prove byte preservation. SHA256 values were verified as exact original manifest records.',
 'new_metadata':metadata,'guard_SHA256':hashlib.sha256(guard.encode()).hexdigest(),
 'fixed_e3_import_count':58,'paired_evidence_not_in_fixed_acceptance_set':True,
 'task_product_validation_workflow_source_changes':0,
 'interpretation':'Relocation retains the historical failure archive with explicit non-acceptance provenance. It neither imports the paired evidence into fixed-e3 acceptance nor weakens its unchanged verifier or adds a redirect at the excluded path.',
 'preserved_outcomes':provenance['preserved_original_outcomes'],
 'risks_limits':['Actual PR CI and P7 checks remain separately required; currently all eight observed checks queued.', 'Historical original paths now require the explicit mapping; old manifests remain records of old commits.', 'This is path/provenance preservation only, not acceptance of old benchmark contents, full paired throughput, heldout quality, P5/G4 CI, or release.', 'No remote write, merge, product execution, Cargo, or full CLI gate executed in this audit.'],
 'observed_checks':[{'id':c['id'],'name':c['name'],'status':c['status'],'conclusion':c['conclusion']} for c in read('checks.json')['check_runs']],
 'TODO_closed':0,'TODO_remaining':29,
}
(ROOT/'review.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':result['status'],'review_sha256':hashlib.sha256((ROOT/'review.json').read_bytes()).hexdigest(),'original_files':188,'original_bytes':26428588,'new_metadata':metadata}))
