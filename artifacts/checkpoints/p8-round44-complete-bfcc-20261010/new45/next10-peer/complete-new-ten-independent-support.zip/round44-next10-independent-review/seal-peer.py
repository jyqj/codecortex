import datetime,hashlib,json,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent; ROOT=HERE.parent
def encoded(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def identity(p,b):return {'local_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def write(name,x):
 with (HERE/name).open('xb') as f:f.write(encoded(x))
r=json.loads((HERE/'independent-new-ten-review.json').read_text())
mp=ROOT/'round44-next10-original-intake/sealed/upload-manifest.actual.json'
m=json.loads(mp.read_text());assert m['source']==r['source'] and m['run_id']==r['run_id'] and m['attempt']==1
assert all(f['actual_created'] is True and f['server_sha']==f['git_blob'] for f in m['files'])
r['receiver_immutable_manifest']=m
r['publication_addendum']={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Append actual three receiver immutable evidence locators only; no new original raw reads, validator, ELF or measurements. Original pending peer report remains unchanged.'}
write('independent-new-ten-review.final.json',r)
names=['read-new-ten.py','read-new-ten.attempt01.py','reader-attempt01.execution.json','reader-attempt01.stdout','reader-attempt01.stderr',
 'reader-attempt02.execution.json','reader-attempt02.stdout','reader-attempt02.stderr','independent-new-ten-review.json','independent-new-ten-review.final.json',
 'detailed-new-ten-review.json','selected-new-ten-parity-and-fanout-evidence.json','producer-jobs-0557.original.json','seal-peer.py']
files=[HERE/n for n in names]
files += [ROOT/'round44-next10-original-intake'/n for n in ['terminal.json','stdio-preseal-custody-check.json','host-wrapper-adaptation.diff','host-adaptation.json','sealed/upload-manifest.actual.json']]
members=[];zp=HERE/'complete-new-ten-independent-support.zip'
with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:
  raw=p.read_bytes();name=str(p.relative_to(ROOT));members.append(identity(p,raw)|{'archive_path':name});z.writestr(name,raw)
 manifest={'schema':'new10-independent-peer-selected-support-v1','files':members,'receiver_full_return_support':'eaa37f326aee5af6e06a05b6c265cbf122775c2d',
   'original_whole_ZIP_raw_ELF_not_nested':True,'old27_originals_not_reopened':True,'peer_validator_or_ELF_calls':0,
   'producer_status_boundary':'05:57 original jobs report9success+fanout128tailrunning for this batch. Original accepted native results do not assert37producerjobs success.'}
 raw=encoded(manifest);z.writestr('MANIFEST.json',raw)
write('archive-selection.json',manifest|{'support':identity(zp,zp.read_bytes()),'support_members':len(members)+1,'manifest_member_bytes':len(raw),'manifest_member_sha256':hashlib.sha256(raw).hexdigest()})
prefix='artifacts/checkpoints/p8-round44-complete-bfcc-20261010/new45/next10-peer/'
upload={'files':[identity(p,p.read_bytes())|{'repository_path':prefix+p.name} for p in (HERE/'independent-new-ten-review.final.json',zp,HERE/'archive-selection.json')]}
write('upload-manifest.pending.json',upload);print(json.dumps(upload))
