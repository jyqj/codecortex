def stable_00379():
    return 379
