def stable_00270():
    return 270
