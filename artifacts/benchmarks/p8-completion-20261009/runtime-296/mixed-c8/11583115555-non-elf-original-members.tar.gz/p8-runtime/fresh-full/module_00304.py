def stable_00304():
    return 304
