import hashlib
import json
from pathlib import Path

OUT=Path(__file__).parent
BASE='55902428d49b09bb4a90cee6ccccf985680618bb'
HEAD='2f8ea98dfbe2900d2222140dbcba7903eb1749a9'
PREFIX='artifacts/checkpoints/p8-independent-acceptance-20261009-28fe'
FORBIDDEN='artifacts/checkpoints/localwidth4-100k-paired-20261003'
def load(n):return json.loads((OUT/n).read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def tree_hash(entries):
    rows=sorted(entries,key=lambda e:e['path'].encode()+(b'/' if e['type']=='tree' else b''))
    raw=b''.join(e['mode'].lstrip('0').encode()+b' '+e['path'].encode()+b'\0'+bytes.fromhex(e['sha']) for e in rows)
    return hashlib.sha1(b'tree '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def identity(e):return {k:e[k] for k in ['path','type','mode','sha']}
commits={t:load(t+'-commit-official.json') for t in ['base','head']}
assert commits['base']['sha']==BASE and commits['head']['sha']==HEAD
assert BASE in [x['sha'] for x in commits['head']['parents']]
trees={}
proof=[]
parent_expected={t:commits[t]['tree']['sha'] for t in commits}
for layer,allowed in [('root','artifacts'),('artifacts','checkpoints'),('checkpoints','p8-independent-acceptance-20261009-28fe')]:
    for tag in ['base','head']:
        d=load(tag+'-'+layer+'-official.json')
        assert d['truncated'] is False
        assert tree_hash(d['tree'])==d['sha']==parent_expected[tag]
        trees[tag,layer]=d
    old={e['path']:identity(e) for e in trees['base',layer]['tree']}
    new={e['path']:identity(e) for e in trees['head',layer]['tree']}
    removed=set(old)-set(new)
    added=set(new)-set(old)
    changed={p for p in set(old)&set(new) if old[p]!=new[p]}
    if layer=='checkpoints':
        assert removed==changed==set() and added=={allowed}
        assert 'localwidth4-100k-paired-20261003' not in new
        assert len(old)==189 and len(new)==190
    else:
        assert removed==added==set() and changed=={allowed}
        assert old[allowed]['mode']==new[allowed]['mode']=='040000'
        assert old[allowed]['type']==new[allowed]['type']=='tree'
        parent_expected={tag:(old if tag=='base' else new)[allowed]['sha'] for tag in ['base','head']}
    proof.append({'layer':layer,'base_tree':trees['base',layer]['sha'],'head_tree':trees['head',layer]['sha'],
        'removed':sorted(removed),'added':sorted(added),'changed':sorted(changed),
        'preserved_entries':[old[p] for p in sorted(set(old)-changed)]})
leaf=load('new-subtree-recursive-official.json')
expected=next(e['sha'] for e in trees['head','checkpoints']['tree'] if e['path']==PREFIX.split('/')[-1])
assert leaf['sha']==expected=='9218884b59000ecc9a7cf82bbeb6157d229bf250' and leaf['truncated'] is False
assert len(leaf['tree'])==len({e['path'] for e in leaf['tree']})
by={e['path']:e for e in leaf['tree']}
tree_count=0
for p,expected in [('',leaf['sha'])]+[(e['path'],e['sha']) for e in leaf['tree'] if e['type']=='tree']:
    prefix=p+'/' if p else ''
    children=[dict(e,path=n[len(prefix):]) for n,e in by.items() if n.startswith(prefix) and '/' not in n[len(prefix):]]
    assert tree_hash(children)==expected,p
    tree_count+=1
files=[]
for e in leaf['tree']:
    assert e['mode'] in ['040000','100644']
    if e['type']=='blob':
        assert e['mode']=='100644' and e['size']>=0
        files.append({'path':PREFIX+'/'+e['path'],'mode':e['mode'],'git_blob':e['sha'],'bytes':e['size']})
assert len(files)==188
closure_path=Path('/workspace/scratch/a217aaae3bde/prospective-combined-tree-prep/historical-v2-complete-read-closure.json')
closure=json.loads(closure_path.read_bytes())
readset={x['path'] for x in closure['current_files']}
assert len(readset)==323
assert not {x['path'] for x in files}&readset
assert not any(p==FORBIDDEN or p.startswith(FORBIDDEN+'/') for p in [x['path'] for x in files])
prior=Path('/dev/shm/a217aaae3bde/platform-review/prospective-original-v2-execution-independent-review.json')
record={
    'schema_version':1,'scope':'PR166 archive-only engineering tree preservation, not native acceptance',
    'reviewer':'/root/pr_audit','pr':166,'head':HEAD,'base':BASE,'head_tree':commits['head']['tree']['sha'],
    'head_parents':[x['sha'] for x in commits['head']['parents']],
    'verdict':'accepted_scoped_archive_integration','unresolved_engineering_scope_blockers':[],
    'method':'Independently retrieve official commit/root/artifacts/checkpoints trees and recompute each Git tree SHA1. Compare path/type/mode/object IDs at every ancestor. Recursively verify entire newly added subtree inventory and every subtree hash without downloading archive payload blobs.',
    'preservation_proof':proof,
    'new_subtree':{'path':PREFIX,'tree':leaf['sha'],'recursive_entries':len(leaf['tree']),'tree_nodes_verified_including_root':tree_count,'regular_files':len(files),'uncompressed_bytes':sum(x['bytes'] for x in files),'files':files},
    'original_source_guard_and_task_inputs_unchanged':True,
    'all_189_old_checkpoint_siblings_retained_exact_tree_blob_mode':True,
    'forbidden_exact_path':FORBIDDEN,
    'forbidden_absent_in_direct_complete_checkpoints_tree':True,
    'absence_covers_empty_tree_symlink_blob':True,
    'historical_required_read_closure':{'file':str(closure_path),'sha256':sha(closure_path.read_bytes()),'current_reads':323,'new_paths_intersection':[],
        'prior_execution_review':str(prior),'prior_execution_review_sha256':sha(prior.read_bytes()),
        'applicability':'All original actualmain559 required paths remain byte/mode-identical and forbidden path remains absent. This is input applicability, not a new full-checkout guard/CI execution. v15 historicalcontext enumerates its fixed catalogue and temporary context, not unrelated new archives.'},
    'ci_and_merge_boundary':{'normal_nonforce_merge_route':'No source/guard/required-read interaction blocker found. Parent may use normal merge API under its actually enforced requirements; no rules change, force, skip, cancel or queued-as-success inference.',
        'branch_required_gates':'Not inferred absent from previous403/rulesets[]; actual platform enforcement remains authority.',
        'PR166_current_CI_success_claim':False,
        'PR167_E_CI_or_original_v15_replaced':False,
        'future_main_or_merge_tree':'Freshly verify actual merged tree/parents and preserve distinct execution identities if main advances.'},
    'not_in_scope':['Original M5/M6/F5 native success semantics and archive-content truth.','Independent rehash of117096815 payload bytes; this audit verifies fixed Git object identity and tree preservation only.','Use of PR166 results as E=a23bb72 measurement evidence or as complete P8-010 cache acceptance.'],
    'remote_actions':[],'formal_todo_completion':False,'done':163,'remaining':29}
p=OUT/'archive-only-independent-engineering-review.json'
p.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'verdict':record['verdict'],'files':len(files)}))
