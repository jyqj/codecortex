"""Read existing root-owned original log; no Actions access or execution of product."""
import collections,datetime,hashlib,json,re
from pathlib import Path
ROOT=Path('/workspace/scratch/bfccb8494ba0')
HERE=Path(__file__).resolve().parent
path=ROOT/'round42-new45-study/114135224079-original-main.log'
b=path.read_bytes()
assert len(b)==1098463
assert hashlib.sha256(b).hexdigest()=='19dd6cb83ed8e7a9bfb93d9b3ba8b05465a6bffabf69824c381e5c2dfd042354'
oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
assert oid=='b42f2f685f4f2caaaa0497db6706399d9f89d998'
lines=b.decode('utf-8-sig').splitlines()
ansi=re.compile(r'\x1b\[[0-9;]*m')
clean=[ansi.sub('',re.sub(r'^\S+Z\s?', '',l)) for l in lines]
methods=[
 'benchmark::oracle::streaming::tests::borrowed_cursor_pair_keeps_original_step_and_conversion_error_order',
 'benchmark::oracle::streaming::tests::borrowed_cursor_text_matches_owned_conversion_and_row_storage',
 'benchmark::oracle::streaming::tests::borrowed_cursor_pair_preserves_both_rows_duplicates_and_asymmetric_eof',
 'task_descriptive_cli_does_not_launch_a_n30_or_mixed_scope_plan',
 'task_descriptive_scope_is_explicit_n1_without_weakening_old_n30',
 'task_descriptive_scope_rejects_changed_identity_and_registered_budgets']
group,target=None,None
observations=[]; results=[]; ignored=[]; warnings=[]; failures=[]; json_outputs=[]; commands=[]
for i,text in enumerate(clean,1):
 if text.startswith('##[group]Run '):
  group={'line':i,'command':text[len('##[group]Run '):]};commands.append(group);target=None
 if re.search(r'Running (unittests|tests/)',text):target={'line':i,'text':text}
 if text.startswith('test ') and ' ... ' in text:
  name,outcome=text[5:].split(' ... ',1)
  if name in methods:observations.append({'method':name,'line':i,'original':lines[i-1],'outcome':outcome,'group':group,'target':target})
  if outcome.startswith('ignored'):ignored.append({'line':i,'method':name,'reason':outcome,'group':group,'target':target})
  if outcome=='FAILED':failures.append({'line':i,'original':lines[i-1]})
 if text.startswith('test result:'):
  results.append({'line':i,'text':text,'group':group,'target':target})
  if not text.startswith('test result: ok.'):failures.append({'line':i,'original':lines[i-1]})
 if '##[error]' in text:failures.append({'line':i,'original':lines[i-1]})
 if '##[warning]' in text:warnings.append({'line':i,'original':lines[i-1]})
 if text.startswith('{'):
  try:x=json.loads(text)
  except json.JSONDecodeError:continue
  if isinstance(x,dict) and ('source_version' in x or 'task_count' in x or 'V19' in x):json_outputs.append({'line':i,'value':x})
expected_commands={
 'cargo test --workspace --all-targets --exclude cc-semantic --locked',
 'cargo test -p cc-eval --features eval-http --locked'}
assert len(observations)==12 and len({x['method'] for x in observations})==6
for m in methods:
 matches=[x for x in observations if x['method']==m]
 assert len(matches)==2 and all(x['outcome']=='ok' for x in matches)
 assert {x['group']['command'] for x in matches}==expected_commands
assert not failures
guard=next(x for x in json_outputs if x['value'].get('source_version')=='p8-completion-source-20261009-v15')
assert guard['value']['status']=='passed'
assert guard['value']['product_source']=='3481da0baf46bf510580951a4f5fbc9cb2255ae5'
assert guard['value']['review_source']=='533e900cf83900f726e92835956137356081861f'
assert guard['value']['complete_inputs']==1096
plans=[x for x in json_outputs if 'task_count' in x['value'] and 'states' in x['value']]
assert plans and all(x['value']['status']=='passed' and x['value']['task_count']==192 and x['value']['states']=={'done':164,'blocked':1,'in_progress':15,'todo':12} for x in plans)
assert clean[189]=='9c4f29f5b290bfcd60375bc1c1c7a194b5099eae'
important_results=[x for x in results if x['group'] and x['group']['command'] in expected_commands and x['target'] and
                   ('p8_scale-' in x['target']['text'] or 'unittests src/lib.rs' in x['target']['text'] and 'cc_eval-' in x['target']['text'])]
assert len(important_results)==4
assert sum('22 passed; 0 failed; 0 ignored;' in x['text'] for x in important_results)==2
probes=[x for x in ignored if 'benchmark::oracle::projection_tests::' in x['method'] and 'probe' in x['method']]
assert len(probes)==4 and len({x['method'] for x in probes})==2
facts=json.loads((HERE/'finite-merge-readiness-review.json').read_text())
report={'schema':'independent-original-PR201-G2-main-log-peer-v1','reviewer':'/root/pr_triage',
 'scope':'Original terminal engineering main job only; distinct study and hour-soak outcomes are not inherited.',
 'source':'f97c5068d056969705e8387ba1f37d83847f5bee','source_tree':'39a053ae49b486764751a570d164e7cd41d7ff29',
 'run_id':38025451919,'job_id':114135224079,'conclusion':'success','completed_at':'2026-10-10T05:24:45Z',
 'log':{'path':str(path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':oid,'contains_original_BOM':b.startswith(b'\xef\xbb\xbf')},
 'checkout':{'sha':clean[189],'line':190,'parents':['b9b089bb4eae072affe9326681d4980eae15fd84','f97c5068d056969705e8387ba1f37d83847f5bee'],
  'tree':'39a053ae49b486764751a570d164e7cd41d7ff29','evidence':'Actual checkout from this log; exact parents/tree reused from previously accepted official 05:10 bridge, immutable report ba71a59e609fdd31e73f20b304257ddfca89aae5 and support90e1acc5019ad32746af663573aeac35fe2a1a38. No new tree fetch.'},
 'new_unique_methods':6,'new_pass_observations':12,'new_method_observations':observations,
 'critical_cargo_summaries':important_results,'guard':guard,'task_plan_outputs':plans,
 'historical_integration_outputs':[x for x in json_outputs if 'V19' in x['value']],
 'ignored_borrowed_probes':probes,'all_ignored_observations':ignored,
 'all_cargo_result_summaries':results,'commands':commands,'failure_annotations_or_failed_tests':failures,
 'warnings':warnings,'ordinary_current':{'observed':facts['ended'],'success':25,'total':26,'running_job':114135223703,
  'running_step':'One-hour actual stdio session with Git switches and catalog churn','started_at':'2026-10-10T04:59:53Z'},
 'limitations':[
  'Six distinct new methods each passed in default-workspace and eval-http configurations, not twelve unique methods; eval-http is not labelled semantic.',
  'Main cargo test uses debug test profile. New N1 positive Release45 plan admission is independently established by original study build job114138076763:1 passed21 filtered; main debug run does not substitute for that Release branch.',
  'Two borrowed cost probes remain ignored in each relevant configuration. All other ignored/filtered results remain retained by target/command, not silently counted as executed.',
  'Expected MCP negative-case Error strings appear in the successful fixture suite and are not a failed job or error annotation.',
  'One checkout Node.js20 deprecation/forcedNode24 annotation is preserved; no failed test or error annotation was found.',
  'Original G750 formatter failure remains historical. This new G2 actualfmt success does not erase it.',
  'Source v15 passed proves its declared admission scope; runtime/quality/study completion remains separate. Taskplan stays164done/28remaining.',
  'Only hour-soak remains unfinished among26ordinary checks at05:34:41-43. Engineeringmerge remains pending its actual terminal verification/preservation.',
  'No Actions download, Rust/product/test/validator rerun, artifact intake, refs, labels, PR or task mutation performed by this reader.'],
 'reader_attempt_history':'Attempt01 parser exit1: it selected historical-integrations summary by task_count and incorrectly assumed a states key. Attempt02 restricts plan outputs to their actual states schema, while preserving the historical summary separately. No product execution or original input change.',
 'result':'accepted_main_engineering_evidence_pending_existing_hour_soak',
 'read_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(HERE/'independent-original-main-log-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
selected=set([187,189,190,468,478,498,730,5306,5310,6064,6066,6067,6076,6077,9696])
selected.update(x['line'] for x in observations+important_results+probes+warnings+plans)
(HERE/'main-selected-original-lines.json').write_text(json.dumps([{'line':n,'original':lines[n-1]} for n in sorted(selected)],ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'result':report['result'],'unique_new_methods':6,'actual_pass_observations':12,'source_v15':'passed','task_plan':'passed','ordinary':'25success1running','warnings':len(warnings)}))
