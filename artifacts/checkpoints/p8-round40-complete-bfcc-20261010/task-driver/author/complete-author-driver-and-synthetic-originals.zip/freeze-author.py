import ast
import datetime
import difflib
import hashlib
import json
from pathlib import Path
import stat
import zipfile

BASE = Path('/workspace/scratch/bfccb8494ba0')
ROOT = BASE / 'round40-task-descriptive-driver-candidate'
paths = ['scripts/p8_task_profile_matrix.py', 'scripts/tests/test_p8_task_profile_matrix.py',
         'docs/roadmap/code-index-v2/P8-TASK-PROFILE-DESCRIPTIVE.md',
         'docs/roadmap/code-index-v2/p8-profile-task-descriptive-v1.json']

def meta(path):
    data = path.read_bytes()
    return dict(local_path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                git_blob=hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
                mode=oct(stat.S_IMODE(path.stat().st_mode)))

def write(name, data):
    path = ROOT / name
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    return path

for name in paths[:2]:
    ast.parse((ROOT / 'candidate' / name).read_text())
spec = json.loads((ROOT / 'candidate' / paths[-1]).read_text())
assert spec['cell_count'] == 45 and spec['record_count'] == 85
assert spec['repetitions'] == 1 and spec['cold_curve_is_subset_of_setup'] is True
items = [dict(repository_path=name, status='A', **meta(ROOT / 'candidate' / name)) for name in paths]
manifest = write('source-manifest.json', dict(actual_P=None, author='execution_recon', source_leaves=items,
    fixed_existing_main='b9b089bb4eae072affe9326681d4980eae15fd84',
    required_PR192_native_integration='round40-PR192-main-integration-candidate',
    required_explicit_task_scope_hook=meta(BASE / 'round40-profile-task-descriptive-native-candidate/candidate/scripts/p8_scale_matrix.py'),
    runtime_source_identity='resolved only by final actual source/build/run/attempt registration; no guessed SHA',
    prior_source_or_study_mutated=False))
patch = ''.join(''.join(difflib.unified_diff([], (ROOT / 'candidate' / name).read_text().splitlines(True),
                                          fromfile='/dev/null', tofile='b/' + name)) for name in paths)
(ROOT / 'source.patch').write_text(patch)
old = ROOT / 'synthetic-attempt01/synthetic-source-view/scripts/p8_task_profile_matrix.py'
new = ROOT / 'candidate/scripts/p8_task_profile_matrix.py'
delta = ''.join(difflib.unified_diff(old.read_text().splitlines(True), new.read_text().splitlines(True),
                                   fromfile='attempt01/p8_task_profile_matrix.py', tofile='final/p8_task_profile_matrix.py'))
(ROOT / 'attempt01-to-final-driver.diff').write_text(delta)
donor = BASE / 'round40-PR192-main-integration-candidate/candidate/scripts/p8_profile_matrix.py'
old_text, new_text = donor.read_text(), new.read_text()
def function(text, name, next_name):
    return text[text.index('def ' + name + '('):text.index('def ' + next_name + '(')]
assert function(old_text, 'expected_fanout_case', 'inspect_raw') == function(new_text, 'expected_fanout_case', 'inspect_raw')
expected = function(old_text, 'inspect_raw', 'validate_shard').replace(
    'isolated_profile=profile)', 'isolated_profile=profile, profile_scope=SCOPE)').replace(
    'isolated native sample count differs', 'task native sample count differs')
assert expected == function(new_text, 'inspect_raw', 'validate_shard')
receipts = [json.loads((ROOT / directory / 'receipt.json').read_text())
            for directory in ['synthetic-attempt01', 'synthetic-attempt02-final']]
assert all(row['exit_code'] == 0 and row['inputs_before_equals_after'] for row in receipts)
assert 'Ran 11 tests' in (ROOT / 'synthetic-attempt01/stderr').read_text()
assert 'Ran 12 tests' in (ROOT / 'synthetic-attempt02-final/stderr').read_text()
for name in paths[:2]:
    assert (ROOT / 'candidate' / name).read_bytes() == (ROOT / 'synthetic-attempt02-final/synthetic-source-view' / name).read_bytes()
report = write('author-design-and-validation-boundary.json', dict(
    schema='p8-task-descriptive-driver-author-v1', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    author='execution_recon', independent_source_approval='pending', actual_P=None,
    changes='four new files only; no old driver, source, test, workflow or registered study modified',
    old_profile_driver=meta(donor), final_source_manifest=meta(manifest),
    source_instructions=dict(CONTRIBUTING=meta(BASE / 'round40-borrowed-sorted-cursor-candidate/CONTRIBUTING.original.md'),
        actual_main='b9b089bb4eae072affe9326681d4980eae15fd84',
        ancestor_AGENTS_git_paths=['AGENTS.md', 'scripts/AGENTS.md', 'scripts/tests/AGENTS.md',
             'docs/AGENTS.md', 'docs/roadmap/AGENTS.md', 'docs/roadmap/code-index-v2/AGENTS.md'],
        actual_ls_tree_exit=0, actual_ls_tree_stdout=''),
    protocol=dict(schema=spec['schema'], scope=spec['stage_scope'], N=1, cells=45, retained_records=85,
                  setup=40, mutation=40, fanout=5, cold_selected='five no_op setups prescribed before run; subset of forty',
                  budgets_unchanged=True, full_fifteen_table_original_validation=True,
                  old_N30_and_full_populations_unchanged=True, observed_results_available=False),
    implementation=[
        'Explicit new plan; old full.registered_plan still requires repetitions at least30.',
        'Same original full.build/validate_build/run_shard/_validate_shard; no alternate native success predicate.',
        'Exact original expected_fanout_case function; inspect_raw exact original additional checks except explicit new scope and error label.',
        'Build seals complete task-registry before cells, rechecked against same source/binary/driver/run/attempt and45plans.',
        'All forty cold setups retained; five cold-curve records selected by no_op name, never timing.',
        'Aggregate attempts every supplied original cell; retains failed receipts, errors and missing slots; duplicate or any failure prevents passed.',
        'Every environment and original measurement retained separately; no quantiles, pooled means or latency thresholds.',
        'Observer closure contains newcapture and its unchanged delegated old capture source plus workflow/docs/schema/tests.'
    ],
    real_validation=receipts,
    first_to_final_change='First11 controls passed before old capture closure/IndexError custody hardening/unique count and added resealed-registration negative; final12 controls passed on exact final source.',
    actual_product_execution=dict(Rust='not_run', fmt='not_run', Clippy='not_run', native='not_run', ELF='not_run',
                                 Actions='not_run', studies='not_run', source_guard='not_run'),
    synthetic_scope='Mock build/validate only where explicitly shown; generated raw fixtures are no study samples.',
    risk_limits=['Future actual native scope must compile and execute on final admitted source.',
                 'Observer workflow/capture are separate root-authored inputs not executed by this test suite.',
                 'No claim45cell success or taskdone; no stable statistics or historical study equivalence.',
                 'Malformed or missing original inputs remain failures; partial capture is only custody.'],
    task_statuses_changed=False, credit=0, remote_refs_changed=False))
selected = [ROOT / 'candidate' / name for name in paths]
selected += [manifest, report, ROOT / 'source.patch', ROOT / 'attempt01-to-final-driver.diff',
             ROOT / 'prepare-driver.py', ROOT / 'run-synthetic-once.py', ROOT / 'freeze-author.py']
for directory in ['synthetic-attempt01', 'synthetic-attempt02-final']:
    selected += [ROOT / directory / name for name in ['receipt.json', 'stdout', 'stderr', 'inputs-before.json', 'inputs-after.json']]
selection = write('archive-selection.json', dict(files=[dict(archive_path=str(path.relative_to(ROOT)), **meta(path)) for path in selected]))
sealed = ROOT / 'sealed'
sealed.mkdir(exist_ok=True)
zip_path = sealed / 'complete-author-driver-and-synthetic-originals.zip'
with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in selected + [selection]:
        info = zipfile.ZipInfo(str(path.relative_to(ROOT)))
        info.external_attr = (stat.S_IMODE(path.stat().st_mode) | stat.S_IFREG) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, path.read_bytes())
with zipfile.ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    for path in selected + [selection]:
        assert archive.read(str(path.relative_to(ROOT))) == path.read_bytes()
uploads = [ROOT / 'candidate' / name for name in paths] + [manifest, report, zip_path, selection]
write('sealed/upload-manifest.pending.json', dict(files=[meta(path) for path in uploads],
     members=len(selected)+1, source_paths=paths, no_refs=True))
print(json.dumps(dict(files=items, support=meta(zip_path), members=len(selected)+1)))
