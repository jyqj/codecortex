from pathlib import Path
import hashlib, json, stat, zipfile

ROOT = Path('/dev/shm/root-round17')
SELECTIONS = [
    ('Gc8-failed-100k', Path('/dev/shm/execution-recon-recovery-20261009/failed-100k-11617588539/archive-selection.json')),
    ('Gc8-failed-aggregate', Path('/dev/shm/execution-recon-recovery-20261009/failed-aggregate-11619200069/archive-selection.json')),
    ('Gc8-independent-phase-analysis', Path('/dev/shm/pr-triage-Gc8-100k-failure-analysis/archive-selection.json')),
]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def oid(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def read_regular(path):
    mode = path.lstat().st_mode
    assert stat.S_ISREG(mode), str(path)
    return path.read_bytes(), stat.S_IMODE(mode)

entries = []
for prefix, selection in SELECTIONS:
    raw, mode = read_regular(selection)
    entries.append((f'{prefix}/archive-selection.json', raw, mode, str(selection)))
    declared = json.loads(raw)
    for row in declared['files']:
        path = Path(row.get('local_path', row['path']))
        raw, mode = read_regular(path)
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], str(path)
        if 'git_blob' in row:
            assert oid(raw) == row['git_blob'], str(path)
        rel = row['path']
        if Path(rel).is_absolute():
            rel = str(path.relative_to(selection.parent))
        assert '..' not in Path(rel).parts and not Path(rel).is_absolute()
        entries.append((f'{prefix}/{rel}', raw, mode, str(path)))

observed = json.loads((ROOT / 'H-observed-source-admission.json').read_text())
stdout = observed['original_v15_stdout'].encode()
assert len(stdout) == 572
assert sha(stdout) == 'f619f8b10ae650a5f48d3bf95ba87f807ce320718b8dcd68bbf5114386b9cd11'
entries.append(('H-observed-admission/original-v15.stdout', stdout, 0o644, 'exact stdout extracted from received native output'))
for name in ['H-observed-source-admission.json', 'P3-create-commit-original.json', 'P3-create-tree-original.json', 'P3-create-production-blob-original.json', 'P3-create-test-blob-original.json', 'seal-progress-originals.py']:
    raw, mode = read_regular(ROOT / name)
    entries.append((f'progress/{name}', raw, mode, str(ROOT / name)))

summary = {
    'schema': 'p8-round17-in-progress-checkpoint-v1',
    'observed_through_utc': '2026-10-09T14:00:34Z',
    'round': 17,
    'round_state': 'in_progress',
    'original_todos': {'total': 192, 'done': 163, 'remaining': 29, 'newly_done': 0},
    'Gc8_original_study': {
        'source': 'c8be5afaac568ffd40ef86d3795423c3b73c9f39',
        'run_id': 37902429727, 'attempt': 1, 'conclusion': 'failure',
        'terminal_utc': '2026-10-09T13:34:06Z',
        '100k_native_status': 'deadline_exceeded', '100k_native_exit': 3,
        'worker_exit_code': None, 'worker_stderr_complete': False,
        'summary_missing': True, 'further_measurement_shards_skipped': 145,
        'aggregate_passed': False, 'accepted_shards': 4,
        'required_shards': 150, 'accepted_samples': 41, 'required_samples': 1500,
        'cohorts_pooled_or_relabelled': False,
        'original_failed_100k_zip_sha256': 'f758ca519a6b5ed90bfe1040944ad32b1daad8248e44b8ea4c7d4840d4a43236',
        'original_failed_aggregate_zip_sha256': '2914d0b238c9ba2614532affd28bfe11132d7d0ce45b3f3b75d391f4132e9363',
    },
    'current_H_source_admission': {
        'source': '0e6b07c75183da79c5a6679d4c2b66c65f7db663',
        'product': 'b3bf22eab019175774c6c83295620b63a9740888',
        'review': 'cd68f3ecf384a3da5e1186c27b1f3ff328bafca4',
        'original_v15_exit': 0, 'elapsed_seconds': 608.9988290829999,
        'started_utc': '2026-10-09T13:25:27.863462Z',
        'ended_utc': '2026-10-09T13:35:36.782986Z',
        'before_and_after_inputs': 1444,
        'full_original_package_received': False,
        'separate_Rust_runtime_scale_claim': False,
    },
    'native_transport': {
        'observed_failure': 'tunnel_client_not_connected', 'http_status': 404,
        'observed_utc': '2026-10-09T13:44:27Z',
        'calls_stopped_after_disconnection': True,
        'G1_C1_and_C4_packaging': 'sealed locally; independent complete package transport pending',
        'G1_C1_and_C4_git_carrier_commit': '28c718badfceb80692f8752da69c914873ba4594',
        'carrier_push_dispatched_once': True, 'carrier_push_exit': None,
        'carrier_ref_still_absent_at_utc': '2026-10-09T13:55:55Z',
        'H_packaging_dispatched_once': True, 'H_packaging_exit': None,
        'G1_C8_started': False, 'G1_C16_started': False,
    },
    'SQL_candidate': {
        'P3': '9c1605118edcb7e88d211c3f6bd31249ebe36dc7',
        'tree': '5ac4d3fb96cfb11433d529b8292d1e7652471036',
        'parents': ['0e6b07c75183da79c5a6679d4c2b66c65f7db663', 'd22d36dddf8b38f1a864c933deefe0b6d3b5baf3'],
        'scope': 'two source files plus exact current main benchmark documentation',
        'formatter_Rust_Clippy_CI': 'not_run',
        'format_only_continuation': 'in_progress',
        'independent_source_review': 'accepted only to enter necessary engineering controls',
        'Python_SQLite_scattered_counterexample': {'old_VM_callbacks': 132988, 'new_VM_callbacks': 163001, 'increase_percent_rounded': 22.57},
        'universal_speedup_claim': False, 'five_hour_scale_pass_claim': False,
    },
    'existing_external_sources': {
        'C3ff_study': {'run_id': 37910924354, 'attempt': 1, 'last_observed': 'in_progress', 'observed_utc': '2026-10-09T13:45:45Z'},
        'diagnostic_study': {'run_id': 37930392164, 'attempt': 1, 'source': '4d18dcdb34b5d7a277566b57801cc882d8b1eb61', 'C4_C8': 'API success; original independent intake pending', 'C1_C16': 'queued at latest read'},
        'new_Cloud_Codex_tasks_started': 0,
    },
}
summary_bytes = (json.dumps(summary, ensure_ascii=False, indent=2) + '\n').encode()
(ROOT / 'round17-progress-summary.json').write_bytes(summary_bytes)
entries.append(('progress/round17-progress-summary.json', summary_bytes, 0o644, str(ROOT / 'round17-progress-summary.json')))
assert len({e[0] for e in entries}) == len(entries)

out = ROOT / 'round17-original-failure-and-progress-evidence.zip'
with zipfile.ZipFile(out, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, raw, mode, local_path in sorted(entries):
        info = zipfile.ZipInfo(name, date_time=(2026, 10, 9, 14, 0, 34))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | mode) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, raw)
with zipfile.ZipFile(out) as archive:
    assert archive.testzip() is None
    assert sorted(archive.namelist()) == sorted(e[0] for e in entries)
    for name, raw, mode, local_path in entries:
        assert archive.read(name) == raw, name

blob = out.read_bytes()
manifest = {
    'schema': 'round17-progress-evidence-complete-members-v1',
    'archive': out.name, 'archive_bytes': len(blob), 'archive_sha256': sha(blob), 'archive_git_blob': oid(blob),
    'member_count': len(entries), 'uncompressed_bytes': sum(len(x[1]) for x in entries),
    'members': [{'path': name, 'bytes': len(raw), 'sha256': sha(raw), 'git_blob': oid(raw), 'mode': oct(mode)} for name, raw, mode, local_path in sorted(entries)],
    'transport_credentials_and_native_observation_tokens_included': False,
    'original_failed_ZIPs_and_all_declared_selected_bytes_preserved': True,
}
(ROOT / 'round17-complete-evidence-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in manifest.items() if k != 'members'}))
