#!/usr/bin/env python3
"""Read/hash and mechanically compare source; never import/run the product."""
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path('/dev/shm/root-round21/oracle-order-witness')
LIVE = Path('/dev/shm/a217aaae3bde/pr180-M6-b2a1-validated')
MAP = Path('/dev/shm/todo-audit-P6B-crash-ready-source-review/actual-P6B-complete-product-validation-inputs.json')
OUT = Path(sys.argv[1])
assert not OUT.exists(), 'fresh independent output required'
OUT.mkdir(parents=True)
PATHS = ['crates/cc-eval/src/benchmark/oracle/streaming.rs',
         'crates/cc-eval/tests/benchmark_oracle_streaming.rs']
EXPECTED = {
    PATHS[0]: '52ef74482a85e5a0711ab4af2006473932082ff07f34a84e1649b12717b34c97',
    PATHS[1]: 'd9c0439b36a671d082bc403d150f5ec2e46552f78bb64086fc85d0672ede96ff',
}

def meta(data):
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                git_blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())

def write(name, value):
    (OUT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')

def between(s, start, end):
    return s[s.index(start):s.index(end, s.index(start))]

identity = json.loads(MAP.read_text())
manifest = json.loads((ROOT/'candidate-files.json').read_text())
sources = []
for path in PATHS:
    old = (ROOT/'original'/path).read_bytes()
    new = (ROOT/'candidate'/path).read_bytes()
    om, nm = meta(old), meta(new)
    original = identity['actual_input_mode_blob_inventory'][path]
    assert original['sha256'] == om['sha256'] and original['sha'] == om['git_blob']
    assert original['size'] == om['bytes'] and original['mode'] == '100644'
    assert nm['sha256'] == EXPECTED[path]
    authored = next(x for x in manifest if x['path'] == path)
    assert all(nm[key] == authored[key] for key in ['bytes','sha256','git_blob'])
    target = OUT/'source'/path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(new)
    sources.append(dict(path=path, original=om, candidate=nm, original_git_mode='100644'))

a = (ROOT/'original'/PATHS[0]).read_text()
b = (ROOT/'candidate'/PATHS[0]).read_text()
oldspool = between(a, 'fn spool(', 'fn next_row(')
newspool = between(b, 'fn spool(', 'fn stored_table(')
original_block = oldspool[oldspool.index('        check_row_size('):oldspool.index('        let ordinal =')]
extracted_calls = ('        let serialized = serialized_row(row, &cols, &mut projection, limits)?;\n'
                   '        account_bytes(canonical_bytes, &serialized, limits)?;\n')
assert newspool.count(extracted_calls) == 1
assert newspool.replace(extracted_calls, original_block) == oldspool
assert between(a, 'const INSERT_TIERS:', 'fn spool(') == between(b, 'const INSERT_TIERS:', 'fn spool(')
assert between(a, 'fn next_row(', 'fn compare_with_validated_limits(') == between(b, 'fn next_row(', 'fn compare_with_validated_limits(')
assert a[a.index('#[cfg(test)]\nmod tests {'):] == b[b.index('#[cfg(test)]\nmod tests {'):]
assert a[:a.index('fn check_row_size(')] == b[:b.index('fn check_row_size(')]
assert between(a,'fn check_row_size(','const INSERT_TIERS:').rstrip() == between(b,'fn check_row_size(','fn serialized_row(').rstrip()

support = []
for path in ['Cargo.toml','crates/cc-eval/src/benchmark/oracle.rs',
             'crates/cc-eval/src/benchmark/p8_scale.rs','scripts/p8_scale_matrix.py']:
    data = (LIVE/path).read_bytes()
    m = meta(data)
    original = identity['actual_input_mode_blob_inventory'][path]
    assert original['sha'] == m['git_blob'] and original['sha256'] == m['sha256']
    assert original['size'] == m['bytes']
    support.append(dict(path=path, **m, verified_against_actual_P6B_map=True))

def anchor(s, text):
    return s[:s.index(text)].count('\n')+1

review = dict(
    schema='independent_oracle_order_witness_source_review_v1',
    reviewer='/root/todo_audit', author='/root',
    verdict='accepted_scoped_source_pending_original_Rust_validation', blockers=[],
    product_executed=False, rustfmt_executed=False, clippy_executed=False,
    performance_credit=False, scale_acceptance_credit=False, todo_completion_credit=0,
    source_basis=dict(actual_source=identity['source'], actual_tree=identity['source_tree'],
                      scope='actual P6B product bytes inherited by G6; candidate is uncommitted',
                      complete_map=meta(MAP.read_bytes())),
    sources=sources, retained_support=support,
    mechanical_checks=dict(
        spool_after_expanding_only_two_helpers='byte_identical_to_original',
        complete_CanonicalInsert='byte_identical',
        next_row_equal_rows_digest_example_and_entry_points_open_scratch='byte_identical',
        original_six_unit_test_module='byte_identical',
        original_limits_and_raw_row_size_check='byte_identical',
        original_integration_test_definitions=8, candidate_integration_test_definitions=10,
        tests_actually_run=0),
    source_findings=[
        dict(topic='eligibility', line=anchor(b,'fn stored_table('), conclusion=
             "sqlite_schema type=table and rootpage>0 excludes VIEW and virtual tables. The existing table_info projection omits generated/hidden columns. Ordinary stored rows are reread under the already-held source snapshot; dynamic sources retain original dual spool."),
        dict(topic='A priority and B validation', line=anchor(b,'fn equal_input_order('), conclusion=
             "The original A spool fully completes before witness entry. B is stepped, row-limited, raw-size checked, projected/UTF8-checked, serialized-size checked, then cumulative-byte checked before comparison with the next A row. Every error propagates; only an ordinary byte/order/count/EOF mismatch yields false."),
        dict(topic='accounting', line=anchor(b,'    let mut witness_bytes ='), conclusion=
             "Witness uses a local copy of cumulative canonical bytes. Only both EOF plus exact expected A count commits B accounting. False discards it, then unchanged B spool counts once. True counts actual A+B canonical bytes despite storing only A. B ordinal conversion may be skipped safely because admitted row caps are far below i64::MAX."),
        dict(topic='whole-row equality and multiplicity', line=anchor(b,'        if av != bv {'), conclusion=
             "All serialized projected bytes and both complete EOFs are required, not a digest or prefix. Full duplicate counts follow expected_count. Signed-zero encoding differences reject the witness and preserve old sorted Value comparison and distinct exact digests."),
        dict(topic='sorted report', line=anchor(b,'            let bvalue ='), conclusion=
             "On a complete byte witness, both digest streams consume the same actual A sorted rows; otherwise they consume the original independent sorted streams. Existing examples, counts, ordering, layout, capacity profile and limits stay unchanged; an additional table-level Boolean exposes which path was used."),
        dict(topic='resource outcome boundary', conclusion=
             "Same hard scratch cap/cache/page/row/byte admission is retained. Omitting B storage may legitimately avoid an old two-copy disk-full result; preserving one-sided exhaustion controls is sufficient and no artificial duplicate allocation is required. Extra A scan/projection cost and hit rate are unmeasured; no speed claim follows from source review."),
        dict(topic='driver compatibility', conclusion=
             "Current p8_scale.rs parity passes through the returned Value and adds counts; scripts/p8_scale_matrix.py check_parity reads required table fields without exact-key equality. It still checks all 15 tables, count correspondence, capacity mode, exact limits/layout and bounds. The additive witness field requires no driver/protocol modification.")
    ],
    test_source_assessment=dict(
        direct_new_controls=['same-source witness and reversed-order fallback for all 15 tables/types/duplicates',
                             'full canonical-byte sum for same-source and fallback paths',
                             '100002-row complete witness and last-row mutation rejection',
                             'signed-zero fallback preserving original digests',
                             'B-side cumulative canonical-byte failure',
                             'A UTF8 failure takes precedence over B oversized row',
                             'VIEW and FTS5 virtual table fallback'],
        original_controls_retained=['six independent spool/unit tests',
                                    'row/byte/disk failures', 'malformed schema, UTF8 and FK',
                                    'content/multiplicity/missing-row and all-table detection'],
        narrow_nonblocking_suggestion='Add A=1 row, B=same first row plus an extra row, max_rows=1 and assert side 1 row-budget error; old max_rows control fails on A and does not directly distinguish the new B witness branch.'),
    execution_boundary='Only read/hash/source-equivalence assertions were executed. No original validator, Cargo, formatter, Clippy, workload, SQLite fixture, or performance run was invoked.'
)
write('independent-source-review.json', review)
(OUT/'candidate.diff').write_bytes((ROOT/'candidate.diff').read_bytes())
write('mechanical-source-checks.json', dict(status='passed', checks=review['mechanical_checks'],
                                         immutable_candidate_hashes=EXPECTED))
print(json.dumps(dict(status='source_review_written', output=str(OUT),
                     report=meta((OUT/'independent-source-review.json').read_bytes())), ensure_ascii=False))
