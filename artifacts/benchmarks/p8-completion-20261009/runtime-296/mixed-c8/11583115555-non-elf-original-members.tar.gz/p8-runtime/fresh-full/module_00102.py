def stable_00102():
    return 102
