def stable_00010():
    return 10
