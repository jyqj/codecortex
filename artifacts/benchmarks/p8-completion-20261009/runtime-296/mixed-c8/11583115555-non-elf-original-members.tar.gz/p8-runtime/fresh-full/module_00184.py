def stable_00184():
    return 184
