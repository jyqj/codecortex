#!/usr/bin/env python3
"""New append-only independent review following scratch loss; no execution credit."""
import datetime, difflib, hashlib, json
from pathlib import Path, PurePosixPath
ROOT=Path(__file__).resolve().parent
DONOR=Path('/dev/shm/todo-audit-p8007-final-main-integration')
def read(p): return json.loads(p.read_text())
def sha(b): return hashlib.sha256(b).hexdigest()
def oid(k,b): return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def write(n,d):
    with (ROOT/n).open('x') as f: json.dump(d,f,ensure_ascii=False,indent=2,sort_keys=True);f.write('\n')
def hash_leaves(leaves, expected_dirs=None):
    children={}
    for p,row in leaves.items():
        pp=PurePosixPath(p);children.setdefault(str(pp.parent) if str(pp.parent)!='.' else '',{})[pp.name]=row
        for parent in pp.parents:
            if str(parent)=='.':break
            children.setdefault(str(parent),{})
    computed={}
    for path in sorted(children,key=lambda p:(p.count('/')+(bool(p)),p),reverse=True):
        rows=children[path]
        raw=b''.join((row['mode'].lstrip('0')+' '+name).encode()+b'\0'+bytes.fromhex(row['sha']) for name,row in sorted(rows.items(),key=lambda pair:(pair[0]+('/' if pair[1]['type']=='tree' else '')).encode()))
        current=oid('tree',raw);computed[path]=current
        if expected_dirs is not None:assert current==expected_dirs[path],path
        if path:
            pp=PurePosixPath(path);parent=str(pp.parent) if str(pp.parent)!='.' else ''
            children.setdefault(parent,{})[pp.name]={'mode':'040000','type':'tree','sha':current}
    return computed

meta=read(ROOT/'actual-P2-official-commit.recovered.json')
assert meta['sha']=='b3bf22eab019175774c6c83295620b63a9740888'
assert meta['tree']['sha']=='964af30886e142c6284dddab4e4451b4dc5e26cb'
parents=[x['sha'] for x in meta['parents']]
assert parents==['d7f21ab52ee2068c45ab5f7781e9e1db57f613de','4efbc97eb439a56347e7b32d05b7ea1ab6d34c75','ae033369f015c416cd7995709c1853497773cf6a']
old_raw=(ROOT/'canonical-R1-51d5.original.json').read_bytes()
assert sha(old_raw)=='9a8a494481ac0acb2a2199b2df5697fe3727092abe1644bd91a6717d11418eeb'
assert oid('blob',old_raw)=='74eadfa07b3c75823219d3a21572407a98f4c49f'
old=json.loads(old_raw)
maps=read(DONOR/'actual-P2/actual-P2-complete-product-validation-inputs.json')
tree=read(DONOR/'actual-P2/actual-P2-complete-derived-Git-tree.json')
assert not tree['truncated']
all_entries={r['path']:r for r in tree['tree']}
assert len(all_entries)==len(tree['tree'])
leaves={p:r for p,r in all_entries.items() if r['type']!='tree'}
dirs={p:r['sha'] for p,r in all_entries.items() if r['type']=='tree'};dirs['']=meta['tree']['sha']
computed=hash_leaves(leaves,dirs)
assert tree['sha']==meta['tree']['sha']==maps['source_tree']
assert maps['source']==meta['sha'] and maps['source_parents']==parents
product=maps['complete_inputs'];validation=maps['validation_inputs'];delta=maps['paths'];iv=maps['actual_input_mode_blob_inventory']
assert len(product)==1095 and len(validation)==142 and len(delta)==70
assert set(product)|set(validation)==set(iv)
assert set(product)==set(old['complete_inputs'])
assert validation==old['validation_inputs']
changed=[p for p in product if product[p]!=old['complete_inputs'][p]]
expected=['crates/cc-eval/src/benchmark/ablation/mechanism_controls.json','crates/cc-search/src/lanes.rs','crates/cc-search/src/query_policy.rs']
assert changed==expected
assert {p:v for p,v in delta.items() if p not in changed}==old['paths']
assert all(set(v)=={'before_sha256','sha256'} and v['sha256']==product[p] for p,v in delta.items())
for p in changed:assert delta[p]['before_sha256']==old['complete_inputs'][p]
for p in iv:
    assert all(iv[p][k]==leaves[p][k] for k in ('mode','type','sha'))
    if p not in changed:
        assert all(iv[p][k]==old['actual_input_mode_blob_inventory'][p][k] for k in ('mode','type','sha'))
source_notes={}
for i,p in enumerate(expected):
    before=(ROOT/f'before-{i}.raw').read_bytes();after=(DONOR/f'main4ef-source-{i}.raw').read_bytes()
    assert sha(before)==old['complete_inputs'][p] and oid('blob',before)==old['actual_input_mode_blob_inventory'][p]['sha']
    assert sha(after)==product[p] and oid('blob',after)==iv[p]['sha']
    assert len(after)==iv[p].get('size',len(after))
    (ROOT/f'after-{i}.raw').write_bytes(after)
    diff=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='G1/'+p,tofile='P2/'+p))
    (ROOT/f'change-{i}.diff').write_text(diff)
    source_notes[p]={'before_sha256':sha(before),'sha256':sha(after),'before_blob':oid('blob',before),'blob':oid('blob',after),'bytes':len(after),'reviewer':'/root/execution_recon'}
controls=json.loads((ROOT/'after-0.raw').read_text());oldcontrols=json.loads((ROOT/'before-0.raw').read_text())
assert controls[1]==oldcontrols[1]
for control in controls:
    actual=(ROOT/('after-1.raw' if control['path'].endswith('lanes.rs') else 'after-2.raw')).read_text()
    assert actual.count(control['on_text'])==1 and control['off_text'] not in actual
proof=read(DONOR/'actual-P2/actual-P2-source-identity-and-sparse-delta-proof.json')
updates=proof['delta_from_first_parent'];assert len(updates)==70
g1leaves={p:dict(r) for p,r in leaves.items()}
for update in updates:
    p=update['path'];after=update['after'];before=update['before']
    assert all(leaves[p][k]==after[k] for k in ('mode','type','sha'))
    if before is None:del g1leaves[p]
    else:g1leaves[p]=before
g1hashes=hash_leaves(g1leaves)
assert g1hashes['']=='23f0f69fef9d62229fd947e7747aefdfea78d024'
assert all(p in leaves and all(leaves[p][k]==row[k] for k in ('mode','type','sha')) for p,row in g1leaves.items() if p.startswith('artifacts/'))
for p in ('scripts/verify_reviewed_source_v15.py','scripts/reviewed_source_registry_v15.json'):
    if p in g1leaves:assert leaves[p]['sha']==g1leaves[p]['sha']
semantics={
 expected[0]: 'Only local-retrieval fixed on/off anchors change. On refers to the shared registry; off materializes then clears the execution Vec, preserving policy obligations. The semantic_dense control remains byte-identical. Each on anchor matches actual P2 once and off anchor is absent.',
 expected[1]: 'Shared borrowed static registry retains exact_symbol,path,lexical,grep,graph order and stateless Sync references. Existing owned execution-list signature stays Vec and delegates to to_vec. Registry access and lane_id access perform no lane/DB work. No new measured allocation or performance claim.',
 expected[2]: 'Policy obligations iterate the same registry and obtain existing lane IDs. Intent-role mapping, budget caps, semantic availability/error/effective dispatch, wire version, all remaining production fields and fingerprint calculation stay unchanged. New 8-intent/strategy/config/budget control and frozen complete Local/Auto JSON+digest control cover divergence; execution remains separately pending.'}
for p in expected:source_notes[p]['semantic_review']=semantics[p]
report={'schema':'independent-P2-reconstructed-source-review-v1','reconstructed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reconstruction':{'reason':'Entire prior task scratch directory observed absent; surviving RAM donor originals and new official immutable Git reads used. No claim about cause. This is a new append-only review, not the missing old report bytes.','old_path':'/workspace/scratch/bfccb8494ba0/scale-intake-primary/future-P2-lane-registry-independent/actual-P2-complete-source-and-three-path-review.json','recorded_old_bytes':539688,'recorded_old_sha256':'87f61e114d847f72ff8b974ec4ef83bedb80d88f02a72c3f304c4a274f603686','original_report_reproduced':False,'canonical_R1_recovered_byte_exact':True},'source':meta['sha'],'tree':meta['tree']['sha'],'source_parents':parents,'base':maps['base'],'verdict':'accepted_scoped_source_only_execution_pending','scope':'Independent three-path semantics and all 1095 product / 142 validation / 70 BASE delta identity, with exact prior canonical review reused only for unchanged bytes.','independent_reviewer':'/root/execution_recon','unresolved_source_blockers':[],'complete_inputs':product,'validation_inputs':validation,'paths':delta,'actual_input_mode_blob_inventory':iv,'counts':{'product':1095,'validation':142,'historical_delta':70,'new_product_paths':3,'retained_historical_delta':67,'changed_leaves_from_G1':70,'recomputed_directories':len(computed)},'whole_tree_rehash':{'actual_P2':computed[''],'reversed_70_leaf_G1':g1hashes[''],'all_prior_G1_artifacts_preserved':True,'derived_tree_not_an_official_recursive_response':True},'new_source_reviews':source_notes,'prior_review':{'commit':'51d5ed91e14ddb13eccb93ebd28311a3235075cc','blob':'74eadfa07b3c75823219d3a21572407a98f4c49f','sha256':sha(old_raw),'retained_product_paths':1092,'validation_paths':142,'retained_delta_paths':67},'execution_boundary':{'same_P2_controls_pending_original_terminal_review':True,'initial_same_P2_fmt_exit':0,'initial_same_P2_cc_search_lib_compile_exit':101,'initial_missing_original_fixture_count':5,'initial_tests_executed':0,'additional_compile_input_count':6,'initial_input_count':1250,'continued_input_count':1256,'source_and_test_assertions_unchanged':True,'expected_remaining_controls':['cc-search --lib 303 tests','cc-eval fixed_controls_match_current_product_source_once 1 test','cc-search and cc-eval strict Clippy','original four-variant mechanism --prepare-only'],'donor_186_and_G1_results_not_P2_execution_credit':True},'acceptance_boundary':{'remaining_TODOs':29,'formal_scale_source':'c8be5afaac568ffd40ef86d3795423c3b73c9f39','formal_scale_run':37902429727,'accepted_shards':4,'accepted_samples':41,'no_TODO_or_formal_sample_credit':True,'P8_007_actual_four_C_DB_acquisition_observations_remain_separate':True}}
write('actual-P2-independent-source-review.reconstructed.json',report)
print(json.dumps({'source':meta['sha'],'tree':computed[''],'counts':report['counts'],'verdict':report['verdict']}))
