from pathlib import Path
import hashlib,json,zipfile
ROOT=Path('/workspace/scratch/bfccb8494ba0');OUT=Path(__file__).resolve().parent;D=ROOT/'round42-new45-build-original-intake'
def ident(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
names=['source-test.original-response.json','source-plan.original-response.json','source-p8_scale.rs','source-native-p8_scale.rs','review-original-build-log.py','reader.stdout','reader.stderr','reader.exit.json','independent-original-build-log-review.json','log-review-actual-create-blob.json','review-original-build-tuple.py','tuple-reader.stdout','tuple-reader.stderr','tuple-reader.exit.json','independent-original-build-tuple-review.json','seal-independent-peer.py']
files=[(n,OUT/n) for n in names]
for n in ['original-validator-execution.json','original-validator.stdout','original-validator.stderr','validate-original-build-once.py','transport-original.json','validation-attempt01/original-validate-build-return.json','validation-attempt01/native-hash-subprocess-original.json','validation-attempt01/native-hash-stdout.original','validation-attempt01/native-hash-stderr.original']:
 files.append(('receiver/'+n,D/n))
files.append(('official/build-artifact-original-metadata.json',ROOT/'round42-new45-study/build-artifact-original-metadata.json'))
manifest={'scope':'Independent build log and receipt peer, complete selected small originals; not the whole original build ZIP or ELF.',
 'files':[{'member':n,**ident(p)} for n,p in files],
 'external_originals':{
  'full_original_build_log':{'actual_git_blob':'9b61d0159a83b1e5130caca4166ceb9aa0e3013c','bytes':39996,'sha256':'489ed33c2d9352b4463a99f0c46a98e131fca5d8656f440b60fab966e732675b'},
  'receiver_full_70_member_originals_support_actual_git_blob':'79d96014710c2172b8bd17053d2a559144ec6003',
  'receiver_report_actual_git_blob':'767527f7cccf372e6ca1dd866466d6bf66c86da3',
  'receiver_selection_actual_git_blob':'7534c59fc85cddfa8e64e5dcde490f1b4226b241',
  'note':'Complete source/build before-and-after snapshots and restored 1107-input inventory are in the receiver immutable full support, cited with exact per-file hashes in this peer report. They were read here but not repackaged.'},
 'manifest_self_entry_not_recursively_hashed':True}
save(OUT/'member-manifest.json',manifest)
zpath=OUT/'complete-independent-build-peer-originals.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in files+[('member-manifest.json',OUT/'member-manifest.json')]:
  i=zipfile.ZipInfo(n,(2026,10,10,0,0,0));i.create_system=3;i.external_attr=0o100644<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,p.read_bytes())
with zipfile.ZipFile(zpath) as z:
 assert z.namelist()==[n for n,p in files]+['member-manifest.json'] and z.testzip() is None
 for row in manifest['files']:assert hashlib.sha256(z.read(row['member'])).hexdigest()==row['sha256']
sel={'schema_version':1,'formal_round':42,'prefix':'artifacts/checkpoints/p8-round42-complete-bfcc-20261010/new45/build-independent/',
 'files':[{'name':p.name,**ident(p)} for p in [OUT/'independent-original-build-log-review.json',OUT/'independent-original-build-tuple-review.json',zpath]],
 'members':len(files)+1,'log_review_already_actual':'1d00bf6c097258ac3553fc86cadbd38a6838e20d','actual_new_uploads_pending':True}
save(OUT/'publication-selection.json',sel)
print(json.dumps({'files':sel['files'],'selection':ident(OUT/'publication-selection.json'),'members':sel['members']}))
