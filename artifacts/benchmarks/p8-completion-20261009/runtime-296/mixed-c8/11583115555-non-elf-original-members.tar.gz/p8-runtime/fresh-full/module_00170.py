def stable_00170():
    return 170
