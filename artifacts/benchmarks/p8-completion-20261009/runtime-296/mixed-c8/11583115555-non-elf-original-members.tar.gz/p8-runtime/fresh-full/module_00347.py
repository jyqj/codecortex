def stable_00347():
    return 347
