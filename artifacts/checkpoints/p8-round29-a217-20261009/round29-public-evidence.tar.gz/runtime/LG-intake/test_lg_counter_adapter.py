"""Synthetic transport correspondence controls, never native observations."""
import copy,json,pathlib,sys,tempfile,unittest
BASE=pathlib.Path('/workspace/scratch/a217aaae3bde')
sys.path.insert(0,str(BASE/'original-LG-runtime/helpers-LG-v2'))
sys.path.insert(0,str(BASE/'p8-lock-observation-validated/scripts'))
import p8_runtime_lock_observation as native
from lg_counter_audit import audit_original_counter_boundaries


def pair():
    zero=dict(attempts=0,acquired=0,poisoned=0,failed=0,would_block=0,in_flight=0,elapsed_ns_total=0,elapsed_ns_max=0)
    a=dict(schema_version=1,process_id=41,db_instance_id=1,created_instances=1,scope='process_lifetime_all_index_db_handles',sqlite_busy_wait_observed=False,coherent=True,overflowed=False,update_sequence=2,**{r:{m:dict(zero) for m in native.METRICS} for r in native.ROLES})
    b=copy.deepcopy(a);b.update(db_instance_id=3,created_instances=3,update_sequence=100)
    for m in native.METRICS:
        b['workload'][m].update(attempts=4,acquired=1,poisoned=1,failed=1,would_block=1,elapsed_ns_total=1999,elapsed_ns_max=999)
        b['observer'][m].update(attempts=2,acquired=2,elapsed_ns_total=701,elapsed_ns_max=601)
    return a,b


class CounterAdapterControls(unittest.TestCase):
    def execute(self,mutate=None):
        with tempfile.TemporaryDirectory(prefix='lg-synthetic-',dir=BASE/'original-LG-runtime') as td:
            root=pathlib.Path(td);(root/'build-evidence').mkdir();(root/'product').mkdir()
            plan=dict(diagnostic_profile=native.LOCK_OBSERVATION_PROFILE,profile='mixed',operations=900,files=1000,offer_interval_ms=500,concurrency=4)
            before,after=pair();summary=native.summarize(before,after)
            report=dict(diagnostic_profile=plan['diagnostic_profile'],status='passed_observation',exit_code=0,db_lock_observation=summary,owned_cleanup=dict(unfinished_work=0,sampler_stopped=True,product_stopped=True),artifact_seal_status='sealed')
            ops=[dict(kind='operation',id=i,offered_ns=10+i,finished_ns=12+i) for i in range(900)]
            bounds=[dict(kind='db_lock_observation',phase=phase,started_ns=start,finished_ns=start+1,owned_product_pid=41,response=value) for phase,start,value in [('before_work',1,before),('after_work_and_sampler_drain',1000,after)]]
            wire=[]
            for ident,value in [(1,before),(904,after)]:
                wire.extend([dict(event='request',payload=dict(id=ident,method='tools/call',params=dict(name='status',arguments=dict(aspect='lock_observation')))),dict(event='stdout_wire',text=json.dumps(dict(id=ident,result=dict(structuredContent=dict(result=value)))))])
            if mutate:mutate(wire)
            (root/'raw.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in [bounds[0],*ops,bounds[1]]))
            (root/'product/rpc.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in wire))
            (root/'product/process.json').write_text(json.dumps(dict(pid=41)))
            (root/'build-evidence/build-receipt.json').write_text(json.dumps(dict(diagnostic_profile=plan['diagnostic_profile'])))
            (root/'db-lock-observation.json').write_text(json.dumps(summary))
            return audit_original_counter_boundaries(native,root,plan,report,ops,dict(db_lock_observation=2))
    def test_exact_wire_and_nonmicrosecond_integer_deltas(self):
        result=self.execute()
        self.assertEqual(result['summary']['counters']['workload']['writer_mutex_acquire']['elapsed_ns_total'],1999)
        self.assertEqual(result['summary']['counters']['observer']['writer_mutex_acquire']['elapsed_ns_total'],701)
        self.assertEqual(result['original_request_ids'],[1,904])
        self.assertIsNone(result['summary']['counters']['workload']['writer_mutex_acquire']['interval_max_ns'])
    def test_retained_report_without_same_wire_is_rejected(self):
        def mutate(wire):
            row=json.loads(wire[3]['text']);row['result']['structuredContent']['result']['created_instances']=4;wire[3]['text']=json.dumps(row)
        with self.assertRaises(AssertionError):self.execute(mutate)
    def test_missing_boundary_response_is_rejected(self):
        with self.assertRaises(AssertionError):self.execute(lambda wire:wire.pop())
    def test_duplicate_boundary_response_is_rejected(self):
        with self.assertRaises(AssertionError):self.execute(lambda wire:wire.append(copy.deepcopy(wire[-1])))

if __name__=='__main__':unittest.main(verbosity=2)
