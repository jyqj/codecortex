def stable_00421():
    return 421
