import hashlib,json,platform,sys,traceback
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=Path('/workspace/scratch/bfccb8494ba0/candidate-ready-signal-github')
artifact_id=int(sys.argv[1]);attempt=sys.argv[2]
RAW=BASE/'raw/37902429727'/str(artifact_id)/attempt/'extracted'
OUT=BASE/('shard-validation-'+str(artifact_id));OUT.mkdir(exist_ok=False)
BUILD=BASE/'build-validation-11603522248/build-replay-input'
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'scripts'))
import p8_scale_matrix as original
def state(root):
 return {str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':oct(p.stat().st_mode&0o777)} for p in sorted(root.rglob('*')) if p.is_file()}
def put(name,data):
 with (OUT/name).open('x') as f:json.dump(data,f,indent=2,ensure_ascii=False);f.write('\n')
before=state(RAW);put('original-before.json',before)
receipt={'started_at':original.utc(),'function':'p8_scale_matrix.validate_shard','artifact_id':artifact_id,'source_root':str(ROOT),'source_G':'c8be5afaac568ffd40ef86d3795423c3b73c9f39','build_artifact_id':11603522248,'platform':platform.platform(),'python':sys.version,'new_native_workload':False,'aggregate_or_TODO_complete':False}
code=1
try:
 original.driver_snapshot(ROOT)
 record=json.loads((BUILD/'build.json').read_text());binary=BUILD/'p8-scale'
 assert original.file_sha256(binary)==record['binary_sha256']
 output=original.validate_shard(RAW,record,binary,original.file_sha256(BUILD/'build.json'))
 put('original-function-output.json',output)
 receipt.update(status='original_validate_shard_passed',scale=output['plan']['files'][0],shard_index=output['plan']['shard']['index'],global_repetitions=output['plan']['repetitions'],measurement_count=len(output['measurements']),build_receipt_sha256=original.file_sha256(BUILD/'build.json'),sample_ids=[m['sample'] for m in output['measurements']])
 code=0
except Exception as error:
 receipt.update(status='failed_retained',error=repr(error));traceback.print_exc()
after=state(RAW);put('original-after.json',after)
receipt.update(finished_at=original.utc(),original_unchanged=before==after,actual_exit=code)
if before!=after:code=1;receipt['actual_exit']=1;receipt['status']='original_invariance_failure'
put('receipt.json',receipt);print(json.dumps(receipt));sys.exit(code)
