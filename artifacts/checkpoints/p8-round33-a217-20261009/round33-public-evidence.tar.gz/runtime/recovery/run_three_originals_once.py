#!/usr/bin/env python3
"""Authorized original-artifact audit only; no workload, compile, or new samples."""
import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path("/workspace/scratch/a217aaae3bde")
BASE=ROOT/"original-LG2-runtime"
VIEW=ROOT/"p8-lock-observation-G2-recovered-1419"
HEAD="4d18dcdb34b5d7a277566b57801cc882d8b1eb61"
OUT=BASE/"accepted-after-local-recovery-20261009-1420"
HELPERS=BASE/"helpers-LG2-v1"
EXPECTED={
"review_e_runtime_original.py":"f519b9d3623307b71cd83c26434bd7aa757d169cfd9601bfddb45a190a251230",
"e_raw_cache_audit.py":"82461b5ac4424e4afb3b197f60bf8f265e1b8a33f5ef084b6681f3857f9b1694",
"preflight_e_runtime_zip.py":"575937564eba6607d8fec97c70fa9711448a38ae66eea9cf5c596df0b9324bf4",
"lg_counter_audit.py":"185fbd9a2134eb8f91ffe10963789fdd288ebcab894f8c512d1d1401278ed05e"}
ARTIFACTS=[
[4,11620977433,16993296,"67eba33ee740e923a303b6ec8c19018d6d40fd5b25f8ab7514ef56f1490e9cfc"],
[8,11621010611,16642248,"d12b7f72eee15a47691f3168342671f4d7426b76200e9ca3288fd844f33f0236"],
[1,11623110311,16608748,"6fa82bbe05ee1a35212cae00e0e861ad97d74f026dfd21a895b93020cbb895ac"]]
def hash_file(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for b in iter(lambda:f.read(1024*1024),b""):h.update(b)
 return h.hexdigest()
def info(p):
 p=Path(p);b=p.read_bytes()
 return {"path":str(p),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()}
def put(p,obj):
 with p.open("x") as f:json.dump(obj,f,indent=2,sort_keys=True);f.write("\n")
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not OUT.exists()
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=VIEW,text=True).strip()==HEAD
assert subprocess.check_output(["git","rev-parse","HEAD^{tree}"],cwd=VIEW,text=True).strip()=="383716945d2d5f2404578d726afb317e4490c181"
assert subprocess.run(["git","diff","--quiet","HEAD","--","Cargo.toml","Cargo.lock","crates","scripts"],cwd=VIEW).returncode==0
for name,digest in EXPECTED.items():assert hash_file(HELPERS/name)==digest
proof=json.loads((BASE/"source-and-observer-proof.json").read_text())
observer_files=proof["observer"]["files"]
assert len(observer_files)==10
for name,v in observer_files.items():assert hash_file(VIEW/name)==v["sha256"]
OUT.mkdir()
env=os.environ.copy();env["GIT_NO_LAZY_FETCH"]="1";env["PYTHONDONTWRITEBYTECODE"]="1"
for c,aid,size,digest in ARTIFACTS:
 art=BASE/"artifacts"/str(aid);archive=art/(str(aid)+".zip");meta=art/"artifact-metadata.json";extracted=art/"extracted"
 assert archive.stat().st_size==size and hash_file(archive)==digest and not extracted.exists()
 work=art/"offline-intake-20261009-1420";work.mkdir(exist_ok=False)
 inputs=[archive,meta]+[HELPERS/n for n in EXPECTED]+[VIEW/n for n in observer_files]
 before=[info(x) for x in inputs]
 manifest=work/"input-manifest.json";put(manifest,[[c,aid,size,digest]])
 preflight=work/"zip-preflight-and-extraction.json"
 commands=[
 ("preflight",["python3","-B",str(HELPERS/"preflight_e_runtime_zip.py"),str(archive),str(meta),str(extracted),str(preflight),"--extract"]),
 ("original-retained-verifier",["python3","-B",str(VIEW/"scripts/p8_runtime.py"),"verify","--output",str(extracted/"p8-lock-runtime"),"--build-output",str(extracted/"p8-lock-build")]),
 ("frozen-independent-audit",["python3","-B",str(HELPERS/"review_e_runtime_original.py"),str(manifest),str(BASE/"artifacts"),HEAD,str(VIEW),str(OUT)])]
 receipt={"schema":"g2-original-artifact-audit-execution-v1","artifact_id":aid,"configured_concurrency":c,"head":HEAD,"workflow_run":37930392164,"started_at":now(),"commands":[],"protected_before":before,"source_view_recovery_receipt":str(BASE/"recovery-input/source-view-recovery-execution.json"),"helper_recovery_receipt":str(BASE/"recovery-input/frozen-helper-recovery-receipt.json"),"execution_scope":"original retained verifier, Rust statistics, and 15-table oracle replay on copies; no workload or compilation","prior_execution_local_receipt_lost":aid==11621010611,"prior_execution_not_fabricated_or_overwritten":True,"formal_task_completion":False}
 try:
  for label,argv in commands:
   stdout=work/(label+".stdout.txt");stderr=work/(label+".stderr.txt")
   start=now();t=time.monotonic()
   with stdout.open("xb") as a,stderr.open("xb") as b:
    result=subprocess.run(argv,cwd=ROOT,env=env,stdout=a,stderr=b,timeout=900)
   row={"label":label,"argv":argv,"started_at":start,"finished_at":now(),"duration_seconds":time.monotonic()-t,"returncode":result.returncode,"stdout":info(stdout),"stderr":info(stderr)}
   receipt["commands"].append(row)
   assert result.returncode==0,(label,result.returncode)
  review=OUT/("artifact-"+str(aid)+"-"+HEAD[:8]+"-independent-final")/"independent-review.json"
  receipt["review"]=info(review);receipt["status"]="accepted_scoped"
 except BaseException as exc:
  receipt["status"]="audit_execution_failed";receipt["exception"]={"type":type(exc).__name__,"message":str(exc)}
  raise
 finally:
  receipt["finished_at"]=now();receipt["protected_after"]=[info(x) for x in inputs]
  receipt["protected_unchanged"]=receipt["protected_before"]==receipt["protected_after"]
  put(work/"actual-execution.json",receipt)
  assert receipt["protected_unchanged"]
 print(json.dumps({"artifact_id":aid,"status":receipt["status"],"review":receipt.get("review"),"receipt":info(work/"actual-execution.json")}),flush=True)
