def stable_00348():
    return 348
