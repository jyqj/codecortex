def stable_00107():
    return 107
