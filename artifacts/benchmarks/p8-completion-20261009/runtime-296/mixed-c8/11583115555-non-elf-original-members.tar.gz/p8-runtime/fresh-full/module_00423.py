def stable_00423():
    return 423
