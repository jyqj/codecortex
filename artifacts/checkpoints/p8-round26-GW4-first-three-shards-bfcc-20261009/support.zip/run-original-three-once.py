from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

B = Path(__file__).resolve().parent
ADAPTER = B.parent / 'GW4-original-shard-intake-preparation/intake-original-shard-once.py'
EXPECTED = 'a49a363e765c0de24a32851296a8d113fe2f1beb18160d9643f5364cd48de961'
assert hashlib.sha256(ADAPTER.read_bytes()).hexdigest() == EXPECTED
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
records = []
for scale in (1000, 5000, 10000):
    command = [sys.executable, str(ADAPTER), str(B / 'descriptors' / (str(scale) + '.json')),
               str(B / ('scale-' + str(scale) + '-attempt01'))]
    with (B / ('scale-' + str(scale) + '.outer.stdout')).open('xb') as stdout, (B / ('scale-' + str(scale) + '.outer.stderr')).open('xb') as stderr:
        result = subprocess.run(command, stdout=stdout, stderr=stderr, check=False)
    records.append({'scale': scale, 'command': command, 'exit_code': result.returncode})
    (B / 'progress.json').write_text(json.dumps(records, indent=2) + '\n')
    if result.returncode != 0:
        break
terminal = {'started_utc': started, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'wall_seconds': time.monotonic() - clock, 'commands': records,
            'exit_code': records[-1]['exit_code']}
with (B / 'terminal.json').open('x') as output:
    json.dump(terminal, output, indent=2)
    output.write('\n')
print(json.dumps(terminal))
raise SystemExit(terminal['exit_code'])
