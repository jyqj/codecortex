from pathlib import Path
import datetime
import hashlib
import json
import os
import stat
import subprocess
import sys
import time

OUT = Path('/dev/shm/p8-exact-G-checkout-preparation')
SOURCE = Path('/workspace/scratch/2eaa00d0f93a/codecortex')
TARGET = Path('/home/runner/work/codecortex/codecortex')
BUILD = Path('/workspace/scratch/2eaa00d0f93a/p8-scale-actions-37830173594/artifacts/p8-scale-build-37830173594')
G = 'bb9a96d71622458c39a143055360cc97f0d11d78'
TREE = 'bd7f0abc21650a1656783ddb26961c212aa1f2ae'
BUDGET = 50 * 1024**2
PATHS = ['Cargo.toml', 'Cargo.lock', 'crates', 'scripts', '.github/workflows']

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def write(name, data):
    with (OUT / name).open('x') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write('\n')

def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args])

def footprint():
    paths = [TARGET, *TARGET.rglob('*')] if TARGET.exists() else []
    logical = allocated = 0
    for path in paths:
        s = path.lstat()
        assert not stat.S_ISLNK(s.st_mode), str(path)
        allocated += s.st_blocks * 512
        if stat.S_ISREG(s.st_mode):
            logical += s.st_size
    return {'logical_regular_bytes': logical, 'allocated_bytes_including_directories': allocated,
            'entries': len(paths)}

commands = []
def command(label, argv, cwd):
    record = {'argv': argv, 'cwd': str(cwd), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'started_monotonic_ns': time.monotonic_ns(), 'environment_overlay': {'GIT_TERMINAL_PROMPT':'0','PYTHONDONTWRITEBYTECODE':'1'}}
    with (OUT / (label + '.stdout')).open('xb') as out, (OUT / (label + '.stderr')).open('xb') as err:
        result = subprocess.run(argv, cwd=cwd, stdout=out, stderr=err, check=False,
                                env=os.environ | record['environment_overlay'])
    record.update(exit_code=result.returncode, elapsed_ns=time.monotonic_ns()-record['started_monotonic_ns'],
                  stdout_sha256=sha(OUT/(label+'.stdout')), stderr_sha256=sha(OUT/(label+'.stderr')),
                  footprint=footprint())
    write(label+'.command.json',record)
    commands.append(record)
    assert result.returncode == 0, label
    assert max(record['footprint']['logical_regular_bytes'], record['footprint']['allocated_bytes_including_directories']) <= BUDGET

assert TARGET.is_absolute() and not TARGET.exists() and not TARGET.is_symlink()
assert not TARGET.parent.exists() and not TARGET.parent.is_symlink()
ancestors = []
for p in [TARGET.parent.parent, *TARGET.parent.parent.parents]:
    s=p.lstat()
    assert stat.S_ISDIR(s.st_mode) and not stat.S_ISLNK(s.st_mode)
    ancestors.append({'path':str(p),'inode':s.st_ino,'device':s.st_dev,'uid':s.st_uid,'gid':s.st_gid,'mode':oct(stat.S_IMODE(s.st_mode))})
assert git('rev-parse',G+'^{tree}').decode().strip() == TREE
source_head_before=git('rev-parse','HEAD').decode().strip()
expected={}
for row in git('ls-tree','-rlz',G,'--',*PATHS).split(b'\0'):
    if row:
        metadata,path=row.split(b'\t',1)
        mode,kind,oid,size=metadata.decode().split()
        assert kind=='blob' and mode in ['100644','100755']
        expected[path.decode()]={'mode':mode,'git_blob':oid,'bytes':int(size)}
assert len(expected)==1208 and sum(v['bytes'] for v in expected.values())==21502362
artifact_before={'sha256':sha(BUILD/'p8-scale'),'bytes':(BUILD/'p8-scale').stat().st_size,
                 'mode':oct(stat.S_IMODE((BUILD/'p8-scale').stat().st_mode)), 'build_receipt_sha256':sha(BUILD/'build.json')}
write('before.json',{'source_head':source_head_before,'source_commit':G,'source_tree':TREE,'ancestors':ancestors,
                     'target_absent':True,'target_parent_absent':True,'expected_files':expected,'artifact':artifact_before})
# Create exactly one absent project parent. Git clone alone creates its target.
TARGET.parent.mkdir()
s=TARGET.parent.lstat()
write('created-parent.json',{'path':str(TARGET.parent),'created_ns':time.time_ns(),'inode':s.st_ino,'uid':s.st_uid,'gid':s.st_gid,'device':s.st_dev})
command('01-clone',['git','-c','maintenance.auto=false','-c','gc.auto=0','clone','--shared','--no-checkout','--no-hardlinks',str(SOURCE),str(TARGET)],TARGET.parent)
command('02-sparse',['git','-c','maintenance.auto=false','-c','gc.auto=0','sparse-checkout','set','--no-cone','/Cargo.toml','/Cargo.lock','/crates/','/scripts/','/.github/workflows/'],TARGET)
command('03-checkout',['git','-c','maintenance.auto=false','-c','gc.auto=0','checkout','--detach',G],TARGET)
command('04-status',['git','status','--porcelain=v1','--untracked-files=all'],TARGET)
command('05-diff',['git','diff','--binary'],TARGET)
assert not (OUT/'04-status.stdout').read_bytes() and not (OUT/'05-diff.stdout').read_bytes()
head=subprocess.check_output(['git','-C',str(TARGET),'rev-parse','HEAD']).decode().strip()
tree=subprocess.check_output(['git','-C',str(TARGET),'rev-parse','HEAD^{tree}']).decode().strip()
assert (head,tree)==(G,TREE)
disk={p.relative_to(TARGET).as_posix() for p in TARGET.rglob('*') if p.is_file() and '.git' not in p.relative_to(TARGET).parts}
assert disk==set(expected)
objects=list(dict.fromkeys(row['git_blob'] for row in expected.values()))
batch=subprocess.check_output(['git','-C',str(TARGET),'cat-file','--batch'],input=('\n'.join(objects)+'\n').encode())
offset=0; blobsha={}
for oid in objects:
    end=batch.index(b'\n',offset); actual,kind,n=batch[offset:end].decode().split();assert actual==oid and kind=='blob'
    offset=end+1;n=int(n);blobsha[oid]=hashlib.sha256(batch[offset:offset+n]).hexdigest();offset+=n;assert batch[offset:offset+1]==b'\n';offset+=1
assert offset==len(batch)
inventory={}
for rel,entry in expected.items():
    path=TARGET/rel;s=path.lstat();assert stat.S_ISREG(s.st_mode)
    assert s.st_size==entry['bytes']
    assert bool(s.st_mode&stat.S_IXUSR)==(entry['mode']=='100755')
    digest=sha(path);assert digest==blobsha[entry['git_blob']]
    inventory[rel]=entry|{'sha256':digest}
write('checked-out-inventory.json',inventory)
sys.path.insert(0,str(TARGET/'scripts'))
import p8_scale_matrix as matrix
source_snapshot=matrix.source_snapshot(TARGET)
driver=matrix.driver_snapshot(TARGET)
record=matrix.read_json(BUILD/'build.json');original=matrix.read_json(BUILD/'source-before.json')
assert source_snapshot==original==matrix.read_json(BUILD/'source-after.json')
assert driver==record['driver_source'] and matrix.inventory(BUILD,('build.json',))==record['files']
matrix.validate_snapshot(source_snapshot)
messages=[matrix.decode(line) for line in (BUILD/'cargo.jsonl').read_bytes().splitlines() if line]
assert messages[-1]=={'reason':'build-finished','success':True}
matrix.verify_build_origin(record,messages)
write('source-before.json',source_snapshot);write('driver-before.json',driver)
source_after=matrix.source_snapshot(TARGET);driver_after=matrix.driver_snapshot(TARGET)
write('source-after.json',source_after);write('driver-after.json',driver_after)
assert source_after==source_snapshot and driver_after==driver
command('06-final-status',['git','status','--porcelain=v1','--untracked-files=all'],TARGET)
command('07-final-diff',['git','diff','--binary'],TARGET)
assert not (OUT/'06-final-status.stdout').read_bytes() and not (OUT/'07-final-diff.stdout').read_bytes()
assert git('rev-parse','HEAD').decode().strip()==source_head_before
artifact_after={'sha256':sha(BUILD/'p8-scale'),'bytes':(BUILD/'p8-scale').stat().st_size,
                'mode':oct(stat.S_IMODE((BUILD/'p8-scale').stat().st_mode)), 'build_receipt_sha256':sha(BUILD/'build.json')}
assert artifact_after==artifact_before
final_footprint=footprint();assert max(final_footprint['logical_regular_bytes'],final_footprint['allocated_bytes_including_directories'])<=BUDGET
report={'schema':'p8-exact-G-checkout-preparation-v1','status':'prepared_and_read_only_identity_verified_no_native_execution',
        'owner':'/root/acceptance_audit','target':str(TARGET),'created_project_parent':str(TARGET.parent),
        'source_commit':head,'source_tree':tree,'source_input_count':source_snapshot['input_count'],
        'source_manifest_sha256':source_snapshot['manifest_sha256'],'driver':driver,
        'source_snapshot_equals_original_build':True,'source_driver_before_after_equal':True,
        'all_checked_out_paths':len(inventory),'checked_out_regular_bytes':sum(v['bytes'] for v in inventory.values()),
        'all_checked_out_modes_and_blobs_match_commit':True,'no_artifacts_directory_materialized':not (TARGET/'artifacts').exists(),
        'git_status_and_diff_empty':True,'git_objects_alternate':(TARGET/'.git/objects/info/alternates').read_text().strip(),
        'original_source_head_unchanged':source_head_before,'original_artifact_before_after':artifact_after,
        'commands':commands,'footprint':final_footprint,'authorized_budget_bytes':BUDGET,
        'no_product_Cargo_or_hash_binary_executed':True,'no_original_artifact_chmod':True,
        'cleanup_ownership':'Only newly created /home/runner/work/codecortex parent and its codecortex checkout are owned by this preparation. Shared source/object directory and existing ancestors are not owned. No cleanup performed.',
        'limitations':['Actual validate_build native BLAKE3 still awaits authorized executable permission preparation and execution.',
                       'No native shard or performance sample has run. Original per-cell disk gate and preassigned-origin plan remain required.'],
        'todo_closed':0,'formal_remaining':29}
report['artifacts']={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(OUT.iterdir())if p.is_file()}
write('report.json',report)
print(json.dumps({'report':str(OUT/'report.json'),'sha256':sha(OUT/'report.json'),'target':str(TARGET),'source_commit':head,'footprint':final_footprint,'status':report['status']},indent=2))
