from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

root = Path(__file__).resolve().parent
repo = root / 'guard-view-attempt02'
out = root / 'actual-original-validation-attempt03'
out.mkdir()
expected = json.loads((root / 'actual-G-pre-admission-inputs.json').read_text())
paths = sorted(expected['selected_entries'])
env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'GIT_TERMINAL_PROMPT': '0',
       'GIT_NO_LAZY_FETCH': '1', 'GIT_OPTIONAL_LOCKS': '0'}

def meta(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}

def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo, env=env)

def snapshot():
    entries = {}
    for path in paths:
        target = repo / path
        assert target.is_file() and not target.is_symlink(), path
        raw = target.read_bytes()
        entries[path] = {**meta(raw), 'mode': oct(target.stat().st_mode & 0o777)}
        assert entries[path]['sha256'] == expected['selected_entries'][path]['sha256'], path
        assert entries[path]['git_blob'] == expected['selected_entries'][path]['git_blob'], path
        assert int(entries[path]['mode'], 8) == int(expected['selected_entries'][path]['mode'][-3:], 8), path
    head = git('rev-parse', 'HEAD').decode().strip()
    tree = git('write-tree', '--missing-ok').decode().strip()
    assert head == expected['source'] and tree == expected['source_tree']
    assert not git('diff-index', '--cached', '--name-only', head)
    index = git('ls-files', '--stage', '-z')
    return {'head': head, 'index_tree': tree, 'tracked_mode_blob_index': meta(index),
            'selected_count': len(entries), 'entries': entries,
            'scope': 'Exact required-file projection and real Git HEAD/index; not full worktree.'}

commands = [
    ('original-v15', ['python3', '-B', 'scripts/verify_reviewed_source_v15.py', '--source-version', 'p8-completion-source-20261009-v15']),
    ('original-task-plan', ['python3', '-B', 'scripts/code_index_plan.py']),
]
records = []
for name, command in commands:
    before = snapshot()
    (out / (name + '-inputs-before.json')).write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    begin = time.monotonic()
    code, error = None, None
    with (out / (name + '.stdout')).open('xb') as stdout, (out / (name + '.stderr')).open('xb') as stderr:
        try:
            code = subprocess.run(command, cwd=repo, env=env, stdout=stdout, stderr=stderr,
                                  check=False, timeout=3600).returncode
        except Exception as exc:
            error = type(exc).__name__ + ': ' + str(exc)
    finished = datetime.datetime.now(datetime.timezone.utc).isoformat()
    after, after_error = None, None
    try:
        after = snapshot()
        (out / (name + '-inputs-after.json')).write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
    except Exception as exc:
        after_error = type(exc).__name__ + ': ' + str(exc)
    receipt = {'name': name, 'command': command, 'cwd': str(repo), 'source': expected['source'],
        'started_at_utc': started, 'completed_at_utc': finished, 'wall_seconds': time.monotonic() - begin,
        'exit_code': code, 'error': error, 'after_snapshot_error': after_error,
        'inputs_unchanged': after == before, 'selected_inputs': len(paths),
        'stdout': meta((out / (name + '.stdout')).read_bytes()),
        'stderr': meta((out / (name + '.stderr')).read_bytes()),
        'environment_overrides': {k: env[k] for k in ['PYTHONDONTWRITEBYTECODE', 'GIT_TERMINAL_PROMPT', 'GIT_NO_LAZY_FETCH', 'GIT_OPTIONAL_LOCKS']},
        'scope': 'Actual unmodified selected CLI. No Rust, ignored probe, workflow, native build or scale workload.'}
    (out / (name + '-execution.json')).write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    records.append(receipt)
    (out / 'progress.json').write_text(json.dumps(records, indent=2, sort_keys=True) + '\n')
    print(json.dumps(receipt), flush=True)
    if code != 0 or error or after_error or before != after:
        break
(out / 'terminal.json').write_text(json.dumps({'records': records, 'all_planned_commands_completed': len(records) == len(commands),
    'passed': len(records) == len(commands) and all(x['exit_code'] == 0 and x['inputs_unchanged'] and not x['error'] for x in records)}, indent=2, sort_keys=True) + '\n')
raise SystemExit(0 if len(records) == len(commands) and all(x['exit_code'] == 0 and x['inputs_unchanged'] and not x['error'] for x in records) else 1)
