def stable_00122():
    return 122
