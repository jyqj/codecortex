def stable_00359():
    return 359
