# committed protocol-control fixture: scripts/p7_build_identity.py
