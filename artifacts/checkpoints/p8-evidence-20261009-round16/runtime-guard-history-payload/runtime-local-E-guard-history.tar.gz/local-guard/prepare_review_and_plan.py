#!/usr/bin/env python3
"""Append a scoped review and an unexecuted plan; never mutate repository data."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/dev/shm/a217aaae3bde/codecortex')
FROZEN = Path('/dev/shm/a217aaae3bde/codecortex-round6-frozen')
SRC = Path('/workspace/scratch/a217aaae3bde/pr161-e95-scope-review/immutable-source')
REVIEW = Path('/dev/shm/a217aaae3bde/runtime-review')
PRODUCT = '254009277688d64677361a0ca33e5dea73f295ef'
E95 = 'e95fd750d2f5052d0308c970cd5032c48b765cde'
BASE = '29682890c89511dd6f477a6bf48bd969aa1537af'

def sha(raw): return hashlib.sha256(raw).hexdigest()
def load(path): return json.loads(path.read_bytes())
def ref(path):
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path.read_bytes()))
def write(name, value):
    path = OUT / name
    path.write_text(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    return ref(path)
def gitblob(path):
    return subprocess.check_output(['git','show',BASE+':'+path],cwd=ROOT)
def functions(raw):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}

inv = load(OUT/'independent-git-inventory-review.json')
inputs = load(OUT/'independent-git-inputs.json')
paths = inv['validation_changes']
assert len(paths)==8
for p in paths:
    assert sha((SRC/p).read_bytes())==inputs['files'][p]['sha256']
api = {}
for path, names in {
    'scripts/p8_cold_build.py':['digest','json_bytes','new_directory','write_json'],
    'scripts/p8_rollback.py':['Product','require'],
}.items():
    old,new=functions(gitblob(path)),functions((SRC/path).read_bytes())
    api[path]={n:old[n]==new[n] for n in names}
    assert all(api[path].values())
controls=load(REVIEW/'cache-gap-e95/selected-controls-result.json')
assert controls['exit_code']==0 and controls['failures']==0 and controls['errors']==0
assert controls['inputs_before']==controls['inputs_after']
assert all(inputs['files'][x['path']]['sha256']==x['sha256'] for x in controls['inputs_before'])
guard = ast.parse(gitblob('scripts/verify_reviewed_source_v15.py'))
unchanged_guard_rules = {
    n.name:ast.dump(n,include_attributes=False) for n in guard.body
    if isinstance(n,ast.FunctionDef) and n.name in ['validation_path','validation_inventory']}
assert len(unchanged_guard_rules)==2
proof_refs = [
    OUT/'independent-git-inventory-review.json',OUT/'independent-git-inputs.json',
    REVIEW/'cache-gap-e95/e95-runtime-cache-finalization-independent-review.json',
    REVIEW/'cache-gap-e95/selected-controls-result.json',
    REVIEW/'cache-gap-e95/control-originals-inventory.json',
    REVIEW/'cache-gap-e95/zero-cache-original-negative-control.json',
    REVIEW/'final-ten-draft/P8-010-cache-coverage-correction-v1.json',
    Path('/dev/shm/a217aaae3bde/platform-review/P8-010-cache-correction-independent-review.json'),
    Path('/dev/shm/a217aaae3bde/scale-round5-review/e95-helper-independent-review/independent-review.json'),
]
review = {
    'schema_version':1,'reviewer':'runtime_closeout','verdict':'accepted_scoped',
    'source':PRODUCT,'source_tree':inv['source_tree'],'base':inv['parent'],
    'scope':'Eight exact e95 validation files ported into the combined candidate; complete product and validation Git input binding independently verified.',
    'compared_validation_baseline':BASE,'ported_validation_origin':E95,
    'paths':{p:inputs['files'][p] for p in paths},
    'complete_inputs':inputs['complete_inputs'],'validation_inputs':inputs['validation_inputs'],
    'product_manifest_sha256':inv['canonical_product_manifest_sha256'],
    'runtime_observers':inputs['runtime_observers'],
    'findings':[
        {'paths':['scripts/p8_runtime.py','scripts/tests/test_p8_runtime.py','scripts/tests/test_p8_runtime_cache.py','scripts/tests/test_p8_runtime_finalization.py'],
         'conclusion':'Exact cache and finalization implementation already independently examined at e95; all four bytes match the combined Git product. The original 296 zero-cache result is rejected by the new cache control. This establishes software suitability, not native combined acceptance.',
         'cache_scope':['One offered soak read contains before-status, symbol search, local hybrid top-1 search, after-status; four RPCs remain in the full request denominator.',
                        'Serial write admission isolates each read/build cache generation; admission wait remains part of original operation timing. Mixed load remains the original mixed concurrency protocol.',
                        'Actual native PID plus generation/epoch/incarnation identity and full freshness determine hit versus miss; monotone integral counter increments must account for exactly one graph and one result lookup.',
                        'Each actual-completion-time quarter requires hits, misses and invalidations; offered timestamps alone cannot satisfy coverage.',
                        'Stable fixture symbol content/span/entity is verified against actual source bytes. This does not prove every mutated entity cache lookup or semantic/live-provider reuse.'],
         'failure_scope':['All unfinished workers, sampler and owned product readers must stop before seal; cleanup failure cannot produce accepted sealed output.',
                          'Seal/verify failure produces failed exit2/unsealed state and preserves the original preseal record; backup collision and missing output remain explicit failures.',
                          'Budget-failure compact terminal metadata is intentionally not full replayable successful raw evidence; original512MiB runtime raw.jsonl budget is unchanged and is not a total ZIP/RPC-log budget.']},
        {'paths':['scripts/p8_cold_build.py','scripts/tests/test_p8_platform.py'],
         'conclusion':'Collector selection is tied to original matrix cell inventory, exact receipt digest/source and receipt-owned target. Portable v2 requires the live strict receipt/stdio replay flag and retains original strict cell replay. Collection failures/cancellation now retain machine-readable outcomes without overwrite.',
         'preserved':['Eight unique OS/toolchain/package cells','Original private target release/Cargo origin/compiler/features/profile/raw stdio checks','Portability after original compiler/target removal; no old target existence dependency','No sample, threshold, budget or requested platform reduction'],
         'new_control_scope':'Four added platform tests include consistently resealed corruptions, selection/source/owner rejection, portability, failed-collection and overwrite protection; static review here, execution at the combined source remains required.'},
        {'paths':['scripts/p8_rollback.py','scripts/tests/test_p8_recovery.py'],
         'conclusion':'Manifest validation supports both original map and cold-build row-list schemas while rejecting duplicate keys/paths, noncanonical paths, wrong cardinality/digests and mutable content; schema version parsing hashes and parses one byte snapshot.',
         'callsite_review':'The only original external manifest_hashes call was the platform test, updated in the eight-file scope. Current production callers resolve product_manifest_hashes. Product stdio launcher and shared require API remain AST-identical.',
         'new_control_scope':'Five additional tests cover the actual cold receipt producer via a synthetic compiler, both manifest formats, duplicate/cardinality failures, post-identity mutation and same-snapshot schema parsing. No native recovery claim follows from these controls.'},
    ],
    'shared_import_api_ast_equal':api,'original_test_methods_retained':inv['tests_ast'],
    'existing_controls':{'execution_source':E95,'selected_test_count':22,'failures':0,'errors':0,'input_before_after_equal':True,
                         'all_13_executed_python_inputs_match_combined_git':True,
                         'meaning':'Previously executed unchanged software controls, retained under original e95 identity; not rerun or relabeled as combined native workload.'},
    'proofs':[ref(p) for p in proof_refs],
    'not_reviewed_here':['Semantic correctness of six changed Rust product files; other independent reviewers own this scope.',
                         'Final product/review/registry/CI-selector pins and complete v15 historical proof execution.',
                         'Any actual build, native benchmark, platform, recovery, gates or new-source full matrix execution.'],
    'unresolved_blockers':[],'formal_task_completion':False,'status_action':'no_change','done':163,'remaining':29,
}
review_ref = write('eight-validation-files-independent-review.json',review)

workflows={}
for name in ['p8-runtime.yml','p8-lifecycle.yml','p8-platform.yml','p8-gates.yml','p8-scale.yml','p7-engineering.yml','p7-closeout.yml']:
    path='.github/workflows/'+name
    assert sha((FROZEN/path).read_bytes())==inputs['files'][path]['sha256']
    workflows[path]=inputs['files'][path]
original=load(REVIEW/'final-ten-draft/original-task-snapshot.json')
groups=[
 {'id':'runtime_mixed','tasks':['P8-007'],'workflow':'p8-runtime.yml','job':'mixed','status':'not_run_for_combined_source',
  'fixed_dimensions':{'concurrency':[1,4,8,16],'operations_per_cell':900,'files':1000,'interval_ms':500,'job_timeout_minutes':90},
  'commands':['python3 -m unittest discover -s scripts/tests -p test_p8_runtime*.py -v','python3 scripts/p8_runtime_build.py --output "$RUNNER_TEMP/p8-build"',
   'python3 scripts/p8_runtime.py --binary "$RUNNER_TEMP/p8-build/codecortex" --oracle "$RUNNER_TEMP/p8-build/p8-oracle" --statistics "$RUNNER_TEMP/p8-build/p8-runtime-statistics" --build-receipt "$RUNNER_TEMP/p8-build/build-receipt.json" --concurrency C --operations 900 --files 1000 --interval-ms 500 --output "$RUNNER_TEMP/p8-runtime"',
   'python3 scripts/p8_runtime.py verify --output "$RUNNER_TEMP/p8-runtime" --build-output "$RUNNER_TEMP/p8-build"'],
  'acceptance':['Four distinct fresh source-bound release builds and complete original offered/completed request denominators.',
   'Actual C>1 read/build overlap and original queue/accounting/latency controls; configured concurrency is not measured peak concurrency.',
   'Original resource observations, endpoint recovery, no-repair complete15table oracle parity and independently executed retained Rust statistics.',
   'Original native cleanup, immutable complete build/runtime seals, exact9observer and before/after source/toolchain/binary identity.']},
 {'id':'runtime_soak','tasks':['P8-010'],'workflow':'p8-runtime.yml','job':'soak','status':'not_run_for_combined_source',
  'fixed_dimensions':{'concurrency':4,'operations':3601,'files':1000,'interval_ms':1000,'minimum_actual_and_offered_seconds':3600,'runtime_raw_budget_bytes':536870912,'job_timeout_minutes':180},
  'commands':['python3 scripts/p8_runtime_build.py --output "$RUNNER_TEMP/p8-build"',
   'python3 scripts/p8_runtime.py --binary "$RUNNER_TEMP/p8-build/codecortex" --oracle "$RUNNER_TEMP/p8-build/p8-oracle" --statistics "$RUNNER_TEMP/p8-build/p8-runtime-statistics" --build-receipt "$RUNNER_TEMP/p8-build/build-receipt.json" --profile soak --concurrency 4 --operations 3601 --files 1000 --interval-ms 1000 --output "$RUNNER_TEMP/p8-runtime"',
   'python3 scripts/p8_runtime.py verify --output "$RUNNER_TEMP/p8-runtime" --build-output "$RUNNER_TEMP/p8-build"'],
  'acceptance':['Measure actual raw elapsed/offered spans; GitHub step start is progress only. All3601 outcomes,2400 reads,1201 builds and every compound RPC remain accounted.',
   '2400 four-RPC compound reads; before/symbol/hybrid-local/after actual raw order and all counter/generation/freshness predicates; no resource-only zero probes substituted.',
   'Hits, misses and project-generation invalidations in every actual-completion quarter; stable source witness remains exact.',
   'Original edit/delete/branch/catalog compaction/worker progress coverage, bounded queue and full resource/RSS sampling/growth checks.',
   'Complete15table no-repair endpoint parity, actual original Rust statistics replay, successful lifecycle cleanup, complete immutable seals.',
   'Serial cache isolation is reported as such; do not claim C4 simultaneous cache probing or semantic/live-provider reuse.']},
 {'id':'runtime_backfill','tasks':['P8-007','P8-010'],'workflow':'p8-runtime.yml','job':'fake_backfill','status':'not_run_for_combined_source',
  'fixed_dimensions':{'seeds':[7,19,43],'modes':['quiet','held'],'concurrency':[1,4,8,16],'requests_per_cell':32,'total_requests':768,'worker_width':4,'query_deadline_seconds':2,'progress_deadline_seconds':5,'writer_deadline_ms':100,'job_timeout_minutes':90},
  'commands':['python3 -m unittest discover -s scripts/tests -p test_p8_backfill.py -v','python3 scripts/p8_backfill.py --output "$RUNNER_TEMP/p8-backfill"','python3 scripts/p8_backfill.py verify --output "$RUNNER_TEMP/p8-backfill"'],
  'acceptance':['Original real_slow_backfill_preserves_local_progress_and_records_every_request actual test executes, no ignored/skipped substitute.',
   'Fresh private release test artifact with exact features[semantic] and --no-default-features; complete source/observer/build/raw seals.',
   'All768 outcomes and original per-cell success, bounded progress and terminal worker state; fake provider remains explicit, no paid/liveprovider claim.']},
 {'id':'lifecycle_resources','tasks':['P8-008','P8-009'],'workflow':'p8-lifecycle.yml','job':'lifecycle','status':'not_run_for_combined_source',
  'fixed_dimensions':{'cold_samples':30,'process_reopen_samples':400,'warm_uncached_samples':400,'cache_hit_samples':400,'files':32,'run_timeout_seconds':3600,'artifact_budget_bytes':536870912,'job_timeout_minutes':40},
  'commands':['python3 scripts/p7_stdio_build_receipt.py --package-kind default --offline --release --output-dir "$RUNNER_TEMP/p8-lifecycle/product"',
   'cargo build --offline --locked --release -p cc-eval --bin p8-measurements --target-dir "$RUNNER_TEMP/p8-lifecycle/product/cargo-target" --message-format=json-render-diagnostics',
   'python3 scripts/p8_lifecycle.py --binary "$RUNNER_TEMP/p8-lifecycle/product/codecortex" --build-receipt "$RUNNER_TEMP/p8-lifecycle/product/build-receipt.json" --evaluator "$RUNNER_TEMP/p8-lifecycle/p8-measurements" --evaluator-build-receipt "$RUNNER_TEMP/p8-lifecycle/replay-build-receipt.json" --profile release --cold-samples 30 --query-samples 400 --files 32 --run-timeout-seconds 3600 --artifact-budget-bytes 536870912 --output-dir "$RUNNER_TEMP/p8-lifecycle/measurement"',
   'python3 scripts/p8_lifecycle.py verify --output-dir "$RUNNER_TEMP/p8-lifecycle/measurement"'],
  'acceptance':['Original product and evaluator raw Cargo events, exact flags/profile/origin/private target/copy binary, workflow-generated replay receipt, actual combined source before/after.',
   'All30+3x400 original strata, native PID/generation/cache witnesses and complete denominator; actual Rust normalizer/replay against real fixed source, equivalent output.',
   'Actual runner/server/tree/external roles, RSS current vs lifetime peak, CPU/IO, disk device+inode dedup and SQLiteFTS/WAL/SHM records.',
   'Optional unavailable process tree, limited observation windows and billing/token null remain unknown rather than zero or whole-machine peak claims.']},
 {'id':'recovery_rollback','tasks':['P8-011','P8-016'],'workflow':'p8-platform.yml','job':'recovery','status':'not_run_for_combined_source',
  'fixed_dimensions':{'packages':['default','semantic','semantic-http'],'active_seeds':[223,227,229],'original_production_fault_tests':7,'previous_commit':'277f2490fad3fa30f2812b5547bad033867c9ea5','jobs':2,'job_timeout_minutes':45},
  'commands':['python3 -m unittest discover -s scripts/tests -p test_p8_recovery.py -v',
   'python3 scripts/p8_recovery.py --full-matrix --expected-commit "$EXACT_SOURCE" --previous-source-root "$GITHUB_WORKSPACE/p8-previous-source" --previous-commit 277f2490fad3fa30f2812b5547bad033867c9ea5 --jobs 2 --output-dir "$RUNNER_TEMP/p8-full-recovery"'],
  'acceptance':['Original local kill/restart,SQLitebusy,deleted-source cases against bound actual product.',
   'Three active loopback HTTP seeds cover disconnect/recover,semantic-cache corruption,rejected unknown cache format and concurrent database replacement, with original source/native receipts and every raw response.',
   'Seven original nonignored production-linked persistence/cache isolation/crash and writer-lock tests retain exact built executables/argv/Cargo origins and actual results.',
   'Default/semantic bounded database+config+package rollback and actual fixed historical version pair current->old schema24->current->original backup; original source/config hashes unchanged.',
   'Disable semantic then local search available; do not claim live-provider failover, actual paidcost=0, released-package rollback or arbitrary device powerloss.',
   'Old local unknown-format not_run remains literal history; closure comes from actual active cases and original artifact_cache tests, not relabeling it.']},
 {'id':'platform','tasks':['P8-012','P8-016'],'workflow':'p8-platform.yml','job':'cold-build plus complete-matrix','status':'not_run_for_combined_source',
  'fixed_dimensions':{'platform':['linux','macos'],'toolchain':['1.95','stable'],'package':['default','semantic'],'cells':8,'profile':'release','jobs':2,'build_timeout_seconds':1800,'cell_job_timeout_minutes':45,'collector_job_timeout_minutes':10},
  'commands':['python3 -m unittest discover -s scripts/tests -p test_p8_platform*.py -v',
   'python3 scripts/p8_cold_build.py --execute --stdio-smoke --only-toolchain TOOLCHAIN --only-package PACKAGE --profile release --jobs 2 --timeout-seconds 1800 --output-dir "$RUNNER_TEMP/p8-platform/cold"',
   'python3 scripts/p8_cold_build.py --export-selected "$RUNNER_TEMP/p8-platform/cold/matrix.json" --only-platform PLATFORM --only-toolchain TOOLCHAIN --only-package PACKAGE --output-dir "$RUNNER_TEMP/p8-platform/bundle"',
   'python3 scripts/p8_cold_build.py --collect-cells "$RUNNER_TEMP/p8-platform-cells" --expected-commit "$EXACT_SOURCE" --output-dir "$RUNNER_TEMP/p8-platform-complete"'],
  'acceptance':['All8 distinct actual host/toolchain/package release cold builds and native stdio; fresh owned target means compiler artifact cold, not OS cache cold.',
   'Single-cell original CLI exit2 due other7 not_run is accepted only with strict successful source/compiler/binary/rawRPC/EOF selection+export; never treat one host as whole matrix.',
   'Strict portable v2 including live receipt replay flag, original full matrix selected inventory/receipt SHA/owned target/new collector contract; raw export original bytes and both16 artifacts retained.',
   'Final actual exact-source collector8 passed/0failed/0not_run; original collector log/receipt separately accepted.',
   'Stable toolchain actual observed version retained, not silently assumed; two package release configuration builds are not publication certification.']},
 {'id':'failure_gates','tasks':['P8-013'],'workflow':'p8-gates.yml','job':'gate_controls','status':'not_run_for_combined_source',
  'fixed_dimensions':{'original_nonignored_tests':6,'job_timeout_minutes':40},
  'commands':['python3 scripts/p8_gate_controls.py --output "$RUNNER_TEMP/p8-gates" --target "$RUNNER_TEMP/p8-gates-target"'],
  'acceptance':['All6 original production-linked benchmark_cli tests and retained built CLI/original fixtures; distinguish library assertions from actual CLI processes.',
   'Independent actual retained CLI replays: quality/latency failed exit1; insufficient or zero latency denominator inconclusive exit1; raw-lock drift/badpolicy invalid_measurement exit2.',
   'Zero plan invalid and output overwrite refusal preserve original raw bytes; no reports silently replaced.',
   'Deterministic control success does not establish measured quality, benchmark performance or release approval.']},
 {'id':'scale_full','tasks':['P8-005','P8-006'],'workflow':'p8-scale.yml','job':'complete original scale study and aggregate','status':'not_run_for_combined_source',
  'fixed_dimensions':{'shards':150,'groups':50,'samples_per_group':30,'total_samples':1500,'native_timeout_hours':5,'native_raw_budget_MiB':512,'registered':[200,1024],'fanout':[8,128],'oracle_canonical_GiB':16,'oracle_scratch_GiB':8,'oracle_rows':5000000,'oracle_cache_MiB':2},
  'commands':['Use the unchanged original p8-scale.yml build, all150 shard commands, original combine and final CI aggregate at the final execution HEAD; do not invent a reduced invocation.'],
  'acceptance':['All5 scales×3reps? No: preserve the exact original registered150-shard schedule and50 groups×30 total1500 observations; this plan does not redefine the workflow schedule.',
   'Every stage original15 canonical tables plus integrity/FK, config SQL target and fanout handwritten facts, no truncated or repaired incremental database.',
   'Original IndexReport per-build files_*,dirty_plan,document_changes,project_model counters plus phase timings.',
   'Old599 four accepted shards/41 samples and deadline-exceeded100k are historical only, zero combined credits; original final combine and CIaggregate required.',
   'Heterogeneous host/CPU/kernel strata remain explicit, no pooled causal speedup or each-stratum N30 claim; vectors disabled/null, post-buildRSS not peak.',
   'Measurement coverage only: G8/release certification remains not_evaluated/not_run unless separately actually established.']},
]
# Do not leave an invented schedule even as a negated draft sentence.
groups[-1]['acceptance'][0]='Preserve the exact original registered150-shard schedule and50 groups×30 total1500 observations; this plan does not redefine the workflow schedule.'
plan={
 'schema_version':1,'source':PRODUCT,'source_tree':inv['source_tree'],'base':inv['parent'],
 'source_review':review_ref,'product_manifest_sha256':inv['canonical_product_manifest_sha256'],
 'complete_product_input_count':1087,'validation_input_count':138,'runtime_observer_count':9,
 'execution_head':None,'execution_runs':{},'meaning':'Prospective original-protocol acceptance plan; final execution HEAD must include approved product/review/registry pins and be fixed before native execution.',
 'workflow_git_bindings':workflows,'workflow_commands_are_templates':True,
 'workflow_template_rule':'The original bound workflow is authoritative for shell quoting, preparation, receipt construction, environment, upload-always behavior and matrix substitution. Commands here are navigational templates, not independently issued runs.',
 'groups':groups,
 'before_execution':[
  'Independently review six changed Rust files and all exact validation bytes; bind full new1087/138 manifests and new canonical manifest4e0aa6… to fixed product2540092.',
  'Create immutable source review and regenerate only allowed v15 pins/registry/CI selector as applicable; execute the complete original historical approval chain and original controls without bypass.',
  'Freeze final execution HEAD/tree/run IDs and actual source_snapshot/observer_snapshot from that checkout. Product2540092 is not automatically the final execution HEAD.',
  'Revalidate final execution product/validation bytes equal approved product; differences restricted to approved review/pins/evidence scope. Complete new-source native builds still required.',
  'Fork a separately versioned raw helper from frozen e95 helpers; never mutate historical helpers or merely rename their approval. Bind exact new HEAD/run/manifest/9observer bytes and actual new oracle/statistics binaries.',
  'Retain all strict old assertions except documented schema/source pin replacements, with independent review and meaningful wrong-head/missing-or-replaced observer/failed-seal/cache-counter controls.',
  'Run source-bound original controls and normal required CI/P7 engineering, mechanism/offline semantic and fault/lifecycle suites; preserve ignored scope and all failed/cancelled results.'
 ],
 'artifact_acceptance':[
  'Official artifact metadata must independently match exact head/run/artifact ID/name/size/SHA before and after native materialization; never signed-URL shortcuts or old-source renaming.',
  'Stream ZIP path/type/duplicate safety inventory and actual expanded/copy size; compare actual free space before any one owned derived extraction. Original ZIP and metadata immutable.',
  'Compare receipts to actual final Git blobs, full1087 product and exact observer set/source commit; source count alone is insufficient.',
  'Check complete original sealed inventory before accepting report status; CLI, Cargo, native process and verify exits independently retained. Failed finalization is not sealed success.',
  'Run retained original Rust statistics/measurement normalizers and complete no-repair parity on copies; bind exact compiler/source/binary provenance and retain replay outputs.',
  'Use original raw full denominators, actual completion times and all terminal states. No selected successful subset or increased budget.',
  'Keep failed/original ZIPs. Any delivery reduction excludes only receipt-bound actual native binaries, preserves all other raw bytes and exact member partition hashes, and is labelled a derived record bundle rather than the full original ZIP.'
 ],
 'historical_evidence_policy':{
  'old_599':'Accepted native scopes and failed100k remain at599; no product-identical applicability bridge to new sharedDB product.',
  'old_296':'Original6runtime seals,1h/RSS/parity and other original facts remain valid at296, but010 cache scope was missing and explicitly corrected.',
  'old_e95':'Queued existing run37859755918 may be reviewed as e95 only; its observer fix does not establish new combined native acceptance.',
  'software_controls':'Exact unchanged Python byte controls may be cited under their original identity as software-review evidence, not as fresh product execution.',
  'new_source_native_sample_credit':0
 },
 'original_task_snapshot':ref(REVIEW/'final-ten-draft/original-task-snapshot.json'),
 'task_mapping':[{'id':f'P8-{i:03d}','groups':[g['id'] for g in groups if f'P8-{i:03d}' in g['tasks']], 'status_action':'no_change'} for i in list(range(5,14))+[16]],
 'ledger_constraints':['Original192 definitions unchanged; P8-005 historical acceptance_subgates including every open field remain immutable history.',
                       'Only after all original own-scope criteria and dependencies actually accepted may the parent append evidence/implementation_notes and change status with required derived views.',
                       'No future native result, full matrix completion, combined CI or final merge is prefilled as successful.'],
 'not_run_here':['native benchmarks','Rust compilation','new hour','new scale study','complete v15 CLI','combined CI'],
 'formal_task_completion':False,'status_action':'no_change','done':163,'remaining':29,
}
plan_ref=write('combined-original-protocol-acceptance-plan.json',plan)
readme='''组合候选2540092：八脚本审查与原协议新执行计划

当前163完成/29剩余；本目录不修改账本、源码、index或refs，也不声明任何新native通过。

1. independent-git-inventory-review.json / independent-git-inputs.json：独立从官方完整Git树重算树OID、逐blob字节核对。1087产品+138验证，新产品manifest4e0aa6bbfd4d5bea00416bca2cd99318d865ffc526fdcb45897c4d300de3ac00。不是完整候选checkout或v15通过声明。
2. eight-validation-files-independent-review.json：八个e95脚本原字节移植的限定接受。新缓存探针、终态封存、portable-v2 collector和rollback同字节快照均在范围。六个Rust产品文件语义由其他独审负责。
3. combined-original-protocol-acceptance-plan.json：最终execution HEAD及run尚未指定。新源必须实际完成runtime四C+真实1h+768 backfill、生命周期30+3×400、完整recovery/rollback、平台8格+collector、原6失败控制，以及规模150片/1500样本/原combine；所有原标准、重复数、时间/存储预算不变。

共享DB产品已经改变，所以旧599/296/e95成功原件只能保留原身份。e95冻结helper及独审不会更名成新候选；最终HEAD固定后另版本绑定新Git/9observer/新native binaries并做窄审。旧296真实一小时/RSS/parity/seal事实保留，cache缺口更正不可撤回。

原workflow Git blob是精确命令和环境的权威来源；JSON中的CLI仅导航模板，并未执行。
'''
(OUT/'README.txt').write_text(readme)
manifest=write('handoff-manifest.json',{'source':PRODUCT,'scope':'read_only_inventory_and_eight_validation_review_plus_unexecuted_original_protocol_plan','files':[ref(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='handoff-manifest.json'],'formal_task_completion':False,'done':163,'remaining':29})
print(json.dumps({'review':review_ref,'plan':plan_ref,'manifest':manifest},ensure_ascii=False,indent=2))
