"""Synthetic transport controls only: no product process or measurement runs."""
import copy
import hashlib
import json
from pathlib import Path
import stat
import tempfile
import types
import unittest
from unittest import mock
import warnings
import zipfile

import receive

REPLAY = Path('/workspace/scratch/2eaa00d0f93a/p8-D0-exact-source')
matrix, IDENTITIES, OBSERVER = receive.load_driver(REPLAY)
fixture = types.ModuleType('original_scale_contract_fixtures')
fixture.__file__ = str(REPLAY / 'scripts/tests/test_p8_scale_matrix.py')
FIXTURE_SOURCE = receive.git(REPLAY, 'show', receive.SOURCE + ':scripts/tests/test_p8_scale_matrix.py')
exec(compile(FIXTURE_SOURCE, fixture.__file__, 'exec'), fixture.__dict__)


def archive(path, members):
    with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED) as target:
        for name, contents in members:
            target.writestr(name, contents)
    return {'size_in_bytes': path.stat().st_size, 'digest': 'sha256:' + receive.digest(path)}


class ZipControls(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='p8-receiver-contract-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.zip = self.root / 'original.zip'
        self.expected = archive(self.zip, [('native/raw.jsonl', b'{"all":"original rows"}\n'),
                                           ('source-before.json', b'{}'), ('empty/', b'')])
        self.members = receive.zip_members(self.zip, self.expected)
        self.owner = receive.Expansions(self.root)

    def test_all_members_reclaimed_only_after_original_zip_equality(self):
        expanded = self.owner.extract('p8-scale-shard-contract', self.zip, self.expected, self.members)
        self.owner.reclaim(expanded, self.zip, self.expected, self.members)
        self.assertFalse(expanded.exists())
        self.assertTrue(self.zip.is_file())
        self.assertEqual(receive.zip_members(self.zip, self.expected), self.members)

    def test_modified_expansion_and_extra_directory_block_reclamation(self):
        expanded = self.owner.extract('p8-scale-shard-contract', self.zip, self.expected, self.members)
        raw = expanded / 'native/raw.jsonl'
        original = raw.read_bytes()
        raw.write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError, 'expanded files'):
            self.owner.reclaim(expanded, self.zip, self.expected, self.members)
        raw.write_bytes(original)
        (expanded / 'unlisted').mkdir()
        with self.assertRaisesRegex(ValueError, 'expanded directories'):
            self.owner.reclaim(expanded, self.zip, self.expected, self.members)
        self.assertTrue(expanded.is_dir())

    def test_modified_zip_blocks_reclamation_even_when_expansion_is_unchanged(self):
        expanded = self.owner.extract('p8-scale-shard-contract', self.zip, self.expected, self.members)
        with self.zip.open('ab') as out:
            out.write(b'changed')
        with self.assertRaisesRegex(ValueError, 'ZIP bytes/digest'):
            self.owner.reclaim(expanded, self.zip, self.expected, self.members)
        self.assertTrue(expanded.exists())

    def test_unowned_directory_is_never_reclaimed(self):
        other = self.root / 'foreign'
        other.mkdir()
        (other / 'keep').write_text('keep')
        with self.assertRaisesRegex(ValueError, 'not created'):
            self.owner.reclaim(other, self.zip, self.expected, self.members)
        self.assertEqual((other / 'keep').read_text(), 'keep')

    def test_zip_path_symlink_and_duplicate_members_fail_closed(self):
        for name in ('../escape', '/absolute', './alias', 'x\\escape'):
            with self.subTest(name=name):
                expected = archive(self.zip, [(name, b'x')])
                with self.assertRaises(ValueError):
                    receive.zip_members(self.zip, expected)
        symlink = zipfile.ZipInfo('link')
        symlink.create_system = 3
        symlink.external_attr = (stat.S_IFLNK | 0o777) << 16
        expected = archive(self.zip, [(symlink, b'/foreign')])
        with self.assertRaisesRegex(ValueError, 'nonregular'):
            receive.zip_members(self.zip, expected)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            expected = archive(self.zip, [('same', b'1'), ('same', b'2')])
        with self.assertRaisesRegex(ValueError, 'duplicate'):
            receive.zip_members(self.zip, expected)

    def test_free_space_refusal_does_not_create_partial_expansion(self):
        with mock.patch.object(receive.shutil, 'disk_usage', return_value=types.SimpleNamespace(free=0)):
            with self.assertRaisesRegex(ValueError, 'insufficient space'):
                self.owner.extract('p8-scale-shard-contract', self.zip, self.expected, self.members)
        self.assertEqual(list(self.owner.root.iterdir()), [])


class PopulationControls(unittest.TestCase):
    def test_all_302_inputs_required_optional_matrix_preserved_and_foreign_source_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            artifacts = []
            for number, name in enumerate(sorted(receive.expected_names()), 1):
                path = root / (name + '.zip')
                path.write_bytes(b'contract metadata only')
                artifacts.append(dict(id=number, name=name, size_in_bytes=path.stat().st_size,
                    digest='sha256:' + receive.digest(path), expired=False,
                    workflow_run=dict(id=receive.RUN, head_sha=receive.CONTROLLER), archive_path=path.name))
            inventory = dict(schema='p8-fixed-D0-scale-download-set-v1', run_id=receive.RUN, run_attempt=1,
                             source_commit=receive.SOURCE, controller_commit=receive.CONTROLLER,
                             registration_sha256=receive.REGISTRATION_SHA256, artifacts=artifacts)
            self.assertEqual(len(receive.artifact_set(inventory, root)), 303)
            missing = copy.deepcopy(inventory)
            missing['artifacts'] = [a for a in missing['artifacts'] if not a['name'].startswith('p8-scale-matrix-')]
            self.assertEqual(len(receive.artifact_set(missing, root)), 302)
            missing['artifacts'].pop()
            with self.assertRaisesRegex(ValueError, '302'):
                receive.artifact_set(missing, root)
            wrong = copy.deepcopy(inventory)
            wrong['artifacts'][0]['workflow_run']['head_sha'] = 'f' * 40
            with self.assertRaisesRegex(ValueError, 'another source'):
                receive.artifact_set(wrong, root)

    def test_original_complete_population_retains_1500_and_every_environment(self):
        shards = fixture.complete_shards(matrix.CAPACITY_PROFILE)
        result = matrix.combine(shards, repetitions=30, shard_count=30, capacity_profile=matrix.CAPACITY_PROFILE)
        self.assertEqual(result['sample_count'], 1500)
        self.assertEqual(len(result['groups']), 50)
        self.assertTrue(all(group['n'] == 30 for group in result['groups']))
        self.assertTrue(all('engine_ms' not in group for group in result['groups']))
        for bad in (shards[:-1], shards + [shards[0]]):
            with self.assertRaises(ValueError):
                matrix.combine(bad, repetitions=30, shard_count=30, capacity_profile=matrix.CAPACITY_PROFILE)
        changed = copy.deepcopy(shards)
        changed[1]['engine']['binary_digest'] = 'f' * 64
        with self.assertRaisesRegex(ValueError, 'source/binary'):
            matrix.combine(changed, repetitions=30, shard_count=30, capacity_profile=matrix.CAPACITY_PROFILE)

    def test_remote_comparison_excludes_only_actual_expansion_paths(self):
        left = {'passed': True, 'evidence': [{'directory': '/old', 'receipt_sha256': 'a'}], 'groups': [1]}
        right = copy.deepcopy(left)
        right['evidence'][0]['directory'] = '/new'
        self.assertEqual(receive.comparable_matrix(left), receive.comparable_matrix(right))
        right['groups'] = [2]
        self.assertNotEqual(receive.comparable_matrix(left), receive.comparable_matrix(right))


class OriginalShardControls(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='p8-receiver-original-contract-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.directory = self.root / 'synthetic-shard'
        self.native = self.directory / 'native'
        self.native.mkdir(parents=True)
        self.plan, self.events = fixture.raw_fixture(capacity_profile=matrix.CAPACITY_PROFILE)
        self.events[0]['engine']['engine_head_observed'] = receive.SOURCE
        inputs = {path: 'a' * 64 for path in ('Cargo.toml', 'Cargo.lock', 'crates/cc-eval/Cargo.toml',
            'crates/cc-eval/src/bin/p8-scale.rs', 'crates/cc-eval/src/benchmark/p8_scale.rs',
            'crates/cc-eval/src/benchmark/oracle.rs', 'crates/cc-eval/src/benchmark/oracle/streaming.rs')}
        snapshot = dict(inputs=inputs, input_count=len(inputs), source_commit=receive.SOURCE,
                        source_tree='f' * 40, manifest_sha256=hashlib.sha256(matrix.json_bytes(inputs)).hexdigest())
        self.built = dict(source_commit=receive.SOURCE, source_manifest_sha256=snapshot['manifest_sha256'],
                          binary_sha256='b' * 64, binary_blake3='c' * 64, driver_source={'contract': True})
        for when in ('before', 'after'):
            matrix.write_new(self.directory / f'source-{when}.json', snapshot)
        matrix.write_new(self.directory / 'registered-plan.json', self.plan)
        matrix.write_new(self.native / 'plan.json', self.plan)
        (self.native / 'worker.stderr').write_bytes(b'')
        matrix.write_new(self.directory / 'disk-preflight.json', dict(schema='p8-scale-disk-preflight-v1',
            passed=True, required_free_bytes=1000 * 256 * 1024 + 4 * 1024**3, available_bytes=10 * 1024**3,
            temporary_root='/CONTRACT_FAKE'))
        self.record = dict(schema=matrix.SCHEMA, kind='shard', status='passed', exit_code=0,
            build_receipt_sha256='d' * 64, plan=self.plan, capacity_contract=matrix.capacity_contract(),
            temporary_environment={key: '/CONTRACT_FAKE' for key in ('TMPDIR', 'TMP', 'TEMP')},
            environment=dict(host='CONTRACT_FAKE', cpu_model='CONTRACT_FAKE'), **self.built)

    def seal(self):
        raw = self.native / 'raw.jsonl'
        raw.write_text(''.join(json.dumps(event) + '\n' for event in self.events))
        groups = [f'scale-1000/{stage}' for stage in ('cold', 'no_op', 'body', 'api', 'config', 'batch_1', 'batch_10', 'batch_100', 'batch_1000')]
        groups.extend(f'fanout-{n}' for n in matrix.FANOUTS)
        summary = dict(passed=True, shard_only=True, sample_count=14, raw_bytes=raw.stat().st_size,
            executed_repetition_range=dict(start=0, end=1), release_certification='not_run',
            full_100k_certification='not_run', groups=[dict(group=group, samples=1, passed=1, failed_or_not_compared=0) for group in groups])
        report = dict(profile='release', max_output_bytes=self.plan['max_output_bytes'], exit_code=0,
            worker_exit_code=0, status='measurement_complete', stderr_complete=True, fixture_cleanup={'error': None},
            worker_binary_unchanged=True, worker_binary_digest_before='c'*64, worker_binary_digest_after='c'*64,
            plan_digest='c'*64, raw_digest='c'*64, summary=summary, registered_repetitions=30, **{key:summary[key] for key in
            ('shard_only','executed_repetition_range','release_certification','full_100k_certification')})
        for path, value in ((self.native/'worker-summary.json',summary),(self.native/'report.json',report)):
            path.write_text(json.dumps(value))
        self.record['files'] = matrix.inventory(self.directory, ('shard.json',))
        (self.directory/'shard.json').write_text(json.dumps(self.record))

    def validate(self, directory):
        # Only hash invocation is mocked: fixture bytes are not executable.
        # Original validate_shard, inspect_raw and all admission logic execute.
        with mock.patch.object(matrix, 'native_digest', return_value='c'*64):
            return matrix.validate_shard(directory, self.built, self.root/'CONTRACT_FAKE_BINARY', 'd'*64)

    def test_original_full_shard_replay_then_reclamation_retains_all_measurements(self):
        self.seal()
        zipped = self.root/'original.zip'
        expected = archive(zipped, [(p.relative_to(self.directory).as_posix(),p.read_bytes())
                                   for p in self.directory.rglob('*') if p.is_file()])
        members = receive.zip_members(zipped, expected)
        owner = receive.Expansions(self.root)
        expanded = owner.extract('p8-scale-shard-contract', zipped, expected, members)
        value = self.validate(expanded)
        self.assertEqual(len(value['measurements']), 14)
        self.assertEqual(value['engine']['engine_head_observed'], receive.SOURCE)
        owner.reclaim(expanded, zipped, expected, members)
        self.assertEqual(len(value['measurements']), 14)
        self.assertTrue(zipped.exists())

    def test_resealed_raw_missing_table_still_fails_original_validator(self):
        next(event for event in self.events if event['event']=='cold_parity')['parity']['tables'].pop()
        self.seal()
        with self.assertRaises(ValueError):
            self.validate(self.directory)


class CapacityControls(unittest.TestCase):
    def test_original_capacity_receipt_retained_and_source_free_space_checked(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            context = dict(GITHUB_REPOSITORY='jyqj/codecortex', GITHUB_RUN_ID=str(receive.RUN),
                GITHUB_RUN_ATTEMPT='1', GITHUB_JOB='measure', RUNNER_OS='Linux', RUNNER_ENVIRONMENT='github-hosted',
                ImageOS='ubuntu24', P8_EXPECTED_SOURCE=receive.SOURCE, RUNNER_NAME='CONTRACT_FAKE', ImageVersion='CONTRACT_FAKE')
            need = 1000*256*1024+4*1024**3
            receipt = dict(profile=matrix.CAPACITY_PROFILE, scale=1000, status='capacity_available', exit_code=0,
                artifact_state='sealed_after_commands_finished', source_commit=receive.SOURCE, observer_sha256=OBSERVER,
                files={}, context=context, required_free_bytes=need, allow_preparation=True, steps=[],
                initial=dict(total_bytes=need*2, used_bytes=0, free_bytes=need*2),
                final=dict(total_bytes=need*2, used_bytes=0, free_bytes=need*2))
            def check():
                (root/'receipt.json').write_text(json.dumps(receipt))
                return receive.capacity_review(root, 1000, OBSERVER, matrix)
            self.assertEqual(check()['status'], 'passed')
            receipt['final']['free_bytes']=need-1
            with self.assertRaisesRegex(ValueError, 'capacity unavailable'):
                check()
            receipt['final']['free_bytes']=need
            receipt['context']['GITHUB_RUN_ID']='37824742267'
            with self.assertRaisesRegex(ValueError, 'context mismatch'):
                check()


class ControllerControls(unittest.TestCase):
    def test_full_transport_population_uses_original_combine_despite_missing_remote_infra_result(self):
        """Orchestration fixture; native build/shard and study admission stubs are explicit.

        Original shard admission/raw is exercised separately above. This test
        exercises 302 real tiny ZIPs, 150 capacity receipts and original combine.
        """
        with tempfile.TemporaryDirectory(prefix='p8-receiver-controller-contract-') as temporary:
            root = Path(temporary)
            archives = root/'archives'
            archives.mkdir()
            artifacts = []
            names = receive.expected_names() - {f'p8-scale-matrix-{receive.RUN}'}
            for number, name in enumerate(sorted(names), 1):
                if name.startswith('p8-scale-capacity-'):
                    scale = int(name.split('-')[3])
                    need = scale*256*1024+4*1024**3
                    receipt = dict(profile=matrix.CAPACITY_PROFILE, scale=scale, status='capacity_available', exit_code=0,
                        artifact_state='sealed_after_commands_finished', source_commit=receive.SOURCE, observer_sha256=OBSERVER,
                        files={}, context=dict(GITHUB_REPOSITORY='jyqj/codecortex', GITHUB_RUN_ID=str(receive.RUN),
                            GITHUB_RUN_ATTEMPT='1', GITHUB_JOB='measure', RUNNER_OS='Linux', RUNNER_ENVIRONMENT='github-hosted',
                            ImageOS='ubuntu24', P8_EXPECTED_SOURCE=receive.SOURCE, RUNNER_NAME='CONTRACT_FAKE', ImageVersion='CONTRACT_FAKE'),
                        required_free_bytes=need, allow_preparation=True, steps=[],
                        initial=dict(total_bytes=need*2, used_bytes=0, free_bytes=need*2),
                        final=dict(total_bytes=need*2, used_bytes=0, free_bytes=need*2))
                    files = [('receipt.json', json.dumps(receipt))]
                elif name.startswith('p8-scale-build-'):
                    files = [('build.json', '{"fixture":"not a real build"}'), ('p8-scale', 'CONTRACT_FAKE_NOT_EXECUTABLE')]
                else:
                    files = [('shard.json', '{"fixture":"admission stub for transport test"}')]
                path = archives/(name+'.zip')
                metadata = archive(path, files)
                artifacts.append(dict(id=number, name=name, **metadata, expired=False,
                    workflow_run=dict(id=receive.RUN, head_sha=receive.CONTROLLER), archive_path=path.name))
            inventory = dict(schema='p8-fixed-D0-scale-download-set-v1', run_id=receive.RUN, run_attempt=1,
                source_commit=receive.SOURCE, controller_commit=receive.CONTROLLER,
                registration_sha256=receive.REGISTRATION_SHA256, artifacts=artifacts,
                aggregate_job=dict(id=1, name='aggregate', run_id=receive.RUN, head_sha=receive.CONTROLLER,
                                   status='completed', conclusion='failure'))
            receive.save(root/'inventory.json',inventory)
            original = fixture.complete_shards(matrix.CAPACITY_PROFILE)
            by_key = {(row['plan']['files'][0],row['plan']['shard']['index']):row for row in original}
            def fake_shard(directory, *_args):
                scale, index = map(int, directory.name.removeprefix('p8-scale-shard-').removesuffix(f'-{receive.RUN}').split('-'))
                value = copy.deepcopy(by_key[(scale,index)])
                value['directory'] = str(directory)
                return value
            built = {'driver_source':{'contract_fixture':True}}
            source = matrix.source_snapshot(REPLAY)
            registration = dict(source_tree=source['source_tree'], complete_source_inputs=source['inputs'],
                primary_cells=[dict(scale=row['plan']['files'][0], shard_index=row['plan']['shard']['index'],
                                    plan=row['plan']) for row in original])
            with mock.patch.object(receive, 'load_driver', return_value=(matrix,IDENTITIES,OBSERVER)), \
                 mock.patch.object(receive, 'admission_review', return_value=({'status':'CONTRACT_STUB'},registration)), \
                 mock.patch.object(matrix, 'validate_build', side_effect=lambda path:(built,path/'p8-scale')) as build_calls, \
                 mock.patch.object(matrix, 'validate_shard', side_effect=fake_shard) as shard_calls:
                result = receive.replay(types.SimpleNamespace(output=root/'review', inventory=root/'inventory.json',
                                                             archives=archives,replay_root=REPLAY))
            self.assertTrue(result['passed'],result.get('error'))
            self.assertEqual(result['sample_count'],1500)
            self.assertEqual(result['original_zips'],302)
            self.assertEqual(result['capacity_receipts'],150)
            self.assertEqual(shard_calls.call_count,150)
            self.assertEqual(build_calls.call_count,2)
            self.assertEqual(result['remote_aggregate']['status'],'artifact_not_generated')
            self.assertEqual(result['original_aggregate_job']['conclusion'],'failure')
            self.assertEqual(result['actions_all_green'],'not_claimed')
            self.assertEqual(list((root/'review/expanded').iterdir()),[])
            self.assertEqual(len(list(archives.glob('*.zip'))),302)


if __name__ == '__main__':
    unittest.main(verbosity=2)
