"""Small real-product engineering probe; never a substitute for the one-hour soak."""
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parent
CANDIDATE = Path('/dev/shm/p8-soak-cache-candidate-G2')
SOURCE_SHA = '63ad7e850d5cfeca9830db747fe8137c9200bc0f5d4d446ab678ec96f040617e'
BINARY_SHA = '9ebbd85103ae3d4e88fc13d2fcf6144438a0dfbcfba44cbe6a4e0232bf8a8f7e'
ORIGINAL_BINARY = Path('/workspace/scratch/2eaa00d0f93a/p8-formal-evidence-G/lifecycle/files/product/codecortex')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def observer_hashes():
    base = json.loads((CANDIDATE / 'base-source.json').read_bytes())
    expected = {path: value['sha256'] for path, value in base['files'].items() if not path.startswith('scripts/tests/')}
    expected['scripts/p8_runtime.py'] = SOURCE_SHA
    actual = {path: sha(CANDIDATE / path) for path in expected}
    assert actual == expected
    return actual

def interrupted(_signum, _frame):
    raise TimeoutError('independent engineering probe 180-second watchdog')

def main():
    assert os.statvfs('/dev/shm').f_bavail * os.statvfs('/dev/shm').f_frsize > 150 * 1024 * 1024
    assert sha(ORIGINAL_BINARY) == BINARY_SHA
    before = observer_hashes()
    binary = ROOT / 'retained-G-codecortex'
    if not binary.exists():
        binary.write_bytes(ORIGINAL_BINARY.read_bytes())
        binary.chmod(0o755)
    assert sha(binary) == BINARY_SHA
    out = ROOT / 'run-01'
    out.mkdir(exist_ok=False)
    sys.path.insert(0, str(CANDIDATE / 'scripts'))
    import p8_runtime as runtime

    project = out / 'project'
    plan = {
        'scope': 'Small actual-product engineering probe only; no one-hour or formal scale acceptance',
        'product_source': 'bb9a96d71622458c39a143055360cc97f0d11d78',
        'original_product_artifact_id': 11573313154,
        'original_product_member': 'product/codecortex',
        'product_sha256': BINARY_SHA,
        'observer_base': 'd2d492b329a5630bf4a5fa6bc4b6eac30d07b13c',
        'observer_runtime_sha256': SOURCE_SHA,
        'observer_hashes_before': before,
        'fixture_source_files': 8,
        'planned': {'initial_full_builds': 1, 'incremental_mutations': 6, 'compound_reads': 14, 'rpc_per_compound_read': 4},
        'semantic_provider': 'disabled by original make_fixture configuration',
        'read_rpc_timeout_seconds': [30, 60, 60, 30],
        'engineering_watchdog_seconds': 180,
        'owned_directory_budget_bytes': 64 * 1024 * 1024,
        'formal_soak_entrypoint_called': False,
        'task_complete': False,
    }
    save(out / 'plan.json', plan)
    rows, mutations, product = [], [], None
    report = dict(status='running', plan=plan, errors=[])
    start = time.monotonic_ns()
    elapsed = lambda: time.monotonic_ns() - start
    previous = None
    preceding = None
    exit_code = 2
    signal.signal(signal.SIGALRM, interrupted)
    signal.alarm(180)
    try:
        runtime.make_fixture(project, 8)
        product = runtime.Product({'binary_path': str(binary), 'binary_sha256': BINARY_SHA},
                                  project, out / 'product', out / 'cache')
        assert product.initialize() == 14
        report['initial_full'] = product.tool('index', {'path': str(project), 'full': True}, timeout=60)
        assert report['initial_full']['parse_errors'] == []
        assert report['initial_full']['resolution_freshness']['complete'] is True
        save(out / 'initial-full.json', report['initial_full'])
        for stage in range(7):
            if stage:
                ordinal = stage - 1
                mutation = runtime.mutate(project, ordinal)
                build = {'ordinal': ordinal, 'mutation': mutation, 'started_ns': elapsed()}
                mutations.append(build)
                try:
                    build['response'] = product.tool('index', {'path': str(project), 'full': False}, timeout=60)
                    assert build['response']['parse_errors'] == []
                    assert build['response']['resolution_freshness']['complete'] is True
                    build['status'] = 'success'
                    preceding = dict(action=mutation['action'], ordinal=ordinal, operation_id=ordinal,
                                     index_epoch=build['response']['resolution_freshness'].get('index_epoch'))
                except Exception as error:
                    build.update(status='error', error=f'{type(error).__name__}: {error}')
                    raise
                finally:
                    build['finished_ns'] = elapsed()
                    save(out / 'mutations.json', mutations)
            for _ in range(2):
                row = {'id': len(rows), 'operation': 'read', 'status': 'error', 'offered_ns': elapsed()}
                rows.append(row)
                row['started_ns'] = elapsed()
                row['call_started_ns'] = elapsed()
                try:
                    observed = runtime.soak_read(product, project, row, previous, preceding, elapsed)
                    assert runtime.validate_cache_probe(row['cache_probe'], previous, project) == observed
                    previous = observed
                    row['status'] = 'success'
                except Exception as error:
                    row['error'] = f'{type(error).__name__}: {error}'
                    raise
                finally:
                    row['finished_ns'] = elapsed()
                    save(out / 'reads.json', rows)
                size = sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file())
                assert size <= plan['owned_directory_budget_bytes'], ('owned probe budget exceeded', size)
        assert len(rows) == 14 and len(mutations) == 6
        assert all(row['status'] == 'success' for row in rows)
        assert {entry['mutation']['action'] for entry in mutations} == {
            'bounded_symbol_churn', 'add', 'rename', 'delete', 'real_git_branch_switch', 'restore_api'}
        report['outcomes'] = {'compound_reads': len(rows), 'successful_reads': sum(row['status'] == 'success' for row in rows),
                              'incremental_mutations': len(mutations),
                              'actual_read_rpc_requests': sum(len(row.get('cache_probe', {}).get('requests', [])) for row in rows)}
        report['cache_states'] = [row['cache_probe']['observation']['lookup']['state'] for row in rows]
        report['invalidations'] = sum(row['cache_probe']['observation']['invalidated'] for row in rows)
        report['status'] = 'passed_small_actual_product_probe'
        exit_code = 0
    except Exception as error:
        report.update(status='failed_small_actual_product_probe', error=f'{type(error).__name__}: {error}', traceback=traceback.format_exc())
    finally:
        signal.alarm(0)
        if product is not None:
            try:
                product.close()
                report['cleanup'] = product.record
            except Exception as error:
                report['errors'].append({'cleanup_error': f'{type(error).__name__}: {error}'})
                report['status'] = 'failed_small_actual_product_probe'
                exit_code = 2
        report['elapsed_ns'] = elapsed()
        report['observer_hashes_after'] = observer_hashes()
        report['observer_unchanged'] = before == report['observer_hashes_after']
        assert report['observer_unchanged'] and sha(binary) == BINARY_SHA
        report['exit_code'] = exit_code
        report['planned_reads'] = 14
        report['actual_read_rows'] = len(rows)
        report['actual_read_rpc_requests'] = sum(len(row.get('cache_probe', {}).get('requests', [])) for row in rows)
        report['limitations'] = ['Actual original G product with revised observer bytes; neither is relabelled as a new formally built candidate.',
                                 'Small sequential fixture only; no one-hour run, quarter coverage, performance certification, or task completion.',
                                 'Formal soak entrypoint and all its budgets, samples and acceptance remain unchanged.']
        report['files'] = {path.relative_to(out).as_posix(): {'bytes': path.stat().st_size, 'sha256': sha(path)}
                           for path in out.rglob('*') if path.is_file() and path.name != 'receipt.json'}
        save(out / 'receipt.json', report)
    print(json.dumps({'status': report['status'], 'exit_code': exit_code, 'reads': len(rows),
                      'error': report.get('error'), 'cache_states': report.get('cache_states'),
                      'receipt_sha256': sha(out / 'receipt.json')}))
    return exit_code

if __name__ == '__main__':
    raise SystemExit(main())
