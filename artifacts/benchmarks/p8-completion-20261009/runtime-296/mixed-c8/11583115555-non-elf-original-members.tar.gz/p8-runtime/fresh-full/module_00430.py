def stable_00430():
    return 430
