"""Independent offline receipt/file/fixture audit; does not execute a product."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "gates-artifact"
SOURCE = "bb9a96d71622458c39a143055360cc97f0d11d78"
TREE = "bd7f0abc21650a1656783ddb26961c212aa1f2ae"
CASES = ["unmeasurable_latency_cannot_pass_comparison", "zero_measurement_gate_is_invalid",
         "cli_quality_and_latency_failures_are_nonzero_and_keep_raw", "cli_inconclusive_is_nonzero",
         "cli_lock_failure_preserves_machine_readable_failure_and_raw",
         "cli_bad_policy_is_recorded_without_overwriting_existing_report"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def main():
    zipped = ROOT / "gates-artifact-11574255362.zip"
    assert zipped.stat().st_size == 32983972
    assert sha(zipped) == "6d967d8232673cd1fd14123d161a3498d8b347b60b66c767240365a39fc19e36"
    report = read(OUT / "report.json")
    assert report["status"] == "passed_original_failure_gates" and report["exit_code"] == 0
    assert report["task_complete"] is False and report["release_approval"] is False
    disk = {p.relative_to(OUT).as_posix(): sha(p) for p in OUT.rglob("*") if p.is_file() and p != OUT / "report.json"}
    assert disk == report["files"] and len(disk) == 336
    source = report["source"]
    reviewed = read(ROOT.parent / "p8-final-independent-source-review/independent-source-review-P2.json")
    assert source["source_commit"] == SOURCE and source["source_tree"] == TREE
    assert source["input_count"] == 1087 and source["inputs"] == reviewed["complete_inputs"]
    assert [c["test_name"] for c in report["cases"]] == CASES
    fixture_dirs, cases = [], []
    producer = "/home/runner/work/codecortex/codecortex"
    target = "/home/runner/work/_temp/p8-gates-target"
    for index, record in enumerate(report["cases"]):
        home = OUT / f"case-{index:02}"
        assert read(home / "test-receipt.json") == record
        assert record["source"] == source and record["status"] == "passed"
        assert sha(home / "fault-test") == record["executable_sha256"]
        for stage in ("build", "execution"):
            command = record[stage]
            assert command["exit_code"] == 0 and command["status"] == "passed"
            assert read(home / stage / "command.json") == command
            for name, expected in command["logs_sha256"].items():
                assert sha(home / stage / name) == expected
        argv = record["execution"]["command"]
        assert argv == [record["retained_executable"], "--exact", CASES[index], "--nocapture", "--test-threads=1"]
        log = (home / "execution/stdout.log").read_text()
        assert "test " + CASES[index] + " ... ok" in log
        assert re.search(r"test result: ok\. 1 passed; 0 failed; 0 ignored;", log)
        messages = [json.loads(line) for line in (home / "build/stdout.log").read_text().splitlines() if line]
        assert messages[-1] == {"reason": "build-finished", "success": True}
        found = [m for m in messages if m.get("reason") == "compiler-artifact" and m.get("target", {}).get("name") == "benchmark_cli"]
        assert found == [record["cargo_artifact"]]
        artifact = found[0]
        assert artifact["manifest_path"] == producer + "/crates/cc-eval/Cargo.toml"
        assert artifact["target"]["src_path"] == producer + "/crates/cc-eval/tests/benchmark_cli.rs"
        assert artifact["target"]["kind"] == ["test"] and artifact["profile"]["test"] is True
        assert artifact["executable"].startswith(target + "/debug/deps/benchmark_cli-")
        assert artifact["fresh"] is (index != 0)
        cli_events = [m for m in messages if m.get("reason") == "compiler-artifact" and m.get("target", {}).get("name") == "cc-eval" and m["target"]["kind"] == ["bin"]]
        assert len(cli_events) == 1
        assert cli_events[0]["executable"] == report["cli"]["path"] == target + "/debug/cc-eval"
        assert cli_events[0]["manifest_path"] == producer + "/crates/cc-eval/Cargo.toml"
        assert cli_events[0]["target"]["src_path"] == producer + "/crates/cc-eval/src/bin/cc-eval.rs"
        if index == 0:
            assert cli_events[0] == report["cli"]["cargo_artifact"]
        roots = list((home / "retained-fixtures").glob("*")) if (home / "retained-fixtures").exists() else []
        assert len(roots) == (0 if index == 1 else 1)
        if roots:
            fixture_dirs.append(roots[0])
        cases.append(dict(name=CASES[index], passed=1, failed=0, ignored=0,
                          executable_sha256=record["executable_sha256"], fresh_compilation=index == 0,
                          fixture=None if not roots else str(roots[0].relative_to(OUT))))
    assert len(fixture_dirs) == 5 and sha(OUT / "cc-eval") == report["cli"]["executable_sha256"]
    fixtures = {i: next((OUT / f"case-{i:02}/retained-fixtures").iterdir()) for i in (0, 2, 3, 4, 5)}
    def normalized(case, name):
        return [json.loads(line) for line in (fixtures[case] / name / "normalized.jsonl").read_text().splitlines()]
    for name, elapsed in (("base", 0), ("candidate", 10)):
        rows = normalized(0, name)
        assert len(rows) == 30 and all(row["elapsed_us"] == elapsed for row in rows)
    expectations = [(2, "quality-comparison.json", "failed", 1, "Top-1 regression"),
                    (2, "latency-comparison.json", "failed", 1, "p95 regression"),
                    (3, "comparison.json", "inconclusive", 1, None),
                    (4, "comparison.json", "invalid_measurement", 2, "raw response drift"),
                    (5, "comparison.json", "invalid_measurement", 2, "JSON:")]
    outcomes = []
    for index, name, status, code, reason in expectations:
        value = read(fixtures[index] / name)
        assert value["status"] == status and value["exit_code"] == code
        if reason:
            assert any(reason in item for item in value["reasons"])
        if index in (2, 3):
            assert value["baseline_samples"] == value["candidate_samples"] == (30 if index == 2 else 2)
        outcomes.append(dict(path=str((fixtures[index] / name).relative_to(OUT)), status=status, exit_code=code))
    assert (fixtures[4] / "candidate/raw/000000.json").read_text() == "changed raw evidence\n"
    assert (fixtures[5] / "policy.json").read_text() == "broken JSON"
    result = dict(schema_version=1, reviewer="/root/pr_audit", verdict="accepted_scoped",
        scope="original six deterministic Rust failure controls and five retained artifact fixtures at exact G",
        source=SOURCE, tree=TREE, run_id=37830166408, job_id=113493148188, artifact_id=11574255362,
        artifact_zip_sha256=sha(zipped), artifact_zip_bytes=zipped.stat().st_size,
        report_sha256=sha(OUT / "report.json"), bound_files=336, source_inputs=1087,
        tests=dict(passed=6, failed=0, ignored=0), cases=cases, retained_fixture_directories=5,
        retained_cli_sha256=sha(OUT / "cc-eval"), observed_cli_outcomes=outcomes,
        original_assertions_preserved=True, unresolved_blockers=[],
        limitations=["The two direct library controls and four CLI tests use deliberate synthetic gate fixtures, not product retrieval or latency measurements.",
                     "Five complete fixture directories, original Cargo/execution logs, six identical retained test binaries and the actual CLI binary are preserved; zero_measurement is an in-memory test without a fixture directory.",
                     "Review is offline evidence/semantic inspection; it does not re-execute the product or relabel this G run as any later repair source.",
                     "Original task dependencies and whole-CI outcome remain separate; this scoped acceptance does not itself close any TODO."])
    destination = ROOT / "original-gates-independent-review-G.json"
    with destination.open("x") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps(dict(path=str(destination), sha256=sha(destination), verdict=result["verdict"], cases=6, fixtures=5)))


if __name__ == "__main__":
    main()
