#!/usr/bin/env python3
"""Materialize every new E original platform member, only dedup identical readonly native binaries."""
import collections,datetime,hashlib,json,os,pathlib,stat,zipfile
D=pathlib.Path('/dev/shm/a217aaae3bde/platform-review/pr167-execution')
ORIGINALS=pathlib.Path('/workspace/scratch/a217aaae3bde/ci-artifacts')
DEST=pathlib.Path('/dev/shm/a217aaae3bde/ci-artifacts')
E='a23bb72d3c954f385b99fe81ce9189885c208557'
PAIRS=json.loads((D/'platform-e-all-eight-pairs.json').read_text())
assert len(PAIRS)==8 and len({i for p in PAIRS for i in p})==16
OUT=D/'platform-e-complete-materialization.json'
assert not OUT.exists()
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
archives=[];groups={};estimated=0
for aid in [i for p in PAIRS for i in p]:
 home=ORIGINALS/str(aid);archive=home/f'{aid}.zip';md=json.loads((home/'artifact-metadata.json').read_text())
 assert md['id']==aid and md['workflow_run']['id']==37871838952 and md['workflow_run']['head_sha']==E
 zh=digest(archive);assert archive.stat().st_size==md['size_in_bytes'] and 'sha256:'+zh==md['digest']
 target=DEST/str(aid)/'extracted';assert not target.exists()
 rows=[];seen=set()
 with zipfile.ZipFile(archive) as z:
  for info in z.infolist():
   q=pathlib.PurePosixPath(info.filename)
   assert not q.is_absolute() and '..' not in q.parts and '\\' not in info.filename and info.filename not in seen
   seen.add(info.filename);mode=info.external_attr>>16
   assert not stat.S_ISLNK(mode)
   if info.is_dir():continue
   h=hashlib.sha256();n=0;magic=b''
   with z.open(info) as f:
    for b in iter(lambda:f.read(1048576),b''):
     if not n:magic=b[:4]
     h.update(b);n+=len(b)
   assert n==info.file_size
   native=magic in (b'\x7fELF',b'\xcf\xfa\xed\xfe',b'\xfe\xed\xfa\xcf',b'\xce\xfa\xed\xfe',b'\xfe\xed\xfa\xce')
   key=(h.hexdigest(),n,mode)
   if native:assert q.name=='codecortex' and stat.S_IMODE(mode)==0o555
   representative=groups.get(key) if native else None
   relative=str(aid)+'/extracted/'+info.filename
   if representative is None:
    estimated+=((n+4095)//4096)*4096
    if native:groups[key]=relative
   rows.append({'path':info.filename,'bytes':n,'sha256':h.hexdigest(),'original_zip_mode':oct(mode),'native_binary':native,'native_duplicate_representative':representative})
 archives.append({'id':aid,'name':md['name'],'zip_path':str(archive),'zip_sha256':zh,'zip_bytes':archive.stat().st_size,'target_root':str(target),'files':rows})
free=os.statvfs(DEST).f_bavail*os.statvfs(DEST).f_frsize
assert free>estimated+64*1024*1024,('insufficient actual free RAM for full extraction and margin',free,estimated)
for a in archives:
 root=pathlib.Path(a['target_root']);root.mkdir(parents=True,exist_ok=False)
 with zipfile.ZipFile(a['zip_path']) as z:
  for r in a['files']:
   p=root/r['path'];p.parent.mkdir(parents=True,exist_ok=True)
   if r['native_duplicate_representative']:
    representative=DEST/r['native_duplicate_representative'];assert digest(representative)==r['sha256'];os.link(representative,p)
   else:
    h=hashlib.sha256()
    with z.open(r['path']) as f,p.open('xb') as o:
     for b in iter(lambda:f.read(1048576),b''):o.write(b);h.update(b)
    assert h.hexdigest()==r['sha256'];os.chmod(p,stat.S_IMODE(int(r['original_zip_mode'],8)))
   s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_size==r['bytes'] and digest(p)==r['sha256'];assert stat.S_IMODE(s.st_mode)==stat.S_IMODE(int(r['original_zip_mode'],8))
   r.update({'device':s.st_dev,'inode':s.st_ino,'allocated_bytes':s.st_blocks*512})
 assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}=={r['path'] for r in a['files']}
 assert digest(a['zip_path'])==a['zip_sha256']
inodes=collections.defaultdict(list)
for a in archives:
 for r in a['files']:inodes[(r['device'],r['inode'])].append((pathlib.Path(a['target_root'])/r['path'],r))
for group in inodes.values():
 for p,r in group:assert p.stat().st_nlink==len(group);r['final_nlink']=len(group)
receipt={'schema_version':1,'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'complete original 16-ZIP member materialization, readonly identical native binaries internally hardlinked only','execution_source_commit':E,'archive_count':len(archives),'member_count':sum(len(a['files']) for a in archives),'logical_bytes':sum(r['bytes'] for a in archives for r in a['files']),'unique_inodes':len(inodes),'unique_file_allocated_bytes':sum(g[0][0].stat().st_blocks*512 for g in inodes.values()),'original_zip_sha_before_after_matches_official':True,'every_member_stream_sha_and_reopened_materialized_sha_equal':True,'no_sql_or_record_deduplication':True,'all_links_internal':True,'archives':archives}
OUT.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'path':str(OUT),'sha256':digest(OUT),'archives':receipt['archive_count'],'members':receipt['member_count'],'unique_file_allocated_bytes':receipt['unique_file_allocated_bytes']}))
