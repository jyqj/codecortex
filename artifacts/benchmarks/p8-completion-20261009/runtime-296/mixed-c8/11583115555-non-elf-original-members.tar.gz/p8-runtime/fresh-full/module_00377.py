def stable_00377():
    return 377
