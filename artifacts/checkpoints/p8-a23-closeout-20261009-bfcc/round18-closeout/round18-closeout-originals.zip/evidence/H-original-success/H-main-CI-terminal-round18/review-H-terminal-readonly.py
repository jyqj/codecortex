#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
load = lambda p: json.loads(p.read_text())
def rec(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

run = json.loads(load(ROOT/'official-run.json')['response_content'])
jobs = json.loads(load(ROOT/'official-jobs.json')['response_content'])
assert run['id'] == 37936553220 and run['run_attempt'] == 1
assert run['head_sha'] == '0e6b07c75183da79c5a6679d4c2b66c65f7db663'
assert run['conclusion'] == 'success'
check = next(j for j in jobs['jobs'] if j['id'] == 113839937923)
assert check['conclusion'] == 'success'
assert all(s['conclusion'] == 'success' for s in check['steps'])
log = ROOT/'check-113839937923.decoded.log'
raw = log.read_bytes()
text = raw.decode()
lines = text.splitlines()
assert len(raw) == 1081772 and len(text) == 1081770
assert text.startswith('\ufeff') and text.endswith('\n') and '\r' not in text
mergepath = ROOT.parent/'H-MSRV-113839937471/official-MSRV-merge-commit.json'
merge = json.loads(load(mergepath)['response']['content'])
assert merge['sha'] == 'fd3db5e3207ed20d59d0f67348f6edaa486a5225'
assert merge['tree']['sha'] == run['head_commit']['tree_id'] == '9755e717368ffb51bc084c3348c1715b00b34d0d'
assert merge['sha'] in lines[184]
name = 'subprocess_descendant_cannot_hold_stderr_past_worker_deadline'
oks = [{'log_line': i+1, 'text': line} for i,line in enumerate(lines) if 'test '+name+' ... ok' in line]
assert len(oks) == 2
results = []
for hit in oks:
    i = hit['log_line']-1
    j = next(j for j in range(i+1,len(lines)) if 'test result:' in lines[j])
    assert '12 passed; 0 failed; 0 ignored;' in lines[j]
    start = max(j for j in range(i) if '     Running' in re.sub(r'\x1b\[[0-9;]*m','',lines[j]))
    results.append({'test_ok': hit, 'target': {'log_line': start+1, 'text': lines[start]}, 'target_result': {'log_line': j+1, 'text': lines[j]}})
canonical = load(ROOT.parent/'final-R3/independent-source-review.json')
prior = load(ROOT.parent/'final-R2/independent-source-review.json')
path = 'crates/cc-eval/tests/p8_scale.rs'
assert canonical['actual_input_mode_blob_inventory'][path] == prior['actual_input_mode_blob_inventory'][path]
report = {
    'schema': 'H-main-CI-original-descendant-fixture-observation-v1',
    'reviewer': '/root/execution_recon',
    'verdict': 'H_original_main_CI_success_and_descendant_fixture_actually_passed',
    'run_id': run['id'], 'attempt': 1, 'head': run['head_sha'],
    'head_tree': run['head_commit']['tree_id'], 'run_status': run['status'], 'run_conclusion': run['conclusion'],
    'jobs': [{k:j[k] for k in ['id','name','status','conclusion','completed_at']} for j in jobs['jobs']],
    'check_job': check['id'], 'actual_checkout': merge['sha'], 'actual_checkout_tree': merge['tree']['sha'],
    'entire_checkout_tree_equals_H': True, 'checkout_parents': [p['sha'] for p in merge['parents']],
    'actual_stable_toolchain': 'rustc 1.99.0 (b940084d7 2026-09-28)',
    'executed_test': name, 'actual_test_observations': results,
    'commands': {'default': 'cargo test --workspace --all-targets --exclude cc-semantic --locked', 'optional': 'cargo test -p cc-eval --features eval-http --locked'},
    'test_source_identity': {'path': path, 'H_and_G3_same_inventory': canonical['actual_input_mode_blob_inventory'][path]},
    'risk_conclusion': 'This original H check has no descendant-fixture failure: the exact test returned ok in both default and eval-http executions, each twelve-test target passed with zero failed/ignored. This run therefore does not establish a known inherited failure requiring b2 integration before G4 CI. It does not prove absence of intermittency or replace G4 validation. The later b2 readiness improvement is a separate reviewed engineering change.',
    'immutable_checkout_metadata_reused_from_prior_H_MSRV': rec(mergepath),
    'original_decoded_log': rec(log),
    'log_transport': 'Decoded UTF-8 tool content retained including BOM and terminal LF; length and character count checked. No original compressed ZIP hash is asserted.',
    'exit_evidence': 'Official job/all-step conclusions success and original test result lines; no fabricated atomic integer per-command receipt.',
    'all_check_step_conclusions': check['steps'],
    'no_rerun_native_or_mutation': True, 'P4_G4_new_SQL_test_runtime_credit': False, 'TODO_credit': 0, 'TODO_remaining': 29,
}
selected = [{'start_line':lo,'end_line':hi,'lines':lines[lo-1:hi]} for lo,hi in [(175,187),(460,476),(490,505),(724,735),(2148,2165),(8179,8196)]]
for filename, value in [('independent-H-descendant-fixture-CI-review.json', report), ('relevant-original-log-excerpts.json', selected)]:
    with (ROOT/filename).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, ensure_ascii=False)
        stream.write('\n')
print(json.dumps({'verdict':report['verdict'],'report':rec(ROOT/'independent-H-descendant-fixture-CI-review.json'),'descendant_actual_ok':2,'test_target_passed_each':12,'original_log':rec(log)},sort_keys=True))
