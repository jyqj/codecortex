#!/usr/bin/env python3
"""Bind a completed canonical Cargo build to its actual copied product."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/71bc431c4e4f/codecortex-p7-019')
SOURCE = '93356fc87e9534c286192bde1fc88aa95abe878b'
MAP_SHA = 'ef5a880e8633c605cd52ae50fc2b4dd7193a761602da98ac7f97c5dcdff43187'


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, sort_keys=True, indent=2)
        handle.write('\n')


def main():
    kind = sys.argv[1]
    require(kind in ('default', 'http'), 'expected default/http product')
    name = 'canonical-' + kind + '-product-build'
    record = json.loads((OUT / (name + '.json')).read_bytes())
    require(record['exit_code'] == 0 and record['source_inputs_unchanged']
            and record['source_commit_before'] == record['source_parent'] == SOURCE,
            'canonical execution is incomplete or source changed')
    require(sha(OUT / record['source_manifest']) == MAP_SHA == record['source_manifest_sha256'],
            'canonical source manifest changed')
    require(sha(OUT / record['log']) == record['log_sha256'], 'canonical Cargo log changed')
    messages = []
    for line in (OUT / record['log']).read_text().splitlines():
        if line.startswith('{'):
            messages.append(json.loads(line))
    artifacts = [row for row in messages if row.get('reason') == 'compiler-artifact']
    candidates = [row for row in artifacts if row['target']['name'] == 'codecortex'
                  and row['target']['kind'] == ['bin']]
    require(len(candidates) == 1, 'expected one actual product artifact')
    artifact = candidates[0]
    expected_features = [] if kind == 'default' else ['semantic', 'semantic-http']
    require(artifact['features'] == expected_features and artifact['fresh'] is False
            and artifact['profile']['test'] is False, 'wrong or reused product artifact')
    require(Path(artifact['manifest_path']) == ROOT / 'crates/cc-server/Cargo.toml'
            and Path(artifact['target']['src_path']) == ROOT / 'crates/cc-server/src/main.rs',
            'artifact belongs to a different checkout')
    workspace = [row for row in artifacts if str(row.get('manifest_path', '')).startswith(str(ROOT / 'crates') + '/')]
    if kind == 'default':
        require(all(row['fresh'] is False for row in workspace),
                'first build reused a workspace artifact after targeted clean')
    target = OUT / ('canonical-codecortex-default' if kind == 'default' else 'canonical-codecortex-semantic-http')
    require(not target.exists(), 'canonical product snapshot already exists')
    executable = Path(artifact['executable'])
    original_digest = sha(executable)
    shutil.copy2(executable, target)
    require(sha(target) == original_digest == sha(executable), 'binary changed during copy')
    versions = {
        'cargo': subprocess.check_output(['cargo', '+1.95.0', '--version'], cwd=ROOT, text=True).strip(),
        'rustc': subprocess.check_output(['rustc', '+1.95.0', '--version', '--verbose'], cwd=ROOT, text=True).strip(),
    }
    version_path = OUT / 'canonical-toolchain-version.json'
    if version_path.exists():
        require(json.loads(version_path.read_bytes()) == versions, 'toolchain version changed')
    else:
        save(version_path, versions)
    receipt = {
        'source_files': json.loads((OUT / record['source_manifest']).read_bytes()),
        'binary_sha256': original_digest,
        'build_options': {
            'command': record['command'], 'cargo': versions['cargo'], 'rustc': versions['rustc'],
            'SDKROOT': record['environment']['SDKROOT'], 'RUSTFLAGS': record['environment']['RUSTFLAGS'],
            'profile': 'dev debug=0, incremental=false',
            'features': [] if kind == 'default' else ['semantic-http'], 'jobs': 2,
            'binding': {
                'scope': 'Actual compiler-artifact executable after an unchanged-source build and explicit workspace clean; local execution provenance only.',
                'source_commit': SOURCE, 'source_manifest_sha256': MAP_SHA,
                'execution_receipt': name + '.json',
                'workspace_clean_receipt': 'canonical-workspace-clean.json',
                'CARGO_BUILD_BUILD_DIR': record['environment']['CARGO_BUILD_BUILD_DIR'],
                'capture_executor_sha256': sha(__file__),
            },
            'CARGO_TARGET_DIR': record['environment']['CARGO_TARGET_DIR'],
        },
        'exit_code': record['exit_code'],
    }
    receipt_path = OUT / ('canonical-' + kind + '-product-build-receipt.json')
    save(receipt_path, receipt)
    save(OUT / ('canonical-' + kind + '-product-compiler-artifacts.json'),
         {'product': artifact, 'workspace_artifacts': workspace})
    metadata = {'kind': kind, 'source_commit': SOURCE, 'source_manifest_sha256': MAP_SHA,
                'binary': str(target), 'binary_sha256': original_digest, 'binary_bytes': target.stat().st_size,
                'features_requested': receipt['build_options']['features'],
                'features_resolved': artifact['features'], 'product_fresh': artifact['fresh'],
                'build_receipt': receipt_path.name, 'build_receipt_sha256': sha(receipt_path),
                'workspace_artifacts': len(workspace),
                'workspace_artifacts_fresh': sum(row['fresh'] is True for row in workspace),
                'capture_executor_sha256': sha(__file__)}
    save(OUT / ('canonical-' + kind + '-product.json'), metadata)
    print(json.dumps(metadata, indent=2))


if __name__ == '__main__':
    main()
