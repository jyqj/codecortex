import json,pathlib,subprocess,sys,hashlib
root=pathlib.Path(__file__).resolve().parent
arm=sys.argv[1]
rows=[json.loads(line) for line in (root/'receipts'/f'cargo-{arm}-artifacts.jsonl').read_text().splitlines() if line.startswith('{')]
required={}
for row in rows:
 if row.get('reason')=='compiler-artifact' and row['target']['name'] in ['cc_eval','cc_server','serde_json'] and row['profile'].get('debuginfo')==2:
  files=[p for p in row['filenames'] if p.endswith('.rlib')]
  if files: required[row['target']['name']]=files[0]
assert set(required)=={'cc_eval','cc_server','serde_json'},required
out=root/'toolchain'/f'micro-{arm}'
cmd=[str(root/'toolchain/install/bin/rustc'),'--edition','2021',str(root/'receiver_micro_driver.rs'),'-L',f'dependency={root}/targets/{arm}/debug/deps','-o',str(out)]
for name,path in required.items():cmd.extend(['--extern',name+'='+path])
r=subprocess.run(cmd,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(root/'receipts'/f'link-micro-{arm}.log').write_text(r.stdout)
print(r.stdout,end='')
receipt={'command':cmd,'exit_code':r.returncode,'source_sha256':hashlib.sha256((root/'receiver_micro_driver.rs').read_bytes()).hexdigest(),'libraries':{n:{'path':p,'sha256':hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()} for n,p in required.items()}}
if r.returncode==0:receipt['binary_sha256']=hashlib.sha256(out.read_bytes()).hexdigest()
(root/'receipts'/f'link-micro-{arm}.json').write_text(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(r.returncode)
