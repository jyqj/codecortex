#!/usr/bin/env python3
"""Independent, read-only field and raw-byte audit; no product execution."""
import hashlib
import json
from pathlib import Path
import sqlite3
from datetime import datetime, timezone

BASE = Path('/workspace/scratch/a217aaae3bde/original-173-runtime')
ROOT = BASE / 'artifacts/11597639035/extracted/p8-full-recovery'
OUT = BASE / 'reviews/recovery-11597639035-275e8799-independent'
HEAD = '275e8799d4947d297329073eaa3ca675d3fd0777'

def check(condition, message):
    if not condition:
        raise AssertionError(message)

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def contains(value, target):
    return value == target or (isinstance(value, dict) and any(contains(v, target) for v in value.values())) or (isinstance(value, list) and any(contains(v, target) for v in value))

def source_files(project):
    return {p.relative_to(project).as_posix(): sha(p) for p in sorted(project.rglob('*'))
            if p.is_file() and p.relative_to(project).parts[0] not in ('.codecortex', '.codecortex.json')}

def inventory():
    return {p.relative_to(ROOT).as_posix(): sha(p) for p in sorted(ROOT.rglob('*'))
            if p.is_file() and p.name != 'full-recovery.json'}

full = read(ROOT / 'full-recovery.json')
prior_path = OUT / 'recovery-173-review.json'
prior = read(prior_path)
check(prior['assessment'] == 'accepted_scoped_execution_evidence' and prior['execution_source_commit'] == HEAD, 'prior source/build audit differs')
check(prior['integrity']['full_recovery_json_sha256'] == sha(ROOT / 'full-recovery.json'), 'prior audited full report changed')
initial = inventory()
check(initial == full['evidence_files_sha256'], 'full inventory differs')
local = read(ROOT / 'local-recovery/recovery.json')
check(local['status'] == 'passed_limited_local_recovery', 'local cases failed')
local_raw = {}
processes = []
for file in sorted((ROOT / 'local-recovery').rglob('process.json')):
    directory = file.parent
    name = directory.relative_to(ROOT / 'local-recovery').as_posix()
    process = read(file)
    killed = name == 'kill_restart/before-kill'
    check(process['exit_code'] == process['expected_exit_code'] == (-9 if killed else 0), name + ' exit mismatch')
    check(process['binary_sha256'] == prior['products']['default']['binary_sha256'] and process['initialized'] is True and process['tool_count'] == 14 and process['cleanup'] == 'completed', name + ' process identity/cleanup differs')
    rows = [json.loads(x) for x in (directory / 'rpc.jsonl').read_text().splitlines()]
    requests = [x['payload'] for x in rows if x['event'] == 'request']
    responses = [x['payload'] for x in rows if x['event'] == 'response']
    request_ids = [x['id'] for x in requests]
    response_ids = [x['id'] for x in responses]
    check(len(set(request_ids)) == len(request_ids) and len(set(response_ids)) == len(response_ids), name + ' duplicate RPC id')
    check(set(request_ids) - set(response_ids) == ({7} if killed else set()) and not set(response_ids) - set(request_ids), name + ' missing/unmatched RPC')
    wire = []
    for row in rows:
        if row['event'] == 'stdout_wire':
            data = row['text'].encode('utf-8', 'strict')
            check(len(data) == row['wire_bytes'] and hashlib.sha256(data).hexdigest() == row['wire_sha256'], name + ' wire digest differs')
            wire.append(json.loads(data))
    check(wire == responses, name + ' raw wire differs from parsed response sequence')
    if name == 'deleted_source/reopen-without-index':
        check(not any(x.get('params', {}).get('name') == 'index' for x in requests), 'reopen has an explicit index call')
    local_raw[name] = dict(requests=requests, responses=responses)
    processes.append(dict(session=name, requests=len(requests), responses=len(responses), exit_code=process['exit_code'], raw_wire_verified=True))
check(len(processes) == 5, 'missing local sessions')
local_cases = []
for case in local['cases'][:3]:
    name, result = case['id'], case['result']
    check(case['status'] == 'passed', name + ' did not pass')
    project = ROOT / 'local-recovery' / name / 'fixture'
    check(source_files(project) == result['expected_source_after'], name + ' final source bytes differ')
    replies = [v for k, records in local_raw.items() if k.startswith(name + '/') for v in records['responses']]
    if name in ('kill_restart', 'database_busy'):
        check(contains(replies, result['capabilities']) and contains(replies, result['query']['response']), name + ' final report not retained RPC')
        for hit in result['query']['check']['checked']:
            path = project / hit['file_path']
            check(sha(path) == hit['source_sha256'] and hit['start_line'] <= hit['end_line'] <= len(path.read_text().splitlines()), name + ' public source span differs')
    if name == 'kill_restart':
        kill = result['kill']
        check(kill['exit_code'] == -9 and kill['pending_request_id'] == 7 and kill['stop_observed'] is True and kill['stop_observation_method'] == 'waitpid_owned_child_WUNTRACED_SIGSTOP', 'kill was not observed at declared boundary')
        check(kill['request']['kind'] == 'error' and kill['request']['event']['kind'] == 'stdout_eof', 'kill pending RPC did not fail by EOF')
    elif name == 'database_busy':
        busy = result['busy']
        check(busy['lock_probe']['blocked'] is True and busy['lock_probe']['sqlite_errorcode'] == 5 and busy['new_symbol_rows_while_locked'] == 0, 'database lock not actually observed')
        check(0 < busy['held_seconds'] <= busy['hold_budget_seconds'] == 6 and busy['request_while_locked']['kind'] == 'error', 'lock duration/request failure differs')
        check(contains(replies, result['incremental']) and not result['incremental']['parse_errors'], 'no successful recovery incremental result')
    else:
        check(result['deleted_source_recreated'] is False and not (project / 'src/deleted.rs').exists(), 'deleted source resurrected')
        for label in ('after_incremental', 'after_reopen'):
            phase = result[label]
            check(phase['deleted_query']['response'] == [] and contains(replies, phase['retained_query']['response']) and contains(replies, phase['capabilities']), 'deleted-source response differs')
        check(result['after_reopen']['explicit_index_called'] is False, 'reopen claimed rebuild')
    db = project / '.codecortex/index.sqlite3'
    with sqlite3.connect(db.as_uri() + '?mode=ro&immutable=1', uri=True) as connection:
        check(connection.execute('PRAGMA integrity_check').fetchone()[0] == 'ok' and not connection.execute('PRAGMA foreign_key_check').fetchall(), name + ' invalid retained database')
    local_cases.append(dict(id=name, status='passed', final_authored_source_rehashed=True, original_rpc_values_matched=True))
check([c['status'] for c in local['cases'][3:]] == ['not_run'] * 4, 'limited report omissions were rewritten')

active_reviews = []
for seed in (223, 227, 229):
    directory = ROOT / f'active-stdio-{seed}'
    report = read(directory / 'active-faults.json')
    check(report in full['active_stdio'] and report['status'] == 'passed', 'active original report mismatch')
    check(report['binary_sha256'] == report['binary_sha256_after'] == prior['products']['semantic-http']['binary_sha256'], 'active binary differs')
    events = [json.loads(x) for x in (directory / 'events.jsonl').read_text().splitlines()]
    check([x['sequence'] for x in events] == list(range(len(events))), 'active event sequence differs')
    responses = [x['response'] for x in events if x['kind'] == 'mcp_response']
    sessions = []
    for process in report['product_exits']:
        session = process['session']
        check(process['exit_code'] == 0 and process['cleanup'] is False and process['requested_sigkill'] is False and process['stdout_reader_joined'] is True and process['stdout_errors'] == [] and process['terminal_notifications'] == 0, 'active process exit/drain differs')
        stdout = directory / (session + '.stdout.log')
        stderr = directory / (session + '.stderr.log')
        check(sha(stdout) == process['stdout_sha256'] and sha(stderr) == process['stderr_sha256'], 'active stdout/stderr hashes differ')
        wire = [json.loads(line) for line in stdout.read_bytes().decode('utf-8', 'strict').splitlines()]
        req = [x['request'] for x in events if x['kind'] == 'mcp_request' and x['session'] == session]
        res = [x['response'] for x in events if x['kind'] == 'mcp_response' and x['session'] == session]
        check(wire == res, 'actual raw stdout differs from complete response log')
        ids = [x['id'] for x in res]
        check(len(ids) == len(set(ids)) and sorted(ids) == sorted(x['id'] for x in req), 'active duplicate/missing/unmatched RPC')
        exit_events = [x for x in events if x['kind'] == 'product_exit' and x['session'] == session]
        check(len(exit_events) == 1 and all(exit_events[0].get(k) == v for k, v in process.items()), 'exit report/event differs')
        sessions.append(dict(session=session, requests=len(req), responses=len(res), exit_code=0, strict_utf8_json=True, no_missing_or_duplicate_ids=True))
    check(len(sessions) == 2, 'missing active/reopen session')
    calls = report['provider_calls']
    http = [x for x in events if x['kind'] == 'http_request']
    check(len(calls) == len(http) == report['observed_provider_requests'] == 6 and report['paid_cost'] is None, 'provider request/cost count differs')
    for call, original in zip(calls, http):
        check(call['request_number'] == original['request_number'] and call['request'] == original['request'] and call['phase'] == original['phase'] and call['mode'] == original['mode'] and call['actual_paid_cost'] is None, 'provider original request differs')
    check(calls[0]['mode'] == 'disconnect' and calls[0]['response_status'] is None and calls[0]['response_write_completed'] is False, 'owned disconnect not actual')
    check(any(x['kind'] == 'http_disconnect' and x['response_bytes_sent'] == 0 for x in events), 'disconnect event absent')
    cases = {c['id']: c for c in report['cases']}
    check(len(cases) == 4 and all(c['status'] == 'passed' for c in cases.values()), 'active fault coverage differs')
    network = cases['active_provider_network_disconnect']
    before, after = network['before'], network['after']
    check(before['semantic_state'] == 'backfilling' and before['dense_state'] == 'partial' and before['semantic_pending'] > 0 and before['dense_published'] < before['dense_desired'], 'disconnect made unearned readiness')
    check(after['semantic_state'] == after['dense_state'] == 'ready' and after['dense_published'] == after['dense_desired'] == 1, 'disconnect did not recover')
    check(contains(responses, before) and contains(responses, after), 'disconnect statuses not raw responses')
    pending = [x['snapshot'] for x in events if x['kind'] == 'database_read_only' and x['phase'] == 'disconnect_pending']
    check(len(pending) == 1 and any(x['state'] == 'pending' and x['attempt_count'] > 0 for x in pending[0]['outbox']), 'durable pending work absent')
    corrupt = cases['active_semantic_cache_corruption']
    lanes = corrupt['corrupt_query']['evidence_summary']['retrieval']['lanes']
    semantic = [x for x in lanes if x['lane_id'] == 'semantic']
    check(len(semantic) == 1 and semantic[0]['status'] == 'partial' and semantic[0]['coverage']['complete'] is False and semantic[0]['truncation_reason'] == 'semantic_artifact_unavailable', 'corrupt cache did not fail incomplete')
    check(corrupt['restored_lane']['status'] == 'complete' and corrupt['restored_lane']['coverage']['complete'] is True and corrupt['additional_provider_requests'] == 0, 'cache recovery/cost differs')
    check(sha(directory / 'original-vector.bin') == corrupt['original_sha256'] and contains(responses, corrupt['corrupt_query']) and contains(responses, corrupt['restored_lane']), 'cache backup/raw result differs')
    replaced = cases['concurrent_database_replacement']
    held, swapped, settled = (replaced[k] for k in ('held', 'swapped', 'settled'))
    check(held['query_pins'] > 0 and held['generation']['incarnation'] != swapped['generation']['incarnation'] and swapped['semantic_state'] != 'ready', 'replacement not actually concurrent/new incarnation')
    check(settled['semantic_state'] == settled['dense_state'] == 'ready' and settled['dense_published'] == settled['dense_desired'] == 1 and all(contains(responses, value) for value in (held, swapped, settled)), 'replacement did not recover from raw observations')
    project = directory / 'project'
    check(replaced['deleted_source_absent'] is True and not (project / 'remove.rs').exists() and sha(project / 'keep.rs') == replaced['current_source_sha256'], 'replacement authored source differs')
    check((project / 'keep.rs').read_text() == f'pub fn survivor_{seed}() -> u32 {{ {seed + 3000} }}\n', 'replacement current source wrong')
    db = project / '.codecortex/index.sqlite3'
    with sqlite3.connect(db.as_uri() + '?mode=ro&immutable=1', uri=True) as connection:
        connection.row_factory = sqlite3.Row
        check(connection.execute('PRAGMA integrity_check').fetchone()[0] == 'ok' and not connection.execute('PRAGMA foreign_key_check').fetchall(), 'replacement database invalid')
        manifest = [dict(x) for x in connection.execute('SELECT * FROM semantic_manifest ORDER BY doc_key')]
        check(manifest == replaced['persisted_manifest'] and len(manifest) == 1, 'replacement semantic manifest resurrected/differs')
        stale = connection.execute('SELECT COUNT(*) FROM semantic_manifest s LEFT JOIN document_manifest d ON d.doc_key=s.doc_key AND d.doc_version=s.doc_version WHERE d.doc_key IS NULL').fetchone()[0]
        check(stale == 0, 'late result published stale version')
    active_reviews.append(dict(seed=seed, cases=list(cases), sessions=sessions, provider_requests=6, actual_paid_cost=None, loopback_only=True, final_database_integrity='ok', stale_semantic_manifest_versions=0, raw_responses_matched=True))

check(inventory() == initial, 'original files changed during read-only review')
report = dict(schema_version=1, reviewer='runtime_closeout', created_at_utc=datetime.now(timezone.utc).isoformat(), assessment='accepted_scoped_original_P8_011_recovery_execution', execution_source_commit=HEAD, artifact_id=11597639035, source_build_and_P8_016_review=dict(path=str(prior_path), sha256=sha(prior_path)), full_recovery_json_sha256=sha(ROOT / 'full-recovery.json'), full_manifest_files=len(initial), original_files_unchanged=True, local_cases=local_cases, local_sessions=processes, active_seeds=active_reviews, internal_crash_test_mapping=prior['original_fault_tests'][:4], limited_nested_not_run_records_preserved=True, unresolved_blockers_in_reviewed_scope=[], hard_dependencies={'P8-011':['P7-020','P8-007','P8-010'],'P8-016':['P7-020','P8-012','P8-013']}, task_completion_certified=False, remaining_todos_unchanged=29, limits=['No new fault execution, product compilation, or writable SQLite operation performed.', 'SIGKILL local boundary is a stopped pending request; internal transaction/rename boundaries are covered by the four separately retained Rust tests, not inferred from that local SIGKILL.', 'Owned loopback HTTP is controlled provider evidence; paid cost remains null and no live-provider/release certification is claimed.', 'Source/config preservation applies to the version rollback scenarios; recovery fixture source edits are intentionally prescribed and final authored bytes are checked.', 'Original hard dependencies and full platform/CI regression prerequisites remain independently required.'])
path = OUT / 'recovery-173-011-review.json'
path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(assessment=report['assessment'], path=str(path), local_cases=len(local_cases), local_sessions=len(processes), active_seeds=len(active_reviews), unchanged_original_files=len(initial))))
