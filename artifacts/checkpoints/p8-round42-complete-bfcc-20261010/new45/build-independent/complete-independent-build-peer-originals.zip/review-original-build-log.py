from pathlib import Path
import datetime,hashlib,json,re

ROOT=Path('/workspace/scratch/bfccb8494ba0'); OUT=Path(__file__).resolve().parent
HEAD='f97c5068d056969705e8387ba1f37d83847f5bee'
def ident(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
log=ROOT/'round42-new45-study/114138076763-original-build.log'
source=ident(log);assert source['git_blob']=='9b61d0159a83b1e5130caca4166ceb9aa0e3013c'
assert source['bytes']==39996 and source['sha256']=='489ed33c2d9352b4463a99f0c46a98e131fca5d8656f440b60fab966e732675b'
text=log.read_text();lines=text.splitlines();ansi=re.compile(r'\x1b\[[0-9;]*m')
def excerpt(a,z):return [{'line':n,'text':ansi.sub('',lines[n-1])} for n in range(a,z+1)]
assert lines[236].endswith(HEAD)
assert '1 passed; 0 failed; 0 ignored; 0 measured; 21 filtered out' in lines[497]
assert '##[error]' not in text
official_path=ROOT/'round42-new45-study/0515-build-and-publication-originals.json'
official=json.loads(official_path.read_text())
jobs=json.loads(official['responses'][3]['value']['structuredContent']['content'])['jobs']
job=next(j for j in jobs if j['id']==114138076763)
assert job['head_sha']==HEAD and job['run_id']==38026411200 and job['run_attempt']==1
assert job['conclusion']=='success' and job['status']=='completed'
metadata_path=ROOT/'round42-new45-study/build-artifact-original-metadata.json'
metadata=json.loads(metadata_path.read_text());artifact=metadata['original_artifact']
assert artifact['id']==11659139900 and artifact['size_in_bytes']==9250795
assert artifact['digest']=='sha256:65ae643b212d826533aa74a55c69e875ea964751966c5487434adbdfb57ac3b9'
assert metadata['source']==HEAD and metadata['run_id']==38026411200 and metadata['attempt']==1
test=OUT/'source-p8_scale.rs';native=OUT/'source-native-p8_scale.rs'
assert ident(test)['git_blob']=='d31ff3e776a6d1e3659ef045498c2857fc350198'
assert ident(native)['git_blob']=='edc56c0ab9c0b3c35f319cdfc2be23ce13bdc220'
ts=test.read_text();ns=native.read_text()
name='task_descriptive_scope_is_explicit_n1_without_weakening_old_n30'
start=ts.index('fn '+name);end=ts.index('\n#[test]',start)
body=ts[start:end]
assert 'for profile in p8_scale::MUTATION_PROFILES' in body and 'for scale in RELEASE_SCALES' in body
assert 'for fanout in [1, 4, 16, 64, 128]' in body
assert all(s not in body for s in ['p8_scale::run','Command::','Connection::','run_scale','run_native'])
profile_raw=ns.split('pub const MUTATION_PROFILES: [&str; 8] = [',1)[1].split('];',1)[0]
profiles=re.findall(r'"([^"]+)"',profile_raw);assert len(profiles)==8
assert 'pub const RELEASE_SCALES: [usize; 5] = [1_000, 5_000, 10_000, 50_000, 100_000];' in ns
validation=ns[ns.index('pub fn validate'):ns.index('\n    pub fn ',ns.index('pub fn validate')+1)]
assert all(s not in validation for s in ['Command::','Connection::','fs::','spawn(','thread::'])
report={
 'schema_version':1,'reviewer':'pr_triage','formal_round':42,
 'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'conclusion':'accepted_scoped_original_build_job_and_pure_release_plan_control; original artifact tuple acceptance awaits independent mechanical receiver',
 'scope':'Read-only original log/API/source review. No Actions download, ZIP open/CRC, ELF inspection, validator import/call, Rust/test/native rerun.',
 'source':HEAD,'source_tree':'39a053ae49b486764751a570d164e7cd41d7ff29',
 'run_id':38026411200,'attempt':1,'producer_job':job,
 'original_log':source,'actual_checkout':excerpt(234,237),
 'toolchain':excerpt(457,463),
 'build_command_and_result':excerpt(465,478),
 'build_result_boundary':'The original task build command returned passed=true,error=null,sample_count=null; this is build/registry preparation, not a measurement sample.',
 'release_gate':{
   'method':name,'command_and_result':excerpt(479,498),
   'passed_methods':1,'failed_methods':0,'ignored_methods':0,'filtered_methods':21,'duration_seconds_reported':0.00,
   'tested_plan_population':45,'mutation_profiles':profiles,'scales':[1000,5000,10000,50000,100000],
   'mutation_profile_plans':40,'fanout_plans':5,'fanouts':[1,4,16,64,128],
   'count_boundary':'One Rust method loops across the 45 registered plan shapes; not 45 test methods, 45 workloads, or 45 accepted study cells.',
   'positive_release_check':'Log shows cargo test --release and optimized release target; cfg!(debug_assertions) is false in this method, which requires all new N1 plans to validate.',
   'old_scope_controls':'For each mutation-scale pair, old ProfileIsolatedV1 with N1 is rejected, old N30 shard0/30 accepted in release, and new task scope with N30 rejected.',
   'pure_control_source':{'test':ident(test),'native_plan_validation':ident(native),'test_start_line':ts[:start].count('\n')+1,'test_body':body},
   'no_measurement_in_this_method':'Only plan construction/cloning, serde round-trip, validate, repetition_range and fanout_budgets; validate checks fields and returns Result. No worker/database/index/measurement invocation.',
 },
 'artifact_upload':{'official':artifact,'original_log':excerpt(517,529),'announced_files':8,'not_independently_downloaded_or_read_here':True},
 'source_and_runtime_binding_boundary':'Direct checkout and original producer job/run/attempt/metadata agree. Complete product/observer snapshots, registry, ELF producer and accepted build tuple are delegated to the original validate_build receiver; not inferred from the short log.',
 'receiver_acceptance':None,
 'warnings':[{'line':i,'text':l} for i,l in enumerate(lines,1) if 'Warning' in l or '##[warning]' in l],
 'official_provenance':{'full_response':ident(official_path),'jobs_response_index':3,'artifact_metadata':ident(metadata_path),'observation_interval':official['interval']},
 'host_read_recovery':{'old_local_contract_missing':True,'first_read_probe_exit':1,'reason':'Prior transient directories absent; no product/validator ran. Two exact current Git source blobs recovered via official raw endpoint and verified by Git OID.'},
 'not_claimed':['any measurement accepted','45 complete cells','85 complete records','full ordinary CI success','main terminal success','task completion','performance benefit'],
}
save(OUT/'independent-original-build-log-review.json',report)
print(json.dumps({'status':'accepted_scoped_log','original_hash_match':True,'release_test':'1passed21filtered','plan_population':45,'receiver_pending':True,'report':ident(OUT/'independent-original-build-log-review.json')}))
