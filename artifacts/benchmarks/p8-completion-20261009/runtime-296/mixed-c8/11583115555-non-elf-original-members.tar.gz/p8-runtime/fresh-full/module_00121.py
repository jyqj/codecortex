def stable_00121():
    return 121
