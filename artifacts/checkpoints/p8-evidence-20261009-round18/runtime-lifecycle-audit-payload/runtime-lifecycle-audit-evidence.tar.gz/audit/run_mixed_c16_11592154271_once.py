import datetime, hashlib, json, os, pathlib, subprocess
base = pathlib.Path('/dev/shm/a217aaae3bde/runtime-review/e-a23-artifact-review')
receipt = base / 'mixed-c16-11592154271-review-process.json'
assert not receipt.exists()
def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
manifest = json.loads((base / 'frozen-helper-manifest.json').read_text())
before = {}
for name, item in manifest['files'].items():
    p = pathlib.Path(item['path'])
    assert p.stat().st_size == item['bytes'] and sha(p) == item['sha256']
    before[name] = item['sha256']
command = ['python', '-B', str(base / 'review_e_runtime_original.py'), str(base / 'mixed-c16-11592154271-manifest.json'), str(base / 'actual-originals'), 'a23bb72d3c954f385b99fe81ce9189885c208557', '/dev/shm/a217aaae3bde/codecortex-combined-guard-view', str(base / 'accepted')]
record = dict(command=command, started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), frozen_manifest_sha256=sha(base / 'frozen-helper-manifest.json'), frozen_files_before=before, exit_code=None)
with (base / 'mixed-c16-11592154271-review.stdout').open('x') as stdout, (base / 'mixed-c16-11592154271-review.stderr').open('x') as stderr:
    result = subprocess.run(command, stdout=stdout, stderr=stderr, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
record['exit_code'] = result.returncode
record['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
after = {name: sha(item['path']) for name, item in manifest['files'].items()}
record['frozen_files_after'] = after
record['frozen_files_unchanged'] = before == after
record['stdout_sha256'] = sha(base / 'mixed-c16-11592154271-review.stdout')
record['stderr_sha256'] = sha(base / 'mixed-c16-11592154271-review.stderr')
receipt.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
assert before == after
print(json.dumps(dict(exit_code=result.returncode, receipt=str(receipt), receipt_sha256=sha(receipt), frozen_files_unchanged=True)))
raise SystemExit(result.returncode)
