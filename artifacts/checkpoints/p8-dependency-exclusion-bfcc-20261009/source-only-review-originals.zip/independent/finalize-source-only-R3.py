#!/usr/bin/env python3
"""Independent immutable Git/tree source review and evidence packaging only."""
import ast, copy, datetime, hashlib, json, stat, zipfile
from pathlib import Path, PurePosixPath
ROOT=Path(__file__).resolve().parent
FINAL=ROOT.parent/'final-R3'
V3=Path('/dev/shm/todo-audit-H-dependency-exclusion-v3')
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def write(p,d):
    with p.open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2,sort_keys=True);f.write('\n')
def desc(p,member=None):
    b=p.read_bytes();r={'path':str(p),'bytes':len(b),'sha256':sha(b),'git_blob':oid('blob',b)}
    if member:r['support_member']=member
    return r
# Recompute exactly the independently reviewed P2->R2->G2->H tree prefix.
# Only the pre-specification statements are selected; no output/source writer runs.
mod=ast.parse((ROOT/'verify-actual-P3-tree-and-inputs.py').read_text())
prefix=[]
for node in mod.body:
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='spec' for t in node.targets):break
    prefix.append(node)
ns={'__file__':str(ROOT/'verify-actual-P3-tree-and-inputs.py')}
exec(compile(ast.Module(body=prefix,type_ignores=[]),'<reviewed tree prefix>','exec'),ns)
leaves=ns['leaves'];hash_leaves=ns['hash_leaves'];roots=ns['roots'];old=ns['old']
prior_report=read(ROOT/'actual-P3-independent-tree-input-review.json')
for p,row in prior_report['actual_deltas_from_H'].items():leaves[p]=dict(row['after'])
assert hash_leaves(leaves)['']==prior_report['tree']
roots['P3']=prior_report['tree']
p3leaves=copy.deepcopy(leaves)
meta=json.loads(read(ROOT/'official-P3f-commit.json')['response_content'])
assert meta['sha']=='aac83a8e57d87fa9fe95af16173c68f1dd4fb88e'
assert [x['sha'] for x in meta['parents']]==[prior_report['source']]
fmt=read(ROOT/'independent-v3-manual-format-review.json')
assert fmt['verdict']=='accepted_scoped_format_only' and fmt['runtime']==fmt['rustfmt']=='not_run'
maps=read(ROOT/'actual-P3-independent-complete-inputs.json')
changed=[]
for label,row in zip(('production','tests'),read(V3/'source-manifest.json')['files']):
    p=row['path'];raw=read(ROOT/f'official-P3f-{label}-blob.json')['response_content'].encode()
    assert raw==(V3/'candidate'/p).read_bytes()
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256'] and oid('blob',raw)==row['git_blob']
    assert any(x['path']==p and x['after_sha256']==sha(raw) and x['after_git_blob']==oid('blob',raw) for x in fmt['files'])
    with (ROOT/f'actual-P3f-{label}.raw').open('xb') as f:f.write(raw)
    r={'mode':'100644','type':'blob','sha':oid('blob',raw),'size':len(raw),'sha256':sha(raw)}
    leaves[p]=r;maps['actual_input_mode_blob_inventory'][p]=r;maps['complete_inputs'][p]=sha(raw);maps['paths'][p]['sha256']=sha(raw);changed.append(p)
roots['P3f']=hash_leaves(leaves)['']
assert roots['P3f']==meta['tree']['sha']=='c61707e398739be23b01570af025c412a723689c'
assert all(leaves[p]==r for p,r in p3leaves.items() if p not in changed)
assert len(leaves)==len(p3leaves)==24126
plan=read(V3/'prospective-P3f-complete-product-validation-inputs.json')
assert maps['complete_inputs']==plan['complete_inputs'] and maps['paths']==plan['paths'] and maps['validation_inputs']==plan['validation_inputs']
assert len(maps['complete_inputs'])==1095 and len(maps['paths'])==70 and len(maps['validation_inputs'])==142
assert maps['validation_inputs']==old['validation_inputs']
for p,r in maps['actual_input_mode_blob_inventory'].items():
    assert all(r[k]==leaves[p][k] for k in ('mode','type','sha'))
    assert r['sha256']==(maps['complete_inputs']|maps['validation_inputs'])[p]
    if p not in changed:assert r==old['actual_input_mode_blob_inventory'][p]
assert all(set(v)=={'before_sha256','sha256'} and v['sha256']==maps['complete_inputs'][p] for p,v in maps['paths'].items())
assert {p:v for p,v in maps['paths'].items() if p not in changed}=={p:v for p,v in old['paths'].items() if p not in changed}
for p in changed:assert maps['paths'][p]['before_sha256']==old['paths'][p]['before_sha256']
maps.update(source=meta['sha'],tree=meta['tree']['sha'],source_parents=[x['sha'] for x in meta['parents']])
write(ROOT/'actual-P3f-independent-complete-inputs.json',maps)
proof={'schema':'actual-P3f-independent-tree-input-review-v1','source':meta['sha'],'tree':meta['tree']['sha'],'source_parents':maps['source_parents'],'reviewer':'/root/execution_recon','root_reconstruction':roots,'source_count':1095,'validation_count':142,'BASE_delta_count':70,'complete_leaf_count':len(leaves),'actual_changed_paths_from_P3':changed,'all_other_P3_leaves_preserved':True,'retained_product_inputs_from_R2':1093,'retained_BASE_deltas_from_R2':68,'validation_changes':0,'current_source_execution':'runtime_not_run','rustfmt_execution':'not_run','prior_source_semantics':'independent-P3-source-semantics.json','formatting_peer':'independent-v3-manual-format-review.json','source_body_or_holdout_data_execution':False,'no_holdout_body_read':True,'derived_tree_not_official_recursive_response':True}
write(ROOT/'actual-P3f-independent-tree-input-review.json',proof)
sem=read(ROOT/'independent-P3-source-semantics.json')
reviewers={}
for p in maps['paths']:
    iv=maps['actual_input_mode_blob_inventory'][p]
    reviewers[p]={'reviewer':'/root/execution_recon','mode':iv['mode'],'git_blob':iv['sha'],'sha256':maps['complete_inputs'][p],'before_sha256':maps['paths'][p]['before_sha256'],'execution_credit_to_current_source':False}
    if p in changed:
        reviewers[p].update(review_kind='Direct new query/test semantic review plus exact manual-format bridge to actual P3f',semantic_review=sem['reviewed_paths'][p],formatting_bridge=desc(ROOT/'independent-v3-manual-format-review.json','independent/independent-v3-manual-format-review.json'),current_byte_identity=iv)
    else:
        reviewers[p].update(review_kind='Exact retained path/mode/Gitblob/SHA and BASE before/after from independently accepted canonical R2',semantic_review=old['source_path_reviewers'][p],prior_review_source=old['source'],prior_review_commit='cd68f3ecf384a3da5e1186c27b1f3ff328bafca4',inheritance_limit='Only exact source semantics inherited; prior native, CI, study and timing evidence remain bound to their original source identities.')
validation_reviewers={}
for p in maps['validation_inputs']:
    iv=maps['actual_input_mode_blob_inventory'][p]
    validation_reviewers[p]={'reviewer':'/root/execution_recon','mode':iv['mode'],'git_blob':iv['sha'],'sha256':maps['validation_inputs'][p],'review_kind':'Exact retained validation domain; original source gate, CI, budgets, failure controls and workload unchanged','semantic_review':old['validation_path_reviewers'][p],'execution_credit_to_current_source':False}
FINAL.mkdir(exist_ok=False)
canonical_path='artifacts/checkpoints/p8-dependency-exclusion-bfcc-20261009/independent-source-review.json'
canonical={'schema_version':1,'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':old['base'],'source':meta['sha'],'source_tree':meta['tree']['sha'],'tree':meta['tree']['sha'],'source_parent':prior_report['source'],'source_parents':maps['source_parents'],'scope':'independently_reviewed_source_and_validation_inputs','verdict':'accepted_scoped','independent_reviewers':['/root/execution_recon'],'unresolved_blockers':[],
 'author_independence':{'reviewer':'/root/execution_recon','candidate_author':'/root/todo_audit','source_commit_creator':'/root','additional_source_peer':'/root/pr_triage','reviewer_authored_current_product_or_validation_changes':False,'role_limit':'Reviewer wrote only independent review/verification/evidence-packaging artifacts; no product/validation source changes or product execution.'},
 'complete_input_count':1095,'changed_source_input_count':70,'validation_input_count':142,'paths':maps['paths'],'complete_inputs':maps['complete_inputs'],'validation_inputs':maps['validation_inputs'],'actual_input_mode_blob_inventory':maps['actual_input_mode_blob_inventory'],'source_modes':{p:maps['actual_input_mode_blob_inventory'][p]['mode'] for p in maps['complete_inputs']},'validation_modes':{p:maps['actual_input_mode_blob_inventory'][p]['mode'] for p in maps['validation_inputs']},'source_path_reviewers':reviewers,'validation_path_reviewers':validation_reviewers,
 'review_basis':{'method':'Independent official actual P3/P3f commit and exact changed blob reads; complete tree rehash P2->R2->G2->H->P3->P3f;1237 product/validation path/mode/blob/SHA checked,1093 product and all142 validation retained;68 BASE deltas retained, two exact BASE-before/current-after updated. New query/test semantics reviewed directly and final format-only token bridge independently checked. No full checkout or holdout-body read claimed.','actual_tree_input_review':desc(ROOT/'actual-P3f-independent-tree-input-review.json','independent/actual-P3f-independent-tree-input-review.json'),'direct_semantic_review':desc(ROOT/'independent-P3-source-semantics.json','independent/independent-P3-source-semantics.json'),'prior_R2':{'commit':'cd68f3ecf384a3da5e1186c27b1f3ff328bafca4','repository_path':'artifacts/checkpoints/p8-final-main-integration-bfcc-20261009/independent-source-review.json',**desc(ROOT.parent/'final-R2/independent-source-review.json','inherited/canonical-R2.original.json')},'formatting':{'method':'Manual whitespace and exactly6 optional trailing commas, read and token-compared; no rustfmt execution claimed.','report':desc(ROOT/'independent-v3-manual-format-review.json','independent/independent-v3-manual-format-review.json')},'retained_validation':'Original142 validation and original CI selector remain exact; only subsequent new R/G identity bindings may be installed by root.','full_worktree_materialization_claim_by_reviewer':False,'holdout_body_read':False},
 'current_execution_support':{'acceptance_by_this_report':False,'status':'runtime_not_run','Rust_compile':'not_run','Rust_tests':'not_run','rustfmt':'not_run','Clippy':'not_run','source_integrity_suite':'not_run','selected_v15_on_current_source':'not_run','CI_on_current_source':'not_run','scale_or_performance_on_current_source':'not_run','pending_original_integration_tests':read(Path('/dev/shm/todo-audit-P3-H-d22-candidate-plan/existing-CI-coverage-and-R3-boundary.json'))['integration_target'],'scope':'Source-only admission review permits subsequent original engineering controls. No scheduled/check status is represented as execution and no prior H/P2/G1/Gc8 result is relabelled.','prior_execution_boundary':desc(ROOT/'prior-execution-and-native-outage-boundary.json','independent/prior-execution-and-native-outage-boundary.json')},
 'prior_SQL_probe':sem['prior_sql_probe'],
 'acceptance_boundary':{'source_level_acceptance_only':True,'source_admission_contract':sem['source_admission_contract'],'unresolved_blockers_scope':'No unresolved source-semantic or identity blocker found. Unexecuted Rust/fmt/Clippy/CI/performance evidence remains explicitly pending, not manufactured as passed.','performance_limits':sem['reviewed_paths'][changed[0]]['limitations'],'no_universal_speedup':True,'counterexample':{'fixture':'Python SQLite3.53.1, scattered2500 exclusions, two keys','old_VM_progress_callbacks':132988,'new_VM_progress_callbacks':163001,'increase_percent_rounded':22.57,'Rust_or_wall_time_measurement':False},'original_study':sem['unchanged_scope'],'prior_H_v15_credit_to_current_source':False,'DB_acquisition_C1_C4_credit_to_current_source':False,'source_fix_is_not_proof_of_Gc8_deadline_repair':True,'new_TODO_completed':0,'TODO_done':163,'TODO_remaining':29,'no_remote_action_new_workflow_or_new_study_by_reviewer':True,'new_source_specific_runtime_required_for_any_future_runtime_claim':True,'documentation':'Exact main d22 docs/BENCHMARK.md retained; no P8-014 completion/LLM execution inferred.','formal_failure_checkpoint_locator':{'commit':'a914160ab328c63c02a87e00362beb63c02ecd11','prefix':'artifacts/checkpoints/p8-round17-progress-bfcc-20261009','provenance':'Root notified successful persistent checkpoint; original terminal Gc8 receipts already reviewed separately. No large failure ZIP duplicated here.'}}}
assert canonical['source']==meta['sha'] and canonical['unresolved_blockers']==[]
assert canonical['verdict']=='accepted_scoped' and canonical['scope']=='independently_reviewed_source_and_validation_inputs'
assert len(canonical['source_path_reviewers'])==70 and len(canonical['validation_path_reviewers'])==142
write(FINAL/'independent-source-review.json',canonical)
# Selection retains complete current/source-only evidence plus old negative SQL
# and prior semantic byte chain; prior native execution ZIPs remain Git locators.
selected={}
def add(p,name,expected=None):
    p=Path(p);assert p.is_file() and not p.is_symlink();b=p.read_bytes()
    if expected:assert len(b)==expected['bytes'] and sha(b)==expected['sha256']
    assert name not in selected
    selected[name]={'local_path':str(p),'archive_path':name,'bytes':len(b),'sha256':sha(b),'git_blob':oid('blob',b),'POSIX_mode':oct(stat.S_IMODE(p.stat().st_mode))}
for p in sorted(ROOT.iterdir()):
    if p.is_file() and p.name not in ('finalize.stdout','finalize.stderr','finalize.exit'):add(p,'independent/'+p.name)
for folder,label,selection in [('/dev/shm/todo-audit-H-dependency-exclusion','author-v1','archive-selection.json'),('/dev/shm/todo-audit-H-dependency-exclusion-v2','author-v2','archive-selection.json'),('/dev/shm/todo-audit-H-dependency-exclusion-v3','author-v3','archive-selection.json'),('/dev/shm/pr-triage-H-dependency-exclusion-peer','source-peer','archive-selection.v2.json')]:
    folder=Path(folder);s=read(folder/selection)
    for row in s['files']:
        p=Path(row['path']);relative=row.get('relative_path',p.relative_to(folder).as_posix());add(p,label+'/'+relative,row)
    add(folder/selection,label+'/'+selection)
for p,name in [(ROOT.parent/'final-R2/independent-source-review.json','inherited/canonical-R2.original.json'),(Path('/dev/shm/todo-audit-G2-cd68-binding/generated/scripts/verify_reviewed_source_v15.py'),'contract/original-v15-guard.py'),(Path('/dev/shm/todo-audit-P3-H-d22-candidate-plan/original-ci.yml'),'contract/original-ci.yml'),(Path('/dev/shm/todo-audit-P3-H-d22-candidate-plan/existing-CI-coverage-and-R3-boundary.json'),'contract/existing-CI-and-runtime-boundary.json'),(ROOT.parent/'H-package-round17-pending-recovery.json','prior-native/pending-recovery.original.json')]:add(p,name)
selection={'schema':'source-only-actual-P3f-R3-support-selection-v1','source':meta['sha'],'tree':meta['tree']['sha'],'runtime_status':'not_run','native_tunnel_calls':0,'files':list(selected.values()),'file_count':len(selected),'total_bytes':sum(x['bytes'] for x in selected.values()),'canonical_uploaded_separately':desc(FINAL/'independent-source-review.json'),'large_original_native_or_scale_ZIPs_duplicated':False,'TODO_remaining':29}
write(FINAL/'support-selection.json',selection)
zip_path=FINAL/'source-only-review-originals.zip'
with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,row in selected.items():
        p=Path(row['local_path']);raw=p.read_bytes();assert sha(raw)==row['sha256']
        info=zipfile.ZipInfo(name,(2026,10,9,0,0,0));info.create_system=3;info.external_attr=(stat.S_IFREG|int(row['POSIX_mode'],8))<<16;info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,raw)
    z.write(FINAL/'support-selection.json','support-selection.json')
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None and len(z.infolist())==len(selected)+1
    for name,row in selected.items():
        raw=z.read(name);assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
        assert stat.S_IMODE(z.getinfo(name).external_attr>>16)==int(row['POSIX_mode'],8)
    assert z.read('support-selection.json')==(FINAL/'support-selection.json').read_bytes()
manifest={'schema':'source-only-actual-P3f-R3-upload-manifest-v1','parent_P':meta['sha'],'base_tree':meta['tree']['sha'],'canonical_repository_path':canonical_path,'files':[],'product_count':1095,'BASE_delta_count':70,'validation_count':142,'source_and_validation_paths_changed_by_R':0,'source_only':True,'runtime_status':'not_run','original_TODO_closed':0,'TODO_remaining':29}
for p,repo in [(FINAL/'independent-source-review.json',canonical_path),(zip_path,canonical_path.rsplit('/',1)[0]+'/source-only-review-originals.zip')]:
    d=desc(p);d['local_path']=d.pop('path');d.update(repository_path=repo,mode='100644',type='blob');manifest['files'].append(d)
write(FINAL/'upload-manifest.json',manifest)
print(json.dumps({'source':meta['sha'],'tree':meta['tree']['sha'],'roots':roots,'support_members':len(selected)+1,'support_original_bytes':selection['total_bytes'],'upload_manifest':str(FINAL/'upload-manifest.json'),'files':manifest['files'],'verdict':'accepted_scoped','runtime_status':'not_run','TODO_remaining':29},ensure_ascii=False))
