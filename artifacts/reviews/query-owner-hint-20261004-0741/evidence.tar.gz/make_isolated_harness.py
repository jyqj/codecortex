from pathlib import Path
import json,re,hashlib
root=Path(__file__).resolve().parent
rows=json.loads((root/'neutral-matrix.json').read_text())['rows']
symbol=(root/'symbol.pinned.rs').read_text(); symbol=symbol[symbol.index('/// Symbol kind'):symbol.index('impl std::fmt::Display')]
symbol=symbol.replace(', Serialize, Deserialize','').replace('#[serde(rename_all = "snake_case")]\n','')
dsl=(root/'dsl.pinned.rs').read_text();dsl=dsl[:dsl.index("/// Check if a file extension")]
# These inputs are unit-test tokens, generated using the exact observed FTS
# regex. The real cc-db regex implementation is NOT linked by this harness.
def rs(s):return json.dumps(s,ensure_ascii=False)
def opt(s):return 'None' if s is None else 'Some('+rs(s)+')'
for arm in ['baseline','candidate']:
 source=(root/('query_target.pinned.rs' if arm=='baseline' else 'candidate/crates/cc-search/src/query_target.rs')).read_text()
 source=source[:source.index('#[cfg(test)]')]
 tests=['#[cfg(test)]\nmod isolated_matrix {\nuse super::*;\n']
 for i,row in enumerate(rows):
  testname=re.sub('[^a-zA-Z0-9_]','_',row['id'])
  tests += [f'#[test]\nfn case_{i:03}_{testname}() {{\n',f'let raw = {rs(row["query"])};\n','let parsed=crate::dsl::parse_search_dsl(raw);\nlet target=QueryTarget::parse(&parsed);\n', 'let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };\n',f'assert_eq!(model,{rs(row["expected_target_model"])},"target: {{raw}}");\n']
  if arm=='candidate':
   tests += ['let context=NameBonusContext::parse(&parsed,&target);\n',f'assert_eq!(context.contextual_owner.as_deref(),{opt(row["expected_context_owner"])},"context: {{raw}}");\n']
  if row['probes']:
   tokens=[t.lower() for t in re.findall(r'[A-Za-z0-9_]+|[\u4e00-\u9fff]{1,8}',row['query'])]
   tests += ['let tokens:Vec<String>=vec!['+','.join(rs(t)+'.into()' for t in tokens)+'];\n']
   for probe in row['probes']:
    expected=probe['expected_bonus']
    if arm=='baseline':expected=probe['name'].lower() in tokens
    gate=' && context.permits('+rs(probe['name'])+','+opt(probe['kind'])+')' if arm=='candidate' else ''
    tests += ['assert_eq!(target.permits('+rs(probe['name'])+','+opt(probe['kind'])+',&tokens)'+gate+','+str(expected).lower()+',"probe: {raw}");\n']
  tests += ['}\n']
 tests+=['}\n']
 harness='#![allow(dead_code)]\nextern crate self as cc_model;\npub mod symbol {\n'+symbol+'\n}\nmod dsl {\n'+dsl+'\n}\nmod query_target {\n'+source+'\n'+''.join(tests)+'\n}\n'
 (root/f'isolated_{arm}.rs').write_text(harness)
(root/'receipts'/'isolated-harness-scope.json').write_text(json.dumps({'scope':'actual query_target/context and DSL parser source; SymbolKind serialization derives removed; precomputed unit-token inputs; no Cargo, serde, cc-db regex, SearchPlan, index, engine, MCP, normalizer, or scorer linked','matrix_rows':len(rows),'bonus_probes_per_arm':sum(len(r['probes']) for r in rows),'baseline_expected_bonus':'historical target eligibility','candidate_expected_bonus':'neutral-matrix contract','source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'query_target.pinned.rs',root/'candidate/crates/cc-search/src/query_target.rs',root/'dsl.pinned.rs',root/'symbol.pinned.rs',root/'neutral-matrix.json',root/'isolated_baseline.rs',root/'isolated_candidate.rs']}},indent=2)+'\n')
print('Prepared baseline/candidate harnesses with 91 matrix tests and 342 bonus assertions per arm')
