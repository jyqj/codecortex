from pathlib import Path,PurePosixPath
import hashlib,json,zipfile,stat,datetime
BASE=Path("/workspace/scratch/bfccb8494ba0")
OUT=Path("/dev/shm/pr-triage-round14-H2-publication")
NATIVE=BASE/"root-round14/native-H2-transfer/native-public-api-H-and-H2-original-v15.zip"
PEER=Path("/dev/shm/todo-audit-pr180-mainb941-H2-readback.zip")
HIST=BASE/"scale-intake-primary/H-historical-input-preparation.zip"
EXTRACTED=NATIVE.parent/"extracted"
H2="e5640904298febdf8dc951e0baddb2819f930c0b"
P="c92eb5ac7ece70d1f62271d7e2dacac513c285b5"
R="f89d5feec91ae611d52614b8fe217bcd7fd5cf64"
def h(b):return hashlib.sha256(b).hexdigest()
def gb(b,t="blob"):return hashlib.sha1(t.encode()+b" "+str(len(b)).encode()+b"\0"+b).hexdigest()
def desc(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=h(b),git_blob=gb(b))
def verify_zip(p,expected_sha,manifest_name,manifest_list,key):
 assert h(p.read_bytes())==expected_sha
 rows={};data={}
 with zipfile.ZipFile(p) as z:
  for i in z.infolist():
   assert "\0" not in i.orig_filename and i.filename==i.orig_filename
   n=PurePosixPath(i.filename);assert not n.is_absolute() and ".." not in n.parts and not i.is_dir()
   assert str(n)==i.filename and i.filename not in rows and not stat.S_ISLNK(i.external_attr>>16)
   b=z.read(i);assert len(b)==i.file_size
   data[i.filename]=b;rows[i.filename]=dict(path=i.filename,bytes=len(b),sha256=h(b),crc32=i.CRC,mode=oct((i.external_attr>>16)&0o777))
 m=json.loads(data[manifest_name]);items=m[manifest_list];expected={}
 for e in items:
  name=e[key];assert name not in expected;expected[name]=e
 assert set(data)==set(expected)|{manifest_name}
 for name,e in expected.items():
  assert len(data[name])==e["bytes"] and h(data[name])==e["sha256"],name
 return data,dict(**desc(p),member_count=len(data),selected_count=len(items),expanded_bytes=sum(len(v) for v in data.values()),all_members_crc_and_manifest_hash_verified=True,members=list(rows.values()))
native,nv=verify_zip(NATIVE,"c9964b0317c81847b21a323f08373cffd40df9541cda9cd27086deb22a11a5b9","archive-manifest.json","files","path")
peer,pv=verify_zip(PEER,"1cc692a5b7e951131e9d374def9210351f86e3cf098aa2239c313ea3653debb7","archive-selection.json","entries","archive_path")
hist,hv=verify_zip(HIST,"c09bfee37f45d4223e414e31dfcae90eb8838e3af9e14dacb35f49fe56da7d57","scale-intake-primary/H-historical-input-preparation/archive-selection.json","files","path")
assert nv["member_count"]==58 and nv["selected_count"]==57
for n,b in native.items():assert (EXTRACTED/n).read_bytes()==b,n
def j(name):return json.loads(native["H2-admission/"+name])
def parse_tree(raw):
 d={}
 for e in raw.split(b"\0"):
  if not e:continue
  left,name=e.split(b"\t",1);mode,kind,blob=left.decode().split()
  assert kind=="blob" and name.decode() not in d
  d[name.decode()]={"mode":mode,"git_blob":blob}
 return d
r=j("original-v15-command-receipt.json")
assert type(r["exit_code"]) is int and r["exit_code"]==0
assert "controller_exception" not in r and "controller_timeout_seconds" not in r
assert r["argv"]==["python3","scripts/verify_reviewed_source_v15.py","--source-version","p8-completion-source-20261009-v15"]
assert r["source_H2"]==H2 and r["product_P"]==P and r["review_R"]==R
assert r["parent_head_before"]==r["parent_head_after"]
for k in ("stdout","stderr","domain_before","domain_after"):
 b=native["H2-admission/"+r[k]["path"]]
 assert len(b)==r[k]["bytes"] and h(b)==r[k]["sha256"]
assert native["H2-admission/original-v15.stderr"]==b""
stdout=j("original-v15.stdout")
assert stdout["status"]=="passed" and stdout["complete_inputs"]==1093
assert stdout["product_source"]==P and stdout["review_source"]==R
assert stdout["source_version"]=="p8-completion-source-20261009-v15"
assert stdout["executed_previous_proof"]==stdout["previous_source_version"]=="p8-oracle-compat-source-20261008-v14"
before=j("original-v15-domain-before.json");after=j("original-v15-domain-after.json");complete=j("complete-domain-before-v15.json")
assert before==after and native["H2-admission/original-v15-domain-before.json"]==native["H2-admission/original-v15-domain-after.json"]
assert before["head"]==before["source_H2"]==H2 and complete["source_H"]==H2
rows={x["path"]:x for x in before["entries"]};assert len(rows)==len(before["entries"])==1435
assert before["entries"]==complete["entries"]
initial=j("initial-domain-receipt.json");protected=j("historical-protection-inputs.json")
union={x["path"]:x for x in initial["entries"]}
for x in protected["entries"]:
 if x["path"] in union:assert x==union[x["path"]]
 union[x["path"]]=x
assert union==rows and len(initial["entries"])==1246 and len(protected["entries"])==236
initial_tree=parse_tree(native["H2-admission/official-initial-domain-ls-tree.stdout"])
protected_tree=parse_tree(native["H2-admission/current-H-protected-ls-tree.stdout"])
base_tree=parse_tree(native["H2-admission/original-BASE-protected-ls-tree.stdout"])
assert protected_tree==base_tree and len(protected_tree)==236
for source,entries in [(initial_tree,initial["entries"]),(protected_tree,protected["entries"])]:
 assert set(source)=={x["path"] for x in entries}
 for x in entries:assert source[x["path"]]=={k:x[k] for k in ("mode","git_blob")}
commit=native["H2-admission/actual-H-object.stdout"];assert gb(commit,"commit")==H2
header=commit.split(b"\n\n",1)[0].decode().splitlines()
assert header[0]=="tree 73b93b60865daf5d9b6b02afa8974688c64191a4"
assert [x[7:] for x in header if x.startswith("parent ")]==["399a71a4c11e7041ce9946fba4d3f72200c47155","b9412406e11422d7cf914458a8bfbbd58cf94eaa"]
canonical_path=BASE/"scale-intake-primary/round14-actual-P-independent/independent-source-review.json"
canonical=json.loads(canonical_path.read_bytes());assert h(canonical_path.read_bytes())=="9fa93a69e2e4be49f1262ff349fcddad18967a5c8e732144292456a24751208f"
assert len(canonical["complete_inputs"])==1093 and len(canonical["validation_inputs"])==139
for group in ("complete_inputs","validation_inputs"):
 for path,sha in canonical[group].items():
  x=rows[path];origin=canonical["actual_input_mode_blob_inventory"][path]
  assert x["sha256"]==sha==origin["sha256"] and x["git_blob"]==origin["sha"] and x["mode"]==origin["mode"] and x["bytes"]==origin["size"]
peerproof=json.loads(peer["actual-H2-readback.json"])
assert peerproof["actual_H2"]["commit"]==H2 and peerproof["actual_H2"]["tree"]=="73b93b60865daf5d9b6b02afa8974688c64191a4"
assert peerproof["all_1093_product_139_validation_mode_blobs_equal_actual_P"] is True
peerprotected=json.loads(peer["H2-historical-protected-mode-blob-bridge.json"])
assert {x["path"]:{k:x[k] for k in ("mode","git_blob")} for x in peerprotected["records"]}==protected_tree
preparation=[]
for branch in ["H-preparation","H2-admission"]:
 for name in ["initial-preparation-receipts.json","history-preparation-commands.json"]:
  commands=json.loads(native[branch+"/"+name])
  for c in commands:
   assert type(c["exit_code"]) is int and c["exit_code"]==0
   for stream in ("stdout","stderr"):
    e=c[stream];b=native[branch+"/"+e["path"]];assert len(b)==e["bytes"] and h(b)==e["sha256"]
   preparation.append({"scope":branch,"label":c["label"],"exit_code":c["exit_code"]})
assert not any(n.startswith("H-preparation/original-v15") for n in native)
controller=native["H2-admission/run-original-v15-controller.py"].decode()
assert "subprocess.Popen(argv,cwd=root,env=env,stdout=so,stderr=se)" in controller and "code=p.wait(timeout=2700)" in controller
assert "r['exit_code']=code" in controller
review={
"schema_version":1,"reviewed_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
"verdict":"accepted_original_H2_selected_v15_execution_evidence",
"scope":"Independent read-only recheck of retained originals, not a validator or native workload replay.",
"source_H2":H2,"source_tree":"73b93b60865daf5d9b6b02afa8974688c64191a4","ordered_parents":["399a71a4c11e7041ce9946fba4d3f72200c47155","b9412406e11422d7cf914458a8bfbbd58cf94eaa"],
"product_P":P,"review_R":R,"guard_G":r["guard_G"],
"native_command":r,"original_stdout":stdout,
"checks":{"native_ZIP_selected_files":57,"native_ZIP_members":58,"all_57_original_manifest_SHA_and_CRC":True,"extracted_bytes_equal_ZIP":True,"actual_commit_object_rehashed":True,"selected_before_after_count":1435,"selected_before_after_exact_bytes":True,"selected_before_after_sha256":r["domain_before"]["sha256"],"initial_count":1246,"historical_count":236,"overlap_count":47,"union_count":1435,"all_input_mode_blob_equal_retained_actual_git_ls_tree":True,"canonical_product_count":1093,"canonical_validation_count":139,"all_canonical_inputs_mode_blob_SHA_match_native_before_after":True,"historical_236_match_immutable_BASE_and_peer":True,"parent_checkout_unchanged":True,"actual_integer_child_exit":0,"stdio_hashes_bound":True,"previous_v14_executed_per_actual_original_stdout":True},
"preparation_commands":preparation,
"H_boundary":{"source":"399a71a4c11e7041ce9946fba4d3f72200c47155","status":"preparation_only","native_v15_execution_credit":False},
"execution_limits":["This is the selected original v15 CLI including its previous v14 proof. It is not the 181-method Python suite, Rust engineering tests, scale study, DB-wait measurement or TODO completion.","The frozen controller has a 2700-second outer safety timeout; the child completed normally in 618.988764334 seconds and no timeout path was taken. Original CLI argv and source input bytes are bound; no command re-executed in this review.","Actual execution was on Mac using /usr/bin/python3. This review is on the separate primary Linux host using retained evidence, not a claim that native files were freshly read here.","1435 is the selected current source/validation/CI/binding/review/historical domain, not the entire repository. 236 protected historical entries are the original declared inputs; this archive does not add undeclared holdout body execution.","Subsequent combined P3ced and any corrective source/controls are separate; this report gives them no pass or source credit."],
"canonical_R_reference":desc(canonical_path),
"supporting_archive_identities":[{k:v for k,v in x.items() if k!="members"} for x in [nv,pv,hv]],
"task_ledger":{"done":163,"remaining":29,"new_completions":0}
}
def save(n,v):
 with (OUT/n).open("x") as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write("\n")
save("independent-H2-original-v15-review.json",review)
save("existing-three-archive-byte-verification.json",{"schema_version":1,"scope":"CRC and original manifest validation only; no workload or original validator replay","archives":[nv,pv,hv],"exit_code":0})
print(json.dumps({"status":review["verdict"],"native_members":58,"selected_inputs":1435,"canonical_product_validation":[1093,139],"exit_code":0}))

