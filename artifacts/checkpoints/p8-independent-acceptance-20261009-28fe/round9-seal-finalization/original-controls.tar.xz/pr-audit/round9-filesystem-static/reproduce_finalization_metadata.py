"""Independent tiny synthetic-controller fault controls; not native acceptance."""
from pathlib import Path
import argparse,contextlib,hashlib,io,json,shutil,sys,unittest
from unittest import mock
p=argparse.ArgumentParser();p.add_argument('--scripts',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(a.scripts));sys.path.insert(0,str(a.scripts/'tests'))
import p8_runtime as runtime
from test_p8_runtime import RuntimeDriverControls

def sha(b):return hashlib.sha256(b).hexdigest()
results=[]
for case in ('inventory_disappeared','postseal_inventory_changed'):
 helper=RuntimeDriverControls();args,identity=helper.prepare_control(0);saved={};original_seal=runtime.seal_output
 def bad_seal(root):
  saved['preseal_report']=(Path(root)/'report.json').read_bytes()
  if case=='inventory_disappeared':raise FileNotFoundError('independent synthetic disappearing inventory path')
  value=original_seal(root);saved['seal']=(Path(root)/'seal.json').read_bytes();(Path(root)/'late-file.txt').write_text('independent synthetic post-seal addition\n');return value
 argv=['p8_runtime.py','--binary',str(args.binary),'--oracle',str(args.oracle),'--statistics',str(args.statistics),'--build-receipt',str(args.build_receipt),'--output',str(args.output),'--profile','mixed','--concurrency','1','--operations','60','--files','8','--interval-ms','1']
 stdout=io.StringIO();stderr=io.StringIO()
 try:
  with mock.patch.object(runtime,'verify_build',return_value=identity),mock.patch.object(runtime,'verify_receipt',return_value=identity['build_identity']),mock.patch.object(runtime,'seal_output',side_effect=bad_seal),mock.patch.object(sys,'argv',argv),contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
   code=runtime.main()
  final=json.loads((args.output/'report.json').read_bytes());before=json.loads(saved['preseal_report'])
  dest=a.output/case;shutil.copytree(args.output,dest/'runtime');(dest/'stdout.log').write_text(stdout.getvalue());(dest/'stderr.log').write_text(stderr.getvalue());(dest/'preseal-report-original.json').write_bytes(saved['preseal_report'])
  if 'seal' in saved:(dest/'first-seal-original.json').write_bytes(saved['seal'])
  entries={f.relative_to(dest).as_posix():{'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in dest.rglob('*') if f.is_file()}
  results.append(dict(case=case,cli_exit=code,preseal_status=before['status'],preseal_exit=before['exit_code'],preseal_seal_status=before['artifact_seal_status'],final_status=final['status'],final_exit=final['exit_code'],final_seal_status=final['artifact_seal_status'],final_report_misleads_success=final['exit_code']==0,original_seal_exists='seal' in saved,seal_at_original_path_unchanged=('seal' not in saved or ((args.output/'seal.json').is_file() and (args.output/'seal.json').read_bytes()==saved['seal'])),terminal_rows=sum(json.loads(l).get('kind')=='operation' for l in (args.output/'raw.jsonl').read_text().splitlines()),stderr=stderr.getvalue(),files=entries))
 finally:helper.doCleanups()
report=dict(scope='Synthetic executables and mocked build admission; actual driver main/run/cleanup/replay/report, actual seal and verify in postseal case. Not native performance or original-workload acceptance.',runtime_sha256=sha(Path(runtime.__file__).read_bytes()),test_helper_sha256=sha((a.scripts/'tests/test_p8_runtime.py').read_bytes()),script_sha256=sha(Path(__file__).read_bytes()),results=results)
(a.output/'results.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='results'}));print(json.dumps([{k:v for k,v in r.items() if k!='files'} for r in results]))
