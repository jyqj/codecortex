from pathlib import Path
import sys,os,json,hashlib,subprocess,datetime,collections
ROOT=Path(__file__).resolve().parent
REC=ROOT.parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(REC/'source/scripts'))
import p8_scale_matrix as m
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,ensure_ascii=False);f.write('\n')
assert sha(REC/'source/scripts/p8_scale_matrix.py')=='f169b0f26cf2a87d3e2548d734431c530cbf63d353ac054045ec8be80889f957'
assert sha(REC/'source/scripts/p7_build_identity.py')=='5003305105464936edf8f444fc0b93cd14a5d5f074dc650f16de2259e86f1cc5'
d=ROOT/'extracted';before=m.inventory(d)
s=m.read_json(d/'shard.json');n=m.read_json(d/'native/report.json')
assert s['files']==m.inventory(d,('shard.json',))
assert (s['source_commit'],s['status'],s['exit_code'])==('c8be5afaac568ffd40ef86d3795423c3b73c9f39','failed',3)
assert n['status']=='deadline_exceeded' and n['exit_code']==3 and n['worker_exit_code'] is None
snap=m.read_json(d/'source-before.json');m.validate_snapshot(snap)
assert snap==m.read_json(d/'source-after.json') and snap['manifest_sha256']==s['source_manifest_sha256']
plan=s['plan'];expected=m.registered_plan(100000,0,30,30,12648430,18000000,'scale_capacity_v1')
assert m.exact_equal(plan,expected) and plan==m.read_json(d/'native/plan.json')==m.read_json(d/'registered-plan.json')
raw=(d/'native/raw.jsonl').read_bytes();assert raw.endswith(b'\n')
events=[m.decode(line) for line in raw.splitlines()];types=collections.Counter(x['event'] for x in events)
starts={x['label']:x for x in events if x['event']=='build_started'}
builds={x['label']:x for x in events if x['event']=='build_finished'}
assert len(starts)==types['build_started'] and len(builds)==types['build_finished']
for label,x in builds.items():assert x['start_us']==starts[label]['start_us'] and x['wall_us']==x['end_us']-x['start_us']
unfinished={k:v for k,v in starts.items() if k not in builds}
assert list(unfinished)==['scale-100000/repetition-0/batch_10/full_control']
phases={}
for x in builds.values():
 label=x['label'].split('/')[2]
 a=phases.setdefault(label,{'finished_builds':0,'full_builds':0,'incremental_builds':0,'build_wall_us':0,'full_build_wall_us':0,'incremental_build_wall_us':0,'reported_full_staging_us':0,'timing_us':{},'phase_ms':{}})
 a['finished_builds']+=1;a['full_builds' if x['full'] else 'incremental_builds']+=1;a['build_wall_us']+=x['wall_us'];a['full_build_wall_us' if x['full'] else 'incremental_build_wall_us']+=x['wall_us']
 for k,v in x['report']['build_timing'].items():
  if k=='schema_version' or v is None:continue
  a['timing_us'][k]=a['timing_us'].get(k,0)+v
  if k=='full_staging_us':a['reported_full_staging_us']+=v
 for k,v in x['report']['phase_timing'].items():a['phase_ms'][k]=a['phase_ms'].get(k,0)+v
parities=[]
for x in events:
 if x['event'] not in ('cold_parity','stage_finished'):continue
 p=x['parity'];assert p['equal'] is True and p['different_tables']==[]
 parities.append({'event':x['event'],'label':x.get('label',x.get('sample')+'/cold_parity'),'parity_wall_us':x['parity_wall_us'],'status':p['status'],'equal':p['equal'],'tables':p['tables'],'canonical_bytes':p['canonical_bytes'],'scratch_peak_bytes':p['scratch_peak_bytes'],'full_counts':p['full_counts'],'incremental_counts':p['incremental_counts']})
 # Preserve substage clocks separately: full_staging is nested in build timing.
 if x['event']=='stage_finished':phases[x['label'].split('/')[2]].update({'stage_finished_passed':x['passed'],'stage_incremental_builds':x['incremental_builds'],'outer_incremental_wall_us':x['incremental_wall_us'],'parity_wall_us':x['parity_wall_us']})
out=ROOT/'original-validator-rejection';out.mkdir(exist_ok=False)
argv=[sys.executable,'-B','-c',"import sys;sys.path.insert(0,sys.argv[1]);from p8_scale_matrix import validate_shard;validate_shard(sys.argv[2],None,None,None)",str(REC/'source/scripts'),str(d)]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:
 child=subprocess.run(argv,stdout=so,stderr=se,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
write(out/'receipt.json',{'argv':argv,'exit_code':child.returncode,'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout_sha256':sha(out/'stdout'),'stderr_sha256':sha(out/'stderr'),'scope':'Exact retained validate_shard first status gate; failed record rejects before build/binary arguments are consumed. No full build replay or new measurement. Arguments intentionally unavailable None; not a passed whole validation.'})
assert child.returncode==1 and b'ValueError: shard execution failed or is missing' in (out/'stderr').read_bytes()
after=m.inventory(d);assert before==after
total_parity=sum(x['parity_wall_us'] for x in parities)
review={'schema':'Gc8-first-original-100k-failed-primary-intake-review-v1','reviewer':'/root/execution_recon','source_G':s['source_commit'],'run_id':37902429727,'run_attempt':1,'artifact_id':11617588539,'artifact_original_sha256':sha(ROOT/'p8-scale-shard-100000-0-37902429727-original.zip'),'verdict':'failed_original_primary_retained_not_accepted','native_status':n['status'],'native_exit_code':n['exit_code'],'worker_exit_code':n['worker_exit_code'],'stderr_complete':n['stderr_complete'],'summary':n['summary'],'cleanup':n['fixture_cleanup'],'original_shard_status':s['status'],'original_shard_exit_code':s['exit_code'],'original_outer_job_exit_code':1,'outer_exit_evidence':'github-job-decoded.log 2026-10-09T13:17:14.0863844Z Process completed with exit code 1','native_wall_ms':n['wall_ms'],'registered_deadline_ms':plan['deadline_ms'],'partial_raw_lines':len(events),'event_counts':dict(types),'unfinished_builds':unfinished,'parity_diagnostics':parities,'completed_parity_total_us':total_parity,'completed_parity_fraction_of_registered_deadline':total_parity/(plan['deadline_ms']*1000),'build_stage_diagnostics':phases,'actual_original_validator_rejection':{'exit_code':child.returncode,'message':'shard execution failed or is missing','receipt':'original-validator-rejection/receipt.json'},'sealed_inventory_exact':True,'source_before_after_equal':True,'source_inputs_count':snap['input_count'],'source_manifest_sha256':snap['manifest_sha256'],'plan_exact_registered':True,'original_member_inventory_before':before,'original_member_inventory_after':after,'limits':['No full raw success validation or accepted partial samples; absence of completed batch_10 plus batch_100/batch_1000 and worker-summary prevents completion.','Disk preflight/after are point checks, not peak; no OOM/disk or worker exit diagnosis is inferred.','Native raw BLAKE3 not independently replayed at this step; original sealed SHA256 and ZIP official digest are verified.','Recorded build timings are nested; do not add full_staging_us to full build wall as disjoint costs.','Completed stages and timings support investigation only; do not substitute primary, reduce N, extend budget or relabel source.'],'accepted_shards_unchanged':4,'accepted_measurements_unchanged':41,'expected_shards':150,'expected_measurements':1500,'original_TODOs_closed':0,'TODO_remaining':29}
write(ROOT/'failed-primary-independent-intake-review.json',review)
print(json.dumps({'status':review['verdict'],'original_validate_shard_exit':child.returncode,'raw_lines':len(events),'parity_seconds':total_parity/1e6,'review':str(ROOT/'failed-primary-independent-intake-review.json')}))

