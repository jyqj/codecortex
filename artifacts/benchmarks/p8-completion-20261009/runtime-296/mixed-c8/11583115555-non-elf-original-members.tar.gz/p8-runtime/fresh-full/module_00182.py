def stable_00182():
    return 182
