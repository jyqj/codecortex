# G4 mechanical binding preparation — actual P4, R4 required

This directory prepares only the two unchanged v15 binding-file formats for actual P4 `1930b8e37e24031c3779553e3fc5b95e8e946d50`. It contains no generated G4 files, no placeholder review, no source-admission result and no new product execution.

The generator seeds are the exact installed G3 registry and guard. It requires the official P4 commit metadata, the actual newly created R4 commit metadata with sole parent P4, and the installed canonical R4 bytes/Git blob. Canonical repository path:

`artifacts/checkpoints/p8-completed-dependency-exclusion-ci-format-bfcc-20261009/independent-source-review.json`

R4 must be the real non-author scoped review. The SQL/integration authors and the new formatting-patch author are excluded from signing this current independent review. Historical accepted reviews may remain cited in provenance. The generator refuses null identities, mismatched tree/maps, unresolved source blockers, any changed validation hash, any product change beyond the one original formatted test, or changes to the guard outside PRODUCT, REVIEW, REVIEW_PATH and REGISTRY_SHA256.

After actual R4 exists, root supplies the real review inputs to this existing interface:

```text
python3 generate-g-bindings.py
  --product-inputs actual-P4-mechanical-input-maps.json
  --product-commit-file P4-official-commit.json
  --review-file [actual installed canonical R4 bytes]
  --review-commit-file [actual official R4 commit JSON]
  --review-path artifacts/checkpoints/p8-completed-dependency-exclusion-ci-format-bfcc-20261009/independent-source-review.json
  --review-git-blob [actual installed canonical Git blob]
  --output-directory [new, absent G4 staging directory]
```

Bracketed values above are required future inputs, not valid placeholder values and not an executable launch instruction. Actual R4 and G4 are not created by this preparation. Root controls subsequent Git objects and PR updates. See `original-CI-coverage.md` for the unchanged CI's direct coverage and default-vs-explicit checkout identities.
