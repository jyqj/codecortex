#!/usr/bin/env python3
"""Reconstruct exact already received Git objects for a sparse original driver checkout.
No network, compiler, product execution or validator invocation. Only two files exist.
"""
from pathlib import Path
import datetime,hashlib,json,subprocess,zlib
P=Path(__file__).resolve().parent;S=P/'source-exact-G8B-attempt02';S.mkdir(exist_ok=False)
D=Path('/dev/shm/todo-audit-G8B-cb57d6e3-binding');R=Path('/dev/shm/root-round21')
record=[]
def git(args):
 r=subprocess.run(['git',*args],cwd=S,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 record.append({'argv':['git',*args],'exit_code':r.returncode,'stdout_utf8':r.stdout.decode('utf8','replace'),'stderr_utf8':r.stderr.decode('utf8','replace')})
 if r.returncode:raise RuntimeError('Git command failed')
 return r.stdout
def obj(kind,data):return kind.encode()+b' '+str(len(data)).encode()+b'\0'+data
def oid(kind,data):return hashlib.sha1(obj(kind,data)).hexdigest()
def store(kind,data,expected):
 h=oid(kind,data);assert h==expected,(kind,h,expected)
 target=S/'.git/objects'/h[:2]/h[2:];target.parent.mkdir(exist_ok=True)
 with target.open('xb') as f:f.write(zlib.compress(obj(kind,data)))
 return h
def tree_bytes(entries):
 entries=sorted(entries,key=lambda e:e['path'].encode()+ (b'/' if e['type']=='tree' else b''))
 return b''.join((e['mode'].lstrip('0')+' '+e['path']).encode()+b'\0'+bytes.fromhex(e['sha']) for e in entries)
G=None
for v in json.loads((R/'G8B-created-objects-original.json').read_text())['originals']:
 s=v.get('value',v).get('structuredContent',{});text=s.get('content')
 if text:
  x=json.loads(text)
  if x.get('sha')=='4fe927488d5cb7f26bd27c7624745fb1b6ca202b' and 'parents'in x:G=x
assert G
rt=json.loads(json.loads((D/'R8B-root-tree-tool-response.json').read_text())['structuredContent']['content'])
st=json.loads((D/'reconstructed-actual-G6B-scripts-tree.json').read_text())
assert oid('tree',tree_bytes(rt['tree']))==rt['sha'] and oid('tree',tree_bytes(st['tree']))==st['sha']
assert next(e['sha'] for e in rt['tree'] if e['path']=='scripts')==st['sha']
for name in ('reviewed-source-registry-v15.json','verify_reviewed_source_v15.py'):
 b=(D/'generated/scripts'/name).read_bytes();next(e for e in st['tree'] if e['path']==name)['sha']=oid('blob',b)
newscript=oid('tree',tree_bytes(st['tree']));next(e for e in rt['tree'] if e['path']=='scripts')['sha']=newscript
assert oid('tree',tree_bytes(rt['tree']))==G['tree']['sha']
def signature(v, zone):
 dt=datetime.datetime.fromisoformat(v['date'].replace('Z','+00:00'))
 return f"{v['name']} <{v['email']}> {int(dt.timestamp())} {zone}"
matched=[]
for az in ('+0000','+0800','-0000'):
 for cz in ('+0000','+0800','-0000'):
  header='tree '+G['tree']['sha']+'\n'+''.join('parent '+q['sha']+'\n' for q in G['parents'])+'author '+signature(G['author'],az)+'\ncommitter '+signature(G['committer'],cz)+'\n\n'
  for nl in ('','\n'):
   candidate=(header+G['message']+nl).encode()
   if oid('commit',candidate)==G['sha']:
    matched.append(candidate);recovered_zones={'author':az,'committer':cz,'message_trailing_newline':bool(nl)}
assert len(matched)==1,'Exact original commit bytes could not be recovered; stop'
git(['init','--quiet'])
store('tree',tree_bytes(rt['tree']),G['tree']['sha']);store('tree',tree_bytes(st['tree']),newscript);store('commit',matched[0],G['sha'])
(S/'.git/HEAD').write_text(G['sha']+'\n')
inputs={}
for name in ('p8_scale_matrix.py','p7_build_identity.py'):
 src=Path('/dev/shm/pr-triage-round20-CI-C3ff-M7F/source/scripts')/name;b=src.read_bytes();e=next(e for e in st['tree'] if e['path']==name);store('blob',b,e['sha']);dest=S/'scripts'/name;dest.parent.mkdir(exist_ok=True);dest.write_bytes(b)
 git(['update-index','--add','--cacheinfo',e['mode'],e['sha'],'scripts/'+name])
 assert git(['show',G['sha']+':scripts/'+name])==b
 inputs['scripts/'+name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':e['sha'],'mode':e['mode']}
assert git(['rev-parse','HEAD']).decode().strip()==G['sha']
assert git(['rev-parse','HEAD^{tree}']).decode().strip()==G['tree']['sha']
report={'schema':'exact-two-driver-sparse-Git-checkout-v1','source_G':G['sha'],'source_tree':G['tree']['sha'],'scripts_tree':newscript,'checkout':str(S),'files':inputs,'recovered_zones_verified_by_exact_Git_SHA':recovered_zones,'exact_commit_bytes_sha256':hashlib.sha256(matched[0]).hexdigest(),'source_scope':'Only two driver/helper files and required exact Git objects. Other Git tree references deliberately not materialized. Not full1095product/142validation/whole repository or working-tree cleanliness.','git_commands':record,'network_calls':0,'validator_executions':0,'product_executions':0,'may_support':'Unmodified validate_build default driver_snapshot exact Git check. Never source_snapshot(root) on this sparse checkout.'}
(P/'exact-driver-checkout-review.attempt02.json').write_text(json.dumps(report,indent=2)+'\n');(P/'exact-G8-commit.raw').write_bytes(matched[0]);print(json.dumps({k:report[k] for k in ('source_G','source_tree','scripts_tree','checkout','files','network_calls','validator_executions')}))
