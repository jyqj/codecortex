import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import zipfile
if sys.flags.optimize: raise SystemExit("Assertions required")
HERE = Path(__file__).resolve().parent
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024**2): h.update(b)
 return h.hexdigest()
for row in json.loads((HERE/'expected-artifacts.json').read_text()):
 path=HERE/f"{row['artifact']}.zip"
 assert path.stat().st_size==row['bytes'] and sha(path)==row['sha']
 members={}
 with zipfile.ZipFile(path) as z:
  infos=z.infolist(); assert len(infos)==len({i.filename for i in infos})
  assert sum(i.file_size for i in infos)<=536870912+1024**2
  for i in infos:
   name=PurePosixPath(i.filename)
   assert not i.is_dir() and not name.is_absolute() and '..' not in name.parts and str(name)==i.filename and '\\' not in i.filename
   assert not stat.S_ISLNK(i.external_attr>>16) and not i.flag_bits&1
   h=hashlib.sha256();size=0
   with z.open(i) as f:
    while b:=f.read(1024**2):h.update(b);size+=len(b)
   assert size==i.file_size
   members[i.filename]={'bytes':size,'sha256':h.hexdigest(),'crc32':f'{i.CRC:08x}'}
  receipt=json.loads(z.read('shard.json'));native=json.loads(z.read('native/report.json'))
  assert receipt['files']=={n:{k:v for k,v in r.items() if k!='crc32'} for n,r in members.items() if n!='shard.json'}
  assert receipt['plan']['shard']=={'index':row['index'],'count':30}
 result={'artifact_id':row['artifact'],'zip_sha256':row['sha'],'members':members,'native_report':native,'source_commit':receipt['source_commit'],'shard':receipt['plan']['shard'],'status':'failed_original_metadata_received','scope':'All original ZIP members fully SHA/CRC verified, with no member extraction; no success certification.'}
 assert sha(path)==row['sha']
 with (HERE/f"{row['artifact']}-zip-inspection.json").open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({'artifact':row['artifact'],'shard':row['index'],'members':len(members),'native_status':native['status'],'wall_ms':native['wall_ms']}))
