import ast
import datetime
import hashlib
import json
from pathlib import Path
import zipfile

OUT = Path(__file__).parent
PEER = Path('/workspace/scratch/bfccb8494ba0/todo-audit-round12/gates-Gc8')
ORIGINAL = Path('/workspace/scratch/bfccb8494ba0/pr-triage-primary-recovery/raw-pr178-c8be5afa/11603892263/attempt01/extracted')
CLI = PEER / 'retained-cli'
def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()
def meta(p):
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)}
def read(p):
    return json.loads(p.read_bytes())
selection = read(PEER / 'archive-selection.json')
assert len(selection['entries']) == 32
for e in selection['entries']:
    assert meta(Path(e['path'])) == e
selection_before = sha(PEER / 'archive-selection.json')
for key in ['canonical_R', 'original_zip']:
    assert meta(Path(selection[key]['path'])) == selection[key]
canonical = read(Path(selection['canonical_R']['path']))
report = read(ORIGINAL / 'report.json')
assert report['source']['source_commit'] == 'c8be5afaac568ffd40ef86d3795423c3b73c9f39'
assert report['source']['source_tree'] == '9b031be22a430e51e153cce6e80770ed885818e3'
assert report['source']['inputs'] == canonical['complete_inputs']
assert len(canonical['complete_inputs']) == 1090 and len(canonical['validation_inputs']) == 139
assert sha(ORIGINAL / 'cc-eval') == sha(CLI / 'cc-eval') == report['cli']['executable_sha256'] == 'e21fa0863c18ea447cf060384fc15ffe502ecb24f9a2627e2248c0373b037e9e'
with zipfile.ZipFile(selection['original_zip']['path']) as z:
    infos = [i for i in z.infolist() if not i.is_dir()]
    assert len(infos) == 337 and len({i.filename for i in infos}) == 337
    assert {i.filename for i in infos} == {p.relative_to(ORIGINAL).as_posix() for p in ORIGINAL.rglob('*') if p.is_file()}
    for i in infos:
        data = z.read(i)
        p = ORIGINAL / i.filename
        assert len(data) == p.stat().st_size and hashlib.sha256(data).hexdigest() == sha(p)
replay = read(CLI / 'replay-report-v2.json')
receipt = read(PEER / 'replay-controller-receipt.json')
assert receipt['actual_exit'] == 0
for stream in ['stdout', 'stderr']:
    p = PEER / ('replay-controller.' + stream)
    assert receipt[p.name] == {'bytes': p.stat().st_size, 'sha256': sha(p)}
assert receipt['controller_sha256'] == sha(PEER / 'retained-cli-controller-Gc8-native.py')
old = ast.parse((PEER / 'original-controller-G9f.py').read_text())
new = ast.parse((PEER / 'retained-cli-controller-Gc8-native.py').read_text())
def case_expr(tree):
    return next(n.value for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'cases' for t in n.targets))
assert ast.dump(case_expr(old), include_attributes=False) == ast.dump(case_expr(new), include_attributes=False)
working = CLI / 'inputs-copy-v2'
manifest = {p.relative_to(working).as_posix(): sha(p) for p in working.rglob('*') if p.is_file()}
assert manifest == replay['working_fixture_manifest'] and len(manifest) == 287
assert sum((working / n).stat().st_size for n in manifest) == 209265
assert all(sha(ORIGINAL / n) == h for n, h in manifest.items())
expected = [('quality_failed', 1, 'failed'), ('latency_failed', 1, 'failed'), ('insufficient_samples', 1, 'inconclusive'), ('zero_latency_denominator', 1, 'inconclusive'), ('raw_lock_drift', 2, 'invalid_measurement'), ('bad_policy', 2, 'invalid_measurement'), ('output_overwrite_refusal', 2, None)]
assert len(replay['cases']) == 7
verified_cases = []
for c, (name, code, status) in zip(replay['cases'], expected, strict=True):
    assert c['case'] == name and c['expected_exit_code'] == c['actual_exit_code'] == code
    for stream in ['stdout', 'stderr']:
        assert sha(CLI / ('v2-' + name + '.' + stream + '.log')) == c[stream + '_sha256']
    if status is not None:
        out = CLI / 'outputs-v2' / (name + '.json')
        assert sha(out) == c['output_sha256']
        data = read(out)
        assert data == c['actual_report'] and data['status'] == c['expected_status'] == c['actual_status'] == status
        assert data['exit_code'] == code
    else:
        assert c['existing_report_unchanged'] and c['output_before_sha256'] == c['output_after_sha256'] == sha(CLI / 'outputs-v2/bad_policy.json')
    verified_cases.append({'case': name, 'actual_exit': code, 'status': status, 'stdio_and_output_hashes_verified': True})
six = []
assert len(report['cases']) == 6
for i, c in enumerate(report['cases']):
    assert c['source'] == report['source']
    assert c['build']['exit_code'] == c['execution']['exit_code'] == 0
    for phase in ['build', 'execution']:
        for n, h in c[phase]['logs_sha256'].items():
            assert sha(ORIGINAL / f'case-{i:02}' / phase / n) == h
    stdout = (ORIGINAL / f'case-{i:02}/execution/stdout.log').read_text()
    assert f'test {c["test_name"]} ... ok' in stdout and '1 passed; 0 failed; 0 ignored' in stdout
    assert c['execution']['command'][1:] == ['--exact', c['test_name'], '--nocapture', '--test-threads=1']
    six.append({'name': c['test_name'], 'actual_exit': 0, 'actual_stdout_one_pass_zero_failed_zero_ignored': True})
for e in selection['entries']:
    assert meta(Path(e['path'])) == e
assert sha(PEER / 'archive-selection.json') == selection_before
result = {
    'schema_version': 1,
    'reviewer': '/root/execution_recon',
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'verdict': 'accepted_scoped_retained_evidence_and_host_adaptation',
    'source_G': report['source']['source_commit'], 'source_tree': report['source']['source_tree'],
    'run_id': 37901930843, 'artifact_id': 11603892263,
    'reviewed_selection': meta(PEER / 'archive-selection.json'),
    'reviewed_controller': meta(PEER / 'retained-cli-controller-Gc8-native.py'),
    'reviewed_adaptation_diff': meta(PEER / 'controller-adaptation.diff'),
    'reviewed_replay_report': meta(CLI / 'replay-report-v2.json'),
    'canonical_R': selection['canonical_R'], 'original_zip': selection['original_zip'],
    'actual_replay_controller_exit': 0,
    'six_original_tests': six, 'seven_replays': verified_cases,
    'checks': {'all_32_selected_files_exact': True, 'original_zip_all_337_extracted_files_equal': True, 'fixture_copy_287_files_equal_original_and_recorded_map': True, 'original_case_list_AST_identical': True, 'exact_Gc8_ELF_original_and_copy_equal': True, 'Gc8_original_source_inputs_equal_canonical_P_R_1090': True, 'canonical_validation_domain_139': True, 'all_reviewed_files_unchanged_after_review': True},
    'manual_diff_review': 'Changes are source/artifact identity binding, actual host context and absolute fixture/output paths. The case populations, policies, expected exit/status checks and seventh overwrite refusal are preserved. Replacement of local source_snapshot with retained exact-Gc8 source manifest versus canonical R is explicit; no full local source_snapshot replay is claimed.',
    'execution_context': replay['execution_context'],
    'limits': ['Read-only non-author evidence review; no product command was rerun.', 'Host is native Linux x86_64 glibc2.39, not Docker and not a separately isolated network namespace; failed unshare probe is retained.', 'Original six Rust controls and seven retained deterministic CLI replays are separate evidence classes; zero-plan is an original Rust test, not an invented eighth CLI execution.', 'No new performance measurement, full-scale result, full local checkout source-admission claim, release approval or TODO completion.'],
    'task_credit': 0, 'remaining_todos': 29
}
out = OUT / 'independent-review.json'
with out.open('x') as f:
    json.dump(result, f, indent=2, sort_keys=True)
    f.write('\n')
print(json.dumps(meta(out)))
