#!/usr/bin/env python3
"""Independent static two-binding verification; does not run the guard."""
from pathlib import Path
import ast, copy, hashlib, json, re
ROOT=Path(__file__).resolve().parent
CAN=ROOT.parent/'independent-source-review.json'
SEED=Path('/dev/shm/todo-audit-P4-G4-binding-preparation')
GEN=Path('/dev/shm/todo-audit-G4-b4ad0852-binding')
P='1930b8e37e24031c3779553e3fc5b95e8e946d50';R='b4ad0852fb0f164f89ba194409e2a78578f5413f'
RP='artifacts/checkpoints/p8-completed-dependency-exclusion-ci-format-bfcc-20261009/independent-source-review.json'
REG='scripts/reviewed-source-registry-v15.json';GUARD='scripts/verify_reviewed_source_v15.py'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def tree(rows):
    rows=sorted(rows,key=lambda x:(x['path']+('/' if x['type']=='tree' else '')).encode())
    b=b''.join(x['mode'].lstrip('0').encode()+b' '+x['path'].encode()+b'\0'+bytes.fromhex(x['sha']) for x in rows)
    return hashlib.sha1(b'tree '+str(len(b)).encode()+b'\0'+b).hexdigest()
canraw=CAN.read_bytes();can=json.loads(canraw)
assert sha(canraw)=='61193e99e44f81c19656aed50cbe2730c87c53afdd7eb94839a8b7e1a3cf2cd1' and can['source']==P
oldregraw=(SEED/'seed-G3-registry.json').read_bytes();oldguard=(SEED/'seed-G3-guard.py').read_bytes()
script_tree=read(ROOT/'github-api/actual-R4-scripts-tree.json');root_tree=read(ROOT/'github-api/actual-R4-root-tree.json')
assert script_tree['truncated'] is False and tree(script_tree['tree'])==script_tree['sha']=='f98ef13b7bd4660c06942fbf1d2afd100d1601f0'
assert root_tree['truncated'] is False and tree(root_tree['tree'])==root_tree['sha']=='fea0cfc497e9bf1eb573474f3a3ecd69544fa456'
official={x['path']:x for x in script_tree['tree']}
assert blob(oldregraw)==official['reviewed-source-registry-v15.json']['sha']=='7b38ecd2b2760ecc0b144fcbce02598e4dc3af93'
assert blob(oldguard)==official['verify_reviewed_source_v15.py']['sha']=='0013040d59908b1fbe30e27d6877c0c5077cab11'
oldreg=json.loads(oldregraw);regraw=(GEN/'generated'/REG).read_bytes();guard=(GEN/'generated'/GUARD).read_bytes();reg=json.loads(regraw)
assert sha(regraw)=='1b170d4b61853b2c41caa0280e106bd31b21b2e8b28071b3a1fe5a69f72223f9'
assert sha(guard)=='a0bdaaf56cee7ae812d30d7314ebb59d19eb4d86825046f460869d549e172fb1'
fields=sorted(k for k in set(oldreg)|set(reg) if oldreg.get(k)!=reg.get(k))
assert fields==['complete_inputs','delta','product_source','review_sha256','review_source']
assert reg['product_source']==P and reg['review_source']==R and reg['review_sha256']==sha(canraw)
assert reg['complete_inputs']==can['complete_inputs'] and reg['delta']==can['paths'] and reg['validation_inputs']==can['validation_inputs']==oldreg['validation_inputs']
assert [len(reg[k]) for k in ('complete_inputs','delta','validation_inputs')]==[1095,70,142]
changed={}
for field in ['complete_inputs','delta']:
    assert set(reg[field])==set(oldreg[field])
    changed[field]=sorted(p for p in reg[field] if reg[field][p]!=oldreg[field][p])
    assert changed[field]==['crates/cc-db/tests/p2b_resolution_store.rs']
assert all(set(x)=={'before_sha256','sha256'} for x in reg['delta'].values())
assert all(reg['delta'][p]['before_sha256']==oldreg['delta'][p]['before_sha256'] for p in reg['delta'])
pins={'PRODUCT':P,'REVIEW':R,'REVIEW_PATH':RP,'REGISTRY_SHA256':sha(regraw)}
expected=oldguard.decode()
for name,value in pins.items():
    expected,n=re.subn(r'^'+name+r' = "[^"]*"$',name+' = '+json.dumps(value),expected,flags=re.M);assert n==1
assert expected.encode()==guard
ast.parse(guard)
request=read(GEN/'two-binding-create-tree-request.json');assert request['base_tree']==root_tree['sha'] and len(request['tree'])==2
payloads={REG:regraw,GUARD:guard};files=[]
for entry in request['tree']:
    assert entry['path'] in payloads and set(entry)=={'path','mode','type','sha'}
    data=payloads[entry['path']]
    assert entry['mode']=='100644' and entry['type']=='blob' and entry['sha']==blob(data)
    assert entry['path'] not in can['complete_inputs'] and entry['path'] not in can['validation_inputs']
    files.append({'path':entry['path'],'local_path':str(GEN/'generated'/entry['path']),'bytes':len(data),'sha256':sha(data),'git_blob':blob(data),'mode':'100644'})
assert {x['path'] for x in files}=={REG,GUARD}
newscript=copy.deepcopy(script_tree['tree'])
for x in newscript:
    p='scripts/'+x['path']
    if p in payloads:x['sha']=blob(payloads[p])
newscriptsha=tree(newscript);newroot=copy.deepcopy(root_tree['tree'])
next(x for x in newroot if x['path']=='scripts')['sha']=newscriptsha
expectedtree=tree(newroot)
assert expectedtree=='26baafefb05e113d9f4bab63716d8e72128208cf'
report={'schema_version':1,'reviewer':'/root/pr_triage','verdict':'accepted_for_G4_commit_source_binding_only','actual_P4':P,'actual_R4':R,'actual_R4_tree':root_tree['sha'],'actual_G4':None,'required_G4_sole_parent':R,'expected_G4_tree':expectedtree,'exact_changed_paths':[REG,GUARD],'all_other_R4_Git_leaves_unchanged_by_expected_complete_Merkle_tree':True,'canonical_review_sha256':sha(canraw),'registry_changed_fields':fields,'registry_changed_product_and_delta_paths':changed,'guard_only_four_pins':pins,'old_guard_bytes_except_four_pin_lines_exact':True,'BASE_FROZEN_history_algorithm_CI_preserved':True,'all_original_142_validation_maps_modes_and_Git_leaves_unchanged':True,'complete_product_inputs':1095,'BASE_delta':70,'all_before_SHA_values_preserved':True,'protected_ordinary_input_paths_do_not_include_the_two_binding_files':True,'actual_frozen_payloads':files,'source_review_current_execution':'P4 not_run; originalG3 fmt1/skipped retained. This static binding review does not run v15/Rust/fmt/workload or claim all CI green.','original_TODO_remaining':29,'remote_mutations':0,'new_native_or_CI_or_scale_executions':0}
with (ROOT/'G4-independent-two-bindings-review.pending-actual.json').open('x') as f:json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({'verdict':report['verdict'],'expected_G4_tree':expectedtree,'actual_G4':None,'files':files}))
