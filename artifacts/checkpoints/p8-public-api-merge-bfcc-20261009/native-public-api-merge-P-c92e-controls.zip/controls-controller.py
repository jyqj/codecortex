from pathlib import Path
import subprocess,json,hashlib,datetime,time,os,sys,re
root=Path.cwd();out=root.parent/'native-public-api-merge-P-c92e-evidence'
baseline=json.loads((out/'before-domain-receipt.json').read_text());expected={e['path']:e for e in baseline['entries']}
assert baseline['source_P']=='c92eb5ac7ece70d1f62271d7e2dacac513c285b5' and len(expected)==1245
(out/'controls-controller.py').write_bytes(Path(sys.argv[0]).read_bytes())
def snapshot(label,phase):
 rows=[]
 for name,e in sorted(expected.items()):
  p=root/name;b=p.read_bytes();row={'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'mode':'100755' if p.stat().st_mode&0o111 else '100644'}
  assert row==e,(label,phase,name)
  rows.append(row)
 b=(json.dumps({'source_P':baseline['source_P'],'tree':baseline['tree'],'phase':phase,'label':label,'entries':rows},indent=2,sort_keys=True)+'\n').encode();p=out/(label+'-input-'+phase+'.json');p.write_bytes(b)
 return {'path':p.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'entries':len(rows)}
env=os.environ.copy();env['PATH']='/Users/jin/.cargo/bin:'+env.get('PATH','');env['SDKROOT']='/Library/Developer/CommandLineTools/SDKs/MacOSX15.4.sdk'
source_target=root.parent/'targets/public-dependency-fix-1.95-sdk154-round13';target=root.parent/'targets/public-api-merge-P-c92e-1.95-sdk154-round14'
assert source_target.is_dir() and not target.exists()
start=time.monotonic();c=subprocess.run(['/bin/cp','-cR',str(source_target),str(target)],capture_output=True)
(out/'target-clone.stdout').write_bytes(c.stdout);(out/'target-clone.stderr').write_bytes(c.stderr)
(out/'target-clone-receipt.json').write_text(json.dumps({'command':['/bin/cp','-cR',str(source_target),str(target)],'exit_code':c.returncode,'elapsed_seconds':time.monotonic()-start,'scope':'own APFS cached engineering target clone; not fresh/cold/performance'},indent=2)+'\n')
assert c.returncode==0,c.stderr
env['CARGO_TARGET_DIR']=str(target)
commands=[
 ('resolution-store',['test','--locked','-p','cc-db','--test','p2b_resolution_store'],7),
 ('snapshot-binder-dependency-unit',['test','--locked','-p','cc-db','--lib','index_db_snapshot_insert::'],14),
 ('snapshot-leaf-owner-control',['test','--locked','-p','cc-index','--test','snapshot_leaf_batching'],6),
 ('workspace-format',['fmt','--all','--','--check'],0),
 ('cc-db-strict-clippy',['clippy','--locked','-p','cc-db','--all-targets','--','-D','warnings'],0),
 ('integrated-installer-cli',['test','--locked','-p','cc-server','--test','installer_cli'],1)]
all_receipts=[]
for label,args,minimum in commands:
 before=snapshot(label,'before');cmd=['/Users/jin/.cargo/bin/cargo','+1.95.0']+args;start=time.monotonic()
 r={'schema_version':1,'label':label,'source_P':baseline['source_P'],'tree':baseline['tree'],'cwd':str(root),'command':cmd,'minimum_tests':minimum,'before':before,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'ordinary engineering on actual committed P, 1245 selected inputs; cached owned cloned target; no cold/performance or whole-repository execution claim','environment':{k:env.get(k) for k in ['SDKROOT','CARGO_TARGET_DIR','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CC','CXX']}}
 sp=out/(label+'.stdout');ep=out/(label+'.stderr');rp=out/(label+'-receipt.json')
 with sp.open('wb') as so,ep.open('wb') as se:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=so,stderr=se);r['pid']=p.pid;rp.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'started':label,'pid':p.pid,'command':cmd}),flush=True);code=p.wait()
 r.update(exit_code=code,elapsed_seconds=time.monotonic()-start,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),after=snapshot(label,'after'))
 for k,q in [('stdout',sp),('stderr',ep)]:
  b=q.read_bytes();r[k]={'path':q.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};print(label+' '+k+' '+b.decode(errors='replace')[-8000:],flush=True)
 summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed;',sp.read_text(errors='replace'));r['test_summaries']=[{'passed':int(a),'failed':int(b)} for a,b in summaries]
 r['nonzero_test_check_passed']=minimum==0 or sum(int(a) for a,b in summaries)>=minimum and all(int(b)==0 for a,b in summaries)
 rp.write_text(json.dumps(r,indent=2)+'\n');all_receipts.append(r);(out/'controls-progress.json').write_text(json.dumps(all_receipts,indent=2)+'\n');print('RECEIPT '+json.dumps(r),flush=True)
 if code!=0 or not r['nonzero_test_check_passed']:sys.exit(code if code>0 else 1)
print('ALL_CONTROLS_PASSED',len(all_receipts),flush=True)
