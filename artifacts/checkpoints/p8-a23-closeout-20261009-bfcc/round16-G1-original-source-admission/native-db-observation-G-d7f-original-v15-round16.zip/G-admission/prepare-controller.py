from pathlib import Path
import subprocess,json,hashlib,datetime,time,sys

sys.dont_write_bytecode=True
cfg=json.load(sys.stdin)
G=cfg['guard'];TREE=cfg['tree'];P=cfg['product'];R=cfg['review'];review_path=cfg['review_path'];paths=cfg['historical_paths']
assert P=='bb290be2deaf4334863e09dbf47fe4ccc9625f2b'
assert review_path=='artifacts/checkpoints/p8-db-acquisition-cleanup-bfcc-20261009/independent-source-review.json'
assert len(paths)==len(set(paths))==236
assert hashlib.sha256(('\n'.join(paths)+'\n').encode()).hexdigest()=='aafd155302992ec650493a57ed432d81745955c1c77f8350e0a436732dd6df09'
root=Path.cwd();base=root/'artifacts/benchmarks/p8-bfccb8494ba0';wt=base/('candidate-db-observation-G-'+G[:8]);out=base/('native-db-observation-G-'+G[:8]+'-admission')
assert not wt.exists() and not out.exists()
out.mkdir();(out/'prepare-controller.py').write_bytes(Path(sys.argv[0]).read_bytes());(out/'preparation-binding.json').write_text(json.dumps(cfg,indent=2)+'\n')
receipts=[]
def run(label,argv,cwd=root,timeout=300):
    sp=out/(label+'.stdout');ep=out/(label+'.stderr');started=time.monotonic()
    rec={'label':label,'argv':argv,'cwd':str(cwd),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with sp.open('wb') as so,ep.open('wb') as se:
        proc=subprocess.Popen(argv,cwd=cwd,stdout=so,stderr=se);rec['pid']=proc.pid
        try:code=proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:proc.kill();code=proc.wait();rec['controller_timeout_seconds']=timeout
    rec.update(exit_code=code,elapsed_seconds=time.monotonic()-started,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    for key,q in [('stdout',sp),('stderr',ep)]:
        raw=q.read_bytes();rec[key]={'path':q.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
        if key=='stderr' and raw:print(raw.decode(errors='replace')[-2000:],flush=True)
    receipts.append(rec);(out/'preparation-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    print(json.dumps({'label':label,'exit_code':code,'elapsed_seconds':rec['elapsed_seconds']}),flush=True)
    if code:sys.exit(code if code>0 else 1)
    return sp.read_bytes()
git=['/usr/bin/git','-c','core.commitGraph=false']
parent_head=run('parent-head-before',git+['rev-parse','HEAD'])
run('fetch-actual-G-staging-branch',git+['fetch','--no-tags','origin','task/p8-public-api-merge-bfcc-20261009'])
raw=run('actual-G-commit',git+['cat-file','-p',G])
assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==G
assert raw.startswith(('tree '+TREE+'\nparent '+R+'\n').encode())
header=raw.split(b'\n\n',1)[0].splitlines();assert len([x for x in header if x.startswith(b'parent ')])==1
run('create-detached-G',git+['worktree','add','--no-checkout','--detach',str(wt),G])
initial_paths=['Cargo.lock','Cargo.toml','crates','scripts','.github','tests','artifacts/checkpoints/capability-snapshot-optimization-20261003/current-status-under-test.rs','artifacts/checkpoints/capability-snapshot-optimization-20261003/v2-status-checks.rs',review_path]
run('checkout-selected-G',git+['checkout',G,'--']+initial_paths,cwd=wt)
def parse(data):
    entries={}
    for line in data.split(b'\0'):
        if not line:continue
        left,name=line.split(b'\t',1);mode,kind,blob=left.decode().split();assert kind=='blob' and mode in ['100644','100755'];entries[name.decode()]={'mode':mode,'git_blob':blob}
    return entries
initial=parse(run('initial-G-ls-tree',git+['ls-tree','-r','-z',G,'--']+initial_paths,cwd=wt));assert len(initial)==1251,len(initial)
sys.path.insert(0,str(wt/'scripts'));import v15_historical_context as history
assert history.HISTORICAL_HEAD=='7354db236c9d9850a75f31672697ae9eab44565e'
for path in paths:assert history.relative(path)==path
protected=parse(run('current-G-historical-ls-tree',git+['ls-tree','-r','-z',G,'--']+paths,cwd=wt))
original=parse(run('original-BASE-historical-ls-tree',git+['ls-tree','-r','-z',history.HISTORICAL_HEAD,'--']+paths,cwd=wt))
assert set(protected)==set(paths) and protected==original
run('checkout-exact-historical-inputs',git+['checkout',G,'--']+paths,cwd=wt)
expected=dict(initial)
for name,value in protected.items():
    if name in expected:assert expected[name]==value
    expected[name]=value
rows=[]
for name,e in sorted(expected.items()):
    p=wt/name;b=p.read_bytes();actual={'path':name,'mode':'100755' if p.stat().st_mode&0o111 else '100644','git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
    assert {k:actual[k] for k in ['mode','git_blob']}==e,name
    rows.append(actual)
assert len(rows)==1440,len(rows)
receipt={'source_G':G,'tree':TREE,'product_P':P,'review_R':R,'initial_selected_count':len(initial),'protected_history_count':len(protected),'combined_selected_count':len(rows),'entries':rows,'scope':'Exact actual G product/validation/CI/bindings/canonical independent review, original current protected history and two original Rust compile inputs. Selected-input checkout; source admission not yet executed.'}
data=(json.dumps(receipt,indent=2,sort_keys=True)+'\n').encode();(out/'complete-domain-before-v15.json').write_bytes(data)
assert run('parent-head-after',git+['rev-parse','HEAD'])==parent_head
print(json.dumps({'source_G':G,'worktree':str(wt),'output':str(out),'selected_inputs':len(rows),'receipt_bytes':len(data),'receipt_sha256':hashlib.sha256(data).hexdigest(),'original_v15_not_started':True}),flush=True)
