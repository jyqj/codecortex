def stable_00250():
    return 250
