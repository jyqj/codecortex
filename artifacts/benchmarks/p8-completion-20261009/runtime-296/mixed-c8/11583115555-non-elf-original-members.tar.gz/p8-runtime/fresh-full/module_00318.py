def stable_00318():
    return 318
