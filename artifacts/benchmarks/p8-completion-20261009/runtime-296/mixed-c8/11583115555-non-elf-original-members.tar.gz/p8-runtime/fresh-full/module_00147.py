def stable_00147():
    return 147
