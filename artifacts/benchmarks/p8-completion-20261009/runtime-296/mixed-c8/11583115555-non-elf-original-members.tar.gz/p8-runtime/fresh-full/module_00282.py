def stable_00282():
    return 282
