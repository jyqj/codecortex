"""Run fixed follow-up protocol controls against the immutable parent runtime."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import unittest

root = Path('/workspace/scratch/2eaa00d0f93a/codecortex-runtime-followup-sparse')
sys.path[:0] = [str(root / 'scripts'), str(root / 'scripts/tests')]
import p8_runtime as runtime
import test_p8_runtime as controls

parent = '88d447390fa8a7dd04d9a6679fe90c1477bfa280'
body = subprocess.check_output(['git', '-C', str(root), 'show', parent + ':scripts/p8_runtime.py'])
exec(compile(body, str(root / 'scripts/p8_runtime.py'), 'exec'), runtime.__dict__)
print(json.dumps({'scope': 'explicit protocol controls with actual threads; not product evidence',
                  'runtime_commit': parent, 'runtime_sha256': hashlib.sha256(body).hexdigest(),
                  'controls_sha256': hashlib.sha256((root / 'scripts/tests/test_p8_runtime.py').read_bytes()).hexdigest()}))
names = ['test_oracle_difference_keeps_statistics_and_failure_exit_one',
         'test_raw_budget_abort_drains_actual_worker_before_sealing',
         'test_unconfirmed_worker_shutdown_cannot_create_a_seal']
suite = unittest.TestSuite(controls.RuntimeFailureLifecycleTests(name) for name in names)
result = unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(0 if result.wasSuccessful() else 1)
