#!/usr/bin/env python3
"""Bounded read-only source review bridge; no source/test/CI execution."""
from pathlib import Path
import json,hashlib,copy
ROOT=Path(__file__).resolve().parent
PRIOR=Path('/dev/shm/pr-triage-P5B-preselect-format-source-review')
READY=Path('/dev/shm/todo-audit-round19-PR180-crash-ready-review')
P='5534ebf38cc31efec1590d132ca57c30e2f77f1b'
M='fffd950d5b34b0180f308db1428a57d5bf358bf1'
PATH='crates/cc-semantic/tests/p7_crash_preparation.rs'
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def payload(name):
 d=read(ROOT/'official-responses'/name);assert not d.get('isError');return json.loads(d['structuredContent']['content'])
def save(name,d):(ROOT/name).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
def tree_oid(rows):
 body=b''
 for r in sorted(rows,key=lambda x:(x['path']+('/' if x['type']=='tree' else '')).encode()):
  mode='40000' if r['mode']=='040000' else r['mode']
  body+=mode.encode()+b' '+r['path'].encode()+b'\0'+bytes.fromhex(r['sha'])
 return oid('tree',body)
pc=payload('P6B-commit.json');diff=payload('M7F-to-P6B-compare.json')
assert pc['sha']==P and pc['tree']['sha']=='3d3d5a6ef11f3e632eb5ab8ce2502d7854aa2bd1'
assert [x['sha'] for x in pc['parents']]==[M]
assert diff['base_commit']['sha']==diff['merge_base_commit']['sha']==M
assert diff['total_commits']==1 and len(diff['files'])==1 and diff['commits'][0]['sha']==P
assert diff['files'][0]['filename']==PATH and diff['files'][0]['sha']=='97ce7a96471cabc0943a1f5ecf9d2a62bde40d12'
names=['crates','cc-semantic','tests','p7_crash_preparation.rs']
trees=[payload(f'tree-path-{i}.json') for i in range(4)]
for i,t in enumerate(trees):
 assert not t['truncated'] and tree_oid(t['tree'])==t['sha']
 e=next(e for e in t['tree'] if e['path']==names[i])
 if i<3:assert e['type']=='tree' and e['sha']==trees[i+1]['sha']
 else:assert e['mode']=='100644' and e['type']=='blob' and e['sha']==diff['files'][0]['sha'] and e['size']==15069
assert trees[0]['sha']==pc['tree']['sha']
old=(READY/'source/M7F-p7_crash_preparation.rs').read_bytes()
new=(READY/'source/candidate-p7_crash_preparation.rs').read_bytes()
assert oid('blob',old)=='6493cbe6c291bc4622cf93cdb566f68e6e215155' and oid('blob',new)==diff['files'][0]['sha']
# Revert only that leaf in the four new, fully hashed directory nodes. The
# reconstructed old root must equal M7F: this covers every unchanged sibling,
# mode, source binding and artifact without another full repository traversal.
replacement=oid('blob',old)
for i in reversed(range(4)):
 rows=copy.deepcopy(trees[i]['tree']);entry=next(e for e in rows if e['path']==names[i]);entry['sha']=replacement
 replacement=tree_oid(rows)
assert replacement=='7fd27832748e18cf878132fedf27571d0c20de1f'
prior_raw=(PRIOR/'independent-source-review.json').read_bytes()
assert sha(prior_raw)=='a79f4a1dddd8e7fcd3b39997e5c8caecc1e857be58908a711221417ff19225f3'
prior=json.loads(prior_raw)
assert prior['source']=='d21e140ca9ebb5a73294358d64a839466c5a0076' and prior['verdict']=='accepted_scoped'
peerpath=PRIOR/'external-M7F-equivalence/independent-M7F-versus-G5B-equivalence-review.json'
peerraw=peerpath.read_bytes();assert sha(peerraw)=='401a644efd982550e43b179a50d135d5b4f8fe304f39eac6ff336d8c318d8b22'
peer=json.loads(peerraw);assert peer['published_external_G']==M and peer['entire_P_trees_equal'] and peer['all_three_maps_exactly_equal_own_canonical_R5B']
external=read(PRIOR/'external-M7F-equivalence/external-canonical-R.json')
for key in ('complete_inputs','paths','validation_inputs'):assert external[key]==prior[key]
assert prior['complete_inputs'][PATH]==sha(old) and PATH not in prior['paths']
assert prior['actual_input_mode_blob_inventory'][PATH]=={'mode':'100644','type':'blob','sha':oid('blob',old),'sha256':sha(old),'size':len(old)}
newmap={'source':P,'source_tree':pc['tree']['sha'],'source_parents':[M],'base':prior['base'],'complete_inputs':copy.deepcopy(prior['complete_inputs']),'paths':copy.deepcopy(prior['paths']),'validation_inputs':copy.deepcopy(prior['validation_inputs']),'actual_input_mode_blob_inventory':copy.deepcopy(prior['actual_input_mode_blob_inventory'])}
newmap['complete_inputs'][PATH]=sha(new)
newmap['paths'][PATH]={'before_sha256':sha(old),'sha256':sha(new)}
newmap['actual_input_mode_blob_inventory'][PATH]={'mode':'100644','type':'blob','sha':oid('blob',new),'sha256':sha(new),'size':len(new)}
assert [len(newmap[k]) for k in ('complete_inputs','paths','validation_inputs','actual_input_mode_blob_inventory')]==[1095,72,142,1237]
assert all(set(x)=={'before_sha256','sha256'} for x in newmap['paths'].values())
expected=read(READY/'existing-P2-mechanical-input-map.json')
for key in ('complete_inputs','paths','validation_inputs'):assert newmap[key]==expected[key]
review=read(READY/'independent-existing-repair-applicability-review.json')
assert review['verdict']=='existing_candidate_applicable_scoped_source_only' and review['existing_candidate']['all_other_source_bytes_equal']
save('actual-P6B-complete-product-validation-inputs.json',newmap)
receipt={'schema_version':1,'reviewer':'/root/todo_audit','source':P,'source_tree':pc['tree']['sha'],'source_parents':[M],'verdict':'accepted_actual_one_leaf_source_identity_and_semantics','official_complete_compare_paths':[PATH],'official_hierarchical_tree_nodes_rehashed':4,'reverting_only_existing_candidate_blob_restores_exact_M7F_root':replacement,'all_other_Git_leaves_and_modes_preserved':True,'counts':{'product':1095,'BASE_delta':72,'validation':142,'mode_blob_inputs':1237},'previous_71_BASE_before_after_entries_exactly_preserved':True,'one_added_BASE_delta':PATH,'all142_validation_exactly_preserved':True,'actual_complete_maps_equal_existing_P2':True,'full_current_domain_method':'Inherit previously independently verified complete P5B/M7F 1237 mode/blob/SHA map; prove exact current whole tree differs only in one leaf through four actual Git tree objects, then replace only that leaf. No claim to reread unchanged1236 source bodies or reexecute prior checks.','source_review':'Current reviewer independently read whole old/new fixture and original full failure log; complete file differs only in signal_and_wait; existing candidate and non-author narrow review retain their identities.','source_admission_or_product_execution':'not_run','no_new_test_gate':True,'raw_candidate_bytes':len(new),'raw_candidate_sha256':sha(new),'raw_candidate_git_blob':oid('blob',new)}
save('actual-P6B-independent-source-bridge.json',receipt)
print(json.dumps(receipt,sort_keys=True))
if __name__=='__main__':pass
