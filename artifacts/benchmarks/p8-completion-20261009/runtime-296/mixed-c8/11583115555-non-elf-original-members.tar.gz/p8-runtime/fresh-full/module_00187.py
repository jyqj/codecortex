def stable_00187():
    return 187
