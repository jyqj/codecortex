#!/usr/bin/env python3
"""Summarize received immutable records; no repository or workflow execution."""
import hashlib,json,shutil
from pathlib import Path
R=Path(__file__).resolve().parent
def load(p):return json.loads((R/p).read_bytes())
def dump(p,j):(R/p).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
computed=load('computed-identity-audit.json'); maps=load('input-official-file-maps.json')
root_diffs={}
for pr in (175,179):
 a={e['path']:e for e in load(f'official/p{pr}_old-root-tree.json')['tree']};b={e['path']:e for e in load(f'official/p{pr}_new-root-tree.json')['tree']}
 changes=[p for p in sorted(a.keys()|b.keys()) if (a.get(p,{}).get('sha'),a.get(p,{}).get('mode'))!=(b.get(p,{}).get('sha'),b.get(p,{}).get('mode'))]
 assert set(changes)<={'artifacts','crates','scripts','.github','docs','CONTRIBUTING.md'}
 root_diffs[str(pr)]=changes
preserved={}
for pr,paths in [(175,['crates/cc-eval/src/benchmark/statistics.rs','crates/cc-eval/src/bin/p8-runtime-statistics.rs','docs/P8_RUNTIME_EVIDENCE.md','scripts/p8_runtime.py','scripts/tests/test_p8_runtime.py']),(179,['crates/cc-index/src/resolver/catalog.rs','crates/cc-index/src/resolver/helpers.rs'])]:
 preserved[str(pr)]=[]
 for p in paths:
  a,b=maps[f'p{pr}_old'][p],maps[f'p{pr}_new'][p];assert (a['mode'],a['sha'])==(b['mode'],b['sha'])
  preserved[str(pr)].append({'path':p,'mode':b['mode'],'Git_blob':b['sha'],'bytes':b['size']})
head=load('official/p179_new-root-tree.json');main=load('official/merge-f7a003636b4902f569404f4e493e1fff7630093e-root-tree.json')
headrows={e['path']:e for e in head['tree']};md=[e['path'] for e in main['tree'] if e['sha']!=headrows[e['path']]['sha'] or e['mode']!=headrows[e['path']]['mode']]
assert md==['README.md','docs']
newdocs=load('official/latest-main-docs-tree.json');task=next(e for e in newdocs['tree'] if e['path']=='roadmap/code-index-v2/tasks.json');assert task['sha']=='1365970c32d0883cc05a37f9333ffb9589299141'
latest_task=Path('/workspace/scratch/bfccb8494ba0/task-closeout-current-main-900539/docs/roadmap/code-index-v2/tasks.json')
taskraw=latest_task.read_bytes();assert hashlib.sha1(f'blob {len(taskraw)}\0'.encode()+taskraw).hexdigest()==task['sha']
core=Path('/workspace/scratch/bfccb8494ba0/task-closeout-ready/docs/roadmap/code-index-v2/tasks.json')
before=json.loads(core.read_bytes());after=json.loads(taskraw)
assert len(before['tasks'])==len(after['tasks'])==192
for a,b in zip(before['tasks'],after['tasks']):
 assert a['id']==b['id'] and a['status']==b['status']
 for f in ['scope','depends_on','steps','deliverables','acceptance','validations','rollback','conditional','required_for','conditional_dependencies']:
  assert a.get(f)==b.get(f),(a['id'],f)
status_counts={s:sum(t['status']==s for t in after['tasks']) for s in sorted({t['status'] for t in after['tasks']})}
report={
 'schema_version':1,'reviewed_at_utc':'2026-10-09T09:41:12Z','reviewer':'/root/todo_audit','scope':'readonly PR175/179 actual refreshed heads, immutable P/R/G assembly, source-risk and official current-head job snapshot',
 'verdict':'no_new_source_assembly_blocker_identified; execution_acceptance_not_granted',
 'source_blockers':[],'no_repository_code_or_tests_executed':True,'no_remote_write':True,'TODO_closed':0,'TODO_done':163,'TODO_remaining':29,
 'observed_external_merge':computed['current_head_job_snapshot'],
 'actual_bindings':{k:v for k,v in computed['heads'].items() if k.endswith('_new')},
 'old_bindings_for_comparison':{k:v for k,v in computed['heads'].items() if k.endswith('_old')},
 'source_change_summary':{
  'old_to_new_complete_nonartifact_changes':computed['old_to_new_nonartifact_delta'],
  'root_domain_completeness_check':root_diffs,
  'only_changed_product_body':'crates/cc-index/src/indexer_phases/reconcile.rs',
  'reconcile_before':'9617e0f241c624ce35db3c6db8e5eba568fb7594','reconcile_after':'c8aed85c88cf2fbbbf691592fd1837ce6356818e',
  'reconcile_and_surface_workflow_equal_inherited_main_bd469335':all(maps[k]['crates/cc-index/src/indexer_phases/reconcile.rs']['sha']==maps['main']['crates/cc-index/src/indexer_phases/reconcile.rs']['sha'] and maps[k]['.github/workflows/p8-surface-window-controls.yml']['sha']==maps['main']['.github/workflows/p8-surface-window-controls.yml']['sha'] for k in ['p175_new','p179_new']),
  'old_PR_body_files_exactly_preserved':preserved,
  'tests_subtree_unchanged':'b3e8744962f9e4b25ff9104001a3e57d3168735d',
  'validation_count_change':'138 -> 139, only new inherited p8-surface-window-controls.yml; no old validation body removed or loosened',
  'P_to_R':'Only artifacts root changes; all source, validation and guard input trees exactly retained',
  'R_to_G':'Only scripts/reviewed-source-registry-v15.json and scripts/verify_reviewed_source_v15.py differ; guard normalization proves PRODUCT/REVIEW/REVIEW_PATH/REGISTRY_SHA256 only; BASE unchanged',
  'R_inventory':'Both canonical reviews and registries cover exact actual full1089 product and139 validation domains; mode/type/blob/size match official complete recursive trees, registry/R SHA256 and actual P/R/G parents match',
  'new_179_vs_new_175':'Only original resolver catalog.rs/helpers.rs product bodies plus two binding files; resolver bodies are byte-identical to reviewed old179',
 },
 'semantic_review':[
  {'path':'crates/cc-index/src/indexer_phases/reconcile.rs','lines':[18,40,130,145,188,201,234],'finding':'Materialized surface window is reused only for exactly equal queried/final seed slices and bounded admitted work. It captures the raw first matching query before mutating candidate population. None/changed seed basis or over-budget admission returns to original tail SQL. Existing root/conservative pending and expected_index_epoch fence remain. No changed caller precondition introduced by the separately preserved resolver/statistic bodies was found.'},
  {'path':'crates/cc-index/src/indexer_phases/reconcile.rs','lines':[451,542,595,645,753],'finding':'Six added surface controls remain present, covering multi-batch/budget canonical pending equivalence, basis/admission fallback, replacement/removal/reopen, promotion preservation, propagated seed fallback and external epoch fence. This is source inspection only; this review does not call those tests passed.'},
  {'path':'.github/workflows/p8-surface-window-controls.yml','finding':'Exact inherited main workflow body. Its branch-specific push trigger and fixed old source fingerprint do not turn it into a newly executed current-PR gate. Retaining this file is source/validation preservation, not execution credit; no extra gate is invented.'},
  {'path':'canonical R records','finding':'Read actual review records, including actual input inventories and reviewer recusals. acceptance_audit recuses unchanged authored surface paths and inherits prior non-author source review by exact blob; current integration has a different composition author. PR179 role-correction metadata does not change product maps or verdict. We verify binding/assembly; this report does not independently recreate every historical semantic review.'}
 ],
 'latest_main':{'commit':'f7a003636b4902f569404f4e493e1fff7630093e','merge_parents':['d4f5dc380507eaacd36ca77590eb4f6cb6f4733a','8da6bd93d6bd735e30daba11d821726a21ad8424'],'prior_merge_175_parents':['900539f25ed9f9f78cf15895257f82f78810831e','8da1f956f6b0dd3413a37c639a79e1e0d939de81'],'root_differences_from_new179':md,'product_scripts_workflows_tests_and_artifacts_tree_OIDs_match_new179':True,'latest_tasks_blob':task['sha'],'current_status_counts':status_counts,'old_Gc8_task_core_definitions_and_status_unchanged':True,'notes_and_evidence_not_overwritten':True},
 'limitations':['Official09:34snapshot is not a final check verdict; neither generic CI check has completed. No old head green result is transferred. External merges were performed by jyqj, not this reviewer.','No runtime/performance/scale/sourceguard execution is granted to either new head by this static audit. Gc8 originals and registered run37902429727 remain an independent fixed-source study.','Git SHA and SHA256 are different domains: official tree/blob identity binds complete inputs; canonical R supplies their existing SHA256. This refresh does not redownload and rehash every unchanged product body.','The first two local report-verifier attempts failed on reviewer assumptions (tree API top sha echoes commit; canonical manifest uses indented JSON newline); original failed scripts/stdout/stderr/exit1 are retained. No repository source changed; corrected readonly comparisons exited0.','Primary report-write attempt failed ENOSPC; complete original GitHub response bodies were retained in toolstore and then written to a separate RAM directory. No frozen evidence or other session files were removed.'],
 'support':{'identity_audit':'computed-identity-audit.json','exact_canonical_reviews':'source/p175_new/independent-source-review.json and source/p179_new/independent-source-review.json','official_API':'official/','original_identity_verifier_receipt':'verification-receipt.json','frozen_study_boundary':'frozen-study-and-latest-ledger-boundary.json'}
}
dump('readonly-pr175-pr179-refresh-review.json',report)

protocol_root=Path('/workspace/scratch/bfccb8494ba0/scale-intake-primary/target-ten-closeout-map/protocol/docs/roadmap/code-index-v2')
boundary_sources={}
for name,path in [('P8-SCALE.md',protocol_root/'P8-SCALE.md'),('09-BENCHMARK.md',protocol_root/'09-BENCHMARK.md'),('06-VALIDATION.md',core.parent/'06-VALIDATION.md')]:
 b=path.read_bytes();(R/'protocol').mkdir(exist_ok=True);(R/'protocol'/name).write_bytes(b);boundary_sources[name]=info(path)
selected=[]
for t in before['tasks']:
 if t['id'] in ['P8-005','P8-006','P8-007','P8-008','P8-009','P8-010','P8-011','P8-012','P8-013','P8-016']:
  selected.append({k:t.get(k) for k in ['id','title','status','scope','depends_on','steps','deliverables','acceptance','validations','rollback','conditional_dependencies']})
dump('protocol/original-ten-definitions-extract.json',{'origin':info(core),'derived_extract_not_replacement_ledger':True,'tasks':selected})
boundary={
 'schema_version':1,'reviewer':'/root/todo_audit','kind':'read_only_interpretation_of_original_scope_not_new_gate',
 'frozen_source_G':'c8be5afaac568ffd40ef86d3795423c3b73c9f39','frozen_study_run':37902429727,'attempt':1,'current_observed_main':'f7a003636b4902f569404f4e493e1fff7630093e','task_states_modified':False,
 'finding':'No reviewed original task definition or cited protocol requires the final bookkeeping commit to equal the newest main performance cohort. Each accepted scientific/execution claim must retain its actual frozen source; all original acceptance/dependencies still apply.',
 'authority':[
  {'file':'tasks.json','pointer':'tasks[P8-005] and tasks[P8-006]','requirement':'Fixed-seed release1k/5k/10k/50k/100k, full workload counts, attributable incremental phases and full parity, original common regression/dependency requirements; no latest-main bookkeeping-SHA requirement.'},
  {'file':'P8-SCALE.md','lines':[141,147],'requirement':'Build/run/replay at one fixed commit and same driver/helper, preserving actual executable/manifest hashes.'},
  {'file':'P8-SCALE.md','lines':[250,256],'requirement':'150-sample cohort conditions preserve source, binary, toolchain/profile/features, seed,input and config; heterogeneous environmental layers remain separate.'},
  {'file':'P8-SCALE.md','lines':[267,281],'requirement':'All150 shards/1500 samples remain required. A new source must not relabel a prior build receipt. Every complete execution fixes a final fullSHA first; old partial/failure/source records stay.'},
  {'file':'P8-SCALE.md','lines':[184,189],'requirement':'Large matrix starts by explicit dispatch/label, not every ordinary PR; actual evidence and independent task acceptance determine005/006 completion.'},
  {'file':'09-BENCHMARK.md','lines':[130,136,189,191],'requirement':'Manifest/run identity and samples carry actual engine/binary/config; PR/nightly/release profiles separate; latest is only a pointer, never an overwrite of old raw.'},
  {'file':'06-VALIDATION.md','lines':[58,67],'requirement':'A whole G8 release gate needs its actual current-run evidence and zero blockers; hard correctness failures and ungrounded statistics cannot be hidden. Ten source-scoped tasks do not establish full G8 or latest-main release certification.'}
 ],
 'allowed_conditional_closeout':'Only after every original task acceptance and hard dependency actually passes for the named Gc8 candidate, a fresh-main ledger update may attach an explicit accepted-at-Gc8 fixed-study evidence record. Preserve current external notes/evidence and unchanged task definitions. The ledger commit is documentation of that historical actual execution, not a claim its own code was measured.',
 'not_allowed':['Changing Gc8 raw/source/binary names to mainf7a003 or mixing later-source samples into its150-cohort.','Calling newmain performance/regression/release certified from Gc8 data alone.','Using an external merge or this review to close tasks before missing original evidence passes.','Ignoring a subsequently discovered real correctness problem that invalidates the fixed-study claims.'],
 'not_added':['No automatic fullN30 rerun merely because main or documentation moves.','No latest-ledgerSHA==performance-sourceSHA requirement.','No new study, optional test, acceptance criterion or dependency introduced.'],
 'actual_current_progress':'All ten original TODOs remain unclosed here; remaining29. This report neither asserts completion of150 shards nor predicts its result.',
 'source_documents':boundary_sources,'latest_tasks':info(latest_task),'latest_tasks_blob':task['sha']
}
dump('frozen-study-and-latest-ledger-boundary.json',boundary)
for name in ['readonly-pr175-pr179-refresh-review.json','frozen-study-and-latest-ledger-boundary.json']:
 print(json.dumps(info(R/name),ensure_ascii=False))
