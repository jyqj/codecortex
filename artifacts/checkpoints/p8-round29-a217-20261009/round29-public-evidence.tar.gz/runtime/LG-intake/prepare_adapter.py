import ast,difflib,hashlib,json,pathlib
BASE=pathlib.Path('/workspace/scratch/a217aaae3bde')
OLD=BASE/'original-C3ff-runtime/helpers-C3ff-v1'
OUT=BASE/'original-LG-runtime/helpers-LG-v1'
OUT.mkdir(exist_ok=False)
records=[]
def ident(p,data=None):
 data=p.read_bytes() if data is None else data
 return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),git_blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
def adapt(name,changes):
 before=(OLD/name).read_text();after=before;edits=[]
 for old,new,n in changes:
  assert after.count(old)==n,(name,old,after.count(old),n)
  after=after.replace(old,new);edits.append(dict(old=old,new=new,expected_matches=n))
 ast.parse(after)
 p=OUT/name;p.write_text(after)
 diff=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='C/'+name,tofile='LG/'+name));(OUT/(name+'.diff')).write_text(diff)
 records.append(dict(before=ident(OLD/name),after=ident(p),edits=edits,before_asserts=sum(isinstance(x,ast.Assert) for x in ast.walk(ast.parse(before))),after_asserts=sum(isinstance(x,ast.Assert) for x in ast.walk(ast.parse(after)))))
adapt('e_raw_cache_audit.py',[
 ('fixed C3ff runtime evidence','fixed LG diagnostic runtime evidence',1),
 ("HEAD = '3ffcefc3b28ee1a4ed80caecebd7208a45c3e302'","HEAD = '18255c53b7fa153bb71c96f57f1b97ca139e427f'",1),
 ('RUN = 37908825814','RUN = 37919399759',1),
 ("PRODUCT_MANIFEST = 'be60b3d1bb7b90a8f8023506e9d9570c7b445d67686f047e4ef12fde75f7e835'","PRODUCT_MANIFEST = '11b8922962005ba5feb55d8c998d815db93825c84a24052054ab02eddead0f65'",1),
])
adapt('preflight_e_runtime_zip.py',[
 ("('p8-runtime/project/','p8-runtime/fresh-full/')","('p8-lock-runtime/project/','p8-lock-runtime/fresh-full/')",1),
 ("('p8-build/p8-oracle','p8-build/p8-runtime-statistics')","('p8-lock-build/p8-oracle','p8-lock-build/p8-runtime-statistics')",1),
])
old_cmd="assert build['build_command']==['cargo','build','--release','--locked','--offline','--no-default-features','-p','cc-server','--bin','codecortex','-p','cc-eval','--bin','p8-oracle','--bin','p8-runtime-statistics','--message-format=json-render-diagnostics','--target-dir',build['target_dir']]"
new_cmd=old_cmd[:-1]+",'--features','cc-server/p8-db-lock-observation,cc-eval/p8-db-lock-observation']]"
# old_cmd ends with ]] (target_dir index then command list); retain the target index.
assert "build['target_dir'],'--features'" in new_cmd
adapt('review_e_runtime_original.py',[
 ('exact fixed C3ff execution','exact fixed LG diagnostic execution',1),
 ("'scripts/resource_harness/runtime.py']:","'scripts/resource_harness/runtime.py','scripts/p8_runtime_lock_observation.py']:",1),
 ('import p8_runtime_build as owner; import p8_runtime as runtime','import p8_runtime_build as owner; import p8_runtime as runtime; import p8_runtime_lock_observation as locks\nfrom lg_counter_audit import audit_original_counter_boundaries',1),
 ("m=p/'p8-runtime';b=p/'p8-build'","m=p/'p8-lock-runtime';b=p/'p8-lock-build'",1),
 (" n=3601 if plan['profile']=='soak' else 900"," assert plan['profile']=='mixed' and c in (1,4,8,16)\n assert plan.get('diagnostic_profile')==r.get('diagnostic_profile')==build.get('diagnostic_profile')==owner.LOCK_OBSERVATION_PROFILE\n n=3601 if plan['profile']=='soak' else 900",1),
 ('1092','1094',3),
 (old_cmd,new_cmd,1),
 ("a['cargo_artifact']['features']==[]","a['cargo_artifact']['features']==['p8-db-lock-observation']",1),
 (" cache_audit=audit_cache(runtime,m,plan,r,raw,raw_offsets) if plan['profile']=='soak' else None"," counter_audit=audit_original_counter_boundaries(locks,m,plan,r,ops,raw_event_counts)\n cache_audit=audit_cache(runtime,m,plan,r,raw,raw_offsets) if plan['profile']=='soak' else None",1),
 ("'observer_files':9","'observer_files':10",1),
 ("'default profile semantic backfill excluded; separate seeded original-worker run required'","'instrumented feature profile only; no old default latency/lock-counter pooling; SQLite internal busy wait not observed'",1),
 ('summary.update(cache_audit=cache_audit','summary.update(db_lock_observation=counter_audit,diagnostic_profile=owner.LOCK_OBSERVATION_PROFILE,cache_audit=cache_audit',1),
])
(OUT/'adaptation-manifest.json').write_text(json.dumps(dict(schema='LG-helper-adaptation-v1',head='18255c53b7fa153bb71c96f57f1b97ca139e427f',run=37919399759,source_inputs=1094,source_manifest='11b8922962005ba5feb55d8c998d815db93825c84a24052054ab02eddead0f65',observer_count=10,records=records,scope='Only new opt-in mixed four-C artifacts. Original C files untouched. Unused inherited lifecycle/soak definitions are retained, but the adapted entry point strictly requires mixed and the LG runtime run.',original_artifact_execution='not_run',rust_native_measurement='not_run',formal_completion=False,todo_remaining=29),indent=2,sort_keys=True)+'\n')
print(json.dumps({'out':str(OUT),'files':[(r['after']['path'],r['before_asserts'],r['after_asserts']) for r in records]}))
