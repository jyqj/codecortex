def stable_00189():
    return 189
