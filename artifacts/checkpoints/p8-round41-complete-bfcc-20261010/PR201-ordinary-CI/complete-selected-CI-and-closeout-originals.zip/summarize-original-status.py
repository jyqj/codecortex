from pathlib import Path
import json,hashlib,datetime,re,zipfile,yaml
B=Path('/workspace/scratch/bfccb8494ba0');D=Path(__file__).parent
def identity(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def raw(n):return json.loads((D/n).read_text())
def unwrap(n):
 d=raw(n);return json.loads(d.get('response',d)['structuredContent']['content'])
rootpath=B/'round41-0500-official-observation-originals.json';root=json.loads(rootpath.read_text())
r=root['responses'][0]['response'];assert r['status']=='fulfilled'
main=json.loads(r['value']['structuredContent']['content']);assert len(main['jobs'])==3
fragment={'source_original':identity(rootpath),'original_interval':root['observed_interval_utc'],'original_index':0,'response':r['value'],'selection_boundary':'Only root original G2 main jobs; other old-study responses excluded.'}
(D/'jobs-38025451919.root-original-fragment.json').write_text(json.dumps(fragment,indent=2)+'\n')
watch=json.loads((B/'round40-fresh45-route-independent-review/ordinary26-watch-list.json').read_text())
pull=unwrap('pull.official-original.json');runs=unwrap('runs.official-original.json');checks=unwrap('checks.official-original.json');merge=unwrap('current-testmerge.official-original.json')
G='f97c5068d056969705e8387ba1f37d83847f5bee';GT='39a053ae49b486764751a570d164e7cd41d7ff29';BASE='b9b089bb4eae072affe9326681d4980eae15fd84'
assert pull['head']['sha']==G and pull['base']['sha']==BASE and pull['merge_commit_sha']==merge['sha']
assert merge['tree']['sha']==GT and [p['sha'] for p in merge['parents']]==[BASE,G]
assert len(runs['workflow_runs'])==7
expected={w['path']:set(w['expected_check_names']) for w in watch['workflows']}
assert {r['path'] for r in runs['workflow_runs']}==set(expected)
alljobs=[];runrows=[]
for run in runs['workflow_runs']:
 assert run['head_sha']==G and run['run_attempt']==1 and run['event']=='pull_request'
 jobs=main if run['id']==38025451919 else unwrap('jobs-'+str(run['id'])+'.official-original.json')
 assert jobs['total_count']==len(jobs['jobs'])
 assert all(j['head_sha']==G and j['run_id']==run['id'] and j['run_attempt']==1 for j in jobs['jobs'])
 names={j['name'] for j in jobs['jobs']};assert names<=expected[run['path']]
 rows=[]
 for j in jobs['jobs']:
  row={k:j.get(k) for k in ['id','name','status','conclusion','started_at','completed_at','run_id','head_sha']}
  row['active_steps']=[s for s in j.get('steps',[]) if s['status']=='in_progress']
  row['failed_steps']=[s for s in j.get('steps',[]) if s['conclusion']=='failure']
  rows.append(row);alljobs.append(row)
 runrows.append({'id':run['id'],'path':run['path'],'source':run['head_sha'],'attempt':1,'run_status_at_list':run['status'],'run_conclusion_at_list':run['conclusion'],'jobs':rows,'expected_missing_jobs_not_passed':sorted(expected[run['path']]-names)})
assert len(alljobs)==25 and len({j['name'] for j in alljobs})==25
counts={}
for j in alljobs:
 k=j['conclusion'] or j['status'];counts[k]=counts.get(k,0)+1
mainjob=next(j for j in main['jobs'] if j['name']=='check')
critical_names=['Format check','Clippy','Compile every default test target','Default regression within authorized scope','Fixed resource driver harmless fixtures and TODO consistency','P0 benchmark optional HTTP contract tests']
critical=[s for s in mainjob['steps'] if s['name'] in critical_names]
closeout=next(j for j in alljobs if j['name']=='closeout');soak=next(j for j in alljobs if j['name']=='soak')
assert not [j for j in alljobs if j['conclusion']=='failure' or j['failed_steps']]
ci=B/'round32-capture-context-admission/guard-view/.github/workflows/ci.yml';cfg=yaml.safe_load(ci.read_text())
commands={s['name']:s['run'] for s in cfg['jobs']['check']['steps'] if 'run' in s}
scope_tests=['task_descriptive_scope_is_explicit_n1_without_weakening_old_n30','task_descriptive_scope_rejects_changed_identity_and_registered_budgets','task_descriptive_cli_does_not_launch_a_n30_or_mixed_scope_plan']
cursor_tests=['borrowed_cursor_text_matches_owned_conversion_and_row_storage','borrowed_cursor_pair_preserves_both_rows_duplicates_and_asymmetric_eof','borrowed_cursor_pair_keeps_original_step_and_conversion_error_order']
test=B/'round41-PR201-format-fix/candidate/crates/cc-eval/tests/p8_scale.rs';cursor=B/'round40-borrowed-sorted-cursor-candidate/candidate/crates/cc-eval/src/benchmark/oracle/streaming.rs'
for p,names in [(test,scope_tests),(cursor,cursor_tests)]:
 for n in names:assert re.search(r'#\[test\]\s+fn '+re.escape(n)+r'\(',p.read_text())
report={
 'schema':'PR201-G2-finite-original-ordinary-CI-review-v1','recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/pr_triage',
 'actual_source':{'G':G,'tree':GT,'PR':201,'base':BASE,'draft':pull['draft'],'mergeable':pull['mergeable'],'testmerge':merge['sha'],'testmerge_parents':[p['sha'] for p in merge['parents']],'testmerge_tree_exact_equals_G':True,'actual_runner_checkout':'Not inferred from current testmerge API; root owns original terminal log receipt.'},
 'observation_boundary':'One finite batch; initial checks/run list precedes later jobs reads. Mainjobs reused root05:00:20–42 response without duplicateAPI. Retain each raw timestamp and do not turn crossing updates into an atomic snapshot.',
 'original26_scope':{'expected':26,'jobs_present':25,'latest_job_rows_counts':counts,'missing_not_passed':['all eight platform cells'],'initial_checkruns_count':checks['total_count'],'initial_checkruns_counts':{k:sum(1 for x in checks['check_runs'] if (x['conclusion'] or x['status'])==k) for k in sorted({x['conclusion'] or x['status'] for x in checks['check_runs']})}},
 'runs':runrows,'critical_main_steps_from_original_root_snapshot':critical,
 'new_terminal_for_root_unique_log_receipt':{'closeout':closeout},
 'soak':soak,
 'concrete_failures':[],
 'critical_test_selection':{
  'source_inputs':[identity(ci),identity(test),identity(cursor)],
  'scope_integration_target':'cc-eval --test p8_scale','scope_unique_methods':scope_tests,'cursor_library_target':'cc-eval --lib benchmark::oracle::streaming::tests','cursor_unique_methods':cursor_tests,
  'first_actual_CI_command':commands['Default regression within authorized scope'].splitlines()[0],
  'first_command_coverage':'All cc-eval default library and integration targets selected; these6 methods are normal #[test], noignore. Current step inprogress does not yet prove execution or pass of each method.',
  'second_actual_CI_command':commands['P0 benchmark optional HTTP contract tests'].strip(),
  'second_command_coverage':'Same6 unique methods selected again under eval-http; two configurations must not be counted as12 unique methods. Currently pending.',
  'filtered_eval_suite':commands['Eval suite'].strip(),
  'filtered_eval_suite_does_not_establish_these_six_methods':True,
  'debug_release_boundary':'Ordinary cargo test uses debug assertions; the45-plan test checks debug ineligibility. Positive release admission is the separately existing exact --release45-plan command inside task workflow build before matrix measurement, not an additional pre-trigger gate.',
  'named_runtime_pass_claims_now':False},
 'study_start_assessment':{
  'now':'Wait: defaultregression is still inprogress; no named new scope/cursor execution success is claimed.',
  'conditional_recommendation':'Once actual fmt/Clippy/compile and relevant ordinary scope/cursor regression evidence are successful and no known blocking failure remains, root may initiate the one fixed-source45 study while the original hoursoak continues. The original task workflow has build dependency, not ordinary hoursoak dependency.',
  'required_inside_original_workflow':'Its fresh release build, exact45-plan releasecontrol and registry must succeed before any measurement matrix runs. Triggering the workflow before that internal gate succeeds does not bypass it.',
  'not_a_new_gate':'This is a cautious sequencing recommendation using existing controls, not an amendment to task acceptance or requirement for duplicate test commands/full150 study.',
  'merge_and_task_separate':'Engineering merge still waits for ordinary26 terminal disposition. Trigger/build/partial study does not grant45 acceptance or006 done; actual all45/85 and originalformal task review remain required.',
  'actions_performed':'None: no label/ref/PR mutation, trigger, cancellation, rerun or measurement.'},
 'next_meaningful_observation_utc':'2026-10-10T05:10:00Z or a new terminal event; no loop polling',
 'no_actions_logs_or_artifacts_downloaded':True,'no_tests_or_products_executed':True,'task_credit':0,'counts_unchanged':{'done':164,'remaining':28,'session_completed':1}
}
p=D/'independent-finite-CI-observation.json';p.write_text(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
print(json.dumps({'report':identity(p),'counts':counts,'not_created':'all eight platform cells','closeout_job':closeout['id'],'closeout':closeout['conclusion'],'main_active':[s['name'] for s in critical if s['status']=='in_progress']}))
