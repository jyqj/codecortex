from pathlib import Path
import json,hashlib,zipfile,collections,shutil
D=Path('/dev/shm/execution-recon-recovery-20261009/round23-G8B-shard-10000-11633529154')
raw=next((D/'intake-attempt01/extracted').rglob('raw.jsonl'));events=[json.loads(l) for l in raw.read_text().splitlines()]
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def put(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
parities=[];count=collections.Counter()
for e in events:
 if 'parity' not in e:continue
 q=e['parity'];tables=[]
 for t in q['tables']:
  row={k:t.get(k) for k in ['table','equal','incremental_rows','full_rows','equal_input_order_witness']};tables.append(row)
  kind='true' if row['equal_input_order_witness'] is True else 'false' if row['equal_input_order_witness'] is False else 'missing'
  count[kind]+=1
  if row['incremental_rows']==row['full_rows']==0:count['empty_'+kind]+=1
 parities.append({'event':e['event'],'label':e.get('label',e.get('sample')),'status':q.get('status'),'equal':q.get('equal'),'capacity_profile':q.get('capacity_profile'),'oracle_mode':q.get('oracle_mode'),'parity_wall_us':e.get('parity_wall_us'),'canonical_bytes':q.get('canonical_bytes'),'scratch_peak_bytes':q.get('scratch_peak_bytes'),'tables':tables})
assert len(parities)==9 and all(p['equal'] is True and len(p['tables'])==15 and all(t['equal'] is True for t in p['tables']) for p in parities)
obs={'source_G':'4fe927488d5cb7f26bd27c7624745fb1b6ca202b','run_id':37962416564,'artifact_id':11633529154,'scope':'read existing native raw fields only; no additional measurement','raw':{'relative_path':str(raw.relative_to(D)),'bytes':raw.stat().st_size,'sha256':sha(raw.read_bytes()),'events':dict(collections.Counter(e['event'] for e in events))},'parity_records':parities,'witness_table_record_counts':dict(count),'interpretation':['All nine checkpoints use original streaming physical scale_capacity_v1; all fifteen tables equal','The recorded boolean is true for every cold/no-op table. For each later mutation checkpoint it is true only for the three empty tables; all twelve nonempty tables report false and retained original full comparison is equal','This is one registered repetition, not a paired old/new performance experiment. No speed ratio or 100k outcome follows','Original parity wall and scratch metrics are retained as recorded; scratch metric is not whole-process peak memory'],'cumulative_accepted_this_exact_study':{'shards':3,'samples':32},'new_TODO_completed':0,'TODO_remaining':29}
put(D/'original-witness-field-observation.json',obs)
(D/'custody').mkdir();shutil.copyfile('/dev/shm/root-round23/G8-10000-materialize-original.json',D/'custody/root-formal-materialize.original.json')
shutil.copyfile('/dev/shm/execution-recon-recovery-20261009/intake-G8-10000-controller.py',D/'intake-controller.py')
shutil.copyfile(__file__,D/'seal-evidence-controller.py')
S=D/'sealed-evidence';S.mkdir();files=[]
for p in sorted(D.rglob('*')):
 if not p.is_file() or S in p.parents or p==D/'original.zip' or p==raw:continue
 b=p.read_bytes();files.append({'local_path':str(p),'relative_path':str(p.relative_to(D)),'bytes':len(b),'sha256':sha(b),'git_blob':git(b),'mode':p.stat().st_mode&0o777})
selection={'files':files,'whole_raw_retained_in_original_ZIP':True,'raw_locator':obs['raw'],'original_ZIP':{'path':str(D/'original.zip'),'bytes':(D/'original.zip').stat().st_size,'sha256':sha((D/'original.zip').read_bytes()),'git_blob':git((D/'original.zip').read_bytes())}}
put(S/'archive-selection.json',selection)
zpath=S/'G8B-original-shard-10000-11633529154-support.zip'
with zipfile.ZipFile(zpath,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for e in files:z.write(e['local_path'],e['relative_path'])
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and len(z.infolist())==len(files)
 for e in files:assert sha(z.read(e['relative_path']))==e['sha256']
prefix='artifacts/checkpoints/p8-round23-G8B-third-shard-bfcc-20261009/'
chosen=[(D/'original.zip','p8-scale-shard-10000-0-37962416564-original.zip'),(zpath,zpath.name),(S/'archive-selection.json','archive-selection.json'),(D/'independent-shard-review.json','independent-shard-review.json'),(D/'original-witness-field-observation.json','original-witness-field-observation.json')]
upload=[]
for p,n in chosen:
 b=p.read_bytes();upload.append({'local_path':str(p),'repository_path':prefix+n,'bytes':len(b),'sha256':sha(b),'git_blob':git(b),'mode':p.stat().st_mode&0o777})
put(S/'root-upload-manifest.json',{'files':upload,'accepted_shards_cumulative':3,'accepted_samples_cumulative':32,'accepted_new_shard':1,'accepted_new_samples':9,'TODO_remaining':29,'new_TODO_complete':0})
print(json.dumps({'upload_manifest':str(S/'root-upload-manifest.json'),'files':upload,'support_members':len(files),'witness_counts':dict(count)},indent=2))
