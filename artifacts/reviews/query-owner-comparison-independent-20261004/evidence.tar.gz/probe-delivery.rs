#[path = "/workspace/codecortex/crates/cc-search/src/dsl.rs"] mod dsl;
#[path = "/workspace/codecortex/crates/cc-search/src/query_target.rs"] mod query_target;
fn main() {
let rows: serde_json::Value = serde_json::from_str(include_str!("/workspace/independent-comparison-review/probes.json")).unwrap();
let mut out=Vec::new();
for row in rows.as_array().unwrap() {
 let q=row["query"].as_str().unwrap(); let parsed=dsl::parse_search_dsl(q);
 let t=query_target::QueryTarget::parse(&parsed); let ctx=query_target::NameBonusContext::parse(&parsed,&t);
 let tokens=cc_db::fts::tokenize_codeish(&parsed.text);
 let kinds=["class","interface","type_alias","enum","module","namespace","method","function","unknown"];
 let flags:Vec<_>=kinds.iter().map(|k| serde_json::json!({"kind":k,"owner":ctx.permits("Beacon",Some(k)),"other":ctx.permits("Sink",Some(k)),"target":t.permits("Beacon",Some(k),&tokens)})).collect();
 out.push(serde_json::json!({"query":q,"dsl":parsed.text,"target":format!("{:?}",t),"context":format!("{:?}",ctx),"flags":flags,"expected_owner_suppressed":row["expected_owner_suppressed"]}));
}
println!("{}",serde_json::to_string_pretty(&out).unwrap());
}
