# P5B → R5B → G5B mechanical binding preparation

Actual P5B is `d21e140ca9ebb5a73294358d64a839466c5a0076`, tree `7fb46257805e9da89737ef7a6a05574b83f50d79`, sole parent `b2a17adc188338c48b95d01761836916e5d0fcdb`. Its complete 24,162-leaf tree was reconstructed from the retained official b2 delta and this one original formatter-selected replacement. The official P metadata matches the reconstruction. This is a byte/identity check, not a Rust or CI pass.

The source domain is **1,095 product inputs / 71 BASE deltas / 142 validation inputs**. Only `crates/cc-search/src/preselect.rs` changes from b2. All historical BASE before hashes, validation inputs, old source bindings and other product bytes remain exact. SQL/G4 candidate files are not introduced.

`generate-g-bindings.py` is prepared and AST parsed, but has not run. It requires actual immutable P5B and R5B metadata, a genuine non-author canonical review, its installed Git blob and exact complete maps. No provisional review or placeholder commit is accepted. The canonical path is `artifacts/checkpoints/p8-preselect-ci-format-bfcc-20261009/independent-source-review.json`.

The seeds are the original **b2** guard and registry, verified against the complete b2 tree and official H→b2 changed-path response. The generator permits only the four original guard pins and the original necessary registry fields. Validation remains unchanged, so the expected actual registry delta is five fields: product source, review source, review digest, complete product map and BASE delta map. The guard algorithm, BASE, FROZEN and historical logic are untouched. Runtime/source admission remains the original CI's job; this generator neither signs a review nor runs the original verifier.

The original formatter failure belongs to b2 CI run37942313068/check113859546484. The new test-only formatting bytes have not yet been executed here. R5B is pending actual installation at preparation time. PR188/G4 remains an independent head and execution domain.
