"""Read only new nine already-extracted artifacts and existing original receipts.
No old shard read, original validators, archive readers, ELF or workload execution.
"""
import collections,datetime,hashlib,json
from pathlib import Path
ROOT=Path('/workspace/scratch/bfccb8494ba0'); OUT=Path(__file__).resolve().parent
IN=ROOT/'round43-next9-original-intake'; BUILD=ROOT/'round42-new45-build-original-intake'
G='f97c5068d056969705e8387ba1f37d83847f5bee'; RUN=38026411200
identities={}
def read(p):
 b=p.read_bytes();identities[str(p)]={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()};return b
def load(p):return json.loads(read(p))
def dump(name,x):(OUT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
t=load(IN/'terminal.json');registry=load(BUILD/'original-build/task-registry.json');bt=load(BUILD/'validation-attempt01/original-validate-build-return.json')
assert t['source']==G and t['run_id']==RUN and t['attempt']==1 and t['accepted_cells']==9 and t['failed_cells']==0 and t['accepted_records']==18
assert t['validate_build_calls']==t['compile_or_measurement_calls']==t['old_slots_reexecuted']==0
assert load(IN/'shared-source-build-before.json')==load(IN/'shared-source-build-after.json')
custody=load(IN/'stdio-preseal-custody-check.json');assert custody['all_complete'] and not custody['validator_reexecuted']
official=load(ROOT/'round43-new45-study/0544-new45-jobs-and-full-artifacts.original.json')
jobs=json.loads(official['jobs_original']['structuredContent']['content'])['jobs']
expected={('body',50000,0),('config',50000,0)}|{('batch_10',s,0) for s in (1000,5000,10000,50000)}|{('batch_100',s,0) for s in (1000,5000,10000)}
assert {tuple(x['slot']) for x in t['records']}==expected
old=load(ROOT/'round42-new45-first12-independent-review/independent-first12-review.json')
prior6=load(ROOT/'round43-next6-independent-review/independent-new-six-review.json')
oldslots={tuple(c['slot']) for c in old['cells']}|{tuple(c['slot']) for c in prior6['cells']};assert len(oldslots)==18 and oldslots.isdisjoint(expected)
assert old['source']==G and old['run_id']==RUN and old['registry_sha256']==bt['outer']['registration_sha256']
tables={'document_manifest','resolution_frontier','semantic_edges','dispatch_sites','resolution_manifests','resolution_dependencies','public_surfaces','files','symbols','imports','symbol_refs','call_edges','chunks','test_edges','routes'}
selected=[];cells=[]
for item in t['records']:
 profile,scale,rep=item['slot']; d=IN/f'{profile}-{scale}-{rep}'; sd=d/'original-shard'; nd=sd/'native-shard/native'
 ret=load(d/'original-validate-shard-return.json');ex=load(d/'original-validator-execution.json')
 assert ex['exit_code']==0 and ex['original_validate_shard_calls']==1 and ex['validate_build_calls']==ex['measurement_or_compile_calls']==0
 output=read(d/'original-validator.stdout');assert output==read(d/'captured-stdout.frozen-original')==read(d/'original-validate-shard-return.json')
 assert hashlib.sha256(output).hexdigest()==ex['stdout']['sha256'] and len(output)==ex['stdout']['bytes']
 assert read(d/'original-validator.stderr')==read(d/'captured-stderr.frozen-original')==b''
 assert load(d/'shard-before.json')==load(d/'shard-after.json')
 sr=load(sd/'task-shard.json');nr=load(nd/'report.json');assert nr['summary']==load(nd/'worker-summary.json')
 assert ret['plan']==sr['plan'] and ret['plan'] in registry['plans']
 assert ret['study']==sr['study']==registry['study']
 assert ret['driver_source']==sr['driver_source']==registry['driver_source'] and len(ret['driver_source']['inputs'])==11
 assert ret['registration_sha256']==bt['outer']['registration_sha256']
 assert ret['build_receipt_sha256']==sr['task_build_receipt_sha256']==old['task_build_receipt_sha256']
 assert sr['passed'] is True and sr['status']=='passed' and sr['task_statuses_changed'] is False
 assert sr['files']['native-shard/source-before.json']==sr['files']['native-shard/source-after.json']
 assert ret['engine']['engine_head_observed']==G and ret['engine']['binary_digest']==registry['binary_blake3'] and ret['engine']['eval_debug_assertions'] is False
 assert nr['status']=='measurement_complete' and nr['exit_code']==nr['worker_exit_code']==0 and nr['stderr_complete'] is True
 assert nr['worker_binary_digest_before']==nr['worker_binary_digest_after']==registry['binary_blake3'] and nr['worker_binary_unchanged'] is True
 assert nr['fixture_cleanup']['error'] is None and nr['summary']['passed'] is True and nr['summary']['sample_count']==2
 assert [m['group'] for m in ret['measurements']]==[f'scale-{scale}/cold',f'scale-{scale}/{profile}']
 hashes=load(d/'native-hash-subprocess-originals.json');assert len(hashes)==2
 for h,key in zip(hashes,('plan_digest','raw_digest')):
  assert h['returncode']==0 and '--hash-file' in h['argv'] and not read(d/h['stderr']['file'])
  assert read(d/h['stdout']['file']).decode().strip()==nr[key]
 events=collections.Counter();parities=[];builds=[];stages=[]
 with (nd/'raw.jsonl').open() as f:
  for line,text in enumerate(f,1):
   e=json.loads(text);events[e.get('event')]+=1
   if e.get('event') in ('cold_parity','stage_finished'):
    selected.append({'slot':item['slot'],'line':line,'raw_path':str(nd/'raw.jsonl'),'original_event':e})
    p=e['parity'];assert p['equal'] is True and p['status']=='equal' and p['different_tables']==[]
    assert len(p['tables'])==15 and {v['table'] for v in p['tables']}==tables
    for v in p['tables']:
     assert type(v['equal']) is bool and v['equal']
     assert type(v['full_rows']) is int and type(v['incremental_rows']) is int and v['full_rows']==v['incremental_rows']
     assert isinstance(v['full_digest'],str) and v['full_digest']==v['incremental_digest']
     assert type(v['different_row_count']) is int and v['different_row_count']==0 and v['different_row_examples']==[]
    parities.append({'line':line,'event':e['event'],'equal_tables':15,'canonical_bytes':p.get('canonical_bytes'),
                     'scratch_peak_bytes':p.get('scratch_peak_bytes'),'oracle_mode':p.get('oracle_mode'),
                     'comparison':p.get('comparison'),'limits':p.get('limits'),'capacity_profile':p.get('capacity_profile')})
    if e['event']=='stage_finished':assert e['complete'] is True and e['full_complete'] is True and e['passed'] is True;stages.append({k:v for k,v in e.items() if k!='parity'})
   if e.get('event')=='build_finished':
    r=e['report'];builds.append({'line':line,'label':e['label'],'full':e['full'],'resolution_freshness':r.get('resolution_freshness'),
     'dirty_propagation':r.get('dirty_propagation'),'dirty_plan':r.get('dirty_plan'),'build_timing':r.get('build_timing'),'phase_timing':r.get('phase_timing')})
 assert len(parities)==2 and len(stages)==1
 incremental=[x for x in builds if not x['full']];assert len(incremental)==stages[0]['incremental_builds'] and incremental[-1]['resolution_freshness']['complete'] is True
 job=next(j for j in jobs if j['name']==f'measure ({profile}-{scale}, {profile}, {scale})')
 assert job['head_sha']==G and job['status']=='completed' and job['conclusion']=='success'
 steps=[s for s in job['steps'] if s['number'] in (7,48,49,50,51)];assert len(steps)==5 and all(s['conclusion']=='success' for s in steps)
 a=item['artifact'];assert a['workflow_run']['id']==RUN and a['workflow_run']['head_sha']==G and a['digest']=='sha256:'+item['whole_zip']['sha256']
 cells.append({'slot':item['slot'],'artifact':a,'whole_zip':item['whole_zip'],'original_return':identities[str(d/'original-validate-shard-return.json')],
 'execution':ex,'producer':{'id':job['id'],'name':job['name'],'conclusion':job['conclusion'],'completed_at':job['completed_at'],'steps':steps},
 'plan':ret['plan'],'engine':ret['engine'],'environment':ret['environment'],'profile_environment':ret['profile_environment'],'measurement_environment':ret['measurement_environment'],
 'native_report':nr,'measurements':ret['measurements'],'resource_snapshot_count':len(ret['resource_snapshots']),
 'event_counts':dict(events),'parities':parities,'stage_finished':stages[0],'builds':builds,
 'first_incremental_incomplete':incremental[0]['resolution_freshness']['complete'] is False,
 'stdio_two_exclusive_copies_plus_return_equal':True})
report={'schema':'independent-original-next6-peer-v1','reviewer':'/root/pr_triage','source':G,'run_id':RUN,'attempt':1,
 'protocol':'p8-profile-task-descriptive-v1','registry_sha256':bt['outer']['registration_sha256'],'binary_blake3':registry['binary_blake3'],
 'binary_sha256':registry['binary_sha256'],'observer':registry['driver_source'],'accepted_new_cells':9,'accepted_new_records':18,
 'cumulative':{'cells':27,'expected_cells':45,'records':54,'expected_records':85,'setup':27,'mutation':27,'fanout':0,
  'cold_curve_selected_setup':4,'cold_curve_selected_scales':[1000,5000,10000,50000],'cold_100k':None},
 'remaining':{'cells':18,'records':31,'setup':13,'mutation':13,'fanout':5},
 'previous_peers':['b0c2bf92ba9a9bdc6ebd7b089ffe520d147db81d','5423307a14e5a53277e839880b157262e9d79c70'],'old_whole_artifacts_reopened':0,'old_original_validators_reexecuted':0,
 'original_new_validator_calls':9,'original_new_hash_utility_calls':18,'peer_validator_or_hash_utility_calls':0,'peer_zip_crc_reads':0,
 'new_parity_observations':18,'new_equal_table_observations':270,
 'receiver_immutable_evidence':{'status':'pending actual immutable publication at peer read time', 'terminal_identity':identities[str(IN/'terminal.json')], 'pending_actual_manifest':str(IN/'sealed/upload-manifest.actual.json')},
 'producer_snapshot':{'started':official['started'],'ended':official['ended'],'source_file':'round43-new45-study/0544-new45-jobs-and-full-artifacts.original.json'},
 'cells':cells,'input_identities':list(identities.values()),'limitations':[
  'New nine only. Old eighteen accepted by immutable prior peers; no old ZIP/raw/validator re-read or execution.',
  '54 cumulative records split27setup27mutation; cold curve is preselected no_op4setup subset, not four additional records.',
  'N1 descriptive fresh histories; CPU/host/cache/settings retained per cell, no cross-source pooling, N30/stable-tail or performance adoption assertion.',
  'No100k/fanout or remaining cells are supplied by this batch. Full45/85 and actual original aggregate remain necessary for full registered study acceptance.',
  'Original raw comparator results contain all15table rows/digests/equality fields; peer only reads these results and does not recompute DB parity.',
  'Actual mutation first-incomplete/resume observations use raw build_finished resolution_freshness, not the fanout-only-populated native summary counter.',
  'Untracked pycache is recorded; complete registered source/build and receiver inputs before/after are equal. Do not claim clean working tree.',
  'No task changes, release certification or current ordinary all-green claim. Capture prefix uploads/outer wrapper are not extra measurements.'],
 'reader_attempt_history':'Attempt01 failed before new-slot reads because mechanical adaptation incorrectly renamed the prior-six report basename; fixed to the existing immutable prior-six peer. No original validator or measurement failure implied.',
 'result':'accepted_scoped_new9_original_receipts','read_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
dump('selected-new-original-parity-and-stage-events.json',selected);dump('detailed-original-nine-review.json',report)
short={k:v for k,v in report.items() if k not in ('cells','input_identities')}
short['cells']=[{'slot':c['slot'],'artifact_id':c['artifact']['id'],'artifact_name':c['artifact']['name'],'whole_zip':c['whole_zip'],
 'original_return':c['original_return'],'producer_job':c['producer']['id'],'producer_completed_at':c['producer']['completed_at'],
 'native_exit':c['native_report']['exit_code'],'native_wall_ms':c['native_report']['wall_ms'],'incremental_builds':c['stage_finished']['incremental_builds'],
 'first_incremental_incomplete':c['first_incremental_incomplete'],'final_complete':True,'full_control_complete':True,
 'equal_parities':2,'tables_per_parity':15,'cpu_model':c['environment']['cpu_model'],'roles':['setup','mutation'],
 'selected_cold_curve_setup':c['slot'][0]=='no_op','stdio_complete':True} for c in cells]
dump('independent-new-nine-review.json',short)
print(json.dumps({'result':report['result'],'new_cells':9,'new_records':18,'cumulative_cells':27,'cumulative_records':54,'cold_curve_scales':[1000,5000,10000,50000],'incomplete_slots':[c['slot'] for c in cells if c['first_incremental_incomplete']]}))
