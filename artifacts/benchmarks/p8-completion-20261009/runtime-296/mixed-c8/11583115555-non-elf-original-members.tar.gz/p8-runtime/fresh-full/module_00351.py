def stable_00351():
    return 351
