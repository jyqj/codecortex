from pathlib import Path
import json,math,hashlib
r=Path('/workspace/independent-boundary-review');controls=json.loads((r/'controls.json').read_text());probes=json.loads((r/'probes.json').read_text());positive=set(controls['genuine_phrases']);original=set(controls['queries'])-{x['query'] for x in controls['independent_additions']};contracts={q:('comparative' if q in positive else 'owner') for q in original};contracts.update({x['query']:x['contract'] for x in controls['independent_additions']});summary={'verdict':'pending','queries':len(controls['queries']),'query_api_comparisons':0,'common_hit_checks':0,'direct_cases':len(probes),'direct_failures':[],'boundary_output_mismatches':[],'bonus_changes':[],'rank_metadata_changes':[],'prior_code_challenges':[],'original_phrase_regression':[],'new_phrase_challenges':[],'scores':[]}
direct={a:{x['query']:x for x in json.loads((r/f'{a}-probes.json').read_text())} for a in ['candidate','rejected','delivery']}
for p in probes:
 q=p['query'];x=direct['delivery'][q];assert x['target']==direct['candidate'][q]['target']==direct['rejected'][q]['target']=='Ambiguous'
 wanted=p['contract']=='comparative';actual=x['flags'][0]['owner'];assert all(f['other'] for f in x['flags']);assert all(f['owner'] for f in x['flags'] if f['kind'] in ['method','function','unknown']);assert len({f['owner'] for f in x['flags'][:6]})==1
 if actual!=wanted:summary['direct_failures'].append({'query':q,'contract':p['contract'],'expected_owner_bonus_permitted':wanted,'actual_owner_bonus_permitted':actual,'contexts':{a:v[q]['context'] for a,v in direct.items()}})
 if q in original:assert actual==wanted,(q,'original contract changed')
def canonical(e):return dict(hits=e['raw']['machine_pack']['hits'],normalized=e['normalized'],status=e['status'],scores=e.get('scores'))
for variant in ['base','receiver','inversion']:
 arms={a:json.loads((r/f'results/{a}-{variant}/results.json').read_text()) for a in ['base','candidate','rejected','delivery']};assert len({o['source_text'] for o in arms.values()})==1;assert all(set(o['queries'])==set(controls['queries']) for o in arms.values())
 for q in controls['queries']:
  for api in ['engine','mcp']:
   summary['query_api_comparisons']+=1;entries={a:o['queries'][q][api] for a,o in arms.items()};hits={a:{h['chunk_id']:h for h in e['raw']['machine_pack']['hits']} for a,e in entries.items()}
   assert all(m.keys()==hits['base'].keys() for m in hits.values()),(variant,q,api,'hit identities')
   norm={a:{(h['path'],h['start_line'],h['end_line'],h['symbol_name'],h['kind']):h for h in e['normalized']} for a,e in entries.items()};assert all(n==norm['base'] for n in norm.values()),(variant,q,api,'source evidence')
   for before in ['base','candidate','rejected']:
    for cid,x in hits[before].items():
     y=hits['delivery'][cid];summary['common_hit_checks']+=1
     for k in x:
      if k not in ['metadata','score_trace','reasons','rerank_score']:assert x[k]==y[k],(q,cid,k)
     assert {k:v for k,v in x['metadata'].items() if k!='evidence_priority'}=={k:v for k,v in y['metadata'].items() if k!='evidence_priority'}
     if x['metadata'].get('evidence_priority')!=y['metadata'].get('evidence_priority'):summary['rank_metadata_changes'].append({'query':q,'variant':variant,'api':api,'before_arm':before,'chunk_id':cid,'before':x['metadata'].get('evidence_priority'),'after':y['metadata'].get('evidence_priority')})
     assert [t for t in x['score_trace'] if t[0]!='boost:symbol-exact']==[t for t in y['score_trace'] if t[0]!='boost:symbol-exact'];assert [t for t in x['reasons'] if t!='symbol-exact']==[t for t in y['reasons'] if t!='symbol-exact']
     for h in [x,y]:assert math.isclose(sum(v for _,v in h['score_trace']),h['rerank_score'],abs_tol=1e-9)
     if x['score_trace']!=y['score_trace']:
      delta=y['rerank_score']-x['rerank_score'];assert math.isclose(delta,.18 if before=='candidate' else -.18,abs_tol=1e-9);assert x['symbol_name']=='Beacon' and x['symbol_kind']=='class' and 'exact-target' not in x['reasons'];summary['bonus_changes'].append({'variant':variant,'query':q,'api':api,'before_arm':before,'chunk_id':cid,'delta':delta})
     else:assert x['rerank_score']==y['rerank_score'] and x['reasons']==y['reasons']
   wanted_arm='base' if contracts[q]=='comparative' else 'candidate';matches=canonical(entries[wanted_arm])==canonical(entries['delivery']);tops={a:(next(iter(m.values()))['symbol_name'] if m else None) for a,m in hits.items()}
   if not matches:summary['boundary_output_mismatches'].append({'variant':variant,'query':q,'api':api,'expected_arm':wanted_arm,'top1':tops})
   if q in original:assert matches,(variant,q,api,'original expectation changed')
   if q=='Which Beacon API rather than Sink accepts state?':assert list(tops.values())==['Beacon','Sink','Beacon','Beacon'];summary['original_phrase_regression'].append({'variant':variant,'api':api,'top1':tops})
   if q in ['Which Beacon API calls `rather()` `than()` with Commit?','Which Beacon API calls $rather $than with Commit?']:
    assert canonical(entries['candidate'])==canonical(entries['delivery']);summary['prior_code_challenges'].append({'query':q,'variant':variant,'api':api,'top1':tops});
    if variant=='inversion':assert tops['delivery']=='Commit' and tops['rejected']=='Beacon'
   if q in {x['query'] for x in controls['independent_additions'] if x['contract']=='comparative'}:summary['new_phrase_challenges'].append({'query':q,'variant':variant,'api':api,'top1':tops,'matches_base':matches})
   if q in ['Which Beacon API changes the ready state with Commit?','Which method on Beacon changes the ready state with Commit?']:
    scores={a:e['scores'] for a,e in entries.items()};summary['scores'].append({'query':q,'variant':variant,'api':api,'scores':scores})
    if variant=='receiver':assert scores['base']['top1']==0 and scores['delivery']['top1']==1 and scores['delivery']['mrr10']==1
    if variant=='inversion' and ' API ' in q:assert scores['delivery']['top1']==0 and scores['delivery']['mrr10']==.5
 assert arms['candidate']['top_k_1']['machine_pack']['hits']==arms['rejected']['top_k_1']['machine_pack']['hits']==arms['delivery']['top_k_1']['machine_pack']['hits']
summary['verdict']='REJECT' if summary['direct_failures'] or summary['boundary_output_mismatches'] else 'ACCEPT';summary['input_sha256']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in r.glob('results/*/results.json')};(r/'comparison.json').write_text(json.dumps(summary,indent=2));print('PASS identity/component invariants',summary['query_api_comparisons'],'four-arm comparisons;',summary['common_hit_checks'],'common hits');print('Original 85 expectations, original phrase/code regressions, receiver gains PASS');print(summary['verdict'],len(summary['direct_failures']),'independent boundary case failures;',len(summary['boundary_output_mismatches']),'query/API baseline mismatches');print('Changed bonus counts',{a:len([x for x in summary['bonus_changes'] if x['before_arm']==a]) for a in ['base','candidate','rejected']},'rank metadata',len(summary['rank_metadata_changes']))
# Full evidence comparison succeeds independently of the normative gate below.
