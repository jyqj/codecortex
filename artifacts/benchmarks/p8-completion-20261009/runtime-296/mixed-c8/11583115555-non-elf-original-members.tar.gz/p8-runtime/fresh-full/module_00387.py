def stable_00387():
    return 387
