def stable_00195():
    return 195
