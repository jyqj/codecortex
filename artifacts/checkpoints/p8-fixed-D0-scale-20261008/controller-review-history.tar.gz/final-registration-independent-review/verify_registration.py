#!/usr/bin/env python3
import ast, datetime, hashlib, json, pathlib, re, stat, sys, yaml, zipfile, zlib

HERE=pathlib.Path('/dev/shm/p8-D0-registration-independent-review')
AUTHOR=pathlib.Path('/dev/shm/p8-D0-full-study-controller-root')
ROOT=pathlib.Path('/workspace/scratch/2eaa00d0f93a/p8-D0-exact-source')
SOURCE='d0cb69c601e530dcef738af0c2dffb8d3b8bcf28'
RUN=37846370300
EXPECTED_REG='4a56e31e9838f0db1d83a3efd4a10d0a51f8b443dbce4413e68253881740eebc'
EXPECTED_WORKFLOW='67fce65433810d54b06b8a8713760982c17c163bac9c9c98d3c716c817adaf3e'
sys.path.insert(0,str(ROOT/'scripts'))
import p8_scale_matrix as original
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_bytes())
assert sha(AUTHOR/'registration.json')==EXPECTED_REG
assert sha(AUTHOR/'workflow.yml')==EXPECTED_WORKFLOW
assert sha(AUTHOR/'admit.py')=='a65e819d3a00f8032e04d54c8da881a6efb160671f14252e96258f57813df189'
assert sha(AUTHOR/'workflow.template.yml')=='5dda7c2170c2552eee0608e4ddbf84e95577761ad6e390e1d0ec3aa78c2a02ab'
assert (AUTHOR/'workflow.template.yml').read_bytes().count(b'__REGISTRATION_SHA256__')==1
assert (AUTHOR/'workflow.yml').read_bytes()==(AUTHOR/'workflow.template.yml').read_bytes().replace(b'__REGISTRATION_SHA256__',EXPECTED_REG.encode())
registration=load(AUTHOR/'registration.json')
before=original.source_snapshot(ROOT); observers=original.driver_snapshot(ROOT)
assert registration['source']==before['source_commit']==SOURCE
assert registration['source_tree']==before['source_tree']=='c94b6cd9f3e64de377cd646c683e5e031ddf10b1'
assert registration['complete_source_inputs']==before['inputs'] and len(before['inputs'])==1087
assert registration['source_manifest_sha256']==before['manifest_sha256']
assert registration['scale_observer_inputs']==observers['inputs'] and len(observers['inputs'])==2
run=load(HERE/'api-run.json');jobs=load(HERE/'api-jobs.json');artifacts=load(HERE/'api-artifacts.json')
assert run['id']==registration['upstream_run']==RUN and run['run_attempt']==registration['upstream_attempt']==1
assert run['head_sha']==SOURCE and run['status']=='completed' and run['conclusion']=='success'
assert run['repository']['full_name']==registration['repository']=='jyqj/codecortex'
assert run['event']=='push' and run['head_branch']=='task/p8-prefix-window-engineering-20261009'
assert run['path']=='.github/workflows/p8-prefix-window-engineering.yml'
assert jobs['total_count']==len(jobs['jobs'])==3
assert registration['upstream_jobs']==[{'id':j['id'],'name':j['name']} for j in sorted(jobs['jobs'],key=lambda j:j['id'])]
registered_time=datetime.datetime.fromisoformat(registration['registered_utc'])
for j in jobs['jobs']:
    assert j['run_id']==RUN and j['head_sha']==SOURCE and j['status']=='completed' and j['conclusion']=='success'
    assert registered_time>datetime.datetime.fromisoformat(j['completed_at'].replace('Z','+00:00'))
assert artifacts['total_count']==len(artifacts['artifacts'])==6
assert len({a['id'] for a in artifacts['artifacts']})==6
assert registration['upstream_artifacts']==[{'id':a['id'],'name':a['name'],'bytes':a['size_in_bytes'],'sha256':a['digest'][7:]} for a in sorted(artifacts['artifacts'],key=lambda a:a['id'])]
for a in artifacts['artifacts']:
    assert a['expired'] is False and a['workflow_run']['id']==RUN and a['workflow_run']['head_sha']==SOURCE
build_root=pathlib.Path('/workspace/scratch/2eaa00d0f93a/p8-D0-build-11582571291')
controls_root=pathlib.Path('/dev/shm/p8-d0-controls-reception')
diagnostic_root=pathlib.Path('/dev/shm/p8-engineering-shard-reception')
paths={11582571291:(build_root/'original.zip',build_root/'original'),11581509438:(controls_root/'11581509438.zip',controls_root/'original')}
for id in [11582252490,11582323631,11582922326,11583016525]:paths[id]=(diagnostic_root/(str(id)+'.zip'),diagnostic_root/str(id))
assert set(paths)=={x['id'] for x in registration['upstream_artifacts']}
zip_reviews=[]
for item in registration['upstream_artifacts']:
    zp,folder=paths[item['id']]
    assert zp.stat().st_size==item['bytes'] and sha(zp)==item['sha256']
    seen={}
    with zipfile.ZipFile(zp) as z:
        for member in z.infolist():
            path=pathlib.PurePosixPath(member.filename)
            assert not path.is_absolute() and '..' not in path.parts and member.filename not in seen
            assert not member.is_dir() and stat.S_ISREG(member.external_attr>>16)
            data=z.read(member)
            assert len(data)==member.file_size and zlib.crc32(data)&0xffffffff==member.CRC
            digest=hashlib.sha256(data).hexdigest();assert sha(folder/member.filename)==digest
            seen[member.filename]={'bytes':len(data),'sha256':digest}
    assert seen==original.inventory(folder)
    zip_reviews.append({'artifact_id':item['id'],'zip_sha256':sha(zp),'zip_bytes':zp.stat().st_size,'members':len(seen),'all_CRC_SHA_current_original_files_equal':True})
assert sum(x['id']==registration['build']['artifact_id'] for x in registration['upstream_artifacts'])==1
built=load(build_root/'original/build.json')
assert registration['build']['artifact_id']==11582571291
assert registration['build']['receipt_sha256']==sha(build_root/'original/build.json')
for key in ['binary_sha256','binary_blake3']:assert registration['build'][key]==built[key]
assert registration['controls']['artifact_id']==11581509438
control=load(controls_root/'original/receipt.json')
assert registration['controls']['receipt_sha256']==sha(controls_root/'original/receipt.json')
assert control['files']==original.inventory(controls_root/'original',('receipt.json',))
assert control['commands']==registration['controls']['commands']==[r['argv'] for r in control['results']]
assert len(control['commands'])==12 and all(r['exit_code']==0 for r in control['results'])
assert control['status']=='commands_completed' and control['exit_code']==0 and control['not_run_command_indices']==[] and control['source_unchanged'] is True
engineering=yaml.safe_load((ROOT/'.github/workflows/p8-prefix-window-engineering.yml').read_text())
literal_commands=None
for step in engineering['jobs']['controls_and_build']['steps']:
    lines=step.get('run','').splitlines()
    if lines and lines[0].endswith("<<'PY'"):
        syntax=ast.parse('\n'.join(lines[1:-1]))
        for node in ast.walk(syntax):
            if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='commands' for t in node.targets):literal_commands=ast.literal_eval(node.value)
assert control['commands']==literal_commands
passed=ignored=failed=0
for i in range(12):
    for case,result in re.findall(r'^test (.*?) \.\.\. (ok|ignored|FAILED)',(controls_root/'original'/f'{i:02}.stdout').read_text(),re.M):
        passed+=result=='ok';ignored+=result=='ignored';failed+=result=='FAILED'
assert (passed,ignored,failed)==(49,1,0)
for name in ['source-before.json','source-after.json']:assert load(controls_root/'original'/name)==before
review_files={
 'original_build':pathlib.Path('/dev/shm/p8-D0-build-independent-review/review.json'),
 'original_diagnostic_1000':pathlib.Path('/dev/shm/p8-D0-diagnostic-validation/11582323631/review.json'),
 'original_diagnostic_10000':pathlib.Path('/dev/shm/p8-D0-diagnostic-validation/11582922326/review.json')}
assert registration['independent_prerequisite_review_sha256']==[{'kind':kind,'sha256':sha(path)} for kind,path in review_files.items()]
assert [d['scale'] for d in registration['diagnostics']]==[1000,10000]
for d in registration['diagnostics']:
    raw=diagnostic_root/str(d['artifact_id']);review=load(review_files['original_diagnostic_'+str(d['scale'])])
    assert d['receipt_sha256']==sha(raw/'shard.json')==review['shard_receipt_sha256']
    assert review['original_validate_build_passed'] is True and review['original_validate_shard_passed'] is True
    assert review['source']==SOURCE and review['build_receipt_sha256']==registration['build']['receipt_sha256']
for id,scale in [(11582252490,1000),(11583016525,10000)]:
    capacity=load(diagnostic_root/str(id)/'receipt.json')
    assert capacity['status']=='capacity_available' and capacity['exit_code']==0 and capacity['scale']==scale
    assert capacity['source_commit']==SOURCE and capacity['observer_sha256']==sha(ROOT/'scripts/p8_runner_capacity.py')
    assert capacity['required_free_bytes']==scale*262144+4*1024**3 and capacity['final']['free_bytes']>=capacity['required_free_bytes']
plans=[{'scale':scale,'shard_index':index,'plan':original.registered_plan(scale,index,30,30,12648430,18000000,original.CAPACITY_PROFILE)} for scale in [100000,50000,10000,5000,1000] for index in range(30)]
assert original.exact_equal(registration['primary_cells'],plans) and len({(x['scale'],x['shard_index']) for x in plans})==150
workflow=yaml.safe_load((AUTHOR/'workflow.yml').read_text())
assert workflow['jobs']['measure']['strategy']['matrix']=={'scale':[100000,50000,10000,5000,1000],'shard':list(range(30))}
assert workflow['jobs']['measure']['strategy']['max-parallel']==registration['new_execution']['maximum_concurrent_cells']==20
assert workflow['jobs']['measure']['timeout-minutes']==registration['new_execution']['job_timeout_minutes']==350
assert workflow['env']['P8_REGISTRATION_SHA256']==EXPECTED_REG
assert registration['new_execution']['python_timeout_seconds']==18120 and registration['new_execution']['raw_bytes_per_cell']==536870912
assert registration['new_execution']['new_primary_cells']==150 and registration['new_execution']['groups']==50 and registration['new_execution']['expected_raw_samples']==1500
assert original.source_snapshot(ROOT)==before and original.driver_snapshot(ROOT)==observers
assert sha(AUTHOR/'registration.json')==EXPECTED_REG and sha(AUTHOR/'workflow.yml')==EXPECTED_WORKFLOW
report={'schema':'p8-D0-final-registration-independent-prelaunch-review-v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/acceptance_audit',
 'decision':'accepted_for_publication_and_first_attempt_of_independent_D0_study','source':SOURCE,'upstream_run':RUN,
 'registration_sha256':EXPECTED_REG,'workflow_sha256':EXPECTED_WORKFLOW,'controller_script_sha256':sha(AUTHOR/'admit.py'),
 'registration_created_after_actual_three_jobs_completed':True,'independent_current_API_run_jobs_artifacts_all_success_exact':True,
 'all_six_unique_original_ZIP_and_unpacked_member_CRC_SHA':zip_reviews,
 'original_control_commands_literal_from_D0_workflow':12,'control_passed_executions':passed,'original_ignored_executions':ignored,'control_failed_executions':failed,
 'actual_original_validate_build_and_both_validate_shard_reviews_rechecked':True,'complete_source_inputs':1087,'original_scale_observers':2,
 'two_original_capacity_receipts_match_source_helper_and_required_space':True,
 'new_primary_cells':150,'all150_plans_exact_original_registered_plan':True,'unique_cells':150,
 'workflow_only_registration_placeholder_changed_from_accepted_v3':True,
 'limitations':['Publication must preserve reviewed exact bytes on the auxiliary controller commit before executing; that commit itself is still pending here.',
 'Every new cell executes once atD0 with original budget/first-attempt/aggregate/source gates; failed cells are retained and never substituted.',
 'The2 engineering diagnostics are admission extras, not samples in the new150. PriorG and failedlocalG remain independent.',
 'No new study measurement, wholeN30 acceptance, P5 source/fullCI/release approval, or originalTODO closure has occurred in this review.'],
 'source_observer_and_registration_before_after_unchanged':True,'new_Cargo_or_product_workload':False,'TODO_closed':0,'TODO_remaining':29,
 'local_review_files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(HERE.iterdir()) if p.is_file() and p.name not in ['review.json','verify.stdout','verify.stderr']}}
(HERE/'review.json').write_bytes(original.json_bytes(report))
print(json.dumps({'decision':report['decision'],'review_sha256':sha(HERE/'review.json'),'six_ZIP_members':sum(x['members'] for x in zip_reviews),'cells':150}))
