def stable_00286():
    return 286
