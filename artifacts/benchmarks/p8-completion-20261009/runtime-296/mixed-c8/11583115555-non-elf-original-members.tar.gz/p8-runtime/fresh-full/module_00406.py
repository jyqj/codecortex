def stable_00406():
    return 406
