#!/usr/bin/env python3
"""Read-only exact forward composition for PR180 after external #185 merge."""
import ast, copy, hashlib, json, re
from pathlib import Path
OUT=Path(__file__).resolve().parent
IN=Path('/workspace/scratch/bfccb8494ba0/root-round13/current-merge-trees-transfer/extracted')
OLD=Path('/workspace/scratch/bfccb8494ba0/pr180181-readonly')
V2=Path('/dev/shm/todo-audit-pr180-public-dependency-fix-v2')
# Reuse only helper definitions from the preceding read-only audit. Do not execute its top-level writer.
module=ast.parse((OUT/'audit-complete-trees.py').read_text())
helpers=ast.Module(body=[n for n in module.body if isinstance(n,ast.FunctionDef)],type_ignores=[])
exec(compile(helpers,str(OUT/'audit-complete-trees.py'),'exec'))
base_x=json.loads((IN/'mainfd9.json').read_text())
head_x=json.loads((IN/'pr180head4652.json').read_text())
new_x=json.loads((OUT/'new-main55aa-complete-derived-tree.json').read_text())
compute_trees(new_x['tree'],'2cac0dd284a7db2bbce8dfa02942f7c19c8d43c0')
base,head,new=(leafmap(x['tree']) for x in (base_x,head_x,new_x))
changed_main=different(base,new)
changed_head=different(base,head)
divergent=sorted(p for p in base.keys()|new.keys()|head.keys()
                if identity(new.get(p))!=identity(base.get(p))
                and identity(head.get(p))!=identity(base.get(p))
                and identity(new.get(p))!=identity(head.get(p)))
bindings=['scripts/reviewed-source-registry-v15.json','scripts/verify_reviewed_source_v15.py']
assert divergent==bindings
combined={};decisions={}
for p in base.keys()|head.keys()|new.keys():
 b,h,n=base.get(p),head.get(p),new.get(p)
 if p in bindings:chosen,why=h,'branch binding kept temporarily; new R/G required'
 elif identity(h)==identity(n):chosen,why=h,'same immutable file on both parents'
 elif identity(h)==identity(b):chosen,why=n,'latest main change, branch unchanged at common base'
 elif identity(n)==identity(b):chosen,why=h,'PR180 change, latest main unchanged at common base'
 else:raise AssertionError(('unresolved source conflict',p))
 if chosen is not None:combined[p]=copy.deepcopy(chosen)
 decisions[p]=why
manifest=json.loads((V2/'source-manifest.json').read_text())
for item in manifest['modified_files']:
 p=item['path'];v=item['after'];assert combined[p]['sha']==item['before']['git_blob']
 combined[p]={'mode':v['mode'],'type':'blob','sha':v['git_blob'],'size':v['bytes']}
 decisions[p]='frozen v2 fix, exact source-manifest bytes'
assert all(p in combined for p in head.keys()|new.keys())
assert all(identity(combined[p])==identity(new[p]) for p in new if p=='README.md' or p.startswith('docs/'))
assert all(identity(combined[p])==identity(v) for m in [head,new] for p,v in m.items() if p.startswith('artifacts/'))
def row_tree(leaves):
 rows=[dict(v,path=p) for p,v in leaves.items()]
 dirs=set()
 for p in leaves:
  parts=p.split('/')
  dirs.update('/'.join(parts[:i]) for i in range(1,len(parts)))
 assert not dirs.intersection(leaves)
 rows += [{'path':p,'mode':'040000','type':'tree','sha':'0'*40} for p in dirs]
 hashes=compute_trees(rows)
 for r in rows:
  if r['type']=='tree':r['sha']=hashes[r['path']]
 compute_trees(rows,hashes[''])
 return sorted(rows,key=lambda r:r['path']),hashes['']
rows,predicted_tree=row_tree(combined)
is_product=lambda p:p in ('Cargo.toml','Cargo.lock') or p.startswith('crates/')
validation_excluded=set(bindings)|{'.github/workflows/ci.yml'}
is_validation=lambda p:p.startswith(('scripts/','.github/workflows/','tests/source_integrity/')) and p not in validation_excluded
reg_old=json.loads((OLD/'registry180.json').read_text())
reg_new=json.loads((OUT/'55aa-registry.raw').read_text())
assert reg_old['validation_inputs']==reg_new['validation_inputs']
validation={p:v for p,v in combined.items() if is_validation(p)}
assert validation=={p:v for p,v in head.items() if is_validation(p)}=={p:v for p,v in new.items() if is_validation(p)}
assert len(validation)==139
old_guard=(OUT/'180guard.raw').read_text(); new_guard=(OUT/'55aa-guard.raw').read_text()
normalize=lambda s:re.sub(r'^(PRODUCT|REVIEW|REVIEW_PATH|REGISTRY_SHA256) = .*$',r'\1 = <PIN>',s,flags=re.M)
assert normalize(old_guard)==normalize(new_guard)
review_response=json.loads((OUT/'55aa-review-response.json').read_text())
review_bytes=review_response['content'].encode();assert hashlib.sha1(b'blob '+str(len(review_bytes)).encode()+b'\0'+review_bytes).hexdigest()==review_response['sha']
assert sha(review_bytes)==reg_new['review_sha256']
review_new=json.loads(review_bytes);assert review_new['complete_inputs']==reg_new['complete_inputs'] and review_new['validation_inputs']==reg_new['validation_inputs']
product_sha={};donor={};fixed={v['path']:v['after']['sha256'] for v in manifest['modified_files']}
for p,v in combined.items():
 if not is_product(p):continue
 if p in fixed:product_sha[p]=fixed[p];donor[p]='frozen_v2'
 elif identity(v)==identity(head.get(p)):
  product_sha[p]=reg_old['complete_inputs'][p];donor[p]='3ff_registry_and_unchanged_actual4652_blob'
  if identity(v)==identity(new.get(p)):assert product_sha[p]==reg_new['complete_inputs'][p]
 elif identity(v)==identity(new.get(p)):
  product_sha[p]=reg_new['complete_inputs'][p];donor[p]='55aa_canonical_review_and_actual_blob'
 else:raise AssertionError(('unmapped product bytes',p))
delta={}
for p in reg_old['delta'].keys()|reg_new['delta'].keys():
 old_info,new_info=reg_old['delta'].get(p),reg_new['delta'].get(p)
 if old_info is not None and new_info is not None:assert old_info['before_sha256']==new_info['before_sha256'],p
 before=(old_info or new_info)['before_sha256']
 if product_sha[p]!=before:delta[p]={'before_sha256':before,'sha256':product_sha[p]}
assert len(product_sha)==1093 and len(delta)==59
new_product_paths=[p for p in changed_main if is_product(p)]
assert len(new_product_paths)==7
assert all(p not in {x['path'] for x in manifest['modified_files']} for p in new_product_paths)
prospective={'kind':'read_only_virtual_combination_not_commit_or_execution','product_commit':None,
 'expected_parents':['4652cad11dde4b41126544a38fddf25eb2fb7474','55aa2bcf355441585bcf980e1d6f4fab8eebe59d'],
 'predicted_tree_without_new_review_archive':predicted_tree,'base_source':reg_old['base_source'],
 'complete_inputs':product_sha,'delta':delta,'validation_inputs':reg_old['validation_inputs'],
 'input_donors':donor,'actual_input_mode_blob_inventory':{p:v for p,v in combined.items() if is_product(p) or is_validation(p)},
 'counts':{'product':1093,'delta':59,'validation':139},'source_execution_credit':'none_for_this_uncreated_combination'}
prospective_receipt=write('prospective-55aa-product-input-maps.json',prospective)
new_leaves={p:new.get(p) for p in changed_main}
review_meta={k:review_new.get(k) for k in ['source','source_tree','base','scope','verdict','independent_reviewers','unresolved_blockers']}
report={
 'scope':'actual immutable Git metadata and virtual composition; no commit/source write/remote action or runtime test',
 'frozen_latest_main':'55aa2bcf355441585bcf980e1d6f4fab8eebe59d',
 'frozen_PR180_head':'4652cad11dde4b41126544a38fddf25eb2fb7474',
 'common_base':'fd9ca5db6485b575872c722995c451db926d05c9',
 'source_tree_main55aa_recomputed':'2cac0dd284a7db2bbce8dfa02942f7c19c8d43c0',
 'all_main_files':len(new),'all_union_files':len(combined),
 'both_changed_conflicts':{p:{'common_base':base.get(p),'branch':head.get(p),'main':new.get(p),'P_resolution':decisions[p]} for p in divergent},
 'product_or_validation_conflict_beyond_two_bindings':False,
 'file_directory_collisions':[],
 'latest_main_additional_product_inputs':{p:{'common_base':base.get(p),'main':new[p],'P':combined[p],'sha256':product_sha[p]} for p in new_product_paths},
 'latest_main_changes_from_fd9':new_leaves,
 'PR180_product_paths_distinct_from_latest_main':[p for p in changed_head if is_product(p)],
 'latest_main_added_artifact_paths':[p for p in new.keys()-base.keys() if p.startswith('artifacts/')],
 'PR180_only_artifacts_preserved':[p for p in head.keys()-new.keys() if p.startswith('artifacts/')],
 'all_main_and_PR_artifact_mode_blobs_preserved':True,
 'all_latest_README_docs_tasks_mode_blobs_preserved':True,
 'all_139_validation_mode_blobs_and_SHA256_preserved':True,
 'guard_logic_diff_only_four_pins':True,
 'old_source_executions_not_relabelled':True,
 'existing_main_review_locator':{'path':'artifacts/checkpoints/p8-install-compat-36fea-20261009/published-independent-source-review.json','git_blob':review_response['sha'],'bytes':len(review_bytes),'sha256':sha(review_bytes),'metadata':review_meta},
 'proposed_P':prospective_receipt,'predicted_P_tree':predicted_tree,
 'do_not_use_superseded_fd9_only_tree':'0bb881a1e34456ac4556c0256bba56defdb48004',
 'previous_fd9_only_reports_retained_for_exact_historical_scope':True,
 'R_G_still_require_actual_P_and_independent_review':True,
}
result=write('55aa-full-union-audit.json',report)
print(json.dumps({'result':result,'predicted_P_tree':predicted_tree,'counts':prospective['counts'],
                 'main_new_products':new_product_paths,'binding_conflicts':divergent,
                 'new_main_artifacts':len(report['latest_main_added_artifact_paths']),
                 'preserved_PR180_only_artifacts':len(report['PR180_only_artifacts_preserved'])},indent=2))
