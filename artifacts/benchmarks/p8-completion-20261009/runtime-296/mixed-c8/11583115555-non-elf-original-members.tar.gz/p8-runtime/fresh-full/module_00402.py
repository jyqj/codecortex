def stable_00402():
    return 402
