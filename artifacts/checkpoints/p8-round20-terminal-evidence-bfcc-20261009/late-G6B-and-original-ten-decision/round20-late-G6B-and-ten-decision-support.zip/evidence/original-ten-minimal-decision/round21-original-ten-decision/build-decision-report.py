#!/usr/bin/env python3
"""Read existing accepted reports; produce task coordination only, never execute product."""
from pathlib import Path
import hashlib
import json

B=Path(__file__).resolve().parent
CRIT=Path('/dev/shm/todo-audit-round17-original-ten-critical-path/original-ten-critical-path-review-v2.json')
DEFS=CRIT.with_name('current-main-original-ten-definition-extract.json')
C3=Path('/dev/shm/pr-triage-round20-CI-C3ff-M7F/independent-C3ff-failed-original-intake-review.json')
COV=C3.with_name('retained-raw-coverage-facts.json')
FOUR=Path('/dev/shm/pr-triage-G2-db-lock-cohort-37930392164/complete-four-C-cohort/complete-G2-four-C-independent-review.json')
PEER=Path('/dev/shm/execution-recon-recovery-20261009/round18-fourC-peer-and-PR184/independent-four-C-acquisition-evidence-thin-review.json')
LEDGER=Path('/dev/shm/root-round17/current-main-ledger-parsed-reserialized.json')
def read(p):return json.loads(p.read_bytes())
def ident(p):
    x=p.read_bytes();return {'path':str(p),'bytes':len(x),'sha256':hashlib.sha256(x).hexdigest()}
def save(name,o):(B/name).write_text(json.dumps(o,ensure_ascii=False,indent=2,sort_keys=True)+'\n')

c,d,f,q,g,peer,ledger=[read(p) for p in [CRIT,DEFS,C3,COV,FOUR,PEER,LEDGER]]
assert g['complete_Cs']==[1,4,8,16] and g['missing_Cs']==[] and g['total_original_operations']==3600
assert peer['verdict']=='accepted_scoped_complete_original_four_C_acquisition_observation_component'
assert f['source']=='3ffcefc3b28ee1a4ed80caecebd7208a45c3e302'
assert f['actual_native_terminal']['exit_code']==3 and f['layered_failures']['aggregate']['passed'] is False
assert q['build_start_count']==q['build_finish_count']==1002 and q['completed_original_parity_event_count']==6
assert q['unfinished_stage']=='scale-100000/repetition-0/batch_10' and q['stages_with_no_mutation_start']==['batch_100','batch_1000']
assert f['counts']['prior_C3ff_accepted_shards_reported']==4 and f['counts']['registered_shards']==150
defs={t['id']:t for t in d['tasks']}
entries=[
('P8-005','完整规模','有范围内的 fixed-e3 单次100k及正确性子门；多个研究的小规模分片是有效部分证据。','自身未满足：完整固定seed/release的1k/5k/10k/50k/100k；full_scale子门仍open。','无未完成硬依赖（004已done）。','取得一个来源、锁定协议与样本身份完整的五容量研究及相关回归；现有失败研究不能补位或拼接。'),
('P8-006','增量与fanout','已有部分阶段完整15表parity、归因计数和原回归。','自身未满足：完整no-op/body/API/config/batch与超预算闭包/fanout总体；C3ff的batch10未完、batch100/1000未开始。','005。','与005用同一个完整可信研究共同收口；不另造第二套150研究。'),
('P8-007','四C混合负载','Gc8四C混合/排队/尾部/错误与fake-backfill组件已接受；G2=4d18四C实际DB acquisition组件现已完整接受。','没有新发现自身范围缺口；按实际source分别引用，不能合并默认/观测feature分布。','006。','把已封G2四格证据加入原任务依据；无需为本机G1再跑C8/C16。待006。'),
('P8-008','冷/重开/热分层','Gc8 lifecycle1230样本、431sessions及原N/分布/CI已独审。','已有组件范围内无未解决缺口。','007。','复用原分层证据及明确source；待007，不因文档/主干推进重复采样。'),
('P8-009','资源与费用归属','Gc8 mixed/lifecycle/backfill/soak的client/server/process-tree、disk/FTS、reported/estimated/unavailable已审。','既有计量组件无新缺口；最终完整规模结果取得后按其真实范围追加账目。','008。','汇总已审归属及单位；unknown/unavailable保持原样，不新增全树峰值测量门。'),
('P8-010','长时soak','Gc8原3600.054553094秒、3601操作/1201build/2400compound reads及终点15表一致已接受。','已有原一小时组件无未解决缺口。','009。','复用原长时证据；不把四C锁观察变成四个新一小时soak。'),
('P8-011','故障恢复','Gc8原recovery故障/恢复/费用与原件已接受；保留各实际二进制/source身份。','已有组件范围无新缺口；后续任何新回归失败另列实际源，不能被旧结果遮盖。','007、010（P7-020已done）。','引用已封故障矩阵与实际范围；待依赖，不自动重开全恢复研究。'),
('P8-012','冷构建平台矩阵','Gc8 Linux/macOS×1.95/stable×default/semantic八格及原collector全部已接受。','已有八格范围无新缺口；一个新Linux CI不能冒充新源八平台已测。','011。','保持完整八格证据；待011，若声明新目标产品再核相关适用性。'),
('P8-013','红线/非零退出','Gc8六个原Rust契约与七个保留CLI退出1/1/1/1/2/2/2已接受。','已有确定性门控范围无新缺口；inconclusive/失败仍不可自动passed。','012。','引用原fixture/CLI原件；待012，不追加可选门充当原任务条件。'),
('P8-016','回滚','Gc8历史277f/schema24与current/schema25、备份恢复/缓存隔离/default-semantic回退及704源桥接已接受。','已有受控版本对范围无新缺口；不是新main或发布tag的实测认证。','012、013（P7-020已done）。','复用已审版本对/恢复步骤；待依赖，不新增发布tag门。')]
rows=[]
for tid,title,accepted,gap,deps,action in entries:
    rows.append({'id':tid,'title':title,'original_status':defs[tid]['status'],'original_hard_dependencies':defs[tid]['depends_on'],
                 'accepted_components':accepted,'remaining_own_scope':gap,'remaining_dependency_explanation':deps,'next_minimal_action':action,
                 'own_scope_complete_only_at_declared_component_sources':tid not in ['P8-005','P8-006'],'done':False})
task005=next(t for t in ledger['tasks'] if t['id']=='P8-005')
task006=next(t for t in ledger['tasks'] if t['id']=='P8-006')
index_rows=[]
for t in [task005,task006]:
    for e in t['evidence']:
        index_rows.append({'task':t['id'],'source':e.get('target_sha',e.get('source')),
          'status':e.get('status',e.get('scope')),'artifact_locators':e.get('artifact_paths',e.get('artifacts',[])),
          'accepted_measurement_shards':e.get('accepted_measurement_shards'),'registered_measurement_shards':e.get('registered_measurement_shards'),
          'full_aggregate_accepted':e.get('full_aggregate_accepted'),
          'declared_limitations':e.get('limitations',e.get('summary'))})
index={'scope':'Only already retained original task005/006 evidence index and accepted review summaries; no new repository/network search',
  'parsed_ledger_is_not_original_blob_bytes':True,'rows':index_rows,
  'result':'No indexed already accepted complete same-source five-scale study or separately locked lower-N complete alternative found.',
  'explicit_exclusions':['fixed-e3 candidate/baseline each single100k scoped subgate, not full five-scale population',
    '60-file engineering sample and10k budget-ended controls not full release acceptance',
    'G275 run37896198208 index accepts3/150 shards32/1500 samples; five capacity receipts are not five completed measurement groups',
    'Gc8 failed4/150 remains partial; C3ff failed4/150 remains distinct partial population',
    'Build/source-admission/Rust success alone is not full scale acceptance'],
  'unreceived_archive_or_global_nonexistence_claim':False}
save('bounded-existing-index-reuse-check.json',index)
report={'schema_version':1,'scope':'Round21 minimal task/evidence coordination; no task definition or state changes',
 'counts':{'done':163,'remaining':29,'newly_done':0},'rows':rows,
 'new_since_round17':['Original four-C DB acquisition observation gap is filled by complete fixed G2=4d18 cohort and independent peer; old G1 C8/C16 absence is not a remaining task gate.',
   'C3ff complete failed original is retained and original validators rejected it; no accepted count increment.'],
 'C3ff_decisive_failure':{'source':f['source'],'run_id':f['run_id'],'native_exit':3,'status':'deadline_exceeded','wall_ms':18022655,
   'summary':None,'worker_exit_code':None,'aggregate_passed':False,'aggregate_original_exit':1,'accepted_shards':4,'registered_shards':150,
   'accepted_samples_previously_reported':41,'registered_samples':1500,'build_pairs':1002,'partial_equal_parities':6,
   'parity_labels':[r['label'] for r in q['completed_parities']],
   'unfinished_stage':q['unfinished_stage'],'stages_never_started':q['stages_with_no_mutation_start'],
   'why_no_task_credit':'Build_finished closes an internal build only. Six equal parities close only their own completed stages; no batch10 parity/stage receipt, no batch100/1000, no complete repetition or population, no passing aggregate. Never count 1002 builds as primary samples.'},
 'original_N_and_population_boundary':c['N_and_population_exact_scope'],
 'source_and_cohort_boundary':c['cohort_and_source_rules'],
 'minimal_critical_actions':['Keep failed C3ff and other original populations immutable; do not finish them with another source or erase failed primary samples.',
    'Choose the actual integrated product with relevant source/correctness regression evidence, then obtain complete original five-capacity+incremental/fanout evidence under the applicable locked protocol. Current release protocol remainsN>=30; no lower alternative is established.',
    'Use one complete study to support005+006. After genuine acceptance, close original dependency chain using already accepted source-bound components and accurate applicability, without repeating them solely for head/docs changes.'],
 'not_required_new_work':['G1 Mac C8/C16 replay after complete G2 four-C acceptance','New lock-wait threshold/SQLite busy decomposition/trace-all/four new one-hour studies',
     'Second duplicate150 study solely for006','Fresh all-component reruns solely because main advanced or the ledger commit differs','New paid/live/holdout conditional certification when its original scope is not activated'],
 'source_references':[ident(p) for p in [CRIT,DEFS,C3,COV,FOUR,PEER]],
 'limitations':'Own-component acceptance is at each declared original source/feature/platform. It is not blanket latest-head performance/release certification. A claim for a behavior-changing new target needs relevant actual applicability/regression evidence, not renamed old raw.',
 'original_materials_modified':False,'network_calls':0,'product_or_validator_runs':0,'task_state_changes':0}
save('original-ten-minimal-decision.json',report)
lines=['# 第21轮原十任务最小决策核','',
 '现有证据中，005/006仍有真实自身验收缺口；其余八项的已声明来源组件已接受，原硬依赖仍未闭合。163 done / 29 remaining，本轮新增完成0。',
 '', '| 原任务 | 已满足的自身组件（保持原source） | 仍缺什么 | 下一最小动作 |','|---|---|---|---|']
for r in rows:lines.append('| '+r['id']+' '+r['title']+' | '+r['accepted_components']+' | '+r['remaining_own_scope']+' 硬依赖：'+r['remaining_dependency_explanation']+' | '+r['next_minimal_action']+' |')
lines.extend(['','C3ff保持4/150片、41/1500原样本。1002对build只是内部子操作全部结束；6个完整15表相等结果仅是cold、no_op、body、api、config、batch1的阶段事实。batch10没有stage_finished/parity，batch100/1000未开始，原5小时deadline终态exit3、aggregate失败exit1。因此不能把005/006记done，也不能把该100k失败片中的阶段补计为新完整样本。',
 '', '005任务行要求固定seed/release五容量，本身没有写150个GitHub job；008任务行要求N/分布/CI，也没有单独写数值N。现有P8-SCALE release协议明确N≥30，所启动scale_capacity_v1固定为150分片/1500样本；已开始的协议不能改、补位或跨source拼接。没有从既有索引找到已被接受的同源完整五容量研究或另一个已锁定较低N的完整替代。',
 '', 'G2=4d18的C1/4/8/16各900原操作及DB acquisition观察已全收全审，原C8/C16范围现在已有实证；无需再把本机G1 C8/C16作为新增硬门。观察feature分布不并入默认build延迟，不新增SQLite内部busy分解或新阈值。',
 '', '不同独立组件可在任务证据中保留各自实际来源；一个规模研究内部则必须保持原source/build/seed/driver/cohort身份。完整005+006研究一旦真实通过，可沿原依赖使用已有八项组件收口，无需因主干文档变化自动重跑全部组件。这不是对最新head统一性能/发布的认证。',
 '', '本报告仅使用既有定义摘录、归档索引与已封审查；未执行产品、validator、CLI或任何新测试，未修改状态。'])
(B/'decision-table.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'scope':'existing_reports_only','rows':len(rows),'done_delta':0,'remaining':29,'outputs':['original-ten-minimal-decision.json','bounded-existing-index-reuse-check.json','decision-table.md']}))
