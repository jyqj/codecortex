def stable_00394():
    return 394
