#!/usr/bin/env python3
"""Apply an explicitly approved, evidence-filled twelve-task payload once.

This is a progress-file editor, not a task-acceptance validator. It is prepared
without execution; the original code_index_plan owns generated progress views.
"""
import argparse
import copy
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path


TASK_PATH = Path("docs/roadmap/code-index-v2/tasks.json")
VIEW_PATHS = [
    Path("docs/roadmap/code-index-v2/05-TODO.md"),
    Path("README.md"),
    Path("docs/roadmap/code-index-v2/README.md"),
    Path("docs/roadmap/code-index-v2/08-HANDOFF.md"),
]
READ_ONLY_PATHS = [
    Path("scripts/code_index_plan.py"),
    Path("docs/roadmap/code-index-v2/06-VALIDATION.md"),
]
IDS = ["P8-006", "P8-007", "P8-008", "P8-009", "P8-010", "P8-011",
       "P8-012", "P8-013", "P8-016", "P8-017", "P8-018", "P8-019"]
ALLOWED_TASK_FIELDS = {"status", "evidence", "implementation_notes"}
ALLOWED_ROOT_FIELDS = {"next_task", "current_phase", "last_implementation_date"}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def normalized_definition(task):
    return {k: v for k, v in task.items() if k not in ALLOWED_TASK_FIELDS}


def run_original(view, receipt_dir, name, argv):
    # Each invocation has a distinct original receipt. A failure stops the run;
    # no fallback, quiet rerun, or substituted generator is performed.
    start = datetime.now(timezone.utc).isoformat()
    with (receipt_dir / (name + ".stdout")).open("wb") as out, \
            (receipt_dir / (name + ".stderr")).open("wb") as err:
        result = subprocess.run(argv, cwd=view, stdout=out, stderr=err, check=False)
    receipt = {"argv": argv, "cwd": str(view), "started_at_utc": start,
               "ended_at_utc": datetime.now(timezone.utc).isoformat(),
               "actual_exit": result.returncode}
    dump(receipt_dir / (name + ".execution.json"), receipt)
    if result.returncode != 0:
        raise SystemExit("Original " + name + " failed; retain the view and receipts.")
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--approved-payload", type=Path, required=True)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--new-view", type=Path, required=True)
    parser.add_argument("--new-receipts", type=Path, required=True)
    args = parser.parse_args()
    p = json.loads(args.approved_payload.read_text())
    assert p["apply_now"] is True
    assert p["actual_root_application_authorization"]
    assert p["actual_006_formal_decision"]
    assert p["actual_complete45_recovery_receipt"]
    assert p["actual_evidence_commit"]
    assert p["actual_application_base"]
    assert p["actual_decision_date"]
    assert p["next_task"] not in IDS
    assert [u["task_id"] for u in p["updates"]] == IDS
    assert not args.new_view.exists() and not args.new_receipts.exists()
    baseline = args.baseline.resolve()
    raw = (baseline / TASK_PATH).read_bytes()
    assert digest(raw) == p["expected_original_tasks_sha256"]
    old = json.loads(raw)
    # Existing source is in this canonical format; retaining it keeps unchanged
    # records byte-identical, in addition to the structural checks below.
    assert raw == (json.dumps(old, ensure_ascii=False, indent=2) + "\n").encode()
    assert len(old["tasks"]) == 192
    assert sum(t["status"] == "done" for t in old["tasks"]) == 164
    data = copy.deepcopy(old)
    by_id = {t["id"]: t for t in data["tasks"]}
    old_by_id = {t["id"]: t for t in old["tasks"]}
    for update in p["updates"]:
        task = by_id[update["task_id"]]
        assert task["status"] == update["expected_current_status"]
        assert all(by_id[dep]["status"] == "done" for dep in task["depends_on"])
        evidence = update["append_evidence"]
        note = update["append_implementation_notes"]
        assert evidence["date"] == p["actual_decision_date"]
        assert evidence["artifact_paths"] and evidence["formal_acceptance_reference"]
        assert isinstance(note, str) and note.strip()
        task["evidence"].append(evidence)
        task["implementation_notes"] = (task.get("implementation_notes") or "") + "\n" + note
        task["status"] = "done"
    data["next_task"] = p["next_task"]
    data["current_phase"] = by_id[p["next_task"]]["phase"]
    data["last_implementation_date"] = p["actual_decision_date"]
    assert len(data["tasks"]) == 192
    assert [t["id"] for t in data["tasks"]] == [t["id"] for t in old["tasks"]]
    for task in data["tasks"]:
        original = old_by_id[task["id"]]
        assert normalized_definition(task) == normalized_definition(original)
        if task["id"] not in IDS:
            assert task == original
        else:
            assert task["evidence"][:-1] == original["evidence"]
            assert task["implementation_notes"].startswith(original.get("implementation_notes") or "")
    for key in old:
        if key not in ALLOWED_ROOT_FIELDS | {"tasks"}:
            assert data[key] == old[key]
    assert sum(t["status"] == "done" for t in data["tasks"]) == 176
    assert by_id[p["next_task"]]["status"] not in {"done", "deferred"}
    assert all(by_id[x]["status"] == "done" for x in by_id[p["next_task"]]["depends_on"])
    args.new_view.mkdir(parents=True)
    args.new_receipts.mkdir(parents=True)
    for rel in [TASK_PATH] + VIEW_PATHS + READ_ONLY_PATHS:
        dst = args.new_view / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes((baseline / rel).read_bytes())
    dump(args.new_view / TASK_PATH, data)
    dump(args.new_receipts / "approved-input.actual.json", p)
    dump(args.new_receipts / "pre-generator-preservation.json", {
        "task_count": 192, "original_done": 164, "candidate_done": 176,
        "other_180_records_unchanged": True, "all_definitions_and_dependencies_unchanged": True,
        "updated_ids": IDS, "original_tasks_sha256": digest(raw),
        "candidate_tasks_sha256": digest((args.new_view / TASK_PATH).read_bytes())})
    write = run_original(args.new_view.resolve(), args.new_receipts, "write",
                         ["python3", "scripts/code_index_plan.py", "--write"])
    check = run_original(args.new_view.resolve(), args.new_receipts, "check",
                         ["python3", "scripts/code_index_plan.py"])
    changed = [str(rel) for rel in [TASK_PATH] + VIEW_PATHS + READ_ONLY_PATHS
               if (baseline / rel).read_bytes() != (args.new_view / rel).read_bytes()]
    assert set(changed) == {str(x) for x in [TASK_PATH] + VIEW_PATHS}
    dump(args.new_receipts / "five-file-application.actual.json", {
        "schema": "actual-twelve-task-progress-application-v1",
        "actual_application_base": p["actual_application_base"],
        "actual_evidence_commit": p["actual_evidence_commit"],
        "changed_files": changed, "task_count": 192, "done": 176, "remaining": 16,
        "session_new": 13, "write": write, "check": check,
        "other_180_records_unchanged": True, "all_192_definitions_order_dependencies_unchanged": True,
        "read_only_inputs_unchanged": True, "refs_or_PRs_modified": False})


if __name__ == "__main__":
    main()
