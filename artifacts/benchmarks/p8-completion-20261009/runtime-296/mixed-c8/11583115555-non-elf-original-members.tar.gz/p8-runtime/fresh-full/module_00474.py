def stable_00474():
    return 474
