#!/usr/bin/env python3
"""Recheck source-bound peer comparisons without running any product load."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def events(artifact):
    with (ROOT / artifact / 'native/raw.jsonl').open() as stream:
        return [json.loads(line) for line in stream]


old, new = events('11576387472'), events('11580138693')
old_input = next(row for row in old if row['event'] == 'input')
new_input = next(row for row in new if row['event'] == 'input')
assert old_input == new_input
assert old_input['input_digest'] == 'c7857b609c5221ce5f1c89f34822538cb62677e8763186f3d4002e170e86fbbb'
old_mutations = [row for row in old if row['event'] == 'mutation']
new_mutations = [row for row in new if row['event'] == 'mutation']
assert len(old_mutations) == len(new_mutations) == 8
assert old_mutations == new_mutations
old_parities = [row['parity'] for row in old if row['event'] in ('cold_parity', 'stage_finished')]
new_parities = [row['parity'] for row in new if row['event'] in ('cold_parity', 'stage_finished')]
assert len(old_parities) == len(new_parities) == 9
assert old_parities == new_parities
assert all(len(row['tables']) == 15 and row['equal'] for row in new_parities)
assert sum(sum(table['full_rows'] + table['incremental_rows'] for table in row['tables']) for row in new_parities) == 59898384
assert sum(row['canonical_bytes'] for row in new_parities) == 46344950148
assert max(row['scratch_peak_bytes'] for row in new_parities) == 3002945536

original_manifest = json.loads((ROOT / 'manifest.json').read_text())
for record in original_manifest['files']:
    data = (ROOT / record['path']).read_bytes()
    assert len(data) == record['bytes']
    assert hashlib.sha256(data).hexdigest() == record['sha256']
assert hashlib.sha256((ROOT / 'manifest.json').read_bytes()).hexdigest() == '1333c9c687d76e2a8d9d3a3a309198c133025d4449c2b96f38aeb0d66dac1c4a'

report = json.loads((ROOT / 'new50k-comparison.json').read_text())
old_report, new_report = report['measurements']
assert old_report['incremental_sql'] == new_report['incremental_sql']
assert old_report['incremental_build_count'] == new_report['incremental_build_count'] == 501
assert old_report['full_build_count'] == new_report['full_build_count'] == 10
assert old_report['incremental_files_scanned'] == new_report['incremental_files_scanned'] == 25050000
assert old_report['incremental_selected_dependents'] == new_report['incremental_selected_dependents'] == 99022
assert sum(path.stat().st_size for path in ROOT.rglob('*') if path.is_file()) < 80 * 1024**2
print(json.dumps({'status': 'passed', 'scope': 'Independent source-bound peer evidence comparison only; no product load, no paired causal inference or original G acceptance', 'input_event_equal': True, 'eight_mutation_events_equal': True, 'all_nine_complete_parity_objects_equal': True, 'original_manifest_unchanged': True}))
