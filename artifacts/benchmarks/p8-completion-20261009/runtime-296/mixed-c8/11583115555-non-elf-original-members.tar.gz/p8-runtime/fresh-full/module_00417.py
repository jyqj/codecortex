def stable_00417():
    return 417
