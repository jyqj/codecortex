#!/usr/bin/env python3
"""Read retained C50k evidence; never execute a product or acceptance helper."""
import collections
import datetime
import hashlib
import json
import pathlib
import subprocess
import zipfile

BASE = pathlib.Path('/workspace/scratch/a217aaae3bde')
ROOT = BASE / 'scale-original-c3ff'
OUT = BASE / 'scale-pr180-C-review/current-C-cost-analysis'
SOURCE = '3ffcefc3b28ee1a4ed80caecebd7208a45c3e302'

def ident(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}

def file_ref(path):
    return {'path': str(path), **ident(path.read_bytes())}

assert subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip() == SOURCE
archive = BASE / 'scale-pr180-C-review/artifacts/11611019227/11611019227.zip'
builds, parities, schemas = [], [], {}
with zipfile.ZipFile(archive) as z:
    raw = z.read('native/raw.jsonl')
    native_report = json.loads(z.read('native/report.json'))
    for line in raw.splitlines():
        event = json.loads(line)
        schemas.setdefault(event['event'], set()).update(event)
        if event['event'] == 'build_finished':
            builds.append(event)
        elif event['event'] in ('cold_parity', 'stage_finished'):
            parities.append(event)
    stderr = {n: ident(z.read(n)) for n in ('native/worker.stderr', 'supervisor.stderr')}
assert len(builds) == 511 and len(parities) == 9
assert all(p['parity']['equal'] and len(p['parity']['tables']) == 15 for p in parities)
assert all(s['bytes'] == 0 for s in stderr.values())
full = [b for b in builds if b['full']]
incremental = [b for b in builds if not b['full']]
assert len(full) == 10 and len(incremental) == 501
full_outer = sum(b['wall_us'] for b in full)
incremental_outer = sum(b['wall_us'] for b in incremental)
parity_outer = sum(p['parity_wall_us'] for p in parities)
staging = sum(b['report']['build_timing']['full_staging_us'] for b in full)
wall_us = native_report['wall_ms'] * 1000
source_paths = [
    'crates/cc-eval/src/bin/p8-scale.rs',
    'crates/cc-eval/src/benchmark/p8_scale.rs',
    'crates/cc-eval/src/benchmark/oracle.rs',
    'crates/cc-eval/src/benchmark/oracle/streaming.rs',
    'crates/cc-index/src/build_plan.rs',
    'crates/cc-index/src/indexer_phases/mod.rs',
    'crates/cc-index/src/indexer_phases/snapshot.rs',
    'crates/cc-db/src/index_db.rs',
    'crates/cc-db/src/index_db_rebuild.rs',
    'crates/cc-db/src/direct_writer.rs',
    'crates/cc-db/src/index_migrate.rs',
    'crates/cc-db/src/sql/index_v1.sql',
]
source_bindings = {}
for relative in source_paths:
    path = ROOT / relative
    facts = ident(path.read_bytes())
    expected = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', f'{SOURCE}:{relative}'], text=True).strip()
    assert facts['git_blob'] == expected
    source_bindings[relative] = facts
pr = json.loads((OUT / 'pr184-official-metadata.json').read_text())
pr_files = json.loads((OUT / 'pr184-official-files.json').read_text())
assert pr['head']['sha'] == 'b356043c2c0c970d000e5f5e32f1dff69f88454f'
assert len(pr_files) == pr['changed_files'] == 14
assert 'crates/cc-db/src/sql/index_v1.sql' not in {f['filename'] for f in pr_files}
assert 'crates/cc-db/src/index_db_rebuild.rs' not in {f['filename'] for f in pr_files}
remote_binding = {}
for basename in ('direct_writer.rs', 'index_migrate.rs'):
    path = OUT / ('pr184-' + basename)
    facts = ident(path.read_bytes())
    expected = next(f['sha'] for f in pr_files if f['filename'] == 'crates/cc-db/src/' + basename)
    assert facts['git_blob'] == expected
    remote_binding[basename] = {'path': str(path), **facts}
old = (ROOT / 'crates/cc-db/src/direct_writer.rs').read_text()
new = (OUT / 'pr184-direct_writer.rs').read_text()
extract_old = old[old.index('pub(crate) fn extract_index_statements'):old.index('/// Emit `DROP INDEX')]
extract_new = new[new.index('pub(crate) fn extract_index_statements'):new.index('/// Select explicitly maintained indexes')]
assert extract_old == extract_new
drop_old = old[old.index('pub(crate) fn drop_index_statements'):old.index('/// Extract the index name')]
drop_new = new[new.index('pub(crate) fn drop_index_statements'):new.index('/// Extract the index name')]
assert drop_old == drop_new

report = {
 'schema': 'current-C50k-measured-cost-and-candidate-boundary-v1',
 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source': SOURCE, 'run_id': 37910924354, 'attempt': 1, 'artifact_id': 11611019227,
 'actions': 'Read already accepted original ZIP, parse raw timing, bind static source bytes and inspect fixed PR184 diff. No native execution, compiler, validator replay, new source/ref/plan/threshold change.',
 'artifact': file_ref(archive), 'raw_member': {'name': 'native/raw.jsonl', **ident(raw)},
 'original_stderr': stderr,
 'accepted_subset': {'shards': 4, 'required_shards': 150, 'samples': 41, 'required_samples': 1500, 'formal_completion': False, 'remaining_todos': 29},
 'nonoverlapping_wall_partition_us': {
   'full_builds_including_cold_index': full_outer, 'full_build_count': len(full),
   'incremental_builds_excluding_cold_index': incremental_outer, 'incremental_build_count': len(incremental),
   'complete_parity': parity_outer, 'parity_count': len(parities),
   'native_report_wall_ms_converted_to_us': wall_us,
   'residual_from_supervisor_rounded_wall': wall_us - full_outer - incremental_outer - parity_outer,
 },
 'nested_attribution': {'full_staging_us_inside_full_builds': staging,
     'staging_plus_disjoint_parity_us': staging + parity_outer,
     'staging_plus_parity_fraction_of_native_wall': (staging + parity_outer) / wall_us,
     'warning': 'full_staging is nested in prepare/total; never add it again to full-build wall.'},
 'full_builds': [{'label': b['label'], 'wall_us': b['wall_us'], 'build_timing': b['report']['build_timing'], 'phase_timing': b['report']['phase_timing']} for b in full],
 'parity_samples': [{'stage': p.get('label', 'cold'), 'wall_us': p['parity_wall_us'], 'canonical_bytes': p['parity']['canonical_bytes'], 'scratch_peak_bytes': p['parity']['scratch_peak_bytes'], 'tables': len(p['parity']['tables']), 'all_reported_digests_match': all(t['incremental_digest'] == t['full_digest'] for t in p['parity']['tables'])} for p in parities],
 'source_bindings': source_bindings,
 'observability_boundary': [
   'The original worker and supervisor stderr are both zero bytes. Raw records retain only BuildTiming/PhaseTiming aggregate fields.',
   'indexer_phases::time_step emits tracing::debug; DB staging emits tracing::info at write/recreate boundaries, but the retained original evidence contains none of those events. p8-scale main does not initialize a tracing subscriber.',
   'full_staging wraps payload preparation and build_temp_db_staging; it does not isolate SQL insert, FTS, explicit-index rebuilding or close/checkpoint time.',
   'Parity includes both original integrity/FK snapshots, both canonical spools, ordered exact comparison and digests. No per-component durations were captured.',
   'These nine groups have one repetition each. No p95/p99, current100k phase, ETA, OOM diagnosis or cross-source causal estimate follows.'
 ],
 'existing_optimizations_not_new_candidates': [
   'Temp full staging already applies a 64MB SQLite bulk cache, drops explicit indexes before transaction writes and recreates them afterward.',
   'Canonical spool already uses bounded prepared 64/8/1 insertion, one WITHOUT ROWID primary B-tree, 2MiB sorting cache and zero mmap.',
   'equal_rows already avoids Value parsing for byte-identical rows; signed-zero Value equality remains explicit.'
 ],
 'candidate_decisions': {
   'shared_identical_digest_prefix': {'status': 'design opportunity only; no implementation or publication', 'basis': 'Two append_digest updates process identical serialized prefixes twice; one shared prefix state can split before first byte divergence.', 'boundary': 'Original evidence does not time hashing. Saved bytes and material wall benefit are not established; comparisons, both cursors, signed-zero semantics, duplicate preservation and all limits remain mandatory.'},
   'fresh_scratch_per_table': {'status': 'not proposed without further evidence', 'reason': 'Current unconditional DELETE has no triggers; generic claims of row-by-row cleanup cost are unjustified. Reopening introduces schema/setup/allocation work and would need exact cumulative/peak accounting.'},
   'full_staging_rewrite': {'status': 'no evidence-supported low-risk source change prepared', 'reason': 'Measured aggregate identifies the region, but retained evidence does not identify a dominant internal operation; several obvious optimizations already exist.'}
 },
 'pr184_fixed_intersection': {
   'head': pr['head']['sha'], 'base': pr['base']['sha'], 'all_changed_files_count': len(pr_files),
   'official_metadata': file_ref(OUT / 'pr184-official-metadata.json'),
   'official_files': file_ref(OUT / 'pr184-official-files.json'), 'actual_two_blob_bindings': remote_binding,
   'extract_index_statements_unchanged_bytes': True, 'drop_index_statements_unchanged_bytes': True,
   'finding': 'The new selector replaces duplicated physical-index SQL on matching-schema migrate_index_db opens. It preserves the two maintenance definitions/order and caches SQL selection, not database work. The staging path directly executes FULL_SCHEMA_SQL then calls the unchanged drop/extract helpers; it does not invoke the new selector. No measured reduction of full_staging is supported.',
   'scope': 'Static hotspot intersection only, not an independent claim of all PR184 tests or whole-source admission.'
 },
 'historical_studies': 'Original 173/599/E studies retain their own source/host/status. No historical timeout or cost is assigned to current C.',
}
path = OUT / 'current-C50k-cost-and-candidate-boundary.json'
assert not path.exists(), 'append-only record already exists'
path.write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
print(json.dumps(file_ref(path)))
