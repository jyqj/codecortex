# Final PRODUCT component review

Product: `df140ad1dc97f080afd748e9571b360e0cade5fe`
Tree: `cc24dc3490aac7d52fc2b7568fd8341751fc84e0`

**Verdict: accepted_scoped. No unresolved source blockers in the eleven paths below.**

This is a non-author component review for the aggregate source review. The forwarding change I authored is excluded and is independently reviewed by build_validation. The previous pre-final review is preserved.

| Path | SHA-256 | Bytes |
| --- | --- | ---: |
| `crates/cc-eval/src/benchmark/oracle.rs` | `4a0c1b61eaecae6091ef3ea889615e3bd418f54a6b813532c00107cdbde384a1` | 8290 |
| `crates/cc-eval/src/benchmark/oracle/streaming.rs` | `dd8fd87c5518375536fea3003dc8ba45c199a595bb64ddbfbb7e74c116fe280c` | 9919 |
| `crates/cc-eval/src/benchmark/p8_scale.rs` | `f475d81683f7f253f855691ea8d5cbb5136428f0e43ec9e64fecebd892704336` | 41831 |
| `crates/cc-eval/tests/benchmark_oracle_streaming.rs` | `f41e2520995583b7c748627a3c7233cdc4e1529c644f0c7fdb362a13471a5cff` | 9280 |
| `docs/roadmap/code-index-v2/P8-SCALE.md` | `a522ec2360dfb7e4e9b3847d1e022223503e659fabc4ad75559665eaa321c7a0` | 12264 |
| `scripts/p8_compat.py` | `6dde4308d7639fd01bddbda8d7e0f68681d0673b54586482a00460b74ca4ccf9` | 26511 |
| `scripts/tests/test_p8_compat.py` | `7923a968d0b30d08adc439d9ec159b130a1b0892393b312d850b3ba5f329c478` | 20191 |
| `scripts/v14_historical_context.py` | `575c9922f74a62e44676802fc2565729afc042be3125ae7245caf9ade87f9ce6` | 8532 |
| `tests/source_integrity/v14_historical_test_adapter.py` | `52af9b6bdb58c77ce14a0a995d9cfb3c4e7653a1b125021af868942dc4d5f4e8` | 3411 |
| `tests/source_integrity/test_v14_historical_context.py` | `651632a8fc46bfe97b9cdb4eca1fb8b06d132033e9892402e667337b415c0386` | 13773 |
| `tests/source_integrity/test_reviewed_source_v14.py` | `26be23a90a88814781c201e2ad60b0bd618334f82651e1ba55f91ca98d688a0e` | 25020 |

## Findings and evidence

The original signed-zero mismatch is resolved. Canonical row ordering and side-specific digests retain legacy behavior; equality compares real sorted rows using legacy Value semantics, with duplicate rows retained. Snapshot, integrity/FK and all resource errors propagate. The bounded SQLite scratch design has independently observed resource rejection controls and a covering-index plan.

The compatibility change normalizes only actual schema defaults, binds every locked query/repetition, preserves full gold/query identity, binds adapter/profile and exit/status pairs, and retains raw replay and final input-lock checks.

The new historical helper executes the actual prior dual proof chains against fixed immutable validation bytes and rechecks protected current files before and after. The test proxy forwards mutations and explicit fixture roots to real functions. The 14 historical and 21 v14 test methods contain substantive rejection controls; this review does not claim their final execution.

Observed parent receipts for fixed source a20d269b contain 18 passed / 0 ignored oracle, defects, route and scale regression tests plus successful Clippy. The reviewed seven oracle/compat/doc files are byte-identical at final PRODUCT. This is not a whole-final-tree runtime claim.

## Separate gates

The aggregate immutable source review, complete source/validation manifests, final v14 guard and CI, full source-integrity run, and actual repeated 10k scale control are handled separately. This review makes no TODO, full scale, quality, heldout or release completion claim.

Details and receipt hashes are in `df140ad1-component-review.json`.
