def stable_00346():
    return 346
