def stable_00458():
    return 458
