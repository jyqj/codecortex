本 PR 把已经逐条验收的 P8-006、007–013、016–019 十二项记入任务账本，并由原生成器同步四个进度视图。候选从164/192完成、28剩余变为176/192完成、16剩余；加上此前已合并的005，本次会话累计完成13个原始任务。下一任务指向P8-020，仍需其自身发布评审，不代表G8或release已通过。

固定 f97c、run38026411200/a1 的独立描述性研究已完整接受45格/85记录（40setup、40mutation、5fanout）。五cold点仅取预登记no_op setup子集。原Actions聚合只下载42输入而失败；在新目录使用同一未修改原程序、原build和完整45原输入单次恢复，实际退出0，missing/errors为空，独立复核通过。两次聚合身份及原失败均保留，恢复没有重跑测量。

结果严格限于N=1及各环境分列，不宣称稳定尾部、跨host因果提速或旧150/1500、1350研究完成。其余十一项按各自原source/run的并发、backfill、资源、soak、故障、平台、负门、回滚、所有权、文档事实和归档/replay证据逐条验收，没有把历史组件改标为本次G2研究。

验收与原件：

- [原47条逐项验收](https://github.com/jyqj/codecortex/blob/7d9acb9ccd31011ed106b41e8ac2e3c65338ee17/artifacts/checkpoints/p8-round47-complete-bfcc-20261010/formal-twelve/TWELVE-TASK-ACCEPTANCE.final.md)及[独立复核](https://github.com/jyqj/codecortex/blob/7d9acb9ccd31011ed106b41e8ac2e3c65338ee17/artifacts/checkpoints/p8-round47-complete-bfcc-20261010/final-twelve/independent-peer/independent-original47-clause-twelve-task-review.json)。
- [完整45结果](https://github.com/jyqj/codecortex/blob/7d9acb9ccd31011ed106b41e8ac2e3c65338ee17/artifacts/checkpoints/p8-round47-complete-bfcc-20261010/final45/final45-descriptive-results.md)、[全部原ZIP持久目录](https://github.com/jyqj/codecortex/blob/e21a9ae93b0a9d017909ab02d2c4a38245e35b42/artifacts/checkpoints/p8-round48-acceptance-bfcc-20261010/complete-45-raw-custody.published.json)和[正式结项裁决](https://github.com/jyqj/codecortex/blob/e21a9ae93b0a9d017909ab02d2c4a38245e35b42/artifacts/checkpoints/p8-round48-acceptance-bfcc-20261010/ROOT-CLOSEOUT-DECISION.json)。

实际验证：原 `python3 scripts/code_index_plan.py --write` 与 `python3 scripts/code_index_plan.py` 各执行一次、退出均0，输出176done/3in_progress/12todo/1blocked、四视图一致。精确五路径变更；十二项只改status/evidence/implementation_notes，全192定义、顺序、依赖及其他180原记录字节保持，原evidence/notes只追加。根字段只改next_task和日期，current_phase原P8与execution_note保持。产品、guard、registry和P/R/G无变化。该文档PR的普通CI另按实际新head执行，不冒称既有G2 CI为本PR执行。

CONTRIBUTING数字约定按本次进度范围处理：不改测试数、语料数、schema或TEST_PLAN历史基线；任务数字由原生成器核对。固定b9原baseline0+3历史DRIFT与当前G2facts0各保实际来源，不伪称新文档head执行。剩余真实provider/可选LLM/发布评审和P9条件任务仍保原状态，不在本PR中扩大完成范围。
