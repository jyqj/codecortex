#!/usr/bin/env python3
"""Read original task authority and immutable review summaries, without execution."""
from pathlib import Path
import subprocess,json,hashlib,collections,datetime
ROOT=Path('/workspace/scratch/2eaa00d0f93a/p8-staging-engineering-exact-source');OUT=Path(__file__).resolve().parent
BASE='7354db236c9d9850a75f31672697ae9eab44565e';G4='260f596582f2d82b8d7c707b61a6b8b6a43b069f';AUX='8e542e644b06a83fc82d18d9896cf82f5b2d796e';MAIN='341db995e5f092fd95aed35af84cbc8b69e1af40'
TASK='docs/roadmap/code-index-v2/tasks.json'
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,stderr=subprocess.PIPE)
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
 p=Path(p);b=p.read_bytes();return json.loads(b),{'path':str(p),'bytes':len(b),'sha256':sha(b)}
def dump(name,x):
 b=(json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode();(OUT/name).write_bytes(b);return {'path':str(OUT/name),'bytes':len(b),'sha256':sha(b)}
raw=git('show',AUX+':'+TASK);ledger=json.loads(raw);tasks={t['id']:t for t in ledger['tasks']}
assert len(tasks)==192 and ledger['task_count']==192
counts=dict(collections.Counter(t['status'] for t in tasks.values()));assert counts=={'done':163,'blocked':1,'in_progress':16,'todo':12}
assert raw==git('show',BASE+':'+TASK)==git('show',G4+':'+TASK)
main_ref,mr=read(OUT/'main-ref.json');base_root,br=read('/dev/shm/p8-pr165-independent-review/base-root.json');base_commit,bc=read('/dev/shm/p8-pr165-independent-review/base-commit.json')
assert main_ref['object']['sha']==MAIN and base_commit['sha']==MAIN and base_commit['tree']['sha']==base_root['sha']
docs=next(t for t in base_root['tree'] if t['path']=='docs');assert docs['sha']=='4b9e83d5599424a06a218c2d660abc759a4073ab'
assert git('rev-parse',BASE+':docs').decode().strip()==docs['sha']
def ancestors(tid):
 out=set();pending=list(tasks[tid]['depends_on'])
 while pending:
  t=pending.pop()
  if t not in out:out.add(t);pending.extend(tasks[t]['depends_on'])
 return sorted(out)
target=[f'P8-{i:03d}' for i in range(5,14)]+['P8-016']
assert len(target)==10
rows=[]
evidence_files={
 '8e_source_preparation':'/dev/shm/p8-staging-source-admission-preparation/preparation-review.json',
 '8e_canonical_draft':'/dev/shm/p8-staging-source-admission-preparation/independent-source-review-Pnext.draft.json',
 'G4_lifecycle':'/workspace/scratch/2eaa00d0f93a/p8-formal-evidence-G4/lifecycle/independent-review-01/inspection.json',
 'G4_gate_negatives':'/workspace/scratch/2eaa00d0f93a/p8-formal-evidence-G4/gates/inspection.json',
 'G4_P7_engineering':'/dev/shm/p8-G4-P7engineering-pr-audit/inspection.json',
 'G4_CI_failure':'/dev/shm/p8-G4-CI-reception-pr-audit/check-failure-audit.json',
 'G4_platform_partial':'/workspace/scratch/2eaa00d0f93a/p8-formal-evidence-G4/platform/partial-collector-20261008-2356.json',
 'D0_first_failure':'/dev/shm/p8-D0-first-failure-100k-08/review.json',
 'D0_receiver':'/dev/shm/p8-G4-receivers-independent-pr-audit/D0-v2-receiver-audit.json',
 'PR165':'/dev/shm/p8-pr165-independent-review/review.json'}
evidence={};bodies={}
for key,path in evidence_files.items():bodies[key],evidence[key]=read(path)
assert bodies['8e_canonical_draft']['verdict']=='draft_pending_actual_engineering_and_final_nonauthor_acceptance'
assert bodies['8e_canonical_draft']['independent_reviewers']==[] and bodies['8e_canonical_draft']['unresolved_blockers']
support={
 'P8-005':('D0 immutable release build plus 1k/10k engineering diagnostics have scoped reviews; fresh150 original study retains failed100k index8.','No complete original150/N30 matrix; first primary has no final shard after runner shutdown. No replacement/retry/drop authorized. Auxiliary8e is a different four-path source, not a replacement sample.'),
 'P8-006':('Original driver preserves all phase timings, no-op/body/API/config/batch/fanout and15-table oracle; accepted small D0 diagnostics remain original identity.','Complete original matrix and all closure/parity terminal outcomes remain absent; P8-005 hard dependency open.'),
 'P8-007':('Earlier G mixed C1/4/8/16 raw was independently reviewed with failures and queues retained; G4 P7 functional worker evidence is separately scoped.','Current G4 formal mixed/backfill artifacts not independently accepted by this gap audit. Do not substitute functional768 requests for formal mixed/tails, pool cross-CPU cells, or relabel prior G source. P8-006 open.'),
 'P8-008':('G4 lifecycle accepted_scoped:30 cold builds,400 each query strata,431 sessions,all1230 samples,CI and byte-identical original Rust replay.','P8-007 hard dependency open. Preserve30-cold unbounded upper-tailCI and explicitly uncleared OS-cache; no stablep99 or cold-disk claim. 8e four modified inputs mean no automatic source transfer.'),
 'P8-009':('G4 lifecycle review records1261 native resources and128901120 physical fixture bytes; role/process-tree unavailable and offline provider reported/estimated boundaries remain explicit.','P8-008 open. Final task receipt must retain client/server/tree attribution and full disk/FTS/cache ledger, not fill missing tree/provider metrics with0. No new permission/source accounting assumptions.'),
 'P8-010':('Same-server cache miss/hit/invalidation observer was fixed and separately source-reviewed; priorG symbol-only soak cannot establish cache reuse.','G4 actual full cache-aware soak raw/quarter coverage/3601 operations/1Hz resources/15-table endpoint still requires completed independent reception in this audit. P8-009 open. No short probe can close long-soak step.'),
 'P8-011':('PriorG recovery/277schema24 rollback had scoped original acceptance; G4 job113576446835 reported success by platform reviewer at00:48.','G4 recovery ZIP121429720B not yet independently received/verified due storage budget; original fault matrix/source/Cargo/seals must be checked. P8-007 and010 open. Dev-profile evidence is labelled dev; task011 itself is not given an invented release-only dependency.'),
 'P8-012':('Four actual macOS cells received; original exactG4 collector rejects incomplete four-cell input, preserving all8 required configurations.','Four Linux cells queued at00:48; no eight-cell completion. Require genuine fresh target/currentMSRV+stable/default+semantic/Linux+macOS receipts and original collector. P8-011 open.'),
 'P8-013':('G4 original six Rust failure-gate controls, sixCLI invocations/five retained comparison outputs scoped accepted; failed/inconclusive/invalid exits and raw preserved.','P8-012 hard dependency open; synthetic gate fixtures prove rejection behavior only, not measured retrieval quality/performance. Changed8e must retain applicable regression proof.'),
 'P8-016':('OriginalG true277schema24/25 binary-pair evidence preserves old-binary rejection,controlled rebuild/cache/version/disable and source safety scope.','Current G4 recovery/rollback artifact still unreceived as above; require actual original pair/seals/cache/isolation/source preservation. P8-012 and013 open. Do not add a task016 old-first/release-tag condition absent from original wording.')}
for tid in target:
 t=tasks[tid];rows.append({'id':tid,'title':t['title'],'status':t['status'],'depends_on':t['depends_on'],'unfinished_direct_dependencies':[d for d in t['depends_on'] if tasks[d]['status']!='done'],'unfinished_transitive_dependencies':[d for d in ancestors(tid) if tasks[d]['status']!='done'],'steps':t['steps'],'acceptance':t['acceptance'],'validations':t['validations'],'existing_scoped_evidence':support[tid][0],'remaining_gap':support[tid][1]})
assert all(t['id']=='P8-005' or 'P8-005' in t['unfinished_transitive_dependencies'] for t in rows)
frontier=[t['id'] for t in tasks.values() if t['status']!='done' and all(tasks[d]['status']=='done' for d in t['depends_on'])]
assert frontier==['P7-018','P8-005']
report={
 'schema':'p8-original-ten-gap-audit-v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/acceptance_audit','status':'read_only_original_contract_gap_audit_no_task_closure',
 'ledger':{'path':TASK,'bytes':len(raw),'sha256':sha(raw),'same_bytes_at':[BASE,G4,AUX],'current_main':MAIN,'current_main_proof':'Remote mainref plus previously verified basecommit/root tree; main docs subtree equals exactBASE docs subtree. Current maincommit is not materialized locally; no fake localHEAD or inferred blob lookup.','source_evidence':[mr,bc,br],'counts':counts,'total':192,'done':163,'remaining':29,'authority':ledger['state_authority'],'dependency_semantics':ledger['dependency_semantics']},
 'target_original_tasks':rows,'hard_dependency_frontier':frontier,'conditional_frontier_not_authorized':'P7-018 live provider is explicitly blocked/no paid authorization. This is not a way to reach ten done.','common_nonconditional_frontier':'P8-005',
 'source_admission':{'source':AUX,'scope':'1087 production inputs/30 BASE delta pairs/137 validation inputs prepared; old26 pairs and136 validation bytes unchanged; current guard stillP5/R4 and no final approval.','actual_test_population':'41 is static expected nonignored count; no actual control acceptance supplied by this draft.','source_transition':'G4 and D0 equal input bridge does not extend to8e; four changed crate files require actual identity-specific review and applicable revalidation, not relabeling.'},
 'parallel_work_that_reduces_real_gaps':[
 {'work':'Receive actual8e13-command controls,41 concrete nonignored test results,release build and original auxiliary diagnostics once produced.','owner':'root + independent source reviewer','benefit':'Establish whether the proposed staging change is executable and semantically safe before any new candidate admission.','cannot_claim':'No formal150 replacement,sourceCI pass,scale completion or causal speedup.'},
 {'work':'Receive remaining G4 platform cells and recovery/rollback original artifact within independently approved storage plan; run original offline collectors.','owner':'scale_engineering','benefit':'Completes task-specific raw evidence for011/012/016 without changing dependencies.','cannot_claim':'Actions green alone is not accepted raw; partial four cells remain incomplete.'},
 {'work':'Finish original G4 mixed/backfill and cache-aware long-soak independent raw validation when their artifacts exist.','owner':'root + pr_audit as assigned','benefit':'Closes actual evidence gaps for007/010 with operation/request denominator and same-source identity intact.','cannot_claim':'No earlierG/G2 rebrand and no C cells pooled as same-host causal comparison.'},
 {'work':'Prepare read-only017 single-owner/dead-compatibility inventory and018 schema/capability/document fact diff against a frozen chosen candidate.','owner':'Can be delegated after current artifact reception; no edits performed here.','benefit':'Find concrete cleanup/docs gaps while expensive scale work runs.','cannot_claim':'Documentation or deferred optionalP9 work cannot bypass005 or close downstream hard dependencies.'},
 {'work':'Maintain019 immutable artifact/hash/replay index and current failure dispositions; preserve all prior attempts.','owner':'root/archive reviewer','benefit':'Make final evidence reviewable and portable without another complete extraction.','cannot_claim':'No latest/passed release pointer or finalG8 approval until underlying tasks pass.'}],
 'existing_evidence_receipts':evidence,'heldout_body_read':False,'local_Cargo_or_product':False,'remote_mutation':False,'LC_restore_extract_delete':False,'TODO_closed':0,'TODO_remaining':29}
dump('review.json',report);dump('ten-original-contracts.json',rows)
print(json.dumps({'status':report['status'],'counts':counts,'target':target,'frontier':frontier,'review':str(OUT/'review.json'),'review_sha256':sha((OUT/'review.json').read_bytes())},indent=2))
