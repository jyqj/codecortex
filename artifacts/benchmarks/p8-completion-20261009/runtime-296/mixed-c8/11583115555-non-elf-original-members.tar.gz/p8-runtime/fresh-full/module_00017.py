def stable_00017():
    return 17
