def stable_00238():
    return 238
