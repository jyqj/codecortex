import subprocess,json,pathlib,datetime,hashlib,os
base=pathlib.Path(__file__).resolve().parent
repo=base/'source'
repo.mkdir(exist_ok=False)
records=base/'prepare-commands';records.mkdir()
def run(argv):
 n=len(list(records.glob('*.receipt.json')))+1
 prefix=records/f'{n:03d}'
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p=subprocess.run(argv,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
 prefix.with_suffix('.stdout').write_bytes(p.stdout);prefix.with_suffix('.stderr').write_bytes(p.stderr)
 rec={'argv':argv,'cwd':str(repo),'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}
 prefix.with_suffix('.receipt.json').write_text(json.dumps(rec,indent=2)+'\n')
 print(json.dumps({'command':n,'argv':argv,'exit':p.returncode}),flush=True)
 if p.returncode: raise SystemExit(p.returncode)
 return p.stdout
run(['git','init'])
(repo/'.git/objects/info/alternates').write_text('/workspace/scratch/bfccb8494ba0/todo-audit-round25-50k-recovery/git-object-cache/objects\n')
run(['git','remote','add','origin','https://github.com/jyqj/codecortex'])
run(['git','config','remote.origin.promisor','true'])
run(['git','config','remote.origin.partialclonefilter','blob:none'])
run(['git','fetch','--depth=1','--filter=blob:none','origin','34dc4e14dc96d077eae6173ab6885370323eff3f'])
run(['git','sparse-checkout','init','--no-cone'])
(repo/'.git/info/sparse-checkout').write_text('/scripts/\n/Cargo.toml\n/Cargo.lock\n/crates/\n/tests/source_integrity/\n/.github/workflows/\n/artifacts/checkpoints/p8-cold-wide-startup-integration-bfcc-20261009/independent-source-review.json\n')
run(['git','checkout','--detach','34dc4e14dc96d077eae6173ab6885370323eff3f'])
run(['git','rev-parse','HEAD','HEAD^{tree}'])
run(['git','status','--porcelain=v1'])
