def stable_00022():
    return 22
