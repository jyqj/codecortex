"""Retain the actual one-shot admission records, without rerunning any command."""
from pathlib import Path
import datetime
import hashlib
import json
import stat
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'sealed'
PREFIX = 'artifacts/checkpoints/p8-round41-task-profile-format-admission-bfcc-20261010/'


def meta(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}


def put(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def main():
    terminal_path = ROOT / 'actual-original-validation-attempt01/terminal.json'
    terminal = json.loads(terminal_path.read_text())
    outer = json.loads((ROOT / 'admission.outer.receipt.json').read_text())
    binding = json.loads((ROOT / 'inputs/actual-G-binding.json').read_text())
    projection = json.loads((ROOT / 'actual-G-pre-admission-inputs.json').read_text())
    closure = json.loads((ROOT / 'selected-current-history-closure.json').read_text())
    assert len(terminal['records']) in (1, 2)
    records = []
    for original in terminal['records']:
        name = original['name']
        before = ROOT / 'actual-original-validation-attempt01' / (name + '-inputs-before.json')
        after = ROOT / 'actual-original-validation-attempt01' / (name + '-inputs-after.json')
        records.append({**original, 'before_file': { 'path': str(before), **meta(before.read_bytes())},
                        'after_file': {'path': str(after), **meta(after.read_bytes())} if after.exists() else None,
                        'snapshots_byte_identical': after.exists() and before.read_bytes() == after.read_bytes()})
    result = {
        'schema': 'actual-original-admission-evidence-v1',
        'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source': binding['source'], 'source_tree': binding['source_tree'],
        'review': binding['review'], 'review_tree': binding['review_tree'],
        'product': binding['product'], 'product_tree': binding['product_tree'],
        'product_parent': projection['product_parent'],
        'review_path': binding['review_path'], 'review_sha256': binding['review_sha256'],
        'author_boundary': 'execution_recon authored some candidate components and ran these original CLIs; this is an execution record, not an independent source acceptance.',
        'materializer': json.loads((ROOT / 'materializer.outer.receipt.json').read_text()),
        'projection_counts': projection['counts'],
        'history': {'declared_blobs_checked': closure['historical_declared_blobs'],
                    'initial_missing_count': len(closure['missing']),
                    'initial_missing': closure['missing'],
                    'complete_presence_original': '08-complete-presence.stdout',
                    'read_only_cache_receipt': 'readonly-cache-reuse.json',
                    'scope': 'Explicit original historical declaration closure reused; missing current blobs fetched once. No holdout body expansion or lazy-fetch relaxation.'},
        'commands': records, 'outer_controller': outer,
        'all_planned_commands_completed': terminal['all_planned_commands_completed'],
        'passed': terminal['passed'],
        'scope': {
            'actual_original_v15': True, 'actual_original_task_plan': len(records) == 2,
            'current_projection_is_full_checkout': False,
            'rust_fmt_clippy_tests': 'not_run', 'native_or_scale_workloads': 'not_run',
            'synthetic_controls_repeated': False, 'external_refs_changed_by_this_agent': False,
            'study_samples': 0, 'task_credit': 0,
            'limits': 'Only original source-admission/task-plan commands receive execution credit. Product correctness, performance, Actions, full study completion and TODO progress are not inferred.'}}
    OUT.mkdir(exist_ok=False)
    put(OUT / 'actual-original-admission-review.json', result)
    files = sorted([p for p in ROOT.rglob('*') if p.is_file()
                    and not any(part in ('guard-view', 'sealed', '__pycache__') for part in p.relative_to(ROOT).parts)])
    rows = [{'path': str(p), 'archive_path': p.relative_to(ROOT).as_posix(),
             'mode': oct(stat.S_IMODE(p.stat().st_mode)), **meta(p.read_bytes())} for p in files]
    selection = {'schema': 'selected-admission-originals-v1', 'source': binding['source'],
                 'files': rows, 'count': len(rows), 'total_bytes': sum(r['bytes'] for r in rows),
                 'excluded': ['Git object caches and worktree', 'prior source/study ZIPs', 'Rust binaries'],
                 'all_retained_records_are_original_bytes': True}
    put(OUT / 'archive-selection.json', selection)
    zip_path = OUT / 'complete-original-admission-support.zip'
    with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for row in rows:
            path = Path(row['path'])
            info = zipfile.ZipInfo(row['archive_path'])
            info.create_system = 3
            info.external_attr = path.stat().st_mode << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())
        for name in ('archive-selection.json', 'actual-original-admission-review.json'):
            archive.write(OUT / name, name)
    with zipfile.ZipFile(zip_path) as archive:
        assert archive.testzip() is None
        for row in rows:
            assert meta(archive.read(row['archive_path'])) == {key: row[key] for key in ('bytes', 'sha256', 'git_blob')}
        assert len(archive.infolist()) == len(rows) + 2
    artifacts = []
    for name in ('actual-original-admission-review.json', 'complete-original-admission-support.zip', 'archive-selection.json'):
        path = OUT / name
        artifacts.append({'local_path': str(path), 'repository_path': PREFIX + name,
                          'mode': '100644', 'actual_created': False, **meta(path.read_bytes())})
    put(OUT / 'upload-manifest.json', {'source': binding['source'], 'artifacts': artifacts,
                                      'support_members': len(rows) + 2,
                                      'publication_commit': None, 'refs_updated': False})
    print(json.dumps({'passed': terminal['passed'], 'files': len(rows), 'artifacts': artifacts}))


if __name__ == '__main__':
    main()
