def stable_00245():
    return 245
