import hashlib,json,pathlib,stat,zipfile,shutil,datetime
B=pathlib.Path('/dev/shm/a217aaae3bde/C3ff-platform-round30'); M=pathlib.Path('/workspace/scratch/a217aaae3bde/original-C3ff-platform-gates/C3ff-ci'); H='3ffcefc3b28ee1a4ed80caecebd7208a45c3e302'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1024*1024),b''):h.update(x)
 return h.hexdigest()
records=[]; metas={}
for label,run in [('platform-artifacts',37908825722)]:
 p=M/'official-C-artifacts-1791546516716.json';cap=json.loads(p.read_text());d=json.loads(cap['raw']['structuredContent']['content']);assert d['total_count']==len(d['artifacts'])
 for x in d['artifacts']:
  if x['id'] not in (11614026675,11612849803):continue
  assert x['id'] not in metas and x['workflow_run']['id']==run and x['workflow_run']['head_sha']==H and not x['expired'];metas[x['id']]=(x,{'path':str(p),'sha256':sha(p)})
assert len(metas)==2
plan=[];total=0
for id,(md,origin) in metas.items():
 z=B/'zips'/str(id)/f'{id}.zip';assert z.is_file() and not z.is_symlink();assert z.stat().st_size==md['size_in_bytes'] and 'sha256:'+sha(z)==md['digest']
 with zipfile.ZipFile(z) as f:
  infos=f.infolist(); names=set(); files=[]
  for i in infos:
   n=i.filename;p=pathlib.PurePosixPath(n)
   assert n and not n.startswith('/') and '\\' not in n and '\0' not in n and all(t not in ('','..','.') for t in n.rstrip('/').split('/')) and not p.is_absolute(),n
   assert n not in names,n;names.add(n);mode=i.external_attr>>16
   assert not i.flag_bits&1 and stat.S_IFMT(mode) in (0,stat.S_IFREG,stat.S_IFDIR),n
   if i.is_dir():assert stat.S_IFMT(mode) in (0,stat.S_IFDIR);continue
   assert stat.S_IFMT(mode) in (0,stat.S_IFREG),n
   assert not any(x in names for x in [str(parent)+'/' for parent in p.parents if str(parent)!='.']) or True
   files.append({'path':n,'bytes':i.file_size,'zip_mode':mode,'effective_mode':stat.S_IMODE(mode) or 0o644})
  fn={x['path'] for x in files};assert all(not any(str(par) in fn for par in pathlib.PurePosixPath(n).parents if str(par)!='.') for n in fn)
  total+=sum(x['bytes'] for x in files);plan.append((id,z,md,origin,files))
assert shutil.disk_usage(B).free>total+250*1024*1024,(total,shutil.disk_usage(B).free)
for id,z,md,origin,files in plan:
 out=z.parent/'extracted';assert not out.exists();out.mkdir()
 (z.parent/'artifact-metadata.json').write_text(json.dumps(md,indent=2)+'\n')
 with zipfile.ZipFile(z) as f:
  for x in files:
   p=out/x['path'];p.parent.mkdir(parents=True,exist_ok=True);h=hashlib.sha256();count=0
   with f.open(x['path']) as inp,p.open('xb') as dest:
    for b in iter(lambda:inp.read(1024*1024),b''):h.update(b);dest.write(b);count+=len(b)
   assert count==x['bytes'];p.chmod(x['effective_mode']);x['sha256']=h.hexdigest();assert sha(p)==x['sha256'] and stat.S_IMODE(p.stat().st_mode)==x['effective_mode']
 assert {p.relative_to(out).as_posix() for p in out.rglob('*') if p.is_file()}=={x['path'] for x in files}
 assert all(not p.is_symlink() for p in out.rglob('*'));assert 'sha256:'+sha(z)==md['digest']
 records.append({'artifact_id':id,'official_metadata_origin':origin,'zip':str(z),'zip_bytes':z.stat().st_size,'zip_sha256':sha(z),'derived_root':str(out),'member_count':len(files),'expanded_bytes':sum(x['bytes'] for x in files),'files':files})
receipt={'schema_version':1,'source':H,'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'original_zips_and_complete_derived_members_verified','archive_count':len(records),'total_expanded_bytes':total,'records':records,'member_contents_verified':True,'artifact_semantic_acceptance':False,'native_workload_runs':0,'originals_retained':True}
p=B/'linux-stable-default-safe-extraction-receipt.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p),'archive_count':len(records),'member_count':sum(r['member_count'] for r in records),'expanded_bytes':total}))
(B/'linux-stable-default-pairs.json').write_text(json.dumps([[11614026675,11612849803]],indent=2)+'\n')
