"""Prepare separately reviewable exact-173 wrappers; never execute acceptance."""
from pathlib import Path
import ast, difflib, hashlib, json

BASE=Path('/workspace/scratch/a217aaae3bde/original-173-runtime')
OLD=BASE/'recovery-helper-input/restored/audit'
OUT=BASE/'helpers-275e-v1'
OUT.mkdir(exist_ok=False)
HEAD='275e8799d4947d297329073eaa3ca675d3fd0777'
files=['e_raw_cache_audit.py','preflight_e_runtime_zip.py','preflight_e_lifecycle_zip.py',
       'review_e_runtime_original.py','review_e_backfill_original.py','review_e_lifecycle_original.py',
       'lifecycle_cargo_audit.py','test_helper_controls.py','test_lifecycle_helper_controls.py']
mapping=[('a23bb72d3c954f385b99fe81ce9189885c208557',HEAD),
         ('37871838957','37890757030'),('37871838975','37890757049'),
         ('4e0aa6bbfd4d5bea00416bca2cd99318d865ffc526fdcb45897c4d300de3ac00',
          '593cf443fc914998dd2cb5a30c3caf180eb8d0d7a398a86e4624e3df2ca65e83'),
         ('1087','1089'),('combined E','fixed 173'),("'metadata.json'","'artifact-metadata.json'")]
records=[]
def describe(b):
 return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git_blob_sha1=hashlib.sha1(('blob %d\0'%len(b)).encode()+b).hexdigest())
for name in files:
 source=OLD/name; before=source.read_text(); after=before; edits=[]
 for a,b in mapping:
  n=after.count(a)
  if n: after=after.replace(a,b);edits.append(dict(old=a,new=b,count=n))
 path=OUT/name;path.write_text(after);path.chmod(0o444)
 # Applying only the explicit inverse substitutions reconstructs the complete
 # original text. No acceptance predicate is omitted or renamed.
 restored=after
 for e in reversed(edits):restored=restored.replace(e['new'],e['old'])
 assert restored==before
 assertions=lambda text:[ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(text)) if isinstance(n,ast.Assert)]
 assert assertions(restored)==assertions(before)
 diff=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(source),tofile=str(path)))
 (OUT/(name+'.diff')).write_text(diff)
 records.append(dict(path=str(path),original_path=str(source),original=describe(before.encode()),candidate=describe(after.encode()),edits=edits,original_assert_count=len(assertions(before)),candidate_assert_count=len(assertions(after)),all_original_assertions_preserved_after_exact_identity_normalization=True))
manifest=dict(schema='exact-173-helper-identity-adapter-v1',source_commit=HEAD,
 product_manifest='593cf443fc914998dd2cb5a30c3caf180eb8d0d7a398a86e4624e3df2ca65e83',source_input_count=1089,
 runtime_run=37890757030,lifecycle_run=37890757049,files=records,
 source_observer_proof=str(BASE/'actual-fixed-source-and-observer.json'),
 observer_code_comparison=str(BASE/'observer-E-to-275e-applicability.json'),
 scope='Only exact source/run/count/manifest and metadata path bindings change. Original E remains historical; new 173 raw acceptance not yet executed. All workload/statistics/cache/cleanup/oracle/resource predicates and limits unchanged.',
 acceptance_executed=False,tasks_changed=False)
(OUT/'adaptation-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps({'manifest':str(OUT/'adaptation-manifest.json'),'sha256':describe((OUT/'adaptation-manifest.json').read_bytes())['sha256'],'files':len(records)}))
