import datetime
import hashlib
import json
import pathlib
import re
import zipfile

ROOT = pathlib.Path('/workspace/scratch/bfccb8494ba0')
BASE = ROOT / 'scale-intake-primary'
OUT = BASE / 'db-wait-cleanup-P-bb29-independent'
NATIVE = ROOT / 'root-round15/native-controls-transfer'
EXTRACTED = NATIVE / 'extracted'
P0 = '3ced45d1f4bbfc38eeab3fbe1a1ef17eae26721a'
P1 = 'bb290be2deaf4334863e09dbf47fe4ccc9625f2b'
PEER = pathlib.Path('/dev/shm/pr-triage-round15-P1-native-peer/independent-P1-native-execution-review.json')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def load(p):
    return json.loads(p.read_text())

def descriptor(p):
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': sha(data), 'git_blob': blob(data)}

def write_new(p, value):
    data = (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode()
    with p.open('xb') as f:
        f.write(data)
    return descriptor(p)

zip_path = NATIVE / 'native-db-observation-P0-P1-controls-round15.zip'
zip_identity = descriptor(zip_path)
assert zip_identity['bytes'] == 3702778
assert zip_identity['sha256'] == '9c7ca53255dc31ce54fd77a91b9852436631560f0344218ef624429ffac547d0'
assert zip_identity['git_blob'] == '8fea67def09ac9931509a2b7761819953fe493fb'
manifest = load(EXTRACTED / 'archive-manifest.json')
with zipfile.ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    names = archive.namelist()
    assert len(names) == len(set(names)) == 135
    assert len(manifest['files']) == 134
    for entry in manifest['files']:
        data = archive.read(entry['path'])
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256']
        assert data == (EXTRACTED / entry['path']).read_bytes()
    assert archive.read('archive-manifest.json') == (EXTRACTED / 'archive-manifest.json').read_bytes()

audits = {
    P0: load(BASE / 'db-wait-cleanup-P-3ced-independent/actual-P-complete-source-audit.json'),
    P1: load(OUT / 'actual-P1-complete-source-audit.json'),
}
stages = ['P0-negative', 'P1-controls', 'P1-controls/continuation-canonical-temp']
all_commands = []
stage_entries = {}
extra_entries = None
rust_names = []
for stage in stages:
    folder = EXTRACTED / stage
    progress = load(folder / 'controls-progress.json')
    for rec in progress:
        assert rec == load(folder / (rec['label'] + '-receipt.json'))
        expected_P = P0 if stage == 'P0-negative' else P1
        assert rec['source_P'] == expected_P
        assert rec['tree'] == audits[expected_P]['tree']
        files = {}
        for kind in ['before', 'after', 'stdout', 'stderr']:
            ref = rec[kind]
            path = folder / ref['path']
            raw = path.read_bytes()
            assert len(raw) == ref['bytes'] and sha(raw) == ref['sha256']
            files[kind] = descriptor(path)
        before = load(folder / rec['before']['path'])
        after = load(folder / rec['after']['path'])
        assert before['source_P'] == after['source_P'] == expected_P
        assert before['tree'] == after['tree'] == rec['tree']
        assert before['entries'] == after['entries']
        entries = {e['path']: e for e in before['entries']}
        assert len(entries) == len(before['entries']) == 1250
        if expected_P in stage_entries:
            assert stage_entries[expected_P] == before['entries']
        stage_entries[expected_P] = before['entries']
        inv = audits[expected_P]['actual_input_mode_blob_inventory']
        assert len(inv) == 1237
        for path, item in inv.items():
            actual = entries[path]
            assert (actual['mode'], actual['git_blob'], actual['bytes'], actual['sha256']) == (item['mode'], item['sha'], item['size'], item['sha256']), path
        extra = [entries[k] for k in sorted(entries.keys() - inv.keys())]
        assert len(extra) == 13
        if extra_entries is not None:
            assert extra_entries == extra
        extra_entries = extra
        stdout = (folder / rec['stdout']['path']).read_text()
        stderr = (folder / rec['stderr']['path']).read_text()
        if rec['test_kind'] == 'rust':
            summaries = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', stdout)
            assert len(summaries) == 1
            assert tuple(map(int, summaries[0])) == (rec['expected_test_count'], 0, 0)
            names = re.findall(r'^test (\S+) \.\.\. ok$', stdout, re.M)
            assert len(names) == rec['expected_test_count']
            rust_names.extend(names)
        all_commands.append({
            'stage': stage, 'label': rec['label'], 'source': expected_P,
            'argv': rec['command'], 'actual_integer_exit': rec['exit_code'],
            'started_at': rec['started_at'], 'ended_at': rec['ended_at'],
            'files': files, 'receipt': descriptor(folder / (rec['label'] + '-receipt.json')),
            'expected_rust_tests': rec['expected_test_count'],
        })
    if stage == 'P0-negative':
        assert [r['exit_code'] for r in progress] == [0, 1]
        assert all(r['test_kind'] == 'none' for r in progress)
    elif stage == 'P1-controls':
        assert [r['exit_code'] for r in progress] == [0, 0, 0, 0, 1]
    else:
        assert len(progress) == 10 and all(r['exit_code'] == 0 for r in progress)
assert len(all_commands) == 17
assert len(rust_names) == len(set(rust_names)) == 60
first_python = (EXTRACTED / 'P1-controls/all-original-runtime-python-controls.stderr').read_text()
final_python = (EXTRACTED / 'P1-controls/continuation-canonical-temp/all-original-runtime-python-controls.stderr').read_text()
assert re.search(r'Ran 77 tests in ', first_python) and 'FAILED (failures=10, errors=6)' in first_python
assert re.search(r'Ran 77 tests in ', final_python) and final_python.endswith('\nOK\n')
first_methods = re.findall(r'^test_.* \(.*\) \.\.\. ', first_python, re.M)
final_methods = re.findall(r'^test_.* \(.*\) \.\.\. ', final_python, re.M)
assert len(first_methods) == len(set(first_methods)) == 77
assert first_methods == final_methods
for phase in ['before', 'after']:
    name = 'all-original-runtime-python-controls-input-' + phase + '.json'
    assert (EXTRACTED / 'P1-controls' / name).read_bytes() == (EXTRACTED / 'P1-controls/continuation-canonical-temp' / name).read_bytes()
first = load(EXTRACTED / 'P1-controls/all-original-runtime-python-controls-receipt.json')
continued = load(EXTRACTED / 'P1-controls/continuation-canonical-temp/all-original-runtime-python-controls-receipt.json')
assert first['command'] == continued['command'] and first['cwd'] == continued['cwd']
assert {k: v for k, v in continued['environment'].items() if k != 'TMPDIR'} == first['environment']
assert pathlib.PurePosixPath(continued['environment']['TMPDIR']).is_absolute()
peer_identity = descriptor(PEER)
assert peer_identity['sha256'] == 'b3486f3721d76a1476242005bf9e71313bf58d39c75af68f17b928c427a3ff5e'
peer = load(PEER)
assert peer['source_P1'] == P1 and peer['original_ZIP']['sha256'] == zip_identity['sha256']
assert peer['counts']['unique_passing_scope'] == {'Rust': 60, 'Python_methods': 77, 'Rust_ignored': 0, 'Python_skipped': 0}
review = {
    'schema_version': 1, 'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer': '/root/execution_recon', 'verdict': 'accepted_scoped_original_native_evidence',
    'source_P0': P0, 'source_P1': P1, 'original_native_ZIP': zip_identity,
    'original_ZIP_all_135_CRC_134_manifest_hashes_and_extracted_bytes_equal': True,
    'source_binding': {'commands': 17, 'before_after_snapshots': 34,
        'each_snapshot_entries': 1250, 'product': 1095, 'validation': 142,
        'all_1237_match_independently_reconstructed_exact_actual_P_source': True,
        'additional_13_inputs': extra_entries,
        'all_1250_entry_arrays_unchanged_within_exact_source': True,
        'whole_snapshot_file_equality_not_claimed': 'label/phase metadata differs; all entry arrays are equal. The repeated Python before files, and separately after files, are byte-identical across both attempts.'},
    'outcomes': peer['counts'], 'actual_unique_Rust_ok_names': sorted(rust_names),
    'original_all_77_Python_methods_same_both_attempts': True,
    'environment_boundary': peer['environment_review'],
    'cache_and_toolchain_boundary': peer['cache_and_toolchain'],
    'command_results': all_commands, 'independent_execution_peer': peer_identity,
    'negative_history_retained': ['P0 fmt exit1; no Rust/Python tests started', 'P1 first full Python77 exit1 with10failures/6errors; same77methods succeed under explicit canonical TMPDIR'],
    'limits': ['No original source-admission CLI or CI run by this reviewer.', 'Focused60Rust+77Python and default/feature cc-db Clippy do not establish fullworkspaceRust or workspaceClippy.', 'Ordinary cached/APFS engineering controls, not cold/performance evidence.', 'No actual four-C instrumented workload and no original scale sample or TODO credit.'],
}
thin_path = OUT / 'independent-native-evidence-thin-review.json'
thin_identity = write_new(thin_path, review)

draft_path = OUT / 'independent-source-review.draft.pending-execution.json'
final = load(draft_path)
assert final['verdict'] == 'pending' and final['source'] == P1
assert len(final['paths']) == 67 and all(set(v) == {'before_sha256', 'sha256'} for v in final['paths'].values())
assert len(final['complete_inputs']) == 1095 and len(final['validation_inputs']) == 142
assert final['paths'] == audits[P1]['paths']
assert final['complete_inputs'] == audits[P1]['complete_inputs']
assert final['validation_inputs'] == audits[P1]['validation_inputs']
final['verdict'] = 'accepted_scoped'
final['unresolved_blockers'] = []
final['reviewed_at_utc'] = review['reviewed_at_utc']
final['current_execution_support'] = {
    'acceptance_by_this_report': True,
    'scope': 'Retained exact P0/P1 focused native engineering originals independently verified; not fullworkspace or formal workload certification.',
    'formal_mixed_or_scale_workload_measured': False,
    'original_native_ZIP': zip_identity,
    'non_author_execution_peer': peer_identity,
    'this_reviewer_thin_verification': thin_identity,
    'outcomes': peer['counts'],
    'source_binding': review['source_binding'],
    'environment_boundary': peer['environment_review'],
    'cache_and_toolchain_boundary': peer['cache_and_toolchain'],
    'negative_history_retained': review['negative_history_retained'],
}
final['review_basis']['native_originals_thin_review'] = thin_identity
final['review_basis']['native_originals_independent_execution_peer'] = peer_identity
final['review_basis']['pending_history_retained'] = descriptor(draft_path)
final['acceptance_boundary']['source_admission'] = 'This is the completed non-author canonical source review for actual P1. R/G installation and original v15/CI remain separate; no source-admission execution is claimed here.'
final['acceptance_boundary']['latest_main_scope'] = 'Later external main4efbc97/PR186 changes are not included in actual P1 and are not covered by these native controls. Future integration requires an explicit identity bridge and appropriate controls.'
final_identity = write_new(OUT / 'independent-source-review.json', final)
print(json.dumps({'thin_review': thin_identity, 'canonical_R': final_identity, 'product': 1095, 'validation': 142, 'delta': 67, 'source': P1}, indent=2))
