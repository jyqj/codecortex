"""Read the newly accepted checkpoint01 bytes; no original semantic validator.

The previous accepted report supplies checkpoint00 event/count boundary. Only
the new raw interval is parsed here. All inference is limited to emitted records.
"""
import collections
import datetime
import hashlib
import json
from pathlib import Path
import stat
import zipfile

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'round34-diagnostic-checkpoint-01-intake/attempt01'
OLD = ROOT / 'round33-diagnostic-checkpoint-00-intake/attempt01'
BUILD = ROOT / 'round33-PR200-build-capacity-original-intake/attempt01'
BINDING = ROOT / 'round32-100k-diagnostic-intake-bound-9cc6-run38012409915/binding.json'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def identity(p):
    raw = p.read_bytes()
    return {'local_path': str(p), 'bytes': len(raw), 'sha256': sha(raw),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
            'posix_mode': oct(stat.S_IMODE(p.stat().st_mode))}

def save(p, value):
    with p.open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

reader = json.loads((OUT / 'reader/report.json').read_text())
execution = json.loads((OUT / 'reader.execution.json').read_text())
old = json.loads((OLD / 'checkpoint-prefix-review.json').read_text())
assert execution['exit_code'] == 0
assert execution['validate_build_calls'] == execution['validate_shard_calls'] == execution['inspect_raw_calls'] == execution['ELF_calls'] == 0
assert len(reader['artifacts']) == 2 and {x['id'] for x in reader['artifacts']} == {'11655358015', '11655694522'}
new = next(x for x in reader['artifacts'] if x['id'] == '11655694522')
binding = json.loads(BINDING.read_text())
built = json.loads((BUILD / 'original-validate-build-result.json').read_text())['original_build_record']
selected = OUT / 'selected-originals'
selected.mkdir(exist_ok=False)
with zipfile.ZipFile(new['zip_path']) as z:
    manifest_raw = z.read('manifest.json')
    manifest = json.loads(manifest_raw)
    (selected / 'manifest.json').write_bytes(manifest_raw)
    for item in manifest['metadata_snapshots']:
        raw = z.read(item['file'])
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
        (selected / item['file']).write_bytes(raw)
    chunks = [c for c in reader['streams']['shard/native/raw.jsonl']['chunks']
              if any(loc['artifact_id'] == '11655694522' for loc in c['retained_locations'])]
    assert len(chunks) == 1
    chunk = chunks[0]
    location = next(x for x in chunk['retained_locations'] if x['artifact_id'] == '11655694522')
    raw = z.read(location['member'])
    assert len(raw) == chunk['bytes'] and sha(raw) == chunk['sha256']
    (selected / location['member']).write_bytes(raw)
config = json.loads((selected / 'configuration.json.snapshot').read_text())
assert config['original_build_receipt_sha256'] == identity(BUILD / 'extracted/build/build.json')['sha256']
assert config['original_driver_sha256'] == built['driver_sha256']
assert (selected / 'configuration.json.snapshot').read_bytes() == (OLD / 'selected-originals/configuration.json.snapshot').read_bytes()
assert chunk['start'] == old['verified_prefixes']['shard/native/raw.jsonl']['end_exclusive']
assert old['raw_prefix']['partial_tail_bytes'] == 0
events, intervals, failures = [], [], []
offset = chunk['start']
lines = raw.splitlines(keepends=True)
for number, line in enumerate(lines):
    row = {'new_line_index': number, 'start': offset, 'end': offset + len(line), 'bytes': len(line),
           'sha256': sha(line), 'complete_newline': line.endswith(b'\n')}
    offset += len(line)
    if not row['complete_newline']:
        row['status'] = 'partial_tail_not_a_complete_event'
    else:
        try:
            event = json.loads(line)
            events.append(event)
            row.update(event=event.get('event'), label=event.get('label'), status='complete_original_event')
        except (ValueError, UnicodeError) as error:
            row.update(status='complete_line_parse_error', error=str(error))
            failures.append(row)
    intervals.append(row)
new_counts = collections.Counter(x.get('event') for x in events)
total_counts = collections.Counter(old['raw_prefix']['complete_event_counts']) + new_counts
finished = [x for x in events if x.get('event') == 'build_finished']
unfinished = list(old['started_but_not_finished_in_prefix'])
for event in events:
    if event.get('event') == 'build_started':
        unfinished.append(event)
    elif event.get('event') == 'build_finished':
        unfinished = [x for x in unfinished if x['label'] != event['label']]
finish = finished[-1] if finished else None
phase = {k: finish['report'].get(k) for k in ('elapsed_ms', 'phase_timing', 'build_timing',
    'files_scanned', 'files_added', 'files_updated', 'files_removed', 'files_skipped', 'files_parsed',
    'symbols_total', 'chunks_total', 'parse_errors', 'resolution_freshness')} if finish else None
current = next(x for x in reader['checkpoints'] if x['index'] == 1)
assert len(current['acknowledgements']) == 1 and current['acknowledgements'][0]['retained_original_and_official_digest_verified'] is True
report = {'schema': 'p8-original-diagnostic-checkpoint01-prefix-review-v1',
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source': binding['G'], 'run_id': binding['run_id'], 'attempt': 1,
    'scope': 'First custody intake of checkpoint01, retaining checkpoint00 solely as the unchanged frozen-reader continuity/ACK dependency. No native semantic predicate or measurement executed.',
    'new_original_artifact': new,
    'old_continuity_artifact': {'id': 11655358015, 'prior_accepted_review': identity(OLD / 'checkpoint-prefix-review.json'),
       'old_bytes_reread_by_frozen_reader': True, 'new_reception_or_new_sample': False},
    'frozen_reader_execution': identity(OUT / 'reader.execution.json'), 'reader_exit_code': 0,
    'accepted_diagnostic_build_reused_without_revalidation': {'result': identity(BUILD / 'original-validate-build-result.json'),
        'receipt': identity(BUILD / 'extracted/build/build.json'), 'configuration_receipt_exact': True,
        'configuration_bytes_identical_to_checkpoint00': True, 'original_build_record_not_from_full_cohort': True},
    'verified_prefixes': {name: {'start': 0, 'end_exclusive': r['verified_retained_contiguous_chunk_prefix_bytes'],
        'highest_declared_offset': r['highest_declared_offset'], 'unknown_tail_bytes': None, 'EOF_claimed': False}
        for name, r in reader['streams'].items()},
    'new_raw_interval': {**chunk, 'ends_in_newline': raw.endswith(b'\n'), 'original_line_intervals': intervals,
        'new_complete_event_counts': dict(new_counts), 'cumulative_complete_event_counts': dict(total_counts),
        'complete_line_parse_errors': failures, 'partial_tail_bytes': 0 if not lines or lines[-1].endswith(b'\n') else len(lines[-1])},
    'checkpoint01_ACK_of_checkpoint00': current['acknowledgements'][0],
    'checkpoint01_own_ACK_boundary': 'This checkpoint was frozen before its own upload; later local ACK remains unseen. Its official artifact and verified ZIP give current custody without pretending to know that later ACK.',
    'capture_faults_observed': reader['capture_faults'], 'metadata_parse_unknown': reader['metadata_parse_unknown'],
    'observer_before_seen_and_bound': reader['observer_before_seen'], 'observer_after_seen': reader['observer_after_seen'],
    'last_finished_build': {'label': finish['label'], 'full': finish['full'], 'start_us': finish['start_us'],
        'end_us': finish['end_us'], 'wall_us': finish['wall_us'], 'original_report_fields': phase,
        'original_process_snapshot': finish['process_snapshot']} if finish else old['last_finished_build'],
    'started_but_not_finished_in_retained_prefix': unfinished,
    'current_phase_boundary': 'The latest emitted record finishes cold_full_control. No following cold_parity, stage_finished or next-build event is retained. Current internal computation after that record is not directly observed.',
    'cold_parity_events': total_counts.get('cold_parity', 0), 'stage_finished_events': total_counts.get('stage_finished', 0),
    'supervisor_terminal_seen': bool(reader['supervisor_receipts']), 'native_report_seen': bool(reader['native_reports']),
    'reported_native_outcome': reader['reported_native_outcome'], 'custody_status': reader['custody_status'],
    'timing_boundary': 'Original wall/phase/build times only; nested timers must not be added. No performance ratio, cause attribution or cohort acceptance is inferred.',
    'original_function_calls': {'validate_build': 0, 'validate_shard': 0, 'inspect_raw': 0, 'ELF': 0},
    'original_semantic_validation_boundary': 'No complete native/shard terminal or completed parity checkpoint is supplied. Original predicates remain available when actual complete evidence is received; this byte reader never substitutes for them.',
    'full_cohort_run_not_mixed': 38013753078, 'accepted_cohort_shards': 0, 'accepted_samples': 0, 'TODO_credit': 0}
save(OUT / 'checkpoint01-prefix-review.json', report)
print(json.dumps({'report': identity(OUT / 'checkpoint01-prefix-review.json'), 'new_events': dict(new_counts),
    'raw_contiguous_bytes': reader['streams']['shard/native/raw.jsonl']['verified_retained_contiguous_chunk_prefix_bytes'],
    'current_native_outcome': reader['reported_native_outcome']}))
