#!/usr/bin/env python3
"""Read-only portable validation and raw-export lineage for exact C3ff cells."""
import argparse
import subprocess
import hashlib
import json
import os
from pathlib import Path
import sys
from datetime import datetime, timezone

sys.dont_write_bytecode = True
BASE = Path('/workspace/scratch/a217aaae3bde/original-C3ff-platform-gates')
SOURCE = Path('/workspace/scratch/a217aaae3bde/scale-original-c3ff')
ROOT = BASE / 'zips'
parser = argparse.ArgumentParser()
parser.add_argument('--pairs-json', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--artifact-root', type=Path, default=ROOT)
args = parser.parse_args()
ROOT = args.artifact_root
OUT = args.output
assert not OUT.exists(), 'review output must be newly owned'
ORIGINALS = ROOT
HEAD = '3ffcefc3b28ee1a4ed80caecebd7208a45c3e302'
PAIRS = json.loads(args.pairs_json.read_text())
assert isinstance(PAIRS, list) and 1 <= len(PAIRS) <= 8
assert all(isinstance(p, list) and len(p) == 2 and all(type(i) is int for i in p) for p in PAIRS)
assert len({i for p in PAIRS for i in p}) == 2 * len(PAIRS)

def check(condition, message):
    if not condition:
        raise AssertionError(message)

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def read(path):
    return json.loads(path.read_bytes())

sys.path.insert(0, str(SOURCE / 'scripts'))
import p8_cold_build as cold
source, manifest = cold.source_identity(SOURCE, HEAD)
check(subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD']).decode().strip() == HEAD, 'frozen view HEAD differs')
check(subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD^{tree}']).decode().strip() == '0e655b4258afd9ca040dd7c1ace868bf1c322a30', 'frozen tree differs')
check(source['input_count'] == 1092, 'source input count differs')
reviews, missing, original_hashes = [], [], {}
for bundle_id, raw_id in PAIRS:
    original_metadata = []
    for aid in (bundle_id, raw_id):
        folder = ORIGINALS / str(aid)
        md = read(folder / 'artifact-metadata.json')
        archive = folder / f'{aid}.zip'
        check(md['id'] == aid and md['workflow_run']['id'] == 37908825722 and md['workflow_run']['head_sha'] == HEAD, 'official artifact identity differs')
        check(archive.stat().st_size == md['size_in_bytes'] and 'sha256:' + sha(archive) == md['digest'], 'official artifact byte identity differs')
        original_hashes[str(archive)] = sha(archive)
        original_metadata.append(md)
    home = ROOT / str(bundle_id) / 'extracted'
    raw = ROOT / str(raw_id) / 'extracted/cold'
    if not (home / 'bundle.json').is_file() or not (raw / 'matrix.json').is_file():
        missing.append([bundle_id, raw_id])
        continue
    bundle = read(home / 'bundle.json')
    cell_label = '-'.join(bundle['cell'][k] for k in ('platform', 'toolchain', 'package'))
    check(original_metadata[0]['name'] == f'p8-platform-cell-{cell_label}-{HEAD}' and original_metadata[1]['name'] == f'p8-platform-raw-{cell_label}-{HEAD}', 'artifact pairing differs')
    check(bundle['schema_version'] == 2 and bundle['status'] == 'passed' and bundle['live_strict_receipt_and_stdio_replay'] is True, 'bundle v2 missing')
    actual = {p.relative_to(home).as_posix(): sha(p) for p in home.rglob('*') if p.is_file() and p.name != 'bundle.json'}
    check(actual == bundle['files'] and not any(p.is_symlink() for p in home.rglob('*')), 'bundle inventory/hash differs')
    record = read(home / 'receipt.json')
    check(record['cell'] == bundle['cell'] and dict(record['source_before'], source_root=str(SOURCE)) == source and read(home / 'source-inputs.json') == manifest, 'source differs from exact C3ff')
    check(sha(home / 'source-inputs.json') == source['manifest_sha256'], 'source manifest canonical encoding differs')
    check(sha(home / 'receipt.json') == bundle['receipt_sha256'] and sha(home / 'codecortex') == bundle['binary_sha256'] == record['binary_sha256'], 'receipt/binary differs')
    cold.verify_portable_cell(record, home, SOURCE, home / 'codecortex')
    cold.validate_smoke(home, record)
    matrix = read(home / 'matrix.json')
    check(matrix == read(raw / 'matrix.json') and matrix['source'] == record['source_before'], 'raw/export matrix differs')
    expected = {(p, t, k) for p in cold.PLATFORMS for t in cold.TOOLCHAINS for k in cold.PACKAGES}
    key = lambda x: (x['platform'], x['toolchain'], x['package'])
    check(len(matrix['cells']) == 8 and {key(x['cell']) for x in matrix['cells']} == expected, 'matrix declaration incomplete')
    selected = [x for x in matrix['cells'] if x['cell'] == bundle['cell']]
    check(len(selected) == 1 and selected[0]['status'] == 'passed' and selected[0]['receipt_sha256'] == bundle['receipt_sha256'], 'original selected receipt differs')
    check(all(x['status'] == 'not_run' and x['reason'] in ('platform_unavailable', 'cell_not_selected') for x in matrix['cells'] if x['cell'] != bundle['cell']), 'unselected cells silently passed')
    folder = '-'.join(key(bundle['cell']))
    raw_cell = raw / folder
    raw_files = {p.relative_to(raw_cell).as_posix(): sha(p) for p in raw_cell.rglob('*') if p.is_file()}
    check(raw_files == {k: v for k, v in actual.items() if k != 'matrix.json'}, 'raw source cell != exported bundle bytes')
    for parent in (home, ROOT / str(raw_id) / 'extracted'):
        for path in parent.rglob('*'):
            if path.is_file():
                original_hashes[str(path)] = sha(path)
    wire = []
    parsed = []
    for event in map(json.loads, (home / 'stdio-smoke/process/rpc.jsonl').read_text().splitlines()):
        if event['event'] == 'stdout_wire':
            data = event['text'].encode('utf-8', 'strict')
            check(len(data) == event['wire_bytes'] and hashlib.sha256(data).hexdigest() == event['wire_sha256'], 'smoke raw wire differs')
            wire.append(json.loads(data))
        if event['event'] == 'response':
            parsed.append(event['payload'])
    check(wire == parsed and len(wire) == 5, 'smoke parsed response differs from raw wire')
    reviews.append(dict(cell=bundle['cell'], bundle_artifact_id=bundle_id, raw_artifact_id=raw_id, bundle_sha256=sha(home / 'bundle.json'), receipt_sha256=bundle['receipt_sha256'], binary_sha256=bundle['binary_sha256'], source_commit=HEAD, source_input_count=source['input_count'], source_manifest_sha256=source['manifest_sha256'], observer_source_commit=record['observer_before']['source_commit'], observer_manifest_sha256=record['observer_before']['manifest_sha256'], observer_count=len(record['observer_before']['inputs']), portable_v2_passed=True, raw_export_lineage_byte_equal=True, original_unselected_seven_not_run=True, rustc_release=record['toolchain']['rustc_release'], host=record['toolchain']['host'], profile=record['profile'], build_exit_code=record['build_exit_code'], target_initially_absent=record['target_initially_absent'], smoke_requests=5, smoke_exit_code=0))

check(all(sha(Path(p)) == digest for p, digest in original_hashes.items()), 'original artifact mutated during review')
check(reviews, 'no actual original pair was reviewed')
check(len({tuple(c['cell'][k] for k in ('platform', 'toolchain', 'package')) for c in reviews}) == len(reviews), 'duplicate selected cell')
check(cold.source_identity(SOURCE, HEAD) == (source, manifest), 'fixed source changed during review')
OUT.mkdir(parents=True, exist_ok=False)
if len(reviews) == 8:
    stage = OUT / 'collector-input'
    stage.mkdir()
    for bundle_id, _ in PAIRS:
        home = ROOT / str(bundle_id) / 'extracted'
        dest = stage / str(bundle_id)
        for path in home.rglob('*'):
            if path.is_file():
                copied = dest / path.relative_to(home)
                copied.parent.mkdir(parents=True, exist_ok=True)
                os.link(path, copied)
    collected = cold.collect_cells(stage, SOURCE, HEAD)
    check(collected['counts'] == dict(passed=8, failed=0, not_run=0), 'collector not complete')
    (OUT / 'independent-collected-matrix.json').write_text(json.dumps(collected, sort_keys=True, indent=2) + '\n')
result = dict(schema_version=1, reviewer='pr_audit', created_at_utc=datetime.now(timezone.utc).isoformat(), assessment='accepted_scoped_available_platform_cells', execution_source_commit=HEAD, source=source, cells=reviews, counts=dict(accepted=len(reviews), required=8), pending_original_pairs=missing, original_files_unchanged=True, original_files_rehashed=len(original_hashes), task_completion_certified=False, hard_dependencies={'P8-012':['P8-011']}, limits=['Only original captured execution is reviewed; no new compilation or smoke execution.', 'Artifact cell status is kept separate from eight-cell completion, hard-dependency closure, and release certification.', 'Platform manifests retain their own original row encoding; no p7 canonical digest is substituted.'])
if len(reviews) == 8:
    result['assessment'] = 'accepted_scoped_complete_original_eight_cell_matrix'
    result['independent_formal_collector'] = dict(status=collected['status'], counts=collected['counts'], path=str(OUT / 'independent-collected-matrix.json'), sha256=sha(OUT / 'independent-collected-matrix.json'))
path = OUT / 'platform-C3ff-cell-review.json'
path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(path=str(path), accepted=len(reviews), required=8, source_commit=HEAD, original_files_unchanged=True)))
