def stable_00257():
    return 257
