"""First checkpoint04 intake; accepted00/01/02/03 are continuity dependencies only."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'round36-diagnostic-checkpoint-04-intake/attempt01'
OLD = ROOT / 'round36-diagnostic-checkpoint-03-intake/attempt01'
OFFICIAL = ROOT / 'round36-diagnostic-checkpoint04-official-originals.json'
BINDING = ROOT / 'round32-100k-diagnostic-intake-bound-9cc6-run38012409915/binding.json'
READER = ROOT / 'round32-100k-diagnostic-intake-preparation/read-original-diagnostic.py'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save(name, value):
    with (OUT / name).open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

OUT.mkdir(parents=True, exist_ok=False)
assert sha(READER) == 'ae7945e5f7150b350ae856a1fd22d7ad92e157c74ae73c8ab3e3799a857bca23'
assert sha(BINDING) == '12819cd48434ac181d4aaac0eb020ba936c9a48e39d02683766f5dd5f07c17cb'
index = json.loads((OLD / 'official-index.json').read_text())
official = json.loads(OFFICIAL.read_text())
artifact = next(x for x in official['parsed']['artifacts'] if x['id'] == 11656209993)
assert artifact['size_in_bytes'] == 60515 and artifact['digest'] == 'sha256:0625855284b86a6f0d6c2270e431d4691141903ff44a5808c8c9d0e8d2543277'
assert [x['index'] for x in index['artifacts']] == [0, 1, 2, 3]
index['artifacts'].append({'kind': 'checkpoint', 'index': 4, 'artifact': artifact, 'run_attempt': 1,
    'zip_path': str(ROOT / 'round36-diagnostic-original-artifacts/p8-100k-diagnostic-progress-38012409915-1-04-original.zip'),
    'official_original_reference': {'path': str(OFFICIAL), 'sha256': sha(OFFICIAL)}})
index['time_boundary'] = 'Run identity and prior job status remain historical snapshots, not current diagnostic status. New artifact metadata comes from round36 observation. Accepted00/01/02/03 are continuity inputs, not new receptions. Later PR merge does not change fixed9cc6 source.'
index['new_artifact_observed_at'] = official['at']
index['continuity_dependency'] = {'artifact_ids': [11655358015, 11655694522, 11656371239, 11656517936],
    'previous_report': str(OLD / 'checkpoint03-prefix-review.json'), 'sha256': sha(OLD / 'checkpoint03-prefix-review.json'),
    'new_artifact_ids': [11656209993]}
save('official-index.json', index)
argv = ['python3', '-B', str(READER), '--binding', str(BINDING), '--official-index', str(OUT / 'official-index.json'), '--output', str(OUT / 'reader')]
start, tick = datetime.datetime.now(datetime.timezone.utc).isoformat(), time.monotonic()
with (OUT / 'reader.stdout').open('xb') as o, (OUT / 'reader.stderr').open('xb') as e:
    r = subprocess.run(argv, cwd=ROOT, stdout=o, stderr=e, check=False)
save('reader.execution.json', {'argv': argv, 'cwd': str(ROOT), 'started_utc': start,
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'duration_seconds': time.monotonic() - tick,
    'exit_code': r.returncode, 'stdout_sha256': sha(OUT / 'reader.stdout'), 'stderr_sha256': sha(OUT / 'reader.stderr'),
    'reader_sha256': sha(READER), 'new_artifact_ids': [11656209993],
    'continuity_old_artifact_ids': [11655358015, 11655694522, 11656371239, 11656517936],
    'validate_build_calls': 0, 'validate_shard_calls': 0, 'inspect_raw_calls': 0, 'ELF_calls': 0,
    'new_downloads': 0, 'accepted_samples': 0, 'task_credit': 0})
print(json.dumps({'reader_exit': r.returncode, 'output': str(OUT)}))
raise SystemExit(r.returncode)
