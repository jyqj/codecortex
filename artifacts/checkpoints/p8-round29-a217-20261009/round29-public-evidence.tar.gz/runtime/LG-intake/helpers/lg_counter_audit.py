"""Read-only audit of LG's original two counter boundaries and their RPC bodies.

No workload, additional samples, quantile algorithm, or SQLite repair is run.
The native producer's own validation is called first; this adds only original
wire correspondence and independent integer-delta checks for its declared fields.
"""
import json
from e_raw_cache_audit import lines, value_hash


def audit_original_counter_boundaries(owner, measurement, plan, report, operations, event_counts):
    original = owner.verify_retained(measurement, plan, report)
    assert original == dict(status='original_counter_boundaries_verified', native_workload_rerun=False)
    assert event_counts.get('db_lock_observation') == 2
    boundaries = [row for _, row in lines(measurement/'raw.jsonl')
                  if row.get('kind') == 'db_lock_observation']
    assert [row['phase'] for row in boundaries] == ['before_work', 'after_work_and_sampler_drain']
    before, after = [row['response'] for row in boundaries]
    counters = report['db_lock_observation']['counters']
    assert set(counters) == set(owner.ROLES)
    for role in owner.ROLES:
        assert set(counters[role]) == set(owner.METRICS)
        for metric in owner.METRICS:
            left, right, delta = before[role][metric], after[role][metric], counters[role][metric]
            for key in owner.COUNTERS:
                if key not in ('in_flight', 'elapsed_ns_max'):
                    assert delta[key] == right[key] - left[key]
            assert delta['attempts'] == sum(delta[k] for k in ('acquired', 'poisoned', 'failed', 'would_block'))
            assert delta['in_flight_at_boundaries'] == [0, 0]
            assert delta['process_lifetime_max_ns_at_end'] == right['elapsed_ns_max']
            assert delta['interval_max_ns'] is None
    requests, responses = [], {}
    for _, event in lines(measurement/'product/rpc.jsonl'):
        if event['event'] == 'request':
            payload = event['payload']
            if (payload.get('method') == 'tools/call'
                    and payload.get('params') == dict(name='status', arguments=dict(aspect='lock_observation'))):
                assert payload['id'] not in requests
                requests.append(payload['id'])
        elif event['event'] == 'stdout_wire':
            wire = json.loads(event['text'])
            if wire.get('id') in requests:
                ident = wire['id']
                assert ident not in responses and 'error' not in wire
                result = wire['result']
                assert result.get('isError') is not True and isinstance(result.get('structuredContent'), dict)
                structured = result['structuredContent']
                responses[ident] = structured.get('result', structured)
    assert len(requests) == 2 and set(responses) == set(requests)
    assert [responses[ident] for ident in requests] == [before, after]
    assert boundaries[0]['finished_ns'] <= min(row['offered_ns'] for row in operations)
    assert max(row['finished_ns'] for row in operations) <= boundaries[1]['started_ns']
    return dict(
        original_validator_result=original,
        summary=report['db_lock_observation'],
        original_request_ids=requests,
        raw_boundary_response_sha256=[value_hash(value) for value in (before, after)],
        exact_original_wire_bodies=True,
        independent_integer_deltas=True,
        boundary_times=[{key: row[key] for key in ('phase', 'started_ns', 'finished_ns', 'owned_product_pid')}
                        for row in boundaries],
        observed_operation_denominator=len(operations),
        performance_scope='These counters and latency belong only to this instrumented feature execution; no default-build samples are pooled.',
        attribution_scope='Actual writer/read-pool acquisition call wall time is separate from checkout wall and observer-role counters. SQLite internal busy wait and interval maximum are unobserved.',
        formal_task_completion=False,
    )
