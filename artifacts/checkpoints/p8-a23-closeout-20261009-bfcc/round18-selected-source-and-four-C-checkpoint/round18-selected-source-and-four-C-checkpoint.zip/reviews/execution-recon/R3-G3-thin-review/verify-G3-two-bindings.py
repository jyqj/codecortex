#!/usr/bin/env python3
"""Static original binding comparison; no selected-v15 execution."""
import ast, hashlib, json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
GEN=Path('/dev/shm/todo-audit-G3-4ec7543d-binding/generated')
PREV=Path('/dev/shm/todo-audit-G2-cd68-binding/generated')
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
canonical_raw=(ROOT.parent/'final-R3/independent-source-review.json').read_bytes();canonical=json.loads(canonical_raw)
reg_path='scripts/reviewed-source-registry-v15.json';guard_path='scripts/verify_reviewed_source_v15.py'
oldreg=read(PREV/reg_path);raw=(GEN/reg_path).read_bytes();reg=json.loads(raw)
changed=sorted(k for k in set(oldreg)|set(reg) if oldreg.get(k)!=reg.get(k))
assert changed==['complete_inputs','delta','product_source','review_sha256','review_source']
assert reg['product_source']==canonical['source']=='aac83a8e57d87fa9fe95af16173c68f1dd4fb88e'
assert reg['review_source']=='4ec7543db94699077fe4075dd4b3606e92482460'
assert reg['review_sha256']==sha(canonical_raw)
assert reg['complete_inputs']==canonical['complete_inputs'] and reg['delta']==canonical['paths']
assert reg['validation_inputs']==canonical['validation_inputs']==oldreg['validation_inputs']
assert [len(reg[k]) for k in ('complete_inputs','delta','validation_inputs')]==[1095,70,142]
for field in ('complete_inputs','delta'):
    assert sorted(p for p in reg[field] if reg[field][p]!=oldreg[field][p])==['crates/cc-db/src/resolution_dependency_store.rs','crates/cc-db/tests/p2b_resolution_store.rs']
oldguard=(PREV/guard_path).read_bytes();guard=(GEN/guard_path).read_bytes()
pins={'PRODUCT':canonical['source'],'REVIEW':reg['review_source'],'REVIEW_PATH':'artifacts/checkpoints/p8-dependency-exclusion-bfcc-20261009/independent-source-review.json','REGISTRY_SHA256':sha(raw)}
expected=oldguard.decode()
for k,v in pins.items():
    expected,n=re.subn(r'^'+k+r' = "[^"]*"$',k+' = '+json.dumps(v),expected,flags=re.M);assert n==1
assert expected.encode()==guard
ast.parse(guard)
# Read only tree-reconstruction prefix; never run the old report writer.
mod=ast.parse((ROOT/'verify-installed-R3-and-prepare-G3.py').read_text());nodes=[]
for n in mod.body:
    if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='report' for t in n.targets):break
    nodes.append(n)
ns={'__file__':str(ROOT/'verify-installed-R3-and-prepare-G3.py')};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<exact retained R3 tree prefix>','exec'),ns)
leaves=ns['leaves'];before={p:dict(v) for p,v in leaves.items()};hash_leaves=ns['hash_leaves']
files=[]
for p in (reg_path,guard_path):
    b=(GEN/p).read_bytes();row={'mode':'100644','type':'blob','sha':blob(b),'size':len(b)};leaves[p]=row
    files.append({'path':p,'local_path':str(GEN/p),'bytes':len(b),'sha256':sha(b),'git_blob':blob(b),'mode':'100644'})
root=hash_leaves(leaves)[''];assert root=='e7a7f5a685c44aee34b8716377308f0af8782fdd'
assert all(leaves[p]==row for p,row in before.items() if p not in (reg_path,guard_path))
for p,row in canonical['actual_input_mode_blob_inventory'].items():assert all(leaves[p][k]==row[k] for k in ('mode','type','sha'))
report={'schema':'G3-independent-two-bindings-source-boundary-v1','reviewer':'/root/execution_recon','verdict':'accepted_scoped_original_bindings_only','actual_G3':None,'expected_G3_tree':root,'required_sole_parent':reg['review_source'],'actual_product':canonical['source'],'canonical_review_sha256':sha(canonical_raw),'actual_changed_registry_fields':changed,'guard_only_changed_pins':pins,'guard_algorithm_BASE_FROZEN_history_CI_bytes_unchanged':True,'all142_validation_inputs_exact':True,'all1095_product_input_modes_blobs_hashes_exact':True,'BASE_delta_count':70,'only_two_binding_leaves_changed':True,'all_R3_artifacts_and_other_leaves_retained':True,'files':files,'current_source_runtime':'not_run','draft_PR_boundary':'Suitable to publish as source-bound draft after actual G3 parent/tree readback. Original engineering controls remain pending; manual formatting is not fmt success. Preserve +22.57% SQL counterexample and original Gc8 failure; no TODO/scale or prior H-MS​​RV credit.','TODO_remaining':29}
with (ROOT/'G3-independent-two-bindings-review.pending-actual.json').open('x') as f:json.dump(report,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(report))
