#!/usr/bin/env python3
"""Read already captured metadata only; no API calls, workloads or polling."""
from pathlib import Path
import json
import hashlib

B=Path(__file__).resolve().parent
G='88d5f547bb0fae273f4270742503fd1fd5e70bc2'
M='fffd950d5b34b0180f308db1428a57d5bf358bf1'
def read(name): return json.loads((B/name).read_bytes())
runs=read('G6B-runs.original.json')['response']['workflow_runs']
checks=read('G6B-check-runs.original.json')['response']['check_runs']
assert len(runs)==7 and len(checks)==25
assert all(x['head_sha']==G and x['event']=='pull_request' and x['run_attempt']==1 and x['status']=='queued' and x['conclusion'] is None for x in runs)
assert all(x['head_sha']==G and x['status']=='queued' and x['conclusion'] is None for x in checks)
groups=[]; ids=[]
for run in runs:
    jobs=read(f'G6B-jobs-{run["id"]}.original.json')['response']['jobs']
    assert all(x['run_id']==run['id'] and x['status']=='queued' and x['conclusion'] is None for x in jobs)
    ids.extend(x['id'] for x in jobs)
    groups.append({'run_id':run['id'],'workflow':run['name'],'path':run['path'],'source':G,'attempt':1,'event':'pull_request','status':run['status'],'conclusion':run['conclusion'],
        'jobs':[{k:x[k] for k in ('id','name','status','conclusion')} for x in jobs]})
assert len(ids)==25 and len(set(ids))==25 and set(ids)=={x['id'] for x in checks}
pr=read('PR180.original.json')['response']; merge=read('merge-commit.original.json')
assert pr['head']['sha']==G and pr['draft'] is True and pr['state']=='open'
assert merge['sha']==pr['merge_commit_sha']==read('PR180-merge-ref.original.json')['response']['object']['sha']
assert merge['tree']['sha']=='e039a817291934b15cc018fd74d2c83982bb7f37'
assert [x['sha'] for x in merge['parents']]==[pr['base']['sha'],G]
selected=[113888549879,113888549822,113888549731,113888549652]
old_checks={x['id']:x for x in read('M7F-check-runs.original.json')['check_runs'] if x['id'] in selected}
assert len(old_checks)==4 and all(x['head_sha']==M for x in old_checks.values())
old_jobs={}
for run_id in (37950740732,37950740737):
    r=read(f'M7F-run-{run_id}.original.json')
    assert r['head_sha']==M and r['run_attempt']==1
    for job in read(f'M7F-jobs-{run_id}.original.json')['jobs']:
        if job['id'] not in selected:continue
        check=old_checks[job['id']]
        assert job['run_id']==run_id and f'/runs/{run_id}/job/{job["id"]}' in check['details_url']
        assert job['status']==check['status'] and job['conclusion']==check['conclusion']
        old_jobs[job['id']]={'job_id':job['id'],'name':job['name'],'source':M,'run_id':run_id,'run_attempt':1,
            'run_status':r['status'],'run_conclusion':r['conclusion'],'job_status':job['status'],'job_conclusion':job['conclusion'],
            'completed_at':check['completed_at'],'running_steps':[x for x in job['steps'] if x['status']=='in_progress']}
assert set(old_jobs)==set(selected)
result={'schema_version':1,'observer':'/root/pr_triage','observation_window_UTC':['2026-10-09T15:54:12Z','2026-10-09T15:55:11Z'],
    'scope':'One bounded initial discovery/identity/job read after normal FF; no polling loop, logs download, artifact download, mutation or workload.',
    'PR180':{'state':pr['state'],'draft':pr['draft'],'head':G,'base_ref':pr['base']['ref'],'base_sha':pr['base']['sha']},
    'test_merge':{'commit':merge['sha'],'tree':merge['tree']['sha'],'ordered_parents':[x['sha'] for x in merge['parents']],
        'complete_tree_equals_G6B':True,'actual_checkout_execution':'not yet evidenced; all25jobs queued. Test-merge metadata is not a claimed executed checkout.'},
    'G6B_runs':groups,'G6B_counts':{'runs':7,'check_runs':25,'actual_jobs':25,'queued_jobs':25,'in_progress_jobs':0,'completed_jobs':0},
    'previous_M7F_four_jobs':[old_jobs[x] for x in selected],
    'M7F_scope':'Two selected jobs succeeded on their own M7F source; mixed16 and soak remain in_progress. None of these four is cancelled at this read. Do not infer a cancellation mechanism or transfer their results to G6B.',
    'run_job_level_distinction':'M7F platform run37950740737 is aggregate queued while its specified cold job is completed success. Dedicated jobs metadata and check-runs agree.',
    'soak_job_binding':'Specified soak113888549652 belongs to runtime37950740732 according to both official check details_url and dedicated run_jobs. No data from suggested alternative37950740799 used.',
    'transport_scope':'Four initial generic actions/jobs/id reads were rejected as unsupported endpoint before any job record was returned; exact errors retained. Used supported run_jobs + check-runs without repeating any run.',
    'C3ff_scope':'No new C3ff observation, restart or study action; its original failure remains separate.',
    'execution_credit':False,'original_TODO_done':163,'original_TODO_remaining':29,'newly_completed_this_round':0}
target=B/'initial-G6B-CI-and-M7F-terminal-snapshot.json'
with target.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'report_bytes':target.stat().st_size,'report_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'new_G_queued':25,'old4_success':2,'old4_in_progress':2}))
