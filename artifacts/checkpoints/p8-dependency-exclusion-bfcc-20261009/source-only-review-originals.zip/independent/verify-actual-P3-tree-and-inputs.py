#!/usr/bin/env python3
"""Read-only Git/source identity review; no Rust, native runtime, or source CLI."""
import ast, copy, datetime, hashlib, json
from pathlib import Path, PurePosixPath
ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'final-R2'
PLAN=Path('/dev/shm/todo-audit-P3-H-d22-candidate-plan')
def read(p): return json.loads(p.read_text())
def sha(b): return hashlib.sha256(b).hexdigest()
def oid(k,b): return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def write(name,d):
    with (ROOT/name).open('x') as f: json.dump(d,f,ensure_ascii=False,indent=2,sort_keys=True);f.write('\n')
mod=ast.parse((ROOT.parent/'P2-source-review/reconstruct-independent-P2-review.py').read_text())
one=next(x for x in mod.body if isinstance(x,ast.FunctionDef) and x.name=='hash_leaves')
exec(compile(ast.Module(body=[one],type_ignores=[]),'<retained tree hashing helper>','exec'))
meta=json.loads(read(ROOT/'official-P3-commit.json')['response_content'])
assert meta['sha']=='9c1605118edcb7e88d211c3f6bd31249ebe36dc7'
parents=[p['sha'] for p in meta['parents']]
assert parents==['0e6b07c75183da79c5a6679d4c2b66c65f7db663','d22d36dddf8b38f1a864c933deefe0b6d3b5baf3']
old_raw=(PRIOR/'independent-source-review.json').read_bytes()
assert sha(old_raw)=='9ae179a92dbedf27c0b3a6ca56b1ed792cc6639e3bb0765d634ece4db2dd79cd'
assert oid('blob',old_raw)=='c8a6b80912dfa13c664ded8e88f21bbe4a200e73'
old=json.loads(old_raw)
tree=read(Path('/dev/shm/todo-audit-p8007-final-main-integration/actual-P2/actual-P2-complete-derived-Git-tree.json'))
entries={r['path']:r for r in tree['tree']}
assert not tree['truncated'] and len(entries)==len(tree['tree'])
leaves={p:dict(r) for p,r in entries.items() if r['type']!='tree'}
dirs={p:r['sha'] for p,r in entries.items() if r['type']=='tree'};dirs['']=old['tree']
roots={'P2':hash_leaves(leaves,dirs)['']}
for r in read(PRIOR/'upload-manifest.json')['files']:
    assert r['repository_path'] not in leaves
    leaves[r['repository_path']]={'mode':'100644','type':'blob','sha':r['git_blob'],'size':r['bytes']}
roots['R2']=hash_leaves(leaves)['']
assert roots['R2']=='90d4c0aec835c9b5fff9d809c433d353d409dcf8'
for path in ['scripts/reviewed-source-registry-v15.json','scripts/verify_reviewed_source_v15.py']:
    raw=(Path('/dev/shm/todo-audit-G2-cd68-binding/generated')/path).read_bytes()
    leaves[path]={'mode':'100644','type':'blob','sha':oid('blob',raw),'size':len(raw)}
roots['G2']=hash_leaves(leaves)['']
assert roots['G2']=='41a1708082eb49432e8e22aac2c0400f80337cfb'
for r in read(Path('/dev/shm/todo-audit-pr180-832f-forward/future-H-20-artifact-additions.json'))['tree']:
    assert r['path'] not in leaves
    leaves[r['path']]=dict(r)
roots['H']=hash_leaves(leaves)['']
assert roots['H']=='9755e717368ffb51bc084c3348c1715b00b34d0d'
h_leaves=copy.deepcopy(leaves)
spec=[('production','crates/cc-db/src/resolution_dependency_store.rs','b78b482bd210fe19fa8ee15cf70b9ff5d2a668ef'),('tests','crates/cc-db/tests/p2b_resolution_store.rs','b0eaba1afa8f73a4bb1f3c60cb55ac31c5da230a'),('docs','docs/BENCHMARK.md','cb85c58cdac336950612498c4ed638c99d7f689e')]
replacements={}
for label,path,expected in spec:
    raw=read(ROOT/f'official-{label}-blob.json')['response_content'].encode('utf-8')
    assert oid('blob',raw)==expected,(path,oid('blob',raw),expected)
    if label!='docs':
        assert raw==(Path('/dev/shm/todo-audit-H-dependency-exclusion-v2/candidate')/path).read_bytes()
        before=(Path('/dev/shm/todo-audit-H-dependency-exclusion/original')/path).read_bytes()
        assert oid('blob',before)==h_leaves[path]['sha'] and sha(before)==old['complete_inputs'][path]
    with (ROOT/f'actual-P3-{label}.raw').open('xb') as f:f.write(raw)
    replacements[path]={'before':{k:h_leaves[path].get(k) for k in ('mode','type','sha')},'after':{'mode':'100644','type':'blob','sha':expected,'size':len(raw),'sha256':sha(raw)}}
    leaves[path]=dict(replacements[path]['after'])
roots['P3']=hash_leaves(leaves)['']
assert roots['P3']==meta['tree']['sha']=='5ac4d3fb96cfb11433d529b8292d1e7652471036'
plan=read(PLAN/'prospective-P3-complete-product-validation-inputs.json')
product=copy.deepcopy(old['complete_inputs']);delta=copy.deepcopy(old['paths']);iv=copy.deepcopy(old['actual_input_mode_blob_inventory'])
changed=[p for _,p,_ in spec if p.startswith('crates/')]
for p in changed:
    product[p]=replacements[p]['after']['sha256'];delta[p]['sha256']=product[p];iv[p]=dict(replacements[p]['after'])
assert len(product)==1095 and len(delta)==70 and len(old['validation_inputs'])==142
assert product==plan['complete_inputs'] and delta==plan['paths'] and old['validation_inputs']==plan['validation_inputs']
expected_product={p for p in leaves if p.startswith('crates/') or p in ('Cargo.toml','Cargo.lock')}
excluded={'scripts/verify_reviewed_source_v15.py','scripts/reviewed-source-registry-v15.json','.github/workflows/ci.yml'}
def vp(p): return p.startswith(('scripts/','.github/workflows/','tests/source_integrity/')) and p not in excluded and not ('__pycache__' in Path(p).parts and p.endswith('.pyc'))
assert expected_product==set(product)
assert {p for p in leaves if vp(p)}==set(old['validation_inputs'])
assert set(product)|set(old['validation_inputs'])==set(iv)
for p,r in iv.items():
    assert all(r[k]==leaves[p][k] for k in ('mode','type','sha'))
    if p not in changed:assert r==old['actual_input_mode_blob_inventory'][p]
    assert r['sha256']==(product|old['validation_inputs'])[p]
assert all(set(r)=={'before_sha256','sha256'} and r['sha256']==product[p] for p,r in delta.items())
assert {p:r for p,r in delta.items() if p not in changed}=={p:r for p,r in old['paths'].items() if p not in changed}
assert all(leaves[p]==r for p,r in h_leaves.items() if p not in replacements)
ci=(PLAN/'original-ci.yml').read_bytes()
assert oid('blob',ci)==leaves['.github/workflows/ci.yml']['sha']
report={'schema':'actual-P3-independent-tree-input-review-v1','source':meta['sha'],'tree':meta['tree']['sha'],'source_parents':parents,'reviewer':'/root/execution_recon','root_reconstruction':roots,'source_count':len(product),'validation_count':len(old['validation_inputs']),'BASE_delta_count':len(delta),'complete_leaf_count':len(leaves),'actual_deltas_from_H':replacements,'retained_product_inputs':1093,'retained_BASE_delta_paths':68,'all_prior_H_leaves_except_three_preserved':True,'all_H_artifacts_preserved':True,'runtime_status':'not_run','no_holdout_body_read':True,'prior_R2_sha256':sha(old_raw),'method':'Independent official immutable commit/blob reads; full tree reconstructed from independently verified P2 leaves plus exact3R2/2G2/20H/3P3 leaf changes; all directories rehashed. Derived full tree is not an official recursive API response.'}
write('actual-P3-independent-tree-input-review.json',report)
write('actual-P3-independent-complete-inputs.json',{'source':meta['sha'],'tree':meta['tree']['sha'],'source_parents':parents,'base':old['base'],'complete_inputs':product,'validation_inputs':old['validation_inputs'],'paths':delta,'actual_input_mode_blob_inventory':iv})
print(json.dumps(report,ensure_ascii=False))
