from pathlib import Path
import json,sys
r=Path('/workspace/independent-comparison-review');direct={a:{v['query']:v for v in json.loads((r/f'{a}-probes.json').read_text())} for a in ['candidate','delivery']};out={'verdict':'REJECT','expected':'Separate code references do not constitute a standalone comparative phrase; retain candidate owner suppression. No semantic gold assigned.','failed_checks':[],'observations':[]}
for q in ['Which Beacon API calls `rather()` `than()` with Commit?','Which Beacon API calls $rather $than with Commit?']:
 x,y=direct['candidate'][q],direct['delivery'][q]
 assert x['target']==y['target']=='Ambiguous'
 assert x['flags'][0]['owner']==False
 if y['flags'][0]['owner']!=False:out['failed_checks'].append({'query':q,'expected_owner_class_permitted':False,'actual_owner_class_permitted':y['flags'][0]['owner'],'candidate_context':x['context'],'delivery_context':y['context']})
 for variant in ['base','receiver','inversion']:
  arms={a:json.loads((r/f'results/{a}-{variant}/results.json').read_text()) for a in ['base','candidate','delivery']}
  for api in ['engine','mcp']:
   hits={a:o['queries'][q][api]['raw']['machine_pack']['hits'] for a,o in arms.items()}
   out['observations'].append({'query':q,'variant':variant,'api':api,'top1':{a:v[0]['symbol_name'] for a,v in hits.items()},'owner':{a:next({'score':h['rerank_score'],'trace':h['score_trace'],'chunk_id':h['chunk_id']} for h in v if h['symbol_name']=='Beacon') for a,v in hits.items()}})
(r/'challenges.json').write_text(json.dumps(out,indent=2));print('FAIL' if out['failed_checks'] else 'PASS',len(out['failed_checks']),'code-reference boundary assertions;',len(out['observations']),'runtime observations');sys.exit(1 if out['failed_checks'] else 0)
