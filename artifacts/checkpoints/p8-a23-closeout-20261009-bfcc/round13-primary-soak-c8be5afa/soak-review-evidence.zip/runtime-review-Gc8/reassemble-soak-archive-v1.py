from pathlib import Path
import hashlib, json, sys

manifest = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2])
data = json.loads(manifest.read_text())
expected = data['original_new_container']
digest = hashlib.sha256()
total = 0
with output.open('xb') as destination:
    for ordinal, row in enumerate(data['parts']):
        assert row['ordinal'] == ordinal
        assert Path(row['path']).name == row['path']
        assert row['offset'] == total
        part = manifest.parent / row['path']
        payload = part.read_bytes()
        assert len(payload) == row['bytes']
        assert hashlib.sha256(payload).hexdigest() == row['sha256']
        destination.write(payload)
        digest.update(payload)
        total += len(payload)
assert total == expected['bytes']
assert digest.hexdigest() == expected['sha256']
print(json.dumps({'status': 'exact_container_reassembled', 'bytes': total, 'sha256': digest.hexdigest(), 'output': str(output), 'scope': 'New reversible evidence container, not the original GitHub ZIP or a workload execution.'}))
