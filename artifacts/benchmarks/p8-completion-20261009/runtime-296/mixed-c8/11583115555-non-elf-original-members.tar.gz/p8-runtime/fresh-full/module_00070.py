def stable_00070():
    return 70
