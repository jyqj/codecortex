import datetime,hashlib,json,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def identity(p,b):return {'local_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
r=json.loads((HERE/'independent-new-nine-review.json').read_text())
mfile=ROOT/'round43-next9-original-intake/sealed/upload-manifest.actual.json'
m=json.loads(mfile.read_text());assert m['source']==r['source'] and m['run_id']==r['run_id'] and m['attempt']==1 and all(f['actual_created'] and f['server_sha']==f['git_blob'] for f in m['files'])
# Append actual publication bindings without repeating the already-completed peer reader.
r['receiver_immutable_evidence']=m
r['publication_addendum']={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'change':'Actual receiver publication became available after the peer read. Initial pending field is preserved in the original short/detailed reader output; this final report adds server-confirmed immutable locators only.','new_validator_calls':0,'new_raw_reads':0}
dump(HERE/'independent-new-nine-review.final.json',r)
files=[HERE/n for n in ['read-new-nine.py','reader-adaptation.diff','pending-review.json','reader.stdout','reader.stderr','reader-execution.json',
 'independent-new-nine-review.json','independent-new-nine-review.final.json','detailed-original-nine-review.json','selected-new-original-parity-and-stage-events.json','seal-peer.py']]
files+=sorted((HERE/'reader-attempt01').iterdir())
files += [ROOT/'round43-next9-original-intake'/n for n in ['terminal.json','stdio-preseal-custody-check.json','host-wrapper-adaptation.diff','sealed/upload-manifest.actual.json']]
officialpath=ROOT/'round43-new45-study/0544-new45-jobs-and-full-artifacts.original.json'
ob=officialpath.read_bytes();o=json.loads(ob)
jobs_projection={'source_original':identity(officialpath,ob),'started':o['started'],'ended':o['ended'],'projection':'Only the complete jobs_original response retained here; parent file and artifact pages retained by root.','jobs_original':o['jobs_original']}
dump(HERE/'complete-producer-jobs-original-projection.json',jobs_projection);files.append(HERE/'complete-producer-jobs-original-projection.json')
members=[];zp=HERE/'complete-new-nine-independent-support.zip'
with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:
  b=p.read_bytes();name=str(p.relative_to(ROOT));members.append(identity(p,b)|{'archive_path':name});z.writestr(name,b)
 manifest={'schema':'selected-new-nine-original-peer-support-v1','files':members,'receiver_support':'f20c32f380a2b12405b0fd28fdf85221d43ff3d0',
  'original_whole_ZIPs_and_ELF_not_nested':True,'old18_originals_not_reopened':True,'peer_validator_or_ELF_calls':0}
 mb=(json.dumps(manifest,indent=2)+'\n').encode();z.writestr('MANIFEST.json',mb)
dump(HERE/'archive-selection.json',manifest|{'support':identity(zp,zp.read_bytes()),'support_members':len(members)+1,'manifest_member_bytes':len(mb),'manifest_member_sha256':hashlib.sha256(mb).hexdigest()})
pre='artifacts/checkpoints/p8-round43-complete-bfcc-20261010/new45/next9-peer/'
u={'files':[identity(p,p.read_bytes())|{'repository_path':pre+p.name} for p in [HERE/'independent-new-nine-review.final.json',zp,HERE/'archive-selection.json']]}
dump(HERE/'upload-manifest.pending.json',u);print(json.dumps(u))
