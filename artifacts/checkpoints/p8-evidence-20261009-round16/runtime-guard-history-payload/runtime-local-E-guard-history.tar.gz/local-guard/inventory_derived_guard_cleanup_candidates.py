"""Read only two ended guard contexts and prove exact immutable regeneration."""
import hashlib,json,os,pathlib,stat,subprocess,sys
BASE=pathlib.Path(__file__).parent
OUT=BASE/'guard-derived-cleanup-candidates'
OUT.mkdir(exist_ok=False)
VIEW=pathlib.Path('/dev/shm/a217aaae3bde/codecortex-combined-guard-view')
ROOT=pathlib.Path('/dev/shm/a217aaae3bde/codecortex')
sys.dont_write_bytecode=True;sys.path.insert(0,str(VIEW/'scripts'))
import v14_historical_context as h14
import v15_historical_context as h15

def sha(raw):return hashlib.sha256(raw).hexdigest()
def oid(raw):return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def hashfile(p):
    h=hashlib.sha256()
    with p.open('rb') as s:
        for b in iter(lambda:s.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=VIEW)
def save(name,o):
    p=OUT/name;p.write_text(json.dumps(o,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashfile(p))

reports=[]
for name,module,expected_count in [('codecortex-v13-history-15ac44yu',h14,290),('codecortex-v14-history-rcfg4y2l',h15,302)]:
    path=pathlib.Path('/workspace/scratch/a217aaae3bde/combined-original-guard-temp')/name
    assert path.is_dir() and not path.is_symlink()
    blobs,protected=module.catalogue();assert len(blobs)==expected_count
    files={p.relative_to(path).as_posix():p for p in path.rglob('*') if not p.is_dir() or p.is_symlink()}
    assert set(files)==set(blobs),{'extra':sorted(set(files)-set(blobs)),'missing':sorted(set(blobs)-set(files))}
    expected_dirs={'.'}
    for p in files:
        for parent in pathlib.PurePosixPath(p).parents:expected_dirs.add(str(parent))
    actual_dirs={'.'}|{p.relative_to(path).as_posix() for p in path.rglob('*') if p.is_dir() and not p.is_symlink()}
    assert actual_dirs==expected_dirs
    trees={}
    for row in git('ls-tree','-r','-z',module.HISTORICAL_HEAD).split(b'\0'):
        if row:
            md,p=row.decode().split('\t',1);mode,kind,blob=md.split();trees[p]=(mode,kind,blob)
    rows=[]
    for relative,p in sorted(files.items()):
        st=p.lstat();assert stat.S_ISREG(st.st_mode) and stat.S_IMODE(st.st_mode)==0o444
        raw=blobs[relative];digest=sha(raw);assert st.st_size==len(raw) and hashfile(p)==digest
        mode,kind,blob=trees[relative];assert kind=='blob' and mode in ['100644','100755'] and oid(raw)==blob
        copies=[]
        for baseline in [VIEW,ROOT,pathlib.Path('/dev/shm/a217aaae3bde/prospective-combined-tree-prep/checkout')]:
            q=baseline/relative
            if q.is_file() and not q.is_symlink() and q.stat().st_size==st.st_size and hashfile(q)==digest:
                copies.append(str(q))
        rows.append(dict(path=relative,bytes=st.st_size,sha256=digest,materialized_mode=oct(stat.S_IMODE(st.st_mode)),git_mode=mode,git_blob=blob,original_commit=module.HISTORICAL_HEAD,device=st.st_dev,inode=st.st_ino,hardlink_count=st.st_nlink,allocated_bytes=st.st_blocks*512,mtime_ns=st.st_mtime_ns,ctime_ns=st.st_ctime_ns,unchanged_baseline_copies=copies))
    # Re-read names and every digest after the complete initial scan.
    assert {p.relative_to(path).as_posix() for p in path.rglob('*') if p.is_file()}==set(files)
    assert all(hashfile(path/r['path'])==r['sha256'] and (path/r['path']).stat().st_size==r['bytes'] for r in rows)
    catalogue_manifest={p:sha(raw) for p,raw in sorted(blobs.items())}
    catalogue_ref=save(name+'-original-catalogue.json',dict(original_commit=module.HISTORICAL_HEAD,original_context_module=str(pathlib.Path(module.__file__)),original_context_module_sha256=hashfile(pathlib.Path(module.__file__)),files=catalogue_manifest,protected_files=sorted(protected)))
    file_ref=save(name+'-files.json',rows)
    reports.append(dict(path=str(path),file_count=len(rows),directory_count=len(actual_dirs),logical_bytes=sum(r['bytes'] for r in rows),file_allocated_bytes=sum(r['allocated_bytes'] for r in rows),all_current_modes='0444',all_regular=True,symlinks=0,unique_non_git_files=0,extra_empty_directories=0,original_git_commit=module.HISTORICAL_HEAD,original_catalogue=catalogue_ref,file_inventory=file_ref,all_catalogue_bytes_and_git_blobs_equal=True,all_final_names_and_digests_rechecked=True,baseline_copy_count=sum(bool(r['unchanged_baseline_copies']) for r in rows),all_original_git_objects_retained=True,original_git_source_view=str(VIEW),possible_file_allocated_release_bytes=sum(r['allocated_bytes'] for r in rows if r['hardlink_count']==1)))

receipt=dict(schema_version=1,status='exact_two_owned_derived_directories_eligible_for_parent_authorized_cleanup',candidates=reports,total_logical_bytes=sum(r['logical_bytes'] for r in reports),total_possible_file_allocated_release_bytes=sum(r['possible_file_allocated_release_bytes'] for r in reports),unique_logs_or_generated_records=0,original_guard_output_and_trace_retained=str(BASE/'guard-execution-a23bb72-v3'),no_active_writer_basis={'scope':'known_workspace_owners_confirmed_idle; not a system-wide PID assertion','runtime_owner':'Original guard subprocess and outer exec session31043 ended. The separate synthetic helper session16227 also ended and never used these contexts. This inventory reads only.', 'root_owner':'Parent requested bounded cleanup candidate for ended guard and will perform deletion; no other owned writer reported.','pr_audit':'Explicitly confirmed no current/future writer, read stream, or exec dependency on these two directories.','scale_closeout':'Explicitly confirmed no current/future writer or read stream; source/driver snapshots ended and use frozen E view only.','system_wide_process_scan':'Not claimed; prior environment does not permit proving unrelated system process state.'},preserve=['Every original ZIP and metadata','All native measurements and raw record bundles','Every original Git object and fixed historical commit','Shared frozen E source/validation view','All original guard stdout/stderr/trace/snapshots and outer-failure addendum'],mutation_performed=False,deletion_performed=False,required_parent_action='Immediately before deleting only these exact two directories, recheck file inventory and digest against these records; preserve originals and all review receipts. Do not treat filesystem reappearance as new acceptance or delete other paths.',formal_task_completion=False,done=163,remaining=29)
print(json.dumps(save('cleanup-candidate-receipt.json',receipt),indent=2));print(json.dumps({'logical_bytes':receipt['total_logical_bytes'],'allocated_release_bytes':receipt['total_possible_file_allocated_release_bytes']},indent=2))
