#!/usr/bin/env python3
"""Read-only review of retained 173 recovery artifacts; never runs products."""
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
from datetime import datetime, timezone

sys.dont_write_bytecode = True
BASE = Path("/workspace/scratch/a217aaae3bde/original-173-runtime")
ROOT = BASE / "artifacts/11597639035/extracted/p8-full-recovery"
SOURCE = Path("/workspace/scratch/a217aaae3bde/scale-original-275e")
OUT = Path("/workspace/scratch/a217aaae3bde/original-173-runtime/reviews/recovery-11597639035-275e8799-independent")
HEAD = "275e8799d4947d297329073eaa3ca675d3fd0777"
PREVIOUS = "277f2490fad3fa30f2812b5547bad033867c9ea5"

def check(ok, message):
    if not ok:
        raise AssertionError(message)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def read(relative):
    return json.loads((ROOT / relative).read_text())

def inventory():
    result = {}
    for path in sorted(ROOT.rglob("*")):
        check(not path.is_symlink(), "symlink artifact")
        if path.is_file() and path.name != "full-recovery.json":
            result[path.relative_to(ROOT).as_posix()] = sha(path)
    return result

def git(*args, data=None):
    return subprocess.check_output(["git", *args], cwd=SOURCE, input=data)

def committed_inputs(commit):
    blobs = {}
    for item in git("ls-tree", "-r", "-z", commit, "--", "crates", "Cargo.toml", "Cargo.lock").split(b"\0"):
        if not item:
            continue
        meta, name = item.split(b"\t", 1)
        mode, kind, oid = meta.decode().split()
        check(kind == "blob" and mode in ("100644", "100755"), "nonregular committed source")
        blobs[name.decode()] = oid
    ids = list(dict.fromkeys(blobs.values()))
    raw = git("cat-file", "--batch", data=("\n".join(ids) + "\n").encode())
    offset, hashes = 0, {}
    for expected in ids:
        end = raw.index(b"\n", offset)
        oid, kind, size = raw[offset:end].decode().split()
        check(oid == expected and kind == "blob", "unexpected git blob")
        size, offset = int(size), end + 1
        hashes[oid] = hashlib.sha256(raw[offset:offset+size]).hexdigest()
        offset += size
        check(raw[offset:offset+1] == b"\n", "truncated git blob")
        offset += 1
    check(offset == len(raw), "trailing git blob bytes")
    return {name: hashes[oid] for name, oid in sorted(blobs.items())}

def command_record(folder, record):
    check(read(folder + "/command.json") == record, folder + " command record differs")
    check(record["status"] == "passed" and record["exit_code"] == 0, folder + " did not pass")
    for filename, digest in record["logs_sha256"].items():
        check(sha(ROOT / folder / filename) == digest, folder + " log hash differs")

def source_files(project):
    result = {}
    for path in sorted(project.rglob("*")):
        name = path.relative_to(project).as_posix()
        if name == ".codecortex.json" or name == ".codecortex" or name.startswith(".codecortex/"):
            continue
        check(not path.is_symlink(), "authored source symlink")
        if path.is_file():
            result[name] = sha(path)
    return result

def db_snapshot(path):
    # immutable read-only connection avoids creating/altering any retained sidecar.
    before = sha(path)
    connection = sqlite3.connect(path.as_uri() + "?mode=ro&immutable=1", uri=True)
    try:
        result = {
            "schema_version": connection.execute("PRAGMA user_version").fetchone()[0],
            "integrity": connection.execute("PRAGMA integrity_check").fetchone()[0],
            "foreign_key_errors": len(connection.execute("PRAGMA foreign_key_check").fetchall()),
            "indexed_files": connection.execute("SELECT COUNT(*) FROM files").fetchone()[0],
        }
    finally:
        connection.close()
    check(sha(path) == before, "readonly database bytes changed")
    check(result["integrity"] == "ok" and result["foreign_key_errors"] == 0 and result["indexed_files"] > 0,
          "invalid retained database")
    return dict(path=str(path.relative_to(ROOT)), sha256=before, **result)

def contains(value, target):
    if value == target:
        return True
    if isinstance(value, dict):
        return any(contains(item, target) for item in value.values())
    if isinstance(value, list):
        return any(contains(item, target) for item in value)
    return False

full = read("full-recovery.json")
check(full["source"]["source_commit"] == HEAD, "wrong execution source")
check(full["status"] == "passed_declared_fault_matrix", "full matrix failed")
sys.path.insert(0, str(SOURCE / "scripts"))
import p8_cold_build as cold
check(full["schema_version"] == 2 and full["observer_binding"] == "required_git_and_loaded_source", "full formal observer wrapper missing")
check(full["observer_before"] == full["observer_after"], "observer drift")
fixed_observer_snapshot = cold.observer_snapshot(SOURCE, "full")
recorded = full["observer_before"]
check(dict(recorded, source_root=str(SOURCE)) == fixed_observer_snapshot, "full original observer differs from fixed Git/loaded source")
cold.verify_observer_archive(ROOT, recorded)
check(len(fixed_observer_snapshot["inputs"]) == 7 and recorded["source_commit"] == HEAD, "full observer count/commit differs")

initial_inventory = inventory()
check(initial_inventory == full["evidence_files_sha256"], "full artifact manifest mismatch")
for name, digest in full["runner_files_sha256"].items():
    check(sha(ROOT / "runner-source" / name) == digest == sha(SOURCE / "scripts" / name),
          "retained runner differs from fixed source: " + name)

inputs = {commit: committed_inputs(commit) for commit in (HEAD, PREVIOUS)}
check(full["source"]["inputs"] == inputs[HEAD], "full source inventory differs from exact git commit")
products = {}
for label, package, commit in (("default", "default", HEAD), ("semantic", "semantic", HEAD),
                               ("semantic-http", "semantic-http", HEAD), ("previous", "default", PREVIOUS)):
    prefix = "product-" + label
    record = read(prefix + "/build-receipt.json")
    before = record["source_before"]
    check(record["status"] == "passed" and record["build_exit_code"] == 0 and record["stop_reason"] is None,
          "product build did not pass")
    check(before == record["source_after"] and before["source_commit"] == commit, "product source drift")
    check(before["source_tree"] == git("rev-parse", commit + "^{tree}").decode().strip(), "source tree mismatch")
    manifest = read(prefix + "/source-inputs.json")
    check(manifest == inputs[commit] and len(manifest) == before["input_count"], "product source inputs mismatch")
    check(sha(ROOT / prefix / "source-inputs.json") == before["manifest_sha256"], "product manifest digest mismatch")
    command_record(prefix + "/build", record["build_observation"])
    check(record["build_command"] == record["build_observation"]["command"], "build argv differs")
    check("--locked" in record["build_command"] and "--offline" in record["build_command"]
          and "--no-default-features" in record["build_command"], "unexpected build flags")
    cargo = [json.loads(line) for line in (ROOT / prefix / "build/stdout.log").read_text().splitlines() if line]
    artifact = record["cargo_artifact"]
    check(sum(item == artifact for item in cargo) == 1, "original Cargo artifact absent/duplicated")
    check(any(item.get("reason") == "build-finished" and item.get("success") is True for item in cargo),
          "Cargo completion missing")
    expected_features = {"default": [], "semantic": ["semantic"], "semantic-http": ["semantic", "semantic-http"]}[package]
    check(artifact["target"]["name"] == "codecortex" and artifact["target"]["kind"] == ["bin"]
          and sorted(artifact["features"]) == expected_features, "product target/features mismatch")
    source_root = before["source_root"]
    check(artifact["manifest_path"] == source_root + "/crates/cc-server/Cargo.toml"
          and artifact["target"]["src_path"] == source_root + "/crates/cc-server/src/main.rs",
          "Cargo product came from wrong source root")
    check("/p8-full-recovery/cargo-target/" in artifact["executable"], "product target ownership missing")
    check(sha(ROOT / prefix / "codecortex") == record["binary_sha256"], "product executable digest differs")
    check(record["copy_source"] == {"path": artifact["executable"], "bytes": (ROOT / prefix / "codecortex").stat().st_size, "sha256": record["binary_sha256"]}, "original/copy producer binding differs")
    check(record["binary_bytes"] == (ROOT / prefix / "codecortex").stat().st_size and artifact["executable"] == record["target_directory"] + "/debug/codecortex", "producer target/size differs")
    check(artifact["profile"]["test"] is False and artifact["profile"]["opt_level"] == "0" and artifact["profile"]["debug_assertions"] is True, "actual dev profile differs")

    schema_bytes = git("show", commit + ":crates/cc-db/src/index_migrate.rs")
    check(hashlib.sha256(schema_bytes).hexdigest() == manifest["crates/cc-db/src/index_migrate.rs"],
          "schema source not bound to build")
    schema = int(re.search(rb"^pub const CURRENT_SCHEMA_VERSION: u32 = ([0-9]+);$", schema_bytes, re.M)[1])
    products[label] = dict(commit=commit, binary_sha256=record["binary_sha256"], schema=schema,
                           source_manifest_sha256=before["manifest_sha256"], input_count=len(manifest),
                           build_profile=record["build_profile"])

tests = []
for number, record in enumerate(full["executions"]):
    prefix = f"fault-test-{number:02}"
    check(read(prefix + "/test-receipt.json") == record, "fault test receipt mismatch")
    check(record["status"] == "passed" and record["source"] == full["source"], "test source/status mismatch")
    check(sha(ROOT / prefix / "fault-test") == record["executable_sha256"], "fault executable digest mismatch")
    command_record(prefix + "/build", record["build"])
    command_record(prefix + "/execution", record["execution"])
    argv = record["execution"]["command"]
    check(argv[1:] == ["--exact", record["test_name"], "--nocapture", "--test-threads=1"],
          "wrong exact-test command")
    stdout = (ROOT / prefix / "execution/stdout.log").read_text()
    check(f"test {record['test_name']} ... ok" in stdout and
          re.search(r"test result: ok\. 1 passed; 0 failed; 0 ignored;", stdout), "empty/skipped/failed test")
    cargo = [json.loads(line) for line in (ROOT / prefix / "build/stdout.log").read_text().splitlines() if line]
    artifact = record["cargo_artifact"]
    check(sum(row == artifact for row in cargo) == 1 and
          any(row.get("reason") == "build-finished" and row.get("success") is True for row in cargo),
          "test artifact/completion absent")
    check(artifact["manifest_path"] == "/home/runner/work/codecortex/codecortex/crates/" + record["package"] + "/Cargo.toml",
          "test package source differs")
    check(artifact["profile"]["test"] is True and "/p8-full-recovery/cargo-target/" in artifact["executable"],
          "test executable/target mismatch")
    tests.append(dict(case=prefix, name=record["test_name"], package=record["package"], target=record["target"],
                      executable_sha256=record["executable_sha256"], command=argv, exit_code=0,
                      stdout=stdout.strip()))
check(len(tests) == 7, "missing original tests")

pair = read("actual-version-pair/version-pair.json")
check(pair == full["actual_source_version_pair"], "version pair summary differs from original")
check(pair["status"] == "passed_actual_source_version_pair" and pair["schema_fault_injection"] is False,
      "not an actual version pair")
check(pair["production_schema_versions"] == {"current": 25, "previous": 24}, "unexpected production schemas")
check(products["default"]["schema"] == 25 and products["previous"]["schema"] == 24, "source versions differ")
for label, product_label in (("current", "default"), ("previous", "previous")):
    identity = pair["products"][label]
    expected = products[product_label]
    check(identity["source"]["source_commit"] == expected["commit"] and
          identity["binary_sha256"] == expected["binary_sha256"], "version product binding mismatch")
    for filename in ("codecortex", "build-receipt.json", "source-inputs.json"):
        check(sha(ROOT / "actual-version-pair" / (label + "-product") / filename)
              == sha(ROOT / ("product-" + product_label) / filename), "version witness copy mismatch")

pair_root = ROOT / "actual-version-pair"
check(pair["source_unchanged"] is True and source_files(pair_root / "fixture") == pair["source_files"]
      == read("actual-version-pair/source-before.json"), "source changed during version rollback")
check(sha(pair_root / "fixture/.codecortex.json") == sha(pair_root / "backups/config-original.json")
      == pair["configuration_sha256"], "configuration changed during version rollback")
check([c["status"] for c in pair["cases"]] == ["passed"] * 3, "version pair case failure")

databases = []
for field, filename, version in (("current_database_backup", "current-original.sqlite3", 25),
                                 ("previous_database_backup", "previous-rebuilt.sqlite3", 24),
                                 ("current_rebuilt_backup", "current-rebuilt.sqlite3", 25)):
    observed = db_snapshot(pair_root / "backups" / filename)
    check(observed["sha256"] == pair[field]["sha256"] and observed["schema_version"] == version,
          "backup hash/schema differs")
    for key in ("schema_version", "integrity", "foreign_key_errors", "indexed_files"):
        check(observed[key] == pair[field]["snapshot"][key], "backup snapshot differs")
    databases.append(observed)
databases.append(db_snapshot(pair_root / "fixture/.codecortex/index.sqlite3"))
check(databases[-1]["schema_version"] == 25, "restored database is not current schema")

stage_records = [pair["cases"][0]["before"], pair["cases"][0]["after"],
                 pair["cases"][1]["result"], pair["cases"][2]["result"]]
stages = []
for label, expected_version, product_label, result in zip(
        ("01-current-build", "02-previous-opens-current", "03-current-restored", "04-original-backup-restored"),
        (25, 24, 25, 25), ("default", "previous", "default", "default"), stage_records):
    directory = pair_root / label
    process = json.loads((directory / "process.json").read_text())
    check(process["binary_sha256"] == products[product_label]["binary_sha256"] and
          process["exit_code"] == process["expected_exit_code"] == 0 and
          process["cleanup"] == "completed" and process["initialized"] is True and process["tool_count"] == 14,
          "version stage process failure")
    raw = [json.loads(line) for line in (directory / "rpc.jsonl").read_text().splitlines()]
    requests = [row["payload"] for row in raw if row["event"] == "request"]
    responses = [row["payload"] for row in raw if row["event"] == "response"]
    check(len(requests) == len(responses) == 5 and
          sorted(x["id"] for x in requests) == sorted(x["id"] for x in responses) == list(range(1, 6)),
          "version stage RPC coverage differs")
    wire = []
    for event in raw:
        if event["event"] == "stdout_wire":
            data = event["text"].encode()
            check(event["wire_bytes"] == len(data) and event["wire_sha256"] == hashlib.sha256(data).hexdigest(),
                  "wire bytes/hash mismatch")
            wire.append(json.loads(event["text"]))
    check(sorted(wire, key=lambda x:x["id"]) == sorted(responses, key=lambda x:x["id"]), "raw wire/replies differ")
    replies = {x["id"]: x["result"] for x in responses}
    values = {}
    for request in requests:
        if request["method"] == "tools/call":
            response = replies[request["id"]]
            check(response.get("isError") is not True, "tool returned error")
            value = response["structuredContent"]
            name = request["params"]["name"]
            values["capabilities" if name == "status" else name] = value.get("result", value)
    local = json.loads((directory / "local.json").read_text())
    check(values == {k:local[k] for k in ("index", "capabilities", "search")}, "derived local report/raw differs")
    check(result["local"] == local and result["database"]["schema_version"] == expected_version,
          "version stage nested report differs")
    check(values["index"]["parse_errors"] == [] and
          values["capabilities"]["retrieval"]["semantic_state"] == "not_configured" and
          values["capabilities"]["retrieval"]["dense_state"] == "disabled", "local fallback invalid")
    hits = [hit for hit in values["search"] if hit.get("name") == "p8_rollback_source_marker"]
    check(hits and all(h["file_path"] == "src/lib.rs" and h["start_line"] == h["end_line"] == 1 for h in hits),
          "source span mismatch")
    source_text = (pair_root / "fixture/src/lib.rs").read_text()
    check("fn p8_rollback_source_marker(" in source_text and
          local["public_source"]["source_sha256"] == sha(pair_root / "fixture/src/lib.rs"), "invalid public source")
    stderr = (directory / "product-stderr.log").read_text()
    count = stderr.count("index schema version mismatch, rebuild required")
    check(count == result["schema_mismatch_diagnostics"] and
          sha(directory / "product-stderr.log") == result["stderr_sha256"], "schema diagnostic mismatch")
    if label in ("02-previous-opens-current", "03-current-restored"):
        check(count > 0, "no observed schema mismatch before rebuild")
    stages.append(dict(stage=label, schema=expected_version, binary_sha256=process["binary_sha256"],
                       source_commit=products[product_label]["commit"], schema_mismatch_diagnostics=count,
                       requests=5, raw_wire_verified=True, cleanup="completed", exit_code=0))

rollback = read("rollback/rollback.json")
missing_case = next(case for case in rollback["cases"] if case["id"] == "active_cache_reader_rejects_unknown_format")
check(missing_case["status"] == "not_run", "limited rollback record was changed")
check(rollback == full["rollback"] and rollback["status"] == "passed_limited_local_drill", "limited rollback mismatch")
integrity = next(case for case in rollback["cases"] if case["id"] == "source_and_config_integrity")
check(source_files(ROOT / "rollback/fixture") == integrity["source_manifest"]
      == read("rollback/source-before.json") == read("rollback/source-after.json"), "limited drill changed authored source")
check(sha(ROOT / "rollback/fixture/.codecortex.json") == sha(ROOT / "rollback/backups/config-before.json")
      == integrity["config_sha256"], "limited drill configuration drift")
for number, name in ((4, "meta_tampering_is_detected_as_corrupt"),
                     (5, "different_spaces_never_cross_hit"), (6, "namespaces_are_isolated")):
    check(tests[number]["name"] == name and tests[number]["target"] == "artifact_cache", "missing mapped cache test")

active = []
for seed in (223, 227, 229):
    directory = ROOT / f"active-stdio-{seed}"
    report = json.loads((directory / "active-faults.json").read_text())
    check(report in full["active_stdio"] and report["status"] == "passed", "active seed report mismatch")
    check(report["binary_sha256"] == report["binary_sha256_after"] == products["semantic-http"]["binary_sha256"],
          "active product hash mismatch")
    cases = {case["id"]:case for case in report["cases"]}
    case = cases["active_cache_reader_rejects_unknown_format"]
    check(case["status"] == "passed" and case["injected_format"] == 999, "unknown format was not exercised")
    check(case["original_metadata_sha256"] == sha(directory / "original-vector.meta.json"), "metadata backup changed")
    original_meta = json.loads((directory / "original-vector.meta.json").read_text())
    check(original_meta["format_version"] != 999, "original format was not restored from distinct bytes")
    check(case["rejected_lane"]["status"] == "partial" and
          case["rejected_lane"]["coverage"]["complete"] is False and
          case["rejected_lane"]["truncation_reason"] == "semantic_artifact_unavailable" and
          case["restored_lane"]["status"] == "complete" and
          case["restored_lane"]["coverage"]["complete"] is True, "active format rejection/restoration failed")
    events = [json.loads(line) for line in (directory / "events.jsonl").read_text().splitlines()]
    responses = [event["response"] for event in events if event["kind"] == "mcp_response"]
    check(any(contains(response, case["rejected_lane"]) for response in responses)
          and any(contains(response, case["restored_lane"]) for response in responses),
          "active format lane did not originate in retained MCP responses")
    check(all(case["status"] == "passed" for case in report["cases"]), "other active fault failed")
    active.append(dict(seed=seed, injected_format=999, original_format=original_meta["format_version"],
                       rejection_status="partial", rejection_reason="semantic_artifact_unavailable",
                       restored_status="complete", raw_response_match=True,
                       binary_sha256=report["binary_sha256"],
                       observed_provider_requests=report["observed_provider_requests"], paid_cost=report["paid_cost"]))

check(inventory() == initial_inventory, "read-only review changed original artifacts")
report = {
    "schema_version":1, "reviewer":"runtime_closeout",
    "assessment":"accepted_scoped_execution_evidence",
    "created_at_utc":datetime.now(timezone.utc).isoformat(),
    "execution_source_commit":HEAD, "previous_source_commit":PREVIOUS,
    "artifact_id":11597639035, "artifact_root":str(ROOT),
    "scope":["P8-016 actual public-source schema version rollback",
             "P8-016 active cache-format, vector-space and namespace isolation",
             "original seven production fault-test source/build/executable/result bindings"],
    "integrity":{"full_manifest_files":len(initial_inventory),"manifest_exact_match":True,
                 "all_original_files_unchanged_after_review":True,
                 "full_recovery_json_sha256":sha(ROOT/"full-recovery.json"),
                 "source_inputs_rehashed_against_git":{key:len(value) for key,value in inputs.items()}},
    "observer_v2":{"schema_version":2,"inputs":fixed_observer_snapshot["inputs"],"source_commit":HEAD,"before_after_equal":True,"loaded_and_committed_bytes_match":True,"archive_verified":True},
    "products":products, "version_stages":stages, "retained_database_snapshots":databases,
    "source_and_configuration_unchanged":True,
    "cache_scope_resolution":{
        "original_limited_drill_status":"not_run",
        "original_record_preserved":True,
        "format_gate":{"case":"fault-test-04","test":"meta_tampering_is_detected_as_corrupt",
                       "source":"crates/cc-semantic/tests/artifact_cache.rs:250",
                       "specific_assertion":"format_version=99; CacheRead::Corrupt reason contains format_version",
                       "result":"1 passed; 0 failed; 0 ignored"},
        "space_isolation":{"case":"fault-test-05","test":"different_spaces_never_cross_hit"},
        "namespace_isolation":{"case":"fault-test-06","test":"namespaces_are_isolated"},
        "enabled_product_format_gates":active,
        "conclusion":"Limited rollback's missing active-reader subcase is explicitly covered by the actual original cache tests and three enabled-product stdio seeds at the same source; no evidence gap in this scoped cache gate."
    },
    "original_fault_tests":tests,
    "unresolved_blockers_in_reviewed_scope":[],
    "limits":["No product rebuild, new fault execution, or writable database operation was performed during this review.",
              "Actual builds used dev profile as declared; this is recovery/correctness evidence, not cold release performance evidence.",
              "Two public source revisions are not relabelled as released package versions; paid-provider, arbitrary power-loss and physical-device claims remain excluded.",
              "This review certifies only the named original 173 execution scope, not later heads.",
              "P8-016 and related tasks retain their original hard dependencies; this file closes zero tasks and does not change the remaining total of 29."],
    "task_completion_certified":False
}
OUT.mkdir(parents=True, exist_ok=True)
(OUT/"recovery-173-review.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"assessment":report["assessment"],"path":str(OUT/"recovery-173-review.json"),
                  "manifest_files":len(initial_inventory),"source_counts":report["integrity"]["source_inputs_rehashed_against_git"],
                  "stages":[s["schema"] for s in stages],"tests":len(tests),
                  "active_cache_seeds":len(active),"unresolved_blockers":[]},ensure_ascii=False))
