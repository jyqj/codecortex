import hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent
def digest(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(name,data):
 p=P/name;p.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n');return digest(p)
a=json.loads((P/'55aa-full-union-audit.json').read_text())
old=json.loads((P/'complete-tree-composition-audit.json').read_text())
manifest=json.loads(Path('/dev/shm/todo-audit-pr180-public-dependency-fix-v2/source-manifest.json').read_text())
checks={}
for head in ['4652cad11dde4b41126544a38fddf25eb2fb7474','4866ec5558f1cedd34c7dc54231af65b77f706ec']:
 x=json.loads((P/f'checks-{head}.json').read_text());checks[head]={'observed_utc':x['observed_utc'],'runs':x['result']['structuredContent']['workflow_runs']}
plan={
 'schema':'pr180-readonly-forward-integration-plan-v1',
 'prepared_at_utc':'2026-10-09 10:34:04 UTC',
 'verdict':'precise_forward_only_plan_ready_for_actual_candidate_creation_and_independent_review',
 'scope':'Read-only Git metadata, exact source identities, immutable patch bytes, and future composition plan. No repository source edit, commit, push, label change, workflow dispatch, or new performance artifact download.',
 'remaining_original_TODO':29,
 'final_frozen_identity':{'PR180':180,'head':'4652cad11dde4b41126544a38fddf25eb2fb7474','branch':'integrate/p8-snapshot-oracle-28fe-20261009','main':'55aa2bcf355441585bcf980e1d6f4fab8eebe59d','main_tree':'2cac0dd284a7db2bbce8dfa02942f7c19c8d43c0','common_base':'fd9ca5db6485b575872c722995c451db926d05c9','parent_order':['4652cad11dde4b41126544a38fddf25eb2fb7474','55aa2bcf355441585bcf980e1d6f4fab8eebe59d'],'expected_product_tree_if_no_additional_archive_files':'9ae248f8e0c42a8a7389e26e3f44710dfb029640'},
 'external_changes_observed':[
  {'event':'PR180 externally merged mainfd9','head':'4652cad11dde4b41126544a38fddf25eb2fb7474','parents':['3ffcefc3b28ee1a4ed80caecebd7208a45c3e302','fd9ca5db6485b575872c722995c451db926d05c9'],'exact_delta':'7 documentation files plus 20 new artifact files; product and validation remained 3ff'},
  {'event':'main externally merged PR185 during this review','head':'55aa2bcf355441585bcf980e1d6f4fab8eebe59d','parents':['fd9ca5db6485b575872c722995c451db926d05c9','ff8a4e388dd103999b782811c7019ba38e10e511'],'exact_delta':'7 product paths, README/docs/task evidence, 102 added artifact files, and 2 source-binding files','scope_decision':'Parent explicitly authorized retaining all seven external product changes along with frozen v2; 3ff+v2 execution is a different full source identity'},
 ],
 'superseded_plan':{'frozen_main':'fd9ca5db6485b575872c722995c451db926d05c9','product_count':1092,'delta_count':52,'predicted_tree':'0bb881a1e34456ac4556c0256bba56defdb48004','use_for_current_latest_main_integration':False,'evidence_retained':True},
 'complete_file_preservation':{
   'root_and_every_subtree_object_recomputed':True,'five_original_full_tree_file_maps':old['tree_receipts'],
   'main55aa_reconstruction':'30 changed official tree objects, reusing unchanged tree OIDs from the verified complete prior five trees; no leaf inferred by path alone',
   'main55aa_artifact_additions':102,'mainfd9_artifacts_previously_added_to_PR180':20,'PR180_artifacts_distinct_from_main_preserved':169,
   'all_artifact_mode_type_blob_identities_preserved':True,'all_latest_main_README_docs_tasks_preserved':True,
   'external_P8_017_018_notes':'Retained from exact latest-main tasks blob. No task status/dependency/acceptance field edited by this plan.',
   'frozen_source_Gc8_and_original_studies':'Unchanged; no execution/cohort relabelling',
 },
 'true_three_way_conflicts':a['both_changed_conflicts'],
 'source_conflicts':{'product_paths':[],'validation_paths_excluding_two_selected_bindings':[],'file_directory_collisions':[],'text_merge_command_was_run':False,'method':'Both parents differed from exact common-base mode/type/blob and differed from one another; only two explicit incompatible bindings met that definition'},
 'new_main_product_inputs_to_keep_exactly':a['latest_main_additional_product_inputs'],
 'three_DB_files_to_replace_with_frozen_v2':manifest['modified_files'],
 'preserved_compile_inputs_outside_product_domain':[
  {'path':'artifacts/checkpoints/capability-snapshot-optimization-20261003/current-status-under-test.rs','git_blob':'6b25ddadb69ba1f27dcc547e000c392119467cb1','relation':'same original3ff/main55aa/union bytes'},
  {'path':'artifacts/checkpoints/capability-snapshot-optimization-20261003/v2-status-checks.rs','git_blob':'17fc3cdceb467e8837475f396778fa3dff6208cc','relation':'same original3ff/main55aa/union bytes'}],
 'P_plan':[
  'Create a new isolated candidate from actual PR180 head4652; retain first-parent4652 and second-parent frozen main55aa.',
  'Assemble the complete union in prospective-55aa-product-input-maps.json: take independent branch products from4652, the seven main changes and every latest README/docs/task file from55aa, and all distinct artifact leaves from both.',
  'Resolve only registry/guard conflicts by keeping branch4652 bindings temporarily. Replace exactly three DB paths with frozen v2 after bytes. Do not alter source algorithms, tests, budgets, gates, labels, restricted P7-018, or task states.',
  'Before creating P, assert full prospective tree9ae248..., all modes/blobs,1093product/59BASEdelta/139validation. Product commit and execution remain distinct until actual commit is independently bridged.',
  'Record actual P/tree/ordered parents, full input inventory and source-before/after. Do not present native3ff+v2 executions as executions of this newly composed source.',
 ],
 'R_plan':{
   'requires_actual_P_first':True,'new_review_path':'artifacts/checkpoints/p8-pr180-public-dependency-fix-bfcc-20261009/independent-source-review.json',
   'base':'7354db236c9d9850a75f31672697ae9eab44565e','source':'ACTUAL_NEW_P','counts':{'complete_inputs':1093,'paths':59,'validation_inputs':139},
   'path_contract':'Each of the59 paths must equal exactly {before_sha256,sha256}; before values remain the original BASE7354 identities. Full product/validation maps must match actual P.',
   'review_basis':'49 unchanged PR180 delta inputs retain their exact earlier semantic-review bytes;7 latest-main product changes retain published canonical source provenance;3 v2 DB paths use independent source and real RED/GREEN evidence. All actual P identities require non-author verification.',
   'canonical_main_source':'49a03e1f9fa33b7b85cbc9680b47f521afbd8abd','canonical_main_review':'bd9f7979ee76bf1ca3f0d8be284fd1a8f39fea22','canonical_main_review_sha256':'1c29eb3e9f2509de538cb0b737ded099a7ee771c44b2afdde24d868525ce9eca',
   'verdict_and_blockers':'Fill accepted_scoped and [] only after real independent review of actual P; this plan is not that acceptance.',
   'execution_scope':'source admission only; runtime, performance, original task completion, and release require separately scoped evidence',
 },
 'G_minimal_update':{
   'changed_paths':['scripts/reviewed-source-registry-v15.json','scripts/verify_reviewed_source_v15.py'],
   'registry_changes':['product_source=actual P','review_source=actual R','review_sha256=SHA256 of exact canonical R bytes','complete_inputs=all1093 actual product hashes','delta=all59 actual BASE→P records','validation_inputs=unchanged139 original hashes'],
   'registry_fixed':'schema10,versionv15,previousv14,BASE7354,source-only scope and separate-execution requirement unchanged',
   'guard_only_changes':['PRODUCT','REVIEW','REVIEW_PATH','REGISTRY_SHA256'],
   'CI_or_guard_logic_changes':False,'source_admission_original_argv':['python3','scripts/verify_reviewed_source_v15.py','--source-version','p8-completion-source-20261009-v15'],
   'historical_objects':'Keep exact BASE/P/R and pre-existing historical approval objects accessible to the unchanged verifier; do not change no-history/no-lazy-fetch protections to make a run pass.',
   'new_execution':'Parent authorized actual composed-source27 affected tests,fm t and strict cc-db Clippy; use exact commands from retained native receipts, with actual new source snapshots. The unchanged source-integrity/v15 steps run in original newG CI. No additional N30 prerequisite is introduced.',
 },
 'scale_trigger':{'PR180_labels_at_observation':['p8-scale-run'],'PR181_labels_at_observation':[],'workflow_path':'.github/workflows/p8-scale.yml','exact_git_blob':'74f1b64ed447ef24da584f1c1f8d090d2fa1e03e','sha256':'4258476dd37d8af223aaa7ad45d7c97d7298be1ba4ec5ffd9af9949785ed8f3d','events_lines':'3-6:workflow_dispatch or pull_request types[labeled]','job_condition_line':19,'checkout_line':25,'ordinary_push_or_synchronize_starts_full_scale':False,'an_already_present_label_by_itself_retriggers_scale':False,'remove_and_readd_scale_label_or_explicit_dispatch_starts_scale':True,'advice':'Keep labels unchanged for the ordinary fast-forward update. Do not re-add p8-scale-run or dispatch. Existing3ff scale37910924354 remains its own immutable run; do not relabel its artifacts.', 'no_action_taken':True},
 'fresh_PR_metadata_boundary':{'final_read_heads':['4652cad11dde4b41126544a38fddf25eb2fb7474','4866ec5558f1cedd34c7dc54231af65b77f706ec'],'PR_API_reported_base_sha':'fd9ca5db6485b575872c722995c451db926d05c9','actual_main_ref_at_same_review':'55aa2bcf355441585bcf980e1d6f4fab8eebe59d','reported_mergeable':False,'reported_mergeable_state':'dirty','explanation':'Preserve both actual API facts. The PR base.sha lagged the new main ref; do not declare ready-to-merge from earlier true/unstable metadata.', 'before_remote_update':'Assert actual PR180 remote head remains4652 or deliberately reconcile a newer head. Use ordinary fast-forward update only. Freeze55aa for this reviewed combination; no endless restart for later docs-only heads. Handle subsequent actual product conflicts explicitly.'},
 'PR181':{'head':'4866ec5558f1cedd34c7dc54231af65b77f706ec','P':'fced7366cee6aa727aa10d775539c3ef9df5c8d2','R':'d9581c4c9fa0c46cdd792cffb1a19689af946c6d','counts':{'product':1091,'delta':46,'validation':139},'old_to_new_product_delta':old['pr181']['old_to_new_four_product_paths'],'old_to_new_validation_delta':['scripts/p8_runtime.py','scripts/tests/test_p8_runtime.py'],'identity_conclusion':'Current canonical review complete mode/blob/size inventories1091+139 independently equal actual newhead. Four imported product files are inherited main statistics/resolver changes; new input combination is not certified by oldhead CI.', 'no_change_or_merge_requested':True},
 'CI_observations':checks,
 'execution_evidence_boundary':{'prior_native_result_reference':'/workspace/scratch/bfccb8494ba0/scale-intake-primary/pr180-native-peer/independent-execution-review.json','prior_native_peer_sha256':'9f8df1be44aa9b757a15dea6fa0a6e0222ca70a0f2c9b790c2b086a709277640','parent_and_peer_report':'Original3ff+test RED101(64vs70),v1 GREEN0;v2 affected27pass,fmt0,cc-db Clippy0. Those results remain bound to their actual3ff+v2 source; all newmain7-source changes need accurate new-combination validation.','this_author_did_not_rerun_Rust':True,'newhead_CI':'New4652 and4866 each seven workflows queued at archived observation; no oldhead green transferred.'},
 'supporting_reports':[digest(P/'55aa-full-union-audit.json'),digest(P/'55aa-canonical-input-bridge.json'),digest(P/'prospective-55aa-product-input-maps.json'),digest(P/'pr181-current-canonical-inventory-bridge.json')],
}
# Typographic correction only in prose, not an executable command.
plan['G_minimal_update']['new_execution']=plan['G_minimal_update']['new_execution'].replace('fm t','fmt')
report=write('pr180-safe-forward-integration-plan.json',plan)
excluded={'archive-selection.json','archive-receipt.json','new-main55aa-complete-derived-tree.json'}
entries=[digest(p) for p in sorted(P.rglob('*')) if p.is_file() and p.name not in excluded]
selection={'schema':'readonly-PR-integration-plan-archive-selection-v1','scope':'source identity and integration plan; no new product execution','entries':entries,'file_count':len(entries),'total_bytes':sum(x['bytes'] for x in entries),
 'external_immutable_inputs':[{'scope':'five official full trees and native read receipts, already centrally transported; do not duplicate performance artifacts','path':'/workspace/scratch/bfccb8494ba0/root-round13/current-merge-trees-transfer/extracted','trees':old['tree_receipts']},{'scope':'frozen v2 patch/source bytes; old archive remains immutable','manifest':digest(Path('/dev/shm/todo-audit-pr180-public-dependency-fix-v2/source-manifest.json'))}],
 'reproducible_derived_large_file_excluded':digest(P/'new-main55aa-complete-derived-tree.json'),'reconstruction':'resolve-new-main-trees.py + five external official trees + included new-main-trees/*.json'}
sel=write('archive-selection.json',selection)
print(json.dumps({'plan':report,'selection':sel,'files':len(entries),'bytes':selection['total_bytes'],'predicted_P_tree':plan['final_frozen_identity']['expected_product_tree_if_no_additional_archive_files']},indent=2))
