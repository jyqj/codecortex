#!/usr/bin/env python3
"""Artifact installation check and mechanical G8B generation; no product execution."""
import copy
import datetime
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

B = Path(__file__).resolve().parent
PREP = Path('/dev/shm/todo-audit-G8B-binding-preparation')
P = '44e6248106335b5f0625e53de38f76d26aeeadcf'
R = 'cb57d6e39f446e68ed5bd5bce26a7a76d1a26e5c'
RT = '8a9749f558b4c98c814d02353a98ada2ff3e42b5'
CANON = Path('/dev/shm/pr-triage-round21-P8B-source-review/final-R8B')
PREFIX = 'artifacts/checkpoints/p8-immutable-payload-cell-witness-bfcc-20261009/'

def sha(v): return hashlib.sha256(v).hexdigest()
def blob(v): return hashlib.sha1(b'blob '+str(len(v)).encode()+b'\0'+v).hexdigest()
def read(p): return json.loads(Path(p).read_bytes())
def unwrap(p): return json.loads(read(p)['structuredContent']['content'])
def write(n,v): (B/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def tree_oid(rows):
    data=b''
    for r in sorted(rows,key=lambda r:(r['path']+('/' if r['type']=='tree' else '')).encode()):
        data+=('40000' if r['mode']=='040000' else r['mode']).encode()+b' '+r['path'].encode()+b'\0'+bytes.fromhex(r['sha'])
    return hashlib.sha1(b'tree '+str(len(data)).encode()+b'\0'+data).hexdigest()

def main():
    assert not (B/'generated').exists()
    meta=read('/dev/shm/root-round21/R8B-official-commit.json')
    assert meta['sha']==R and meta['tree']['sha']==RT and [x['sha'] for x in meta['parents']]==[P]
    write('R8B-official-commit.json',meta)
    comp=unwrap(B/'R8B-install-compare-tool-response.json')
    assert comp['base_commit']['sha']==P and comp['total_commits']==1 and comp['commits'][0]['sha']==R
    manifest=read(CANON/'upload-manifest.json')
    expected={x['repository_path']:x for x in manifest['files']}
    assert len(expected)==6 and len(comp['files'])==6
    for f in comp['files']:
        x=expected[f['filename']]; raw=Path(x['local_path']).read_bytes()
        assert f['status']=='added' and x['mode']=='100644'
        assert f['sha']==x['git_blob']==blob(raw) and x['sha256']==sha(raw) and x['bytes']==len(raw)
    write('R8B-upload-manifest.json',manifest)
    roots=unwrap(B/'R8B-root-tree-tool-response.json')
    assert roots['truncated'] is False and tree_oid(roots['tree'])==roots['sha']==RT
    scripts=unwrap('/dev/shm/todo-audit-G6B-22975e49-binding/R6B-scripts-tree-tool-response.json')
    assert scripts['truncated'] is False and tree_oid(scripts['tree'])==scripts['sha']=='f691d18ff1ab98f96c02b2d604dc23d57bb12e20'
    srows=copy.deepcopy(scripts['tree'])
    replacements=[('scripts/reviewed-source-registry-v15.json','seed-G6B-registry.json'),('scripts/verify_reviewed_source_v15.py','seed-G6B-guard.py')]
    for path,seed in replacements:
        raw=(PREP/seed).read_bytes()
        row=next(x for x in srows if x['path']==path.split('/',1)[1]); row['sha']=blob(raw); row['size']=len(raw)
    assert tree_oid(srows)=='121df4bdc31cf77e6d829ea8c26bfcbce3773882'
    assert next(x['sha'] for x in roots['tree'] if x['path']=='scripts')==tree_oid(srows)
    write('reconstructed-actual-G6B-scripts-tree.json',{'sha':tree_oid(srows),'tree':srows,'basis':'Original official R6 scripts tree plus exact retained actual G6 two binding blobs; rehash equals actual official R8 scripts root'})
    write('actual-R8B-six-leaf-installation-review.json',{'actual_R':R,'actual_R_tree':RT,'ordered_parents':[P],'verdict':'accepted_scoped_artifact_only_installation','exact_added_leaves':list(expected.values()),'official_compare_only_six_additions':True,'original_R7_and_v1_v2_diagnostics_preserved':True,'runtime_or_source_admission_execution':False})
    argv=[sys.executable,str(PREP/'generate-G8B-bindings.py'),'--product-inputs',str(PREP/'actual-P8B-G6B-six-path-binding-inputs.json'),'--product-commit-file',str(PREP/'P8B-official-commit.json'),'--review-file',str(CANON/'independent-source-review.json'),'--review-commit-file',str(B/'R8B-official-commit.json'),'--review-path',PREFIX+'independent-source-review.json','--review-git-blob','97979612a5faa0322fea39b1ef31d8986a0e3093','--review-sha256','f42192342274b26c0f9c05c5998bf6661c0ae16e90eb82ed6ac63702d42a5b6c','--output-directory',str(B/'generated')]
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (B/'generation.stdout').open('wb') as out,(B/'generation.stderr').open('wb') as err:
        proc=subprocess.run(argv,stdout=out,stderr=err,check=False)
    write('generation-command-receipt.json',{'argv':argv,'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_exit_code':proc.returncode,'scope':'Mechanical metadata/binding generation only; no v15, Rust, study or task execution'})
    assert proc.returncode==0, 'Retain failure without automatic retry'
    receipt=read(B/'generated/generation-receipt.json')
    items=[]; patch=''
    for path,seed in replacements:
        old=(PREP/seed).read_bytes(); raw=(B/'generated'/path).read_bytes()
        row=next(x for x in srows if x['path']==path.split('/',1)[1])
        assert row['mode']=='100644' and row['sha']==blob(old)
        items.append({'repository_path':path,'local_path':str(B/'generated'/path),'mode':'100644','type':'blob','bytes':len(raw),'sha256':sha(raw),'git_blob':blob(raw),'before_git_blob':row['sha'],'before_sha256':sha(old)})
        row['sha']=blob(raw);row['size']=len(raw)
        patch+=''.join(difflib.unified_diff(old.decode().splitlines(True),raw.decode().splitlines(True),fromfile='actual-G6B/'+path,tofile='prospective-G8B/'+path))
    (B/'two-binding.diff').write_text(patch)
    new_scripts=tree_oid(srows);rrows=copy.deepcopy(roots['tree'])
    next(x for x in rrows if x['path']=='scripts')['sha']=new_scripts
    expected_tree=tree_oid(rrows)
    write('G8B-two-leaf-create-tree-request.json',{'base_tree':RT,'tree':[{'path':x['repository_path'],'mode':x['mode'],'type':'blob','sha':x['git_blob']} for x in items]})
    result={'actual_G':None,'expected_G_tree':expected_tree,'expected_scripts_tree':new_scripts,'actual_P':P,'actual_R':R,'actual_R_tree':RT,'suggested_G_ordered_parents':[R],'files':items,'file_count':2,'counts':receipt['counts'],'allowlisted_actual_registry_fields':receipt['actual_changed_registry_fields'],'allowlisted_guard_pin_lines':receipt['changed_guard_lines'],'all_142_validation_bytes_preserved':True,'BASE_FROZEN_historical_CI_and_guard_algorithm_unchanged':True,'exact_G6_to_P8_product_changes':receipt['changed_product_paths'],'new_BASE_delta_paths':receipt['added_BASE_delta_paths'],'current_G_CLI_tests_runtime_performance_TODO_credit':False}
    write('allowlisted-delta-and-installation-manifest.json',result)
    print(json.dumps(result,sort_keys=True))

if __name__=='__main__': main()
