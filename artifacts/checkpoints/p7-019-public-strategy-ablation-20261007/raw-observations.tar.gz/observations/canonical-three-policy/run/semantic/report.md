# CodeCortex benchmark baseline

Suite: `p7-019-fake-public-three-policy-mechanism`
Adapter: `public-strategy-ablation-v1`
Scoring: `Native`
Measurement profile: `fake`

Status: **baseline_recorded_not_quality_certified** (exit 0)

Queries: 3; measured rows: 6.
Mean Top-1: 1.000000; mean nDCG@10: 1.000000.

These are baseline observations, not a release quality certificate.
Latency: Distribution { samples: 6, p50_us: Some(44280), p95_us: Some(97308), max_us: Some(97308), tail_claim: "insufficient_for_tail_claim" }; samples are retained, not best-of.
Source evidence: 0 invalid, 0 unverified hits.

| Case | Top-1 | nDCG@10 | Repetitions |
|---|---:|---:|---:|
| exact-a | 1.000000 | 1.000000 | 2 |
| exact-b | 1.000000 | 1.000000 | 2 |
| authored-intent | 1.000000 | 1.000000 | 2 |

## Failures
