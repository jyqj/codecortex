def stable_00018():
    return 18
