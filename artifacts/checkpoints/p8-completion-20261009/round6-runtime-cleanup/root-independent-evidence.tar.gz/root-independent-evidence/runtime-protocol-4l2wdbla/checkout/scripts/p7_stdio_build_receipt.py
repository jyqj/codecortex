# committed protocol-control fixture: scripts/p7_stdio_build_receipt.py
