def p8_lifecycle_000001(value):
    return value + 17

def p8_lifecycle_000003(value):
    return value + 17

