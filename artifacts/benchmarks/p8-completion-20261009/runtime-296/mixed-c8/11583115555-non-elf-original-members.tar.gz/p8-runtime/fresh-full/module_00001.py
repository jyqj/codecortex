def stable_00001():
    return 1
