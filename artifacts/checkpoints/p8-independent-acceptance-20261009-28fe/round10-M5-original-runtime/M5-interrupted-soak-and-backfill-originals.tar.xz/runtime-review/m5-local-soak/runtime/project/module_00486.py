def stable_00486():
    return 486
