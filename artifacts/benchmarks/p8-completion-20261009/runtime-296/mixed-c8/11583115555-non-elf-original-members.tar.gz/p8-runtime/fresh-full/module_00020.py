def stable_00020():
    return 20
