def stable_00339():
    return 339
