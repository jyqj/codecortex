import datetime, hashlib, json, pathlib, zipfile
ROOT=pathlib.Path('/workspace/scratch/bfccb8494ba0');BASE=ROOT/'scale-intake-primary'
NATIVE=ROOT/'root-round16/native-G-admission-transfer';E=NATIVE/'extracted/G-admission'
OUT=BASE/'G-d7f-admission-independent';OUT.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def git(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def load(p):return json.loads(p.read_text())
def ref(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b),'git_blob':git('blob',b)}
z=NATIVE/'native-db-observation-G-d7f-original-v15-round16.zip'
assert (z.stat().st_size,sha(z.read_bytes()),git('blob',z.read_bytes()))==(413296,'6133e513c6c47aae9d84b02b388e2c8f88f8ae8d5b802d279b2ff5a9f063fa13','9b7ce01e7d4b52fb168b68e44abcc50e5a8a62e5')
manifest=load(NATIVE/'extracted/archive-manifest.json')
with zipfile.ZipFile(z) as a:
 assert a.testzip() is None and len(a.namelist())==len(set(a.namelist()))==32 and len(manifest['files'])==31
 for e in manifest['files']:
  b=a.read(e['path']);assert len(b)==e['bytes'] and sha(b)==e['sha256'];assert b==(NATIVE/'extracted'/e['path']).read_bytes()
 assert a.read('archive-manifest.json')==(NATIVE/'extracted/archive-manifest.json').read_bytes()
r=load(E/'original-v15-command-receipt.json')
assert r['source_G']==r['guard_G']=='d7f21ab52ee2068c45ab5f7781e9e1db57f613de'
assert r['product_P']=='bb290be2deaf4334863e09dbf47fe4ccc9625f2b' and r['review_R']=='51d5ed91e14ddb13eccb93ebd28311a3235075cc'
assert r['exit_code']==0 and 'controller_exception' not in r and 'controller_timeout_seconds' not in r
assert r['argv']==['python3','scripts/verify_reviewed_source_v15.py','--source-version','p8-completion-source-20261009-v15']
for key in ['domain_before','domain_after','stdout','stderr']:
 q=r[key];b=(E/q['path']).read_bytes();assert len(b)==q['bytes'] and sha(b)==q['sha256']
assert (E/r['domain_before']['path']).read_bytes()==(E/r['domain_after']['path']).read_bytes()
domain=load(E/r['domain_before']['path']);assert domain['head']==domain['source_G']==r['source_G']
items={e['path']:e for e in domain['entries']};assert len(items)==len(domain['entries'])==1440
Rpath=BASE/'db-wait-cleanup-P-bb29-independent/independent-source-review.json';R=load(Rpath)
for path,e in R['actual_input_mode_blob_inventory'].items():
 a=items[path];assert (a['mode'],a['git_blob'],a['bytes'],a['sha256'])==(e['mode'],e['sha'],e['size'],e['sha256'])
Gbindings=load(BASE/'installed-db-acquisition-R-G-review/independent-actual-G-installation-review.json')
for q in Gbindings['files']:
 a=items['scripts/'+pathlib.Path(q['path']).name];assert (a['git_blob'],a['bytes'],a['sha256'])==(q['git_blob'],q['bytes'],q['sha256'])
canonical='artifacts/checkpoints/p8-db-acquisition-cleanup-bfcc-20261009/independent-source-review.json'
assert items[canonical]['git_blob']==ref(Rpath)['git_blob'] and items[canonical]['sha256']==ref(Rpath)['sha256']
nativeP1=load(ROOT/'root-round15/native-controls-transfer/extracted/P1-controls/workspace-format-input-before.json')
nativeP1paths={e['path']:e for e in nativeP1['entries']}
assert len(nativeP1paths)==1250 and set(nativeP1paths)<=set(items)
changed=[p for p,a in nativeP1paths.items() if a!=items[p]]
assert sorted(changed)==['scripts/reviewed-source-registry-v15.json','scripts/verify_reviewed_source_v15.py']
additional=set(items)-set(nativeP1paths);assert len(additional)==190 and canonical in additional
history=load(BASE/'H-historical-input-preparation/protected-input-whitelist.json')
commit=(E/'actual-G-commit.stdout').read_bytes();assert git('commit',commit)==r['source_G']
assert commit.startswith(b'tree 23f0f69fef9d62229fd947e7747aefdfea78d024\nparent 51d5ed91e14ddb13eccb93ebd28311a3235075cc\n')
stdout=load(E/'original-v15.stdout')
assert stdout['status']=='passed' and stdout['product_source']==r['product_P'] and stdout['review_source']==r['review_R'] and stdout['complete_inputs']==1095 and stdout['executed_previous_proof']=='p8-oracle-compat-source-20261008-v14'
assert r['parent_head_before']==r['parent_head_after']=='ff458bc591b4e7e444af4464d6eef2513cdb335c'
report={'schema_version':1,'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/execution_recon','verdict':'accepted_scoped_actual_G_original_v15_execution','source_G':r['source_G'],'product_P':r['product_P'],'review_R':r['review_R'],'original_ZIP':ref(z),'all_32_members_CRC_31_original_file_sizes_SHA_and_extracted_bytes_verified':True,'actual_native_receipt':ref(E/'original-v15-command-receipt.json'),'actual_integer_child_exit':r['exit_code'],'actual_argv':r['argv'],'started_at':r['started_at'],'ended_at':r['ended_at'],'elapsed_seconds':r['elapsed_seconds'],'actual_G_raw_commit_SHA_reconstructed':True,'stdout':ref(E/'original-v15.stdout'),'stdout_fields':stdout,'stderr':ref(E/'original-v15.stderr'),'before_after_1440_complete_JSON_bytes_identical':True,'product1095_validation142_match_canonical_R_complete_mode_blob_size_SHA':True,'actual_two_G_bindings_and_canonical_R_bytes_equal':True,'selected_domain_bridge':{'original_P1_selected':1250,'only_two_original_selected_changes':'actual new G registry and guard pins','additional_paths':190,'current_canonical_R_paths':1,'additional_original_historical_context_paths':189,'full_repository_checkout_claim':False},'unchanged_parent_head':r['parent_head_after'],'recorded_environment_overrides':r['environment_overrides'],'controller_boundary':'Original child Popen.wait result is recorded before after-snapshot. Postcheck errors are distinct controller_exception; none in actual receipt. Original argv/guard body unchanged. core.commitGraph=false only changes Git object lookup optimization; no validation logic or caps bypass.','scope_limits':['Original selected v15 including previous v14 proof is the executed scope; 181-test suite not executed here.','No Rust or workload execution by this reviewer, no source/runtime transfer to P2 b3bf.','G1 mixed diagnostic cells and original Gc8 scale remain distinct. No task closure;29remain.']}
p=OUT/'independent-original-v15-thin-review.json'
with p.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps(ref(p)))
