from pathlib import Path
import hashlib,json,stat,zipfile
R=Path('/workspace/scratch/bfccb8494ba0');H=R/'round40-diagnostic-checkpoint-09-intake';O=H/'sealed';O.mkdir(exist_ok=False)
PREFIX='artifacts/checkpoints/p8-round40-complete-bfcc-20261010/diagnostic/checkpoint09/'
def meta(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
paths=[H/n for n in ['receive-original-prefix-once.py','receive-original-prefix-once.py.adaptation.diff','derive-continuity-and-frontier.py','seal-support.py']]
paths+=sorted(p for p in (H/'attempt01').rglob('*') if p.is_file() and p.name!='checkpoint09-prefix-review.json')
paths += [R/'round32-100k-diagnostic-intake-preparation/read-original-diagnostic.py',R/'round32-100k-diagnostic-intake-bound-9cc6-run38012409915/binding.json',R/'round39-0355-dual-study-observation/diagnostic-artifacts.original.json',R/'round39-0355-dual-study-observation/finite-observation-review.json']
paths += [R/'round39-diagnostic-checkpoint-08-intake/attempt01'/n for n in ['checkpoint08-prefix-review.json','reader/report.json','official-index.json']]
paths += sorted(p for p in R.glob('round*-diagnostic-checkpoint-*-intake/attempt01/selected-originals/manifest.json') if json.loads(p.read_text())['index']<9)
assert len(set(paths))==len(paths)
files=[{'local_path':str(p),'archive_path':str(p.relative_to(R)),'posix_mode':oct(stat.S_IMODE(p.stat().st_mode)),**meta(p)} for p in paths]
selection={'schema':'selected-new09-prefix-intake-originals-v1','files':files,'scope':'New09 sole frozen-reader all-member CRC/SHA acceptance; explicit derived00-08 small-record bridge. No prior ZIP read, ELF, product or original semantic validator. No study/TODO credit.','original_ZIPs_not_nested':True,'original09':{'artifact_id':11658523401,'bytes':56274,'sha256':'c328608100037e26e58ecb3c0a0d071c8f9ff17a8fdc003a55911a1651922b4c'},'report_separate_leaf':True}
sp=O/'archive-selection.json';sp.write_text(json.dumps(selection,indent=2)+'\n');zp=O/'diagnostic-checkpoint09-original-prefix-support.zip'
with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p,rec in zip(paths,files):
  zi=zipfile.ZipInfo(rec['archive_path'],(2026,10,10,0,0,0));zi.create_system=3;zi.external_attr=(stat.S_IFREG|stat.S_IMODE(p.stat().st_mode))<<16;zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,p.read_bytes())
 zi=zipfile.ZipInfo('archive-selection.json',(2026,10,10,0,0,0));zi.create_system=3;zi.external_attr=(stat.S_IFREG|0o644)<<16;zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,sp.read_bytes())
# Verify only this newly written small support archive, never any original study ZIP.
with zipfile.ZipFile(zp) as z:
 assert len(z.infolist())==len(files)+1
 for rec in files:
  b=z.read(rec['archive_path']);assert len(b)==rec['bytes'] and hashlib.sha256(b).hexdigest()==rec['sha256']
  assert oct((z.getinfo(rec['archive_path']).external_attr>>16)&0o777)==rec['posix_mode']
 assert z.read('archive-selection.json')==sp.read_bytes()
report=H/'attempt01/checkpoint09-prefix-review.json'
uploads=[{'local_path':str(p),'repository_path':PREFIX+name,**meta(p)} for p,name in [(report,report.name),(zp,zp.name),(sp,sp.name)]]
manifest={'files':uploads,'support_members':len(files)+1,'new_support_crc_sha_mode_verified':True,'frozen_reader_invocations':1,'old_original_ZIPs_reopened':0,'native_or_semantic_validator_calls':0,'refs_changed':False}
(O/'upload-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
