#!/usr/bin/env python3
"""Finite receipt-only intake of three already materialized original ZIPs; no API/native/workload."""
from pathlib import Path
import sys, json, hashlib, importlib.util, datetime
sys.dont_write_bytecode=True
ROOT=Path("/dev/shm/pr-triage-G2-db-lock-cohort-37930392164")
OLD=Path("/dev/shm/execution-recon-recovery-20261009/intake_once.v2.py")
assert hashlib.sha256(OLD.read_bytes()).hexdigest()=="61f4ae48bc84dbc9f90862a80d06a8268ec4aa93f83c75582b716bc32f4c3369"
spec=importlib.util.spec_from_file_location("original_zip_receiver_v2",OLD)
original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
source=Path("/dev/shm/pr-triage-round17-existing-lock-diagnostic")
run=json.loads((source/"run.raw.json").read_text())
assert run["id"]==37930392164 and run["head_sha"]=="4d18dcdb34b5d7a277566b57801cc882d8b1eb61"
assert run["run_attempt"]==1 and run["event"]=="push" and run["path"]==".github/workflows/p8-db-lock-observation.yml"
artifacts=json.loads((source/"artifacts.raw.json").read_text())["artifacts"]
assert len(artifacts)==3 and {x["id"] for x in artifacts}=={11621010611,11620977433,11617781499}
results=[]
for meta in artifacts:
    out=ROOT/"raw"/str(meta["id"])/"attempt01"
    receipt={"schema_version":1,"artifact_id":meta["id"],"source_G":run["head_sha"],"run_id":run["id"],"run_attempt":1,"workflow_event":"push","receiver_sha256":hashlib.sha256(OLD.read_bytes()).hexdigest(),"started_at":original.utc(),"status":"running","semantic_acceptance":"pending","measurement_or_TODO_credit":False}
    code=0
    try:
        assert meta["workflow_run"]["id"]==run["id"] and meta["workflow_run"]["head_sha"]==run["head_sha"] and meta["expired"] is False
        original.write_new(out/"github-metadata.json",meta)
        original.write_new(out/"run.json",run)
        digest,verified=original.verify_zip_identity(out/"original.zip",meta,out)
        assert verified
        inventory=original.extract_original(out/"original.zip",out/"extracted")
        original.write_new(out/"zip-members.json",{"members":inventory,"member_count":len(inventory),"uncompressed_bytes":sum(x.get("bytes",0) for x in inventory),"original_zip_mode_and_receiver_mode_separately_recorded":True})
        assert original.sha(out/"original.zip")==digest
        receipt.update(status="transport_verified",zip_sha256=digest,zip_bytes=(out/"original.zip").stat().st_size,members=len(inventory),uncompressed_bytes=sum(x.get("bytes",0) for x in inventory),CRC_all_read=True,all_regular_members_SHA256=True,original_zip_unchanged=True,extracted_path=str(out/"extracted"),POSIX_mode_preservation_claim=False)
    except Exception as exc:
        receipt.update(status="failed_retained",error=repr(exc));code=1
    receipt.update(finished_at=original.utc(),actual_intake_exit_code=code)
    original.write_new(out/"transport-receipt.json",receipt)
    results.append(receipt)
original.write_new(ROOT/"three-original-intake-summary.json",{"results":results,"native_workloads_started":0,"API_requests":0,"automatic_retry":False})
print(json.dumps(results,indent=2))
sys.exit(1 if any(x["actual_intake_exit_code"] for x in results) else 0)
