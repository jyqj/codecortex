def p8_temporary():
    return 3
