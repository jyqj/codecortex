def stable_00272():
    return 272
