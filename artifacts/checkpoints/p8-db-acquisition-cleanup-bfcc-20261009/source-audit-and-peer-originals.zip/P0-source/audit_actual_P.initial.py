import collections,datetime,hashlib,json
from pathlib import Path
OUT=Path(__file__).resolve().parent
API=OUT/'github-api'
P='3ced45d1f4bbfc38eeab3fbe1a1ef17eae26721a'
PREV=OUT.parent/'round14-actual-P-independent'
AUTHOR=Path('/dev/shm/todo-audit-p8007-lock-observation-review')
def load(p): return json.loads(p.read_text())
def api(name): return json.loads(load(API/name)['content'])
def sha256(b): return hashlib.sha256(b).hexdigest()
def git(kind,b): return hashlib.sha1((kind+' '+str(len(b))+'\0').encode()+b).hexdigest()
def identity(p):
    raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':sha256(raw)}
def tree_hash(entries):
    body=b''.join((('40000' if e['mode']=='040000' else e['mode'])+' '+e['path']).encode()+b'\0'+bytes.fromhex(e['sha']) for e in sorted(entries,key=lambda e:(e['path']+('/' if e['type']=='tree' else '')).encode()))
    return git('tree',body)
def verify_tree(data):
    assert data['truncated'] is False
    children=collections.defaultdict(list)
    for e in data['tree']:
        parent,_,name=e['path'].rpartition('/');children[parent].append({**e,'path':name})
    expected={'':data['sha'],**{x['path']:x['sha'] for x in data['tree'] if x['type']=='tree'}}
    for path,want in expected.items():assert tree_hash(children[path])==want,path
    return len(expected)
commit=api('commit.json');root=api('root-tree.json')
parents=['e5640904298febdf8dc951e0baddb2819f930c0b','18255c53b7fa153bb71c96f57f1b97ca139e427f','b7154d585527cdc4cd7fb86d1e9828bed3d37088']
assert commit['sha']==P and [r['sha'] for r in commit['parents']]==parents
assert root['sha']==commit['tree']['sha']=='de9e502692569dec1f0e6629575145ec10c837d5'
assert tree_hash(root['tree'])==root['sha']
raw='tree '+root['sha']+'\n'+''.join('parent '+p+'\n' for p in parents)
for role in ['author','committer']:
    item=commit[role];stamp=int(datetime.datetime.fromisoformat(item['date'].replace('Z','+00:00')).timestamp())
    raw+=f"{role} {item['name']} <{item['email']}> {stamp} +0800\n"
raw+='\n'+commit['message'];assert git('commit',raw.encode())==P
(OUT/'actual-P.commit').write_bytes(raw.encode())
actual={e['path']:e for e in root['tree'] if e['type']=='blob'};tree_count=1
for prefix,name in [('crates','crates'),('scripts','scripts'),('tests','tests'),('.github','github')]:
    data=api(name+'-tree.json');assert next(e['sha'] for e in root['tree'] if e['path']==prefix)==data['sha'];tree_count+=verify_tree(data)
    actual.update({prefix+'/'+e['path']:{**e,'path':prefix+'/'+e['path']} for e in data['tree'] if e['type']!='tree'})
product={p:r for p,r in actual.items() if p.startswith('crates/') or p in ('Cargo.toml','Cargo.lock')}
excluded={'scripts/verify_reviewed_source_v15.py','scripts/reviewed-source-registry-v15.json','.github/workflows/ci.yml'}
validation={p:r for p,r in actual.items() if (p.startswith('scripts/') or p.startswith('.github/workflows/') or p.startswith('tests/source_integrity/')) and p not in excluded and not ('__pycache__' in Path(p).parts and p.endswith('.pyc'))}
assert len(product)==1095 and len(validation)==142
plan_path=AUTHOR/'actual-P-review-inputs/actual-P-complete-product-validation-inputs.json';plan=load(plan_path)
assert plan['source']==P and plan['tree']==root['sha']
assert set(product)==set(plan['complete_inputs']) and set(validation)==set(plan['validation_inputs'])
previous=load(PREV/'actual-P-complete-source-audit.json');old=previous['actual_input_mode_blob_inventory']
changed=load(AUTHOR/'staged-combined-source-manifest.json')['files'];changed={e['path']:e for e in changed}
current={};donors={}
for path,e in {**product,**validation}.items():
    assert e['type']=='blob' and e['mode'] in ('100644','100755')
    expected=plan['actual_input_mode_blob_inventory'][path]
    assert all(e[k]==expected[k] for k in ('mode','type','sha','size')),path
    if path in changed:
        donor=changed[path];raw=Path(donor['local_path']).read_bytes()
        assert e['sha']==git('blob',raw)==donor['sha'] and len(raw)==e['size']==donor['bytes']
        digest=sha256(raw);assert digest==donor['sha256']
        dst=OUT/'source'/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw)
        donors[path]='Actual original donor bytes freshly rehashed: '+donor['source']
    else:
        prior=old[path];assert all(prior[k]==e[k] for k in ('mode','type','sha','size')),path
        digest=prior['sha256'];donors[path]='Exact retained independently reviewed c92 path/mode/type/blob/size; SHA reused only through immutable identity'
    assert digest==plan['complete_inputs'].get(path,plan['validation_inputs'].get(path)),path
    current[path]={**{k:e[k] for k in ('mode','type','sha','size')},'sha256':digest}
assert sum(p in changed for p in product)==12 and sum(p in changed for p in validation)==5
doc='docs/P8_DB_LOCK_OBSERVATION.md';raw=Path(changed[doc]['local_path']).read_bytes();assert git('blob',raw)==changed[doc]['sha'] and sha256(raw)==changed[doc]['sha256']
dst=OUT/'source'/doc;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw)
base=dict(previous['complete_inputs'])
for path,d in previous['paths'].items():
    if d['before_sha256'] is None:del base[path]
    else:base[path]=d['before_sha256']
assert set(base)<=set(product)
delta={p:{'before_sha256':base.get(p),'sha256':current[p]['sha256']} for p in sorted(product) if base.get(p)!=current[p]['sha256']}
assert delta==plan['paths'] and len(delta)==67
retained=[p for p,d in delta.items() if d==previous['paths'].get(p)]
assert len(retained)==55
derived_path=AUTHOR/'actual-P-review-inputs/actual-P-complete-derived-Git-tree.json';derived=load(derived_path);derived_count=verify_tree(derived);assert derived['sha']==root['sha']
dm={e['path']:e for e in derived['tree']}
for path,e in actual.items():
    assert all(dm[path][k]==e[k] for k in ('mode','type','sha')),path
assert dm[doc]['sha']==changed[doc]['sha'] and dm[doc]['mode']==changed[doc]['mode']
for path in excluded:
    assert all(actual[path][k]==dm[path][k] for k in ('mode','type','sha'))
result={'schema_version':1,'scope':'Actual source and validation identity audit; no native execution, original source CLI or new workload','source':P,'tree':root['sha'],'parents':parents,'base':previous['base'],'raw_commit_sha_independently_reconstructed':True,'official_protected_and_root_tree_objects_rehashed':tree_count,'independently_rehashed_derived_complete_tree_objects':derived_count,'derived_full_tree_is_not_a_new_official_recursive_response':True,'complete_inputs':{p:current[p]['sha256'] for p in sorted(product)},'validation_inputs':{p:current[p]['sha256'] for p in sorted(validation)},'paths':delta,'actual_input_mode_blob_inventory':current,'input_identity_sources':donors,'counts':{'product':1095,'validation':142,'BASE_delta':67,'unchanged_c92_product':1083,'changed_product_raw_rehashed':12,'unchanged_c92_validation':137,'changed_validation_raw_rehashed':5,'retained_c92_BASE_delta':55,'additional_document_raw_rehashed':1},'binding_inputs_at_P':{p:{k:actual[p][k] for k in ('mode','type','sha','size')} for p in sorted(excluded)},'source_references':{'previous_c92_audit':identity(PREV/'actual-P-complete-source-audit.json'),'mechanical_author_map':identity(plan_path),'complete_derived_tree':identity(derived_path),'changed_source_manifest':identity(AUTHOR/'staged-combined-source-manifest.json')},'limitations':['No historical CI, diagnostic timing or original Gc8 samples transfer to this product source.','The full derived Git tree is checked by SHA reconstruction; only current source/validation four subtrees were separately obtained as official complete recursive responses.','Existing selected P guard/registry remain provisional old bindings until root creates the new canonical R/G.','P8-007 still requires actual four diagnostic cells on an admitted source; this is source preparation only.']}
out=OUT/'actual-P-complete-source-audit.json'
with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'report':identity(out),'source':P,'counts':result['counts'],'official_trees':tree_count,'derived_trees':derived_count}))
