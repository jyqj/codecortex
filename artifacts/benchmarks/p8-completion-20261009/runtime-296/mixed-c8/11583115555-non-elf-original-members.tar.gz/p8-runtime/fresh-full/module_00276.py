def stable_00276():
    return 276
