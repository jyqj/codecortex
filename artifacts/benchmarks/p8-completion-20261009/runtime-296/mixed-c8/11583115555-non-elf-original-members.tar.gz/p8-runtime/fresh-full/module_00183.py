def stable_00183():
    return 183
