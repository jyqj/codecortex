#!/usr/bin/env python3
"""Read only already extracted terminal text and retained official responses."""
import ast
import collections
import datetime
import hashlib
import json
from pathlib import Path

BASE = Path('/workspace/scratch/bfccb8494ba0')
OUT = BASE / 'round40-full-cohort-terminal-independent-review'
OBS = BASE / 'round39-0355-dual-study-observation'
LOGS = BASE / 'round40-full-cohort-terminal-original-logs'

def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}

def read(path):
    return json.loads(path.read_text())

matrix_path = OUT / 'original-members/matrix.json'
matrix = read(matrix_path)
missing = ast.literal_eval(matrix['error'].removeprefix('missing matrix shards: '))
assert matrix['status'] == 'failed' and matrix['passed'] is False
assert matrix['release_certification'] == 'not_run'
assert len(missing) == len(set(missing)) == 146
universe = {(scale, repetition) for scale in (1000, 5000, 10000, 50000, 100000) for repetition in range(30)}
complement = sorted(universe - set(missing))
assert complement == [(1000, 0), (5000, 0), (10000, 0), (50000, 0)]
log_path = LOGS / '114125450702-original-aggregate.log'
log_identity = identity(log_path)
assert log_identity['git_blob'] == 'df5aacfba4beb0f6103c995fbbb9d4cdc5c823b4'
lines = log_path.read_text(encoding='utf-8-sig').splitlines()
needles = [
    'HEAD is now at 9cc6bf4',
    "repetitions=30, shard_count=30, capacity_profile=matrix.WIDE_DIRTY_PROFILE",
    "'sample_count': None",
    'Process completed with exit code 1.',
    'Total of 4 artifact(s) downloaded',
    'SHA256 digest of uploaded artifact zip is 716be1cef60ff03736583ca7bca4dd75be435c44fc6936aa801df6cf57a4f32b',
    'Artifact ID is 11658738280',
]
selected = []
for needle in needles:
    found = [{'line': index + 1, 'text': text} for index, text in enumerate(lines) if needle in text]
    assert found, needle
    selected.extend(found)
jobs = read(OBS / 'fullcohort-jobs.original.json')['jobs']
job100 = next(j for j in jobs if j['id'] == 114100438875)
aggregate = next(j for j in jobs if j['id'] == 114125450702)
measure = next(j for j in jobs if j['id'] == 114125451149)
assert job100['status'] == 'completed' and job100['conclusion'] == 'failure'
assert aggregate['conclusion'] == 'failure' and measure['conclusion'] == 'skipped'
artifacts = read(OBS / 'fullcohort-artifacts.original.json')['artifacts']
artifact = next(a for a in artifacts if a['id'] == 11658738280)
assert artifact['size_in_bytes'] == 580
assert artifact['digest'] == 'sha256:716be1cef60ff03736583ca7bca4dd75be435c44fc6936aa801df6cf57a4f32b'
assert not any(a['name'].startswith('p8-scale-wide-dirty-shard-100000-') for a in artifacts)
request_path = LOGS / '114100438875-original-log-request-result.json'
request = read(request_path)
assert request['original_result']['value']['isError'] is True
assert '404' in request['original_result']['value']['structuredContent']['error']
assert 'BlobNotFound' in request['original_result']['value']['structuredContent']['error']
report = {
    'schema': 'r40-original-failed-fullcohort-terminal-independent-review-v1',
    'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer': '/root/pr_triage',
    'status': 'accepted_original_failure_evidence_not_a_passed_matrix',
    'apply_now': False,
    'source': '9cc6bf49f6dd81e4069a8004eed49addba0ab79b',
    'source_tree': '6461938788665701cfa4fa095a064a3a404ec492',
    'run_id': 38013753078, 'attempt': 1,
    'profile': 'scale_wide_dirty_v1',
    'original_artifact': artifact,
    'original_zip_read': read(OUT / 'original-ZIP-transport-and-member-manifest.json'),
    'zip_read_boundary': 'Original new 580-byte ZIP was opened/read once by this peer. ZipFile.read verified the sole member CRC while extracting matrix.json. This analysis reads the retained text only and does not reopen that ZIP.',
    'original_matrix': matrix,
    'missing_slots': {
        'count': len(missing), 'unique_count': len(set(missing)),
        'by_scale': dict(sorted(collections.Counter(scale for scale, rep in missing).items())),
        'exact_slots': missing, 'complement_in_registered_150': complement,
        'interpretation': 'Missing set is the 100k preflight rep0 plus every scale repetition1..29 (145 later planned cells). The official API represents the later matrix as one skipped measure placeholder job, not 145 separately observed failed jobs.',
    },
    'aggregate_execution': {
        'job_id': 114125450702, 'official_job': aggregate,
        'original_log': log_identity,
        'actual_checkout': '9cc6bf49f6dd81e4069a8004eed49addba0ab79b',
        'downloaded_by_original_job': {'build_artifacts': 1, 'shard_artifacts': 4},
        'original_function': 'p8_scale_matrix.aggregate',
        'original_arguments': {'repetitions': 30, 'shard_count': 30, 'capacity_profile': 'matrix.WIDE_DIRTY_PROFILE'},
        'result_status': 'failed', 'printed_sample_count': None, 'actual_shell_exit': 1,
        'failure_cause_proved': 'The aggregate rejected 146 missing registered matrix slots. Its error and nonzero exit agree with the preserved matrix.json.',
        'upload_failure_record': 'After the aggregation failure, the original job uploaded its one-file failed matrix result successfully: 580 bytes, exact official digest and artifact ID11658738280.',
        'complete_cohort_validation_credit': False,
        'exact_log_excerpts': selected,
        'warnings': [text for text in lines if 'Warning:' in text or '##[warning]' in text],
    },
    'hundred_k_failure_boundary': {
        'official_job': job100,
        'job_level': 'completed/failure',
        'step_api_inconsistency': 'The same official response leaves workload step7 in_progress with null conclusion/completed_at, and preservation step8 pending. Both are retained without inventing a terminal native stage.',
        'original_log_request': request,
        'root_cause': 'unknown',
        'native_exit_code': None, 'native_terminal_report': 'unavailable in received artifacts',
        'native_failed_phase': None,
        'not_inferred': ['deadline_exceeded', 'OOM', 'runner loss', 'worker signal', 'native exit3', 'parity failure', 'SQLITE_FULL', 'normal EOF'],
        'absence_boundary': 'No 100k measurement artifact appears in the complete 03:55 official index. The single original log request returned404 BlobNotFound. This does not establish why the original job failed or whether any recoverable bytes exist elsewhere.',
    },
    'retained_credit': {'previously_accepted_samples': 4, 'registered_samples': 150, 'previously_accepted_transitions': 41, 'registered_transitions': 1500, 'new_samples': 0, 'new_transitions': 0, 'later_planned_cells_skipped': 145, 'missing_matrix_slots': 146, 'old_four_shards_revalidated': False},
    'separation': 'Independent diagnostic run38012409915 is not pooled into this cohort, even though its source is9cc6. No diagnostic prefix substitutes for missing cohort slots or native terminal evidence.',
    'next_action_boundary': 'No product patch or recovery cause is justified by this aggregate alone. Preserve failure and absence. Any later root-authorized original evidence may refine the unknown cause; this review does not initiate a retry, new study or API recovery.',
    'operations': {'new_original_zip_read_count': 1, 'new_original_log_downloads': 0, 'api_calls': 0, 'validate_build_calls': 0, 'validate_shard_calls': 0, 'aggregate_reruns': 0, 'product_runs': 0, 'ref_or_pr_or_label_mutations': 0, 'task_credit': 0},
    'complete_0355_observations_in_support': [p.name for p in sorted(OBS.glob('*.json'))],
}
destination = OUT / 'independent-original-fullcohort-terminal-review.json'
destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': identity(destination), 'missing_slots': 146, 'actual_aggregate_exit': 1, 'hundred_k_native_cause': 'unknown', 'new_credit': 0}))
