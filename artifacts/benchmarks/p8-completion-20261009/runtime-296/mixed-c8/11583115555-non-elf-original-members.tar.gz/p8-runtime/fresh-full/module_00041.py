def stable_00041():
    return 41
