import pathlib,json,hashlib,zipfile,re,datetime
R=pathlib.Path('/workspace/scratch/bfccb8494ba0/root-round13/native-transfer')
E=R/'extracted'; O=pathlib.Path(__file__).parent
def H(b):return hashlib.sha256(b).hexdigest()
def B(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def file_check(root,record):
    p=root/record['path'];b=p.read_bytes();assert len(b)==record['bytes'] and H(b)==record['sha256'],p;return b
transport=load(R/'transport-receipt.json');z=R/'native-public-dependency-fix-red-green-and-controls.zip';raw=z.read_bytes()
assert len(raw)==2466963 and H(raw)=='cfd396fd6eeb50724f0bac091abc955281741a712dcd846e33e706e3e893e840' and B(raw)=='e7a90bc40e19ceda0c37fded58b902376d6d13fc'
manifest=load(E/'native-evidence-selection.json');assert len(manifest['files'])==62
with zipfile.ZipFile(z) as archive:
    assert len(archive.infolist())==63 and archive.testzip() is None
    for rec in manifest['files']:
        b=file_check(E,rec);assert archive.read(rec['path'])==b
base=load(E/'before-domain-receipt.json');assert len(base['entries'])==1242
bm={x['path']:x for x in base['entries']};assert len(bm)==1242
assert base['source']=='3ffcefc3b28ee1a4ed80caecebd7208a45c3e302'
inv=load(pathlib.Path('/dev/shm/execution-recon-bfcc/pr180181/inventory-audit.json'))['inventories']['180']
for x in inv['product']:
    y=bm[x['path']];assert y['mode']==x['mode'] and y['git_blob']==x['sha'] and y['sha256']==x['sha256'] and y['bytes']==x['size']
for p,h in inv['validation'].items():assert bm[p]['sha256']==h
test='crates/cc-db/tests/p2b_resolution_store.rs';prod=['crates/cc-db/src/index_db_write_batch.rs','crates/cc-db/src/snapshot_write_txn.rs']
v1=load(pathlib.Path('/dev/shm/todo-audit-pr180-public-dependency-fix/source-manifest.json'))
v2=load(pathlib.Path('/dev/shm/todo-audit-pr180-public-dependency-fix-v2/source-manifest.json'))
mods1={x['path']:{'path':x['path'],**x['after']}for x in v1['modified_files']};mods2={x['path']:{'path':x['path'],**x['after']}for x in v2['modified_files']}
red=dict(bm);red[test]=mods1[test]
green={**bm,**mods1}
extra=load(E/'v2-complete-additional-inputs.json')['additional_compile_inputs'];assert len(extra)==2
green2={**bm,**mods2,**{x['path']:x for x in extra}};assert len(green2)==1244
cases=[('red-public-catch-commit',101,red,0,1),('green-public-catch-commit',0,green,1,0),('resolution-store-suite',0,green,7,0),('snapshot-binder-dependency-unit',0,green,14,0),('snapshot-leaf-owner-control',0,green,6,0),('workspace-format',1,green,None,None),('resolution-store-suite-v2',0,green2,7,0),('snapshot-binder-dependency-unit-v2',0,green2,14,0),('snapshot-leaf-owner-control-v2',0,green2,6,0),('workspace-format-v2',0,green2,None,None),('cc-db-strict-clippy-v2',0,green2,None,None)]
results=[]
for label,code,expected,passed,failed in cases:
    p=E/(label+'-receipt.json');rec=load(p);assert rec['exit_code']==code and rec['source_G']==base['source']
    streams={k:file_check(E,rec[k]) for k in ['stdout','stderr']}
    states={}
    for side in ['before','after']:
        b=file_check(E,rec[side]);ss=json.loads(b);states[side]={x['path']:x for x in ss['rows']}
        assert states[side]==expected and rec[side]['entries']==len(expected),(label,side)
    assert states['before']==states['after']
    text=streams['stdout'].decode();summaries=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    if passed is not None:
        assert len(summaries)==1 and tuple(map(int,summaries[0][1:]))==(passed,failed,0),(label,summaries)
        names=re.findall(r'^test (\S+) \.\.\. (ok|FAILED)$',text,re.M)
        assert len(names)==passed+failed and len({n for n,v in names})==len(names)
    else:names=[]
    results.append({'label':label,'command':rec['command'],'exit_code':code,'started_at':rec['started_at'],'ended_at':rec['ended_at'],'input_count':len(expected),'before_after_rows_equal':True,'test_names_and_statuses':names,'passed':passed,'failed':failed,'ignored':0 if passed is not None else None,'receipt_bytes':p.stat().st_size,'receipt_sha256':H(p.read_bytes()),'stdout':rec['stdout'],'stderr':rec['stderr']})
assert not (E/'cc-db-strict-clippy-receipt.json').exists()
rs=(E/'red-public-catch-commit.stderr').read_text();assert 'Finished `test` profile' in rs and 'Running tests/p2b_resolution_store.rs' in rs
left=json.loads(re.search(r'^\s*left: (\[.*\])$',rs,re.M).group(1));right=json.loads(re.search(r'^\s*right: (\[.*\])$',rs,re.M).group(1))
assert left==[f'key-{n:05}'for n in range(64)] and right==[f'key-{n:05}'for n in range(70)]
fmtout=(E/'workspace-format.stdout').read_text();fmterr=(E/'workspace-format.stderr').read_text()
assert 'let path = directory.path().join' in fmtout and 'current-status-under-test.rs' in fmterr and 'No such file or directory' in fmterr
assert 'Finished `dev` profile' in (E/'cc-db-strict-clippy-v2.stderr').read_text()
assert results[-1]['command'][-3:]==['--','-D','warnings'] and '-p' in results[-1]['command'] and 'cc-db' in results[-1]['command']
controllers=[]
for name in ['red.py','green.py','controls.py','controls-v2.py','package.py','native-preparation-tool-observations.json']:
    p=R/'controllers'/name;controllers.append({'path':str(p),'bytes':p.stat().st_size,'sha256':H(p.read_bytes())})
out={'schema_version':1,'reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'accepted_scoped_actual_Rust_RED_GREEN_and_controls','scope':'Independent read-only review of retained actual native receipts and logs; no test rerun','transport':transport,'archive_members':63,'manifest_members_verified':62,'baseline_G':base['source'],'source_evidence':{'product1092_all_mode_blob_bytes_sha_match_independently_verified_official_PR180_map':True,'validation139_all_sha_match_independently_verified_PR180_map':True,'baseline1242_includes_11_additional_inputs':[x for p,x in bm.items() if p not in {i['path']for i in inv['product']}|set(inv['validation'])],'red_actual_source':'G3ff execution domain plus v1 new test only; two production files remain exact3ff','green_actual_source':'G3ff execution domain plus same v1 test and exactly two reviewed production changes','v2_actual_source':'same two production changes, exact whitespace-only v2 test, plus two original artifact compile inputs restored for workspace formatting','v1_inputs':1242,'v2_inputs':1244,'v2_additional_original_inputs':extra,'all_command_before_after_rows_equal':True,'whole_repository_checkout_claim':False},'red_assertion':{'compiled_and_ran':True,'left_count':len(left),'right_count':len(right),'actual_failure':'exact new public catch/commit regression fails64 versus70; not build or preparation failure','exit_code':101},'commands':results,'preserved_failures':{'v1_format_exit_code':1,'v1_format_stdout':'actual test formatting difference','v1_format_stderr':'actual missing current-status-under-test.rs #[path] input; subsequent recovery enumerated both original artifact module inputs','v1_strict_clippy':'not run after formatting failure, not marked passed'},'controllers_read_and_hashed':controllers,'limits':['Actual /Users/jin/.cargo/bin/cargo +1.95.0 and SDK15.4, ordinary cached APFS-cloned target; no cold-build or performance credit.','V2 strict Clippy is cc-db --all-targets -D warnings, not workspace Clippy. Workspace formatting actually passed.','The 7+14+6 controls are targeted suites, not an unfiltered workspace test run. Each v1/v2 suite has0ignored; unrelated tests are filtered by the disclosed commands.','No P/R/G/remote-head or formal-scale credit: these are uncommitted source combinations. Gc8 primary study source and samples are unchanged.','Neither historical SQL-only control nor any old3ff/Gc8 CI is substituted for these actual native receipts.']}
(O/'independent-execution-review.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'verdict':out['verdict'],'commands':len(results),'v1_control_passes':27,'v2_control_passes':27,'red':101,'green':0,'v1_fmt':1,'v2_fmt':0,'v2_cc_db_clippy':0,'input_counts':[1242,1244]},indent=2))
