#!/usr/bin/env python3
"""Package selected immutable round21 evidence only. No network or product execution."""
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import stat
import zlib
import zipfile

B = Path(__file__).resolve().parent
OUT = B / 'sealed-attempt01'

def sha(v): return hashlib.sha256(v).hexdigest()
def blob(v): return hashlib.sha1(b'blob '+str(len(v)).encode()+b'\0'+v).hexdigest()
def write(p, value): p.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')
def read(p): return json.loads(Path(p).read_bytes())
def facts(path):
    path=Path(path); s=path.lstat()
    if not stat.S_ISREG(s.st_mode): raise ValueError('Selected input is not a regular file: '+str(path))
    raw=path.read_bytes()
    return {'bytes':len(raw),'sha256':sha(raw),'git_blob':blob(raw),'posix_mode':oct(stat.S_IMODE(s.st_mode)),'source_mtime_ns':s.st_mtime_ns},raw
def main():
    assert not OUT.exists(), 'Never overwrite a frozen or failed output'
    OUT.mkdir()
    config=read(B/'package-inputs.json')
    members={};sources={};dedup=[];selection_summary=[]
    def add(path, origin, expected=None):
        path=Path(path)
        assert path.is_absolute() and '..' not in path.parts
        relative=path.relative_to('/dev/shm').as_posix()
        name='originals/'+relative
        f,raw=facts(path)
        if expected:
            assert f['bytes']==expected['bytes'] and f['sha256']==expected['sha256'], str(path)
            if expected.get('git_blob'): assert f['git_blob']==expected['git_blob'],str(path)
            mode=expected.get('posix_mode',expected.get('mode'))
            if mode: assert int(mode,8)&0o7777==int(f['posix_mode'],8),str(path)
        if name in members:
            assert members[name]['facts']==f and members[name]['data']==raw,'Conflicting member duplicate'
            members[name]['origins'].append(origin)
            dedup.append({'member':name,'origin':origin,'sha256':f['sha256']})
        else: members[name]={'facts':f,'data':raw,'source_path':str(path),'origins':[origin]}
        sources[str(path)]=f
        return name
    for item in config['selections']:
        p=Path(item['path']);f,raw=facts(p)
        assert len(raw)==item['bytes'] and sha(raw)==item['sha256']
        selected=json.loads(raw); rows=selected.get('entries',selected.get('files'))
        assert isinstance(rows,list) and len(rows)==item['expected_entry_count']
        declared=selected.get('file_count',selected.get('count',len(rows)))
        assert declared==len(rows)
        declared_bytes=selected.get('total_bytes',selected.get('bytes'))
        if declared_bytes is not None: assert declared_bytes==sum(r['bytes'] for r in rows)
        names=[]
        for row in rows:
            names.append(add(row.get('path',row.get('local_path')),{'selection':str(p),'label':item['label'],'declared_entry':row},row))
        selection_name=add(p,{'kind':'original_selection','label':item['label']},item)
        selection_summary.append({**item,'selection_member':selection_name,'members':names,'all_declared_entries_present':True})
    root=Path(config['root_directory']);root_files=sorted(root.glob('*.json'))
    assert root_files and all(p.is_file() for p in root_files)
    root_names=[add(p,{'kind':'root_original_json','selected_glob':'/dev/shm/root-round21/*.json'}) for p in root_files]
    add(config['additional_readonly_peer'],{'kind':'original_dispatch_adapter_static_peer','boundary':'Original dispatch-only peer remains historical; later label-event one-line correction retained separately'})
    closeout_raw=(root/'round21-formal-closeout.json').read_bytes();closeout=json.loads(closeout_raw)
    assert closeout['round']==21 and closeout['status']=='closed' and closeout['closed_at_utc']=='2026-10-09 16:56:16 UTC'
    assert closeout['original_tasks']['remaining']==29 and closeout['original_tasks']['newly_completed_this_round']==0
    assert closeout['implementation']['guard']=='4fe927488d5cb7f26bd27c7624745fb1b6ca202b'
    assert closeout['selected_acceptance_paths'][1]['run']==37962416564 and closeout['selected_acceptance_paths'][1]['initial_status']=='queued'
    (OUT/'round21-formal-closeout.json').write_bytes(closeout_raw)
    installed=read(root/'R8B-created-objects-original.json')['upload_manifest']['files']
    assert len(installed)==6
    locators={'scope':'Already durable R8 artifact leaves; not duplicated in this selected checkpoint ZIP','commit':'cb57d6e39f446e68ed5bd5bce26a7a76d1a26e5c','items':[]}
    for row in installed:
        locators['items'].append({k:row[k] for k in ['repository_path','mode','bytes','sha256','git_blob']} | {'url':'https://github.com/jyqj/codecortex/blob/cb57d6e39f446e68ed5bd5bce26a7a76d1a26e5c/'+row['repository_path']})
    summary={'schema_version':1,'artifact_scope':'Complete selected evidence, not complete original study archives','round':21,'status':'closed','closed_at_utc':closeout['closed_at_utc'],'next_round':22,'next_round_status':'in_progress','original_tasks':closeout['original_tasks'],'implementation':closeout['implementation'],'pr180_external_merge':closeout['pr180'],'selected_acceptance_paths':closeout['selected_acceptance_paths'],'not_selected':closeout['not_selected'],'preserved_failures':closeout['preserved_failures'],'observation_policy':'Every source file and null/pending template is retained at its own original time. The 37962416564 attempt1 build was queued at the recorded initial observation; no later state is inferred.','retained_selections':selection_summary,'root_json_members':root_names,'deduplicated_member_references':dedup,'included_original_regular_file_count':len(members),'already_durable_R8_six_artifacts':locators,'known_checkpoint_parent_only_not_a_publish_lease':config['known_checkpoint_parent_only_not_a_lease'],'remote_write':False,'new_tests_or_validator_or_measurements':False}
    write(OUT/'round21-summary.json',summary)
    readme='''# Round 21 selected checkpoint

Round 21 closed at 2026-10-09 16:56:16 UTC with **0 newly completed original tasks and 29 remaining**. Round 22 is active. This ZIP preserves the complete selected small evidence and all original selection manifests, not the full original study ZIPs, executables or raw RPC/database corpora.

PR180 was merged externally at 16:42:18 UTC into main 23eab8a7ea1fdfd6333c2e5a001cfb41e2a10d69; its tree equaled the reviewed G6 head. The new six-path candidate is P44e62481/Rcb57d6e3/G4fe92748 in PR193. G8 ordinary CI and the newly triggered full-stage study have their own identities. The original study 37962416564 attempt 1 was queued at the retained initial observation; no sample completion is implied here.

The accepted execution choice is independent cold source044c/run37954851017 for P8-005 and the new G8 original sequential scale_capacity_v1 study for P8-006. Their samples and source identities stay separate. PR192 fresh-profile alternative is not an additional mandatory study. Neither source-only review, compilation, partial parity nor a successful prefix closes a task. Original failed Gc8/C3ff cohorts remain failed/incomplete. Current templates retain their original null and pending fields.

`round21-member-index.json` lists every ZIP member with exact SHA256, Git blob, bytes, CRC32 and POSIX mode, and records the original source path and source-selection references. Deduplication uses a deterministic member path plus exact bytes/hash/mode; each declared selected file must be represented. A repeated reference is not a missing file. Original source files were rehashed after sealing. No source, task, branch, workflow or original evidence was modified.

The six large artifact leaves already installed in R8—including unchanged R7 support and both finite diagnostic result archives—are linked with their exact Git/SHA identities in the summary and `bundle/already-durable-R8-locators.json`, not nested again. This package does not create a new canonical source review or measurement result. Root must freshly check the checkpoint ref before publishing; 6aab5a4a225f17653fa56097ea610fc71ba3e7e6 is only the last known parent.
'''
    (OUT/'README.md').write_text(readme)
    def extra(name,raw,origin):
        assert name not in members
        members[name]={'facts':{'bytes':len(raw),'sha256':sha(raw),'git_blob':blob(raw),'posix_mode':'0o644','source_mtime_ns':None},'data':raw,'source_path':None,'origins':[origin]}
    extra('bundle/README.md',(OUT/'README.md').read_bytes(),{'kind':'packaging_context'})
    extra('bundle/round21-summary.json',(OUT/'round21-summary.json').read_bytes(),{'kind':'packaging_index_summary'})
    extra('bundle/already-durable-R8-locators.json',(json.dumps(locators,indent=2,sort_keys=True)+'\n').encode(),{'kind':'immutable_large_artifact_locators'})
    for name in ['package-checkpoint.py','run-package-once.py','package-inputs.json']:
        extra('bundle/'+name,(B/name).read_bytes(),{'kind':'packaging_procedure_only'})
    zip_path=OUT/'round21-selected-evidence.zip'
    with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as z:
        for name,item in sorted(members.items()):
            posix=PurePosixPath(name)
            assert not posix.is_absolute() and '..' not in posix.parts and '\\' not in name
            info=zipfile.ZipInfo(name,(2026,10,9,16,56,16));info.create_system=3
            info.external_attr=(stat.S_IFREG|int(item['facts']['posix_mode'],8))<<16
            info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,item['data'],compresslevel=9)
    index=[]
    with zipfile.ZipFile(zip_path) as z:
        assert z.testzip() is None and len(z.infolist())==len(members)
        assert len(set(z.namelist()))==len(members) and set(z.namelist())==set(members)
        for info in z.infolist():
            item=members[info.filename];raw=z.read(info);f=item['facts']
            assert len(raw)==f['bytes'] and sha(raw)==f['sha256'] and blob(raw)==f['git_blob']
            assert info.CRC==zlib.crc32(raw)&0xffffffff
            assert stat.S_IMODE(info.external_attr>>16)==int(f['posix_mode'],8)
            index.append({'member':info.filename,**f,'crc32':f'{info.CRC:08x}','compressed_bytes':info.compress_size,'compression':info.compress_type,'source_path':item['source_path'],'origins':item['origins']})
    for path,expected in sources.items():
        current,_=facts(path);assert current==expected,'Original source changed: '+path
    assert [str(p) for p in sorted(root.glob('*.json'))]==[str(p) for p in root_files], 'Root source glob changed; do not claim complete snapshot'
    raw=zip_path.read_bytes()
    index_object={'schema_version':1,'archive':{'local_path':str(zip_path),'bytes':len(raw),'sha256':sha(raw),'git_blob':blob(raw)},'member_count':len(index),'member_uncompressed_bytes':sum(x['bytes'] for x in index),'selected_source_file_count':len(sources),'selection_count':len(selection_summary),'root_json_count':len(root_files),'deduplicated_references':dedup,'CRC_and_every_member_SHA_and_mode_verified':True,'all_selected_sources_unchanged_after':True,'no_missing_declared_selected_files':True,'members':index}
    write(OUT/'round21-member-index.json',index_object)
    print(json.dumps({k:index_object[k] for k in ['archive','member_count','member_uncompressed_bytes','selected_source_file_count','selection_count','root_json_count','CRC_and_every_member_SHA_and_mode_verified','all_selected_sources_unchanged_after','no_missing_declared_selected_files']},sort_keys=True))

if __name__=='__main__':main()
