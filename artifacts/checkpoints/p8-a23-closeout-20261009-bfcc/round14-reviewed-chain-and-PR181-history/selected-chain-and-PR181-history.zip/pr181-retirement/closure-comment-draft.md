建议将 #181 作为产品推进已汇入 #180 的重复草稿关闭，保留 task/p8-empty-input-preparation-50c-20261009 分支及全部提交、工件、历史运行。本结论针对实际 head 27e60348f01d16298dd4d28f48dd1e2d47ee687c，不沿用旧 4866 的审查时态，也不表示 #181 已整体合并进 main。

对照 #180 head 1d39f382d4e08e702a55693c9c614fa477bf7e0c 及实际 P c92eb5ac7ece70d1f62271d7e2dacac513c285b5：interface_dispatch.rs、interface_dispatch_tests.rs、full_snapshot_empty_config.rs 的 Git blobs 完全相同；snapshot.rs 的空 token 延迟准备实现亦完整保留，唯一差异是整合源保留 write_file_data_for_rebuild 调用，以保留其已有 FTS 重建实现。当前 #181 无尚未保留的新产品改动。

关闭只收束重复产品入口。B4 的协调、更正及任务记录、P2/P3/G3 的原失败和实际执行收据、G275/Gc8 各自验收原件及 source-specific 来源均继续由原分支/固定提交保留，不改标为 #180/c92e 运行，也不取消或重跑研究。原完整同源规模研究、当前组合回归和硬依赖仍待各自真实验收；P8-007 的实际混合路径 DB lock acquisition wait 窄缺口仍然开放，已有 availability probe 不替代它。163 done /29 remaining，本次关闭不记 TODO 完成。
