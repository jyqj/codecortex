def stable_00328():
    return 328
