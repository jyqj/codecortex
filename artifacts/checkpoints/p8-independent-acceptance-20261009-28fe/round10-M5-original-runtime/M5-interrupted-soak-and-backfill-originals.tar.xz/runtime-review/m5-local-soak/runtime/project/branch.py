def branch_signal():
    return 2
