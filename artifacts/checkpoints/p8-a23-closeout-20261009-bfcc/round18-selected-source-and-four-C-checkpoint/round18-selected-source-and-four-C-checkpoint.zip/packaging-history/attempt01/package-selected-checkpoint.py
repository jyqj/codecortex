#!/usr/bin/env python3
"""Package existing selected evidence only. No network, git, subprocess or imports of project code."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import zipfile
import zlib

ROOT = Path(__file__).resolve().parent
SELECTIONS = [
    ('G2-four-C', '/dev/shm/pr-triage-G2-db-lock-cohort-37930392164/complete-four-C-cohort/archive-selection.json', '662e06bf4da2351febeba1630653204f7335fbd1d1831691cbf4960999222840'),
    ('PR188-and-H-MSRV', '/dev/shm/execution-recon-recovery-20261009/round17-PR188-thin-and-H-MSRV-archive-selection.json', '12dcac03c8ab8e46804f2e572419863ce4868400a35fc7c83b9b6217a5ec547d'),
    ('original-ten-critical-path', '/dev/shm/todo-audit-round17-original-ten-critical-path/archive-selection.json', 'c3780b7829b8e77dc095096d5072ec12cfbf64bb98670bbb5ca6b22e73b0a390'),
    ('G3-binding-generation', '/dev/shm/todo-audit-G3-4ec7543d-binding/archive-selection.json', '819a96f18b9e6e25aaca5963eb513f9b45c42255cdf2199c96ef623b8b2fd21d'),
    ('b2-G3-forward-plan', '/dev/shm/todo-audit-b2-G3-forward-plan/archive-selection.json', '5a79689b4a45e2a0d1f48cd3043ed47f0ba39c72376c70c2fd95c4bf10f6bc60'),
]

def raw_json(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def git_oid(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def safe_member(name):
    p = PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or str(p) != name or '\\' in name or not name:
        raise ValueError('unsafe or non-canonical member: ' + name)
    return name

def read_regular(path):
    path = Path(path)
    st = path.lstat()
    if not stat.S_ISREG(st.st_mode):
        raise ValueError('only exact regular selected files supported: ' + str(path))
    raw = path.read_bytes()
    after = path.lstat()
    if (st.st_ino, st.st_dev, st.st_size, st.st_mtime_ns, st.st_mode) != (after.st_ino, after.st_dev, after.st_size, after.st_mtime_ns, after.st_mode):
        raise ValueError('selected source changed while reading: ' + str(path))
    return raw, st

def member_for(key, item):
    if 'repository_path' in item:
        return safe_member('selected-repository/' + item['repository_path'])
    if key == 'b2-G3-forward-plan':
        return safe_member('reviews/todo-audit/b2-G3-forward-plan/' + item['relative_path'])
    owner = 'execution-recon' if key == 'PR188-and-H-MSRV' else 'todo-audit'
    return safe_member('reviews/' + owner + '/' + item['archive_path'])

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--peer-config', required=True, help='JSON listing exact completed four-C peer original file(s), each with path/member/bytes/sha256; no placeholders')
    parser.add_argument('--output-name', required=True)
    args = parser.parse_args()
    out = ROOT / args.output_name
    if out.parent != ROOT or out.exists():
        raise ValueError('fresh direct-child output required')
    out.mkdir()
    receipt = {'scope': 'selected evidence packaging only, not measurement/source validation', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'success': False, 'actual_exit_code': None}
    try:
        peer_raw, _ = read_regular(args.peer_config)
        peer_config = json.loads(peer_raw)
        if peer_config.get('complete_final_peer_received') is not True or not peer_config.get('files'):
            raise ValueError('actual final peer receipt required before final packaging')
        selected, selections, duplicate_refs = {}, [], []
        def include(path, member, provenance, expected=None):
            member = safe_member(member)
            raw, st = read_regular(path)
            if raw.startswith(b'\x7fELF') or str(path).endswith('.zip'):
                raise ValueError('unselected large original ZIP/ELF is outside this package: ' + str(path))
            sha = digest(raw)
            mode = stat.S_IMODE(st.st_mode)
            if expected:
                if len(raw) != expected['bytes'] or sha != expected['sha256']:
                    raise ValueError('selected byte/hash mismatch: ' + str(path))
                if expected.get('git_blob') and git_oid(raw) != expected['git_blob']:
                    raise ValueError('selected Git blob mismatch: ' + str(path))
                if expected.get('mode'):
                    declared = int(str(expected['mode']), 8) & 0o7777
                    if declared != mode: raise ValueError('selected mode mismatch: ' + str(path))
            row = {'member': member, 'source_path': str(path), 'bytes': len(raw), 'sha256': sha, 'git_blob': git_oid(raw), 'mode': f'{mode:04o}', 'source_stat_mode': st.st_mode, 'source_mtime_ns': st.st_mtime_ns, 'crc32_hex': f'{zlib.crc32(raw) & 0xffffffff:08x}', 'provenance': [provenance]}
            if member in selected:
                old = selected[member]
                if any(old[k] != row[k] for k in ['bytes', 'sha256', 'mode', 'git_blob']):
                    raise ValueError('conflicting duplicate member: ' + member)
                old['provenance'].append(provenance)
                duplicate_refs.append({'member': member, 'sha256': sha, 'source_path': str(path), 'provenance': provenance})
            else: selected[member] = row
            return raw
        for key, path, expected_sha in SELECTIONS:
            raw = include(path, 'selections/' + key + '.json', {'kind': 'input_selection', 'key': key})
            if digest(raw) != expected_sha: raise ValueError('frozen selection changed: ' + path)
            value = json.loads(raw)
            if value['file_count'] != len(value['files']): raise ValueError('selection count mismatch')
            if value['total_bytes'] != sum(x['bytes'] for x in value['files']): raise ValueError('selection byte-total mismatch')
            for idx, item in enumerate(value['files']):
                include(item.get('local_path', item.get('path')), member_for(key, item), {'kind': 'selected_file', 'selection_key': key, 'selection_entry_index': idx}, item)
            selections.append({'key': key, 'original_path': path, 'sha256': digest(raw), 'bytes': len(raw), 'declared_file_count': value['file_count'], 'all_selected_entries_present_and_verified': True})
        for name in ['P3-create-commit-original', 'R3-create-commit-original', 'G3-create-commit-original', 'PR188-create-original']:
            path = Path('/dev/shm/root-round17') / (name + '.json')
            include(path, 'root-official-objects/' + path.name, {'kind': 'root_official_original'})
        for item in peer_config['files']:
            include(item['path'], 'reviews/execution-recon/complete-four-C-peer/' + item['member'], {'kind': 'complete_four_C_independent_peer'}, item)
        include(args.peer_config, 'selections/complete-four-C-peer-binding.json', {'kind': 'peer_binding_config'})
        include(__file__, 'packaging/package-selected-checkpoint.py', {'kind': 'packaging_controller_not_product_code'})
        triage = json.loads(Path(SELECTIONS[0][1]).read_bytes())
        complete_path = Path('/dev/shm/pr-triage-G2-db-lock-cohort-37930392164/complete-four-C-cohort/complete-G2-four-C-independent-review.json')
        cohort = json.loads(complete_path.read_bytes())
        assert cohort['source_G'] == '4d18dcdb34b5d7a277566b57801cc882d8b1eb61'
        assert cohort['complete_Cs'] == [1, 4, 8, 16] and cohort['missing_Cs'] == []
        assert cohort['per_C_denominator'] == 900 and cohort['total_original_operations'] == 3600
        summary = {
            'schema': 'round18-selected-evidence-checkpoint-v1',
            'archive_scope': 'selected evidence, not full original ZIP archive',
            'round17': {'status': 'ended', 'new_original_TODO_completed': 0, 'remaining_original_TODO': 29},
            'round18': {'status': 'in_progress', 'new_original_TODO_completed': 0, 'remaining_original_TODO': 29},
            'ledger': {'total': 192, 'done': 163, 'remaining': 29, 'mutated_by_packaging': False},
            'G2_four_C': {'source': cohort['source_G'], 'tree': cohort['source_tree'], 'product': cohort['product_P'], 'review': cohort['review_R'], 'run_id': cohort['run_id'], 'run_attempt': cohort['run_attempt'], 'actual_Cs': cohort['complete_Cs'], 'operations_each': 900, 'operations_total': 3600, 'original_collector_integer_exits': {'C1': 0, 'C4': 0, 'C8': 0, 'C16': 0}, 'distributions_pooled': False, 'review_verdict': cohort['verdict'], 'peer': peer_config['conclusion'], 'scope': 'separate original G2 diagnostic source; not G3/main/Gc8 performance'},
            'PR188': {'source_G3': '67b7f4ee15a9c9633868b446870fec1358dda3d9', 'source_tree': 'e7a7f5a685c44aee34b8716377308f0af8782fdd', 'CI_scope': 'initial official observation pending; no new claim beyond retained evidence', 'engineering_execution': 'awaiting actual original CI; source-only R3 keeps not_run'},
            'H_MSRV': 'separate exact H source check success retained; not G3 execution',
            'P8_005_006': 'full scale evidence blockers unresolved; no new 150-job study started by this checkpoint',
            'historical_records': 'pending and raw preparation/metadata failures preserved byte-for-byte; later acceptance is append-only',
            'excluded_originals': triage['outside_selection_originals'],
            'exclusions': ['large original G2 ZIP bodies', 'ELF executables', 'full product RPC streams', 'unselected authored fixtures'],
            'full_raw_operation_JSONL_included': True,
            'no_product_test_measurement_network_or_remote_mutation': True,
            'input_selections': selections,
            'deduplication': 'same canonical bundle member path AND bytes/hash/mode only; different original paths with equal hashes remain separate',
            'duplicate_reference_count': len(duplicate_refs),
            'selected_original_file_count_including_selections_and_controllers': len(selected),
        }
        readme = '''# Round 18 selected evidence checkpoint\n\nThis ZIP contains selected frozen evidence, not the complete original G2 artifact ZIPs. All input-selection entries are included and verified; no missing selected member is silently dropped. The four original raw operation JSONL files are included, but ELF files, complete RPC streams and large original ZIP bodies remain at the exact official locators and SHA256 identities in checkpoint-summary.json and the original selections.\n\nRound 17 ended with 0 new original TODO completions and 29 remaining. Round 18 is in progress; the ledger stays 192 total / 163 done / 29 remaining. Original fixed G2 4d18 has C1/C4/C8/C16, each with 900 outcomes and original collector exit 0. Their source, source review, feature artifacts, windows and distributions remain separate from Gc8, G1, H, main and SQL G3. P8-005/P8-006 full-scale blockers remain unresolved. PR188 G3 67b7 remains pending in the retained initial CI evidence; no unobserved completion is inferred. The H-only MSRV success is not relabeled as G3 validation.\n\nHistorical pending snapshots and original failed preparation/metadata operations are retained unmodified. Later full-four-C acceptance and its non-author peer are appended. Packaging does not execute any source validator, Rust/Python product test, workload, network call or remote mutation.\n\nselected-file-manifest.json binds every selected original file, original selection entry, selected filesystem mode, SHA256, Git blob OID and CRC32. Distinct original records remain distinct even if bytes match. Duplicate canonical member paths are collapsed only if byte length, SHA256, Git OID and mode all match. ZIP external attributes preserve observed selected-file modes; this is not a claim that source artifact extraction preserved every original POSIX attribute. No symlink is followed by this packager.\n\nThe external zip-member-manifest.json covers every ZIP member, including this README, checkpoint-summary.json and selected-file-manifest.json. The external package-result.json and upload-metadata.json bind the completed whole ZIP, its exact Git blob OID and CRC verification. None of these reports constitutes an additional task gate or an original measurement.\n'''
        manifest = {'schema': 'selected-original-file-manifest-v1', 'file_count': len(selected), 'total_bytes': sum(x['bytes'] for x in selected.values()), 'files': list(sorted(selected.values(), key=lambda x: x['member'])), 'duplicate_references': duplicate_refs, 'input_selections': selections}
        generated = {'README.md': readme.encode(), 'checkpoint-summary.json': raw_json(summary), 'selected-file-manifest.json': raw_json(manifest)}
        for name, raw in generated.items(): (out / name).write_bytes(raw)
        zip_path = out / 'round18-selected-source-and-four-C-checkpoint.zip'
        with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as z:
            for member, row in sorted(selected.items()):
                raw, st = read_regular(row['source_path'])
                if len(raw) != row['bytes'] or digest(raw) != row['sha256'] or stat.S_IMODE(st.st_mode) != int(row['mode'], 8):
                    raise ValueError('source changed before ZIP write: ' + member)
                info = zipfile.ZipInfo(member, date_time=(1980, 1, 1, 0, 0, 0))
                info.create_system = 3; info.external_attr = (stat.S_IFREG | int(row['mode'], 8)) << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
            for name, raw in generated.items():
                info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0)); info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16; info.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        entries = []
        with zipfile.ZipFile(zip_path) as z:
            infos = z.infolist()
            if len(infos) != len({i.filename for i in infos}): raise ValueError('duplicate ZIP member')
            if set(z.namelist()) != set(selected) | set(generated): raise ValueError('ZIP membership mismatch')
            for info in infos:
                raw = z.read(info)
                expected_raw = generated.get(info.filename)
                if info.filename in selected:
                    row = selected[info.filename]
                    if digest(raw) != row['sha256'] or len(raw) != row['bytes'] or ((info.external_attr >> 16) & 0o7777) != int(row['mode'], 8): raise ValueError('ZIP selected payload/mode mismatch')
                elif raw != expected_raw: raise ValueError('generated member mismatch')
                if (zlib.crc32(raw) & 0xffffffff) != info.CRC: raise ValueError('CRC mismatch')
                entries.append({'member': info.filename, 'bytes': len(raw), 'compressed_bytes': info.compress_size, 'sha256': digest(raw), 'git_blob': git_oid(raw), 'crc32_hex': f'{info.CRC:08x}', 'mode': f'{(info.external_attr >> 16) & 0o7777:04o}'})
            if z.testzip() is not None: raise ValueError('ZIP CRC scan failed')
        for row in selected.values():
            raw, st = read_regular(row['source_path'])
            if len(raw) != row['bytes'] or digest(raw) != row['sha256'] or stat.S_IMODE(st.st_mode) != int(row['mode'], 8): raise ValueError('selected source changed after packaging')
        zip_raw = zip_path.read_bytes()
        zip_manifest = {'schema': 'complete-ZIP-member-manifest-v1', 'member_count': len(entries), 'member_bytes': sum(x['bytes'] for x in entries), 'ZIP': {'path': str(zip_path), 'bytes': len(zip_raw), 'sha256': digest(zip_raw), 'git_blob': git_oid(zip_raw)}, 'all_members_reopened_sha_crc_mode_verified': True, 'source_after_matches_before': True, 'entries': entries}
        (out / 'zip-member-manifest.json').write_bytes(raw_json(zip_manifest))
        receipt.update({'success': True, 'actual_exit_code': 0, 'ZIP': zip_manifest['ZIP'], 'ZIP_member_count': len(entries), 'all_selected_entries_present': True, 'source_after_matches_before': True, 'CRC_and_bytes_verified': True, 'selected_original_count': len(selected), 'duplicate_references': len(duplicate_refs), 'final_peer_included': True})
    except BaseException as error:
        receipt.update({'actual_exit_code': 1, 'error_type': type(error).__name__, 'error': str(error)})
        raise
    finally:
        receipt['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        (out / 'package-result.json').write_bytes(raw_json(receipt))
    upload = {'schema': 'root-local-upload-metadata-v1', 'remote_uploaded': False, 'expected_repository_prefix': 'artifacts/checkpoints/p8-a23-closeout-20261009-bfcc/round18-selected-source-and-four-C-checkpoint', 'files': []}
    for name in ['round18-selected-source-and-four-C-checkpoint.zip', 'zip-member-manifest.json', 'selected-file-manifest.json', 'README.md', 'checkpoint-summary.json', 'package-result.json']:
        raw = (out / name).read_bytes()
        upload['files'].append({'local_path': str(out / name), 'repository_filename': name, 'mode': '100644', 'bytes': len(raw), 'sha256': digest(raw), 'expected_git_blob': git_oid(raw)})
    (out / 'upload-metadata.json').write_bytes(raw_json(upload))
    print(json.dumps(receipt, sort_keys=True))

if __name__ == '__main__':
    main()
