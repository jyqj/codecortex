from pathlib import Path
import subprocess,json,hashlib,datetime,time,os,sys
root=Path.cwd()
base=root/'artifacts/benchmarks/p8-bfccb8494ba0'
out=base/'native-db-observation-combined-P1-bb29-evidence'
wt=base/'candidate-db-observation-combined-P1-bb29'
assert not wt.exists(),str(wt)
out.mkdir(exist_ok=False)
P='bb290be2deaf4334863e09dbf47fe4ccc9625f2b'
(out/'prepare-controller.py').write_bytes(Path(sys.argv[0]).read_bytes())
receipts=[]
def run(label,args,timeout=120,cwd=root):
 start=time.monotonic();sp=out/(label+'.stdout');ep=out/(label+'.stderr')
 r={'label':label,'argv':args,'cwd':str(cwd),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with sp.open('wb') as so,ep.open('wb') as se:
  p=subprocess.Popen(args,cwd=str(cwd),stdout=so,stderr=se);r['pid']=p.pid
  try: code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   p.kill();code=p.wait();r['controller_timeout_seconds']=timeout
 r.update(exit_code=code,elapsed_seconds=time.monotonic()-start,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
 for k,q in [('stdout',sp),('stderr',ep)]:
  b=q.read_bytes();r[k]={'path':q.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
  if b:print(label+' '+k+' '+b.decode(errors='replace')[-4000:],flush=True)
 receipts.append(r);(out/'preparation-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print(json.dumps(r),flush=True)
 if code:sys.exit(code if code>0 else 1)
 return sp.read_bytes()
run('parent-head-before',['/usr/bin/git','-c','core.commitGraph=false','rev-parse','HEAD'])
raw=run('actual-P-object',['/usr/bin/git','-c','core.commitGraph=false','cat-file','-p',P])
assert raw.startswith(b'tree 4dbe8ee3d09701c8563f42695b483ae104da0a2a\nparent 3ced45d1f4bbfc38eeab3fbe1a1ef17eae26721a\n')
run('create-detached-worktree',['/usr/bin/git','-c','core.commitGraph=false','worktree','add','--no-checkout','--detach',str(wt),P])
paths=['Cargo.lock','Cargo.toml','crates','scripts','.github','tests','artifacts/checkpoints/capability-snapshot-optimization-20261003/current-status-under-test.rs','artifacts/checkpoints/capability-snapshot-optimization-20261003/v2-status-checks.rs']
run('checkout-exact-inputs',['/usr/bin/git','-c','core.commitGraph=false','checkout',P,'--']+paths,timeout=180,cwd=wt)
inventory=run('official-domain-ls-tree',['/usr/bin/git','-c','core.commitGraph=false','ls-tree','-r','-z',P,'--']+paths,cwd=wt)
rows=[]
for entry in inventory.split(b'\0'):
 if not entry:continue
 left,name=entry.split(b'\t',1);mode,kind,oid=left.decode().split();name=name.decode();assert kind=='blob'
 p=wt/name;b=p.read_bytes();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 actualmode='100755' if p.stat().st_mode&0o111 else '100644'
 assert blob==oid and actualmode==mode,(name,blob,oid,actualmode,mode)
 rows.append({'path':name,'mode':mode,'git_blob':blob,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
receipt={'source_P':P,'tree':'4dbe8ee3d09701c8563f42695b483ae104da0a2a','ordered_parents':['3ced45d1f4bbfc38eeab3fbe1a1ef17eae26721a'],'scope_paths':paths,'entries':rows,'scope':'exact committed P selected Cargo/crates/scripts/.github/tests plus two original artifact Rust compile inputs; sparse selected-input checkout, not whole repository'}
b=(json.dumps(receipt,indent=2,sort_keys=True)+'\n').encode();(out/'before-domain-receipt.json').write_bytes(b)
print(json.dumps({'verified_entries':len(rows),'receipt_bytes':len(b),'receipt_sha256':hashlib.sha256(b).hexdigest(),'worktree':str(wt)}),flush=True)
after=run('parent-head-after',['/usr/bin/git','-c','core.commitGraph=false','rev-parse','HEAD'])
assert after==(out/'parent-head-before.stdout').read_bytes()
