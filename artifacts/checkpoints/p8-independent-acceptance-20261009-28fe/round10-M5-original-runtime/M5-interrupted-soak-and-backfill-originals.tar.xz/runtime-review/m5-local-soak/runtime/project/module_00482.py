def stable_00482():
    return 482
