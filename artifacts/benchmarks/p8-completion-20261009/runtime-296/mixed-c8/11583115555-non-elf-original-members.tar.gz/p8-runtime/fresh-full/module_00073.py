def stable_00073():
    return 73
