C3ff original 100k failure and the 15:27 UTC CI observation

This record preserves the terminal failure of source `3ffcefc3b28ee1a4ed80caecebd7208a45c3e302`, original run `37910924354`, attempt 1. Both original jobs checked out that exact source. The 100k native supervisor reached the registered 18,000,000 ms child-lifetime deadline, returned 3, retained worker exit `null`, incomplete stderr, and no worker summary. The shard driver and aggregate each exited 1. The follow-on measure branch was skipped.

The complete official 100k ZIP and aggregate ZIP are separate publication leaves. They retain all 13 original files, including the full 20,826,459-byte raw JSONL. This support ZIP does not nest or replace them. The selected unpacked JSON, stdout/stderr, all-member CRC/SHA receipts, official source drivers, full terminal job logs and reviewer receipts can be used with those complete original ZIPs.

The unchanged C3ff `validate_shard` rejected the original failed record at its first gate. Because rejection precedes access to its build-record and binary arguments, that limited replay did not claim to revalidate a release ELF. The unchanged `inspect_raw` traversed the complete retained raw and rejected missing registered mutation stages. A separate seal/source/plan integrity check passed. These are read-only validation results, not new benchmark runs.

The retained raw contains 1,002 build starts and 1,002 build finishes. Six completed parity records (cold, no-op, body, API, config and batch 1) each cover all 15 original tables. Batch 10 has completed incremental and full-control builds but no completed parity/stage record. Batch 100 and batch 1000 did not start. Partial completed records are not accepted samples from this failed shard. The previously reported C3ff coverage remains 4/150 shards and 41/1,500 samples; no source is pooled and no failure is replaced.

The G4 and M7F files are the single official observation at 15:27:05 UTC. At that observation G4's check was still in progress and M7F's aggregate run was queued while its check job was actually in progress. Later terminal evidence owned by root is separate. Step success in this historical observation is not presented as a terminal test-count or source-CLI audit.

The pending file-reference and intake-summary records remain unchanged as earlier observations. The final intake report records successful materialization and validation outcomes without overwriting them. Official execution clocks and local reviewer host clocks are distinct; original study durations use the official/native records.

Round 20: 0 newly completed original TODOs; 163 done and 29 remaining. This archive does not change source, thresholds, budgets, registered repetitions, or the failed study's conclusion.
