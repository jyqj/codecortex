def stable_00321():
    return 321
