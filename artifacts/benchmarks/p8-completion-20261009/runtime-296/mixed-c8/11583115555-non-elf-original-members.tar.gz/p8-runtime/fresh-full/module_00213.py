def stable_00213():
    return 213
