def stable_00037():
    return 37
