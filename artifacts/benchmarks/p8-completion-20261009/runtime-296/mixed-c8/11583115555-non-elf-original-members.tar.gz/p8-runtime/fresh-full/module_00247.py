def stable_00247():
    return 247
