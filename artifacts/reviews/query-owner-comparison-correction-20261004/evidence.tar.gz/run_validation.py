from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/workspace/owner-comparison-validation')
env=os.environ.copy()
env.update(PATH='/workspace/.cargo/bin:'+env['PATH'],CARGO_HOME='/workspace/.cargo',RUSTUP_HOME='/workspace/.rustup')
receipts=[]
def run(cmd,cwd,out,err=None,arm=None,expected=0):
    e=env.copy()
    if arm: e['CARGO_TARGET_DIR']=str(root/f'target-{arm}')
    with (root/out).open('w') as o:
        if err:
            with (root/err).open('w') as f: r=subprocess.run(cmd,cwd=cwd,env=e,stdout=o,stderr=f)
        else: r=subprocess.run(cmd,cwd=cwd,env=e,stdout=o,stderr=subprocess.STDOUT)
    receipts.append(dict(cmd=cmd,cwd=str(cwd),target_dir=e.get('CARGO_TARGET_DIR'),exit=r.returncode,stdout=out,stderr=err))
    (root/'execution.json').write_text(json.dumps(receipts,indent=2))
    assert r.returncode==expected,(cmd,r.returncode)
    print(out,'exit',r.returncode,flush=True)
for arm,cwd in [('correction',Path('/workspace/codecortex')),('base',Path('/workspace/owner-comparison-base')),('candidate',Path('/workspace/owner-comparison-candidate'))]:
    run(['cargo','+1.95.0','test','--locked','-p','cc-search','query_target','--lib','-j','2'],cwd,f'{arm}-tests.log',arm=arm)
    run(['cargo','+1.95.0','build','--locked','-p','cc-eval','--lib','-j','2','--message-format=json-render-diagnostics'],cwd,f'{arm}-artifacts.jsonl',f'{arm}-build.log',arm)
    rows=[json.loads(line) for line in (root/f'{arm}-artifacts.jsonl').read_text().splitlines() if line.startswith('{')]
    for name in ['cc_search','cc_server','cc_eval']:
        found=[r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']==name]
        assert len(found)==1 and not found[0]['fresh'],(arm,name,'production library must actually rebuild')
    run(['python3',str(root/'link_driver.py'),arm],cwd,f'{arm}-link-command.log')
    for variant in ['base','receiver','inversion']:
        run([str(root/f'driver-{arm}'),str(root/f'fixtures/{arm}-{variant}'),str(root/f'results/{arm}-{variant}'),variant],cwd,f'{arm}-{variant}-run.log')
