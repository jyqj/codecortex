import pathlib, json, hashlib, collections
D = pathlib.Path(__file__).resolve().parent
A = D / 'config-100000-0'
raw = A / 'original-shard/native-shard/native/raw.jsonl'
counts = collections.Counter()
records = []
for number, line in enumerate(raw.open('rb'), 1):
    d = json.loads(line)
    counts[d['event']] += 1
    r = {'line': number, 'original_line_bytes': len(line), 'original_line_sha256': hashlib.sha256(line).hexdigest(), 'event': d['event']}
    if d['event'] == 'mutation':
        ops = d['operations']
        r.update(label=d['label'], operations=len(ops), unique_paths=len({x['path'] for x in ops}), kinds=sorted({x['kind'] for x in ops}))
    elif d['event'] == 'build_finished' and not d['full']:
        r.update({k: d[k] for k in ['label','full','start_us','end_us','wall_us']})
        r['report_fields'] = {k: d['report'].get(k) for k in ['dirty_plan','files_parsed','files_updated','files_scanned','files_skipped','resolution_freshness','parse_errors','build_timing','phase_timing']}
    elif d['event'] == 'stage_finished':
        r.update({k: d.get(k) for k in ['label','complete','full_complete','incremental_builds','passed','independent_config_fact']})
        r['parity'] = {k:d['parity'].get(k) for k in ['equal','different_tables']}
    else:
        continue
    records.append(r)
inc = [r for r in records if r['event'] == 'build_finished']
prior_meta = json.loads((A/'shard-before.json').read_text())['native-shard/native/raw.jsonl']
result = json.loads((A/'original-validate-shard-return.json').read_text())
out = {'schema':'config-emitted-mutation-and-closure-facts-v1','scope':'Read-only extraction from newly accepted raw; no additional validator or measurement. Original raw unchanged in external whole ZIP.','raw':{'path':str(raw),**prior_meta},'event_counts':dict(counts),'observed_first_incomplete':not inc[0]['report_fields']['resolution_freshness']['complete'],'observed_incremental_builds':len(inc),'observed_subsequent_incremental_builds':len(inc)-1,'observed_resumed_true_reports':sum(r['report_fields']['dirty_plan']['resumed'] for r in inc),'observed_final_complete':inc[-1]['report_fields']['resolution_freshness']['complete'],'registered_plan':result['plan'],'records':records}
target=D/'original-config-mutation-closure-facts.json'
with target.open('x') as f: json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['records','registered_plan']}))
