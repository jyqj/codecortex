from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime
import hashlib
import json
import os
import subprocess
import threading
import time

ROOT = Path(__file__).resolve().parent
SOAK_ROOT = ROOT.parent / 'm5-local-soak'
SOURCE = SOAK_ROOT / 'source'
BUILD = SOAK_ROOT / 'build'
COMMIT = 'fec0698c7fa4d76076b828cc17cf277ad8b307e0'
RUNTIME_SHA256 = 'bc33ed073a2e035912a4d6f1794ceec8b836243c2bbb46c8a4dddfcdda791559'
BUILD_INPUTS = {
    'build-receipt.json': 'ea81dc31bfc10072b51fa98eb25474fc62fce9b86e15b38234317bbb482f29d0',
    'codecortex': '07803d0bbc79e00ad9500c16db0eeee25f4dcfa5541456d6e7a4f0225bd523f4',
    'p8-oracle': '4ed0d23e8a064e49cfb5b86677e1c28b0d8e75e853433e73c77bc9d39a4ac93a',
    'p8-runtime-statistics': 'a87422b6608b7c077cf84e411a6a83c82e1161243fafcf10ca498bcbaa98324d',
}
LOCK = threading.Lock()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identity():
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE).decode().strip()
    runtime = digest(SOURCE / 'scripts/p8_runtime.py')
    binaries = {name: digest(BUILD / name) for name in BUILD_INPUTS}
    if head != COMMIT or runtime != RUNTIME_SHA256 or binaries != BUILD_INPUTS:
        raise RuntimeError('Fixed M5 source, build receipt, or binary changed')
    return {'head': head, 'runtime_sha256': runtime, 'build_inputs': binaries}


def save():
    temporary = ROOT / 'execution-receipt.json.tmp'
    temporary.write_text(json.dumps(receipt, indent=2) + '\n')
    temporary.replace(ROOT / 'execution-receipt.json')


if (ROOT / 'execution-receipt.json').exists() or any((ROOT / f'c{c}').exists() for c in (1, 4, 8, 16)):
    raise RuntimeError('A mixed execution may not overwrite or retry an existing observation')

environment = os.environ.copy()
environment['PYTHONDONTWRITEBYTECODE'] = '1'
receipt = {
    'schema_version': 1,
    'kind': 'original_fixed_M5_four_concurrency_mixed_observations',
    'started_at_utc': utc(),
    'status': 'running',
    'source_directory': str(SOURCE),
    'source_and_build_before': identity(),
    'build_directory': str(BUILD),
    'build_scope': 'Reuse the single independently verified fresh-target locked offline release build executed at M5; no cell is claimed to have a separately compiled binary.',
    'plan': {'concurrency_caps': [1, 4, 8, 16], 'operations_per_cell': 900,
             'files_per_cell': 1000, 'interval_ms': 500, 'profile': 'mixed'},
    'execution_environment': {
        'four_cells_share_host': True,
        'overlaps_M5_cache_soak': True,
        'performance_scope': 'Observed workload and resource distributions only; no isolated-host or causal speed comparison.',
        'fixtures': 'Each original invocation owns a separate newly created synthetic project and output directory.',
        'provider': 'Semantic disabled; no live or paid provider.',
    },
    'cells': [],
    'task_state_changed': False,
}
save()


def run_cell(concurrency):
    cell_root = ROOT / f'c{concurrency}'
    cell_root.mkdir()
    cell = {'concurrency': concurrency, 'started_at_utc': utc(), 'status': 'running', 'phases': []}
    with LOCK:
        receipt['cells'].append(cell)
        save()
    binary_args = ['--binary', str(BUILD / 'codecortex'), '--oracle', str(BUILD / 'p8-oracle'),
                   '--statistics', str(BUILD / 'p8-runtime-statistics'), '--build-receipt', str(BUILD / 'build-receipt.json')]
    commands = [
        ('mixed', ['python3', '-B', 'scripts/p8_runtime.py', *binary_args,
                   '--profile', 'mixed', '--concurrency', str(concurrency), '--operations', '900',
                   '--files', '1000', '--interval-ms', '500', '--output', str(cell_root / 'runtime')]),
        ('verify', ['python3', '-B', 'scripts/p8_runtime.py', 'verify',
                    '--output', str(cell_root / 'runtime'), '--build-output', str(BUILD)]),
    ]
    try:
        for name, argv in commands:
            phase = {'name': name, 'argv': argv, 'cwd': str(SOURCE),
                     'started_at_utc': utc(), 'source_and_build_before': identity(), 'status': 'running'}
            with LOCK:
                cell['phases'].append(phase)
                save()
            started = time.monotonic()
            log_path = cell_root / (name + '.log')
            with log_path.open('xb') as log:
                result = subprocess.run(argv, cwd=SOURCE, env=environment, stdout=log, stderr=subprocess.STDOUT)
            raw = log_path.read_bytes()
            after = identity()
            with LOCK:
                phase.update(exit_code=result.returncode, elapsed_seconds=time.monotonic() - started,
                             finished_at_utc=utc(), source_and_build_after=after,
                             log_path=str(log_path), log_bytes=len(raw), log_sha256=hashlib.sha256(raw).hexdigest(),
                             status='passed' if result.returncode == 0 else 'failed')
                save()
            print(json.dumps({'concurrency': concurrency, 'phase': name, 'exit_code': result.returncode}), flush=True)
        with LOCK:
            cell.update(status='passed' if all(p['exit_code'] == 0 for p in cell['phases']) else 'failed', finished_at_utc=utc())
            save()
    except Exception as error:
        with LOCK:
            cell.update(status='execution_infrastructure_failed', error=f'{type(error).__name__}: {error}', finished_at_utc=utc())
            save()
    return cell['status'] == 'passed'


with ThreadPoolExecutor(max_workers=4) as pool:
    futures = [pool.submit(run_cell, c) for c in (1, 4, 8, 16)]
    results = [future.result() for future in as_completed(futures)]

receipt.update(status='passed' if all(results) else 'failed', finished_at_utc=utc(), source_and_build_after=identity())
receipt['cells'].sort(key=lambda c: c['concurrency'])
save()
raise SystemExit(0 if all(results) else 1)
