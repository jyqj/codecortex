#!/usr/bin/env python3
"""Read preserved peer raw events; engineering attribution, no task acceptance."""
import collections
import hashlib
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
DRIVER = pathlib.Path('/workspace/scratch/2eaa00d0f93a/codecortex-scale-replay-G/scripts')
sys.dont_write_bytecode = True
sys.path.insert(0, str(DRIVER))
import p8_scale_matrix as matrix

EXPECTED = {
    '11576387472': ('6e3eb4fd97edcf238774e74b88d397e059337bac', 50000,
                   'bc988a90b12e96e960dd466c3b93aa642985f7ba47bac1f0c69b6e8be203cd0d'),
    '11577518538': ('599a7050e7d52b5b7b93975c419138e175b3f754', 10000,
                   '3c6978e33fb33f7954c48131eb5f86a01606ca4a12d08f85efd8e84b864131d8'),
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def summarize_builds(builds):
    reports = [build['report'] for build in builds]
    sums = lambda field: {
        key: sum(report[field].get(key) or 0 for report in reports)
        for key in reports[0][field] if key != 'schema_version'
    }
    return {
        'builds': len(builds),
        'wall_us': sum(build['wall_us'] for build in builds),
        'build_timing_us': sums('build_timing'),
        'phase_timing_ms': sums('phase_timing'),
        'dependency_sql': {
            key: sum(report['dirty_plan']['dependency_sql'][key] for report in reports)
            for key in reports[0]['dirty_plan']['dependency_sql']
        },
        'files_scanned': sum(report['files_scanned'] for report in reports),
        'files_parsed': sum(report['files_parsed'] for report in reports),
        'selected_dependents': sum(report['dirty_plan']['selected_dependents'] for report in reports),
        'document_changes': sums('document_changes'),
    }

analyses = []
for artifact, (source, scale, zip_sha) in EXPECTED.items():
    directory = ROOT / artifact
    assert sha(ROOT / (artifact + '.zip')) == zip_sha
    receipt = matrix.read_json(directory / 'shard.json')
    assert receipt['files'] == matrix.inventory(directory, ('shard.json',))
    assert receipt['source_commit'] == source and receipt['status'] == 'passed'
    assert receipt['exit_code'] == 0
    before = matrix.read_json(directory / 'source-before.json')
    matrix.validate_snapshot(before)
    assert before == matrix.read_json(directory / 'source-after.json')
    assert before['source_commit'] == source
    assert before['manifest_sha256'] == receipt['source_manifest_sha256']
    plan = receipt['plan']
    assert plan == matrix.registered_plan(scale, 0, 30, 30, 12648430, 18000000,
                                          'scale_capacity_v1')
    assert plan == matrix.read_json(directory / 'registered-plan.json')
    assert plan == matrix.read_json(directory / 'native/plan.json')
    replayed = matrix.inspect_raw(directory / 'native/raw.jsonl', plan)
    assert len(replayed['measurements']) == 9
    assert replayed['engine']['engine_head_observed'] == source
    assert replayed['engine']['binary_digest'] == receipt['binary_blake3']
    native = matrix.read_json(directory / 'native/report.json')
    assert native['exit_code'] == native['worker_exit_code'] == 0
    assert native['worker_binary_unchanged'] is True
    assert native['worker_binary_digest_before'] == native['worker_binary_digest_after'] == receipt['binary_blake3']
    with (directory / 'native/raw.jsonl').open() as stream:
        events = [json.loads(line) for line in stream]
    builds = [event for event in events if event['event'] == 'build_finished']
    full = summarize_builds([build for build in builds if build['full']])
    incremental = summarize_builds([build for build in builds if not build['full']])
    assert full['builds'] == 10
    parity = [event for event in events if event['event'] in ('cold_parity', 'stage_finished')]
    assert len(parity) == 9 and all(event['parity']['equal'] for event in parity)
    stages = []
    for event in events:
        if event['event'] != 'stage_finished':
            continue
        subset = [build for build in builds if build['label'].startswith(event['label'] + '/incremental-')]
        assert len(subset) == event['incremental_builds']
        group = summarize_builds(subset)
        assert event['incremental_wall_us'] >= group['wall_us']
        group.update(stage=event['label'].split('/')[-1],
                     complete=event['complete'], passed=event['passed'],
                     outer_incremental_wall_us=event['incremental_wall_us'],
                     parity_wall_us=event['parity_wall_us'],
                     first_dependency_sql=subset[0]['report']['dirty_plan']['dependency_sql'],
                     last_dependency_sql=subset[-1]['report']['dirty_plan']['dependency_sql'])
        stages.append(group)
    total_us = native['wall_ms'] * 1000
    parity_us = sum(event['parity_wall_us'] for event in parity)
    accounted_us = full['wall_us'] + incremental['wall_us'] + parity_us
    assert 0 <= total_us - accounted_us
    analyses.append({
        'artifact_id': int(artifact), 'source_commit': source, 'files': scale,
        'zip_sha256': zip_sha, 'raw_sha256': sha(directory / 'native/raw.jsonl'),
        'shard_receipt_sha256': sha(directory / 'shard.json'),
        'source_manifest_sha256': before['manifest_sha256'],
        'binary_sha256_recorded': receipt['binary_sha256'],
        'binary_blake3_recorded': receipt['binary_blake3'],
        'binary_original_locally_verified_for_this_analysis': False,
        'environment': receipt['environment'], 'plan': plan,
        'source_before_after_and_inventory_verified': True,
        'original_g_inspect_raw_passed': True, 'replayed_measurements': 9,
        'native_child_wall_us': total_us, 'full': full, 'incremental': incremental,
        'parity_us': parity_us, 'parity_count': len(parity),
        'outside_build_calls_and_parity_us': total_us - accounted_us,
        'stages': stages,
        'dominant_nonoverlapping_fraction_of_child': {
            'full_builds': full['wall_us'] / total_us,
            'incremental_builds': incremental['wall_us'] / total_us,
            'oracle_parity': parity_us / total_us,
            'other': (total_us - accounted_us) / total_us,
        },
        'nested_fraction_of_child_not_additive': {
            'full_staging': full['build_timing_us']['full_staging_us'] / total_us,
            'incremental_commit_write': incremental['build_timing_us']['commit_write_us'] / total_us,
            'incremental_prepare': incremental['build_timing_us']['prepare_us'] / total_us,
            'incremental_scan_diff': incremental['phase_timing_ms']['scan_diff_ms'] * 1000 / total_us,
        },
    })

result = {
    'schema': 'p8-peer-scale-hotspot-analysis-v1',
    'scope': 'Source-bound peer engineering attribution only; neither paired causal comparison nor original G matrix/task/release acceptance.',
    'driver_path': str(DRIVER / 'p8_scale_matrix.py'),
    'driver_sha256': sha(DRIVER / 'p8_scale_matrix.py'),
    'input_populations': analyses,
    'timing_interpretation': [
        'Full/incremental outer build wall plus parity are non-overlapping; staging is nested inside full prepare, and commit_write/scan are inside their build.',
        'Dependency SqlWork is actual rows/VM/statements/sorts, not elapsed time; fullscan_steps=0 does not mean there is no repeated indexed prefix work.',
        'These are different scales, source binaries and executions; equal reported host text/CPU is not proof of a paired controlled host, so no speedup inference is made.',
        'No original binary was downloaded or executed for this analysis. Raw event structural/closure/15-table checks and sealed inventory/source identity passed; complete validate_build/validate_shard certification was not run.',
    ],
}
(ROOT / 'analysis.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'analysis_sha256': sha(ROOT / 'analysis.json'),
                  'analysis_bytes': (ROOT / 'analysis.json').stat().st_size,
                  'owned_bytes': sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file()),
                  'populations': [{key: item[key] for key in ('artifact_id', 'source_commit', 'native_child_wall_us', 'dominant_nonoverlapping_fraction_of_child', 'nested_fraction_of_child_not_additive')} for item in analyses]}, indent=2))
