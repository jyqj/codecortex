"""Finite R30 public small-record index; excludes every private capture and raw ZIP."""
import gzip,hashlib,io,json,pathlib,stat,tarfile
W=pathlib.Path('/workspace/scratch/a217aaae3bde')
B=W/'original-C3ff-runtime';O=pathlib.Path(__file__).resolve().parent
selected=[]
def info(p):
 d=p.read_bytes();s=p.stat()
 return dict(source=p.relative_to(W).as_posix(),bytes=len(d),sha256=hashlib.sha256(d).hexdigest(),git_blob=hashlib.sha1(('blob '+str(len(d))+'\0').encode()+d).hexdigest(),mode=stat.S_IMODE(s.st_mode))
def add(p,target):
 assert p.is_file() and not p.is_symlink() and p.name!='private-transfer.json' and p.suffix!='.zip'
 d=p.read_bytes()
 for forbidden in (b'"file_id"',b'"file_uri"',b'Bearer ',b'X-Amz-Signature=',b'sig='):
  assert forbidden not in d,(str(p),forbidden)
 selected.append(dict(target=target,**info(p)))
for aid,c in [('11611743908',1),('11612539681',4),('11612256751',8),('11611524778',16)]:
 prefix='runtime/mixed-c'+str(c)
 for p in sorted((B/'artifacts'/aid).iterdir()):
  if p.is_file() and p.suffix!='.zip' and p.name!='private-transfer.json':add(p,prefix+'/'+p.name)
 review=B/'accepted'/('artifact-'+aid+'-3ffcefc3-independent-final')
 for p in sorted(review.iterdir()):add(p,prefix+'/replay/'+p.name)
 add(B/'accepted'/('runtime-3ffcefc3-independent-'+aid+'.json'),prefix+'/aggregate-review.json')
for name in ['run_mixed_originals_round30_once.py','run_mixed_c16_round30_once.py','run_mixed_c16_round30_ram_once.py','run_mixed_c4_round30_ram_once.py','reclaim_mixed_round30_derived.py','reclaim_c16_ram_derivatives.py','reclaim_c4_ram_derivatives.py']:
 add(B/name,'runtime/wrappers/'+name)
for folder in ['monitor-1112','monitor-1123','monitor-1134']:
 for p in sorted((B/folder).glob('37908825814-*.json')):add(p,'runtime/official-monitor/'+folder+'/'+p.name)
old=W/'original-173-runtime'
for folder in ['round30-derived-reclamation','round30-lifecycle-recovery-derived-reclamation']:
 for p in sorted((old/folder).iterdir()):add(p,'runtime/historical173-storage/'+folder+'/'+p.name)
for name in ['reclaim_completed_runtime_round30.py','reclaim_completed_lifecycle_recovery_round30.py']:
 add(old/name,'runtime/historical173-storage/'+name)
add(W/'original-C3ff-platform-gates/helper-storage-root-v1/independent-review.json','runtime/storage-root-peer/independent-review.json')
add(O/'storage-path-decision.json','runtime/storage-path-decision.json')
assert len({r['source'] for r in selected})==len(selected)==len({r['target'] for r in selected})
selected.sort(key=lambda r:r['target'])
large=[r for r in selected if r['bytes']>=262144]
small=[r for r in selected if r['bytes']<262144]
archive=O/'large-original-records.tar.gz';assert not archive.exists()
with archive.open('xb') as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0,compresslevel=9) as zipped:
  with tarfile.open(fileobj=zipped,mode='w|',format=tarfile.USTAR_FORMAT) as tar:
   for row in large:
    p=W/row['source'];d=p.read_bytes();assert info(p)=={k:v for k,v in row.items() if k!='target'}
    item=tarfile.TarInfo(row['target']);item.size=len(d);item.mode=row['mode'];item.uid=item.gid=0;item.uname=item.gname='';item.mtime=0;item.type=tarfile.REGTYPE
    tar.addfile(item,io.BytesIO(d))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert [m.name for m in members]==[r['target'] for r in large]
 for member,row in zip(members,large):
  assert member.isfile() and member.size==row['bytes'] and member.mode==row['mode'] and member.uid==member.gid==member.mtime==0 and member.uname==member.gname==''
  with tar.extractfile(member) as f:d=f.read()
  assert d==(W/row['source']).read_bytes() and hashlib.sha256(d).hexdigest()==row['sha256']
for row in selected:assert info(W/row['source'])=={k:v for k,v in row.items() if k!='target'}
derivation=dict(schema='R30-large-original-records-lossless-container-v1',archive=info(archive),member_count=len(large),uncompressed_original_bytes=sum(r['bytes'] for r in large),members=large,format='Sorted regular USTAR members; original actual mode; uid/gid0; empty owner names; tar/gzipmtime0; gzip9.',verification='Full reopen: exact order/member set/regular headers/mode/size and complete member bytes against unchanged source; every SHA256 and Gitblob retained.',scope='Storage only. This contains original auditor records, not raw native ZIPs or a new acceptance run. Original source JSONs remain untouched.')
delivery=O/'large-original-records-delivery.json';delivery.write_text(json.dumps(derivation,indent=2,sort_keys=True)+'\n')
files=small+[dict(target='runtime/large-original-records.tar.gz',**info(archive)),dict(target='runtime/large-original-records-delivery.json',**info(delivery)),dict(target='runtime/prepare-manifest.py',**info(pathlib.Path(__file__)))]
assert len({r['target'] for r in files})==len(files)
manifest=dict(schema='R30-runtime-public-file-manifest-v1',source='3ffcefc3b28ee1a4ed80caecebd7208a45c3e302',workflow_run=37908825814,scope='C four original mixed profiles, exact original replay outputs, CLI execution, official metadata, storage-path decision and constrained old/current derived recovery; no soak/LG sample in this cutoff.',original_selected_records=len(selected),original_selected_bytes=sum(r['bytes'] for r in selected),direct_public_files=len(files),direct_public_bytes=sum(r['bytes'] for r in files),files=sorted(files,key=lambda r:r['target']),large_records_losslessly_contained=len(large),large_record_original_targets_retained_in_container=[r['target'] for r in large],excluded=['All private-transfer captures and actual private transfer IDs or signed links','All original ZIP/executable/SQLite/raw measurement payloads; metadata locators do not assert raw publication','All historical R29 67 selected files remain unchanged and are not repackaged','Current C lifecycle/recovery exceptional paths and old173 unknown-mode binary','Round31soak and not-yet-produced LG artifacts'],actual_mixed_original_acceptance={'C1':{'artifact_id':11611743908,'requests':900,'rpc_peak':1},'C4':{'artifact_id':11612539681,'requests':900,'rpc_peak':4},'C8':{'artifact_id':11612256751,'requests':900,'rpc_peak':7},'C16':{'artifact_id':11611524778,'requests':900,'rpc_peak':12}},formal_task_completion=False,task_status_changed=False,ledger=dict(done=163,remaining=29,newly_closed=0),publication_status='local_prepared_only; no remote upload/ref created by this manifest')
p=O/'new-public-files-manifest.json';p.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(manifest=info(p),container=info(archive),delivery=info(delivery),selected=len(selected),large=len(large),public_files=len(files),public_bytes=manifest['direct_public_bytes'])))
