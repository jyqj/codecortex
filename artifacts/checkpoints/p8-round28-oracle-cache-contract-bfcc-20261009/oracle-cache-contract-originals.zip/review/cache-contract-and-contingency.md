# 固定 dual-spool 的缓存合同与条件性排查

核查源码为 `b8ab8ecdc5b32993fc02ce43877b7e172b8a4b3f`，不是当前仍在运行的旧规模研究。
本次仅阅读源码、原协议和已保留的两个 50k rep0 诊断；没有调参、运行 SQLite/Rust、重放测量或启动研究。

## 结论

`cache_size=-2048` 不是整个进程的硬 RSS 上限，但已经是 `scale_capacity_v1` 的明确物理配置合同，
`scale_wide_dirty_v1` 也继承它。不能将调大缓存说成原研究“预算完全不变”的私有实现替换，
更不能继续报告 `sorting_cache_kib=2048`。当前两个已注册研究的原身份、容量与判定保持不动。

| 依据 | 确切位置 | 约束 |
|---|---|---|
| 实际 dual-spool | `streaming.rs:298–320`、`326–345` | 每次比较创建一个私有临时 SQLite；A spool 完成后才 B spool；4096-byte 页、journal/synchronous OFF、temp_store FILE、cache -2048、mmap 0、max_page_count；两侧都写入同一主树。 |
| 输出 | `streaming.rs:399–408` | 对外记录 limits、canonical bytes、scratch bytes、`sorting_cache_kib: 2048` 和布局。 |
| 旧物理配置回归 | `streaming.rs:719–777` | 原控制要求 PRIMARY KEY 读取、无 TEMP B-TREE、实际 cache_size=-2048、mmap=0。 |
| 原协议说明 | `P8-SCALE.md:57`、`219–232` | 明确固定 2 MiB 页缓存；同时声明它不是整个产品/SQLite 进程峰值。登记容量保留 8 GiB scratch、2 MiB cache、全部 15 表及逐表复用。 |
| 实际接收合同 | `p8_scale_matrix.py:47–63`、`527–539`、`799–800` | wide 只改工作配置而不改 oracle 物理限制；大表 parity 的 cache、limits、layout 必须与原 contract 精确相等，原 record 完整 contract 也须相等。 |

SQLite 官方 [cache_size](https://www.sqlite.org/pragma.html#pragma_cache_size) 说明负数单位是 KiB，
转换为按当前 page_size 计算的建议页数；内置页缓存按需分配，这不是整个进程内存限制。
[cache_spill](https://www.sqlite.org/pragma.html#pragma_cache_spill) 说明 dirty pages 可在事务中途落盘，
阈值与 cache_size 有关。此处 4096-byte 页对应 512 页的目标缓存。
不应将该目标扩大解释成“只允许整个 evaluator 分配 2 MiB”。

## 改缓存可能改变的观察与错误

增大缓存预计影响 cache miss/write/spill、读取/写入字节、CPU、wall 和峰值内存，收益方向尚未测得。
它不需要改变投影、重复行、Value/signed-zero 判等、摘要或排序键，但这不等于所有失败表现不变。
dirty page 写出时点可能后移，I/O/磁盘错误可能从插入阶段移至 flush/commit；在后面还有坏 UTF-8、
超行数或超 canonical bytes 时，首先观测到的错误可能不同。增加内存还可能改变 OOM 或宿主调度结果。
原代码中的 A→B、逐行检查→计费→插入的结构顺序可保留，不能仅凭它承诺实际首个错误也相同。

原 `max_page_count`、双侧真实 spool、每表行上限、raw/encoded 单行上限、累计 canonical bytes、
scratch 清理和输入只读快照不能因此删改。禁用 spill、改成内存临时库或开启大 mmap 也不是等价的
“缓存优化”；这些会引入新的资源行为，当前不建议搭配修改。

## 若原 100k 将来真的超时，最小有用路径

1. 先用该次原终态/未完成阶段定位，不从两个 50k 单样本预测其失败原因。原 50k 的 default 与 wide
   分别约 29.0% 和 35.5% wall 落在 parity，都是各自 N=1、不同 source/profile，不能作跨 profile 因果比较。
   当前材料没有 scratch cache hit/miss/spill 或页 I/O 计数，不能断言页缓存是主瓶颈。
2. 若仍要求保留原 2 MiB 物理配置，可考虑只在既有 `CanonicalInsert` 缓冲内部按 `(value, ordinal)`
   排序已验证行：仍最多 64 行/64 KiB，原 64/8/1 分组、超大合法行单行路径、自然读取/计费/ordinal
   保持。它只可能改善小批次插入局部性，不是外部排序算法的替代。插入顺序会影响页分裂和 scratch
   占用，原低空间错误控制必须原样保留；未经原/新对照不能称为资源合同等价。本次没有实现此候选。
3. 只有明确决定研究另一物理配置时，缓存增大才是独立、显式 opt-in 的小候选。旧 2 MiB 入口和旧
   contract 必须仍原样可用；新缓存值如实进入物理 profile、输出和接收合同，不沿用旧注册研究身份。
   这是供未来决策的边界说明，不是建议现在另开研究，也不是完成 P8-006 的新增门槛。

实施任一候选前需要的工程证据应紧贴这一次改动：原 dual-spool 的完整表输出/摘要/重复/±0/类型与
列顺序/100002 尾行差异对照；B 侧预算和 A 错误优先；两侧共同撑满 scratch 的原负例；公共表 JSON
字段集；PRIMARY KEY 无额外 TEMP B-TREE。现有原控制已有这些入口，应复用原条件，不为改善结果
删掉、放宽或重新定义。缓存新配置若被选择，还必须诚实记录资源错误时点差异，不能声称严格等价错误序。

成本对照只需要先回答一个具体问题：缓存/插入局部性是否减少本地临时库页工作，而非仅降低返回行数。
可在同一已固定候选和原实现的有界夹具中记录实际 page-cache hit/miss/write、峰值内存、scratch bytes、
wall/CPU 与读写成本，交错顺序，保留全部尝试。语义对照包含等输入与尾行不等；输入大小应确实超过
2 MiB，否则不足以说明这个假设。它是工程诊断，不替代已注册 N30/1500，也不凭短时倍数启动规模实验。

若原失败发生在其它阶段、页 I/O 不是主要成本、插入已基本有序、64 KiB 预排序收益不足，或收益由
更高内存/更晚报错换来且不符合要保留的合同，就停止该候选。当前证据不足以支持调整缓存或承诺提速。
