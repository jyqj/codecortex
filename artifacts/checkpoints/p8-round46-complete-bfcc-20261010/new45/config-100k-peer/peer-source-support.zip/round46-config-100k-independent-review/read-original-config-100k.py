import collections, datetime, hashlib, json
from pathlib import Path
ROOT=Path('/workspace/scratch/bfccb8494ba0'); OUT=Path(__file__).resolve().parent
IN=ROOT/'round46-config-100k-original-intake'; CELL=IN/'config-100000-0'; SHARD=CELL/'original-shard'; NATIVE=SHARD/'native-shard/native'
BUILD=ROOT/'round42-new45-build-original-intake'; G='f97c5068d056969705e8387ba1f37d83847f5bee'; RUN=38026411200
inputs={}
def read(p):
 b=p.read_bytes();inputs[str(p)]={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()};return b
def load(p):return json.loads(read(p))
def dump(name,v):
 text=json.dumps(v,ensure_ascii=False,indent=2)+'\n'
 if (OUT/name).exists():
  assert (OUT/name).read_text()==text
 else:
  with (OUT/name).open('x') as f:f.write(text)

t=load(IN/'terminal.json'); official=load(ROOT/'round46-new45-original-artifacts/config-100k-original-inputs.json')
ret=load(CELL/'original-validate-shard-return.json'); ex=load(CELL/'original-validator-execution.json')
registry=load(BUILD/'original-build/task-registry.json'); bt=load(BUILD/'validation-attempt01/original-validate-build-return.json')
prior=load(ROOT/'round46-api-100k-independent-review/independent-api-100k-review.json')
assert (t['source'],t['run_id'],t['attempt'],t['accepted_cells'],t['failed_cells'],t['accepted_records'])==(G,RUN,1,1,0,2)
assert t['records'][0]['slot']==['config',100000,0]
assert t['validate_build_calls']==t['compile_or_measurement_calls']==t['old_slots_reexecuted']==0
assert t['stdio_custody_complete'] and load(IN/'shared-source-build-before.json')==load(IN/'shared-source-build-after.json')
assert prior['cumulative']['cells']==42 and prior['cumulative']['records']==79 and prior['source']==G and prior['registry_sha256']==bt['outer']['registration_sha256']
stdout=read(CELL/'original-validator.stdout');assert stdout==read(CELL/'captured-stdout.frozen-original')==read(CELL/'original-validate-shard-return.json')
assert len(stdout)==ex['stdout']['bytes'] and hashlib.sha256(stdout).hexdigest()==ex['stdout']['sha256']
assert read(CELL/'original-validator.stderr')==read(CELL/'captured-stderr.frozen-original')==b''
assert ex['exit_code']==0 and ex['original_validate_shard_calls']==1 and ex['validate_build_calls']==ex['measurement_or_compile_calls']==0
assert load(CELL/'shard-before.json')==load(CELL/'shard-after.json')
sr=load(SHARD/'task-shard.json');nr=load(NATIVE/'report.json');assert nr['summary']==load(NATIVE/'worker-summary.json')
p=ret['plan'];assert p==sr['plan'] and p in registry['plans']
assert (p['deadline_ms'],p['max_output_bytes'],p['dirty_budget'],p['max_resume_builds'],p['seed'])==(18000000,536870912,200,1024,12648430)
assert p['profile']=='release' and p['capacity_profile']=='scale_capacity_v1' and p['stage_scope']=='profile_task_descriptive_v1'
assert p['files']==[100000] and p['repetitions']==1 and p['shard']=={'count':1,'index':0}
assert p['profile_study']=={'fanout':None,'mutation_profile':'config','run_attempt':1,'run_id':str(RUN)}
assert ret['study']==sr['study']==registry['study'] and ret['driver_source']==sr['driver_source']==registry['driver_source']
assert len(ret['driver_source']['inputs'])==11 and ret['registration_sha256']==bt['outer']['registration_sha256']
assert ret['build_receipt_sha256']==sr['task_build_receipt_sha256']=='5b3f02a114fd68355916a4d94ec3b2c65a5895371e2bbdd97d24077598e50aab'
assert sr['passed'] and sr['status']=='passed' and sr['task_statuses_changed'] is False
assert sr['files']['native-shard/source-before.json']==sr['files']['native-shard/source-after.json']
assert ret['engine']['engine_head_observed']==G and ret['engine']['binary_digest']==registry['binary_blake3'] and not ret['engine']['eval_debug_assertions']
assert nr['status']=='measurement_complete' and nr['exit_code']==nr['worker_exit_code']==0 and nr['stderr_complete'] and nr['worker_binary_unchanged']
assert nr['worker_binary_digest_before']==nr['worker_binary_digest_after']==registry['binary_blake3']
assert nr['fixture_cleanup']['error'] is None and nr['summary']['passed'] and nr['summary']['sample_count']==2
assert [x['group'] for x in ret['measurements']]==['scale-100000/cold','scale-100000/config']
hs=load(CELL/'native-hash-subprocess-originals.json');assert len(hs)==2
for h,k in zip(hs,['plan_digest','raw_digest']):
 assert h['returncode']==0 and '--hash-file' in h['argv'] and read(CELL/h['stderr']['file'])==b''
 assert read(CELL/h['stdout']['file']).decode().strip()==nr[k]

TABLES={'document_manifest','resolution_frontier','semantic_edges','dispatch_sites','resolution_manifests','resolution_dependencies','public_surfaces','files','symbols','imports','symbol_refs','call_edges','chunks','test_edges','routes'}
counts=collections.Counter(); builds=[];parities=[];stages=[];mutations=[]
raw=NATIVE/'raw.jsonl';sha=hashlib.sha256();raw_bytes=0
with raw.open('rb') as f:
 for ln,b in enumerate(f,1):
  sha.update(b);raw_bytes+=len(b);e=json.loads(b);ev=e['event'];counts[ev]+=1
  if ev=='build_finished':
   r=e['report'];pm=r['project_model'];pm_short={k:(dict(array_count=len(v),canonical_sha256=hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()) if isinstance(v,list) else v) for k,v in pm.items()}
   fields={k:v for k,v in r.items() if k.startswith('files_') or k in ['dirty_plan','dirty_propagation','document_changes','build_timing','phase_timing','resolution_freshness','elapsed_ms','symbols_total','chunks_total','parse_errors','used_parallel_parse']}
   builds.append({'line':ln,'label':e['label'],'full':e['full'],'start_us':e['start_us'],'end_us':e['end_us'],'wall_us':e['wall_us'],'report_fields':fields,'project_model_list_values_summarized':pm_short})
   assert e['wall_us']==e['end_us']-e['start_us']
   if e['full']:assert r['resolution_freshness']['complete']
  if ev in ['cold_parity','stage_finished']:
   q=e['parity'];assert q['equal'] is True and q['status']=='equal' and q['different_tables']==[]
   assert len(q['tables'])==15 and {x['table'] for x in q['tables']}==TABLES
   for v in q['tables']:
    assert type(v['equal']) is bool and v['equal'] and type(v['full_rows']) is int and type(v['incremental_rows']) is int
    assert v['full_rows']==v['incremental_rows'] and v['full_digest']==v['incremental_digest'] and isinstance(v['full_digest'],str)
    assert type(v['different_row_count']) is int and v['different_row_count']==0 and v['different_row_examples']==[]
   assert q['full_counts']['files']==q['incremental_counts']['files']==100000
   parities.append({'line':ln,'event':ev,'original_parity':q,'parity_wall_us':e['parity_wall_us'],'independent_config_fact':e['independent_config_fact']})
   if ev=='stage_finished':stages.append({'line':ln,**{k:v for k,v in e.items() if k!='parity'}})
  if ev=='mutation':mutations.append({'line':ln,'event':e})
assert raw_bytes==nr['summary']['raw_bytes'] and len(builds)==333 and len(parities)==2 and len(stages)==1 and len(mutations)==1
incs=[v for v in builds if not v['full']];no=incs[0];stage=stages[0]
assert len(incs)==330 and counts['build_started']==counts['build_finished']==333
assert [b['line'] for b in incs]==list(range(10,669,2))
assert [b['label'].rsplit('/',1)[1] for b in incs]==['incremental-'+str(i) for i in range(330)]
assert [b['line'] for b in builds if b['full']]==[4,6,670] and stage['line']==671
assert stage['passed'] and stage['complete'] and stage['full_complete'] and stage['incremental_builds']==330
assert mutations[0]['event']['requested_files']==1
assert len(mutations[0]['event']['operations'])==len(mutations[0]['event']['receipts'])==1
for i,v in enumerate(incs):
 r=v['report_fields'];dp=r['dirty_plan'];fr=r['resolution_freshness']
 assert dp['file_budget']==200 and 0<=dp['selected_dependents']<=200 and dp['resumed']==(i>0)
 assert r['files_scanned']==100000
 assert r['build_timing']['full_staging_us'] is None
 assert fr['complete']==(i==329) and fr['status']==('ready' if i==329 else 'incomplete')
 if i<329:assert fr['reason']=='budget_exceeded' and fr['retry'] is not None
m=ret['measurements'][1]
assert m['builds']==330 and m['engine_ms']==sum(v['report_fields']['elapsed_ms'] for v in incs)
assert m['index_wall_us']==sum(v['wall_us'] for v in incs) and m['outer_incremental_wall_us']==stage['incremental_wall_us']
for k,value in m['build_timing'].items():
 observed=[v['report_fields']['build_timing'][k] for v in incs]
 if value is None:assert all(x is None for x in observed)
 else:assert value==sum(observed)
for k,value in m['phases'].items():assert value==sum(v['report_fields']['phase_timing'][k] for v in incs)
closure={'incremental_builds':330,'incomplete_builds':329,'resumed_true_builds':329,'first':incs[0],'last':incs[-1],'dependent_selection_visits':sum(v['report_fields']['dirty_plan']['selected_dependents'] for v in incs),'dependent_visit_boundary':'Sum of selection visits across builds, not independently deduplicated unique dependency files.','aggregate_engine_ms':m['engine_ms'],'aggregate_index_wall_us':m['index_wall_us'],'outer_incremental_wall_us':m['outer_incremental_wall_us'],'aggregate_build_timing':m['build_timing'],'aggregate_legacy_phases':m['phases'],'aggregation_verified_against_all330_original_builds':True}
art=official['inputs'][0]['artifact'];job=official['producer_job']
assert art==t['records'][0]['artifact'] and art['id']==11663330163 and art['digest']=='sha256:'+t['records'][0]['whole_zip']['sha256']
assert (job['id'],job['head_sha'],job['run_id'],job['run_attempt'],job['status'],job['conclusion'])==(114139257139,G,RUN,1,'completed','success')
assert all(s['conclusion']=='success' for s in job['steps'])

timing={'scope':'Each raw unit retained; full_staging and prepare_snapshot are nested within prepare, and legacy phase_timing is not an additive partition of build_timing. No cross-host or prior-study causal ratio.','raw_path':str(raw),'raw_bytes':raw_bytes,'raw_sha256':sha.hexdigest(),'original_BLAKE3_from_native_report':nr['raw_digest'],'builds':builds,'parities':parities,'stage':stage,'measurements':ret['measurements'],'mutation':mutations}
dump('original-timing-phase-and-parity-selection.json',timing)
report={'schema':'independent-original-config-100k-whole-acceptance-v1','reviewer':'/root/pr_triage','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':G,'run_id':RUN,'attempt':1,'result':'accepted_scoped_one_registered_config_100k_cell','new_cells':1,'new_records':2,'roles':['setup','config mutation'],'cumulative':{'cells':43,'expected_cells':45,'records':81,'expected_records':85,'setup':38,'mutation':38,'fanout':5,'cold_curve_selected_setup':5,'cold_curve_selected_scales':[1000,5000,10000,50000,100000]},'remaining':{'cells':2,'records':4,'population':'body/batch_100 at100k'},'cold_subset_boundary':'The no_op setup from the separately accepted prior cell supplies the fifth cold point. This config setup remains retained but does not replace or add a sixth cold point. All original failed continuous studies remain failed/incomplete and are never pooled.','artifact':art,'whole_zip_identity_from_original_receiver':t['records'][0]['whole_zip'],'producer':job,'official_pagination_limit':official.get('observation_limit', 'Individual exact-name artifact query; not a full population enumeration. Original input retains the actual lookup metadata.'),'original_validator_execution':ex,'original_hash_utility_calls':2,'validate_build_reexecuted':False,'stdio_two_copies_return_receipt_equal':True,'source_build_and_shard_before_after_equal':True,'registry_sha256':ret['registration_sha256'],'task_build_receipt_sha256':ret['build_receipt_sha256'],'binary_blake3':registry['binary_blake3'],'binary_sha256':registry['binary_sha256'],'observer':ret['driver_source'],'plan':p,'native_report':nr,'engine':ret['engine'],'environment':ret['environment'],'profile_environment':ret['profile_environment'],'measurement_environment':ret['measurement_environment'],'resource_snapshots':ret['resource_snapshots'],'measurements':ret['measurements'],'phase_count_mapping':{'complete333_builds_and_two15table_parities':'original-timing-phase-and-parity-selection.json','full_builds':[v for v in builds if v['full']],'incremental_closure':closure},'raw_event_counts':dict(counts),'raw_identity':{'bytes':raw_bytes,'sha256':sha.hexdigest(),'original_report_blake3':nr['raw_digest']},'typed_parity':{'observations':2,'tables_each':15,'equal_table_observations':30,'initial_raw_line':7,'final_raw_line':671,'different_rows':0,'initial_and_final_full_control_complete':True,'config_builds':330,'first_build_incomplete':True,'original_summary_first_build_incomplete_samples':nr['summary']['groups'][1]['first_build_incomplete_samples'],'summary_counter_boundary':'Original summary group counter preserved literally; first incomplete is established by raw resolution_freshness, not inferred from that counter.','initial_and_final_capacity_profile':'scale_capacity_v1','canonical_bytes_initial_final':[q['original_parity']['canonical_bytes'] for q in parities],'scratch_peak_bytes_initial_final':[q['original_parity']['scratch_peak_bytes'] for q in parities]},'limits':['N1, one environment and fixed source/build. No stable tail, confidence interval, all100k/full-study or release claim.','Raw reports retain semantic vectors disabled/countnull, untracked Python caches, PID-only resource snapshots, observed seed-cache max500000 and hardware identity; no fabricated peak or clean host.','Timing scopes differ: engine elapsed_ms, detailed total_us, enclosing wall_us, parity_wall_us and native child wall_ms. Nested full_staging/prepare_snapshot are not added again.','Whole payload and producer completion are proven for this slot; concurrent artifact enumeration is not a final complete population index.','Original aggregate has not been executed or accepted by this peer; no task status updated.'],'peer_execution':{'read_only_original_returns_and_new_raw':True,'CRC_ZIP_ELF_original_validator_or_product_calls':0,'old_raw_or_ZIP_reads':0,'Actions_downloads':0},'task_credit':0,'reader_attempt_history':{'attempt01':'Pure independent new-slot receipt/raw reader; no original validator, ELF, CRC, ZIP or product operation.'}}
dump('independent-config-100k-review.json',report);dump('read-input-identities.json',list(inputs.values()))
print(json.dumps({'status':report['result'],'accepted_new_cells':1,'accepted_new_records':2,'cumulative':report['cumulative'],'native_wall_ms':nr['wall_ms'],'config_engine_ms':ret['measurements'][1]['engine_ms'],'config_first_parsed_files':no['report_fields']['files_parsed'],'cold_counts':ret['measurements'][0]['counts'],'new_original_function_executions_by_peer':0},ensure_ascii=False,indent=2))
