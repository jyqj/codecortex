def stable_00476():
    return 476
