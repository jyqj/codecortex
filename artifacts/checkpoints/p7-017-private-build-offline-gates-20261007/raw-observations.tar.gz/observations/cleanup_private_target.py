#!/usr/bin/env python3
"""Remove only this run's private Cargo intermediates after its actual gate."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

OUT = Path(__file__).resolve().parent
SOURCE = 'a213a4cfab0e0e87198bc279acacda51e4ff62cf'


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ('default', 'semantic'):
        raise SystemExit('expected default or semantic')
    package = sys.argv[1]
    product_dir = OUT / (package + '-product')
    target = product_dir / 'cargo-target'
    record_path = OUT / (package + '-private-target-cleanup.json')
    if record_path.exists() or target.is_symlink() or not target.is_dir():
        raise SystemExit('new cleanup receipt and regular owned target required')
    if target.resolve() != OUT / (package + '-product/cargo-target'):
        raise SystemExit('private target resolved outside its explicitly owned path')
    receipt_path = product_dir / 'build-receipt.json'
    receipt = json.loads(receipt_path.read_bytes())
    runner_path = OUT / (package + '-test-runner.json')
    runner = json.loads(runner_path.read_bytes())
    gate_path = OUT / (package + '-offline-gate.json')
    gate = json.loads(gate_path.read_bytes())
    if (receipt['cargo_target_dir'] != str(target)
            or receipt['cargo_build_dir'] != str(target)
            or receipt['cargo_target_initially_absent'] is not True
            or receipt['source_before']['source_commit'] != SOURCE
            or receipt['source_after'] != receipt['source_before']):
        raise SystemExit('product receipt did not bind this new private target/source')
    product = product_dir / 'codecortex'
    executable = OUT / (package + '-benchmark-adapters')
    if (sha(product) != receipt['binary_sha256']
            or sha(executable) != runner['executable_sha256']):
        raise SystemExit('retained product/runner copy does not match captured build')
    if (not isinstance(gate['exit_code'], int) or gate['source_unchanged'] is not True
            or gate['source_before']['source_commit'] != SOURCE
            or gate['product_binary_sha256_before'] != receipt['binary_sha256']
            or gate['product_binary_sha256_after'] != receipt['binary_sha256']
            or gate['test_runner_sha256_before'] != runner['executable_sha256']
            or gate['test_runner_sha256_after'] != runner['executable_sha256']):
        raise SystemExit('actual gate has not reached a recorded terminal state against these retained bytes')
    observations = OUT / (package + '-offline-observations') / ('p7-017-' + package + '.json')
    protected = [product, executable, receipt_path, runner_path, gate_path,
                 product_dir / 'source-inputs.json', product_dir / 'cargo-build.jsonl',
                 product_dir / 'cargo-build.stderr.log',
                 OUT / (package + '-offline-gate.log'),
                 OUT / (package + '-network-exec.json'),
                 OUT / (package + '-test-runner-build.log')]
    if observations.exists():
        protected.append(observations)
    hashes = {str(path.relative_to(OUT)): sha(path) for path in protected}
    usage_before = shutil.disk_usage(OUT)
    shutil.rmtree(target)
    if target.exists() or any(sha(OUT / path) != expected for path, expected in hashes.items()):
        raise SystemExit('private target cleanup changed a retained artifact')
    usage_after = shutil.disk_usage(OUT)
    record = {
        'schema_version': 1, 'package_kind': package,
        'deleted_owned_private_target': str(target),
        'target_was_initially_absent_in_actual_product_build': True,
        'source_commit': SOURCE,
        'gate_exit_code': gate['exit_code'],
        'gate_passed': gate['exit_code'] == 0,
        'observations_written_by_original_gate': observations.exists(),
        'retained_artifacts_sha256': hashes,
        'retained_artifacts_unchanged': True,
        'free_bytes_before': usage_before.free, 'free_bytes_after': usage_after.free,
        'cleanup_script_sha256': sha(Path(__file__)),
        'scope': 'Only task-created private Cargo intermediates were removed after the actual gate reached its recorded terminal state, whether success or failure. Copied product, copied runner, receipts, raw Cargo/gate logs and any completed observations remain unchanged. Cleanup does not change gate acceptance.',
    }
    record_path.write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
    print(json.dumps({key: record[key] for key in ('package_kind', 'deleted_owned_private_target', 'retained_artifacts_unchanged', 'free_bytes_before', 'free_bytes_after')}, indent=2))


if __name__ == '__main__':
    main()
