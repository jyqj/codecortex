#!/usr/bin/env python3
"""Read original terminal receipts and exact input identity; never run product."""
import datetime,hashlib,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
NATIVE=Path('/workspace/scratch/bfccb8494ba0/root-round16/native-P2-originals-transfer')
E=NATIVE/'extracted/P2-native-evidence'
SOURCE=json.loads((ROOT/'actual-P2-independent-source-review.reconstructed.json').read_text())
TREE=json.loads(Path('/dev/shm/todo-audit-p8007-final-main-integration/actual-P2/actual-P2-complete-derived-Git-tree.json').read_text())
leaves={r['path']:r for r in TREE['tree'] if r['type']!='tree'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
zip_path=NATIVE/'native-P2-first-failure-and-complete-continuation-originals.zip'
assert zip_path.stat().st_size==25744293 and sha(zip_path)=='ff5d3ae9bb81189bbe3714f783ef11c8bd4c84d0c8774cb41b7e83e07232e27e'
files=['workspace-format-receipt.json','new-lane-query-policy-lib-controls-receipt.json','continuation-complete-original-inputs/new-lane-query-policy-lib-controls-receipt.json','continuation-complete-original-inputs/mechanism-source-anchor-control-receipt.json','continuation-complete-original-inputs/changed-search-eval-strict-clippy-receipt.json','continuation-complete-original-inputs/mechanism-four-variants-prepare-only-receipt.json']
results=[];entries_by_command=[];canonical={**SOURCE['complete_inputs'],**SOURCE['validation_inputs']}
for i,name in enumerate(files):
    p=E/name;d=json.loads(p.read_text());assert d['source_P']==SOURCE['source'] and d['tree']==SOURCE['tree']
    assert type(d['exit_code']) is int and d['exit_code']==(101 if i==1 else 0)
    for key in ('stdout','stderr','before','after'):
        q=p.parent/d[key]['path'];assert q.stat().st_size==d[key]['bytes'] and sha(q)==d[key]['sha256']
    before=json.loads((p.parent/d['before']['path']).read_text());after=json.loads((p.parent/d['after']['path']).read_text())
    assert before['entries']==after['entries']
    assert before['source_P']==after['source_P']==SOURCE['source'] and before['tree']==after['tree']==SOURCE['tree']
    items={x['path']:x for x in before['entries']};assert len(items)==(1250 if i<2 else 1256)
    assert len(items)==len(before['entries']) and set(canonical)<=set(items)
    for path,item in items.items():
        assert item['mode']==leaves[path]['mode'] and item['git_blob']==leaves[path]['sha']
        if path in canonical:assert item['sha256']==canonical[path]
    entries_by_command.append(items)
    stdout=(p.parent/d['stdout']['path']).read_text();stderr=(p.parent/d['stderr']['path']).read_text()
    parsed=[tuple(map(int,row)) for row in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',stdout)]
    if i==1:
        assert not parsed and 'running ' not in stdout and len(re.findall(r"error: couldn't read",stderr))==5
    if i==2:assert parsed==[(303,0,0,0,0)]
    if i==3:assert parsed==[(1,0,0,0,65)]
    results.append({'receipt':info(p),'actual_receipt':d,'parsed_original_test_summaries':parsed,'source_entries_equal':True,'all_entry_mode_blob_match_actual_P2':True,'canonical_1237_sha_match':True,'whole_snapshot_json_byte_equal':sha(p.parent/d['before']['path'])==sha(p.parent/d['after']['path'])})
assert entries_by_command[0]==entries_by_command[1]
assert all(x==entries_by_command[2] for x in entries_by_command[2:])
assert all(entries_by_command[2][p]==v for p,v in entries_by_command[0].items())
extra=sorted(set(entries_by_command[2])-set(entries_by_command[0]));assert len(extra)==6
assert results[2]['actual_receipt']['environment']==results[1]['actual_receipt']['environment']
clippy=results[4]['actual_receipt']['command'];assert clippy[2:]==['clippy','--locked','--offline','-p','cc-search','-p','cc-eval','--all-targets','--','-D','warnings']
assert clippy[-3:]==['--','-D','warnings'] and '--workspace' not in clippy
assert results[5]['actual_receipt']['command'][-1]=='--prepare-only'
report={'schema':'independent-actual-P2-native-terminal-thin-review-v1','reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/execution_recon','source':SOURCE['source'],'tree':SOURCE['tree'],'verdict':'accepted_scoped_original_terminals_and_identity','scope':'Six original child receipts, actual stdin-free stdout/stderr digests, 12 original input snapshots, all1250/1256 Gitmode/blob identities and1237 canonical SHA maps. Full archive and five mechanism source-tree verification is independently assigned to pr_triage; this report does not duplicate that work.','original_zip':info(zip_path),'zip_git_blob':'102956bbc16a1138f4bb3abf3cc6190f7f699e27','commands':results,'source_input_counts':{'first':1250,'continuation':1256,'canonical_product':1095,'canonical_validation':142,'extras_before':13,'new_original_compile_inputs':extra},'accepted_engineering_result':{'workspace_fmt':0,'search_lib_passed':303,'mechanism_anchor_passed':1,'strict_Clippy':'cc-search + cc-eval --all-targets -D warnings exit0; not workspace Clippy','mechanism_prepare_only':0,'no_variants_built_or_measured_by_prepare_only':True},'negative_history':{'first_compile_exit':101,'first_missing_include_str_fixtures':5,'first_Rust_tests_executed':0,'original_first_failure_and1250_domain_preserved':True,'continuation_only_materializes_six_existing_actual_P2_inputs':True},'limits':['Source entry arrays equal, while snapshot JSON phase/labels differ; no whole-file byte equality claim.','Mac Rust1.95 SDK15.4 cached/APFS engineering controls, no cold or performance claim.','P1/G1/PR186 original executions retain their own source scopes.','Current four-C acquisition and originalGc8 scale remain independent; no TODO completion.']}
report['reviewer_preparation_note']='The first thin-check helper had a redundant always-true conditional in its package-list assertion. It is retained unchanged. This v2 explicitly verifies the complete actual two-package Clippy argv; original receipts/source and test results are unchanged.'
out=ROOT/'independent-P2-native-terminals-thin-review.v2.json'
with out.open('x') as f:json.dump(report,f,indent=2,ensure_ascii=False);f.write('\n')
print(json.dumps({'report':str(out),'bytes':out.stat().st_size,'sha256':sha(out),'verdict':report['verdict'],'unique_Rust_tests':304}))
