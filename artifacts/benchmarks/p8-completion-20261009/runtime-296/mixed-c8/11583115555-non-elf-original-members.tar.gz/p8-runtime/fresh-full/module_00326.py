def stable_00326():
    return 326
