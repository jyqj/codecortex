from pathlib import Path
import json,hashlib,zipfile,re
r=Path('/workspace/scratch/bfccb8494ba0');d=r/'round40-diagnostic-checkpoint-11-intake';s=d/'sealed-attempt02';s.mkdir(exist_ok=False)
def info(p):
 b=p.read_bytes();return {'local_path':str(p),'archive_path':str(p.relative_to(r)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
files=sorted(p for p in d.rglob('*') if p.is_file() and s not in p.parents)+[r/'round40-diagnostic-0438-official-originals.json']
for p in files:
 if p.suffix in ('.json','.py','.txt','.log','.diff') or p.name.endswith('.snapshot'):
  b=p.read_bytes();assert not re.search(rb'https?://[^\s\"<>]*[?&](?:sig|X-Amz-Signature)=',b), str(p)
selection={'schema':'selected-originals-v1','scope':'new11 source-bound intake and derived old00-10 continuity; prior whole ZIPs not nested; root retains new wholeZIP','files':[info(p) for p in files]};(s/'archive-selection.json').write_text(json.dumps(selection,indent=2)+'\n')
z=s/'diagnostic-checkpoint11-original-prefix-support.zip'
with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as f:
 for p in files+[s/'archive-selection.json']:f.write(p,str(p.relative_to(r)))
with zipfile.ZipFile(z) as f:
 assert len(f.infolist())==len(files)+1
 for p in files+[s/'archive-selection.json']:assert f.read(str(p.relative_to(r)))==p.read_bytes()
manifest={'schema':'three-leaf-upload-manifest','prefix':'artifacts/checkpoints/p8-round40-complete-bfcc-20261010/diagnostic/checkpoint11/','files':[info(d/'attempt01/checkpoint11-prefix-review.json'),info(z),info(s/'archive-selection.json')]};(s/'upload-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest))
