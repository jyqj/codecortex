def stable_00249():
    return 249
