import datetime
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'root-round13/publication-reviews'
PREFIX = 'artifacts/checkpoints/p8-a23-closeout-20261009-bfcc/round13-pr-refresh-and-public-api-fix'
OUT.mkdir(parents=True, exist_ok=True)
entries = []
bundles = []
selections = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def validate_bytes(p, expected=None):
    p = Path(p)
    assert p.is_file() and not p.is_symlink(), str(p)
    data = p.read_bytes()
    if expected:
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256'], str(p)
    text = data.decode('utf-8', errors='replace')
    for pattern in [r'(?:[?&]|\\u0026)(?:sig|signature|x-amz-signature|x-goog-signature|token|access_token)=[A-Za-z0-9%/+_-]{12,}', r'(?im)^set-cookie:\s*(?!\[?REDACTED)[^\r\n]{12,}']:
        assert not re.search(pattern, text, re.I), (str(p), 'private transfer value')
    return data

def selection_files(path):
    p = Path(path)
    data = validate_bytes(p)
    selection = json.loads(data)
    selections.append({'local_path':str(p), 'bytes':len(data), 'sha256':sha(data)})
    rows = selection.get('entries', selection.get('files'))
    assert isinstance(rows, list)
    result = {'archive-selection.json': (str(p), data)}
    for row in rows:
        source = row.get('source_path', row.get('path'))
        name = row.get('relative_path', row.get('archive_relative_path'))
        assert name and not Path(name).is_absolute() and '..' not in Path(name).parts
        assert name not in result, name
        result[name] = (source, validate_bytes(source, row))
    return result

def archive(name, files, existing=None):
    p = Path(existing) if existing else OUT / name
    if not existing:
        assert not p.exists(), str(p)
        with zipfile.ZipFile(p, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for path, (_, data) in sorted(files.items()):
                info = zipfile.ZipInfo(path, date_time=(2026, 10, 9, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                z.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None and set(z.namelist()) == set(files)
        assert len(z.namelist()) == len(files)
        for member, (source, data) in sorted(files.items()):
            assert z.read(member) == data, member
            entries.append({'archive':name, 'archive_member':member, 'original_local_path':source, 'bytes':len(data), 'sha256':sha(data)})
    data = p.read_bytes()
    assert len(data) <= 8 * 1024 * 1024
    bundles.append({'file_name':name, 'local_path':str(p), 'repository_path':PREFIX+'/'+name, 'bytes':len(data), 'sha256':sha(data), 'git_blob_sha':blob(data), 'members':len(files), 'uncompressed_bytes':sum(len(v[1]) for v in files.values())})

archive('PR175-PR179-fixed-head-review.zip', selection_files('/dev/shm/todo-audit-pr-refresh-175-179/archive-selection.json'), '/dev/shm/todo-audit-pr-refresh-175-179-evidence.zip')
archive('PR180-PR181-source-review.zip', selection_files('/dev/shm/execution-recon-bfcc/pr180181/archive-selection.json'))
archive('PR180-public-dependency-fix-source.zip', selection_files('/dev/shm/todo-audit-pr180-public-dependency-fix/archive-selection.json'), '/dev/shm/todo-audit-pr180-public-dependency-fix.zip')

coordination = {}
for p in [ROOT/'root-round12/job-113726259498-decoded.log', ROOT/'root-round12/external-main-tasks-reconciliation.json', Path('/dev/shm/root-bfccb8494ba0/third-fourth-base64-cleanup-receipt.json'), Path(__file__).resolve()]:
    coordination[p.name] = (str(p), validate_bytes(p))
for name in ['job-113726260236-decoded.log', 'job-113726260410-decoded.log', 'original-P7-decoded-log-evidence.json']:
    p = Path('/dev/shm/root-bfccb8494ba0/round13-P7-logs') / name
    coordination[name] = (str(p), validate_bytes(p))
archive('original-P7-logs-and-root-coordination.zip', coordination)

manifest = {
    'schema':'codecortex.round13.review-publication.v1',
    'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'parent_commit':'802fbae9f984f921cdb5f78dad201dd80605d941',
    'fixed_primary_source':'c8be5afaac568ffd40ef86d3795423c3b73c9f39',
    'primary_scale_run':37902429727,
    'original_tasks':{'total':192, 'done':163, 'new_completed':0, 'remaining':29},
    'scope':[
        'Independent exact-head source and identity review of PR175 8da1f956 and PR179 8da6bd93, whose external merges do not relabel the fixed Gc8 study.',
        'Original contract permits eventual accepted-at-Gc8 evidence in a fresh main ledger without inventing a latest-main full-N30 requirement; source/correctness limits remain explicit.',
        'Independent full-domain source review of PR180 3ffcefc3 and PR181 73885e5f.',
        'Frozen three-file public dependency error-prefix fix, author checks and independent peer review, before native Rust validation. The earlier exact SQL counterexample is published separately in parent802fbae.',
        'Original P7 engineering/default/closeout decoded job logs and separate ledger reconciliation.'
    ],
    'limits':[
        'No task status changes or source branch mutations are made by this evidence publication.',
        'Full original scale study and original one-hour soak remain required and pending.',
        'PR175/179 metadata success is not promoted to unreviewed raw source admission or fixed-Gc8 measurements.',
        'The frozen source-fix packet states Rust not_run at its freeze time. Subsequent actual native red/green evidence must be appended separately, including actual failures.',
        'P7 job113726259498 uses synthetic merge39ae6437 source-domain-equivalent to Gc8, not whole-repository equality. Jobs113726260236 and113726260410 directly check out Gc8.',
        'P7 decoded logs are exact fetched decoded UTF-8 content; original compressed log bytes are not attested. The one-row development-profile engineering baseline is not release or quality certification.',
        'Archive member names in this manifest govern expanded paths; all included selections and frozen archives retain exact original bytes.'
    ],
    'selections':selections, 'bundles':bundles, 'file_count':len(entries), 'files':entries
}
p = OUT / 'publication-manifest.json'
p.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n')
index = {'prefix':PREFIX, 'files_to_upload':bundles, 'manifest':{'local_path':str(p), 'bytes':p.stat().st_size, 'sha256':sha(p.read_bytes())}}
(OUT/'upload-index.json').write_text(json.dumps(index, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'files':len(entries), 'bundles':bundles, 'manifest_bytes':p.stat().st_size}, ensure_ascii=False))
