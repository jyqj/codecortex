def stable_00009():
    return 9
