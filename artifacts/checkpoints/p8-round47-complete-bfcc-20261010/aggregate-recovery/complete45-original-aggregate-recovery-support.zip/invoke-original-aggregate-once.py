import pathlib,json,hashlib,subprocess,sys,datetime,os
D=pathlib.Path(__file__).resolve().parent;R=D.parent
C=json.loads((R/'round47-new45-descriptive-analysis/complete-45-original-directories.pending-recovery.json').read_text())
V=pathlib.Path(C['source_root']);B=pathlib.Path(C['original_build_directory'])
DIRECTORIES=[pathlib.Path(x['original_directory']) for x in C['directories']]
def write(name,data):
    b=data if isinstance(data,bytes) else (json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode()
    with (D/name).open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
def meta(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),mode=oct(p.stat().st_mode&0o777))
def inventory(p):return {f.relative_to(p).as_posix():meta(f) for f in sorted(p.rglob('*')) if f.is_file()}
def snapshot():
    declared=json.loads((R/'round42-new45-build-original-intake/restored-source-inventory.json').read_text())['inventory']
    return dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=V,text=True).strip(),index=meta(V/'.git/index'),source={p:meta(V/p) for p in declared},build=inventory(B),input_directories={str(p):inventory(p) for p in DIRECTORIES})
write('bound-complete-inputs.json',C)
before=snapshot();write('inputs-before.json',before)
sys.path.insert(0,str(V/'scripts'))
import p8_task_profile_matrix as task
run_code=subprocess.run.__code__;calls=[];active={};function_calls={'aggregate':0,'validate_build':0,'validate_shard':0,'combine':0}
observed_codes={getattr(task,n).__code__:n for n in function_calls}
def trace(frame,event,arg):
    if event=='call' and frame.f_code in observed_codes:function_calls[observed_codes[frame.f_code]]+=1
    if frame.f_code is run_code:
        args=frame.f_locals.get('popenargs',());argv=args[0] if args else frame.f_locals.get('kwargs',{}).get('args')
        if isinstance(argv,(list,tuple)) and '--hash-file' in argv:
            if event=='call':
                index=len(calls);active[id(frame)]=index
                calls.append(dict(index=index,argv=[str(x) for x in argv],started_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=None))
            elif event=='return':
                index=active.pop(id(frame));record=calls[index]
                record['completed_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
                if isinstance(arg,subprocess.CompletedProcess):
                    record['returncode']=arg.returncode
                    for channel in ['stdout','stderr']:
                        b=getattr(arg,channel);assert isinstance(b,bytes)
                        name=f'child-hash-{index:03d}.{channel}.original';write(name,b)
                        record[channel]={'file':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
                else:record['exception_or_noncompleted_return']=True
    return trace
sys.setprofile(trace)
try:
    result=task.aggregate(B,DIRECTORIES,D/'aggregate-output',root=V)
finally:
    sys.setprofile(None)
    write('original-function-call-counts.json',function_calls)
    write('actual-native-hash-child-trace.json',calls)
    after=snapshot();write('inputs-after.json',after)
    write('input-identity-comparison.json',dict(equal=before==after,source_head=before['head'],product_observer_count=len(before['source']),directories=len(DIRECTORIES)))
b=(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode()
write('original-aggregate-return.json',b)
write('original-return-vs-matrix.json',dict(structurally_equal=result==json.loads((D/'aggregate-output/task-matrix.json').read_text()),return_meta=meta(D/'original-aggregate-return.json'),matrix_meta=meta(D/'aggregate-output/task-matrix.json')))
sys.stdout.buffer.write(b);sys.stdout.buffer.flush()
raise SystemExit(0 if result.get('passed') is True else 1)
