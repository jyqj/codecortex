import hashlib
import json
from pathlib import Path
import re
import subprocess

out = Path(__file__).resolve().parent
root = out.parent / 'codecortex-runtime-followup-sparse'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*argv): return subprocess.check_output(['git', '-C', str(root), *argv], text=True).strip()
commit = git('rev-parse', 'HEAD')
assert commit == 'd5d4d570d97b59cda29a55251db875235ff6e507'
assert git('status', '--porcelain', '--untracked-files=all') == ''
paths = ['scripts/p8_runtime.py', 'scripts/tests/test_p8_runtime.py']
assert git('diff-tree', '--no-commit-id', '--name-only', '-r', commit).splitlines() == paths
expected = ['1e458c6fd0bd15b2825651f5a40bd2b5889b7d64d16a0fe99d4c81d9c25026b4',
            '9bdfd77ee40a314c955db9a70472923bda0ebca218c2612c25caba9c88f815a0']
for name, digest in zip(paths, expected):
    assert sha(root / name) == digest
    assert hashlib.sha256(subprocess.check_output(['git', '-C', str(root), 'show', commit + ':' + name])).hexdigest() == digest
raw = (out / 'all-python-final.stderr').read_text()
assert re.search(r'Ran 356 tests in 56\.978s\s+OK\s*$', raw)
assert not re.search(r'^.* \.\.\. (FAIL|ERROR|skipped)', raw, re.MULTILINE)
red = (out / 'red-fixed-controls.stderr').read_text()
assert re.search(r'Ran 3 tests in [0-9.]+s\s+FAILED \(failures=3\)', red)
inventory = {}
for path in sorted(out.rglob('*')):
    if path.is_file() and path.name != 'validation-receipt.json':
        assert not path.is_symlink()
        inventory[path.relative_to(out).as_posix()] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
receipt = {
    'schema_version': 1, 'status': 'passed_python_controls',
    'scope': 'Two-file runtime repair; explicit protocol fakes and real executor threads, not product evidence or TODO closure',
    'source_commit': commit, 'parent_commit': git('rev-parse', commit + '^'),
    'source_tree': git('rev-parse', commit + '^{tree}'),
    'source_files': dict(zip(paths, expected)), 'source_matches_committed_blobs': True,
    'checks': [
        {'argv': ['python', '-B', '-m', 'unittest', 'discover', '-s', 'scripts/tests', '-p', 'test_p8_*.py', '-v'],
         'exit_code': 0, 'tests': 356, 'failed': 0, 'errors': 0, 'skipped': 0, 'elapsed_seconds': 56.978,
         'stdout': 'all-python-final.stdout', 'stderr': 'all-python-final.stderr'},
        {'scope': 'Fixed follow-up tests against immutable original parent runtime', 'exit_code': 1,
         'tests': 3, 'expected_failures_observed': 3, 'stdout': 'red-fixed-controls.stdout',
         'stderr': 'red-fixed-controls.stderr', 'runner': 'reproduce_parent_controls.py'},
        {'scope': 'Original eight runtime controls plus six new protocol controls', 'exit_code': 0,
         'tests': 14, 'elapsed_seconds': .954, 'stdout': 'green-final.stdout', 'stderr': 'green-final.stderr'},
        {'argv': ['git', 'diff', '--check'], 'exit_code': 0}],
    'preserved_unsuccessful_attempts': [
        {'stderr': 'all-python.stderr', 'tests': 337, 'errors': 6,
         'reason': 'Sparse checkout omitted three existing small fixture/definition inputs; no product failure'},
        {'stderr': 'all-python-complete.stderr', 'tests': 356, 'errors': 5,
         'reason': 'Test process began before sparse fixture restoration reached early external-candidate setup'}],
    'behavior': [
        'Oracle difference exit 1 retains completed terminal rows, statistics and summary as failed observation 1; infrastructure exit 2 remains 2',
        'Offering and worker exceptions use the existing cancellation/kill/70-second drain before sealing; original 180/70/35/60 limits retained',
        'Raw budget exhaustion can leave raw terminal rows missing; report retains terminal total and canceled-row retention errors without claiming raw completeness',
        'Unconfirmed worker, sampler, process or transport shutdown yields explicit unsealed_owned_writers with no raw digest or artifact seal',
        'Normal original drain-deadline control retains all 60 unique terminal IDs, including 59 canceled queued operations'],
    'limitations': ['No Cargo compilation or product load executed for this Python repair',
                    'No final new SOURCE/GitHub CI or source approval is claimed',
                    'Prior published G and its original evidence identities remain unchanged'],
    'evidence_inventory': inventory,
}
(out / 'validation-receipt.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
print(json.dumps({'receipt': str(out / 'validation-receipt.json'), 'sha256': sha(out / 'validation-receipt.json'),
                  'files': len(inventory), 'bytes': sum(v['bytes'] for v in inventory.values())}))
