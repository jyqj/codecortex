def stable_00447():
    return 447
