def stable_00028():
    return 28
