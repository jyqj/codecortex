"""Actual old-candidate engineering samples, never the final N=30 population."""
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/2eaa00d0f93a/codecortex')
OUT = Path('/workspace/scratch/2eaa00d0f93a/validation-scale-20261009')
sys.path.insert(0, str(ROOT / 'scripts'))
from p7_build_identity import source_snapshot, file_sha256, json_bytes
import p8_scale_matrix as matrix

binary = OUT / 'p8-scale-99f9574'
if not binary.exists():
    shutil.copy2('/workspace/scratch/2eaa00d0f93a/target/release/p8-scale', binary)
for name in ('p8_scale_matrix.py', 'p7_build_identity.py'):
    destination = OUT / ('99f9574-' + name)
    if not destination.exists():
        shutil.copy2(ROOT / 'scripts' / name, destination)

for scale in [int(value) for value in sys.argv[1:]]:
    out = OUT / f'preflight-{scale}-one-global-sample'
    out.mkdir()
    before = source_snapshot(ROOT)
    (out / 'source-before.json').write_bytes(json_bytes(before))
    command = [str(binary), '--profile', 'release', '--files', str(scale), '--repetitions', '30',
               '--shard-index', '0', '--shard-count', '30', '--batch-sizes', '1,10,100,1000',
               '--fanouts', '1,4,16,64,128', '--dirty-budget', '8', '--max-resume-builds', '128',
               '--deadline-ms', '1800000', '--max-output-bytes', str(512 * 1024 * 1024),
               '--output', str(out / 'native')]
    if scale != 1000:
        command += ['--skip-fanout']
    record = {'kind': 'engineering_preflight_one_global_sample', 'status': 'failed', 'command': command,
              'source_commit': before['source_commit'], 'source_manifest_sha256': before['manifest_sha256'],
              'binary_sha256': file_sha256(binary), 'driver_sha256': file_sha256(matrix.__file__),
              'started_utc': datetime.now(timezone.utc).isoformat(), 'environment': matrix.runtime_environment(),
              'release_certification': 'not_run', 'formal_final_population': False,
              'resource_scope': 'host filesystem free-space snapshots, not attributable fixture/process-tree peak'}
    (out / 'started.json').write_bytes(json_bytes(record))
    start = time.monotonic()
    free_before = shutil.disk_usage('/tmp').free
    minimum_free = free_before
    with (out / 'supervisor.stdout').open('xb') as stdout, (out / 'supervisor.stderr').open('xb') as stderr:
        child = subprocess.Popen(command, cwd=ROOT, stdout=stdout, stderr=stderr)
        while True:
            minimum_free = min(minimum_free, shutil.disk_usage('/tmp').free)
            try:
                code = child.wait(timeout=1)
                break
            except subprocess.TimeoutExpired:
                pass
    record['exit_code'] = code
    record['wall_seconds'] = time.monotonic() - start
    record['filesystem_free_bytes_before'] = free_before
    record['filesystem_free_bytes_minimum_sampled'] = minimum_free
    after = source_snapshot(ROOT)
    (out / 'source-after.json').write_bytes(json_bytes(after))
    record['source_unchanged'] = before == after
    try:
        assert code == 0
        assert before == after
        assert record['binary_sha256'] == file_sha256(binary)
        plan = matrix.read_json(out / 'native/plan.json')
        report = matrix.read_json(out / 'native/report.json')
        inspected = matrix.inspect_raw(out / 'native/raw.jsonl', plan)
        assert inspected['engine']['engine_head_observed'] == before['source_commit']
        assert inspected['engine']['eval_debug_assertions'] is False
        assert inspected['engine']['binary_digest'] == matrix.native_digest(binary, binary)
        assert report['raw_digest'] == matrix.native_digest(binary, out / 'native/raw.jsonl')
        assert report['plan_digest'] == matrix.native_digest(binary, out / 'native/plan.json')
        assert report['worker_binary_unchanged'] is True
        assert report['summary']['sample_count'] == len(inspected['measurements']) == (14 if scale == 1000 else 9)
        assert report['shard_only'] is True
        assert report['executed_repetition_range'] == {'start': 0, 'end': 1}
        assert report['release_certification'] == 'not_run'
        (out / 'raw-replayed.json').write_bytes(json_bytes(inspected))
        record.update(status='passed', native_status=report['status'], raw_bytes=(out / 'native/raw.jsonl').stat().st_size,
                      sample_count=len(inspected['measurements']), engine=inspected['engine'])
    except Exception as error:
        record['error'] = repr(error)
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    record['files'] = matrix.inventory(out)
    (out / 'control.json').write_bytes(json_bytes(record))
    print(json.dumps({'scale': scale, **{key: record.get(key) for key in
                     ('status', 'exit_code', 'error', 'wall_seconds', 'raw_bytes', 'sample_count',
                      'source_unchanged', 'filesystem_free_bytes_before', 'filesystem_free_bytes_minimum_sampled')}}, indent=2), flush=True)
    if record['status'] != 'passed':
        raise SystemExit(1)
