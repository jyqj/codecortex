import hashlib, importlib.util, json, sys, traceback
from pathlib import Path
BASE=Path(__file__).resolve().parent
OUT=BASE/'raw/37902429727/11603522248/attempt-03'
SCRIPT=BASE/'published-preparation/intake_once.v2.py'
assert hashlib.sha256(SCRIPT.read_bytes()).hexdigest()=='61f4ae48bc84dbc9f90862a80d06a8268ec4aa93f83c75582b716bc32f4c3369'
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('receiver_v2_unchanged',SCRIPT)
v2=importlib.util.module_from_spec(spec);spec.loader.exec_module(v2)
receipt={'started_at':v2.utc(),'receiver_v2_sha256':v2.sha(SCRIPT),'transport':'Root authorized prepare_materialize workspace placement of original resolved GitHub artifact file_id','file_id':'file_0000000051b481f78417512daf5749e6','new_download_requested':False,'measurement_or_todo_credit':False}
code=1
try:
 inputs=json.loads((OUT.parent/'attempt-01/connector-inputs.json').read_text())
 binding=v2.checked_binding(BASE/'actual-run-37902429727/receiver-binding.actual-run.json')
 run=json.loads(inputs['run_before']['content']);v2.verify_run(run,binding)
 matches=[x for x in json.loads(inputs['artifact_list']['content'])['artifacts'] if x['id']==11603522248]
 assert len(matches)==1
 meta=matches[0]
 assert meta['workflow_run']['id']==binding['run_id'] and meta['workflow_run']['head_sha']==binding['source_G'] and not meta['expired']
 assert meta['name']=='p8-scale-build-37902429727'
 original=OUT/'p8-scale-build-37902429727-original.zip'
 digest,verified=v2.verify_zip_identity(original,meta,OUT)
 members=v2.extract_original(original,OUT/'extracted')
 v2.write_new(OUT/'members.json',{'members':members,'total_uncompressed_bytes':sum(x.get('bytes',0) for x in members)})
 assert v2.sha(original)==digest
 receipt.update(status='transport_bytes_verified_extracted_post_run_get_pending',zip_sha256=digest,github_digest_verified=verified,member_count=len(members),total_uncompressed_bytes=sum(x.get('bytes',0) for x in members),semantic_validation='pending')
 code=0
except Exception as error:
 receipt.update(status='failed_retained',error=repr(error));traceback.print_exc()
receipt.update(finished_at=v2.utc(),actual_exit=code)
v2.write_new(OUT/'materialized-intake-receipt.json',receipt)
print(json.dumps(receipt))
sys.exit(code)
