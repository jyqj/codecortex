def stable_00126():
    return 126
