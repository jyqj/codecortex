#!/usr/bin/env python3
"""Package reviewed immutable observations; no product or task mutations."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

RAW = Path(__file__).resolve().parent
REPO = RAW.parent / 'codecortex-historical-v2'
NAME = 'main-legacy-ci-37661087144-20261007'
DEST = REPO / 'artifacts/checkpoints' / NAME
PREFIX = 'artifacts/checkpoints/' + NAME

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def jbytes(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()

def load(name):
    return json.loads((RAW / name).read_bytes())

def save(name, value):
    (RAW / name).write_bytes(jbytes(value))

def main():
    run, index, source, cross = map(load, ['main-run-audit.json', 'step-and-test-index.json', 'git-source-binding.json', 'p7-cross-binding-review.json'])
    assert run['conclusion'] == 'success' and source['P7_013_original_conditions_unchanged']
    assert source['current_P7_012_dependency'] == 'done'
    source_commit = source['source_commit']
    review = {
        'schema_version': 1, 'reviewer': '/root/ci_history_review',
        'decision': 'accepted_actual_main_legacy_ci_execution_evidence', 'blockers': [],
        'source_commit': source_commit, 'source_tree': source['source_tree'], 'PR_head': source['PR_head'],
        'run_id': run['run_id'], 'run_attempt': 1, 'event': 'push', 'run_url': run['run_url'],
        'run_conclusion': 'success', 'all_three_job_checkouts_match_fixed_main': True,
        'job_checkouts': run['job_checkouts'],
        'actual_toolchains': {'check': 'rustc 1.99.0 (b940084d7 2026-09-28), original stable selector', 'msrv': 'rustc 1.95.0, compile checks only', 'separate_P7_jobs': 'rustc 1.95.0; independently reviewed P7 execution evidence'},
        'full_workflow_command_blocks_matched': 28,
        'default_all_target_compilation': 'success; compilation not counted as behavior tests',
        'rust_target_executions': run['rust_target_executions'],
        'rust_execution_totals': run['rust_results_counted_as_executions_not_unique_functions'],
        'python_suites': run['python_suites'], 'python_passed': 144,
        'step_results': [{'number': row['number'], 'name': row['name'], 'conclusion': row['conclusion'], 'rust_target_executions': row['rust_target_executions'], 'rust_results': row['rust_results']} for row in index['steps']],
        'retained_source_guard': 'Actual v9 source-integrity output confirms 776 inputs and six separately reviewed deltas; historical v2 confirms 731 packing inputs/246 evidence,708 E3 inputs/58 imports,nine unchanged helpers,current 192 tasks/four views.',
        'independently_reconstructed_git_input_count': 776,
        'independently_reconstructed_git_manifest_sha256': source['crate_manifest_sha256'],
        'git_manifest_is_not_legacy_runner_disk_artifact': True,
        'actual_product_summaries': run['products'],
        'runner_artifact_count': 0,
        'full_product_build_receipts_and_stdio_case_json_downloaded': False,
        'network_isolation': 'not_isolated_not_claimed',
        'rustsec_audit': run['rustsec_audit'],
        'parser_origin': {'author': '/root/ci_history_fix', 'copy': 'legacy_log_indexer.py', 'sha256': sha((RAW / 'legacy_log_indexer.py').read_bytes()), 'method': 'Read and invoke shared read-only parser against this independently fetched main log: exact 28 printed command blocks, FIFO Cargo stderr target / complete libtest stdout blocks, every named case count equals declared and summary counts; explicit lists excluded. No reliance on only same-second API timestamps or latest Running line.'},
        'execution_ownership': {'tests_and_products': 'GitHub Actions main run only', 'this_reviewer': 'Read-only GitHub API/log retrieval, immutable Git reconstruction, actual log parsing and scoped acceptance analysis', 'product_or_test_reruns_by_reviewer': 0},
        'evidence': {'complete_index': 'step-and-test-index.json in raw-observations.tar.gz', 'source_map': 'git-source-binding.json in raw-observations.tar.gz', 'related_P7_013_results': 'p7-013-related-legacy-results.json', 'run_API_and_three_original_logs': 'raw-observations.tar.gz'},
        'limits': ['Totals are executions; repeated commands/ignored observations remain separate, not unique functions.', 'The original failed legacy run37653732411 and all skipped later steps remain historical failure evidence.', 'Private default/semantic product digests are actual printed summaries; full runner build receipts, binaries and stdio observation files were not uploaded.', 'This legacy workflow did not set P7_017_NETWORK_POLICY=process_seccomp_deny_network; it does not replace the earlier local P7-017 isolated failures or close full P7-017.', 'No full G7, live provider, quality, cost, crash matrix, resource tail or release acceptance follows from this CI scope.'],
        'task_state_at_review': {'task_sha256': source['current_task_sha256'], 'counts': source['current_counts'], 'unfinished': 40, 'task_changes_by_reviewer': False},
    }
    save('independent-review.json', review)
    original = load('p7-013-acceptance-reconciliation-20261007.json')
    clauses = []
    for obligation in original['applicable_obligations']:
        clauses.append({'requirement': obligation['requirement'], 'authority': obligation['authority'],
                        'current_acceptance': 'accepted_current_engineering_scope',
                        'bounded_evidence': obligation['evidence_kind'],
                        'named_tests': obligation['expected_current_tests'],
                        'current_execution_binding': 'Original 58 identities each passed once in each separate PR/main P7 run; related original main CI regression executions are indexed with source and command ownership.'})
    p7_prefix = 'artifacts/checkpoints/pr144-final-p7-ci-20261007'
    acceptance = {
        'schema_version': 1, 'reviewer': '/root/ci_history_review', 'task': 'P7-013',
        'decision': 'accept_current_engineering_scope_under_original_conditions', 'blockers_for_this_scope': [],
        'main_source_commit': source_commit, 'main_source_tree': source['source_tree'],
        'PR_head': source['PR_head'], 'PR_actual_P7_checkout': cross['runs']['37657882000']['actual_checkout'],
        'PR_and_main_entire_source_tree_equal': True,
        'original_task_conditions_unchanged': True, 'original_task_conditions': original['original_task_conditions'],
        'original_conditions_projection_sha256': sha(jbytes(original['original_task_conditions'])),
        'full_original_task_fields_also_compared_to_886_baseline': True,
        'current_P7_012_hard_dependency': 'done',
        'current_supported_V11_and_V15_engineering_evidence': clauses,
        'P7_execution_reviews': [
            {'run_id': 37657882000, 'job_id': 112917552850, 'event': 'pull_request', 'run_attempt': 1, 'path': p7_prefix + '/pr-independent-review.json', 'sha256': cross['runs']['37657882000']['review_sha256'], 'original_58': {'passed': 58, 'failed': 0, 'ignored': 0, 'duplicate_identities': 0}},
            {'run_id': 37661087236, 'job_id': 112928487184, 'event': 'push', 'run_attempt': 1, 'path': p7_prefix + '/main-independent-review.json', 'sha256': cross['runs']['37661087236']['review_sha256'], 'original_58': {'passed': 58, 'failed': 0, 'ignored': 0, 'duplicate_identities': 0}},
        ],
        'P7_source_and_build': {'complete_inputs': 776, 'manifest_sha256': source['crate_manifest_sha256'], 'source_before_after_each_equal': True, 'all_entries_equal_independent_fixed_Git_reconstruction': True, 'thirteen_original_source_files_equal_5af': True, 'toolchain': '1.95.0', 'private_Cargo_target_and_build_dir': '/home/runner/work/_temp/p7-engineering-cargo', 'schedule': 'Original libtest schedule; no --test-threads/RUST_TEST_THREADS override or retries within each reviewed P7 job', 'binary_sha256': None, 'unrecorded_binary_digest_not_fabricated': True},
        'legacy_execution_review': {'run_id': 37661087144, 'job_id': 112928486870, 'run_attempt': 1, 'event': 'push', 'path': PREFIX + '/independent-review.json', 'sha256': sha((RAW / 'independent-review.json').read_bytes()), 'source': source_commit, 'all_related_original_regressions_passed': True, 'HTTP_status_stdio': {'passed': 17, 'failed': 0, 'ignored': 0}, 'P5_B': {'passed': 17, 'normal_run_ignored': 1, 'explicit_stdio_passed': 1}, 'P5_C': {'passed': 32, 'normal_run_ignored': 1, 'explicit_stdio_passed': 1}, 'P5_D': {'passed': 12, 'normal_run_ignored': 1, 'explicit_stdio_passed': 1}, 'stdio_counts_already_in_pass_totals': True},
        'independent_cross_review': {'path': PREFIX + '/p7-cross-binding-review.json', 'sha256': sha((RAW / 'p7-cross-binding-review.json').read_bytes()), 'scope': 'This reviewer independently checked both P7 actual case/summary raw log lines and all source entries; it did not rerun tests or reassign ci_evidence authorship.'},
        'query_inline_network_decision': 'Existing explicit default false opt-in, semantic-http+enabled+network opt-in+allow_query_network gates, one attempt, absolute remaining deadline and capacity/cost caps; original configuration and production bytes unchanged.',
        'old_evidence_preserved': original['historical_observations'],
        'old_failed_legacy_run': {'run_id': 37653732411, 'status': 'failure', 'later_steps': 'skipped in that run; new main success is a separate execution'},
        'separate_not_accepted_tasks': original['not_required_to_complete_P7_013'],
        'conditional_future_V11': 'Original real supported semantic successor / migration / old-pin / reopen obligations remain not_run_cross_build; no invented successor or blanket future waiver.',
        'live_authorization': 'D1+D2 unchanged; P7-018 remains blocked, no paid provider/source egress or live effect claim.',
        'task_state': {'current_status_in_reviewed_source': 'in_progress', 'state_changed_by_this_reviewer': False, 'remaining_at_review': 40, 'remaining_after_root_records_acceptance_and_changes_only_P7_013': 39, 'expected_counts_after': {'done': 153, 'todo': 37, 'in_progress': 1, 'blocked': 1}, 'next_task_after_root_update': 'P7-014'},
        'final_action_for_root': 'Record current engineering acceptance in the authoritative task evidence/notes and update P7-013 to done; preserve original definitions, existing failures and unrelated task states. This review itself does not edit tasks.',
    }
    save('p7-013-acceptance-review.json', acceptance)
    save('audit-preparation-notes.json', {'schema_version': 1, 'audit_attempt': 'The first local Git-binding analysis asserted that all immutable task fields equalled the prior reconciliation projection and rejected the unequal key set before producing output. The projection intentionally omitted batch,phase,phase_name,priority,contracts_doc,benchmark_doc,rollback. The analysis was corrected to compare every immutable field to fixed886 and separately verify the prior projection; that read-only analysis then passed. No repository task/source changed, no product/test failure or retry was involved.', 'raw_log_storage': 'Decoded tool log strings are stored as UTF-8 with original BOM and terminal newline; API native JSON strings receive a final newline only. Logs are never normalized in the archive.', 'reused_worktree': {'path': 'codecortex-historical-v2', 'base': '8d88f00cae5c61d9d6760b72feeac2ca385d9c81', 'evidence_only': True, 'actual_CI_source_is_fixed_b951_not_worktree_HEAD': True}, 'cleanup': {'removed_clean_worktree': 'codecortex-main-legacy-review', 'removed_head': source_commit, 'normal_git_worktree_remove': True, 'branch_retained': True, 'released_available_bytes': 497328128}})
    if DEST.exists():
        raise RuntimeError('checkpoint already exists; refusing replacement')
    DEST.mkdir(parents=True)
    direct = ['independent-review.json', 'p7-013-acceptance-review.json', 'p7-013-related-legacy-results.json', 'p7-cross-binding-review.json']
    original_files = sorted(path for path in RAW.iterdir() if path.is_file())
    archive = DEST / 'raw-observations.tar.gz'
    with tarfile.open(archive, 'w:gz') as tar:
        for path in original_files:
            data = path.read_bytes()
            info = tarfile.TarInfo(path.name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            tar.addfile(info, io.BytesIO(data))
    for name in direct:
        shutil.copyfile(RAW / name, DEST / name)
    manifest = {'schema_version': 1, 'source_commit': source_commit, 'run_id': 37661087144,
                'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes())},
                'files': [{'path': path.name, 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes()), 'storage': 'archive', 'also_direct': path.name in direct} for path in original_files],
                'original_file_count': len(original_files), 'direct_mirrors': direct,
                'untracked_cache_directories_excluded': True,
                'archive_contents_are_original_decoded_logs_APIs_and_review_analysis_files': True}
    (DEST / 'checkpoint-files.json').write_bytes(jbytes(manifest))
    print(json.dumps({'checkpoint': str(DEST), 'original_files': len(original_files), 'archive_bytes': archive.stat().st_size,
                      'archive_sha256': manifest['archive']['sha256'], 'review_sha256': sha((DEST / 'independent-review.json').read_bytes()),
                      'P7_013_review_sha256': sha((DEST / 'p7-013-acceptance-review.json').read_bytes())}))

if __name__ == '__main__':
    main()
