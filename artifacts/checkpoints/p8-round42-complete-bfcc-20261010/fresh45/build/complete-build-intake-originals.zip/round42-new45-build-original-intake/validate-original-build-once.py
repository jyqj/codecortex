import pathlib,json,hashlib,subprocess,sys,datetime
D=pathlib.Path('/workspace/scratch/bfccb8494ba0/round42-new45-build-original-intake')
V=D/'source-exact-G2';B=D/'original-build';A=D/'validation-attempt01'
A.mkdir(exist_ok=False)
def digest(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':oct(p.stat().st_mode&0o777)}
def dump(name,value): (A/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def snapshot():
 inventory=json.loads((D/'restored-source-inventory.json').read_text())['inventory']
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=V,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=V,text=True).strip(),'index':digest(V/'.git/index'),'source':{k:digest(V/k) for k in inventory},'build':{p.relative_to(B).as_posix():digest(p) for p in B.rglob('*') if p.is_file()}}
before=snapshot();dump('inputs-before.json',before)
sys.path.insert(0,str(V/'scripts'))
import p8_task_profile_matrix as task
calls=[]
run_code=subprocess.run.__code__
def profile(frame,event,arg):
 if frame.f_code is run_code:
  cmd=frame.f_locals.get('popenargs',())
  argv=cmd[0] if cmd else frame.f_locals.get('kwargs',{}).get('args')
  if isinstance(argv,(list,tuple)) and '--hash-file' in argv:
   if event=='call':calls.append({'argv':[str(x) for x in argv],'start':datetime.datetime.now(datetime.timezone.utc).isoformat()})
   if event=='return' and isinstance(arg,subprocess.CompletedProcess):
    row=calls[-1];row.update(end=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=arg.returncode)
    for key in ['stdout','stderr']:
     raw=getattr(arg,key);assert isinstance(raw,bytes)
     name='native-hash-'+key+'.original';(A/name).write_bytes(raw)
     row[key]={'file':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 return profile
sys.setprofile(profile)
try:
 outer,built,binary=task.validate_build(B,root=V) # sole original validation invocation
finally:
 sys.setprofile(None);dump('native-hash-subprocess-original.json',calls)
result={'outer':outer,'built':built,'binary':str(binary)}
dump('original-validate-build-return.json',result)
after=snapshot();dump('inputs-after.json',after)
assert before==after,'source/build inputs changed'
assert outer['study']=={'protocol':'p8-profile-task-descriptive-v1','run_id':'38026411200','run_attempt':1}
assert outer['source_commit']==before['head']=='f97c5068d056969705e8387ba1f37d83847f5bee'
assert len(calls)==1 and calls[0]['returncode']==0
print(json.dumps(result,ensure_ascii=False,indent=2))
