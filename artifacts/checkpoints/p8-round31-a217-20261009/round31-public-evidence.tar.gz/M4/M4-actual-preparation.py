import datetime,hashlib,json,os,pathlib,re,subprocess
B=pathlib.Path('/workspace/scratch/a217aaae3bde');O=B/'p8-db-lock-observation-integration';REPO=B/'codecortex-recovered';OLD=pathlib.Path('/dev/shm/a217aaae3bde/pr180-M3-9c77-validated');VIEW=pathlib.Path('/dev/shm/a217aaae3bde/pr180-M4-832f-validated')
P='3fd980c724e3272c6d936eb066cecf478667a553';R='fe09d0ed102e717ebfe1bd4802008053814c7eff';G='832f79b8702c6cdfb567b7cf949508cd4589f286';GT='c40de30474ae9de97fb938dade9a51e6b028b7c6'
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def write(n,x):
 b=(json.dumps(x,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode();(O/n).open('xb').write(b);return {'path':str(O/n),'bytes':len(b),'sha256':sha(b)}
def inventory(ref,roots):
 out={}
 for row in git('ls-tree','-r','-z',ref,'--',*roots).split(b'\0'):
  if row:
   m,p=row.decode().split('\t');mode,kind,h=m.split();assert kind=='blob';out[p]={'mode':mode,'sha':h}
 return out
def bodies(entries):
 keys=sorted(entries); request=''.join(entries[p]['sha']+'\n' for p in keys).encode();r=subprocess.run(['git','-C',str(REPO),'cat-file','--batch'],input=request,stdout=subprocess.PIPE,check=True).stdout;pos=0;out={}
 for p in keys:
  end=r.index(b'\n',pos);h,kind,size=r[pos:end].decode().split();assert kind=='blob' and h==entries[p]['sha'];size=int(size);pos=end+1;b=r[pos:pos+size];pos+=size+1;assert oid(b)==h;out[p]=b
 assert pos==len(r);return out
plan=json.loads((O/'M4-fixed-product-composition-plan.json').read_bytes());uploads=json.loads((O/'M4-review-upload-plan.json').read_bytes());guards=json.loads((O/'M4-guard-upload-plan.json').read_bytes())
assert git('show','-s','--format=%P',P).decode().strip().split()==plan['parents'];assert git('rev-parse',P+'^{tree}').decode().strip()==plan['expected_tree']
assert git('show','-s','--format=%P',R).decode().strip()==P and git('show','-s','--format=%P',G).decode().strip()==R
assert git('rev-parse',R+'^{tree}').decode().strip()==guards['review_tree'] and git('rev-parse',G+'^{tree}').decode().strip()==GT
assert set(git('diff','--name-only',P,R).decode().splitlines())=={x['path'] for x in uploads['entries']}
assert set(git('diff','--name-only',R,G).decode().splitlines())=={x['path'] for x in guards['entries']}
assert all(s.startswith('A\t') for s in git('diff','--name-status',P,R).decode().splitlines())
actual_records=[]
for ref,rows in [(R,uploads['entries']),(G,guards['entries'])]:
 for x in rows:
  b=git('show',ref+':'+x['path']);assert b==pathlib.Path(x['source']).read_bytes() and oid(b)==x['sha'] and sha(b)==x['sha256'];actual_records.append(x)
prod=inventory(G,['crates','Cargo.toml','Cargo.lock']);rawprod=bodies(prod);pm={p:sha(b) for p,b in rawprod.items()};assert pm==plan['complete_inputs']
val=inventory(G,['scripts','.github/workflows','tests/source_integrity']);ex={'scripts/verify_reviewed_source_v15.py','scripts/reviewed-source-registry-v15.json','.github/workflows/ci.yml'};val={p:x for p,x in val.items() if p not in ex};rawval=bodies(val);vm={p:sha(b) for p,b in rawval.items()};assert vm==plan['validation_inputs']
base=inventory('7354db236c9d9850a75f31672697ae9eab44565e',['crates','Cargo.toml','Cargo.lock']);changed=git('diff','--name-only','7354db236c9d9850a75f31672697ae9eab44565e',G,'--','crates','Cargo.toml','Cargo.lock').decode().splitlines();basechanged=bodies({p:base[p] for p in changed if p in base});delta={p:{'before_sha256':sha(basechanged[p]) if p in basechanged else None,'sha256':pm[p]} for p in changed};assert delta==plan['delta']
oldguard=(OLD/'scripts/verify_reviewed_source_v15.py').read_text();newguard=git('show',G+':scripts/verify_reviewed_source_v15.py').decode()
for key in guards['pins']:
 oldguard,n=re.subn(r'^'+key+r' = ".*"$',key+' = "<PIN>"',oldguard,flags=re.M);assert n==1
 newguard,n=re.subn(r'^'+key+r' = ".*"$',key+' = "<PIN>"',newguard,flags=re.M);assert n==1
assert oldguard==newguard
free=os.statvfs('/dev/shm').f_bavail*os.statvfs('/dev/shm').f_frsize;assert free>1024**3 and not VIEW.exists()
subprocess.run(['git','-C',str(REPO),'worktree','add','--detach','--no-checkout',str(VIEW),G],check=True)
subprocess.run(['git','-C',str(VIEW),'config','--worktree','core.sparseCheckout','true'],check=True);subprocess.run(['git','-C',str(VIEW),'config','--worktree','core.sparseCheckoutCone','false'],check=True)
sp=pathlib.Path(subprocess.check_output(['git','-C',str(VIEW),'rev-parse','--git-path','info/sparse-checkout']).decode().strip());sp.parent.mkdir(parents=True,exist_ok=True);sp.write_text('/*\n!/artifacts/\n')
subprocess.run(['git','-C',str(VIEW),'read-tree','-m','-u','HEAD'],check=True)
oldbefore=json.loads((O/'M3-independent-inputs-after.json').read_text());linked=[];copied=[]
for p,x in oldbefore.items():
 src=OLD/p;assert src.is_file() and not src.is_symlink() and sha(src.read_bytes())==x['sha256'];dest=VIEW/p
 if dest.exists():
  if dest.read_bytes()!=src.read_bytes():continue
  dest.unlink()
 else:
  expected=git('rev-parse',G+':'+p).decode().strip();assert expected==x['git_blob'];dest.parent.mkdir(parents=True,exist_ok=True)
 os.link(src,dest);linked.append(p)
core=uploads['entries'][0];dest=VIEW/core['path'];assert not dest.exists();dest.parent.mkdir(parents=True,exist_ok=True);dest.open('xb').write(pathlib.Path(core['source']).read_bytes());os.chmod(dest,0o644);copied.append(core['path'])
before={}
paths=set(prod)|set(val)|set(ex)|set(oldbefore)|{core['path']}
for p in sorted(paths):
 f=VIEW/p;assert f.is_file() and not f.is_symlink();b=f.read_bytes();h=git('rev-parse',G+':'+p).decode().strip();assert oid(b)==h;before[p]={'bytes':len(b),'sha256':sha(b),'git_blob':h,'mode':format(f.stat().st_mode&0o777|0o100000,'o')}
before_ref=write('M4-independent-inputs-before.json',before)
for p,x in oldbefore.items():assert sha((OLD/p).read_bytes())==x['sha256']
assert subprocess.check_output(['git','-C',str(VIEW),'rev-parse','HEAD']).decode().strip()==G
proof={'schema':'M4-actual-composition-and-RAM-preparation-v1','product':P,'review':R,'guard':G,'tree':GT,'parents_exact':True,'P_to_R_exact_new_artifact_count':len(uploads['entries']),'R_to_G_exact_guard_paths':[x['path'] for x in guards['entries']],'actual_readback_records':actual_records,'source_count':len(pm),'BASE_delta_count':len(delta),'validation_count':len(vm),'complete_inputs':pm,'delta':delta,'validation_inputs':vm,'product_manifest_sha256':sha((json.dumps(pm,indent=2,sort_keys=True)+'\n').encode()),'validation_manifest_sha256':sha((json.dumps(vm,indent=2,sort_keys=True)+'\n').encode()),'four_pins_only':guards['pins'],'guard_algorithm_unchanged':True,'source_view':str(VIEW),'old_M3_view_unchanged':True,'hardlinked_input_count':len(linked),'hardlinked_paths':linked,'exclusive_new_core_paths':copied,'before':before_ref,'ram_free_before':free,'native_or_compile':False,'source_CLI':'not_yet_run','formal_completion':False,'remaining_todos':29,'prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
print(json.dumps(write('M4-actual-composition-and-source-preparation.json',proof)),flush=True)
