def stable_00025():
    return 25
