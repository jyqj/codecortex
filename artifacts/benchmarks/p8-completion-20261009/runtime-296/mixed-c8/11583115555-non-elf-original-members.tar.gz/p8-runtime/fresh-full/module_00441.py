def stable_00441():
    return 441
