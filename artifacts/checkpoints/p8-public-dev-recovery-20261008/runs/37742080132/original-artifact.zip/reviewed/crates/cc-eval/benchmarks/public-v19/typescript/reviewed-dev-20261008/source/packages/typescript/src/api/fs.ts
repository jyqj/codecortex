import getExePath from "#getExePath";
import { dirname } from "node:path";
import type {
    RootedDirectoryPath,
    RootedFilePath,
    RootedPath,
} from "../ast/index.ts";
import { normalizePath } from "./path.ts";
import type {
    RequestDirectoryEntries,
    RequestFileSystem,
    RequestSymlink,
} from "./proto.generated.ts";
import {
    type DocumentIdentifier,
    resolveFileName,
} from "./proto.ts";

export interface FileSystemEntries {
    files: string[];
    directories: string[];
    /** Names from `files` or `directories` that are symbolic links. */
    symlinks: string[] | undefined;
}

export interface FileSystemStat {
    /** POSIX-style file mode, matching Node.js `fs.Stats.mode`. */
    mode: number;
    /** File size in bytes, matching Node.js `fs.Stats.size`. */
    size: number;
    /** Last modification time, matching Node.js `fs.Stats.mtime`. */
    mtime: Date;
}

const useOS: unique symbol = Symbol("useOS");
const identity: unique symbol = Symbol("identity");
const fakeStat: unique symbol = Symbol("fakeStat");
const noop: unique symbol = Symbol("noop");
const error: unique symbol = Symbol("error");

export const serverFS: {
    /** Delegate the configured operation, or the current callback invocation, to the server's operating-system filesystem. */
    readonly useOS: typeof useOS;
    /** Use the input path as its own real path without consulting a filesystem. Valid only for `realpath`. */
    readonly identity: typeof identity;
    /** Synthesize stat information from `directoryExists` and `fileExists`. Valid only for `stat`. */
    readonly fakeStat: typeof fakeStat;
    /** Ignore writes without invoking a callback or writing to the server's operating-system filesystem. Valid only for `writeFile`. */
    readonly noop: typeof noop;
    /** Panic if the configured operation, or current callback invocation, reaches the server filesystem. */
    readonly error: typeof error;
} = {
    useOS: useOS,
    identity: identity,
    fakeStat: fakeStat,
    noop: noop,
    error: error,
};

export interface FileSystemCallbacks {
    directoryExists:
        | ((directoryName: RootedDirectoryPath) => boolean | typeof serverFS.useOS | typeof serverFS.error)
        | typeof serverFS.useOS
        | typeof serverFS.error;
    fileExists:
        | ((fileName: RootedFilePath) => boolean | typeof serverFS.useOS | typeof serverFS.error)
        | typeof serverFS.useOS
        | typeof serverFS.error;
    getAccessibleEntries:
        | ((directoryName: RootedDirectoryPath) => FileSystemEntries | typeof serverFS.useOS | typeof serverFS.error)
        | typeof serverFS.useOS
        | typeof serverFS.error;
    /**
     * Read a file's content.
     * - Return the file content as a `string` (including `""` for empty files).
     * - Return `undefined` to indicate the file does not exist.
     * - Return {@link serverFS.useOS} to fall back to the server's operating-system filesystem.
     */
    readFile:
        | ((fileName: RootedFilePath) => string | undefined | typeof serverFS.useOS | typeof serverFS.error)
        | typeof serverFS.useOS
        | typeof serverFS.error;
    /** Relative results are resolved against the queried path's directory by the server. */
    realpath:
        | ((path: RootedPath) => string | typeof serverFS.useOS | typeof serverFS.identity | typeof serverFS.error)
        | typeof serverFS.useOS
        | typeof serverFS.identity
        | typeof serverFS.error;
    stat:
        | ((path: RootedPath) => FileSystemStat | undefined | typeof serverFS.useOS | typeof serverFS.fakeStat | typeof serverFS.error)
        | typeof serverFS.useOS
        | typeof serverFS.fakeStat
        | typeof serverFS.error;
    writeFile:
        | ((path: RootedFilePath, content: string) => void | typeof serverFS.useOS | typeof serverFS.noop | typeof serverFS.error)
        | typeof serverFS.useOS
        | typeof serverFS.noop
        | typeof serverFS.error;
    removeFile:
        | ((path: RootedPath) => void | typeof serverFS.useOS | typeof serverFS.noop | typeof serverFS.error)
        | typeof serverFS.useOS
        | typeof serverFS.noop
        | typeof serverFS.error;
}

export interface CreateFileSystemOptions {
    /** Complete directory listings. Full filesystems derive these from `files` when omitted. */
    directories?: Record<string, RequestDirectoryEntries> | undefined;
    symlinks?: Record<string, RequestSymlink> | undefined;
    /** Files or directory trees hidden from an underlying snapshot or host filesystem. */
    removedPaths?: readonly string[] | undefined;
}

export interface CreateFileSystemWithLibOptions extends CreateFileSystemOptions {
    /** Default library directory used by a custom or non-embedded compiler executable. */
    defaultLibraryPath?: string | undefined;
}

/**
 * Files supplied to a request filesystem. String identifiers are file names;
 * use `{ uri }` when supplying a document URI so it can be decoded correctly.
 */
export type RequestFileEntries = readonly (readonly [id: DocumentIdentifier, content: string])[];

/** Creates a full request filesystem. The server derives directory listings when omitted. */
export function createFileSystem(
    files: RequestFileEntries,
    options: CreateFileSystemOptions = {},
): RequestFileSystem {
    return createRequestFileSystem("full", files, options);
}

/**
 * Creates a full request filesystem with the compiler's default library
 * directory mounted read-only through the host filesystem.
 */
export function createFileSystemWithLib(
    files: RequestFileEntries,
    options: CreateFileSystemWithLibOptions = {},
): RequestFileSystem {
    const defaultLibraryPaths = options.defaultLibraryPath
        ? [normalizePath(options.defaultLibraryPath)]
        : [normalizePath("bundled:///libs")];
    if (!options.defaultLibraryPath) {
        try {
            defaultLibraryPaths.push(normalizePath(dirname(getExePath())));
        }
        catch {
            // A socket-connected embedded server can provide bundled libs without
            // a locally installed compiler executable.
        }
    }
    const symlinks = { ...options.symlinks };
    for (const defaultLibraryPath of defaultLibraryPaths) {
        symlinks[defaultLibraryPath] ??= { target: defaultLibraryPath, host: true };
    }
    return createRequestFileSystem("full", files, {
        symlinks,
        directories: options.directories,
        removedPaths: options.removedPaths?.length ? options.removedPaths : undefined,
    });
}

/** Creates a request filesystem layer, merging base directory listings when omitted. */
export function createFileSystemLayer(
    files: RequestFileEntries,
    options: CreateFileSystemOptions = {},
): RequestFileSystem {
    return createRequestFileSystem("layer", files, options);
}

function createRequestFileSystem(
    kind: RequestFileSystem["kind"],
    files: RequestFileEntries,
    options: CreateFileSystemOptions,
): RequestFileSystem {
    const normalizedFiles = new Map<string, string>();
    for (const [id, content] of files) {
        const fileName = normalizePath(resolveFileName(id));
        if (normalizedFiles.has(fileName)) {
            throw new Error(`Duplicate request filesystem path: ${fileName}`);
        }
        normalizedFiles.set(fileName, content);
    }
    const fileRecord = Object.fromEntries(normalizedFiles);
    return {
        kind,
        files: fileRecord,
        directories: options.directories,
        symlinks: options.symlinks,
        removedPaths: options.removedPaths?.length ? [...options.removedPaths] : undefined,
    };
}
