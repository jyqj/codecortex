"""Produce a descriptive report from accepted returns and already extracted phase facts."""
import pathlib,json,hashlib,decimal,datetime
R=pathlib.Path('/workspace/scratch/bfccb8494ba0');D=pathlib.Path(__file__).resolve().parent
cat=json.loads((R/'round46-final45-catalog-and-aggregate-preparation/accepted-43-original-receipt-custody-catalog.json').read_text())
for directory,prefix in [('round47-batch100-100k-original-intake','batch100-100k'),('round47-body-100k-original-intake','body-100k')]:
    base=R/directory
    extra=json.loads((base/(prefix+'-original-intake-review.json')).read_text())
    manifest=json.loads((base/'sealed/upload-manifest.actual.json').read_text())
    leaf=next(x for x in manifest['files'] if x['local_path'].endswith('/'+prefix+'-original-intake-review.json'))
    for c in extra['catalog']:cat['ordered_cells'].append(dict(c,accepted_report={k:leaf[k] for k in ['git_blob','repository_path','sha256']}))
def meta(p,b):return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
keys=['group','sample','engine_ms','index_wall_us','outer_incremental_wall_us','whole_fixture_wall_us','full_control_ms','parity_wall_us','builds','first_build_incomplete','build_timing','full_control_build_timing','phases','counts','process_snapshot']
rows=[];cells=[];envs={}
for number,c in enumerate(sorted(cat['ordered_cells'],key=lambda x:x['slot']),1):
    slot=c['slot'];p=pathlib.Path(c['original_result']['local_path']);b=p.read_bytes();v=json.loads(b)
    assert hashlib.sha256(b).hexdigest()==c['original_result']['sha256']
    fp=D/f'phase-facts-{slot[0]}-{slot[1]}.json';fb=fp.read_bytes();f=json.loads(fb)
    env=f'E{number:02d}'
    envs[env]={'slot':slot,'environment':v['environment'],'engine_cpu_parallelism':v['engine'].get('cpu_parallelism'),'measurement_environment':v['measurement_environment'],'profile_environment':v['profile_environment']}
    roles=['fanout'] if slot[0]=='fanout' else ['setup','mutation']
    cells.append({'slot':slot,'n':1,'environment_ref':env,'original_result':c['original_result'],'original_task_receipt_sha256':c['original_task_receipt_sha256'],'acceptance_report':c['accepted_report'],'registered_plan':v['plan'],'phase_fact_source':meta(fp,fb)})
    for index,(role,m) in enumerate(zip(roles,v['measurements'])):
        counts=f['count_summaries'][role]
        control=f['count_summaries'][role+'_full_control']
        events=[e for e in f['completion_and_parity_events'] if e['role']==role]
        row={'slot':slot,'role':role,'n':1,'environment_ref':env,'original':{k:m[k] for k in keys if k in m},'original_result_pointer':dict(**c['original_result'],json_pointer='/measurements/'+str(index)),'counts_over_original_reports':counts,'full_control_counts_over_original_reports':control,'original_completion_events':events,'phase_fact_source':meta(fp,fb)}
        if role=='fanout':
            row['fanout_setup_reports']={k:x for k,x in f['count_summaries'].items() if k.startswith('fanout_setup_')}
            row['fanout_actual_fixture_files']=slot[1]+1
            row['fanout_plan_capacity_files']=v['plan']['files'][0]
            row['initial_evidence_equal']=m['initial_evidence']['equal']
        rows.append(row)
assert len(cells)==45 and len(rows)==85 and len({(tuple(x['slot']),x['role']) for x in rows})==85
assert all(x['counts_over_original_reports']['files_parsed_sum'] is not None and x['counts_over_original_reports']['selected_dependents_sum'] is not None for x in rows)
out={'schema':'new45-descriptive-results-scratch-draft-v2','apply':False,'publication':'Scratch draft; all individual cells accepted, original Actions 42-input aggregate failed; final closure awaits explicit original aggregate recovery result.','recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':cat['source'],'run_id':cat['run_id'],'attempt':1,'accepted_cells':45,'accepted_records':85,'expected_cells':45,'expected_records':85,'missing_slots':[],'original_aggregate':{'status':'failed','job_id':114158378120,'accepted_inputs':42,'missing_slots':[['batch_100',100000,0],['body',100000,0],['config',100000,0]],'recovery_aggregate_executed':False,'scope':'Root original Actions matrix/log received; this descriptive draft does not replace its failure.'},'roles':{'setup':40,'mutation':40,'fanout':5},'preselected_cold_subset':[{'slot':x['slot'],'role':'setup'} for x in rows if x['role']=='setup' and x['slot'][0]=='no_op'],'environments':envs,'cells':cells,'observations':rows,'units':{'engine_ms':'ms','index_wall_us':'us','outer_incremental_wall_us':'us','whole_fixture_wall_us':'us; entire fanout fixture, not an ordinary index interval','full_control_ms':'ms','parity_wall_us':'us','build_timing':'us; nested prepare_snapshot/full_staging are not added to prepare or total','phases':'ms; original emitted phase aggregate','counts':'Sums of emitted report counters, including repeated work. Not distinct files unless original report says so.'},'scope':['N1 per exact registered cell, complete original environment retained. Hostname alone is not a machine identity.','No cross-host causal claims, pooled statistics, stable tails, p99 or fitted curve.','Five no_op cold setup records are part of forty setups: total85, never90.','Fanout actual fixture has N+1 files; plan files1000 is capacity identity.','Original vector state remains disabled with null count; no vector performance claim.','Raw-phase facts were extracted once for reporting, separately from original validation. No original predicate, source, deadline, budget or sample changed.'],'draft_projection_calls':{'validator':0,'aggregate':0,'combine':0,'ELF':0,'CRC':0,'raw_reread':0},'task_credit':0}
def sec(v,n):return '—' if v is None else format(decimal.Decimal(v)/decimal.Decimal(n),'f')
def label(x):return x['slot'][0]+'/'+str(x['slot'][1])
def val(x):return 'unavailable' if x is None else str(x)
lines=['# 新45格原始结果：N=1描述性草表','','固定source `'+cat['source']+'`，run `38026411200` / attempt `1`。现45/45格、85/85条记录逐格已接受；原Actions aggregate只收到42输入而失败，恢复聚合尚未执行。本文是scratch草表，不授任务或发布完成信用。','','每条记录以(slot,role)唯一识别。原整数在JSON保存，表中秒值是十进制精确单位换算，不是新测量。各格CPU/环境独立保留；相同host字符串不意味着同一台机器。','','## Mutation及fanout单点','','| 格 | N | 环境 | engine s | index s | outer inc s | fixture s | full s | parity s | builds | resumed |','|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|']
for x in rows:
    if x['role']=='setup':continue
    m=x['original'];c=x['counts_over_original_reports']
    lines.append('| '+' | '.join([label(x),'1',x['environment_ref'],sec(m.get('engine_ms'),1000),sec(m.get('index_wall_us'),1000000),sec(m.get('outer_incremental_wall_us'),1000000),sec(m.get('whole_fixture_wall_us'),1000000),sec(m.get('full_control_ms'),1000),sec(m.get('parity_wall_us'),1000000),str(m['builds']),val(c['resumed_true_report_count'])])+' |')

lines+=['','Fanout的fixture wall包含fresh setup及初末parity；缺独立index/parity wall不补造。其真实文件数依次2/5/17/65/129，计划files1000只表示容量配置。','','## Setup角色（no_op五点是预选cold子集）','','| 格 | 环境 | engine s | index s | full s | parity s | files | symbols | chunks |','|---|---|---:|---:|---:|---:|---:|---:|---:|']
for x in rows:
    if x['role']!='setup':continue
    m=x['original'];c=m['counts'];lines.append('| '+' | '.join([label(x)+(' [cold子集]' if x['slot'][0]=='no_op' else ''),x['environment_ref'],sec(m['engine_ms'],1000),sec(m['index_wall_us'],1000000),sec(m['full_control_ms'],1000),sec(m['parity_wall_us'],1000000),str(c['files']),str(c['symbols']),str(c['chunks'])])+' |')
lines+=['','## 原phase值（毫秒，角色独立）','','| 格/角色 | scan_diff | parse | analysis | resolve | write | postprocess |','|---|---:|---:|---:|---:|---:|---:|']
for x in rows:
    p=x['original']['phases'];lines.append('| '+label(x)+'/'+x['role']+' | '+' | '.join(val(p.get(k)) for k in ['scan_diff_ms','parse_ms','analysis_ms','resolve_ms','write_ms','postprocess_ms'])+' |')
lines+=['','## 原实际工作计数与闭包','','计数是各实际build原report求和（包括重复扫描），不冒充去重文件数；原每次build计数/freshness及行SHA在phase-facts文件中。完整对照计数在JSON独立保留。','','| 格/角色 | builds | parsed | updated | scanned | skipped | selected dependents | resumed | 首complete | 末complete | full末complete |','|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|']
for x in rows:
    c=x['counts_over_original_reports'];fc=x['full_control_counts_over_original_reports'];values=[label(x)+'/'+x['role']]+[val(c[k]) for k in ['original_report_count','files_parsed_sum','files_updated_sum','files_scanned_sum','files_skipped_sum','selected_dependents_sum','resumed_true_report_count']]+[val(c['first_freshness'].get('complete')),val(c['last_freshness'].get('complete')),val(fc['last_freshness'].get('complete'))];lines.append('| '+' | '.join(values)+' |')
lines+=['','## 原build timing（微秒，保留嵌套项）','','prepare_snapshot与full_staging属于嵌套工作，不能再加进prepare/total。以下为原measurement中已汇总的值，不另求新的总时长。完整full-control timing也在JSON原样保存。','','| 格/角色 | prepare | commit_write | postprocess_compute | postprocess_apply | between | total | prepare_snapshot（嵌套） | full_staging（嵌套） |','|---|---:|---:|---:|---:|---:|---:|---:|---:|']
for x in rows:
    t=x['original']['build_timing'];lines.append('| '+label(x)+'/'+x['role']+' | '+' | '.join(val(t.get(k)) for k in ['prepare_us','commit_write_us','postprocess_compute_us','postprocess_apply_us','between_stages_us','total_us','prepare_snapshot_us','full_staging_us'])+' |')
lines+=['','## 环境及出处','','| 环境 | 格 | 原host | CPU | 原CPU count |','|---|---|---|---|---:|']
for key,e in envs.items():
    v=e['environment'];lines.append('| '+' | '.join([key,e['slot'][0]+'/'+str(e['slot'][1]),v['host'],v['cpu_model'],str(v['cpu_count'])])+' |')
lines+=['','完整临时环境、source/binary/driver/build/run登记及每格return/acceptance/whole-custody出处由JSON和已发表catalog关联；不跨host拟合，不提供稳定分位数。所有setup中的vectors均原disabled/null。全部逐格值已齐；原42输入aggregate失败保留，完成明确授权的原聚合恢复后才最终封存。']
with (D/'accepted-45-descriptive-pending-aggregate-draft.json').open('x') as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
(D/'accepted-45-descriptive-pending-aggregate-draft.md').write_text('\n'.join(lines)+'\n')
receipt={'exit_code':0,'cells':45,'records':85,'missing':[],'all_original_phase_counts_mapped':True,'validator_calls':0,'aggregate_calls':0,'ELF_calls':0,'CRC_calls':0,'raw_reads_in_this_render':0,'published':False}
(D/'draft-45-render-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
