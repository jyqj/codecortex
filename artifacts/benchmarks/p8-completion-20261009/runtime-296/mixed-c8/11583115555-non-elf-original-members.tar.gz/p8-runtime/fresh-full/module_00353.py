def stable_00353():
    return 353
