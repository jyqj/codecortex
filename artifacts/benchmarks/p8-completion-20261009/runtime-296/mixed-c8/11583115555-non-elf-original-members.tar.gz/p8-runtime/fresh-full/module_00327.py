def stable_00327():
    return 327
