def stable_00023():
    return 23
