from pathlib import Path
import subprocess,os,json,hashlib
r=Path('/workspace/independent-boundary-review'); env=os.environ.copy(); env.update(PATH='/workspace/.cargo/bin:'+env['PATH'],CARGO_HOME='/workspace/.cargo',RUSTUP_HOME='/workspace/.rustup'); receipts=json.loads((r/'execution.json').read_text()) if (r/'execution.json').exists() else []
def run(cmd,cwd,log,arm=None,err=None):
 e=env.copy()
 if arm:e['CARGO_TARGET_DIR']=str(r/f'target-{arm}')
 with (r/log).open('w') as f:
  if err:
   with (r/err).open('w') as ef:p=subprocess.run(cmd,cwd=cwd,env=e,stdout=f,stderr=ef)
  else:p=subprocess.run(cmd,cwd=cwd,env=e,stdout=f,stderr=subprocess.STDOUT)
 receipts.append(dict(cmd=cmd,cwd=str(cwd),target=e.get('CARGO_TARGET_DIR'),exit=p.returncode,log=log,stderr=err));(r/'execution.json').write_text(json.dumps(receipts,indent=2));print(log,p.returncode,flush=True);assert p.returncode==0
rustc='/workspace/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc'
for arm,src in [('delivery',Path('/workspace/codecortex')),('rejected',r/'rejected'),('candidate',r/'candidate'),('base',r/'base')]:
 if not (r/f'{arm}-tests.log').exists():run(['cargo','+1.95.0','test','--locked','-p','cc-search','query_target','--lib','-j','2'],src,f'{arm}-tests.log',arm)
 if not (r/f'{arm}-artifacts.jsonl').exists():run(['cargo','+1.95.0','build','--locked','-p','cc-eval','--lib','-j','2','--message-format=json-render-diagnostics'],src,f'{arm}-artifacts.jsonl',arm,f'{arm}-build.log')
 rows=[json.loads(x) for x in (r/f'{arm}-artifacts.jsonl').read_text().splitlines() if x.startswith('{')]
 libs={}
 for row in rows:
  if row.get('reason')=='compiler-artifact':
   name=row['target']['name']; paths=[x for x in row['filenames'] if x.endswith('.rlib')]
   if paths and row['profile'].get('debuginfo')==2:libs[name]=paths[0]
   if name in ['cc_search','cc_server','cc_eval']:assert not row['fresh'],(arm,name)
 for label,source,names in [('driver',r/'driver.rs',['cc_eval','cc_server','serde_json'])]+([] if arm=='base' else [('probe',r/f'probe-{arm}.rs',['cc_model','cc_db','serde_json'])]):
  cmd=[rustc,'--edition','2021',str(source),'-L','dependency='+str(r/f'target-{arm}/debug/deps'),'-o',str(r/f'{label}-{arm}')]
  for name in names:cmd+=['--extern',name+'='+libs[name]]
  run(cmd,src,f'{label}-{arm}-link.log')
  (r/f'{label}-{arm}-link.json').write_text(json.dumps({'cmd':cmd,'libraries':{n:{'path':libs[n],'sha256':hashlib.sha256(Path(libs[n]).read_bytes()).hexdigest()} for n in names},'binary_sha256':hashlib.sha256((r/f'{label}-{arm}').read_bytes()).hexdigest()},indent=2))
  if label=='probe':run([str(r/f'probe-{arm}')],src,f'{arm}-probes.json')
 for variant in ['base','receiver','inversion']:
  run([str(r/f'driver-{arm}'),str(r/f'fixtures/{arm}-{variant}'),str(r/f'results/{arm}-{variant}'),variant],src,f'{arm}-{variant}-run.log')
