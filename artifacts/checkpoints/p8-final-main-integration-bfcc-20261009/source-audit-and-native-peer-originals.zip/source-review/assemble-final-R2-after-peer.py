#!/usr/bin/env python3
"""Assemble canonical reviewer decision after manual peer inspection; no source edit."""
import argparse,copy,datetime,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
parser=argparse.ArgumentParser();parser.add_argument('--peer',required=True,type=Path);args=parser.parse_args()
peer=read(args.peer);source=read(ROOT/'actual-P2-independent-source-review.reconstructed.json');prior=read(ROOT/'canonical-R1-51d5.original.json');thin=read(ROOT/'independent-P2-native-terminals-thin-review.v2.json')
assert 'accepted' in peer.get('verdict','').lower(), 'Actual peer acceptance required'
assert source['source']=='b3bf22eab019175774c6c83295620b63a9740888'
assert peer['source_P2']==source['source'] and peer['tree']==source['tree']
assert peer['same_P2_continuation']['Rust_unique_passed']==304 and peer['same_P2_continuation']['original_four_child_exits']==[0,0,0,0]
assert peer['actual_prepare_only']['full_reference_mode_blob_SHA_equal_actual_P2_products'] and peer['actual_prepare_only']['four_variant_exact_changes_and_all_other_bytes_checked']
assert peer['unresolved_blockers_within_this_focused_scope']==[]
assert thin['source']==source['source'] and thin['verdict']=='accepted_scoped_original_terminals_and_identity'
assert len(source['complete_inputs'])==1095 and len(source['validation_inputs'])==142 and len(source['paths'])==70
newpaths=source['new_source_reviews'];iv=copy.deepcopy(source['actual_input_mode_blob_inventory'])
for p,row in iv.items():
 row['sha256']=source['complete_inputs'].get(p,source['validation_inputs'].get(p))
 row['size']=newpaths[p]['bytes'] if p in newpaths else prior['actual_input_mode_blob_inventory'][p]['size']
reviews=copy.deepcopy(prior['source_path_reviewers'])
for p,d in newpaths.items():
 reviews[p]={'before_sha256':source['paths'][p]['before_sha256'],'sha256':d['sha256'],'mode':iv[p]['mode'],'git_blob':d['blob'],'reviewer':'/root/execution_recon','review_kind':'Direct independent three-path semantic review and actual P2 byte/Git identity reconstruction','semantic_review':d['semantic_review'],'review_references':[info(ROOT/'actual-P2-independent-source-review.reconstructed.json')]}
assert set(reviews)==set(source['paths'])
for p,row in reviews.items():assert row['sha256']==source['paths'][p]['sha256']
boundary=copy.deepcopy(prior['acceptance_boundary'])
boundary['latest_main_scope']='Actual P2 includes exact main4ef three lane-policy/anchor product changes and preserves PR184ae033 evidence. Later b356 adds no missing product bytes; its sole additional review artifact may be preserved only by a separately verified source-identical future merge. No future merge or latest unknown source is claimed here.'
boundary['source_admission']='This is the completed independent canonical source review for actual P2. New R2/G2 and exact selected v15/CI remain separate; previous G1 source-admission execution is not relabelled as P2 admission.'
boundary['P8_007']='Actual DB acquisition observations retain their fixed G1 d7f feature-build identity and original four-C protocol. No G1 timing population is relabelled as P2 or originalGc8; no task closure is claimed by this review.'
r={'schema_version':1,'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':source['source'],'source_tree':source['tree'],'tree':source['tree'],'source_parent':source['source_parents'][0],'source_parents':source['source_parents'],'base':source['base'],'verdict':'accepted_scoped','scope':'independently_reviewed_source_and_validation_inputs','independent_reviewers':['/root/execution_recon'],'author_independence':{'reviewer':'/root/execution_recon','reviewer_authored_current_product_or_validation_changes':False,'combination_author':'/root/todo_audit prepared nonloss union; root created actual P2 and executed native controls','donor_authors':'External main PR186 lane registry changes; unchanged prior reviewed P1/G1 source','independent_execution_peer':'/root/pr_triage'},'unresolved_blockers':[],'paths':source['paths'],'complete_inputs':source['complete_inputs'],'validation_inputs':source['validation_inputs'],'changed_source_input_count':70,'complete_input_count':1095,'validation_input_count':142,'source_modes':{p:iv[p]['mode'] for p in source['complete_inputs']},'validation_modes':{p:iv[p]['mode'] for p in source['validation_inputs']},'actual_input_mode_blob_inventory':iv,'source_path_reviewers':reviews,'validation_path_reviewers':copy.deepcopy(prior['validation_path_reviewers']),'review_basis':{'source_reconstruction':info(ROOT/'actual-P2-independent-source-review.reconstructed.json'),'method':'Independent actual P2 official commit, complete3242-directory tree rehash and reverse70-leaf G1 root check. Entire1095/142 map and70 strict two-key BASE delta verified:1092 product+142validation path/mode/blob/SHA retained from exact original canonicalR1; three changed product before/after raw bytes independently Gitblob/SHA verified and semantically reviewed. No holdout body interpretation.','prior_canonical_R':{'commit':'51d5ed91e14ddb13eccb93ebd28311a3235075cc','repository_path':'artifacts/checkpoints/p8-db-acquisition-cleanup-bfcc-20261009/independent-source-review.json',**info(ROOT/'canonical-R1-51d5.original.json')},'retained_prior_review_scope':'The prior67 semantic path reviews and142 validation reviews remain applicable only to exact retained bytes. Prior P1/G1 execution is not current P2 execution.','recovery_disclosure':source['reconstruction'],'full_worktree_materialization_claim_by_reviewer':False,'holdout_body_read':False},'current_execution_support':{'acceptance_by_this_report':True,'original_native_zip':thin['original_zip'],'native_zip_git_blob':thin['zip_git_blob'],'native_terminals_thin_review':info(ROOT/'independent-P2-native-terminals-thin-review.v2.json'),'non_author_complete_execution_peer':info(args.peer),'accepted_engineering_result':thin['accepted_engineering_result'],'source_input_counts':thin['source_input_counts'],'negative_history':thin['negative_history'],'limits':thin['limits'],'scope':'Actual P2 focused engineering only: retained first fmt0/compile101, then unchanged P2 with six original compile inputs materialized, 303searchlib+1anchor pass, exact two-package all-target strictClippy0 and original prepare-only0. No workspaceClippy, benchmark, cold build or four-C/scale credit.'},'acceptance_boundary':boundary}
r['current_execution_support']['original_archive_and_prepare_only_peer_scope']={'archive_counts':peer['archive_counts'],'actual_prepare_only':peer['actual_prepare_only'],'extracted_copy_permission_observation':peer['extracted_copy_permission_observation'],'environment':peer['execution_environment'],'peer_boundaries':peer['boundaries']}
for p,row in r['paths'].items():assert set(row)=={'before_sha256','sha256'}
out=ROOT/'independent-source-review.final-R2.json'
with out.open('x') as f:json.dump(r,f,indent=2,ensure_ascii=False,sort_keys=True);f.write('\n')
print(json.dumps(info(out)))
