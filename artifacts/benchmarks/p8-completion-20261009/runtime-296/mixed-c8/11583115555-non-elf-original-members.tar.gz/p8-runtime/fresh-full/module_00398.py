def stable_00398():
    return 398
