def stable_00313():
    return 313
