#!/usr/bin/env python3
"""Capture one execution of the original v15 command on the fixed diagnostic guard."""
import datetime,hashlib,json,pathlib,subprocess,time
ROOT=pathlib.Path("/workspace/scratch/a217aaae3bde")
OUT=ROOT/"p8-db-lock-observation-integration"
VIEW=ROOT/"p8-lock-observation-validated"
cfg=json.loads((OUT/"final-composition-inputs.json").read_text())
prep=json.loads((OUT/"root-actual-composition-and-preparation.json").read_text())
assert prep["verdict"]=="passed_actual_composition_and_preparation" and prep["source"]==cfg["guard"]
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(["git","-C",str(VIEW),*args]).decode().strip()
paths=["scripts/verify_reviewed_source_v15.py","scripts/reviewed-source-registry-v15.json",cfg["core_path"],".github/workflows/ci.yml"]
def inputs():return {p:sha((VIEW/p).read_bytes()) for p in paths}
before=inputs()
assert git("rev-parse","HEAD")==cfg["guard"]
assert before[paths[0]]==cfg["verifier_sha256"] and before[paths[1]]==cfg["registry_sha256"] and before[paths[2]]==cfg["core_sha256"]
command=["python3","-B","scripts/verify_reviewed_source_v15.py","--source-version","p8-completion-source-20261009-v15"]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
stdout=OUT/"source-guard-original-v15.stdout.txt";stderr=OUT/"source-guard-original-v15.stderr.txt"
with stdout.open("xb") as out,stderr.open("xb") as err:
    p=subprocess.run(command,cwd=VIEW,stdout=out,stderr=err)
after=inputs()
record={"schema":"p8-db-lock-observation-original-v15-execution-v1","started_at":started,"finished_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"elapsed_seconds":time.monotonic()-t,"command":command,"cwd":str(VIEW),"source_before":cfg["guard"],"source_after":git("rev-parse","HEAD"),"returncode":p.returncode,"inputs_before":before,"inputs_after":after,"input_bytes_unchanged":before==after,"stdout":{"path":str(stdout),"bytes":stdout.stat().st_size,"sha256":sha(stdout.read_bytes())},"stderr":{"path":str(stderr),"bytes":stderr.stat().st_size,"sha256":sha(stderr.read_bytes())},"rust_and_native_execution":"not_run","todo_closures":0,"todo_remaining":29}
raw=(json.dumps(record,sort_keys=True,indent=2)+"\n").encode()
(OUT/"source-guard-original-v15-execution.json").write_bytes(raw)
print(json.dumps({"source":cfg["guard"],"returncode":p.returncode,"elapsed_seconds":record["elapsed_seconds"],"input_bytes_unchanged":before==after,"execution_receipt":str(OUT/"source-guard-original-v15-execution.json"),"receipt_bytes":len(raw),"receipt_sha256":sha(raw),"stdout":stdout.read_text(),"stderr":stderr.read_text()}))
assert record["source_after"]==cfg["guard"] and before==after
raise SystemExit(p.returncode)

