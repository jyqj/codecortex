import hashlib,json,os,shutil,subprocess
from pathlib import Path
H=Path(__file__).resolve().parent;OLD=H.parent/'p8-profile-isolated-integration/guard-view';VIEW=H/'guard-view';HEAD='e7f8e913861f32e6745bcd56794601133b621c34'
def git(*a,**kw):return subprocess.run(['git','-C',str(VIEW),*a],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,**kw).stdout
assert not VIEW.exists();shutil.copytree(OLD,VIEW,ignore=shutil.ignore_patterns('.git','__pycache__','*.pyc'));subprocess.run(['git','init','-q',str(VIEW)],check=True);(VIEW/'.git/objects/info/alternates').write_text(str(OLD/'.git/objects')+'\n')
if (OLD/'.git/shallow').exists():shutil.copy2(OLD/'.git/shallow',VIEW/'.git/shallow')
git('remote','add','origin','https://github.com/jyqj/codecortex.git');git('config','remote.origin.promisor','true');git('config','remote.origin.partialclonefilter','blob:none');git('config','core.autocrlf','false')
with (H/'exact-fetch.stdout').open('wb') as out,(H/'exact-fetch.stderr').open('wb') as err:
 r=subprocess.run(['git','-C',str(VIEW),'fetch','--no-tags','--depth=3','--filter=blob:none','origin',HEAD],stdout=out,stderr=err,timeout=180);(H/'exact-fetch-receipt.json').write_text(json.dumps({'exit_code':r.returncode,'head':HEAD,'scope':'isolated exact3-commit fetch; no shared Git writer'}));r.check_returncode()
for root in [H/'after',H/'scripts']:
 for p in root.rglob('*'):
  if p.is_file():
   rel=p.relative_to(root);dest=VIEW/rel if root.name=='after' else VIEW/'scripts'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for e in json.loads((H/'review-file-plan.json').read_text()):
 dest=VIEW/e['path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(e['source'],dest)
files=[p for p in VIEW.rglob('*') if p.is_file() and '.git' not in p.relative_to(VIEW).parts];git('hash-object','-w','--stdin-paths',input=('\n'.join(str(p) for p in files)+'\n').encode());git('update-ref','HEAD',HEAD);git('read-tree',HEAD)
reg=json.loads((VIEW/'scripts/reviewed-source-registry-v15.json').read_text());names=set(reg['complete_inputs'])|set(reg['validation_inputs'])|{'scripts/reviewed-source-registry-v15.json','scripts/verify_reviewed_source_v15.py'}|{e['path'] for e in json.loads((H/'review-file-plan.json').read_text())}|{e['path'] for e in json.loads((H/'fixed-product-composition-plan.json').read_text())['elements']}
actual=[]
for p in sorted(names):
 raw=(VIEW/p).read_bytes();oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();line=git('ls-tree',HEAD,'--',p).decode().strip();mode,kind,expected=line.split('\t')[0].split();assert mode in ('100644','100755') and kind=='blob' and oid==expected,(p,line,oid);assert bool((VIEW/p).stat().st_mode&0o111)==(mode=='100755'),(p,mode)
 actual.append({'path':p,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':oid,'mode':mode})
record={'scope':'required-input projection, not full artifacts checkout; actual private Git HEAD/index and unchanged old-object alternate','head':HEAD,'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'complete_inputs':len(reg['complete_inputs']),'delta':len(reg['delta']),'validation_inputs':len(reg['validation_inputs']),'index_sha256':hashlib.sha256((VIEW/'.git/index').read_bytes()).hexdigest(),'files':actual};(H/'private-view-actual-source-proof.json').open('x').write(json.dumps(record,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='files'}))
