"""One frozen C preflight and evidence audit, never a new native workload."""
import datetime,hashlib,json,os,pathlib,subprocess,sys,time
B=pathlib.Path(__file__).resolve().parent;A=B/'artifacts/11610619483';H=B/'helpers-C3ff-v1';S=B.parent/'scale-original-c3ff';HEAD='3ffcefc3b28ee1a4ed80caecebd7208a45c3e302';O=B/'accepted';O.mkdir(exist_ok=True)
record=A/'actual-acceptance-execution.json';assert not record.exists() and not (A/'extracted').exists()
def hashfile(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def snap():return {str(p):hashfile(p) for p in sorted(H.glob('*.py'))}
m=json.loads((A/'artifact-metadata.json').read_text());z=A/'11610619483.zip'
assert m['id']==11610619483 and m['workflow_run']['id']==37908825814 and m['workflow_run']['head_sha']==HEAD
assert z.stat().st_size==m['size_in_bytes'] and hashfile(z)==m['digest'].removeprefix('sha256:')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==HEAD
receipt=dict(schema='C-backfill-original-acceptance-execution-v1',source=HEAD,workflow_run=37908825814,artifact_id=m['id'],started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_zip_sha256_before=hashfile(z),original_zip_bytes=z.stat().st_size,helper_inputs_before=snap(),commands=[],status='started',new_native_workload=False)
def save():record.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
def run(label,argv):
 row=dict(label=label,command=argv,cwd=str(B),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat());receipt['commands'].append(row);save();start=time.monotonic()
 with (A/(label+'.stdout')).open('xb') as out,(A/(label+'.stderr')).open('xb') as err:
  try:r=subprocess.run(argv,cwd=B,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err,timeout=900);row['exit_code']=r.returncode
  finally:row['elapsed_seconds']=time.monotonic()-start;save()
 row.update(stdout=dict(path=str(A/(label+'.stdout')),bytes=(A/(label+'.stdout')).stat().st_size,sha256=hashfile(A/(label+'.stdout'))),stderr=dict(path=str(A/(label+'.stderr')),bytes=(A/(label+'.stderr')).stat().st_size,sha256=hashfile(A/(label+'.stderr'))));save();assert r.returncode==0,label
try:
 run('preflight',[sys.executable,'-B',str(H/'preflight_e_runtime_zip.py'),str(z),str(A/'artifact-metadata.json'),str(A/'extracted'),str(A/'preflight-and-extraction.json'),'--extract'])
 manifest=A/'acceptance-manifest.json';manifest.write_text(json.dumps(dict(artifact_id=m['id'],zip_bytes=m['size_in_bytes'],zip_sha256=receipt['original_zip_sha256_before']),indent=2)+'\n')
 run('backfill-review',[sys.executable,'-B',str(H/'review_e_backfill_original.py'),str(manifest),str(B/'artifacts'),HEAD,str(S),str(O)])
 receipt['helper_inputs_after']=snap();assert receipt['helper_inputs_after']==receipt['helper_inputs_before']
 receipt['original_zip_sha256_after']=hashfile(z);assert receipt['original_zip_sha256_after']==receipt['original_zip_sha256_before']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==HEAD
 p=O/'backfill-11610619483-3ffcefc3-independent/independent-review.json';receipt['review']=dict(path=str(p),bytes=p.stat().st_size,sha256=hashfile(p));receipt['status']='accepted_scoped_original_C_backfill'
except BaseException as e:receipt['status']='failed_or_blocked_original_review';receipt['exception']=repr(e);raise
finally:receipt['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(dict(status=receipt['status'],receipt=str(record),sha256=hashfile(record),review=receipt.get('review'))))
