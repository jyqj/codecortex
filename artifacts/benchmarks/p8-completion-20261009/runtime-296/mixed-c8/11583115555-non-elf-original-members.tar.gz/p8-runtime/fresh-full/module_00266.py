def stable_00266():
    return 266
