from pathlib import Path
import hashlib

root=Path('/dev/shm/p8-D0-sequential-receiver')
original=Path('/workspace/scratch/2eaa00d0f93a/p8-scale-sequential-receiver/receive.py')
text=original.read_text()
assert hashlib.sha256(original.read_bytes()).hexdigest()=='a05743c0bdd15df5337287ca6861c6e88317623ebf53855d10dd83642a88528d'
def change(old,new,count=1):
    global text
    assert text.count(old)==count,(old,text.count(old),count)
    text=text.replace(old,new)
change('run 37830173594','run 37854240827')
change('exact G validation','exact D0 validation')
change('SOURCE = "bb9a96d71622458c39a143055360cc97f0d11d78"\nRUN = 37830173594',
'''SOURCE = "d0cb69c601e530dcef738af0c2dffb8d3b8bcf28"
CONTROLLER = "ca72a2dde363e35203f7b3cb30ed00729d460fd7"
RUN = 37854240827
UPSTREAM_RUN = 37846370300
REGISTRATION_SHA256 = "4a56e31e9838f0db1d83a3efd4a10d0a51f8b443dbce4413e68253881740eebc"
CONTROLLER_SCRIPT_SHA256 = "a65e819d3a00f8032e04d54c8da881a6efb160671f14252e96258f57813df189"
ADMISSION_NAME = f"p8-d0-study-admission-{RUN}"''')
change('replay checkout is not exact G','replay checkout is not exact D0')
change('replay driver/helper differs from G','replay driver/helper differs from D0')
change('names = {f"p8-scale-build-{RUN}", f"p8-scale-matrix-{RUN}"}',
       'names = {ADMISSION_NAME, f"p8-scale-build-{RUN}", f"p8-scale-matrix-{RUN}"}')
change('inventory.get("schema") == "p8-scale-download-set-v1"','inventory.get("schema") == "p8-fixed-D0-scale-download-set-v1"')
change('inventory.get("source_commit") == SOURCE, "wrong reception run/source/attempt")',
       'inventory.get("source_commit") == SOURCE and inventory.get("controller_commit") == CONTROLLER and\n            inventory.get("registration_sha256") == REGISTRATION_SHA256, "wrong reception run/source/controller/registration/attempt")')
change('len(artifacts) in (301, 302), "all 301 original build/shard/capacity artifacts are required"',
       'len(artifacts) in (302, 303), "all 302 original admission/build/shard/capacity artifacts are required"')
change('item["workflow_run"].get("head_sha") == SOURCE','item["workflow_run"].get("head_sha") == CONTROLLER')
change('require(re.fullmatch(r"p8-scale-[a-z0-9-]+", name), "unexpected expansion name")',
       'require(name == ADMISSION_NAME or re.fullmatch(r"p8-scale-[a-z0-9-]+", name), "unexpected expansion name")')
change('capacity receipt did not complete at G','capacity receipt did not complete at D0')
change('def comparable_matrix(value):', (root/'admission.fragment.py').read_text()+'def comparable_matrix(value):')
change('"run_attempt": ATTEMPT, "scope": "original ZIP transport and original G validators only",',
       '"run_attempt": ATTEMPT, "controller_commit": CONTROLLER, "registration_sha256": REGISTRATION_SHA256,\n              "scope": "original ZIP transport and original D0 validators only",')
change('aggregate_job.get("head_sha") == SOURCE','aggregate_job.get("head_sha") == CONTROLLER')
change('''        records, capacity, remote = [], [], None
        for name in sorted(originals):
            if name == build_name:
''','''        admission_item, admission_archive = originals[ADMISSION_NAME]
        admission_directory = expanded.extract(ADMISSION_NAME, admission_archive, admission_item, members[ADMISSION_NAME])
        admission_result, registration = admission_review(admission_directory, build, built, matrix, args.replay_root)
        report["admission"] = admission_result
        save(output / "registration.json", registration)
        registered_plans = {(item["scale"], item["shard_index"]): item["plan"] for item in registration["primary_cells"]}
        expanded.reclaim(admission_directory, admission_archive, admission_item, members[ADMISSION_NAME])
        report["artifacts"].append({"artifact_id": admission_item["id"], "name": ADMISSION_NAME,
            "zip_sha256": admission_item["digest"], "zip_bytes": admission_item["size_in_bytes"],
            "archive_path": str(admission_archive), "complete_original_zip_verified_before_reclaim": True})
        records, capacity, remote = [], [], None
        for name in sorted(originals):
            if name in (build_name, ADMISSION_NAME):
''')
change('''                        "artifact name differs from original shard identity")
                records.append(value)''','''                        "artifact name differs from original shard identity")
                require(matrix.exact_equal(value["plan"], registered_plans[(scale, index)]),
                        "new primary shard differs from the fixed original registration plan")
                records.append(value)''')
change('''        require(matrix.validate_build(build)[0] == built, "retained build changed")
        save(output / "matrix.json", result)''','''        require(matrix.validate_build(build)[0] == built, "retained build changed")
        snapshot_after = matrix.source_snapshot(args.replay_root)
        require(snapshot_after["source_commit"] == SOURCE and snapshot_after["source_tree"] == registration["source_tree"] and
                snapshot_after["inputs"] == registration["complete_source_inputs"], "complete D0 source changed before final seal")
        save(output / "matrix.json", result)''')
(root/'receive.py').write_text(text)
print(hashlib.sha256((root/'receive.py').read_bytes()).hexdigest(),len(text.encode()))
