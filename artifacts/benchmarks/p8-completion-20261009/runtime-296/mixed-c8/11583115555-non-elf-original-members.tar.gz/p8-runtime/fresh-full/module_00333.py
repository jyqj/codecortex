def stable_00333():
    return 333
