#!/usr/bin/env python3
"""Seal already reviewed Git/source/diagnostic originals. No product execution."""
from pathlib import Path
import copy
import hashlib
import json
import stat
import zipfile

HERE = Path(__file__).resolve().parent
OUT = HERE / 'final-R8B'
PREFIX = 'artifacts/checkpoints/p8-immutable-payload-cell-witness-bfcc-20261009'
OLDROOT = Path('/dev/shm/pr-triage-round21-P7B-source-review/final-R7B')
EX = Path('/dev/shm/execution-recon-recovery-20261009')
D1 = EX / 'round21-oracle-witness-diagnostic'
D2 = EX / 'round21-oracle-raw-cell-diagnostic-v2'

def load(p):
    return json.loads(Path(p).read_bytes())

def meta(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                git_blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest())

def dump(p, value):
    data=(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)+'\n').encode()
    with p.open('xb') as f:
        f.write(data)
    return meta(data)

oldraw=(OLDROOT/'independent-source-review.json').read_bytes()
assert meta(oldraw)['sha256']=='9de57a05b8d9896689a19a289fb3edfcfd8e859eef505f8ff7a63e9718ba3653'
old=json.loads(oldraw)
bridge=load(HERE/'actual-P8B-complete-source-bridge.json')
assert bridge['source']=='44e6248106335b5f0625e53de38f76d26aeeadcf'
assert bridge['source_tree']=='6ade2b570e0d1bba09cf3f70ed6a1522c3c05e2b'
assert bridge['source_parents']==[old['source']]
assert bridge['counts']==dict(product=1095,BASE_delta=75,validation=142,mode_blob_inputs=1237)
assert load(HERE/'actual-P8B-source-bridge-receipt.json')['exit_code']==0
assert bridge['validation_inputs']==old['validation_inputs']
assert set(bridge['complete_inputs'])==set(old['complete_inputs'])
assert sum(old['complete_inputs'][p]!=h for p,h in bridge['complete_inputs'].items())==2
assert all(set(v)=={'before_sha256','sha256'} for v in bridge['paths'].values())
peer=load(D2/'independent-source-review.json')
risk1=load(D1/'bounded-risk-review.json')
risk2=load(D2/'bounded-risk-review.json')
assert peer['unresolved_source_blockers']==[]
assert risk2['terminal_execution']['child_exit_code']==0
assert risk2['checks']['all_original_18_calls_completed']
assert risk2['checks']['nine_pairs_exact_complete_sorted_bytes_and_common_results_equal']
for f in peer['files']:
    inventory=bridge['actual_input_mode_blob_inventory'][f['path']]
    assert inventory['sha256']==f['v2_sha256'] and inventory['sha']==f['v2_git_blob']

assert not OUT.exists(), 'never overwrite frozen final output'
OUT.mkdir()
selected={}
external=[]

def add(p,name,expected=None):
    p=Path(p)
    assert p.is_file() and not p.is_symlink()
    raw=p.read_bytes(); info=meta(raw)
    if expected:
        assert info['bytes']==expected['bytes'] and info['sha256']==expected['sha256']
        if 'git_blob' in expected:
            assert info['git_blob']==expected['git_blob']
    assert name not in selected and not name.startswith('/') and '..' not in Path(name).parts
    selected[name]=(p,raw,stat.S_IMODE(p.stat().st_mode))

for name in ['P8B-commit.original.json','P7B-to-P8B-compare.original.json',
             'actual-P8B-complete-source-bridge.json','verify-P8B-two-leaf-inheritance.py',
             'actual-P8B-source-bridge-receipt.json','independent-two-leaf-static-readback.json',
             'package-canonical-R8B.py']:
    add(HERE/name,'actual-P8B/'+name)
add('/dev/shm/root-round21/P8B-created-objects-original.json','actual-P8B/root-P8B-created-objects-original.json')
for name in ['candidate-v2.diff','candidate-v2-manifest.json']:
    add(Path('/dev/shm/root-round21/oracle-raw-cell-witness-v2')/name,'oracle-v2-author/'+name)

# Original source/review selections keep exact bytes. The two binary result ZIPs
# are external artifact leaves, never nested in the new support ZIP.
for root,dest in [(D1,'diagnostics-v1'),(D2,'diagnostics-v2')]:
    sel=load(root/'archive-selection.json')
    assert len(sel['files']) in (34,39)
    for item in sel['files']:
        p=Path(item.get('local_path') or item['path'])
        relative=p.relative_to(root).as_posix()
        raw=p.read_bytes(); info=meta(raw)
        assert info['bytes']==item['bytes'] and info['sha256']==item['sha256']
        assert info['git_blob']==item['git_blob']
        if relative=='complete-diagnostic-byte-results.zip':
            with zipfile.ZipFile(p) as z:
                assert z.testzip() is None
            external.append(dict(local_path=str(p),repository_path=PREFIX+'/'+dest+'/'+relative,mode='100644',**info))
        else:
            add(p,dest+'/'+relative,item)
    add(root/'archive-selection.json',dest+'/archive-selection.json')

oldmanifest=load(OLDROOT/'upload-manifest.json')
assert len(oldmanifest['files'])==2
for item in oldmanifest['files']:
    p=Path(item['local_path']); info=meta(p.read_bytes())
    assert all(info[k]==item[k] for k in info)
    if p.suffix=='.zip':
        with zipfile.ZipFile(p) as z:
            assert z.testzip() is None
    external.append(copy.deepcopy(item))

locators=dict(schema_version=1,
    prior_review=oldmanifest['files'][0],prior_support=oldmanifest['files'][1],
    prior_review_status='Frozen R7 was source-only and uninstalled at its preparation timestamp. Its two original files are now selected unchanged as sibling artifact leaves of the new R8 installation. No R7 review commit is invented.',
    prior_review_source=old['source'],prior_review_tree=old['source_tree'],
    original_fixed_review=old['previous_fixed_reviews'],
    standalone_diagnostic_results=external[:2],
    selected_support_boundary='This ZIP is incremental source/review/diagnostic evidence, not a full repository or study artifact. Prior R7 complete source support and full diagnostic result ZIPs are separate immutable artifact leaves.',
    chronology='R7 and the v2 pre-execution peer keep original pending wording. New terminal diagnostics are appended, not backdated into them.')
dump(OUT/'inherited-and-external-original-locators.json',locators)
add(OUT/'inherited-and-external-original-locators.json','inherited-and-external-original-locators.json')

manifest=dict(schema_version=1,scope='incremental R8 source/review originals; no nested ZIPs',
              file_count=len(selected),total_bytes=sum(len(v[1]) for v in selected.values()),
              files=[dict(archive_path=n,local_path=str(v[0]),posix_mode=format(v[2],'04o'),**meta(v[1])) for n,v in sorted(selected.items())])
manifest_raw=(json.dumps(manifest,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode()
zpath=OUT/'P8B-source-only-originals.zip'
with zipfile.ZipFile(zpath,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,(_p,raw,mode) in sorted(selected.items()):
        zi=zipfile.ZipInfo(name,(2026,10,9,0,0,0));zi.create_system=3
        zi.external_attr=(stat.S_IFREG|mode)<<16;zi.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(zi,raw)
    zi=zipfile.ZipInfo('support-member-manifest.json',(2026,10,9,0,0,0));zi.create_system=3
    zi.external_attr=(stat.S_IFREG|0o644)<<16;zi.compress_type=zipfile.ZIP_DEFLATED
    z.writestr(zi,manifest_raw)
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None and len(z.infolist())==len(selected)+1
    assert not any(i.filename.endswith('.zip') for i in z.infolist())
    for name,(_p,raw,mode) in selected.items():
        assert z.read(name)==raw and stat.S_IMODE(z.getinfo(name).external_attr>>16)==mode
    assert z.read('support-member-manifest.json')==manifest_raw
zmeta=meta(zpath.read_bytes());assert zmeta['bytes']<8*1024*1024
(OUT/'support-member-manifest.json').write_bytes(manifest_raw)

def ref(p,name):
    return dict(path=name,**meta(Path(p).read_bytes()))

r=copy.deepcopy(old)
for key in ['source','source_tree','source_parents','complete_inputs','paths','validation_inputs','actual_input_mode_blob_inventory']:
    r[key]=bridge[key]
r['review_path']=PREFIX+'/independent-source-review.json'
r['author_independence']=dict(current_reviewer='/root/pr_triage',
    current_reviewer_role='Non-author of all six product edits; direct A/B semantic review and oracle-v2 readback, complete actual-P8 inheritance/identity review. No product edits or Git mutations.',
    payload_reuse_author='/root/execution_recon',oracle_author_and_commit_creator='/root',
    oracle_v2_independent_semantic_reviewer='/root/execution_recon',
    scoped_peer_note='execution_recon reviews only the root-authored oracle pair, not its own A/B payload changes; those are reviewed directly by pr_triage.',
    inherited_oracle_v1_semantic_reviewer='/root/todo_audit')
payload=copy.deepcopy(old['primary_review']['payload_reuse_review'])
payload['path']='R7 sibling support ZIP::'+payload['path']
payload['unchanged_P7_to_P8']=True
r['primary_review']=dict(
    actual_source_bridge=dict(counts=bridge['counts'],
        source_bridge=ref(HERE/'actual-P8B-complete-source-bridge.json','actual-P8B/actual-P8B-complete-source-bridge.json'),
        official_P8_parent=old['source'],official_exact_two_modified_paths=[x['path'] for x in bridge['two_changes']],
        combined_exact_six_paths_relative_G6B=old['primary_review']['actual_source_bridge']['official_exact_six_modified_paths'],
        entire_P8_tree_recomputed_by_two_leaf_replacement_in_thirteen_prior_official_tree_objects=True,
        unchanged_four_payload_paths_and_all_other_git_paths_modes=True,
        old142_validation_CI_FROZEN_and_two_bindings_preserved=True,
        BASE_delta_method='Fixed BASE before hashes inherited from independently reviewed R6/R7; complete current domain and all 75 before_sha256/sha256 dictionaries recomputed after two exact replacements. No removal or added validation input.'),
    payload_reuse_review=payload,
    oracle_v2_review=dict(report=ref(D2/'independent-source-review.json','diagnostics-v2/independent-source-review.json'),
        reviewer='/root/execution_recon',actual_source_binding='The byte-reviewed two paths match actual P8 Git blobs and SHA256 exactly; the original peer document retains its earlier actual_product_commit=null.',
        correctness_findings=peer['correctness_findings'],new_tests_review=peer['new_tests_review'],boundaries=peer['boundaries'],
        direct_readback=ref(HERE/'independent-two-leaf-static-readback.json','actual-P8B/independent-two-leaf-static-readback.json')),
    oracle_v1_inheritance='R7 sibling canonical/support retains original ordinary-table admission, A spool, B row/byte/error validation, fallback, complete EOF/count proof, accounting, driver compatibility and original/new controls. Only the reviewed two-leaf v2 delta supersedes its A reserialization witness; v1 statements are not represented as current code.',
    composition='P8 sole parent P7, sole parent G6B. Four A/B files remain exact P7 bytes. The oracle pair changes only witnessed equality implementation and added controls; oracle.rs, drivers, workload, budgets, original validation domain and prior artifacts remain unchanged.')
r['previous_fixed_reviews']=copy.deepcopy(old['previous_fixed_reviews'])
r['previous_frozen_source_review']=dict(source=old['source'],source_tree=old['source_tree'],
    review=oldmanifest['files'][0],support=oldmanifest['files'][1],
    prior_review_commit=None,status='Original frozen R7 was not separately committed; these exact historical bytes are preserved as two sibling artifacts of this intended R8 installation.')
r['historical_preservation']=dict(
    whole_tree='P8 differs from P7 only by two reviewed oracle leaves and from G6B by the six reviewed product leaves; all prior artifacts, other source and validation paths/modes are preserved.',
    earlier_negatives=old['historical_preservation']['earlier_negatives'],
    preparation=old['historical_preservation']['current_preparation'],
    pending_documents='R7 pending diagnostic wording and v2 pre-execution peer remain unchanged. Their actual later results are appended in this review and support.',
    v1_risk='Original v1 late mismatch doubled projection work in the limited design and had median ratio 1.8048347224; original complete v1 inputs/outputs and all 18 calls remain available. V2 is a separate finite execution, not a contemporaneous v1-v2 speed comparison.',
    unrelated_SQL=old['historical_preservation']['unrelated_SQL'])
r['current_execution']=dict(
    actual_P8B=dict(rustfmt='not_run',Rust_tests='not_run',Clippy='not_run',source_CLI='not_run',runtime_or_scale='not_run'),
    inherited_execution='G6B and earlier CI/studies retain original source and conclusions; no inherited execution is a P8 execution.',
    mechanical_source_assertions=dict(actual_exit=0,scope='Git object, SHA256, map and source inheritance only'),
    limited_python_SQLite_design_probes=dict(
        v1=dict(report=ref(D1/'bounded-risk-review.json','diagnostics-v1/bounded-risk-review.json'),
            result=load(D1/'result.json'),child=load(D1/'child-receipt.json')),
        v2=dict(report=ref(D2/'bounded-risk-review.json','diagnostics-v2/bounded-risk-review.json'),
            result=risk2['result'],child=risk2['terminal_execution'],
            interpretation=risk2['interpretation'],implementation_bridge_limits=risk2['implementation_bridge_limits']),
        scope='Each source-specific Python transcription ran exactly 18 fixed calls/9 pairs once with a 45-second outer bound, no repeats or exclusions. Both preserve complete sorted bytes/common results in their chosen ASCII text/integer fixtures. This is not Rust, all 15 tables, fault equivalence, formal sample credit or a demonstrated end-to-end speedup.',
        adoption='No source correctness blocker. V2 retains real adverse reverse/late cases; accepting the explicit fallback cost for engineering controls is a decision, not a new threshold. Rust compile/fmt/tests and source admission remain to execute.'))
r['review_support']=dict(originals_zip_repository_path=PREFIX+'/'+zpath.name,**zmeta,
    selected_files=len(selected),zip_members=len(selected)+1,all_members_CRC_bytes_modes_verified=True,
    contents='Incremental actual P8 two-leaf source/identity and reviewer originals plus complete selected v1/v2 diagnostic records. Four inherited payload changes and earlier source proofs remain in the separately installed original R7 support. No nested ZIPs.',
    sibling_artifacts=external)
r['unresolved_blocker_scope']='No remaining source-semantic or identity blocker. Rust formatting, compilation/tests, Clippy and original source admission are not yet executed for P8 and are not waived. Limited Python timings expose adverse cases; no claimed full-scale pass or performance improvement follows.'
assert r['independent_reviewers']==['/root/pr_triage'] and r['unresolved_blockers']==[]
assert len(r['complete_inputs'])==1095 and len(r['paths'])==75 and len(r['validation_inputs'])==142
review=OUT/'independent-source-review.json';rmeta=dump(review,r)
upload=dict(schema_version=1,source=bridge['source'],source_tree=bridge['source_tree'],
    intended_review_parent=bridge['source'],scope='Exactly six artifact additions: new R8 canonical/support, unchanged R7 canonical/support, complete v1/v2 diagnostic result ZIPs. No product/binding changes.',
    files=[dict(local_path=str(review),repository_path=PREFIX+'/'+review.name,mode='100644',**rmeta),
           dict(local_path=str(zpath),repository_path=PREFIX+'/'+zpath.name,mode='100644',**zmeta)]+external)
assert len(upload['files'])==6 and len({x['repository_path'] for x in upload['files']})==6
umeta=dump(OUT/'upload-manifest.json',upload)
print(json.dumps(dict(canonical=rmeta,support=zmeta,support_members=len(selected)+1,upload_manifest=umeta,artifact_files=6)))
