#!/usr/bin/env python3
"""Narrow, source-only PR disposition evidence. Never execute legacy code."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import tomllib

BASE = pathlib.Path('/workspace/scratch/a217aaae3bde')
OUT = BASE / 'scale-pr180-C-review/legacy-pr3-pr4-triage'
ROOT = pathlib.Path('/dev/shm/a217aaae3bde/pr180-M4-832f-validated')
G4 = '832f79b8702c6cdfb567b7cf949508cd4589f286'
MAIN = '4efbc97eb439a56347e7b32d05b7ea1ab6d34c75'

def identity(b):
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), 'git_blob': hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()}

def ref(p):
    return {'path': str(p), **identity(p.read_bytes())}

paths = [
    'crates/cc-search/src/plan.rs', 'crates/cc-search/src/preselect.rs',
    'crates/cc-search/src/lanes.rs', 'crates/cc-search/src/fusion.rs',
    'crates/cc-search/src/rrf.rs', 'crates/cc-search/src/engine_graph.rs',
    'crates/cc-db/src/index_db_retrieval.rs', 'crates/cc-db/src/index_migrate.rs',
    'crates/cc-index/src/dirty_reload_policy.rs',
    'crates/cc-parsers/src/jsts/mod.rs', 'crates/cc-parsers/src/jsts/references.rs',
    'crates/cc-parsers/src/python/mod.rs', 'crates/cc-parsers/src/python/references.rs',
    'crates/cc-eval/tests/p2b_incremental.rs', 'crates/cc-eval/tests/p2c_reconcile.rs',
    'crates/cc-eval/src/benchmark/report.rs', 'Cargo.lock',
]
bindings = {}
assert subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip() == G4
for path in paths:
    b = (ROOT / path).read_bytes(); facts = identity(b)
    expected = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', f'{G4}:{path}'], text=True).strip()
    assert facts['git_blob'] == expected
    bindings[path] = facts
prs = {}
for n, expected_count in ((3, 48), (4, 70)):
    metadata = json.loads((OUT / f'pr{n}-official-metadata.json').read_text())
    files = json.loads((OUT / f'pr{n}-official-files.json').read_text())
    comparison = json.loads((OUT / f'pr{n}-actual-path-comparison.json').read_text())
    assert len(files) == len(comparison['files']) == metadata['changed_files'] == expected_count
    counts = {}
    for target in ['main', 'G4']:
        counts[target] = {c: sum(f[target]['classification'] == c for f in comparison['files']) for c in ['identical', 'evolved', 'missing']}
    prs[str(n)] = {'head': metadata['head']['sha'], 'base': metadata['base']['sha'], 'state': metadata['state'], 'title': metadata['title'], 'changed_files': len(files), 'path_counts': counts, 'original_metadata': ref(OUT / f'pr{n}-official-metadata.json'), 'all_original_changed_files': ref(OUT / f'pr{n}-official-files.json'), 'actual_complete_path_comparison': ref(OUT / f'pr{n}-actual-path-comparison.json')}
lock = tomllib.loads((ROOT / 'Cargo.lock').read_text())
security_families = {p['name']: p['version'] for p in lock['package'] if p['name'] in {'anyhow', 'crossbeam-epoch', 'lru', 'rand', 'chacha20', 'notify', 'notify-types', 'instant'}}

report = {
 'schema': 'legacy-PR3-PR4-fixed-source-disposition-triage-v1',
 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'reviewer': '/root/scale_closeout', 'fixed_current_main': MAIN, 'fixed_current_candidate': G4,
 'actions': 'Read fresh official PR metadata and complete changed-file sets; compare every changed path against two actual Git trees; inspect listed current sources and specific original patches. No old workflow/native execution, branch/ref/PR mutation, merge, test run or broad equivalence claim.',
 'prs': prs, 'current_source_bindings': bindings,
 'cross_pr_base': 'PR4 explicitly stacks on PR3; its 70-path delta is relative to 9619641, not current main. Whole-head transplantation would also reintroduce PR3 history/schema/interfaces.',
 'intent_triage': [
  {'prs': [3], 'intent': 'Caller hard scope separated from heuristic preselection', 'status': 'current intent covered by evolved API', 'current': ['crates/cc-search/src/plan.rs:133 HardScope/SoftHints', 'crates/cc-search/src/lanes.rs:374 hard-scope admission'], 'limit': 'This is not a bytewise adoption or a replay of all old quality fixtures.'},
  {'prs': [3], 'intent': 'Negative SQLite BM25 monotonic preselection', 'status': 'current intent covered with additional finite-value handling', 'current': ['crates/cc-search/src/preselect.rs:33 bm25_relevance_bonus', 'crates/cc-search/src/preselect.rs:1085 bm25_bonus_is_bounded_and_monotonic'], 'limit': 'Test source is present; this triage did not execute it.'},
  {'prs': [3], 'intent': 'Stable filepath ties before graph-neighbor candidate truncation', 'status': 'specific original hunk not present in current source; isolated patch prepared at root request', 'original': 'PR3 preselect.rs adds then_with(filepath) to final neighbor sort before truncate(expansion_limit).', 'current': ['crates/cc-search/src/preselect.rs:602 still sorts neighbor HashMap values by score only', 'crates/cc-search/src/preselect.rs:488 GraphNeighborLayer invokes this path'], 'risk': 'Equal scores and excess candidate count permit HashMap encounter order to choose retained neighbors. This is static evidence, not a recorded native failure.', 'scope': 'Only final neighbor sort is proposed. The separate top-20 seed sort at line520 is recorded and not changed.', 'candidate': ref(BASE / 'preselect-pr3-tie-candidate/candidate-manifest.json')},
  {'prs': [3, 4], 'intent': 'One vote per candidate per lane', 'status': 'current production uses stricter validation rather than silently dropping duplicates', 'current': ['crates/cc-search/src/lanes.rs:359 rejects duplicate chunk candidates', 'crates/cc-search/src/fusion.rs:43 validates public lanes and rejects duplicate lane ids'], 'residual': 'Old public rrf_accumulate helper still lacks the PR4 dedup addition, but repository-wide Rust reference search found only its definition/tests; active production calls the fusion module. Do not claim an active duplicate-vote defect from this unused helper alone.'},
  {'prs': [3, 4], 'intent': 'Long symbol to source chunk projection', 'status': 'current contract changed; do not transplant old overlap policy', 'original': 'Old symbol_chunks returns every overlapping piece if no containing chunk exists.', 'current': ['crates/cc-search/src/lanes.rs:777 uses symbol_uid_anchor_chunks', 'crates/cc-db/src/index_db_retrieval.rs:1249 uses authoritative UID/declaration start and source-byte containment'], 'decision': 'Current precise declaration-anchor behavior and old full-symbol multi-piece recall are distinct. A deliberate compatibility/gold decision is needed before calling the old intent equivalent or porting it.'},
  {'prs': [3], 'intent': 'Preserve parser-exact same-file bindings on unchanged-source reload', 'status': 'current intent covered and narrowed by actual identity membership', 'current': ['crates/cc-index/src/dirty_reload_policy.rs:131-155 verifies target file/id/uid belongs to unchanged symbols'], 'limit': 'Resolver/inferred targets continue to clear; no legacy reload code should replace this current guard.'},
  {'prs': [4], 'intent': 'AST-backed JS/TS/Python call/reference facts, lexical ownership and conservative binding', 'status': 'current implementation exists under language-specific modules, not old ast_facts.rs', 'current': ['crates/cc-parsers/src/jsts/references.rs skips comments/string/regex and carries lexical owner', 'crates/cc-parsers/src/jsts/mod.rs integrates AST call/reference handling', 'crates/cc-parsers/src/python/mod.rs:981 calls references::extract', 'crates/cc-parsers/src/python/references.rs scopes/dynamic names/owner tracking'], 'limit': 'Absence of old shared ast_facts.rs does not prove missing AST functionality. All twelve old exact gold scenarios were not ported or replayed by this triage.'},
  {'prs': [4], 'intent': 'Negative/module/name lookup invalidation, reexports and bounded closure', 'status': 'evolved typed resolution/dependency machinery and targeted controls exist', 'current': ['crates/cc-eval/tests/p2b_incremental.rs:91 global_unique_becomes_ambiguous_then_unique_again', 'crates/cc-eval/tests/p2b_incremental.rs:132 negative_path_and_precedence_changes_refresh_import_routes', 'crates/cc-eval/tests/p2c_reconcile.rs:119 python_graph_rejects_false_calls_and_preserves_unsupported_shadow_on_reload', 'crates/cc-eval/tests/p2c_reconcile.rs:323 reexport_cycle_and_deep_chain_converge_across_bounded_rounds'], 'decision': 'Do not restore legacy lookup_dependencies/schema8 over current schema25. Listed tests establish current intended coverage in source only, not complete runtime equivalence to all legacy cases.'},
  {'prs': [4], 'intent': 'Partial/degraded output and cache decisions', 'status': 'current typed lane outcomes and graph cacheability checks cover the intent', 'current': ['crates/cc-search/src/engine_graph.rs:179 requires no read errors and all lanes cacheable'], 'limit': 'Old diagnostics wire shape is different; no wholesale adapter restoration.'},
  {'prs': [3, 4], 'intent': 'Legacy quality v2/v3 independent gold and exact raw replay artifacts', 'status': 'exact old manifests/examples/workflow/scripts absent; broad capabilities replaced but fixture-specific disposition remains', 'current': ['crates/cc-eval/src/benchmark/report.rs:315 current replay entry and independent benchmark model'], 'decision': 'Keep original historical evidence and intent list. Decide which original gold scenarios remain useful before targeted fixture migration; do not install a second scoring/schema/CI stack merely to reproduce old filenames.'},
  {'prs': [4], 'intent': 'Historical dependency security updates', 'status': 'current locked versions are not all identical to PR4 claims', 'current_locked_versions': security_families, 'decision': 'Do not reuse historical zero-warning audit as a current security result or blindly downgrade the current lock. Current locked audit results/advisory scope must decide any necessary change.', 'limit': 'No vulnerability claim, advisory fetch or new audit execution was made.'}
 ],
 'disposition': {
   'pr3': 'Keep open for narrowly scoped residual migration until the identified tie hunk and old fixture/projection intent decisions are recorded. Do not merge the old branch wholesale and do not label the whole PR fully duplicated.',
   'pr4': 'Keep open as a stacked historical intent/evidence source pending fixture/contract disposition. Most inspected mechanisms have evolved replacements; absence counts alone are insufficient to close it as fully adopted.',
   'already_covered_hunks': 'Mark the scope/BM25/parser-local/typed-dependency/cache intents as current replacements in the management record. This is a per-intent statement, not a whole-PR merge or closure.',
   'actual_remote_action': 'none; root retains PR/ref authority'
 },
 'validation': {'source_and_tree_checks': 'passed scoped', 'legacy_native_or_benchmarks': 'not_run', 'current_native_regressions': 'not_run', 'new_tie_regressions': 'not_run; candidate only'},
 'accounting': {'formal_completion': False, 'done': 163, 'remaining': 29, 'new_todos_closed': 0},
}
p = OUT / 'legacy-pr3-pr4-disposition-review.json'
assert not p.exists()
p.write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
print(json.dumps(ref(p)))
