from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys

sys.dont_write_bytecode = True
root = Path('/dev/shm/pr-triage-bfcc-c8be5afa')
review = root / 'runtime-review-Gc8'
aid = 11609019055
base = root / 'raw-pr178-c8be5afa' / str(aid) / 'attempt01/extracted'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
canonical_path = review / 'exact-canonical-R.json'
assert sha(canonical_path) == 'c38d10f1b0d5935384039a6af7df6e8d222bc351a68d3137b09e664735ee9404'
canonical = json.loads(canonical_path.read_text())
receipt = json.loads((base / 'p8-build/build-receipt.json').read_text())
original_observers = receipt['observer_before']['files']
assert len(original_observers) == 9
preflight = []
for relative, original in sorted(original_observers.items()):
    path = base / 'p8-build/observer-source' / relative
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    mode = '100755' if path.stat().st_mode & 0o111 else '100644'
    assert not path.is_symlink()
    assert digest == canonical['validation_inputs'][relative] == original['sha256']
    assert blob == original['git_blob'] and mode == canonical['validation_modes'][relative] == original['git_mode']
    assert len(data) == original['bytes']
    preflight.append(dict(path=relative, bytes=len(data), sha256=digest, git_mode=mode, computed_git_blob=blob))
stages = [
    ('soak-primary-review-v2', 'primary-runtime-reviewer-v2.py', '764cd103b5c29591512a7e4e25ee5fdd083c62dcd65d63776247adecf7ae82ff', [str(aid), '40fb5824303044b8bb679def386b76caeab42189d2808302962eade1aea06360', 'soak', '4', '1']),
    ('soak-stdio-binding-review-v1', 'primary-soak-stdio-binding-reviewer-v1.py', '3a16ff6ffca2c3f251d00649b570b0d3615fa2fd212ce0cb743c518e919e55fa', [str(aid), '1']),
]
for name, script, expected, args in stages:
    path = review / script
    assert sha(path) == expected
    argv = [sys.executable, '-B', str(path), *args]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (review / (name + '.stdout')).open('xb') as out, (review / (name + '.stderr')).open('xb') as err:
        child = subprocess.run(argv, cwd=root, stdout=out, stderr=err)
    result = dict(schema_version=1, argv=argv, cwd=str(root), started_at=started,
                  completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  actual_exit=child.returncode, script_sha256=expected,
                  all_nine_original_modules_verified_before_any_import=preflight,
                  new_primary_samples=0,
                  scope='Only original Python verification and retained raw/stdio arithmetic. Original native product/oracle/statistics workload is not re-executed. No automatic retry.')
    for suffix in ['stdout', 'stderr']:
        p = review / (name + '.' + suffix)
        result[p.name] = dict(bytes=p.stat().st_size, sha256=sha(p))
    with (review / (name + '.command.json')).open('x') as f:
        json.dump(result, f, indent=2); f.write('\n')
    print(json.dumps(dict(stage=name, actual_exit=child.returncode)), flush=True)
    if child.returncode:
        raise SystemExit(child.returncode)
