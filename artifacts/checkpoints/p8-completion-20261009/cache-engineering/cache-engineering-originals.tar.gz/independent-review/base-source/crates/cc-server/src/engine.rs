//! Lightweight code-index engine for cc-server.
//!
//! Thin wrapper around cc-db, cc-index and cc-search.
//!
//! # Domain views
//!
//! `CodeIndex` itself only carries the index lifecycle (open/close/build),
//! the shared infrastructure accessors (`ensure_db`, `index_status`,
//! `repo_size_tier`, `output_budget`, `diagnostics_info`), and the lock
//! poison-recovery hook. All query surface area is grouped into three
//! zero-cost borrowed views, entered via:
//!
//! - [`CodeIndex::search`] → [`SearchOps`]: context search and task-to-symbol
//!   retrieval (`search_in_context`, `search_in_context_with`, `task_symbols`).
//! - [`CodeIndex::graph`] → [`GraphOps`]: symbol/file/graph lookups
//!   (`find_symbol`, `callers`, `graph_query`, `explore_symbols`,
//!   `graph_schema`, ...). Impl blocks live here and in `engine_query.rs`,
//!   mirroring the historical `CodeIndex` split across the two files.
//! - [`CodeIndex::impact`] → [`ImpactOps`]: change-impact analysis
//!   (`detect_impact*`, `analyze_impact*`, `git_changed_files`,
//!   `find_impacted_tests`), in `engine_query.rs`.

use cc_db::index_db::IndexDb;
use cc_index::{IndexReport, Indexer, PreparedBuild, StagedPostprocess, WrittenBuild};
use cc_model::config::{
    load_project_config, IndexPaths, IndexingConfig, ProjectConfig, ProjectStats, RepoSizeTier,
};
use cc_model::context::{ContextEnvelope, ContextNode, ContextSpan, NodeType, Role};
use cc_model::search::SearchRequest;
use cc_model::{CcError, CcResult, Intent};
use cc_search::SearchEngine;
use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};
use std::sync::Arc;

/// Owned inputs cloned from a `CodeIndex` under a brief read lock so that the
/// heavy, read-only `prepare_build` phase can run with no `CodeIndex` lock held.
/// The DB handle is shared (`Arc`); writes are still serialized by the caller's
/// write lock during `commit_build`.
pub struct BuildInputs {
    db: Arc<IndexDb>,
    project: PathBuf,
    indexing: IndexingConfig,
}

/// Result of `CodeIndex::graph_query`, carrying the flattened rows plus
/// truncation signals so callers can distinguish a complete result from one
/// that was cut off by the default LIMIT.
#[derive(Debug, Clone, serde::Serialize)]
pub struct GraphQueryOutput {
    pub rows: Vec<serde_json::Value>,
    pub row_count: usize,
    pub default_limit_applied: bool,
    pub limit: Option<usize>,
    /// Pre-serialized fast-path metadata (`{used:true}` / `{used:false,reason}`
    /// / `None`). Sourced from `CypherResult::fast_path` via
    /// `FastPathDecision::as_metadata()`, so the value reported at the response
    /// boundary is exactly what execution produced — no second tokenization of
    /// the query. `None` (non-traversal queries) means the field is omitted.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub fast_path: Option<serde_json::Value>,
}

fn estimate_project_file_count(project: &Path) -> usize {
    const EXCLUDED_DIRS: &[&str] = &[
        ".git",
        ".codecortex",
        "target",
        "node_modules",
        ".next",
        "dist",
        "build",
        "vendor",
    ];

    let mut count = 0usize;
    let mut stack = vec![project.to_path_buf()];
    while let Some(dir) = stack.pop() {
        let Ok(entries) = std::fs::read_dir(&dir) else {
            continue;
        };
        for entry in entries.flatten() {
            let path = entry.path();
            let Ok(file_type) = entry.file_type() else {
                continue;
            };
            if file_type.is_dir() {
                let name = entry.file_name();
                let name = name.to_string_lossy();
                if !EXCLUDED_DIRS.contains(&name.as_ref()) {
                    stack.push(path);
                }
            } else if file_type.is_file() {
                count += 1;
            }
        }
    }
    count
}

pub struct CodeIndex {
    pub project_path: Option<PathBuf>,
    config: Option<ProjectConfig>,
    pub(crate) index_db: Option<Arc<IndexDb>>,
    engine: Option<Arc<SearchEngine>>,
    query_services: Arc<crate::service_factory::QueryServices>,
    #[cfg(feature = "semantic")]
    semantic_subsystem: Option<Arc<crate::semantic_wiring::SemanticSubsystem>>,
    #[cfg(feature = "semantic")]
    semantic_runtime: Option<Arc<crate::semantic_runtime::SemanticRuntime>>,
    pub(crate) repo_tier: Option<RepoSizeTier>,
    /// True when the DB was freshly created (Initialized) or rebuilt after a
    /// schema mismatch — signals that an auto-index build is needed.
    needs_initial_index: bool,
    /// Per-project build gate serializing prepare+commit pairs across every
    /// build entry point (manual MCP `index`, watcher ticks, auto-index).
    /// Created once at construction and untouched by `close()`/`reopen()` so
    /// serialization survives idle eviction.
    ///
    /// Lock-ordering rule: in the build flow the gate is acquired BEFORE any
    /// CodeIndex RwLock acquisition, and no thread may block on the gate
    /// while holding the RwLock — callers that already hold the write lock
    /// (`&mut self` builds) may only `try_lock` and must surface "busy" as an
    /// error instead of waiting.
    build_gate: Arc<std::sync::Mutex<()>>,
}

/// Borrowed view over [`CodeIndex`] for the search domain: context search and
/// task-to-symbol retrieval. Obtained via [`CodeIndex::search`].
#[derive(Clone, Copy)]
pub struct SearchOps<'a>(pub(crate) &'a CodeIndex);

/// Borrowed view over [`CodeIndex`] for the graph domain: symbol, file, and
/// graph lookups. Obtained via [`CodeIndex::graph`].
#[derive(Clone, Copy)]
pub struct GraphOps<'a>(pub(crate) &'a CodeIndex);

/// Borrowed view over [`CodeIndex`] for the impact domain: change-impact
/// analysis over the call graph and git diffs. Obtained via
/// [`CodeIndex::impact`].
#[derive(Clone, Copy)]
pub struct ImpactOps<'a>(pub(crate) &'a CodeIndex);

impl CodeIndex {
    /// Enter the search domain view.
    pub fn search(&self) -> SearchOps<'_> {
        SearchOps(self)
    }

    /// Enter the graph domain view.
    pub fn graph(&self) -> GraphOps<'_> {
        GraphOps(self)
    }

    /// Enter the impact domain view.
    pub fn impact(&self) -> ImpactOps<'_> {
        ImpactOps(self)
    }

    pub fn new(project_path: Option<&Path>) -> CcResult<Self> {
        let mut index = Self::empty();
        if let Some(path) = project_path {
            index.set_project(path, false)?;
        }
        Ok(index)
    }

    pub fn empty() -> Self {
        Self {
            project_path: None,
            config: None,
            index_db: None,
            engine: None,
            query_services: Arc::new(crate::service_factory::QueryServices::default()),
            #[cfg(feature = "semantic")]
            semantic_subsystem: None,
            #[cfg(feature = "semantic")]
            semantic_runtime: None,
            repo_tier: None,
            needs_initial_index: false,
            build_gate: Arc::new(std::sync::Mutex::new(())),
        }
    }

    pub fn set_project(&mut self, path: &Path, auto_index: bool) -> CcResult<()> {
        let project = path.canonicalize().unwrap_or_else(|_| path.to_path_buf());
        let config = load_project_config(&project);
        let paths = IndexPaths::new(&project);
        std::fs::create_dir_all(&paths.workdir)?;
        std::fs::create_dir_all(&paths.logs_dir)?;

        let estimated_files = estimate_project_file_count(&project);
        let read_pool_size = config
            .indexing
            .db_read_pool_size
            .unwrap_or_else(|| RepoSizeTier::from_file_count(estimated_files).db_read_pool_size());
        let (db, schema_status) =
            IndexDb::open_with_read_pool_size(&paths.index_db, read_pool_size)?;
        let db = Arc::new(db);
        let repo_tier = Some(RepoSizeTier::from_file_count(estimated_files));
        let engine = SearchEngine::new(db.clone(), &config, repo_tier);

        let query_services = if self
            .project_path
            .as_ref()
            .is_some_and(|old| old != &project)
        {
            Arc::new(crate::service_factory::QueryServices::default())
        } else {
            self.query_services.clone()
        };
        // Validate and assemble before publishing any new project state.
        // Initialization resolves configuration only; it never calls a provider.
        #[cfg(feature = "semantic")]
        let semantic_subsystem =
            crate::semantic_wiring::assemble(&project.to_string_lossy(), &config, db.clone())?
                .map(Arc::new);
        #[cfg(feature = "semantic-http")]
        let semantic_runtime = match semantic_subsystem.as_ref() {
            Some(subsystem) => crate::semantic_runtime::from_config(
                db.clone(),
                subsystem.clone(),
                query_services.clone(),
                &config.semantic,
            )?,
            None => None,
        };
        self.query_services = query_services;
        #[cfg(feature = "semantic")]
        {
            if let Some(worker) = self.semantic_runtime.take() {
                worker.close();
            }
            match semantic_subsystem.as_ref() {
                Some(subsystem) => crate::semantic_wiring::attach(&self.query_services, subsystem),
                None => crate::semantic_wiring::teardown(&self.query_services),
            }
            self.semantic_subsystem = semantic_subsystem;
            #[cfg(feature = "semantic-http")]
            {
                if let Some(worker) = &semantic_runtime {
                    worker.authorize_configured_space_transition();
                }
                self.semantic_runtime = semantic_runtime;
            }
        }
        self.project_path = Some(project);
        self.config = Some(config);
        self.index_db = Some(db);
        self.engine = Some(Arc::new(engine));
        self.repo_tier = repo_tier;
        self.needs_initial_index = matches!(
            schema_status,
            cc_db::index_migrate::SchemaStatus::Initialized
        );

        if auto_index {
            // set_project itself succeeded (project/db/engine are all set);
            // surface the auto-index failure instead of silently dropping it.
            // Don't fail the whole call: the project is usable, and auto-index
            // skips oversized repos (auto_index.file_limit) by design — those
            // expected skips shouldn't make set_project look like it failed.
            if let Err(e) = self.build_auto_index(false) {
                tracing::warn!(
                    error = %e,
                    "auto-index after set_project failed; project is set, run `index` to build manually"
                );
            }
        }
        Ok(())
    }

    pub fn close(&mut self) {
        // The db_identity is process-unique and never reused, so this
        // handle's process-global graph cache entries can never be hit again
        // after the handle drops — evict them now instead of letting them
        // linger until 16 other identities push them out of each slot's LRU.
        if let Some(db) = &self.index_db {
            crate::graph_read_model::evict_project(db.admin().instance_id());
        }
        #[cfg(feature = "semantic")]
        {
            if let Some(worker) = self.semantic_runtime.take() {
                worker.close();
            }
            crate::semantic_wiring::teardown(&self.query_services);
            self.semantic_subsystem = None;
        }
        self.engine = None;
        self.index_db = None;
    }

    /// Owned initialization handle for lock-free, caller-driven scheduling.
    /// Cloning this handle performs no provider call and starts no worker.
    #[cfg(feature = "semantic")]
    pub fn semantic_subsystem(&self) -> Option<Arc<crate::semantic_wiring::SemanticSubsystem>> {
        self.semantic_subsystem.clone()
    }

    /// Attach an explicitly authorized provider; installation performs no I/O.
    #[cfg(feature = "semantic")]
    pub fn install_semantic_provider(
        &mut self,
        provider: Arc<dyn cc_semantic::ports::EmbeddingProvider>,
    ) -> CcResult<()> {
        let subsystem = self
            .semantic_subsystem
            .clone()
            .ok_or_else(|| CcError::InvalidParams("semantic subsystem disabled".into()))?;
        let db = self
            .index_db
            .clone()
            .ok_or_else(|| CcError::InvalidParams("project closed".into()))?;
        let worker = crate::semantic_runtime::SemanticRuntime::new(
            db,
            subsystem,
            self.query_services.clone(),
            provider,
        )?;
        if let Some(old) = self.semantic_runtime.take() {
            old.close();
        }
        worker.authorize_configured_space_transition();
        self.semantic_runtime = Some(worker);
        Ok(())
    }
    #[cfg(feature = "semantic")]
    pub fn semantic_runtime(&self) -> Option<Arc<crate::semantic_runtime::SemanticRuntime>> {
        self.semantic_runtime.clone()
    }

    pub fn is_closed(&self) -> bool {
        self.project_path.is_some() && self.index_db.is_none()
    }

    pub fn reopen(&mut self) -> CcResult<()> {
        if !self.is_closed() {
            return Ok(());
        }
        let path = self.project_path.clone().ok_or(CcError::ProjectNotSet)?;
        self.set_project(&path, false)
    }

    pub fn index_db(&self) -> Option<&Arc<IndexDb>> {
        self.index_db.as_ref()
    }

    /// Clone the per-project build gate. Callers must follow the
    /// lock-ordering rule documented on the field: acquire the gate before
    /// any CodeIndex RwLock acquisition in the build flow, and never block on
    /// the gate while holding the RwLock.
    pub fn build_gate(&self) -> Arc<std::sync::Mutex<()>> {
        self.build_gate.clone()
    }

    /// Acquire the build gate without blocking, for build entry points that
    /// run with the CodeIndex write lock already held (`&mut self`). Blocking
    /// here could deadlock against a gated split build waiting for that same
    /// write lock, so "busy" is surfaced as an error instead.
    fn try_acquire_build_gate(
        gate: &Arc<std::sync::Mutex<()>>,
    ) -> CcResult<std::sync::MutexGuard<'_, ()>> {
        match gate.try_lock() {
            Ok(permit) => Ok(permit),
            Err(std::sync::TryLockError::WouldBlock) => Err(CcError::BuildBusy),
            // The gate guards no data — only build ordering — so a poisoned
            // gate is safe to recover.
            Err(std::sync::TryLockError::Poisoned(poisoned)) => Ok(poisoned.into_inner()),
        }
    }

    /// Whether this CodeIndex was freshly created (empty DB) and needs an
    /// initial index build. Cleared after a successful build.
    pub fn needs_initial_index(&self) -> bool {
        self.needs_initial_index
    }

    pub(crate) fn ensure_project(&self) -> CcResult<&Path> {
        self.project_path.as_deref().ok_or(CcError::ProjectNotSet)
    }

    pub(crate) fn ensure_db(&self) -> CcResult<&Arc<IndexDb>> {
        self.index_db.as_ref().ok_or(CcError::ProjectNotSet)
    }

    fn ensure_engine(&self) -> CcResult<&Arc<SearchEngine>> {
        self.engine.as_ref().ok_or(CcError::ProjectNotSet)
    }

    pub fn query_handle(&self) -> CcResult<crate::query_handle::QueryHandle> {
        Ok(crate::query_handle::QueryHandle {
            db: self.ensure_db()?.clone(),
            engine: self.ensure_engine()?.clone(),
            project: self.ensure_project()?.to_path_buf(),
            tier: self.repo_size_tier(),
            config: self.ensure_config()?.query.clone(),
            services: self.query_services.clone(),
            _pin: self.query_services.pin(),
            _runtime: None,
        })
    }
    pub fn set_semantic_recall(&self, port: Option<Arc<dyn cc_model::semantic::SemanticRecall>>) {
        self.query_services.set_semantic(port);
    }

    fn ensure_config(&self) -> CcResult<&ProjectConfig> {
        self.config.as_ref().ok_or(CcError::ProjectNotSet)
    }

    pub fn build_index(&mut self, full: bool) -> CcResult<IndexReport> {
        let gate = self.build_gate();
        let _build_permit = Self::try_acquire_build_gate(&gate)?;
        let inputs = self.build_inputs()?;
        let indexer = Indexer::new(inputs.db.clone(), &inputs.project, &inputs.indexing);
        let report = indexer.build_index(&inputs.project, full)?;
        self.after_successful_index_build();
        Ok(report)
    }

    /// Bundled auto-index entry point (prepare + commit inline), routed
    /// through the same split internals as the lock-aware callers so every
    /// index build shares one implementation. Callers that must not hold the
    /// `CodeIndex` write lock during prepare should instead clone
    /// `build_inputs`/`auto_index_file_limit` under a read lock, run
    /// `prepare_build` with no lock, and `commit_build` under the write lock.
    pub fn build_auto_index(&mut self, full: bool) -> CcResult<IndexReport> {
        let gate = self.build_gate();
        let _build_permit = Self::try_acquire_build_gate(&gate)?;
        let file_limit = self.auto_index_file_limit()?;
        let inputs = self.build_inputs()?;
        let prepared = Self::prepare_build(&inputs, full, Some(file_limit))?;
        self.commit_build(&inputs, full, Some(file_limit), prepared)
    }

    /// Auto-index file-count gate (`auto_index.file_limit` from project
    /// config), passed as `auto_file_limit` to the split prepare/commit pair
    /// so oversized repos are skipped during the lock-free prepare phase.
    pub fn auto_index_file_limit(&self) -> CcResult<usize> {
        Ok(self.ensure_config()?.auto_index.file_limit)
    }

    /// Clone the owned inputs needed to drive a split build. Call this under a
    /// brief read lock, then release the lock before running `prepare_build`.
    pub fn build_inputs(&self) -> CcResult<BuildInputs> {
        let project = self.ensure_project()?;
        // One bounded config read per build, never one per import/chunk. A
        // long-lived MCP session must not pin the startup chunk policy forever.
        let config = load_project_config(project);
        config.indexing.chunk_policy().validate()?;
        let db = self.ensure_db()?;
        Ok(BuildInputs {
            db: db.clone(),
            project: project.to_path_buf(),
            indexing: config.indexing.clone(),
        })
    }

    /// Run the read-only prepare phase with no `CodeIndex` lock held. This is an
    /// associated function (no `self`) by design: the caller holds the inputs
    /// across the unlocked window and passes the resulting `PreparedBuild` to
    /// [`CodeIndex::commit_build`]. `full`/`auto_file_limit` must match the
    /// paired `commit_build` call.
    pub fn prepare_build(
        inputs: &BuildInputs,
        full: bool,
        auto_file_limit: Option<usize>,
    ) -> CcResult<PreparedBuild> {
        Self::prepare_build_scoped(inputs, full, auto_file_limit, None)
    }

    /// [`CodeIndex::prepare_build`] with an event-scoped hint: watcher ticks
    /// pass their drained change set so the scan/diff phase can stat/hash
    /// only those paths instead of walking the whole tree.
    pub fn prepare_build_scoped(
        inputs: &BuildInputs,
        full: bool,
        auto_file_limit: Option<usize>,
        scope: Option<&cc_index::BuildScope>,
    ) -> CcResult<PreparedBuild> {
        let indexer = Indexer::new(inputs.db.clone(), &inputs.project, &inputs.indexing);
        indexer.prepare_build_scoped(&inputs.project, full, auto_file_limit, scope)
    }

    /// Commit a previously prepared build under the caller's write lock. Runs
    /// `phase_write` plus postprocess/analysis (the three commit stages
    /// composed inline), then performs the post-build bookkeeping
    /// (`after_successful_index_build`). `full`/`auto_file_limit` must match
    /// the values passed to the paired `prepare_build`. Callers that can drop
    /// the write lock between stages should use the staged trio below instead.
    pub fn commit_build(
        &mut self,
        inputs: &BuildInputs,
        full: bool,
        auto_file_limit: Option<usize>,
        prepared: PreparedBuild,
    ) -> CcResult<IndexReport> {
        let indexer = Indexer::new(inputs.db.clone(), &inputs.project, &inputs.indexing);
        let report = indexer.commit_build(&inputs.project, full, auto_file_limit, prepared)?;
        self.after_successful_index_build();
        Ok(report)
    }

    /// Stage 1 of the staged commit: generation guard + `phase_write` under
    /// the caller's write lock (`&mut self` enforces it at the type level).
    /// The lock may be released afterwards — postprocess compute does not
    /// need it. Callers must keep holding the per-project build gate across
    /// all three stages.
    pub fn commit_build_write(
        &mut self,
        inputs: &BuildInputs,
        full: bool,
        auto_file_limit: Option<usize>,
        prepared: PreparedBuild,
    ) -> CcResult<WrittenBuild> {
        let indexer = Indexer::new(inputs.db.clone(), &inputs.project, &inputs.indexing);
        indexer.commit_build_write(&inputs.project, full, auto_file_limit, prepared)
    }

    /// Stage 2 of the staged commit: postprocess/analysis compute. Like
    /// [`CodeIndex::prepare_build`], this is an associated function (no
    /// `self`) by design — it must run with NO CodeIndex lock held, reading
    /// the just-committed snapshot through the read pool. Readers may observe
    /// stage-1 content without refreshed postprocess artifacts during this
    /// window (accepted eventually-consistent behavior; see `cc_index`'s
    /// `build_plan` module doc).
    pub fn compute_postprocess(
        inputs: &BuildInputs,
        full: bool,
        auto_file_limit: Option<usize>,
        written: WrittenBuild,
    ) -> CcResult<StagedPostprocess> {
        let indexer = Indexer::new(inputs.db.clone(), &inputs.project, &inputs.indexing);
        indexer.compute_build_postprocess(&inputs.project, full, auto_file_limit, written)
    }

    /// Stage 3 of the staged commit: apply the staged deltas (short DB
    /// transactions) under the caller's write lock, then perform the
    /// post-build bookkeeping (`after_successful_index_build`).
    pub fn apply_postprocess(
        &mut self,
        inputs: &BuildInputs,
        full: bool,
        auto_file_limit: Option<usize>,
        staged: StagedPostprocess,
    ) -> CcResult<IndexReport> {
        let indexer = Indexer::new(inputs.db.clone(), &inputs.project, &inputs.indexing);
        let report = indexer.apply_build_postprocess(full, auto_file_limit, staged)?;
        self.after_successful_index_build();
        Ok(report)
    }

    fn after_successful_index_build(&mut self) {
        // No manual cache invalidation: the cc-db persisted epoch vector
        // (index_epoch/evidence_epoch, bumped inside every write transaction)
        // is the single index clock — both the SearchEngine result cache and
        // the GraphReadModel caches key their entries on it.
        self.repo_tier = Some(self.compute_repo_tier());
        self.needs_initial_index = false;
    }

    /// Drop cached search results after recovering a poisoned lock — they may
    /// have been computed from a half-mutated CodeIndex. The cc-db persisted
    /// epoch vector remains the only index clock for search/graph caches;
    /// poison recovery additionally calls `engine.invalidate_cache()` because
    /// the epochs cannot tell results computed from a half-mutated CodeIndex
    /// apart from valid ones.
    ///
    /// Retire the old Arc-owned engine before replacing it. Detached queries
    /// fail their liveness/publication checks instead of repopulating its cache.
    pub fn invalidate_search_cache_after_poison(&mut self) {
        if let Some(engine) = self.engine.as_ref() {
            engine.retire();
        }
        if let (Some(db), Some(config)) = (&self.index_db, &self.config) {
            self.engine = Some(Arc::new(SearchEngine::new(
                db.clone(),
                config,
                self.repo_tier,
            )));
        }
    }

    pub fn index_status(&self) -> CcResult<ProjectStats> {
        let project = self.ensure_project()?;
        self.ensure_db()?.reads().stats(project)
    }

    pub(crate) fn idle_timeout_secs(&self) -> u64 {
        self.config
            .as_ref()
            .map(|c| c.auto_index.idle_timeout_secs)
            .unwrap_or(60)
    }

    pub fn capabilities_info(&self) -> serde_json::Value {
        crate::capability_status::snapshot(
            self.project_path.as_deref(),
            self.index_db.as_deref(),
            self.config.as_ref(),
            &self.query_services,
        )
    }

    pub fn query_pins(&self) -> usize {
        self.query_services.query_pins()
    }

    pub fn diagnostics_info(&self) -> serde_json::Value {
        let schema_version = cc_db::index_migrate::CURRENT_SCHEMA_VERSION;

        let db_schema_version = self
            .index_db
            .as_ref()
            .and_then(|db| db.reads().schema_version().ok());

        let last_indexed = self
            .index_db
            .as_ref()
            .and_then(|db| db.reads().get_metadata("last_indexed_at").ok().flatten());

        let auto_index_enabled = self
            .config
            .as_ref()
            .map(|c| c.auto_index.enabled)
            .unwrap_or(true);

        // Search result-cache hit/miss counters (the warm/cold split behind
        // per-tool latency). `cache_stats()` is a cheap atomic snapshot; the
        // counters are monotonic over the engine's lifetime. `None` before the
        // engine is constructed (no build yet) — serializes as null.
        let search_cache = self.engine.as_ref().map(|engine| {
            let stats = engine.cache_stats();
            serde_json::json!({
                "result_hits": stats.result_hits,
                "result_misses": stats.result_misses,
                "result_hit_rate": stats.result_hit_rate(),
                "graph_hits": stats.graph_hits,
                "graph_misses": stats.graph_misses,
                "graph_hit_rate": stats.graph_hit_rate(),
            })
        });

        serde_json::json!({
            "schema_version": schema_version,
            "db_schema_version": db_schema_version,
            "last_indexed_at": last_indexed,
            "auto_index_enabled": auto_index_enabled,
            "lock_poison_recovered": crate::handlers::poison_recovered(),
            "query_execution": self.query_services.pool.stats(),
            "semantic_configured": self.query_services.semantic().is_some(),
            "retrieval": self.capabilities_info()["retrieval"].clone(),
            "search_cache": search_cache,
            "process_resources": cc_index::current_process_usage(),
        })
    }
}

impl SearchOps<'_> {
    pub fn search_in_context(
        &self,
        query: &str,
        top_k: usize,
        intent: Option<Intent>,
    ) -> CcResult<ContextEnvelope> {
        self.0
            .query_handle()?
            .search_in_context(query, top_k, intent)
    }
    pub fn search_in_context_with(
        &self,
        query: &str,
        top_k: usize,
        intent: Option<Intent>,
        overrides: SearchRequest,
    ) -> CcResult<ContextEnvelope> {
        self.0
            .query_handle()?
            .search_in_context_with(query, top_k, intent, overrides)
    }
    pub fn task_symbols(
        &self,
        task: &str,
        max_symbols: Option<usize>,
        expand_depth: Option<usize>,
        intent: Option<&str>,
    ) -> CcResult<serde_json::Value> {
        self.0
            .query_handle()?
            .task_symbols(task, max_symbols, expand_depth, intent)
    }
}

impl crate::query_handle::QueryHandle {
    pub fn search_in_context(
        &self,
        query: &str,
        top_k: usize,
        intent: Option<Intent>,
    ) -> CcResult<ContextEnvelope> {
        self.search_in_context_with(query, top_k, intent, SearchRequest::default())
    }

    pub fn search_in_context_with(
        &self,
        query: &str,
        top_k: usize,
        intent: Option<Intent>,
        overrides: SearchRequest,
    ) -> CcResult<ContextEnvelope> {
        self.config.validate()?;
        let mut overrides = overrides;
        let budget = std::time::Duration::from_millis(self.config.deadline_ms);
        overrides.control = Some(match &overrides.control {
            Some(control) => control.limit_total(budget),
            None => cc_model::query::QueryControl::new(budget)?,
        });
        self.engine
            .with_stable_generation(|generation| {
                self.assemble_context_once(query, top_k, intent, overrides.clone(), generation)
            })
            .map(|(_, value)| value)
    }

    fn assemble_context_once(
        &self,
        query: &str,
        top_k: usize,
        intent: Option<Intent>,
        overrides: SearchRequest,
        generation: cc_model::generation::ReadGeneration,
    ) -> CcResult<ContextEnvelope> {
        self.engine.check_live()?;
        let tier = self.tier;
        let token_budget = tier.default_token_budget();
        let max_output_chars = tier.max_output_chars();
        let top_k = if top_k == 0 {
            tier.search_top_k()
        } else {
            top_k
        };
        let engine = &self.engine;
        let detected_intent = intent.unwrap_or_else(|| detect_intent(query));
        let mut request = build_context_search_request(query, top_k, overrides);
        request.intent = Some(detected_intent);
        self.config.validate()?;
        let control = match &request.control {
            Some(c) => c.limit_total(std::time::Duration::from_millis(self.config.deadline_ms)),
            None => cc_model::query::QueryControl::new(std::time::Duration::from_millis(
                self.config.deadline_ms,
            ))?,
        };
        request.control = Some(control.clone());
        let policy = cc_search::query_policy::QueryPolicy::resolve(
            &self.config,
            &request,
            request.semantic.is_some(),
        )?;
        control.check()?;
        // Graph-aware rerank happens entirely inside cc-search: it searches a
        // rerank_window-sized candidate list, folds graph connectivity into
        // rerank_score, and returns the FINAL bounded ranking. The evidence
        // selector chooses a subset without changing that order or its scores.
        let graph_limits = tier.graph_enrich_limits();
        // The returned Arc is a shared, possibly cached pair — read-only by
        // contract (mutating it would corrupt cc-search's graph-aware cache).
        let search_outcome =
            engine.search_context_candidates(&request, &graph_limits, token_budget)?;
        let enrichment = &search_outcome.1;
        let mut verifier = cc_search::evidence_hydrator::EvidenceHydrator::new(
            &self.db,
            &self.project,
            cc_search::query_policy::hard_scope(&request)?,
            generation,
            control.clone(),
        )?;
        let hits = verifier.hydrate(&search_outcome.0)?;

        let (hits, selection) = cc_search::selection::coverage::select_with_query(
            &hits,
            detected_intent,
            top_k,
            query,
        )?;

        let mut nodes = Vec::with_capacity(hits.len());
        let mut spans = Vec::with_capacity(hits.len());
        let mut files = HashSet::new();
        let mut rendered_sections = Vec::new();

        for (idx, hit) in hits.iter().enumerate() {
            files.insert(hit.file_path.clone());
            let node_id = format!("search:{}", hit.chunk_id);
            let title = format!(
                "{} {}:{}-{}",
                hit.file_path, hit.breadcrumb, hit.start_line, hit.end_line
            );
            let role = if hit.reasons.iter().any(|r| r == "doc-file") {
                Role::DocContext
            } else {
                Role::Primary
            };
            let mut node = ContextNode::new(
                node_id.clone(),
                NodeType::SearchHit,
                role,
                title.clone(),
                hit.text.clone(),
            );
            node.file_path = Some(hit.file_path.clone());
            node.start_line = Some(hit.start_line);
            node.end_line = Some(hit.end_line);
            node.score = hit.rerank_score;
            node.confidence = 0.8;
            node.source = hit.source.clone();
            node.reasons = hit.reasons.clone();
            node.invalidation_keys = vec![hit.file_path.clone()];
            node.metadata = hit.metadata.clone();
            node.span_kind = Some("indexed_chunk".to_string());
            node.backing_file_path = Some(hit.file_path.clone());
            node.source_start_line = Some(hit.start_line);
            node.source_end_line = Some(hit.end_line);

            spans.push(ContextSpan {
                node_id,
                file_path: Some(hit.file_path.clone()),
                start_line: Some(hit.start_line),
                end_line: Some(hit.end_line),
                label: hit.breadcrumb.clone(),
            });

            rendered_sections.push(format!(
                "## {}. {}:{}-{}\n{}",
                idx + 1,
                hit.file_path,
                hit.start_line,
                hit.end_line,
                hit.text
            ));
            nodes.push(node);
        }

        // Append graph context nodes within budget.
        let primary_tokens: u32 = nodes.iter().map(|n| n.token_estimate).sum();
        let graph_budget = (token_budget * graph_limits.graph_budget_pct) / 100;
        let mut graph_tokens_used = 0u32;
        let mut graph_rendered: Vec<String> = Vec::new();
        for gnode in &enrichment.nodes {
            if !verifier.graph_current(gnode)? {
                continue;
            }
            if graph_tokens_used + gnode.token_estimate > graph_budget {
                break;
            }
            graph_tokens_used += gnode.token_estimate;
            graph_rendered.push(format!("- {}", gnode.title));
            nodes.push(gnode.clone());
        }

        let token_estimate: u32 = primary_tokens + graph_tokens_used;
        let source_freshness = verifier.diagnostics();
        let incomplete = source_freshness["partial"] == true
            || enrichment
                .grep_diagnostics
                .as_ref()
                .is_some_and(|d| d.is_partial())
            || enrichment.lane_outcomes.iter().any(|lane| {
                matches!(
                    lane.status,
                    cc_model::retrieval::LaneStatus::Partial
                        | cc_model::retrieval::LaneStatus::Timeout
                        | cc_model::retrieval::LaneStatus::Unavailable
                        | cc_model::retrieval::LaneStatus::Error
                        | cc_model::retrieval::LaneStatus::Cancelled
                )
            });
        let summary = if hits.is_empty() && incomplete {
            format!(
                "No results found within the scan budget for `{query}`; retrieval is incomplete."
            )
        } else if hits.is_empty() {
            format!("No indexed code results found for `{}`.", query)
        } else {
            format!(
                "Found {} indexed code result(s) across {} file(s) for `{}`.",
                hits.len(),
                files.len(),
                query
            )
        };
        let mut rendered_prompt = format!(
            "Task: code-index search\nIntent: {}\nQuery: {}\n\n{}",
            detected_intent,
            query,
            rendered_sections.join("\n\n")
        );
        if !graph_rendered.is_empty() {
            rendered_prompt.push_str("\n\n## Graph Context\n");
            rendered_prompt.push_str(&graph_rendered.join("\n"));
        }

        // Unified explainability envelope (additive, same pattern as the
        // graph handlers): the enrichment's GraphExplain is attached only
        // when non-empty, so a clean run keeps the response shape unchanged.
        let mut graph_enrichment_summary = serde_json::json!({
            "symbols_resolved": enrichment.symbols_resolved,
            "callers_added": enrichment.callers_added,
            "callees_added": enrichment.callees_added,
            "tests_found": enrichment.tests_found,
        });
        if !enrichment.graph_explain.is_empty() {
            graph_enrichment_summary["graph_explain"] =
                serde_json::to_value(&enrichment.graph_explain)
                    .map_err(|e| CcError::Search(e.to_string()))?;
        }

        control.check()?;
        self.engine.check_live()?;
        let envelope = ContextEnvelope {
            task: query.to_string(),
            intent: detected_intent,
            query: query.to_string(),
            token_budget,
            token_estimate,
            summary,
            rendered_prompt,
            revision: 0,
            nodes,
            spans,
            reasons: {
                let mut r = vec!["hybrid search over code index".to_string()];
                if enrichment.symbols_resolved > 0 {
                    r.push("graph-enriched".to_string());
                }
                r
            },
            invalidations: Vec::new(),
            machine_pack: serde_json::json!({
                "kind": "code_index_context",
                "query": query,
                "top_k": top_k,
                "repo_size_tier": format!("{:?}", tier),
                "token_budget": token_budget,
                "hits": hits,
            }),
            evidence_summary: serde_json::json!({
                "source_freshness": source_freshness,
                "selection": selection,
                "search_hits": hits.len(),
                "files": files.into_iter().collect::<Vec<_>>(),
                "graph_enrichment": graph_enrichment_summary,
                "retrieval": {"lanes": enrichment.lane_outcomes, "grep": enrichment.grep_diagnostics, "scope": enrichment.scope_explain, "cost": enrichment.retrieval_cost, "policy":policy},
            }),
        };
        let envelope = cc_search::selection::budget::pack(envelope, max_output_chars)?;
        verifier.finish()?;
        self.engine.check_live()?;
        Ok(envelope)
    }
}

impl GraphOps<'_> {
    pub fn find_symbol_in_scope(
        &self,
        name: &str,
        exact: bool,
        top_k: usize,
        prefix: Option<&str>,
    ) -> CcResult<serde_json::Value> {
        let Some(prefix) = prefix else {
            return self.find_symbol(name, exact, top_k, false);
        };
        let prefix = cc_model::repo_path::normalize_relative(prefix)?;
        let db = self.0.ensure_db()?;
        let rows = db.retrieval().scoped_symbol_rows(
            name,
            exact,
            &cc_db::ChunkScope {
                path_prefix: Some(prefix),
                ..Default::default()
            },
            top_k,
        )?;
        Ok(serde_json::to_value(rows)?)
    }

    pub fn find_symbol(
        &self,
        name: &str,
        exact: bool,
        top_k: usize,
        include_metrics: bool,
    ) -> CcResult<serde_json::Value> {
        let db = self.0.ensure_db()?;
        let rows = db.reads().find_symbol(name, exact, top_k)?;
        if !include_metrics {
            return serde_json::to_value(&rows).map_err(|e| CcError::Search(e.to_string()));
        }
        let mut results: Vec<serde_json::Value> = Vec::with_capacity(rows.len());
        for row in &rows {
            let mut obj = serde_json::to_value(row).map_err(|e| CcError::Search(e.to_string()))?;
            if let Some(uid) = row.symbol_uid.as_deref() {
                if let Ok(info) = db.reads().symbol_degree_details(uid) {
                    let hint = centrality_hint(&info);
                    obj["metrics"] = serde_json::json!({
                        "in_degree": info.in_degree,
                        "out_degree": info.out_degree,
                        "caller_count": info.caller_count,
                        "callee_count": info.callee_count,
                        "ref_count": info.ref_count,
                        "centrality_hint": hint,
                    });
                }
            }
            results.push(obj);
        }
        Ok(serde_json::json!(results))
    }

    pub fn file_symbols(&self, file_path: &str) -> CcResult<Vec<cc_db::index_db::SymbolRow>> {
        self.0.ensure_db()?.reads().file_symbols(file_path)
    }

    pub fn list_indexed_files(&self) -> CcResult<Vec<cc_db::index_db::FileInfoRow>> {
        self.0.ensure_db()?.reads().list_indexed_files()
    }

    pub fn list_communities(&self) -> CcResult<Vec<cc_db::index_db::CommunityRow>> {
        self.0.ensure_db()?.reads().list_communities()
    }

    pub fn list_frameworks(&self) -> CcResult<Vec<(String, f64)>> {
        self.0.ensure_db()?.reads().list_repo_frameworks()
    }

    pub fn summarize_file(&self, file_path: &str) -> CcResult<serde_json::Value> {
        self.0.ensure_db()?.reads().file_summary(file_path)
    }

    pub fn graph_query(&self, query: &str) -> CcResult<GraphQueryOutput> {
        let db = self.0.ensure_db()?;

        let tokens = cc_search::cypher::tokenize(query)?;
        let parsed = cc_search::cypher::parse_tokens(&tokens)?;
        let result = cc_search::cypher::execute_parsed(&parsed, db)?;
        let default_limit_applied = result.default_limit_applied;
        let limit = result.limit;
        // Carry the fast-path decision the executor already computed, instead of
        // recomputing the gate against the raw query string at the response
        // boundary. Pre-serialized so GraphQueryOutput needs no FastPathDecision
        // dependency.
        let fast_path = result.fast_path.as_metadata();
        let rows: Vec<serde_json::Value> = result
            .rows
            .into_iter()
            .map(|row| {
                let mut map = serde_json::Map::new();
                for (i, val) in row.into_iter().enumerate() {
                    let key = result
                        .columns
                        .get(i)
                        .cloned()
                        .unwrap_or_else(|| format!("col{}", i));
                    map.insert(key, val);
                }
                serde_json::Value::Object(map)
            })
            .collect();
        let row_count = rows.len();
        Ok(GraphQueryOutput {
            rows,
            row_count,
            default_limit_applied,
            limit,
            fast_path,
        })
    }

    pub fn callers(
        &self,
        symbol_name: &str,
        limit: usize,
    ) -> CcResult<Vec<cc_db::index_db::CallEdgeLite>> {
        let db = self.0.ensure_db()?;
        let syms = db.reads().find_symbol(symbol_name, true, 1)?;
        let sym = syms
            .first()
            .ok_or_else(|| CcError::Search(format!("symbol not found: {}", symbol_name)))?;
        let uid = sym
            .symbol_uid
            .as_deref()
            .ok_or_else(|| CcError::Search("symbol has no uid".into()))?;
        db.reads().caller_rows_by_uid(uid, limit)
    }

    pub fn callees(
        &self,
        symbol_name: &str,
        limit: usize,
    ) -> CcResult<Vec<cc_db::index_db::CallEdgeLite>> {
        let db = self.0.ensure_db()?;
        let syms = db.reads().find_symbol(symbol_name, true, 1)?;
        let sym = syms
            .first()
            .ok_or_else(|| CcError::Search(format!("symbol not found: {}", symbol_name)))?;
        let uid = sym
            .symbol_uid
            .as_deref()
            .ok_or_else(|| CcError::Search("symbol has no uid".into()))?;
        db.reads().callee_rows_by_uid(uid, limit)
    }

    pub fn symbol_refs(
        &self,
        symbol_name: &str,
        limit: usize,
    ) -> CcResult<Vec<cc_db::index_db::SymbolRefLite>> {
        let db = self.0.ensure_db()?;
        let syms = db.reads().find_symbol(symbol_name, true, 1)?;
        let sym = syms
            .first()
            .ok_or_else(|| CcError::Search(format!("symbol not found: {}", symbol_name)))?;
        let uid = sym
            .symbol_uid
            .as_deref()
            .ok_or_else(|| CcError::Search("symbol has no uid".into()))?;
        db.reads().symbol_ref_rows_by_uid(uid, limit)
    }

    pub fn list_unresolved_refs(
        &self,
        limit: usize,
        file_path: Option<&str>,
        kind: Option<&str>,
    ) -> CcResult<serde_json::Value> {
        let db = self.0.ensure_db()?;
        let rows = db
            .reads()
            .list_resolution_attempts(limit.clamp(1, 500), file_path, kind)?;
        let mut by_kind: HashMap<String, usize> = HashMap::new();
        let mut with_candidates = 0usize;
        for row in &rows {
            *by_kind.entry(row.reference_kind.clone()).or_default() += 1;
            if row
                .candidates
                .as_array()
                .map(|a| !a.is_empty())
                .unwrap_or(false)
            {
                with_candidates += 1;
            }
        }
        Ok(serde_json::json!({
            "items": rows,
            "count": rows.len(),
            "with_candidates": with_candidates,
            "by_kind": by_kind,
            "filters": {
                "file_path": file_path,
                "kind": kind,
            }
        }))
    }
}

// One owned implementation shared by synchronous and asynchronous task callers.
impl crate::query_handle::QueryHandle {
    pub(crate) fn task_symbols_direct(
        &self,
        task: &str,
        max_symbols: Option<usize>,
        expand_depth: Option<usize>,
        _intent: Option<&str>,
    ) -> CcResult<Option<serde_json::Value>> {
        self.engine.check_live()?;
        let candidates = crate::symbol_extract::extract_candidate_symbols(task);
        let mut matched_symbols: Vec<serde_json::Value> = Vec::new();
        let mut matched_uids: Vec<String> = Vec::new();
        let mut seen_symbol_keys: HashSet<String> = HashSet::new();
        let mut seen_uids: HashSet<String> = HashSet::new();

        for name in &candidates {
            if let Ok(syms) = self.db.reads().find_symbol(name, true, 1) {
                for sym in &syms {
                    let dedup_key = sym.symbol_uid.clone().unwrap_or_else(|| {
                        format!("{}:{}:{}", sym.file_path, sym.name, sym.start_line)
                    });
                    if !seen_symbol_keys.insert(dedup_key) {
                        continue;
                    }
                    if let Some(uid) = &sym.symbol_uid {
                        if seen_uids.insert(uid.clone()) {
                            matched_uids.push(uid.clone());
                        }
                    }
                    matched_symbols.push(serde_json::json!({
                        "name": sym.name,
                        "kind": sym.kind,
                        "file_path": sym.file_path,
                        "start_line": sym.start_line,
                        "end_line": sym.end_line,
                        "symbol_uid": sym.symbol_uid,
                        "qname": sym.qname,
                        "signature": sym.signature,
                    }));
                }
            }
        }

        // Caller selects sync or async fallback; the symbol algorithm is shared.
        if matched_symbols.len() < 3 {
            return Ok(None);
        }

        let max_syms = max_symbols
            .unwrap_or_else(|| self.tier.explore_max_symbols())
            .clamp(1, 20);
        matched_symbols.truncate(max_syms);
        matched_uids.truncate(max_syms);

        let db = &self.db;

        let mut expanded_callers: Vec<serde_json::Value> = Vec::new();
        let mut expanded_callees: Vec<serde_json::Value> = Vec::new();
        let mut relevant_files: HashSet<String> = HashSet::new();

        // Collect file paths from matched symbols
        for sym in &matched_symbols {
            if let Some(fp) = sym.get("file_path").and_then(|v| v.as_str()) {
                relevant_files.insert(fp.to_string());
            }
        }

        // Expand callers/callees for each matched UID
        let depth = expand_depth.unwrap_or(1).min(3);
        let per_symbol_limit = depth * 3; // depth 1 = 3, depth 2 = 6, depth 3 = 9
        for uid in &matched_uids {
            if let Ok(callers) = db.reads().caller_rows_by_uid(uid, per_symbol_limit) {
                for edge in &callers {
                    relevant_files.insert(edge.file_path.clone());
                    expanded_callers.push(serde_json::json!({
                        "file_path": edge.file_path,
                        "line": edge.line,
                        "caller_symbol": edge.caller_symbol,
                        "callee_symbol": edge.callee_symbol,
                        "dispatch_kind": edge.dispatch_kind,
                        "synthesized_by": edge.synthesized_by,
                        "synthesis_key": edge.synthesis_key,
                        "registered_file": edge.registered_file,
                        "registered_line": edge.registered_line,
                    }));
                }
            }
            if let Ok(callees) = db.reads().callee_rows_by_uid(uid, per_symbol_limit) {
                for edge in &callees {
                    relevant_files.insert(edge.file_path.clone());
                    expanded_callees.push(serde_json::json!({
                        "file_path": edge.file_path,
                        "line": edge.line,
                        "caller_symbol": edge.caller_symbol,
                        "callee_symbol": edge.callee_symbol,
                        "dispatch_kind": edge.dispatch_kind,
                        "synthesized_by": edge.synthesized_by,
                        "synthesis_key": edge.synthesis_key,
                        "registered_file": edge.registered_file,
                        "registered_line": edge.registered_line,
                    }));
                }
            }
        }

        let mut files_sorted: Vec<String> = relevant_files.into_iter().collect();
        files_sorted.sort();

        self.engine.check_live()?;
        Ok(Some(serde_json::json!({
            "task": task,
            "candidates_extracted": candidates,
            "matched_symbols": matched_symbols,
            "expanded_callers": expanded_callers,
            "expanded_callees": expanded_callees,
            "relevant_files": files_sorted,
        })))
    }
}

// ── Free functions kept in engine.rs ───────────────────────────────────

/// Build the `SearchRequest` for `search_in_context_with`, merging the caller
/// supplied override fields (boost/recent/pinned/overlay files, conversation
/// queries, preselect limit, and `path_prefix`) onto the base query.
pub(crate) fn build_context_search_request(
    query: &str,
    top_k: usize,
    overrides: SearchRequest,
) -> SearchRequest {
    SearchRequest {
        query: query.to_string(),
        top_k,
        include_grep: true,
        boost_file_paths: overrides.boost_file_paths,
        retrieval_strategy: overrides.retrieval_strategy,
        intent: overrides.intent,
        control: overrides.control,
        semantic: overrides.semantic,
        recent_file_paths: overrides.recent_file_paths,
        pinned_file_paths: overrides.pinned_file_paths,
        conversation_queries: overrides.conversation_queries,
        overlay_file_paths: overrides.overlay_file_paths,
        file_preselect_limit: overrides.file_preselect_limit,
        path_prefix: overrides.path_prefix,
        languages: overrides.languages,
        file_paths: overrides.file_paths,
    }
}

pub(crate) fn detect_intent(query: &str) -> Intent {
    let q = query.to_lowercase();
    if q.contains("fix") || q.contains("bug") || q.contains("error") || q.contains("报错") {
        Intent::Fix
    } else if q.contains("refactor") || q.contains("重构") {
        Intent::Refactor
    } else if q.contains("trace") || q.contains("call") || q.contains("链路") {
        Intent::Trace
    } else if q.contains("test") || q.contains("测试") {
        Intent::Test
    } else if q.contains("explain") || q.contains("解释") || q.contains("说明") {
        Intent::Explain
    } else {
        Intent::Locate
    }
}

pub(crate) fn centrality_hint(info: &cc_db::index_db::SymbolDegreeInfo) -> &'static str {
    if info.out_degree > 5 * info.in_degree.max(1) {
        "hub"
    } else if info.in_degree > 5 * info.out_degree.max(1) {
        "authority"
    } else if info.in_degree <= 1 && info.out_degree <= 1 {
        "leaf"
    } else {
        "connector"
    }
}

pub use crate::engine_query::{compute_package_boundaries, PackageBoundary};

#[cfg(test)]
mod tests {
    use super::*;
    use cc_db::index_db::SymbolDegreeInfo;
    use tempfile::TempDir;

    // ── CodeIndex::new(None) → empty index ──────────────────────────

    #[test]
    fn new_with_none_creates_empty_index() {
        let idx = CodeIndex::new(None).unwrap();
        assert!(idx.project_path.is_none());
        assert!(idx.index_db.is_none());
        assert!(!idx.needs_initial_index());
    }

    // ── CodeIndex::empty() ──────────────────────────────────────────

    #[test]
    fn empty_has_no_project_or_db() {
        let idx = CodeIndex::empty();
        assert!(idx.project_path.is_none());
        assert!(idx.index_db.is_none());
        assert!(idx.index_db().is_none());
    }

    // ── ensure_db returns ProjectNotSet when no project ─────────────

    #[test]
    fn ensure_db_returns_project_not_set() {
        let idx = CodeIndex::empty();
        match idx.ensure_db() {
            Err(CcError::ProjectNotSet) => {}
            Err(other) => panic!("expected ProjectNotSet, got {:?}", other),
            Ok(_) => panic!("expected error but got Ok"),
        }
    }

    // ── ensure_project returns ProjectNotSet when no project ────────

    #[test]
    fn ensure_project_returns_project_not_set() {
        let idx = CodeIndex::empty();
        let err = idx.ensure_project().unwrap_err();
        assert!(matches!(err, CcError::ProjectNotSet));
    }

    // ── set_project on a valid temp directory ───────────────────────

    #[test]
    fn set_project_initializes_db_and_path() {
        let dir = TempDir::new().unwrap();
        let mut idx = CodeIndex::empty();
        idx.set_project(dir.path(), false).unwrap();

        assert!(idx.project_path.is_some());
        assert!(idx.index_db.is_some());
        assert!(idx.ensure_db().is_ok());
        assert!(idx.ensure_project().is_ok());
    }

    // ── close / is_closed / reopen cycle ────────────────────────────

    #[test]
    fn close_marks_index_closed_and_reopen_restores() {
        let dir = TempDir::new().unwrap();
        let mut idx = CodeIndex::empty();
        idx.set_project(dir.path(), false).unwrap();

        assert!(!idx.is_closed());

        idx.close();
        assert!(idx.is_closed());
        assert!(idx.index_db.is_none());

        idx.reopen().unwrap();
        assert!(!idx.is_closed());
        assert!(idx.index_db.is_some());
    }

    #[cfg(feature = "semantic")]
    #[test]
    fn semantic_initialization_failure_preserves_the_previous_project() {
        let old = TempDir::new().unwrap();
        let rejected = TempDir::new().unwrap();
        let mut idx = CodeIndex::new(Some(old.path())).unwrap();
        let original_db = idx.index_db.as_ref().unwrap().clone();
        std::fs::write(
            rejected.path().join(".codecortex.json"),
            r#"{"semantic":{"enabled":true}}"#,
        )
        .unwrap();
        assert!(idx.set_project(rejected.path(), false).is_err());
        assert_eq!(idx.project_path.as_deref(), Some(old.path()));
        assert!(Arc::ptr_eq(&original_db, idx.index_db.as_ref().unwrap()));
        assert!(idx.semantic_subsystem().is_none());
    }

    #[cfg(feature = "semantic")]
    #[test]
    fn semantic_lifecycle_retains_handle_and_tears_down_before_reopen() {
        let dir = TempDir::new().unwrap();
        let mut config = ProjectConfig::default();
        config.semantic.enabled = true;
        config.semantic.model_id = "fake/model-lifecycle".into();
        config.semantic.dimensions = Some(2);
        config.semantic.max_input_tokens = Some(8192);
        config.semantic.max_batch_items = Some(16);
        config.semantic.endpoint = "https://semantic.invalid/v1".into();
        std::fs::write(
            dir.path().join(".codecortex.json"),
            serde_json::to_vec(&config).unwrap(),
        )
        .unwrap();
        let mut idx = CodeIndex::new(Some(dir.path())).unwrap();
        assert!(idx.semantic_subsystem().is_some());
        assert!(idx.query_services.semantic().is_some());
        assert!(idx.query_services.semantic_wired().is_some());
        idx.close();
        assert!(idx.semantic_subsystem().is_none());
        assert!(idx.query_services.semantic().is_none());
        assert!(idx.query_services.semantic_wired().is_none());
        assert!(idx.query_services.semantic_degradation().is_none());
        idx.reopen().unwrap();
        assert!(idx.semantic_subsystem().is_some());
        assert!(idx.query_services.semantic().is_some());
        config.semantic.enabled = false;
        std::fs::write(
            dir.path().join(".codecortex.json"),
            serde_json::to_vec(&config).unwrap(),
        )
        .unwrap();
        idx.close();
        idx.reopen().unwrap();
        assert!(idx.semantic_subsystem().is_none());
        assert!(idx.query_services.semantic().is_none());
    }

    // ── is_closed is false when no project set ──────────────────────

    #[test]
    fn is_closed_false_when_no_project() {
        let idx = CodeIndex::empty();
        assert!(
            !idx.is_closed(),
            "empty index (no project) should not be considered 'closed'"
        );
    }

    // ── reopen is no-op when not closed ─────────────────────────────

    #[test]
    fn reopen_noop_when_not_closed() {
        let dir = TempDir::new().unwrap();
        let mut idx = CodeIndex::empty();
        idx.set_project(dir.path(), false).unwrap();

        // reopen on an already-open index should succeed without error
        idx.reopen().unwrap();
        assert!(idx.index_db.is_some());
    }

    // ── reopen fails when no project path ───────────────────────────

    #[test]
    fn reopen_fails_with_project_not_set_on_empty() {
        let mut idx = CodeIndex::empty();
        // Not closed (project_path is None), so reopen returns Ok immediately
        assert!(idx.reopen().is_ok());
    }

    // ── needs_initial_index after fresh set_project ─────────────────

    #[test]
    fn needs_initial_index_true_on_fresh_db() {
        let dir = TempDir::new().unwrap();
        let mut idx = CodeIndex::empty();
        idx.set_project(dir.path(), false).unwrap();

        // A freshly created DB should have SchemaStatus::Initialized
        assert!(idx.needs_initial_index());
    }

    #[test]
    fn successful_build_clears_initial_index_flag() {
        let dir = TempDir::new().unwrap();
        std::fs::write(dir.path().join("lib.rs"), "pub fn answer() -> i32 { 42 }\n").unwrap();

        let mut idx = CodeIndex::empty();
        idx.set_project(dir.path(), false).unwrap();
        assert!(idx.needs_initial_index());

        let report = idx.build_index(false).unwrap();

        assert!(report.files_scanned >= 1);
        assert!(!idx.needs_initial_index());

        let auto_report = idx.build_auto_index(false).unwrap();
        assert!(auto_report.files_scanned >= 1);
    }

    // ── build gate: &mut self builds must not wait on a busy gate ───

    #[test]
    fn bundled_build_errors_when_gate_busy() {
        let dir = TempDir::new().unwrap();
        std::fs::write(dir.path().join("lib.rs"), "pub fn answer() -> i32 { 42 }\n").unwrap();

        let mut idx = CodeIndex::empty();
        idx.set_project(dir.path(), false).unwrap();

        let gate = idx.build_gate();
        let _held = gate.lock().unwrap();

        // Callers of the `&mut self` builds already hold the write lock, so a
        // busy gate must surface as an error instead of blocking (deadlock).
        let err = idx.build_index(false).unwrap_err();
        assert!(
            err.to_string().contains("already in progress"),
            "unexpected gate-busy error: {err}"
        );
        let err = idx.build_auto_index(false).unwrap_err();
        assert!(
            err.to_string().contains("already in progress"),
            "unexpected gate-busy error: {err}"
        );
    }

    // ── auto-index file-limit gate fires during lock-free prepare ───

    #[test]
    fn auto_index_file_limit_gates_prepare() {
        let dir = TempDir::new().unwrap();
        std::fs::write(
            dir.path().join(".codecortex.json"),
            r#"{"auto_index": {"file_limit": 1}}"#,
        )
        .unwrap();
        std::fs::write(dir.path().join("a.rs"), "pub fn alpha() {}\n").unwrap();
        std::fs::write(dir.path().join("b.rs"), "pub fn beta() {}\n").unwrap();

        let mut idx = CodeIndex::empty();
        idx.set_project(dir.path(), false).unwrap();
        assert_eq!(idx.auto_index_file_limit().unwrap(), 1);

        // The gate fires inside the lock-free prepare half, so split callers
        // skip oversized repos without ever taking the write lock.
        let inputs = idx.build_inputs().unwrap();
        match CodeIndex::prepare_build(&inputs, false, Some(1)) {
            Ok(_) => panic!("prepare must be gated by the auto-index file limit"),
            Err(err) => assert!(
                err.to_string().contains("auto-index skipped"),
                "unexpected prepare error: {err}"
            ),
        }

        // The bundled entry point routes through the same split internals.
        match idx.build_auto_index(false) {
            Ok(_) => panic!("bundled auto-index must be gated by the file limit"),
            Err(err) => assert!(
                err.to_string().contains("auto-index skipped"),
                "unexpected bundled error: {err}"
            ),
        }
    }

    // ── build_context_search_request propagates overrides ──────────

    #[test]
    fn build_context_search_request_propagates_path_prefix() {
        let overrides = SearchRequest {
            path_prefix: Some("src/api/".to_string()),
            boost_file_paths: Some(vec!["src/main.rs".to_string()]),
            file_preselect_limit: Some(42),
            ..Default::default()
        };
        let request = build_context_search_request("login", 7, overrides);
        assert_eq!(request.query, "login");
        assert_eq!(request.top_k, 7);
        assert_eq!(request.path_prefix.as_deref(), Some("src/api/"));
        assert_eq!(
            request.boost_file_paths.as_deref(),
            Some(["src/main.rs".to_string()].as_slice())
        );
        assert_eq!(request.file_preselect_limit, Some(42));
    }

    // ── detect_intent free function ─────────────────────────────────

    #[test]
    fn detect_intent_fix_keywords() {
        assert_eq!(detect_intent("fix the bug"), Intent::Fix);
        assert_eq!(detect_intent("error in login"), Intent::Fix);
        assert_eq!(detect_intent("报错了"), Intent::Fix);
    }

    #[test]
    fn detect_intent_refactor() {
        assert_eq!(detect_intent("refactor this module"), Intent::Refactor);
        assert_eq!(detect_intent("需要重构"), Intent::Refactor);
    }

    #[test]
    fn detect_intent_trace() {
        assert_eq!(detect_intent("trace the call path"), Intent::Trace);
        assert_eq!(detect_intent("follow the 链路"), Intent::Trace);
    }

    #[test]
    fn detect_intent_test() {
        assert_eq!(detect_intent("add a test for this"), Intent::Test);
        assert_eq!(detect_intent("测试覆盖"), Intent::Test);
    }

    #[test]
    fn detect_intent_explain() {
        assert_eq!(detect_intent("explain how it works"), Intent::Explain);
        assert_eq!(detect_intent("解释一下"), Intent::Explain);
    }

    #[test]
    fn detect_intent_default_locate() {
        assert_eq!(detect_intent("find the symbol"), Intent::Locate);
        assert_eq!(detect_intent("where is this defined"), Intent::Locate);
    }

    // ── centrality_hint ─────────────────────────────────────────────

    #[test]
    fn centrality_hint_hub() {
        let info = SymbolDegreeInfo {
            in_degree: 1,
            out_degree: 10,
            caller_count: 0,
            callee_count: 0,
            ref_count: 0,
        };
        assert_eq!(centrality_hint(&info), "hub");
    }

    #[test]
    fn centrality_hint_authority() {
        let info = SymbolDegreeInfo {
            in_degree: 10,
            out_degree: 1,
            caller_count: 0,
            callee_count: 0,
            ref_count: 0,
        };
        assert_eq!(centrality_hint(&info), "authority");
    }

    #[test]
    fn centrality_hint_leaf() {
        let info = SymbolDegreeInfo {
            in_degree: 0,
            out_degree: 1,
            caller_count: 0,
            callee_count: 0,
            ref_count: 0,
        };
        assert_eq!(centrality_hint(&info), "leaf");
    }

    #[test]
    fn centrality_hint_connector() {
        let info = SymbolDegreeInfo {
            in_degree: 3,
            out_degree: 3,
            caller_count: 0,
            callee_count: 0,
            ref_count: 0,
        };
        assert_eq!(centrality_hint(&info), "connector");
    }

    // ── centrality_hint edge cases ──────────────────────────────────

    #[test]
    fn centrality_hint_zero_zero_is_leaf() {
        let info = SymbolDegreeInfo {
            in_degree: 0,
            out_degree: 0,
            caller_count: 0,
            callee_count: 0,
            ref_count: 0,
        };
        assert_eq!(centrality_hint(&info), "leaf");
    }

    // ── graph_query truncation signals ──────────────────────────────

    #[test]
    fn graph_query_signals_default_limit_when_omitted() {
        let dir = TempDir::new().unwrap();
        std::fs::write(dir.path().join("lib.rs"), "pub fn answer() -> i32 { 42 }\n").unwrap();

        let mut idx = CodeIndex::empty();
        idx.set_project(dir.path(), false).unwrap();
        idx.build_index(false).unwrap();

        // No explicit LIMIT → default limit applied, limit = DEFAULT_CYPHER_LIMIT.
        let output = idx
            .graph()
            .graph_query("MATCH (f:Function) RETURN f.name")
            .unwrap();
        assert!(output.default_limit_applied);
        assert_eq!(output.limit, Some(50));
        assert_eq!(output.row_count, output.rows.len());
    }

    #[test]
    fn graph_query_no_default_limit_when_explicit() {
        let dir = TempDir::new().unwrap();
        std::fs::write(dir.path().join("lib.rs"), "pub fn answer() -> i32 { 42 }\n").unwrap();

        let mut idx = CodeIndex::empty();
        idx.set_project(dir.path(), false).unwrap();
        idx.build_index(false).unwrap();

        // Explicit LIMIT → no default limit, limit reflects the explicit value.
        let output = idx
            .graph()
            .graph_query("MATCH (f:Function) RETURN f.name LIMIT 5")
            .unwrap();
        assert!(!output.default_limit_applied);
        assert_eq!(output.limit, Some(5));
    }

    // ── graph rerank parity fixture ─────────────────────────────────
    //
    // Fixates the end-to-end behaviour of `search_in_context_with`'s graph
    // rerank on a fixture with call edges: hit ORDER, graph_score values,
    // and rerank_score values were captured from the pre-refactor
    // implementation (graph_enrich in cc-server) and must stay bit-identical
    // after the rerank moves into cc-search.

    fn insert_context_fixture_file(
        root: &std::path::Path,
        db: &cc_db::index_db::IndexDb,
        file_path: &str,
        text: &str,
        symbol_name: &str,
        symbol_uid: Option<&str>,
        call_edges: Vec<cc_model::CallEdgeRecord>,
    ) {
        use cc_db::index_db::FileWriteUnit;
        use cc_model::{ChunkRecord, Language, ParseOutcome, ParserTier, SymbolRecord};

        // Keep independent scoring facts, but source evidence requires a real
        // matching original. No rank/score assertion is relaxed.
        let path = root.join(file_path);
        std::fs::create_dir_all(path.parent().unwrap()).unwrap();
        std::fs::write(path, text).unwrap();
        let snapshot = cc_model::source::SourceSnapshot::new(text.as_bytes());
        let chunk = ChunkRecord {
            source: Some(cc_model::source::ChunkSource {
                source: snapshot.identity().clone(),
                span: snapshot.whole(),
                slice_digest: snapshot.slice_digest(snapshot.whole()).unwrap(),
                boundary: "authored_fixture".into(),
                owner: None,
                signature: None,
            }),
            chunk_id: format!("chunk:{}", file_path),
            file_path: file_path.to_string(),
            language: Language::Rust,
            chunk_index: 0,
            start_line: 1,
            end_line: 1,
            breadcrumb: "root".to_string(),
            text: text.to_string(),
            symbol_name: Some(symbol_name.to_string()),
            symbol_kind: Some(cc_model::SymbolKind::Function),
            token_estimate: 8,
            parser_tier: ParserTier::TreeSitter,
            parser_confidence: 1.0,
        };
        let symbol = SymbolRecord {
            symbol_id: format!("sym:{file_path}:{symbol_name}"),
            file_path: file_path.to_string(),
            name: symbol_name.to_string(),
            kind: cc_model::SymbolKind::Function,
            container: None,
            start_line: 1,
            end_line: 1,
            start_col: 0,
            end_col: 0,
            signature: None,
            doc: None,
            parser_tier: ParserTier::TreeSitter,
            parser_confidence: 1.0,
            qname: None,
            parent_symbol_id: None,
            scope_id: None,
            export_name: None,
            is_default_export: false,
            symbol_uid: symbol_uid.map(|s| s.to_string()),
            framework_role: None,
            receiver_type: None,
            param_types: None,
            return_type: None,
            param_count: None,
            base_types: None,
            implements: None,
        };
        let mut outcome = ParseOutcome {
            summary: text.to_string(),
            chunks: vec![chunk],
            symbols: vec![symbol],
            call_edges,
            parser_tier: ParserTier::TreeSitter,
            parser_confidence: 1.0,
            chunk_policy: Some(cc_model::chunk_policy::ChunkPolicy::default().fingerprint()),
            document_spec: Some(cc_index::documents::delta::spec_fingerprint().into()),
            ..Default::default()
        };
        outcome.documents =
            Some(cc_index::documents::delta::prepare(&snapshot, &outcome, &[]).unwrap());
        let conn = crate::test_seed::seed_conn(db);
        cc_db::index_db::IndexDb::insert_file_data(
            &conn,
            &FileWriteUnit {
                rel_path: file_path.to_string(),
                language: Language::Rust,
                content_hash: snapshot.identity().content_digest.clone(),
                mtime: 0.0,
                size: text.len() as u64,
                outcome,
            },
        )
        .unwrap();
    }

    #[test]
    fn graph_rerank_preserves_algebra_with_bm25_and_direct_support() {
        let dir = TempDir::new().unwrap();
        let mut idx = CodeIndex::empty();
        idx.set_project(dir.path(), false).unwrap();
        let db = idx.ensure_db().unwrap().clone();

        // beta: lexically stronger (matches all 8 query tokens), no symbol_uid
        // so the graph lane and graph enrichment cannot see it.
        insert_context_fixture_file(
            dir.path(),
            &db,
            "src/beta.rs",
            "fn ranktoken() { alphaword(); betaword(); gammaword(); deltaword(); epsword(); zetaword(); etaword(); }",
            "ranktoken",
            None,
            vec![],
        );
        // alpha: lexically weaker (7 of 8 query tokens) but heavily connected
        // in the call graph (20 outgoing edges -> high graph_score).
        let ghost_edges: Vec<cc_model::CallEdgeRecord> = (0..20)
            .map(|i| cc_model::CallEdgeRecord {
                edge_id: format!("edge:alpha->ghost{i}"),
                file_path: "src/alpha.rs".to_string(),
                caller_symbol: Some("ranktoken".to_string()),
                callee_symbol: format!("ghost_fn_{i}"),
                line: 2,
                caller_symbol_uid: Some("uid:alpha".to_string()),
                callee_symbol_uid: Some(format!("uid:ghost{i}")),
                ..Default::default()
            })
            .collect();
        insert_context_fixture_file(
            dir.path(),
            &db,
            "src/alpha.rs",
            "fn ranktoken() { alphaword(); betaword(); gammaword(); deltaword(); epsword(); zetaword(); }",
            "ranktoken",
            Some("uid:alpha"),
            ghost_edges,
        );

        let query = "ranktoken alphaword betaword gammaword deltaword epsword zetaword etaword";
        let envelope = idx
            .search()
            .search_in_context_with(query, 2, None, SearchRequest::default())
            .unwrap();

        let hits = envelope.machine_pack["hits"].as_array().unwrap();
        assert_eq!(hits.len(), 2, "expected exactly the two fixture hits");

        let order: Vec<&str> = hits
            .iter()
            .map(|h| h["chunk_id"].as_str().unwrap())
            .collect();
        let graph_scores: Vec<f64> = hits
            .iter()
            .map(|h| h["graph_score"].as_f64().unwrap())
            .collect();
        let rerank_scores: Vec<f64> = hits
            .iter()
            .map(|h| h["rerank_score"].as_f64().unwrap())
            .collect();

        // Baseline captured from the pre-refactor implementation
        // (graph_enrich + re-sort living in cc-server). The graph boost must
        // FLIP the order: alpha is lexically weaker but heavily connected.
        assert_eq!(
            order,
            vec!["chunk:src/alpha.rs", "chunk:src/beta.rs"],
            "graph-boosted hit order must match pre-refactor baseline"
        );

        let expected_alpha_graph = (21.0f64).ln() / 10.0; // ln(in+out+1)/10, 20 edges
        assert!(
            (graph_scores[0] - expected_alpha_graph).abs() < 1e-12,
            "alpha graph_score drifted: got {}, want {}",
            graph_scores[0],
            expected_alpha_graph
        );
        assert_eq!(graph_scores[1], 0.0, "beta has no graph connectivity");

        // Keep the historical baseline and derive BOTH deliberate changes:
        // monotonic BM25 delta from raw SQLite, plus P3-B's bounded direct support.
        // Alpha is the second lexical/grep match: support=1/2, so its old uniform
        // graph bonus loses exactly 0.3 * ln(21)/10 * (1 - 1/2).
        // This is independent algebra, not newly captured opaque output scores.
        assert_eq!(hits[0]["lexical_score"].as_f64().unwrap(), 0.5);
        assert!(hits[0]["grep_score"].as_f64().unwrap() <= 0.5);
        let alpha_support = 0.5;
        let connectivity_delta = expected_alpha_graph * 0.3 * (alpha_support - 1.0);
        let raw = db
            .retrieval()
            .fts_file_summaries(&cc_db::fts::sanitize_fts_query(query), None, 100)
            .unwrap();
        let bm25_delta = |path: &str| {
            let x = -raw.iter().find(|(p, _)| p == path).unwrap().1;
            0.04 * ((x - 1.0) / (x + 1.0))
        };
        assert!(
            (rerank_scores[0]
                - (0.7865038336950975 + bm25_delta("src/alpha.rs") + connectivity_delta))
                .abs()
                < 1e-12,
            "alpha rerank_score drifted: got {}",
            rerank_scores[0]
        );
        assert!(
            (rerank_scores[1] - (0.7275681946166044 + bm25_delta("src/beta.rs"))).abs() < 1e-12,
            "beta rerank_score drifted: got {}",
            rerank_scores[1]
        );

        // Flip proof: without the graph contribution (weight 0.3) alpha would
        // rank BELOW beta — the final ordering genuinely depends on the graph
        // rerank step.
        let alpha_pre_graph = rerank_scores[0] - graph_scores[0] * 0.3 * alpha_support;
        assert!(
            alpha_pre_graph < rerank_scores[1],
            "fixture must demonstrate a graph-driven flip: alpha pre-graph {} vs beta {}",
            alpha_pre_graph,
            rerank_scores[1]
        );
    }

    #[test]
    fn search_in_context_omits_graph_explain_when_clean() {
        let dir = TempDir::new().unwrap();
        let mut idx = CodeIndex::empty();
        idx.set_project(dir.path(), false).unwrap();
        let db = idx.ensure_db().unwrap().clone();
        insert_context_fixture_file(
            dir.path(),
            &db,
            "src/alpha.rs",
            "fn cleanmarker() {}",
            "cleanmarker",
            Some("uid:clean"),
            vec![],
        );

        let envelope = idx
            .search()
            .search_in_context_with("cleanmarker", 5, None, SearchRequest::default())
            .unwrap();
        let enrich = &envelope.evidence_summary["graph_enrichment"];
        assert!(
            enrich.get("symbols_resolved").is_some(),
            "existing graph_enrichment counters must stay: {enrich}"
        );
        assert!(
            enrich.get("graph_explain").is_none(),
            "clean enrichment must omit graph_explain: {enrich}"
        );
    }

    #[test]
    fn search_in_context_surfaces_graph_explain_read_errors() {
        let dir = TempDir::new().unwrap();
        let mut idx = CodeIndex::empty();
        idx.set_project(dir.path(), false).unwrap();
        let db = idx.ensure_db().unwrap().clone();
        insert_context_fixture_file(
            dir.path(),
            &db,
            "src/alpha.rs",
            "fn brokenmarker() {}",
            "brokenmarker",
            Some("uid:broken"),
            vec![],
        );
        // Drop call_edges so the enrichment's batched adjacency reads fail
        // and degrade to partial graph context (the graph lane swallows its
        // own failures, so the search itself still succeeds).
        crate::test_seed::seed_conn(&db)
            .execute("DROP TABLE call_edges", [])
            .unwrap();

        let envelope = idx
            .search()
            .search_in_context_with("brokenmarker", 5, None, SearchRequest::default())
            .unwrap();
        let explain = &envelope.evidence_summary["graph_enrichment"]["graph_explain"];
        let read_errors = explain["read_errors"]
            .as_array()
            .unwrap_or_else(|| panic!("graph_explain.read_errors must be surfaced: {explain}"));
        assert!(
            read_errors.iter().any(|entry| entry
                .as_str()
                .unwrap_or_default()
                .starts_with("symbol_degree_details_batch:")),
            "read_errors must name the failed op: {read_errors:?}"
        );
    }

    #[test]
    fn graph_score_affects_final_ranking() {
        use cc_model::search::SearchHit;
        use cc_model::Language;

        // Construct two hits: B has higher rerank but no graph, A has lower rerank but high graph
        let mut hit_a = SearchHit {
            chunk_id: "a".into(),
            file_path: "a.rs".into(),
            language: Language::Rust,
            start_line: 1,
            end_line: 10,
            breadcrumb: String::new(),
            symbol_name: None,
            symbol_kind: None,
            text: String::new(),
            fused_score: 0.5,
            lexical_score: 0.5,
            grep_score: 0.0,
            graph_score: 0.4,   // high graph score
            rerank_score: 0.50, // lower rerank
            reasons: vec![],
            score_trace: vec![],
            source: String::new(),
            lane: None,
            metadata: serde_json::Value::Null,
        };

        let hit_b = SearchHit {
            chunk_id: "b".into(),
            file_path: "b.rs".into(),
            language: Language::Rust,
            start_line: 1,
            end_line: 10,
            breadcrumb: String::new(),
            symbol_name: None,
            symbol_kind: None,
            text: String::new(),
            fused_score: 0.55,
            lexical_score: 0.55,
            grep_score: 0.0,
            graph_score: 0.0,   // no graph score
            rerank_score: 0.55, // higher rerank
            reasons: vec![],
            score_trace: vec![],
            source: String::new(),
            lane: None,
            metadata: serde_json::Value::Null,
        };

        // Apply graph rerank with weight 0.3
        let gw = 0.3;
        hit_a.rerank_score += hit_a.graph_score * gw; // 0.50 + 0.12 = 0.62
                                                      // hit_b stays at 0.55

        let mut hits = [hit_b, hit_a];
        hits.sort_by(|a, b| {
            b.rerank_score
                .partial_cmp(&a.rerank_score)
                .unwrap_or(std::cmp::Ordering::Equal)
        });

        // A should now be first (0.62 > 0.55)
        assert_eq!(hits[0].chunk_id, "a");
        assert_eq!(hits[1].chunk_id, "b");
    }
}
