def stable_00290():
    return 290
