from pathlib import Path
import json
import hashlib
import re
import difflib

root = Path(__file__).resolve().parents[1]
c = root / 'round30-PR191-equal-lifetime-candidate'
r = Path(__file__).resolve().parent
g = r / 'generated-G'
regraw = json.loads((c / 'PR191-chain-registry.original.json').read_text())['structuredContent']['content']
guard = json.loads((c / 'PR191-chain-guard.original.json').read_text())['structuredContent']['content']
old = json.loads(regraw)
canraw = (root / 'round30-PR191-equal-lifetime-peer/independent-source-review.canonical.json').read_bytes()
can = json.loads(canraw)
assert hashlib.sha256(canraw).hexdigest() == 'cb0ca245699efa7e9d2899230f9b61322dde2b454cdaead003dd9762e67054aa'
assert can['verdict'] == 'accepted_scoped' and can['unresolved_blockers'] == []
assert can['independent_reviewers'] == ['/root/todo_audit: non-author review of exact equal-lifetime v2 test/workflow and actual P two-leaf integration with independently reconstructed complete inherited maps.']
assert can['source'] == '595789f80a76a83b921aec8c6e2a225b25790b40'
new = {**old, 'product_source': can['source'],
       'review_source': 'f0ca176ad1d22d4236bcce5848d8c45493be8df0',
       'review_sha256': hashlib.sha256(canraw).hexdigest(),
       'complete_inputs': can['complete_inputs'], 'delta': can['paths'],
       'validation_inputs': can['validation_inputs']}
fields = {k for k in old if old[k] != new[k]}
assert fields == {'product_source', 'review_source', 'review_sha256', 'complete_inputs', 'delta', 'validation_inputs'}
rr = (json.dumps(new, indent=2, sort_keys=True) + '\n').encode()
pins = {'PRODUCT': can['source'], 'REVIEW': new['review_source'],
        'REVIEW_PATH': can['review_path'], 'REGISTRY_SHA256': hashlib.sha256(rr).hexdigest()}
after = guard
for key, val in pins.items():
    after, n = re.subn(r'^' + key + r' = "[^"]*"$', key + ' = "' + val + '"', after, flags=re.M)
    assert n == 1, key
before_norm, after_norm = guard, after
for key in pins:
    before_norm = re.sub(r'^' + key + r' = .*$', key + ' = PIN', before_norm, flags=re.M)
    after_norm = re.sub(r'^' + key + r' = .*$', key + ' = PIN', after_norm, flags=re.M)
assert before_norm == after_norm

def meta(b):
    return dict(bytes=len(b), sha256=hashlib.sha256(b).hexdigest(),
                git_blob=hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest())

for path, data in [('reviewed-source-registry-v15.json', rr), ('verify_reviewed_source_v15.py', after.encode())]:
    with (g / path).open('xb') as file:
        file.write(data)
manifest = {'schema': 'pr191-equal-lifetime-G-mechanical-generation-v1',
    'source': can['source'], 'review': new['review_source'], 'review_path': can['review_path'],
    'review_sha256': new['review_sha256'], 'expected_parent_tree': '92fbc5ae5a9c328892d28d6adbe913bd22fd98bc',
    'actual_changed_registry_fields': sorted(fields), 'exact_four_guard_pins': pins, 'algorithm_unchanged': True,
    'counts': {'complete_inputs': len(can['complete_inputs']), 'delta': len(can['paths']), 'validation_inputs': len(can['validation_inputs'])},
    'entries': [dict(path='scripts/' + path, **meta((g / path).read_bytes())) for path in
                ['reviewed-source-registry-v15.json', 'verify_reviewed_source_v15.py']],
    'execution_scope': 'Python mechanical serialization/assertions only; no source CLI/Rust/probe'}
(g / 'generation-manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
(g / 'four-pin.diff').write_text(''.join(difflib.unified_diff(guard.splitlines(True), after.splitlines(True), fromfile='seed-G7da', tofile='new-G-candidate')))
print(json.dumps(manifest, indent=2))
