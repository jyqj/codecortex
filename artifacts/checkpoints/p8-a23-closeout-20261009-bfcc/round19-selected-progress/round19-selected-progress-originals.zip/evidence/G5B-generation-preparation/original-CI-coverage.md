# Original CI applicability for the format-only preselect repair

The unchanged `.github/workflows/ci.yml` uses `pull_request` and `push` only for main. Its `check` job uses `actions/checkout@v4` without an explicit ref; on a PR the actual checkout may therefore be GitHub's merge commit. The eventual log and source-domain identity must be read before attributing results. No assumption that the log directly checked out G5B is made.

The original steps at lines 22–36 cover this file directly:

1. `cargo fmt --all -- --check` checks the formatter-selected layout of the test helper.
2. `cargo clippy --workspace --all-targets -- -D warnings` checks all test-target code, including this `cc-search` module.
3. `cargo test --workspace --all-targets --locked --no-run` compiles it.
4. `cargo test --workspace --all-targets --exclude cc-semantic --locked` executes the default `cc-search` library tests. The exclusion is only `cc-semantic`, so it does not omit this module.

The changed expression is in `#[cfg(test)]` module helper `db_with_tied_graph_neighbors`. Its two normal, non-ignored callers are `graph_neighbor_ties_select_file_order_before_truncation` and `graph_neighbor_score_precedes_file_order_at_the_cutoff`. The original fmt failure happened before these execution steps; a future successful formatter step alone must not be presented as test execution.

The original source-integrity and selected v15 steps remain later in the same workflow at lines 53–54. Their execution is conditional on prior steps succeeding. This preparation does not add, remove, skip or run any step, create a workflow, or start a scale study. The original b2 failure and all subsequent skipped steps remain preserved by their original official job record.
