#!/usr/bin/env python3
"""Independent static two-binding verification; does not run the guard."""
from pathlib import Path
import ast, copy, hashlib, json, re
ROOT=Path(__file__).resolve().parent
CAN=ROOT.parent/'independent-source-review.json'
SEED=Path('/dev/shm/todo-audit-P5B-G5B-binding-preparation')
GEN=Path('/dev/shm/todo-audit-G5B-cef789c9-binding')
P='d21e140ca9ebb5a73294358d64a839466c5a0076';R='cef789c9072e659e2026c33b537833edeaf775c9'
RP='artifacts/checkpoints/p8-preselect-ci-format-bfcc-20261009/independent-source-review.json'
REG='scripts/reviewed-source-registry-v15.json';GUARD='scripts/verify_reviewed_source_v15.py'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def tree(rows):
    rows=sorted(rows,key=lambda x:(x['path']+('/' if x['type']=='tree' else '')).encode())
    b=b''.join(x['mode'].lstrip('0').encode()+b' '+x['path'].encode()+b'\0'+bytes.fromhex(x['sha']) for x in rows)
    return hashlib.sha1(b'tree '+str(len(b)).encode()+b'\0'+b).hexdigest()
canraw=CAN.read_bytes();can=json.loads(canraw)
assert sha(canraw)=='a79f4a1dddd8e7fcd3b39997e5c8caecc1e857be58908a711221417ff19225f3' and can['source']==P
oldregraw=(SEED/'seed-b2-registry.json').read_bytes();oldguard=(SEED/'seed-b2-guard.py').read_bytes()
script_tree=read(ROOT.parent/'github-api/b2-domain-scripts.json'); script_tree['tree']=[x for x in script_tree['tree'] if '/' not in x['path']]; root_tree=read(ROOT/'github-api/actual-R5B-root-tree.json')
assert script_tree['truncated'] is False and tree(script_tree['tree'])==script_tree['sha']=='87a6376016df7ddbb7170d9f02b26e89c82502fd'
assert root_tree['truncated'] is False and tree(root_tree['tree'])==root_tree['sha']=='185d1284974711c4c1927e1f5525257fa65ab8c6'
official={x['path']:x for x in script_tree['tree']}
assert blob(oldregraw)==official['reviewed-source-registry-v15.json']['sha']=='d9f512c777d33519df115752797d297b6d6dbf41'
assert blob(oldguard)==official['verify_reviewed_source_v15.py']['sha']=='06fbea745c12bcbfe39731952b0382a137a574fe'
oldreg=json.loads(oldregraw);regraw=(GEN/'generated'/REG).read_bytes();guard=(GEN/'generated'/GUARD).read_bytes();reg=json.loads(regraw)
assert sha(regraw)=='4ea4c173f71cd2f4ab317733b4e7f6a8446ccf64afa9c790adf4aacf77e6bf02'
assert sha(guard)=='3c7aa51082618e79bfa598cbdf5cf3717f3260a84ed192df4bb0aedf8918799b'
fields=sorted(k for k in set(oldreg)|set(reg) if oldreg.get(k)!=reg.get(k))
assert fields==['complete_inputs','delta','product_source','review_sha256','review_source']
assert reg['product_source']==P and reg['review_source']==R and reg['review_sha256']==sha(canraw)
assert reg['complete_inputs']==can['complete_inputs'] and reg['delta']==can['paths'] and reg['validation_inputs']==can['validation_inputs']==oldreg['validation_inputs']
assert [len(reg[k]) for k in ('complete_inputs','delta','validation_inputs')]==[1095,71,142]
changed={}
for field in ['complete_inputs','delta']:
    assert set(reg[field])==set(oldreg[field])
    changed[field]=sorted(p for p in reg[field] if reg[field][p]!=oldreg[field][p])
    assert changed[field]==['crates/cc-search/src/preselect.rs']
assert all(set(x)=={'before_sha256','sha256'} for x in reg['delta'].values())
assert all(reg['delta'][p]['before_sha256']==oldreg['delta'][p]['before_sha256'] for p in reg['delta'])
pins={'PRODUCT':P,'REVIEW':R,'REVIEW_PATH':RP,'REGISTRY_SHA256':sha(regraw)}
expected=oldguard.decode()
for name,value in pins.items():
    expected,n=re.subn(r'^'+name+r' = "[^"]*"$',name+' = '+json.dumps(value),expected,flags=re.M);assert n==1
assert expected.encode()==guard
ast.parse(guard)
request=read(GEN/'two-binding-create-tree-request.json');assert request['base_tree']==root_tree['sha'] and len(request['tree'])==2
payloads={REG:regraw,GUARD:guard};files=[]
for entry in request['tree']:
    assert entry['path'] in payloads and set(entry)=={'path','mode','type','sha'}
    data=payloads[entry['path']]
    assert entry['mode']=='100644' and entry['type']=='blob' and entry['sha']==blob(data)
    assert entry['path'] not in can['complete_inputs'] and entry['path'] not in can['validation_inputs']
    files.append({'path':entry['path'],'local_path':str(GEN/'generated'/entry['path']),'bytes':len(data),'sha256':sha(data),'git_blob':blob(data),'mode':'100644'})
assert {x['path'] for x in files}=={REG,GUARD}
newscript=copy.deepcopy(script_tree['tree'])
for x in newscript:
    p='scripts/'+x['path']
    if p in payloads:x['sha']=blob(payloads[p])
newscriptsha=tree(newscript);newroot=copy.deepcopy(root_tree['tree'])
next(x for x in newroot if x['path']=='scripts')['sha']=newscriptsha
expectedtree=tree(newroot)
assert expectedtree=='03032a2fcc6698b5f2780c57b133c495f8e94e0c'
report={'schema_version':1,'reviewer':'/root/pr_triage','verdict':'accepted_for_G5B_commit_source_binding_only','actual_P5B':P,'actual_R5B':R,'actual_R5B_tree':root_tree['sha'],'actual_G5B':None,'required_G5B_sole_parent':R,'expected_G5B_tree':expectedtree,'exact_changed_paths':[REG,GUARD],'all_other_R5B_Git_leaves_unchanged_by_expected_complete_Merkle_tree':True,'canonical_review_sha256':sha(canraw),'registry_changed_fields':fields,'registry_changed_product_and_delta_paths':changed,'guard_only_four_pins':pins,'old_guard_bytes_except_four_pin_lines_exact':True,'BASE_FROZEN_history_algorithm_CI_preserved':True,'all_original_142_validation_maps_modes_and_Git_leaves_unchanged':True,'complete_product_inputs':1095,'BASE_delta':71,'all_before_SHA_values_preserved':True,'protected_ordinary_input_paths_do_not_include_the_two_binding_files':True,'actual_frozen_payloads':files,'source_review_current_execution':'P5B not_run; originalb2 fmt1/skipped retained. This static binding review does not run v15/Rust/fmt/workload or claim all CI green.','original_TODO_remaining':29,'remote_mutations':0,'new_native_or_CI_or_scale_executions':0}
with (ROOT/'G5B-independent-two-bindings-review.pending-actual.json').open('x') as f:json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({'verdict':report['verdict'],'expected_G5B_tree':expectedtree,'actual_G5B':None,'files':files}))
