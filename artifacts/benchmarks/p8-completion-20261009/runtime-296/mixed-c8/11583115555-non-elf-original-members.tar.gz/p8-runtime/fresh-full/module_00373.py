def stable_00373():
    return 373
