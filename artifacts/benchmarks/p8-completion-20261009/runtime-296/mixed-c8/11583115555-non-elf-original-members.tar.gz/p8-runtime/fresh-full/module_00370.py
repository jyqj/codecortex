def stable_00370():
    return 370
