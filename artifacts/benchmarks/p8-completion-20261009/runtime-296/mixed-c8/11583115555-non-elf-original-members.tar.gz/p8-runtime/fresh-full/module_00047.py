def stable_00047():
    return 47
