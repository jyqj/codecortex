def stable_00200():
    return 200
