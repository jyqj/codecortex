def stable_00263():
    return 263
