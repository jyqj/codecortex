仅待应用准备，apply_now=false；不改账本或注册研究。005本地候选164done/28remaining，不冒称远端已发表。

原任务没有固定default200或wide永不可作006证据的条款；200是既定scale_capacity_v1协议参数，wide4096是独立声明配置。两个study各自150/1500、N30、固定source/binary/driver/seed与预算不变，不替代、不混池。现有样本和后续修复源码的执行身份分开，oracle兼容性HOLD不能自动由新main消除。

| 原任务 | 自身范围 | 当前真正剩余项 | 硬依赖 |
|---|---|---|---|
| P8-006 | no-op/body/API/config/batch、阶段计数、超预算闭包与完整parity | 选定固定study完整150/1500与原aggregate；原source兼容性HOLD最终处置；相关回归证据 | P7-020、P8-001、P8-005 |
| P8-007 | Gc8 four-C mixed/read/build/queue/tail/error and three-seed fake-backfill components accepted; separateG2 fullfour-C actualDB acquisition component now accepted. No deadlock/starvation was hidden in the observed scope. | 已有自身组件接受；等原硬依赖，不新增测量 | P8-006 |
| P8-008 | Gc8 lifecycle retains30 cold+400 reopen+400 uncached+400 cache-hit=1230samples,431sessions; originalN/distributions/CI all retained, no best-of. OS page cache not cleared and upper tail CI may be null. | 已有自身组件接受；等原硬依赖，不新增测量 | P8-007 |
| P8-009 | Accepted original client/server/process-tree roles, physical artifact/FTS accounting and reported/estimated/unavailable columns. Overlapping roles are not summed; unavailable/whole-tree-peak/billing remain unavailable rather than zero. | 已有自身组件接受；等原硬依赖，不新增测量 | P8-008 |
| P8-010 | Original one-hour workload3600.054553094s;3601operations=1201build+2400compoundread, real edits/deletes/branch switches/catalog compaction/cache reuse, original growth checks and15table endpoint accepted. | 已有自身组件接受；等原硬依赖，不新增测量 | P8-009 |
| P8-011 | Accepted original process-kill/network/cache-corruption/database-busy/replacement components with raw failures retained and fake-provider recovery/cost boundaries. Local subreport3passed/4not_run stays unchanged; distinct active/production controls are cited with their own coverage. | 已有自身组件接受；等原硬依赖，不新增测量 | P7-020, P8-007, P8-010 |
| P8-012 | Original8 cold cells Linux/macOS×Rust1.95/stable×default/semantic and final originalcollector all accepted; absent/fresh target and actual SDK/toolchain/binary receipts retained. | 已有自身组件接受；等原硬依赖，不新增测量 | P8-011 |
| P8-013 | Six original Rust failure contracts plus seven retained compareCLI outcomes[1,1,1,1,2,2,2] accepted. Quality/performance/lock failure and inconclusive/invalid states remain non-passes; raw/report preservation verified. | 已有自身组件接受；等原硬依赖，不新增测量 | P8-012 |
| P8-016 | Accepted controlled25→24→25/backup restoration using real277f2490fad3fa30f2812b5547bad033867c9ea5 andGc8, cache namespace/version isolation and default/semantic fallback; user source/config preserved. Historical dev binary is not a published release tag. | 已有自身组件接受；等原硬依赖，不新增测量 | P7-020, P8-012, P8-013 |
