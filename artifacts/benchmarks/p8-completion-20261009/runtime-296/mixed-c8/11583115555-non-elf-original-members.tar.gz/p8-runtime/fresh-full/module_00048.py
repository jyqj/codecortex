def stable_00048():
    return 48
