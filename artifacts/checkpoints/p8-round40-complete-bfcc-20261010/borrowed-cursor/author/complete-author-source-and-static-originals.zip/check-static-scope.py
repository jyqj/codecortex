from pathlib import Path
import ast,datetime,difflib,hashlib,json,re,shutil,subprocess
R=Path('/workspace/scratch/bfccb8494ba0');H=R/'round40-borrowed-sorted-cursor-candidate';VIEW=R/'round32-capture-context-admission/guard-view';rel=Path('crates/cc-eval/src/benchmark/oracle/streaming.rs')
b=(H/'original'/rel).read_bytes();a=(H/'candidate'/rel).read_bytes();before=b.decode();after=a.decode();checks=[]
def check(name,p):
 assert p,name;checks.append(name)
def ident(p):
 b=p.read_bytes();return {'local_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def section(s,start,end):return s[s.index(start):s.index(end,s.index(start))]
base='b9b089bb4eae072affe9326681d4980eae15fd84'
g=lambda *args:subprocess.check_output(['git','--no-optional-locks',*args],cwd=VIEW,text=True,env={**__import__('os').environ,'GIT_NO_LAZY_FETCH':'1'})
check('base main tree equals fixed9cc6',g('rev-parse',base+'^{tree}').strip()=='6461938788665701cfa4fa095a064a3a404ec492')
check('exactbase oneleaf blob',g('rev-parse',base+':'+str(rel)).strip()==ident(H/'original'/rel)['git_blob']=='70394ba06bf714bce1af64a9b9c400f0e0584a46')
ancestors=['AGENTS.md','crates/AGENTS.md','crates/cc-eval/AGENTS.md','crates/cc-eval/src/AGENTS.md','crates/cc-eval/src/benchmark/AGENTS.md','crates/cc-eval/src/benchmark/oracle/AGENTS.md']
agent_index=g('ls-tree','-r','--name-only',base,'--',*ancestors)
check('no repository ancestor AGENTS in actualbase index',not agent_index.strip())
parent_agents=[str(p) for p in [Path('/AGENTS.md'),Path('/workspace/AGENTS.md'),Path('/workspace/scratch/AGENTS.md'),R/'AGENTS.md'] if p.exists()]
check('no additional filesystem ancestor AGENTS',not parent_agents)
check('CONTRIBUTING exact actualbase',ident(H/'CONTRIBUTING.original.md')['git_blob']==g('rev-parse',base+':CONTRIBUTING.md').strip())
check('pre-cursor prefix including limits/fullspool exact unchanged',before[:before.index('fn next_row(')]==after[:after.index('// Match rusqlite 0.40.1')])
for start,end in [('fn equal_rows(', 'fn compare_with_validated_limits(')]:check('equalrows/digest/examples/scratch exact unchanged',section(before,start,end)==section(after,start,end))
old_tests=before[before.index('#[cfg(test)]'):].removesuffix('}\n');check('entire preexisting internal tests byteprefix unchanged',after[after.index('#[cfg(test)]'):].startswith(old_tests))
check('13 existing external streaming controls unchanged', (VIEW/'crates/cc-eval/tests/benchmark_oracle_streaming.rs').read_text().count('#[test]')==13 and g('rev-parse',base+':crates/cc-eval/tests/benchmark_oracle_streaming.rs').strip()==ident(VIEW/'crates/cc-eval/tests/benchmark_oracle_streaming.rs')['git_blob'])
check('three new private tests only',after.count('#[test]')==before.count('#[test]')+3)
# Inverse only the known production changes and remove exactly the appended tests.
inv=after[:after.index('\n    #[test]\n    fn borrowed_cursor_text_')]+'}\n'
start=inv.index('// Match rusqlite 0.40.1');end=inv.index('fn equal_rows(',start)
inv=inv[:start]+section(before,'fn next_row(', 'fn equal_rows(')+inv[end:]
inv=inv.replace('let (av, bv) = next_pair(&mut arows, &mut brows)?;','let av = next_row(&mut arows)?;\n            let bv = next_row(&mut brows)?;')
for new,old in [('equal_rows(av, bv)','equal_rows(av.as_deref(), bv.as_deref())'),('example(av)','example(av.as_deref())'),('example(bv)','example(bv.as_deref())'),('append_digest(&mut ah, av, position)','append_digest(&mut ah, av.as_deref(), position)'),('append_digest(&mut bh, bv, position)','append_digest(&mut bh, bv.as_deref(), position)')]:inv=inv.replace(new,old)
check('exact inverse of narrow productiondelta and appended controls restores old entirefile',inv==before)
check('no unsafe or protocol/workflow edits',not re.search(r'\bunsafe\b',section(after,'// Match rusqlite 0.40.1','fn equal_rows(')) and list((H/'candidate').rglob('*.rs'))==[H/'candidate'/rel])
upstream=[R/'round40-rusqlite-v0.40.1-upstream'/s for s in ['src/row.rs','src/types/value_ref.rs','src/types/from_sql.rs']]
check('actual lock pins0.40.1', 'name = "rusqlite"\nversion = "0.40.1"' in (VIEW/'Cargo.lock').read_text())
check('reviewed upstream original exact API anchors', 'FromSqlError::Utf8Error(err) => Error::Utf8Error(idx, err)' in upstream[0].read_text() and 'value.as_str().map(ToString::to_string)' in upstream[2].read_text())
ast.parse((H/'prepare-candidate.py').read_text())
patch=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+str(rel),tofile='b/'+str(rel)));(H/'source.patch').write_text(patch)
report={'schema':'author-static-preservation-not-Rust-execution-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_static_result':'all assertions passed','checks':checks,'base':base,'tree':'6461938788665701cfa4fa095a064a3a404ec492','repository_AGENTS_index_query':ancestors,'repository_AGENTS_result':agent_index,'filesystem_ancestor_AGENTS':parent_agents,'CONTRIBUTING':ident(H/'CONTRIBUTING.original.md'),'rusqlite_version':'0.40.1','upstream_originals':[ident(p) for p in upstream],'cargo_path':shutil.which('cargo'),'rustc_path':shutil.which('rustc'),'Rust_compile':'not_run','rustfmt':'not_run','clippy':'not_run','new_Rust_controls':'not_run','original13_controls':'not_run_not_modified','workload_or_scale':'not_run','source_before':ident(H/'original'/rel),'source_after':ident(H/'candidate'/rel),'patch':ident(H/'source.patch'),'scope':'Mechanical byte preservation and metadata/AST checks only; not semantic independent approval or Rust parsing.'}
(H/'author-static-preservation.json').write_text(json.dumps(report,indent=2)+'\n')
manifest={'schema':'single-leaf-borrowed-sorted-cursor-candidate-v1','base_commit':base,'actual_P':None,'author':'execution_recon','independent_reviewer':'pr_triage_pending','changes':[{'repository_path':str(rel),'mode':'100644','before':ident(H/'original'/rel),'after':ident(H/'candidate'/rel)}],'retained_external13controls':ident(VIEW/'crates/cc-eval/tests/benchmark_oracle_streaming.rs'),'patch':ident(H/'source.patch'),'static_report':ident(H/'author-static-preservation.json'),'required_Rust_execution':'not_run'}
(H/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'static':'passed','after':manifest['changes'][0]['after'],'patch':manifest['patch'],'Rust':'not_run'}))
