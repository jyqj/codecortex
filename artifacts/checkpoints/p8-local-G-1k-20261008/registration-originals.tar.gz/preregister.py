#!/usr/bin/env python3
"""Preregister deterministic origins before any local G scale measurement."""
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
REPLAY = Path('/workspace/scratch/2eaa00d0f93a/codecortex-platform-replay-G')
COMPILED_ROOT = Path('/home/runner/work/codecortex/codecortex')
OUTPUT = Path('/workspace/scratch/2eaa00d0f93a/p8-local-G-1k-20261008')
G = 'bb9a96d71622458c39a143055360cc97f0d11d78'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def main():
    assert not OUTPUT.exists(), 'registration must precede creation of local execution output'
    driver_raw = (REPLAY / 'scripts/p8_scale_matrix.py').read_bytes()
    assert sha(driver_raw) == 'f169b0f26cf2a87d3e2548d734431c530cbf63d353ac054045ec8be80889f957'
    sys.path.insert(0, str(REPLAY / 'scripts'))
    spec = importlib.util.spec_from_file_location('original_G_scale_registration_only', REPLAY / 'scripts/p8_scale_matrix.py')
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    run = json.loads((HERE / 'G-run.json').read_text())
    pages = [json.loads((HERE / ('G-jobs-page-' + str(i) + '.json')).read_text()) for i in (1, 2)]
    jobs = [job for page in pages for job in page['jobs']]
    assert run['id'] == 37830173594 and run['head_sha'] == G
    assert all(page['total_count'] == len(jobs) == 151 for page in pages)
    assert len({job['id'] for job in jobs}) == len(jobs)
    cells = {}
    for job in jobs:
        match = re.fullmatch(r'measure \((\d+), (\d+)\)', job['name'])
        if not match:
            assert job['name'] == 'build' and job['conclusion'] == 'success'
            continue
        key = tuple(map(int, match.groups()))
        assert key not in cells
        cells[key] = job
    expected = {(scale, index) for scale in driver.SCALES for index in range(30)}
    assert set(cells) == expected
    assert all(cells[(1000, i)]['status'] == 'queued' and cells[(1000, i)]['conclusion'] is None
               and cells[(1000, i)]['steps'] == [] for i in range(30))
    primary = []
    for scale, index in sorted(expected):
        original_job = cells[(scale, index)]
        plan = driver.registered_plan(scale, index, 30, 30, 12648430, 18000000, driver.CAPACITY_PROFILE)
        primary.append({
            'scale': scale, 'shard_index': index, 'registered_plan': plan,
            'primary_origin': 'local-G-1k-20261008' if scale == 1000 else 'github-actions-37830173594',
            'primary_local_directory': str(OUTPUT / f'shard-{scale}-{index:02}') if scale == 1000 else None,
            'original_github_job_id': original_job['id'],
            'github_role': 'additional independent observation outside this preselected study' if scale == 1000 else 'preselected primary observation',
            'github_status_at_registration': original_job['status'],
        })
    registration = {
        'schema_version': 1, 'study': 'p8-G-capacity-local1k-origin-v1',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': 'An additional deterministically selected full original matrix using local1k and original-G GitHub origins; not a modification of the original GitHub run or its 301-artifact receiver',
        'source_commit': G, 'source_tree': 'bd7f0abc21650a1656783ddb26961c212aa1f2ae',
        'compiled_source_root': str(COMPILED_ROOT), 'local_output_root': str(OUTPUT),
        'original_build': {'actions_run': 37830173594, 'artifact_id': 11574210551,
                           'directory': '/workspace/scratch/2eaa00d0f93a/p8-scale-actions-37830173594/artifacts/p8-scale-build-37830173594',
                           'receipt_sha256': '414b1767f2ee3a1c94f05ef12f5f6b58fd604202cfaba66522a348f7a9627a02',
                           'binary_sha256': '501cb11d46c332340a13875ca5ca8048e560917dc3796d8528b27cd12b9779a7',
                           'source_manifest_sha256': 'b0b01c5db450e63fd7dc7e20c8093596ef3df30a67be0def577a35535fbf9f37',
                           'receipt_and_binary_bytes_may_not_be_rewritten': True},
        'driver_inputs': {'scripts/p8_scale_matrix.py': sha(driver_raw),
                          'scripts/p7_build_identity.py': '5003305105464936edf8f444fc0b93cd14a5d5f074dc650f16de2259e86f1cc5'},
        'registered_scales': list(driver.SCALES), 'repetitions_per_scale': 30,
        'shards_per_scale': 30, 'primary_cells': primary, 'total_primary_cells': len(primary),
        'local_cells': 30, 'github_primary_cells': 120,
        'native_measured_executions_before_registration': 0,
        'build_or_hash_validation_is_not_a_measured_cell': True,
        'unchanged_gate_functions': ['validate_build', 'registered_plan', 'run_shard', 'validate_shard', 'inspect_raw', 'combine', 'aggregate'],
        'full_acceptance': 'Run unmodified original-G validate_build and validate_shard/inspect_raw for all150 preselected directories, then unmodified combine/aggregate with repetitions30, shard_count30 and scale_capacity_v1. Every source, binary, plan, unique global ID, all15-table parity, failure, deadline and complete group check remains required.',
        'duplicate_and_failure_policy': [
            'Every cell primary origin is fixed by this committed registration before any local native measurement. It never depends on success, failure, runtime or resource observations.',
            'Original GitHub150 workflow remains active and retains its independent complete evidence/301-artifact receiver. Its eventual1k observations are additional executions outside this study, retained under their own actual identities.',
            'Do not replace a failed, slow, canceled, missing or capacity-refused local primary with a GitHub observation; any such primary leaves this study failed or incomplete.',
            'Do not add duplicate IDs or count the additional executions toward the registered N30. A distinct future study must be explicitly registered and preserve these earlier outcomes; no silent fallback or best-of selection.',
            'All150 primary cells and their original terminal/raw outcomes are required. Completion of the local1k cohort alone closes no TODO.'
        ],
        'local_execution_policy': {
            'parallel_cells': 1, 'first_cell': [1000, 0], 'order': 'ascending shard_index0..29',
            'first_cell_must_pass_original_admission_and_full_original_validation_before_continuing': True,
            'source_preparation': 'Create a new owned real Git checkout at the original compiled path; exact G HEAD/tree,1087complete inputs and both driver inputs; clean before/after. No aliases, source modifications, attribution relabeling or hosted-context spoofing.',
            'execution_environment': {'RUSTFLAGS': '', 'PYTHONDONTWRITEBYTECODE': '1'},
            'credentials': 'Use an explicit environment allowlist; no provider/authentication/proxy credentials are forwarded. Native generated semantic-disabled fixture remains original.',
            'hosted_sdk_cleanup': 'Not invoked or spoofed locally. The original local-capable run_shard executes its own identical registered disk preflight for every cell and retains both disk receipts.',
            'disk': 'Use owned root-volume output. Every run_shard must independently pass the original minimum; insufficient capacity remains not_run and stops the local cohort.',
            'memory': 'Shared8GiB cgroup observed, no invented original threshold or guaranteed peak. One cell at a time. Actual memory/OOM failures remain failed evidence.',
            'storage': 'Preserve every original cell file and failure prefix. Create lossless verified archives and persist them to the repository; no deletion of unarchived evidence. If storage is insufficient, stop and record remaining planned cells as not_run.',
            'supervision': 'Original native300min, Python302min and raw512MiB limits unchanged. No optional shorter timeout or lowered work profile.',
        },
        'statistics_policy': 'The original capacity profile requires nine identical engine/source/binary fields. Retain local Linux x86_64 host/CPU/kernel/parallelism as actual environment strata. No pooled heterogeneous latency or causal speedup claim.',
        'pre_registration_remote_ledger': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
                                           for p in sorted(HERE.glob('G-*.json'))},
        'todo_closed': 0, 'todo_remaining': 29,
    }
    raw = (json.dumps(registration, sort_keys=True, indent=2) + '\n').encode()
    with (HERE / 'registration.json').open('xb') as stream:
        stream.write(raw)
    print(json.dumps({'study': registration['study'], 'created_utc': registration['created_utc'],
                      'sha256': sha(raw), 'bytes': len(raw), 'primary_cells': len(primary),
                      'local_cells': 30, 'prior_local_measurements': 0}))

if __name__ == '__main__':
    main()
