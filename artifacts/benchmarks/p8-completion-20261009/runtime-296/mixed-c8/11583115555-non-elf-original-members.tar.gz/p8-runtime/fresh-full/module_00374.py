def stable_00374():
    return 374
