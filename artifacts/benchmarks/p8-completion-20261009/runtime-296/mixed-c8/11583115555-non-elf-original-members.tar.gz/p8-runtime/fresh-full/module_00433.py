def stable_00433():
    return 433
