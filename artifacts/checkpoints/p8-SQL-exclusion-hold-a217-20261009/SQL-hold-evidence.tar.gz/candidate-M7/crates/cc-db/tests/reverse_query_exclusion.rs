//! The reference deliberately reads every stored row and filters in Rust.
//! It does not reuse the bounded production SQL or its JSON exclusion path.
use cc_db::index_db::{FileWriteUnit, IndexDb};
use cc_model::{
    resolution::{DependencyKind, ResolutionDependency, ResolutionManifest},
    CallEdgeRecord, ImportRecord, Language, ParseOutcome, SymbolRefRecord,
};
use rusqlite::Connection;
use std::collections::BTreeSet;

fn unit(path: &str) -> FileWriteUnit {
    FileWriteUnit {
        rel_path: path.into(),
        language: Language::Python,
        content_hash: "reverse-exclusion-test".into(),
        mtime: 1.0,
        size: 1,
        outcome: ParseOutcome {
            resolution: ResolutionManifest::new(),
            ..Default::default()
        },
    }
}

fn add_binding(file: &mut FileWriteUnit, target: &str, kind: usize, ordinal: usize) {
    match kind {
        0 => file.outcome.imports.push(ImportRecord {
            file_path: file.rel_path.clone(),
            import_string: target.into(),
            resolved_path: Some(target.into()),
            ..Default::default()
        }),
        1 => file.outcome.symbol_refs.push(SymbolRefRecord {
            ref_id: format!("{}:ref:{ordinal}", file.rel_path),
            file_path: file.rel_path.clone(),
            symbol_name: "item".into(),
            container: None,
            ref_kind: "read".into(),
            line: 1,
            column: 0,
            target_symbol_id: None,
            target_file_path: Some(target.into()),
            target_symbol_uid: None,
            ref_name: None,
            scope_id: None,
            resolution_kind: Default::default(),
            resolution_confidence: 1.0,
            resolution_strategy: "test".into(),
            ref_end_line: None,
            ref_end_col: None,
            parser_tier: Default::default(),
            parser_confidence: 1.0,
        }),
        2 => file.outcome.call_edges.push(CallEdgeRecord {
            edge_id: format!("{}:call:{ordinal}", file.rel_path),
            file_path: file.rel_path.clone(),
            callee_symbol: "item".into(),
            target_file_path: Some(target.into()),
            line: 1,
            ..Default::default()
        }),
        _ => unreachable!(),
    }
}

fn dependency_reference(
    conn: &Connection,
    events: &BTreeSet<ResolutionDependency>,
    limit: usize,
    excluded: &[String],
) -> Vec<String> {
    let keys: BTreeSet<_> = events
        .iter()
        .map(|event| (event.kind.as_str().to_owned(), event.key.clone()))
        .collect();
    let excluded: BTreeSet<_> = excluded.iter().map(String::as_str).collect();
    let mut paths = BTreeSet::new();
    let mut stmt = conn
        .prepare("SELECT file_path,kind,key FROM resolution_dependencies")
        .unwrap();
    let rows = stmt
        .query_map([], |row| {
            Ok((
                row.get::<_, String>(0)?,
                row.get::<_, String>(1)?,
                row.get::<_, String>(2)?,
            ))
        })
        .unwrap();
    for row in rows {
        let (path, kind, key) = row.unwrap();
        if keys.contains(&(kind, key)) && !excluded.contains(path.as_str()) {
            paths.insert(path);
        }
    }
    paths.into_iter().take(limit.saturating_add(1)).collect()
}

fn surface_reference(
    conn: &Connection,
    seeds: &[String],
    limit: usize,
    excluded: &[String],
) -> Vec<String> {
    let seeds: BTreeSet<_> = seeds.iter().map(String::as_str).collect();
    let excluded: BTreeSet<_> = excluded.iter().map(String::as_str).collect();
    let mut paths = BTreeSet::new();
    for (table, target) in [
        ("imports", "resolved_path"),
        ("symbol_refs", "target_file_path"),
        ("call_edges", "target_file_path"),
    ] {
        let mut stmt = conn
            .prepare(&format!("SELECT file_path,{target} FROM {table}"))
            .unwrap();
        let rows = stmt
            .query_map([], |row| {
                Ok((row.get::<_, String>(0)?, row.get::<_, Option<String>>(1)?))
            })
            .unwrap();
        for row in rows {
            let (path, target) = row.unwrap();
            if let Some(target) = target {
                if seeds.contains(target.as_str())
                    && !excluded.contains(path.as_str())
                    && (table == "imports" || path != target)
                {
                    paths.insert(path);
                }
            }
        }
    }
    paths.into_iter().take(limit.saturating_add(1)).collect()
}

fn exclusions(paths: &[String]) -> Vec<Vec<String>> {
    let mut large: Vec<_> = (0..1100).map(|i| format!("absent-{i}.py")).collect();
    large.extend([paths[0].clone(), paths[3].clone(), paths[0].clone()]);
    vec![
        Vec::new(),
        vec![paths[0].clone(), paths[3].clone(), paths[0].clone()],
        vec![paths.last().unwrap().clone()],
        paths.to_vec(),
        vec!["Case.py".into()],
        large,
    ]
}

fn fixture_paths() -> Vec<String> {
    let mut paths: Vec<_> = (0..32).map(|i| format!("f{i:03}.py")).collect();
    paths.extend([
        "quote'\".py".into(),
        "unicode/é.py".into(),
        "unicode/雪.py".into(),
        "Case.py".into(),
        "case.py".into(),
    ]);
    paths
}

#[test]
fn dependency_json_exclusion_matches_full_row_reference_across_batches() {
    let directory = tempfile::tempdir().unwrap();
    let path = directory.path().join("index.db");
    let db = IndexDb::open_with_read_pool_size(&path, 1).unwrap().0;
    let paths = fixture_paths();
    let files: Vec<_> = paths
        .iter()
        .enumerate()
        .map(|(i, path)| {
            let mut file = unit(path);
            for key in [
                format!("key-{:03}", i % 7),
                format!("key-{:03}", 398 + i % 3),
            ] {
                file.outcome
                    .resolution
                    .dependency(DependencyKind::NameBucket, &key);
                file.outcome
                    .resolution
                    .dependency(DependencyKind::NameBucket, &key);
            }
            file.outcome
                .resolution
                .dependency(DependencyKind::MissingPath, "key-001");
            file
        })
        .collect();
    db.writes().replace_files_batch(&files).unwrap();
    let conn = Connection::open(&path).unwrap();
    let before = db.reads().generation().unwrap();
    let mut events: BTreeSet<_> = (0..405)
        .map(|i| {
            ResolutionDependency::new(DependencyKind::NameBucket, format!("key-{i:03}"))
        })
        .collect();
    events.insert(ResolutionDependency::new(
        DependencyKind::MissingPath,
        "key-001",
    ));
    for selected_events in [&events, &BTreeSet::new()] {
        for limit in [0, 1, 7, 100, usize::MAX] {
            for excluded in exclusions(&paths) {
                let (actual, _) = db
                    .reads()
                    .resolution_dependents_with_work(selected_events, limit, &excluded)
                    .unwrap();
                assert_eq!(
                    actual,
                    dependency_reference(&conn, selected_events, limit, &excluded)
                );
            }
        }
    }
    assert_eq!(db.reads().generation().unwrap(), before);
}

#[test]
fn surface_json_exclusion_matches_full_row_reference_and_nonlocal_rules() {
    let directory = tempfile::tempdir().unwrap();
    let path = directory.path().join("index.db");
    let db = IndexDb::open_with_read_pool_size(&path, 1).unwrap().0;
    let mut paths = fixture_paths();
    let mut files: Vec<_> = paths
        .iter()
        .enumerate()
        .map(|(i, path)| {
            let mut file = unit(path);
            for kind in 0..3 {
                add_binding(&mut file, &format!("target-{:03}.py", i % 7), kind, 0);
                add_binding(&mut file, &format!("target-{:03}.py", 398 + i % 3), kind, 1);
            }
            file
        })
        .collect();
    for (kind, path) in ["self-import.py", "self-ref.py", "self-call.py"]
        .iter()
        .enumerate()
    {
        let mut file = unit(path);
        add_binding(&mut file, path, kind, 0);
        files.push(file);
        paths.push((*path).to_owned());
    }
    db.writes().replace_files_batch(&files).unwrap();
    let conn = Connection::open(&path).unwrap();
    let before = db.reads().generation().unwrap();
    let mut seeds: Vec<_> = (0..405).map(|i| format!("target-{i:03}.py")).collect();
    seeds.extend([
        "target-000.py".into(),
        "self-import.py".into(),
        "self-ref.py".into(),
        "self-call.py".into(),
    ]);
    let all = db
        .reads()
        .surface_dependents_bounded(&seeds, usize::MAX, &[])
        .unwrap()
        .0;
    assert!(all.contains(&"self-import.py".to_owned()));
    assert!(!all.contains(&"self-ref.py".to_owned()));
    assert!(!all.contains(&"self-call.py".to_owned()));
    for selected_seeds in [&seeds, &Vec::new()] {
        for limit in [0, 1, 7, 100, usize::MAX] {
            for excluded in exclusions(&paths) {
                let (actual, _) = db
                    .reads()
                    .surface_dependents_bounded(selected_seeds, limit, &excluded)
                    .unwrap();
                assert_eq!(
                    actual,
                    surface_reference(&conn, selected_seeds, limit, &excluded)
                );
            }
        }
    }
    assert_eq!(db.reads().generation().unwrap(), before);
}

#[test]
fn completed_prefix_is_not_returned_to_rust_by_either_reverse_query() {
    let directory = tempfile::tempdir().unwrap();
    let path = directory.path().join("index.db");
    let db = IndexDb::open_with_read_pool_size(&path, 1).unwrap().0;
    let files: Vec<_> = (0..600)
        .map(|i| {
            let mut file = unit(&format!("f{i:04}.py"));
            file.outcome
                .resolution
                .dependency(DependencyKind::NameBucket, "hot");
            add_binding(&mut file, "target.py", 0, 0);
            file
        })
        .collect();
    db.writes().replace_files_batch(&files).unwrap();
    let excluded: Vec<_> = files[..598]
        .iter()
        .map(|file| file.rel_path.clone())
        .collect();
    let events = BTreeSet::from([ResolutionDependency::new(
        DependencyKind::NameBucket,
        "hot",
    )]);
    let (dependencies, dependency_work) = db
        .reads()
        .resolution_dependents_with_work(&events, 1, &excluded)
        .unwrap();
    let (surfaces, surface_work) = db
        .reads()
        .surface_dependents_bounded(&["target.py".into()], 1, &excluded)
        .unwrap();
    assert_eq!(dependencies, ["f0598.py", "f0599.py"]);
    assert_eq!(surfaces, dependencies);
    assert_eq!(dependency_work.rows, 2);
    assert_eq!(surface_work.rows, 2);
    // These are returned-row counters, not SQLite VM work or wall-time claims.
}

#[test]
fn both_reverse_queries_preserve_null_path_decode_errors() {
    let directory = tempfile::tempdir().unwrap();
    let path = directory.path().join("index.db");
    let db = IndexDb::open_with_read_pool_size(&path, 1).unwrap().0;
    let conn = Connection::open(&path).unwrap();
    // Model a damaged noncanonical table. The old Rust row decoder reports
    // NULL as an error; SQL exclusion must not silently discard that row.
    conn.execute_batch(
        "DROP TABLE resolution_dependencies;
         CREATE TABLE resolution_dependencies(file_path TEXT, kind TEXT, key TEXT);
         INSERT INTO resolution_dependencies VALUES(NULL, 'name_bucket', 'hot');
         DROP TABLE imports;
         CREATE TABLE imports(file_path TEXT, resolved_path TEXT);
         INSERT INTO imports VALUES(NULL, 'target.py');",
    )
    .unwrap();
    let events = BTreeSet::from([ResolutionDependency::new(
        DependencyKind::NameBucket,
        "hot",
    )]);
    for excluded in [Vec::new(), vec!["absent.py".into()]] {
        assert!(db
            .reads()
            .resolution_dependents_with_work(&events, 0, &excluded)
            .is_err());
        assert!(db
            .reads()
            .surface_dependents_bounded(&["target.py".into()], 0, &excluded)
            .is_err());
    }
}
