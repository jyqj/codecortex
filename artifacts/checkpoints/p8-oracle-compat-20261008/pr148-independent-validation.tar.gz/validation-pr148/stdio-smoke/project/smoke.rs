pub fn smoke_validation() -> u32 { 148 }
