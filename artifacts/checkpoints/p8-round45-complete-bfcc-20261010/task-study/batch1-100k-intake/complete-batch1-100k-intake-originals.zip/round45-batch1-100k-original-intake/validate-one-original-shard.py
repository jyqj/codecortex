import pathlib,json,hashlib,subprocess,sys,datetime
D=pathlib.Path(__file__).resolve().parent
C=json.loads(pathlib.Path(sys.argv[1]).read_text());A=pathlib.Path(C['receipt_directory']);S=pathlib.Path(C['shard_directory']);V=pathlib.Path(C['source_directory']);B=pathlib.Path(C['build_directory'])
def write(name,v):(A/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def inv():
 return {p.relative_to(S).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':oct(p.stat().st_mode&0o777)} for p in sorted(S.rglob('*')) if p.is_file()}
before=inv();write('shard-before.json',before)
cached=json.loads(pathlib.Path(C['accepted_build_tuple']).read_text());binary=pathlib.Path(cached['binary'])
sys.path.insert(0,str(V/'scripts'))
import p8_task_profile_matrix as task
calls=[];run_code=subprocess.run.__code__
def trace(frame,event,arg):
 if frame.f_code is run_code:
  pargs=frame.f_locals.get('popenargs',());argv=pargs[0] if pargs else frame.f_locals.get('kwargs',{}).get('args')
  if isinstance(argv,(list,tuple)) and '--hash-file' in argv:
   if event=='call':calls.append({'argv':[str(x) for x in argv],'start':datetime.datetime.now(datetime.timezone.utc).isoformat()})
   if event=='return' and isinstance(arg,subprocess.CompletedProcess):
    row=calls[-1];row.update(end=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=arg.returncode)
    for key in ['stdout','stderr']:
     b=getattr(arg,key);assert isinstance(b,bytes);name=f'native-hash-{len(calls)-1}-{key}.original';(A/name).write_bytes(b)
     row[key]={'file':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 return trace
sys.setprofile(trace)
try:
 result=task.validate_shard(S,cached['outer'],cached['built'],binary,B,root=V) # exactly once
finally:
 sys.setprofile(None);write('native-hash-subprocess-originals.json',calls)
 after=inv();write('shard-after.json',after)
write('original-validate-shard-return.json',result)
assert before==after,'new shard bytes changed'
assert list(task.slot_key(result['plan']))==C['slot']
assert len(calls)==2 and all(x['returncode']==0 for x in calls)
print(json.dumps(result,ensure_ascii=False,indent=2))
