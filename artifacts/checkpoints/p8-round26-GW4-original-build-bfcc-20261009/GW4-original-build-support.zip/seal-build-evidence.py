from pathlib import Path
import hashlib,json,zipfile,stat,datetime
B=Path(__file__).resolve().parent;O=B/'sealed-evidence';O.mkdir(exist_ok=False)
def meta(p):
 b=p.read_bytes();return {'local_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'mode':'100755' if stat.S_IMODE(p.stat().st_mode)&0o111 else '100644'}
read=lambda p:json.loads(p.read_text());r=read(B/'execution-attempt01/receipt.json');assert r['exit_code']==0;review=read(B/'original-validation-attempt01/independent-build-review.json')
private=B/'root-private-original-transfer-receipt.json';private_meta=meta(private) if private.exists() else None
summary={'schema':'GW4-original-build-custody-v1','source':'008f1ec0ae16b9b6aff9f20d033b17b2219168f8','run':37982220020,'attempt':1,'artifact_id':11642471195,'review':review,'actual_child_receipt':r,'source_reconstruction':{'official_commit_sha_matched':True,'timezone_reconstruction':read(B/'exact-commit-timezone-reconstruction.json'),'preparation_failures':['Initial original Git API header restoration used +0000; exact GitOID assertion rejected before HEAD or validator. Recovered actual+0800 headers match official008f.','Four first connector calls used an incomplete github.com/blob URL and were rejected by route validation. Correct /git/blobs API read exact four source blobs; this was input restoration, not product retry.'],'index_scope':'Complete1095products+2originaldriver/helper tracked; unrelated repository bodies absent; actual source_snapshot called and matched all1095.'},'private_transfer_receipt':{'original_bytes':private_meta,'temporary_urls_omitted_from_publication':True,'no_second_Actions_download':True},'new_measurements':0,'accepted_shards':0,'accepted_samples':0,'newly_completed_todos':0,'remaining_todos':29}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
selected=[]
for name in ['official-GW4-commit.json','actual-GW4-commit.raw','exact-commit-timezone-reconstruction.json','restore-exact-GW4.py','restore-exact-GW4.attempt02.py','materialize-scoped-inputs.py','source-restore-command-receipts.json','scoped-materialization-receipt.json','scoped-restoration-plan.json','missing-scoped-blobs.json','validate-original-GW4-build.py','run-validation-once.py','seal-build-evidence.py']:
 selected.append(B/name)
selected+=sorted((B/'official-scoped-blobs').glob('*'))+sorted((B/'execution-attempt01').glob('*'))
for p in sorted((B/'original-validation-attempt01').rglob('*')):
 if p.is_file() and p.name!='p8-scale':selected.append(p)
selected.append(O/'summary.json');entries=[{**meta(p),'member_path':p.relative_to(B).as_posix()} for p in selected]
sel={'schema':'GW4-selected-build-evidence-v1','files':len(entries),'bytes':sum(e['bytes'] for e in entries),'entries':entries,'omitted':'No repeated originalZIP/ELF, previous study, source checkout or private signed URL receipt in support archive.'};(O/'archive-selection.json').write_text(json.dumps(sel,indent=2)+'\n')
with zipfile.ZipFile(O/'GW4-original-build-support.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for e in entries:z.write(e['local_path'],e['member_path'])
 z.write(O/'archive-selection.json','sealed-evidence/archive-selection.json')
ZIP=B.parent/'p8-scale-wide-dirty-build-008f-37982220020-1-original.zip';prefix='artifacts/checkpoints/p8-round26-GW4-original-build-bfcc-20261009/'
files=[ZIP,O/'GW4-original-build-support.zip',O/'summary.json',O/'archive-selection.json']
upload={'schema':'root-artifact-only-upload-v1','scope':'original build admission only,0samples; actualsource008f','entries':[{**meta(p),'repository_path':prefix+p.name} for p in files]};(O/'root-upload-manifest.json').write_text(json.dumps(upload,indent=2)+'\n');print(json.dumps(upload))
