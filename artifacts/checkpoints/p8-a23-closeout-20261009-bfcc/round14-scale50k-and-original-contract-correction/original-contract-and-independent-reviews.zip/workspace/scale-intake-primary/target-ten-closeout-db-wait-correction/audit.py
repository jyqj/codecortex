import collections,datetime,hashlib,json,re
from pathlib import Path

OUT=Path(__file__).resolve().parent
ROOT=Path('/workspace/scratch/bfccb8494ba0/scale-intake-primary')
PEER=Path('/dev/shm/pr-triage-bfcc-c8be5afa/db-lock-contract-review')
def identity(p):
    b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def visit(value,counts):
    if isinstance(value,dict):
        for k,v in value.items():
            if re.search(r'wait|lock|acquir|checkout',k,re.I):counts[k]+=1
            visit(v,counts)
    elif isinstance(value,list):
        for v in value:visit(v,counts)

inventory_path=PEER/'raw-db-wait-field-inventory.json'
inventory=json.loads(inventory_path.read_text())
mixed=[]
for cell in inventory['mixed']:
    field_counts=collections.Counter()
    for meta in cell['files']:
        p=Path(meta['path']);assert identity(p)==meta
        if p.suffix=='.jsonl':
            for line in p.read_text().splitlines():visit(json.loads(line),field_counts)
        else:visit(json.loads(p.read_text()),field_counts)
    assert cell['operation_count']==900
    assert not any(re.search(r'db.*wait|acquisition.*wait|acquire.*wait|checkout.*wait',k,re.I) for k in field_counts)
    mixed.append({'concurrency':cell['concurrency'],'artifact_id':cell['artifact_id'],'original_files_rehashed':cell['files'],'matching_field_names':dict(sorted(field_counts.items())),'actual_DB_acquisition_wait_measurement_found':False})

canonical=json.loads((ROOT/'historical-277f-peer/actual-P-complete-product-validation-inputs.json').read_text())
mapping={x['path']:x for x in canonical['files']}
source=[]
for leaf,path in [('Gc8-index_db.rs','crates/cc-db/src/index_db.rs'),('Gc8-index_db_types.rs','crates/cc-db/src/index_db_types.rs'),('Gc8-unit_of_work.rs','crates/cc-db/src/unit_of_work.rs'),('Gc8-p7_worker_contention.rs','crates/cc-eval/tests/p7_worker_contention.rs')]:
    p=PEER/leaf;b=p.read_bytes();m=mapping[path]
    assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256']
    assert hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()==m['git_blob']
    source.append({'repository_path':path,**identity(p),'git_blob':m['git_blob']})
protocol=ROOT/'target-ten-closeout-map/protocol/docs/roadmap/code-index-v2/09-BENCHMARK.md'
assert protocol.read_bytes()==(PEER/'Gc8-09-BENCHMARK.md').read_bytes()
line=protocol.read_text().splitlines()[174]
assert 'DB lock wait' in line and 'C=1/4/8/16' in line
backfill=[]
for cell in inventory['backfill']:
    summary=next(x for x in cell['files'] if x['path'].endswith('/summary.json'))
    p=Path(summary['path']);assert identity(p)==summary
    value=json.loads(p.read_text())['db_availability'];assert value==cell['db_availability']
    backfill.append({'seed':cell['seed'],'summary':summary,'single_read_pool_checkout_us':value['single_read_pool_checkout_us'],'writer_acquire_and_rollback_us':value['writer_acquire_and_rollback_us']})
oldmap=ROOT/'target-ten-closeout-map/original-ten-task-closeout-map.json'
oldadd=ROOT/'target-ten-closeout-soak-terminal-addendum/map-addendum.v2.json'
result={'schema_version':1,'reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'append_only_original_contract_omission_correction','source_G':inventory['source'],'supersedes_completion_scope_statements_only':[identity(oldmap),identity(oldadd)],'original_protocol':{**identity(protocol),'repository_path':'docs/roadmap/code-index-v2/09-BENCHMARK.md','line':175,'text':line},'prior_error':'Original ten-task map P8-007 omitted the existing mixed-load DB lock wait metric, and soak addendum v2 incorrectly described scale as the only remaining original execution. No task was marked complete.','mixed_original_raw_checked':mixed,'producer_source_bound_to_canonical_Gc8_product_map':source,'backfill_original_probe_values':backfill,'source_semantics':{'p7_worker_contention.rs:208-236':'db_control measures an isolated read-pool checkout and BEGIN IMMEDIATE plus ROLLBACK availability probe.','p7_worker_contention.rs:399-400':'db_control is called before samples(...held). The probe is not DB lock acquisition timing attached to the four mixed C workloads.','unit_of_work.rs:59-62':'Production acquires write mutex then BEGIN IMMEDIATE without recording elapsed lock acquisition time in this path.','client_dispatch_wait':'Observed driver dispatch queue delay is not the DB mutex/pool/SQLite acquisition duration.','lock_poison_recovered':'A boolean recovery indicator is not duration.'},'corrected_completion_mapping':{'P8-007':'Not ready: original C1/4/8/16 mixed-load DB lock acquisition wait evidence remains missing, in addition to original P8-006 hard dependency.','downstream':'P8-008/009/010/011/012/013/016 retain their original dependency chain; operational component passes do not establish task completion.','existing_component_verifier_results':'Retained unchanged; their actual narrower checks passed.','P8-005_006':'Original scale study still incomplete; no source/workload/registered budget or primary changed.','formal_scale_run':37902429727,'run_attempt':1,'accepted_scale_shards':4,'expected_scale_shards':150,'accepted_scale_samples':41,'expected_scale_samples':1500,'TODO_done':163,'TODO_remaining':29,'newly_closed':0},'limits':['No additional measurement, Rust execution, source change, workflow dispatch or rerun.','This is correction of an explicit original requirement, not a new acceptance gate.','No arbitrary latency threshold or forced concurrency saturation requirement added.','New source-specific instrumentation and original mixed evidence must be reviewed separately; current Gc8 raw cannot be retrospectively relabeled with unmeasured DB wait.','Worker contention and all other original requirements remain under their original scope; this correction addresses the identified DB acquisition-wait omission only.'],'peer_inventory':identity(inventory_path)}
with (OUT/'map-correction.json').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':'original_requirement_omission_confirmed','mixed_cells':len(mixed),'raw_files_rehashed':sum(len(x['original_files_rehashed']) for x in mixed),'source_files_bound':len(source),'TODO_remaining':29}))
