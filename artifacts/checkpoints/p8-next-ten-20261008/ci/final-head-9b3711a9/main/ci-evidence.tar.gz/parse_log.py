#!/usr/bin/env python3
"""Count observed result invocations without treating filtered tests as passes."""
import collections
import hashlib
import json
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
raw = path.read_bytes()
lines = [re.sub(r"^\d{4}-\d\d-\d\dT\S+Z ", "", line)
         for line in raw.decode("utf-8-sig").splitlines()]
rust = []
ignored = []
python = []
python_test_rows = []
unparsed = []
current = None
group = None
group_number = 0
for number, line in enumerate(lines, 1):
    if line.startswith("##[group]"):
        group = line[len("##[group]"):]
        group_number += 1
    match = re.search(r"^\s*Running (.*?) \(([^)]+)\)$", line)
    if match:
        current = {"target": match[1], "executable": match[2],
                   "kind": "rust_test", "running_line": number}
    match = re.search(r"^\s*Doc-tests (\S+)", line)
    if match:
        current = {"target": match[1], "kind": "rust_doctest",
                   "running_line": number}
    match = re.search(
        r"^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; "
        r"(\d+) measured; (\d+) filtered out; finished in ([\d.]+)s", line)
    if match:
        row = dict(current or {"target": None, "kind": "quiet_or_unlabeled_harness"})
        row.update(status=match[1], passed=int(match[2]), failed=int(match[3]),
                   ignored=int(match[4]), measured=int(match[5]),
                   filtered_out=int(match[6]), seconds=float(match[7]),
                   result_line=number, group=group, group_number=group_number)
        rust.append(row)
        current = None
    elif line.startswith("test result:"):
        unparsed.append({"line": number, "text": line})
    match = re.search(r"\.\.\. ignored(?:, (.*))?$", line)
    if match:
        ignored.append({"line": number, "text": line, "reason": match[1],
                        "group": group, "group_number": group_number})
    match = re.match(r"^(test_\S+) \(([^)]+)\) \.\.\. (.+)$", line)
    if match:
        python_test_rows.append({"line": number, "name": match[1],
                                 "qualified_name": match[2], "outcome": match[3]})
    match = re.match(r"^Ran (\d+) tests? in ([\d.]+)s$", line)
    if match:
        following = [value for value in lines[number:number + 4] if value]
        python.append({"line": number, "tests": int(match[1]),
                       "seconds": float(match[2]), "group": group,
                       "group_number": group_number,
                       "observed_ok": any(value == "OK" for value in following),
                       "following_status_lines": [value for value in following
                                                  if value.startswith(("OK", "FAILED"))],
                       "observed_test_rows": python_test_rows})
        python_test_rows = []

totals = {key: sum(row[key] for row in rust)
          for key in ["passed", "failed", "ignored", "measured", "filtered_out"]}
result = {
    "schema_version": 1,
    "head": "9b3711a9346b64868b64cf6cc1f6e38162a59a43",
    "run_id": 37674979736,
    "job_id": 112976035238,
    "raw_log_bytes": len(raw),
    "raw_log_sha256": hashlib.sha256(raw).hexdigest(),
    "rust_groups": len(rust),
    "rust_totals": totals,
    "rust_zero_executed_groups": sum(row["passed"] + row["failed"] == 0 for row in rust),
    "rust_unparsed_results": unparsed,
    "quiet_or_unlabeled_harness_groups": sum(row["kind"] == "quiet_or_unlabeled_harness"
                                             for row in rust),
    "python_groups": len(python),
    "python_tests": sum(row["tests"] for row in python),
    "python": python,
    "ignored_result_rows": len(ignored),
    "rust_results": rust,
    "ignored_tests": ignored,
    "actions_error_lines": [{"line": number, "text": line}
                             for number, line in enumerate(lines, 1)
                             if "##[error]" in line or re.match(r"^error:", line)],
    "scope_note": "Observed invocation totals, including repeated suites; no unique-test "
                  "inventory or unfiltered-suite claim. This final head only; no old-head "
                  "counts are imported.",
}
assert len(rust) + len(unparsed) == sum(line.startswith("test result:") for line in lines)
result["ignored_line_count_matches_summaries"] = len(ignored) == totals["ignored"]
Path(sys.argv[2]).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps({key: value for key, value in result.items()
                  if key not in {"rust_results", "ignored_tests", "python"}}, indent=2))
print("python_groups", [{"tests": row["tests"], "observed_ok": row["observed_ok"],
                          "test_row_count": len(row["observed_test_rows"])} for row in python])
print("python_modules", [dict(collections.Counter(
    item["qualified_name"].split(".")[0] for item in row["observed_test_rows"])) for row in python])
