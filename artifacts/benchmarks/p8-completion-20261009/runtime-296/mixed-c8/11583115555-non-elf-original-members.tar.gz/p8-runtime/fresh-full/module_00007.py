def stable_00007():
    return 7
