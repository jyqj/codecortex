def stable_00393():
    return 393
