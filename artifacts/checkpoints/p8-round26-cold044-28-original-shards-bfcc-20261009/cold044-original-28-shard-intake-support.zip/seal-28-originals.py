from pathlib import Path
import json,hashlib,zipfile,os,stat,datetime,re
B=Path(__file__).resolve().parent;O=B/"sealed-28-originals";O.mkdir(exist_ok=False)
PREFIX="artifacts/checkpoints/p8-round26-cold044-28-original-shards-bfcc-20261009/"
def read(p):return json.loads(p.read_text())
def info(p):
 d=p.read_bytes();return {"bytes":len(d),"sha256":hashlib.sha256(d).hexdigest(),"git_blob":hashlib.sha1(f"blob {len(d)}\\0".encode()+d).hexdigest(),"mode":oct(stat.S_IMODE(p.stat().st_mode))}
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+"\n")
def sanitize(v):
 if isinstance(v,dict):return {k:("[REDACTED temporary signed transfer URL]" if k=="download_url" else sanitize(x)) for k,x in v.items()}
 if isinstance(v,list):return [sanitize(x) for x in v]
 if isinstance(v,str) and "https://" in v and ("sig=" in v or "skoid=" in v):return re.sub(r"https://[^\\s\\\"<>]+","[REDACTED temporary signed transfer URL]",v)
 return v
ledger=read(B/"initial-claim-and-official-ledger.json")["ledger"];measurements=[];rawentries=[];capacities=[]
for slot in ledger["slots"]:
 a=slot["measurement"];r=B/"raw"/str(a["id"]);v=r/"original-validation-attempt01";receipt=read(v/"receipt.json");child=read(r/"validator-child.json");output=read(v/"original-validate-shard-output.json")
 assert receipt["exit_code"]==child["exit_code"]==0 and receipt["inputs_unchanged"] is True and len(output["measurements"])==1
 assert output["plan"]["files"]==[slot["scale"]] and output["plan"]["shard"]["index"]==slot["repetition"]
 measurements.append({"scale":slot["scale"],"repetition":slot["repetition"],"artifact_id":a["id"],"receipt_path":str((v/"receipt.json").relative_to(B)),"receipt":info(v/"receipt.json"),"original_output":info(v/"original-validate-shard-output.json"),"child_exit":0,"sample":output["measurements"][0],"plan":output["plan"],"study":output["study"]})
 for kind in ["measurement","capacity"]:
  art=slot[kind];p=B/"raw"/str(art["id"])/(art["name"]+"-original.zip");m=info(p);assert m["bytes"]==art["size_in_bytes"] and "sha256:"+m["sha256"]==art["digest"]
  rawentries.append({"kind":kind,"scale":slot["scale"],"repetition":slot["repetition"],"artifact":art,"local_path":str(p),"repository_path":PREFIX+"original-zips/"+p.name,**m})
  if kind=="capacity":
   files=list((B/"raw"/str(art["id"])/"capacity-transport-extracted").rglob("*.json"));assert len(files)==1;c=read(files[0])
   assert c["source_commit"]==ledger["source"] and c["context"]["GITHUB_RUN_ID"]==str(ledger["run_id"]) and c["context"]["GITHUB_RUN_ATTEMPT"]=="1" and c["scale"]==slot["scale"] and c["exit_code"]==0 and c["status"]=="capacity_available"
   capacities.append({"artifact_id":art["id"],"scale":slot["scale"],"repetition":slot["repetition"],"original_json":info(files[0]),"scope":"Original capacity receipt identity/terminal inventory, zero measurement credit"})
assert len(measurements)==28 and len(rawentries)==56 and len(capacities)==28
summary={"schema":"cold044-original-28-shard-intake-summary-v1","sealed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"round":26,"source":ledger["source"],"run_id":ledger["run_id"],"run_attempt":1,"accepted_new_original_shards":28,"accepted_new_samples":28,"slots":{"100000":list(range(12,30)),"50000":list(range(1,11))},"registered_shards":150,"registered_samples":150,"parent_owner_reported_accepted":16,"union_accepted_count":44,"union_count_scope":"16 previously owner-reported (10 published +6 pending owner custody) plus these28 unique original-validator accepted slots; no revalidation or source migration of the owner16","published_before_this_package":10,"owner_intaken_not_yet_published":[4,5,6,7,8,11],"full_population_complete":False,"aggregate_executed":False,"product_measurement_rerun":False,"remaining_todos":29,"newly_completed_todos":0,"source_build_scope":{"build_validator_invocations":1,"build_child_exit":0,"product_inputs":1095,"observer_inputs":5,"binary_sha256":"09ef70915331298bbb2fcda3e2526a89757c1385ef3c8e7926c39c73bf8ecdae","canonical_build_custody_commit":"9aba8f01e5f5766ac55f3ebed1ff21991dcb6cdb","build_manifest_path":"artifacts/benchmarks/original-custody-cold044c-37954851017-a217-20261009/manifests/11627448529.json","build_zip_not_duplicated":True},"execution_boundary":"Only unchanged original cold.validate_build / cold.validate_shard and retained ELF --hash-file; no original worker, no Rust compile, no source admission rerun; whole-source checks moved from per-shard host wrapper to batch boundary in later batches, original driver remains exact044.","negative_history":"First local signed-URL transport GET/HEAD403 and official helper failure retained; root formal host materialization succeeded using same file IDs, not second Actions download. No original validator failed.","measurements":measurements,"capacity_receipts":capacities,"original_zips":rawentries}
write(O/"summary.json",summary)
selected=[]
def add(p,name=None):
 if p.is_symlink() or not p.is_file():return
 rel=p.relative_to(B).as_posix();name=name or rel
 data=p.read_bytes()
 if p.suffix==".json":
  try:
   obj=json.loads(data);clean=sanitize(obj)
   if clean!=obj:
    target=O/"sanitized-transport"/rel;target.parent.mkdir(parents=True,exist_ok=True);write(target,clean)
    selected.append({"source_path":str(target),"member_path":rel,"redaction":"temporary signed transfer URLs removed; original local receipt retained","original_receipt_sha256":hashlib.sha256(data).hexdigest(),**info(target)});return
  except (UnicodeError,json.JSONDecodeError):pass
 if b"sig=" in data and b"https://" in data: raise AssertionError("signed URL in selected non-JSON "+rel)
 selected.append({"source_path":str(p),"member_path":name,**info(p)})
for p in sorted(B.iterdir()):
 if p.is_file() and p.suffix in (".json",".py",".stdout",".stderr"):add(p)
for directory in ["batch01-intake","batch02-intake","batch03-intake","original-build-validation-attempt01","official-helper-transfer-attempt01"]:
 for p in sorted((B/directory).rglob("*")):add(p)
for p in sorted((B/"build-restoration").iterdir()):
 if p.is_file() and p.suffix!=".zip":add(p)
for p in sorted((B/"build-restoration/extracted").rglob("*")):
 if p.is_file() and p.name!="p8-scale":add(p)
for p in sorted((B/"custody").rglob("*")):
 if p.is_file() and "chunks" not in p.parts:add(p)
for p in sorted((B/"source/scripts").glob("*.py")):add(p)
add(B/"source/.github/workflows/p8-cold.yml")
for p in sorted((B/"raw").rglob("*")):
 if not p.is_file() or p.suffix==".zip" or "extracted" in p.parts:continue
 add(p)
add(O/"summary.json","summary.json")
assert len({e["member_path"] for e in selected})==len(selected)
write(O/"archive-selection.json",{"schema":"exact-selected-originals-v1","scope":"All28 original validator results/stdio/exit and capacities; full raw only in56 separate original ZIPs. Old buildZIP/binary remain exact existing custody reference. Signed URLs explicitly redacted in derivative transport copies; negative history retained.","entries":selected,"file_count":len(selected),"total_bytes":sum(e["bytes"] for e in selected)})
zpath=O/"cold044-original-28-shard-intake-support.zip"
with zipfile.ZipFile(zpath,"x",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for e in selected:
  p=Path(e["source_path"]);d=p.read_bytes();assert hashlib.sha256(d).hexdigest()==e["sha256"];i=zipfile.ZipInfo(e["member_path"]);i.create_system=3;i.external_attr=(stat.S_IFREG|int(e["mode"],8))<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,d)
 z.write(O/"archive-selection.json","archive-selection.json")
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 for e in selected:assert hashlib.sha256(z.read(e["member_path"])).hexdigest()==e["sha256"]
manifest={"schema":"pure-append-original-evidence-tree-v1","expected_parent":"00b5bab669bf8f32fbc6cc556955efb6134a7abd","prefix":PREFIX,"newly_completed_todos":0,"remaining_todos":29,"entries":[{"local_path":e["local_path"],"repository_path":e["repository_path"],"mode":"100644","type":"blob","sha":e["git_blob"],"bytes":e["bytes"],"sha256":e["sha256"]} for e in rawentries]}
for p in [zpath,O/"summary.json",O/"archive-selection.json"]:
 m=info(p);manifest["entries"].append({"local_path":str(p),"repository_path":PREFIX+p.name,"mode":"100644","type":"blob","sha":m["git_blob"],"bytes":m["bytes"],"sha256":m["sha256"]})
write(O/"publication-manifest.json",manifest)
print(json.dumps({"support":info(zpath),"selection":info(O/"archive-selection.json"),"summary":info(O/"summary.json"),"publication_manifest":info(O/"publication-manifest.json"),"selected_files":len(selected),"raw_zips":len(rawentries),"new_samples":28}))

