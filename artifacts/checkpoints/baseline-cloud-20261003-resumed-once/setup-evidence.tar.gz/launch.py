import os,subprocess,sys,json,pathlib
keep={'PATH','HOME','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR','REQUESTS_CA_BUNDLE','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','http_proxy','https_proxy','all_proxy','no_proxy'}
env={k:v for k,v in os.environ.items() if k in keep}
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='/workspace/driver-128-resumed/scripts')
mode=sys.argv[1]
if mode=='fetch':
 env.update(RUSTC='/workspace/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc',CARGO_HOME='/workspace/measurements/official-fetch-proof/cargo',TMPDIR='/workspace/measurements/official-fetch-proof/tmp')
 command=['/workspace/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/cargo','fetch','--locked']
 cwd='/workspace/source-'+sys.argv[2]
else:
 command=['python3','-m','resource_harness.driver']+sys.argv[1:]
 cwd='/workspace/driver-128-resumed'
print(json.dumps({'environment_variable_names_only':sorted(env),'command':command,'cwd':cwd}),flush=True)
sys.exit(subprocess.call(command,cwd=cwd,env=env))
