#!/usr/bin/env python3
"""Read-only finite review of the already generated five-document candidate."""
import ast
import collections
import hashlib
import json
from pathlib import Path
import re

ROOT = Path('/workspace/scratch/bfccb8494ba0')
HERE = Path(__file__).resolve().parent
PREP = ROOT / 'P8-005-closeout-preparation'
OLD = PREP / 'baseline-main23eab'
NEW = PREP / 'candidate-005-final'
REC = PREP / 'candidate-validation-attempt02-final'
TASK = 'docs/roadmap/code-index-v2/tasks.json'
MAIN = '51138c236cf2ed47858e2306f9c7bfd3600aaef9'

def load(p):
    return json.loads(p.read_bytes())

def meta(p):
    b = p.read_bytes()
    return dict(bytes=len(b), sha256=hashlib.sha256(b).hexdigest(),
                git_blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())

def raw_rows(text):
    pos = text.index('[', text.index('"tasks"')) + 1
    rows = {}
    decoder = json.JSONDecoder()
    while True:
        while text[pos].isspace() or text[pos] == ',':
            pos += 1
        if text[pos] == ']':
            return rows
        value, end = decoder.raw_decode(text, pos)
        rows[value['id']] = text[pos:end]
        pos = end

before, after = load(OLD / TASK), load(NEW / TASK)
official = load(HERE / 'main-commit.json')
assert official['sha'] == MAIN
assert official['commit']['tree']['sha'] == '24df8be11955fda1f2e320de483e9eb4ddd1ffb3'
assert [p['sha'] for p in official['parents']] == [
    '23eab8a7ea1fdfd6333c2e5a001cfb41e2a10d69', '065f5ab5da1bc5de74cbd3e4c360b51e09200687']
assert len(official['files']) == 13
author = load(REC / 'candidate-005-final-change-review.json')
paths = [x['path'] for x in author['changed_files']]
assert len(paths) == 5 and TASK in paths
assert not set(paths + ['scripts/code_index_plan.py', 'docs/roadmap/code-index-v2/06-VALIDATION.md']) & {f['filename'] for f in official['files']}
inventory_before = {p.relative_to(OLD).as_posix() for p in OLD.rglob('*') if p.is_file()}
inventory_after = {p.relative_to(NEW).as_posix() for p in NEW.rglob('*') if p.is_file()}
assert inventory_before == inventory_after
assert {p for p in inventory_before if (OLD/p).read_bytes() != (NEW/p).read_bytes()} == set(paths)
for row in author['changed_files']:
    assert meta(OLD/row['path']) == row['before']
    assert meta(NEW/row['path']) == row['after']
assert meta(REC/'candidate-005-final.patch') == author['patch']
assert set(before) == set(after)
assert {k for k in before if k != 'tasks' and before[k] != after[k]} == {'next_task', 'last_implementation_date'}
assert after['next_task'] == 'P8-006' and after['last_implementation_date'] == '2026-10-09'
assert after['current_phase'] == 'P8' and after['status'] == 'in_progress'
assert [t['id'] for t in before['tasks']] == [t['id'] for t in after['tasks']]
assert len(before['tasks']) == len(after['tasks']) == 192
oldrows, newrows = raw_rows((OLD/TASK).read_text()), raw_rows((NEW/TASK).read_text())
assert {key for key in oldrows if oldrows[key] != newrows[key]} == {'P8-005'}
for a,b in zip(before['tasks'],after['tasks']):
    allowed = {'status','evidence','implementation_notes'}
    assert {k:v for k,v in a.items() if k not in allowed} == {k:v for k,v in b.items() if k not in allowed}
old = next(x for x in before['tasks'] if x['id'] == 'P8-005')
new = next(x for x in after['tasks'] if x['id'] == 'P8-005')
assert set(old) == set(new)
assert {k for k in old if old[k] != new[k]} == {'status','evidence','implementation_notes'}
assert old['status'] == 'in_progress' and new['status'] == 'done'
assert new['evidence'][:-1] == old['evidence'] and len(new['evidence']) == len(old['evidence'])+1
assert new['implementation_notes'].startswith(old['implementation_notes'])
assert old['acceptance_subgates'] == new['acceptance_subgates']
for source in (oldrows['P8-005'], newrows['P8-005']):
    found = re.search(r'"acceptance_subgates"\s*:\s*\{[^}]+\}',source).group()
    if source == oldrows['P8-005']: old_subgate = found
    else: assert found == old_subgate
counts = dict(collections.Counter(t['status'] for t in after['tasks']))
assert counts == {'done':164,'blocked':1,'in_progress':15,'todo':12}
assert next(x for x in after['tasks'] if x['id'] == 'P8-004')['status'] == 'done'
assert next(x for x in after['tasks'] if x['id'] == 'P8-006')['status'] == 'in_progress'

# Three navigation blocks are the only changed bytes in their entry-point files.
for path in [x for x in paths if x not in (TASK,'docs/roadmap/code-index-v2/05-TODO.md')]:
    a,b = (OLD/path).read_text(),(NEW/path).read_text()
    start,end = '<!-- code-index-progress:start -->','<!-- code-index-progress:end -->'
    assert a.split(start)[0] == b.split(start)[0] and a.split(end)[1] == b.split(end)[1]
    block = b.split(start)[1].split(end)[0]
    assert '164 done / 15 in_progress / 12 todo / 1 blocked' in block
    assert '下一任务：**P8-006' in block and meta(NEW/TASK)['sha256'] in block
oldtodo=(OLD/'docs/roadmap/code-index-v2/05-TODO.md').read_text()
newtodo=(NEW/'docs/roadmap/code-index-v2/05-TODO.md').read_text()
pat=r'(?m)^### \[[ x]\] (P\d+-\d+)｜'
def task_sections(text):
    hits=list(re.finditer(pat,text)); return {h.group(1):text[h.start():(hits[i+1].start() if i+1<len(hits) else len(text))] for i,h in enumerate(hits)}
ot,nt=task_sections(oldtodo),task_sections(newtodo)
assert len(ot)==len(nt)==192
assert {key for key in ot if ot[key]!=nt[key]}=={'P8-005'}
assert '### [x] P8-005' in nt['P8-005']

receipts=[]
for label,args in [('write',['python3','scripts/code_index_plan.py','--write']),('check',['python3','scripts/code_index_plan.py'])]:
    r=load(REC/(label+'-receipt.json'))
    assert r['argv']==args and r['cwd']==str(NEW) and type(r['exit_code']) is int and r['exit_code']==0
    assert r['stdout']==meta(REC/(label+'.stdout')) and r['stderr']==meta(REC/(label+'.stderr'))
    assert (REC/(label+'.stderr')).read_bytes()==b''
    out=load(REC/(label+'.stdout'))
    assert out==dict(status='passed',task_count=192,states=counts,task_sha256=meta(NEW/TASK)['sha256'],views=4)
    receipts.append(r)
registry=load(HERE/'current-registry.json')
assert len(registry['complete_inputs'])==1096 and len(registry['validation_inputs'])==142
assert not set(paths)&set(registry['complete_inputs']) and not set(paths)&set(registry['validation_inputs'])
assert meta(HERE/'original-task-progress-helper.py')['sha256']==registry['validation_inputs']['scripts/verify_historical_integrations_v2.py']
assert meta(NEW/'scripts/code_index_plan.py')==meta(OLD/'scripts/code_index_plan.py')
assert meta(NEW/'scripts/code_index_plan.py')['sha256']==registry['validation_inputs']['scripts/code_index_plan.py']

e=new['evidence'][-1]
ledger_path=ROOT/'cold150-complete-custody-ledger/complete-cold150-custody-ledger.json'
ledger=load(ledger_path)
cat=e['full_custody_catalog']
for k in ('bytes','sha256','git_blob'): assert cat[k]==meta(ledger_path)[k]
publication=load(HERE/'catalog-publication.json')
assert publication['sha']==cat['commit']=='a2daea38bc72cb3cf9c95535b852fff214debf2b'
assert next(x for x in publication['files'] if x['filename']==cat['path'])['sha']==cat['git_blob']
assert e['target_sha']==ledger['source'] and e['original_run']==ledger['run_id'] and e['run_attempt']==ledger['attempt']==1
assert e['sample_count']==ledger['counts']['unique_slots']==150 and e['repetitions_per_scale']==30
matrixpath=ROOT/'cold044-original-aggregate-intake/11644384839/attempt01/extracted/cold-matrix.json'
matrix=load(matrixpath)
assert e['aggregate']['matrix_sha256']==meta(matrixpath)['sha256']
assert matrix['passed'] and matrix['sample_count']==150
assert matrix['engine']['engine_head_observed']==e['target_sha']
assert matrix['engine']['binary_digest']==e['source_identity']['binary_blake3']
assert matrix['cold_build_receipt_sha256']==e['source_identity']['outer_build_receipt_sha256']
assert e['cold_definition']==matrix['cold_definition']
checked_counts=0
for workload,group in zip(e['workload_counts'],matrix['groups']):
    assert workload['n']==30
    assert sum(s['n'] for s in group['environment_strata'])==30
    for stratum in group['environment_strata']:
        assert stratum['n']==1
        for count in stratum['counts_by_repetition']:
            assert {k:v for k,v in count.items() if k!='index_db_with_wal_shm_bytes'}==workload['counts']
            assert count['files']==workload['scale']
            checked_counts+=1
assert checked_counts==150
engpath=PREP/'PR189-original-engineering-review.restored.json';eng=load(engpath)
assert e['engineering_regression']['review_sha256']==meta(engpath)['sha256']
for k in ('actual_checkout','head','checkout_tree_equals_head'):
    ek={'actual_checkout':'actual_ci_checkout','head':'head','checkout_tree_equals_head':'whole_repository_tree_equality_to_head'}[k]
    assert e['engineering_regression'][k]==eng[ek]
assert eng['main_CI']['conclusion']=='success'
assert e['engineering_regression']['selected_v15']==eng['main_CI']['selected_v15_result']

report=dict(schema='independent-P8-005-cold-scope-progress-closeout-review-v1',
 reviewer='/root/execution_recon',candidate_author='/root/todo_audit',
 verdict='accepted_scoped_for_docs_closure_PR',unresolved_blockers=[],
 baseline=dict(source=MAIN,tree=official['commit']['tree']['sha'],ordered_parents=[p['sha']for p in official['parents']],official_changed_paths=13,seven_candidate_inputs_unchanged=True),
 candidate_files=author['changed_files'],patch=author['patch'],
 task_boundary=dict(task='P8-005',changed_progress_fields=['status','evidence','implementation_notes'],other191_raw_JSON_fragments_exact=True,all192_immutable_definition_maps_unchanged=True,acceptance_subgates_raw_exact=True,old_evidence_and_notes_preserved=True,top_level_fields=['next_task','last_implementation_date'],next_task='P8-006',candidate_counts=counts,remaining_if_merged=28),
 views=dict(three_entrypoints_outside_generated_markers_byte_identical=True,other191_generated_TODO_sections_byte_identical=True,original_generator_unchanged=meta(NEW/'scripts/code_index_plan.py'),original_existing_execution_receipts=receipts,reviewer_reran_generator=False),
 acceptance=dict(scope='P8-005 fixed-source complete cold scale measurements only',source=e['target_sha'],run_id=e['original_run'],attempt=1,scales=e['scales'],N=30,total=150,full_catalog=cat,all150_counts_match_original_matrix=True,matrix=meta(matrixpath),engineering_identity=e['engineering_regression'],limitations=e['limitations'],original_open_subgate_definition='Historical definition remains unchanged; current scoped closure is an appended evidence record, not a rewritten acceptance definition.'),
 docs_admission=dict(rebind_required=False,reason='All five changed documents are outside current v15 product and validation inventories; no guard, registry, CI, protected snapshot, generator or source input changes. The current locked historical integration helper explicitly permits these three task progress fields and the two plan fields. Original CI should use the existing product/review pins.',source_inventory_count=1096,validation_inventory_count=142,guard=meta(HERE/'current-guard.py'),registry=meta(HERE/'current-registry.json'),locked_task_helper=meta(HERE/'original-task-progress-helper.py'),rule_lines='v15 lines 33-41, 147-150, 247-256; historical-v2 lines 28-30 and 183-217'),
 execution_boundary='This review reads original evidence, compares exact bytes and JSON fields. It does not rerun v15, cold validators, CRCs, Rust, benchmarks or measurements. Existing author write/check each actual exit0 are retained. No current PR execution or merge is claimed.',
 main_counts_at_review=dict(newly_completed=0,remaining=29),
 publication_boundary='Root owns actual commit/PR/merge. Candidate 164/192 is prospective until merge.',
 reviewer_preparation_failure='Initial attempt to save multiple official API responses in one shell argv was rejected before process creation (E2BIG); exact retained responses were then written in bounded chunks. No source, validator or measurement execution occurred.')
out=HERE/'independent-final-review.json'
with out.open('x') as f:json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(dict(status='passed',report=str(out),**meta(out)),ensure_ascii=False))
