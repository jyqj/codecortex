def stable_00334():
    return 334
