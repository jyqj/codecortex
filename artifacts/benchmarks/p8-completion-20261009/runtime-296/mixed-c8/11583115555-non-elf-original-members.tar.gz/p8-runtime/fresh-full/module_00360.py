def stable_00360():
    return 360
