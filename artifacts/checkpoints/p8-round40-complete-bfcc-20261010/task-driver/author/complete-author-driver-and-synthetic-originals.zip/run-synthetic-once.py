import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

BASE = Path('/workspace/scratch/bfccb8494ba0')
ROOT = BASE / 'round40-task-descriptive-driver-candidate'
attempt = ROOT / sys.argv[1]
attempt.mkdir(exist_ok=False)
view = attempt / 'synthetic-source-view'
old = BASE / 'round40-PR192-main-integration-candidate/validation-view'
sources = {
    'scripts/p8_task_profile_matrix.py': ROOT / 'candidate/scripts/p8_task_profile_matrix.py',
    'scripts/tests/test_p8_task_profile_matrix.py': ROOT / 'candidate/scripts/tests/test_p8_task_profile_matrix.py',
    'scripts/p8_scale_matrix.py': BASE / 'round40-profile-task-descriptive-native-candidate/candidate/scripts/p8_scale_matrix.py',
}
for name in ('scripts/p7_build_identity.py', 'scripts/p8_profile_matrix.py', 'scripts/p8_cold_matrix.py',
             'scripts/tests/test_p8_profile_matrix.py', 'scripts/tests/test_p8_scale_matrix.py'):
    sources[name] = old / name
for relative, source in sources.items():
    path = view / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, path)

def inventory():
    return {relative: {'sha256': hashlib.sha256((view / relative).read_bytes()).hexdigest(),
                      'bytes': (view / relative).stat().st_size,
                      'original_path': str(source)} for relative, source in sources.items()}

before = inventory()
(attempt / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
argv = ['python3', '-B', '-m', 'unittest', 'discover', '-s', 'scripts/tests',
        '-p', 'test_p8_task_profile_matrix.py', '-v']
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
with (attempt / 'stdout').open('wb') as out, (attempt / 'stderr').open('wb') as err:
    child = subprocess.run(argv, cwd=view, stdout=out, stderr=err,
                           env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), timeout=90)
end = datetime.datetime.now(datetime.timezone.utc).isoformat()
after = inventory()
(attempt / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
receipt = {'argv': argv, 'cwd': str(view), 'started_utc': start, 'finished_utc': end,
           'wall_seconds': time.monotonic() - clock, 'exit_code': child.returncode,
           'inputs_before_equals_after': before == after,
           'scope': 'new task driver synthetic protocol only; no Rust, ELF, Actions or scale execution',
           'stdout': {'bytes': (attempt / 'stdout').stat().st_size, 'sha256': hashlib.sha256((attempt / 'stdout').read_bytes()).hexdigest()},
           'stderr': {'bytes': (attempt / 'stderr').stat().st_size, 'sha256': hashlib.sha256((attempt / 'stderr').read_bytes()).hexdigest()}}
(attempt / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
raise SystemExit(child.returncode)
