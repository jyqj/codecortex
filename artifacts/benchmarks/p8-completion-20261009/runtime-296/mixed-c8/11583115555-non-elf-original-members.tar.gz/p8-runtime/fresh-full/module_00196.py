def stable_00196():
    return 196
