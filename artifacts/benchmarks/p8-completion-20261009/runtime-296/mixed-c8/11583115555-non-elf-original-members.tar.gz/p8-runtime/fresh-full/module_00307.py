def stable_00307():
    return 307
