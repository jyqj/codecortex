#!/usr/bin/env python3
"""Read-only arithmetic/source-scope analysis; not an acceptance validator."""
import collections
import datetime
import hashlib
import json
from pathlib import Path
import stat

HERE = Path(__file__).resolve().parent
RAW_ROOT = Path('/dev/shm/pr-triage-round20-CI-C3ff-M7F/raw/11626430756/attempt01/extracted')
OUT = HERE / 'analysis-output'
OUT.mkdir(exist_ok=False)
SOURCE = '3ffcefc3b28ee1a4ed80caecebd7208a45c3e302'
PREFIX = 'scale-100000/repetition-0/'

def digest(b):
    return hashlib.sha256(b).hexdigest()

def file_record(p):
    b = p.read_bytes()
    return {'local_path': str(p), 'bytes': len(b), 'sha256': digest(b),
            'git_blob': hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest(),
            'posix_mode': format(stat.S_IMODE(p.stat().st_mode), '04o')}

def write(name, value):
    (OUT / name).open('x').write(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n')

before = [file_record(p) for p in sorted(RAW_ROOT.rglob('*')) if p.is_file()]
raw = (RAW_ROOT / 'native/raw.jsonl').read_bytes()
assert len(raw) == 20826459 and digest(raw) == 'f523933e515b3f2d01a92bf9778b4b30ad97b5eee19275d3f82ab18706f5b947'
assert raw.endswith(b'\n')
records = [dict(json.loads(line), _line=i) for i, line in enumerate(raw.splitlines(), 1)]
plan = json.loads((RAW_ROOT / 'native/plan.json').read_bytes())
supervisor = json.loads((RAW_ROOT / 'native/report.json').read_bytes())
shard = json.loads((RAW_ROOT / 'shard.json').read_bytes())
source_map = json.loads((RAW_ROOT / 'source-before.json').read_bytes())
assert shard['source_commit'] == source_map['source_commit'] == SOURCE
assert records[0]['engine']['engine_head_observed'] == SOURCE
assert plan == shard['plan'] == records[0]['plan']
assert plan['deadline_ms'] == 18000000 and plan['files'] == [100000]
assert plan['dirty_budget'] == 200 and plan['max_resume_builds'] == 1024
assert supervisor['status'] == 'deadline_exceeded' and supervisor['exit_code'] == 3

event_counts = collections.Counter(r['event'] for r in records)
starts = {r['label']: r for r in records if r['event'] == 'build_started'}
finishes = [r for r in records if r['event'] == 'build_finished']
assert len(starts) == event_counts['build_started']
assert len({r['label'] for r in finishes}) == len(finishes)
assert set(starts) == {r['label'] for r in finishes}
for r in finishes:
    s = starts[r['label']]
    assert r['start_us'] == s['start_us'] and r['full'] == s['full']
    assert r['end_us'] - r['start_us'] == r['wall_us'] and s['_line'] < r['_line']
assert all(a['end_us'] <= b['start_us'] for a, b in zip(finishes, finishes[1:]))

PARTITION = ['prepare_us', 'commit_write_us', 'postprocess_compute_us', 'postprocess_apply_us', 'between_stages_us']
TIMING = PARTITION + ['total_us', 'prepare_snapshot_us', 'full_staging_us']
SQL = ['rows', 'statements', 'vm_steps', 'sorts', 'fullscan_steps']

def sums(rs, path, fields):
    result = {}
    for key in fields:
        vals = []
        for row in rs:
            node = row
            for name in path:
                node = node[name]
            vals.append(node[key])
        assert all(v is None or isinstance(v, int) for v in vals)
        result[key] = {'sum': sum(v for v in vals if v is not None),
                       'observed_values': sum(v is not None for v in vals),
                       'null_values': sum(v is None for v in vals)}
    return result

def build_aggregate(rs):
    return {'build_count': len(rs), 'outer_wall_us': sum(r['wall_us'] for r in rs),
            'build_timing_us': sums(rs, ['report', 'build_timing'], TIMING),
            'dependency_sql_merged_work': sums(rs, ['report', 'dirty_plan', 'dependency_sql'], SQL),
            'first_start_us': min((r['start_us'] for r in rs), default=None),
            'last_end_us': max((r['end_us'] for r in rs), default=None)}

partition_errors = [sum(r['report']['build_timing'][k] for k in PARTITION) - r['report']['build_timing']['total_us'] for r in finishes]
assert max(map(abs, partition_errors)) <= 6
full = [r for r in finishes if r['full']]
incremental = [r for r in finishes if not r['full']]
resuming_three = [r for r in incremental if r['label'].split('/')[2] in ['body', 'api', 'config']]
parities = [r for r in records if r['event'] in ['cold_parity', 'stage_finished']]
stages_finished = {r['label'].removeprefix(PREFIX): r for r in records if r['event'] == 'stage_finished'}
mutations = {r['label'].removeprefix(PREFIX): r for r in records if r['event'] == 'mutation'}
stage_rows = []
for stage in ['cold', 'no_op', 'body', 'api', 'config', 'batch_1', 'batch_10', 'batch_100', 'batch_1000']:
    rs = [r for r in finishes if (r['label'].split('/')[2].startswith('cold_') if stage == 'cold' else r['label'].split('/')[2] == stage)]
    p = next((r for r in parities if (r['event'] == 'cold_parity' if stage == 'cold' else r.get('label') == PREFIX + stage)), None)
    complete = stages_finished.get(stage)
    inc = [r for r in rs if not r['full']]
    numeric = build_aggregate(rs)
    samples = []
    selected = list(dict.fromkeys([0, 1, len(inc)-2, len(inc)-1])) if inc else []
    for idx in selected:
        if 0 <= idx < len(inc):
            r = inc[idx]
            samples.append({'raw_line': r['_line'], 'label': r['label'], 'wall_us': r['wall_us'],
                            'dependency_sql': r['report']['dirty_plan']['dependency_sql'],
                            'dirty_plan': {k: v for k, v in r['report']['dirty_plan'].items() if k != 'dependency_sql'},
                            'resolution_freshness': r['report'].get('resolution_freshness')})
    stage_rows.append({'stage': stage, 'mutation_raw_line': mutations.get(stage, {}).get('_line'),
                       'finished_builds': len(rs), 'full_builds': sum(r['full'] for r in rs),
                       'incremental_builds': len(inc), 'full_build_outer_wall_us': sum(r['wall_us'] for r in rs if r['full']),
                       'incremental_build_outer_wall_us': sum(r['wall_us'] for r in inc),
                       'stage_finished_raw_line': complete['_line'] if complete else None,
                       'stage_passed': complete['passed'] if complete else None,
                       'recorded_stage_incremental_loop_wall_us': complete['incremental_wall_us'] if complete else None,
                       'parity_raw_line': p['_line'] if p else None,
                       'parity_wall_us': p['parity_wall_us'] if p else None,
                       'parity_equal': p['parity']['equal'] if p else None,
                       'canonical_bytes': p['parity']['canonical_bytes'] if p else None,
                       'parity_mode': p['parity']['oracle_mode'] if p else None,
                       'recorded_parity_table_count': len(p['parity']['tables']) if p else None,
                       'aggregate': numeric, 'first_last_incremental_examples': samples})

last = finishes[-1]
deadline_us = plan['deadline_ms'] * 1000
components = {
    'completed_full_build_outer_wall': sum(r['wall_us'] for r in full),
    'completed_incremental_build_outer_wall': sum(r['wall_us'] for r in incremental),
    'completed_parity_wall': sum(r['parity_wall_us'] for r in parities),
}
components['other_time_before_last_build_finished'] = last['end_us'] - sum(components.values())
components['after_last_build_finished_to_registered_deadline_unassigned'] = deadline_us - last['end_us']
assert sum(components.values()) == deadline_us and all(v >= 0 for v in components.values())

source_inputs = [
    ('crates/cc-eval/src/benchmark/p8_scale.rs', Path('/dev/shm/pr-triage-Gc8-100k-failure-analysis/source/crates/cc-eval/src/benchmark/p8_scale.rs'), [(581, 603), (780, 806), (872, 929)]),
    ('crates/cc-index/src/indexer.rs', Path('/dev/shm/pr-triage-Gc8-100k-failure-analysis/source/crates/cc-index/src/indexer.rs'), [(193, 220)]),
    ('crates/cc-index/src/indexer_phases/reconcile.rs', Path('/dev/shm/pr-triage-Gc8-100k-failure-analysis/source/crates/cc-index/src/indexer_phases/reconcile.rs'), [(105, 155), (170, 204)]),
    ('crates/cc-db/src/resolution_dependency_store.rs', Path('/dev/shm/todo-audit-H-dependency-exclusion/original/crates/cc-db/src/resolution_dependency_store.rs'), [(107, 173)]),
]
excerpts = []
for name, path, ranges in source_inputs:
    b = path.read_bytes()
    assert digest(b) == source_map['inputs'][name], name
    lines = b.decode().splitlines()
    excerpts.append({'repository_path': name, 'source_commit': SOURCE, 'cached_donor': str(path),
                     'bytes': len(b), 'sha256': digest(b),
                     'git_blob_computed': hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),
                     'exact_byte_bridge': 'Cached bytes match the fixed C3ff original source-before map; this is source-byte reuse only, never an execution transfer.',
                     'excerpts': [{'first_line': lo, 'last_line': hi, 'text': '\n'.join(lines[lo-1:hi])+'\n'} for lo, hi in ranges]})

report = {
    'schema': 'fixed-C3ff-original-failed-100k-phase-analysis-v1',
    'generated_runtime_UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Read-only arithmetic and source-scoped interpretation of one original failed primary. No validator/collector invocation, measurement, rerun, source mutation or acceptance credit.',
    'identity': {'source': SOURCE, 'source_tree_recorded': source_map['source_tree'], 'run_id': 37910924354,
                 'run_attempt': 1, 'job_id': 113760872142, 'artifact_id': 11626430756,
                 'sample': 'scale-100000/repetition-0', 'source_input_count_recorded': source_map['input_count'],
                 'binary_sha256_recorded': shard['binary_sha256'], 'binary_blake3_recorded': shard['binary_blake3'],
                 'build_receipt_sha256_recorded': shard['build_receipt_sha256'],
                 'raw': file_record(RAW_ROOT/'native/raw.jsonl')},
    'original_plan': plan,
    'native_failure': {'status': supervisor['status'], 'exit_code': supervisor['exit_code'],
                       'wall_ms': supervisor['wall_ms'], 'worker_exit_code': supervisor['worker_exit_code'],
                       'stderr_complete': supervisor['stderr_complete'], 'fixture_cleanup': supervisor['fixture_cleanup'],
                       'wall_scope': 'Supervisor lifetime includes cleanup; wall_ms minus deadline_ms is not extra accepted worker/parity duration.'},
    'event_counts': dict(event_counts),
    'build_pairing': {'unique_started': len(starts), 'unique_finished': len(finishes), 'unmatched_started': [],
                      'matching_start_full_label_wall_fields': True, 'finished_build_intervals_nonoverlapping': True},
    'completion': {'completed_full_builds': len(full), 'completed_incremental_builds': len(incremental),
                   'completed_parities': len(parities), 'all_recorded_parities_equal': all(r['parity']['equal'] for r in parities),
                   'completed_mutation_stages': list(stages_finished),
                   'started_but_not_closed_mutation_stage': 'batch_10',
                   'batch_10_incremental_and_full_builds_finished': True,
                   'unstarted_registered_stages': ['batch_100', 'batch_1000'],
                   'last_raw_line': last['_line'], 'last_raw_event': 'build_finished', 'last_build_label': last['label'],
                   'last_build_end_us': last['end_us'],
                   'unfinished_stage_location_limit': 'After batch_10/full_control finished and before stage_finished. Exact source next calls parity, then config_fact and emits stage_finished. No parity_started event or terminal inner marker exists; actual kill location and time split across these operations remain unknown.'},
    'outer_wall_accounting': {'denominator_us': deadline_us, 'denominator_definition': 'Original registered child deadline, not independently measured performance population.',
                            'components': {k: {'microseconds': v, 'seconds': v/1e6, 'percent_of_registered_deadline': 100*v/deadline_us} for k,v in components.items()},
                            'unassigned_before_last_scope': 'Generation, setup, mutation, loop/evidence/config-fact overhead and other gaps collectively; no narrower attribution.',
                            'unassigned_after_last_scope': 'A budget-coordinate remainder, not a measured parity interval, CPU time or proof of worker alive at every instant.'},
    'all_completed_builds': build_aggregate(finishes),
    'full_builds': build_aggregate(full),
    'incremental_builds': build_aggregate(incremental),
    'body_api_config_combined_within_this_one_sample': build_aggregate(resuming_three),
    'timing_schema': {'partition_fields': PARTITION, 'maximum_observed_partition_rounding_error_us': max(map(abs, partition_errors)),
                      'nested_fields_not_added_to_partition': ['prepare_snapshot_us', 'full_staging_us'],
                      'full_staging_is_subset_of_prepare': True, 'no_SQL_specific_duration_field': True,
                      'legacy_phase_timing_ms_not_added_to_BuildTiming': True},
    'stage_breakdown': stage_rows,
    'parity_scope': {'completed_wall_us': sum(r['parity_wall_us'] for r in parities),
                     'sum_recorded_canonical_bytes': sum(r['parity']['canonical_bytes'] for r in parities),
                     'canonical_byte_sum_is_repeated_work_not_unique_dataset_or_peak_memory': True,
                     'mode': sorted({r['parity']['oracle_mode'] for r in parities}),
                     'per_table_or_canonicalize_sort_compare_hash_time_unavailable': True,
                     'uncompleted_batch_10_parity_result_not_inferred': True},
    'SQL_attribution_limit': 'dependency_sql merges work from the initial resolution-dependency window, positive surface-dependency queries and fallback pending checks in reconcile. The raw counter is per build, not per SQL family/call/query-plan. VM steps/rows/sorts/statements cannot be assigned exclusively to resolution_dependents_with_work, converted into wall time, or called whole-workspace SQL work. Zero recorded FullscanStep does not mean zero expensive indexed traversal/sort work.',
    'evidence_guided_next_work': [
        {'target': 'Dependency exclusion/prefix replay',
         'observed': 'All recorded dependency_sql work lies in body/API/config, which required 490/171/330 incremental builds. First/last examples show increasing returned rows and VM work. The exact source still raises SQL LIMIT by excluded.len() and filters excluded paths after yielding rows.',
         'scope': 'This supports reviewing the already-isolated exclusion-query work and obtaining a distinct source-specific result. It does not prove that query alone dominates merged VM or that G4 resolves the five-hour failure. Preserve ordered/distinct/bounded semantics and the prior sparse-case counterexample.'},
        {'target': 'Repeated incremental prepare and commit',
         'observed': 'The 991 body/API/config builds record prepare and commit_write as the largest separate internal timing totals; their exact sums are included above.',
         'scope': 'Raw does not identify which commit suboperation/table or acquisition owns that time. Do not equate it with FTS or DB lock wait, remove required dirty work, or infer an O(N) full rewrite without separate source evidence.'},
        {'target': 'Exact parity work',
         'observed': 'Six completed exact disk-backed comparisons alone consume the recorded parity total; each reports roughly 10.3 GB canonical bytes.',
         'scope': 'Prioritize bounded implementation review only while preserving all original fifteen-table projections, duplicate handling and Value equality. Raw provides no per-table or serialization/sort/comparison split; do not remove parity or claim a RowProjection/borrowed-cursor speedup from this failed cohort.'},
        {'target': 'Full staging',
         'observed': 'Eight full builds all finished; nested full_staging_us accounts for a large part of their prepare time.',
         'scope': 'No per-table/FTS statement attribution or peak-buffer measurement exists here. Do not count staging twice, claim FTS alone explains it, or transfer an earlier prototype timing.'},
    ],
    'nonclaims': ['No pooling with Gc8/G2/H/G3/G4 or independent-run speedup inference',
                  'No new primary/sample acceptance, TODO closure, N/budget/workload change',
                  'No deadline increase or original failure replacement recommendation',
                  'No independent validator, build receipt or native binary execution'],
    'TODO': {'new_completed': 0, 'remaining': 29},
}

write('fixed-C3ff-failed-100k-phase-analysis.json', report)
write('source-instrumentation-excerpts.json', {'schema':'source-byte-bound-instrumentation-excerpts-v1','source':SOURCE,'files':excerpts})
after = [file_record(p) for p in sorted(RAW_ROOT.rglob('*')) if p.is_file()]
assert before == after
write('original-input-custody-before-after.json', {'schema':'read-only-original-custody-v1','unchanged':True,'files':before,
      'raw_not_copied_or_mutated':True,'acceptance_validator_not_invoked':True})
write('preparation-observation.json', {'schema':'analysis-preparation-observation-v1',
      'earlier_inline_exploration_exit':1,
      'error':'TypeError: unsupported operand type(s) for +: int and NoneType',
      'scope':'An exploratory Python Counter tried to add null full_staging_us. No output artifact or original mutation occurred. Final analysis retains null-count explicitly rather than treating missing staging as measured zero.',
      'raw_stdio_file_available':False,'evidence':'Original tool output in conversation; this is a descriptive record, not a claimed captured stderr file.',
      'rejected_cached_source_alias':'Old Gc8 resolution_dependency_store.rs SHA7afc688e… did not match C3ff expected c37a7c44…; it was not used for C3ff source conclusions. The exact c37a7c44 cached bytes were selected and hash-checked.'})
print(json.dumps({'status':'analysis_complete_not_acceptance','events':dict(event_counts),
                  'full_builds':len(full),'incremental_builds':len(incremental),'completed_parities':len(parities),
                  'unfinished_stage':'batch_10','outer_wall_us':components,
                  'original_files_before_after_equal':True,'report':str(OUT/'fixed-C3ff-failed-100k-phase-analysis.json')}))
