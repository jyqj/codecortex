# cold044 完整聚合接收准备

本说明仅读已恢复的固定源码，不执行聚合、验证器或产品。来源为 `044c008c9459cfa61e7701db2eb868342c508a39`；原研究为 run `37954851017` / attempt `1`。

原 workflow 的 aggregate job（`.github/workflows/p8-cold.yml:169–212`）在 build 成功且 preflight / measure 终态后运行，限时 30 分钟。它从本次 run / attempt 下载同一个原 build，以及所有 `p8-cold-shard-*-37954851017-1`；每个 artifact 保持一个独立子目录。checkout 使用原事件 head，不能改为后来 PR 的 head。

原函数入口是 `matrix.aggregate(build_directory, inputs, output)`。等 150 个原 envelope 目录全部齐备，可直接使用原 CLI（下面是待运行形式，没有执行）：

```bash
cd /workspace/scratch/bfccb8494ba0/cold044-original-intake/source
python3 scripts/p8_cold_matrix.py aggregate \
  --root "$PWD" \
  --build /workspace/scratch/bfccb8494ba0/cold044-original-intake/build-restoration/extracted \
  --output "<全新且尚不存在的输出目录>" \
  --inputs "<原片1解包目录>" "<原片2解包目录>" ... "<原片150解包目录>"
```

每个输入目录直接包含 `cold-shard.json` 与 `native-shard/`，不能传入 ZIP、capacity 目录、先前接收 summary 或只列原 raw 文件。CLI 的 aggregate 子命令没有 `--run-id` / `--attempt` 参数；原 build / 每片 receipt 和 driver 负责严格比对这些字段。原 ELF 需在当前合法宿主可执行；Actions 原命令将下载副本 chmod 为 0755，字节不变。

原 aggregate 自己执行一次 `validate_build`，再对所有输入调用原 `validate_shard`，最后原 `combine` 严格检查 5 尺度 × repetition 0–29 的 150 个唯一位置、单一 source / binary / study、每尺度相同 corpus 和每片一个 cold pair。这个最终函数内的全量验证是原代码行为；无需在此前另行重跑已接受的 51 片。输出必须不存在，失败原 JSON / 退出码仍保留。

成功时 `cold-matrix.json` 的 `status=complete_cold_measurement_coverage`、`passed=true`、`sample_count=150`，五个 group 各 `n=30`。统计按环境分层，明确不计算异构 pooled stable tails；该结果只有 cold scope，`release_certification=not_run`、`G8=not_evaluated`，不会自动更改 task 状态。

Actions 最后上传 `p8-cold-matrix-37954851017-1`，仅包含该输出目录中的 `cold-matrix.json`。它不包含完整 150 片 ZIP / raw 日志、build ELF 或独立 capacity ZIP。接收时保存原 matrix ZIP、官方 metadata / digest、实际 aggregate job / 完整日志与 JSON；现有逐片原件 custody 继续保留。原 build / shard / capacity / matrix 上传都使用 `if: always()`，失败也应留档。

当前已接受 51 / 150，不是完整 population；未接受 99 片分别是 1k、5k、10k 各 repetition 1–29，以及 50k repetition 18–29。本说明没有查询最新运行状态，因此这些是验收账本缺项，不声称它们尚未测量。

剩余的 owner custody 6 项是 100k repetition **4、5、6、7、8、11**：它们已经 owner 验收，等待 owner 将确切原 ZIP 和既有接收收据追加到 Git；不把这 6 项算作未测量，也不自动重复下载或接管。上个 root 原 28 片已持久于 `39cc7981…`；本次新 7 片已上传全部 blobs，本文冻结时 root 的合并 publication 尚未确认。确认后可记 45 已持久、6 待 owner，accepted 51 不变。

本准备不新增验收门、不改 N / 预算 / 协议，不给 TODO 完成信用。剩余 TODO：29。
