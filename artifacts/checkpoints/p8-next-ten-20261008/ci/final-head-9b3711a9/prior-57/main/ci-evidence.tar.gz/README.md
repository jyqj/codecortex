# 固定 head 57cec179 的正式 CI 归档

本目录只绑定 `57cec179b39f78a5c758aa43c8c4653fad349f1c` / tree `e0db3f4a2b99ff40cf574d41e855db321750408a`。
官方 run：https://github.com/jyqj/codecortex/actions/runs/37673188026，最终 `completed/success`。
各 job/step 原状态见 `official-jobs.json`；`verification-index.json` 汇总实际结果和日志内源码控制、任务状态输出。

check 日志实际含 392 组 Rust result：3119 passed、0 failed、126 ignored、1855 filtered out，其中 151 组没有实际执行测试。
Python 共 5 组、388 tests；逐组数量、状态和模块分布均保留。
这些是执行组累计，可能重复同一 suite；不是去重库存或全量未筛选测试通过声明。ignored 原名、原因与行号没有删去。

完整官方 decoded 日志无损 gzip，原文件继续留在 scratch；解压后 1001514 bytes，SHA256 `2cd8c58b22558473d4586fff4cf4d1ed965c3133dabdedbf134512ed43ae6f54`。
可用 `python3 parse_log.py <解压后的log路径> <新的输出JSON路径>` 重算结果，禁止覆盖既有文件再冒充新运行。
解析脚本只读取日志，不运行产品或测试。所有归档载荷由 `file-manifest.json` 绑定。本次没有修改 PR head、源码、任务或 CI。
