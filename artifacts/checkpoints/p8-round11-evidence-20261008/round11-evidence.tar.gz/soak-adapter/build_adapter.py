"""Generate the review draft from the previously reviewed G2 receiver."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

HERE=Path(__file__).resolve().parent
BASE=Path('/dev/shm/p8-formal-G2-soak-pr-audit/inspect.py')
old=BASE.read_text();text=old
def change(before,after):
    global text
    assert text.count(before)==1,(before[:80],text.count(before))
    text=text.replace(before,after)
change('original G2 ZIP','original G4 ZIP')
change('import zipfile','import zipfile\nimport re\nimport sys\nimport time\nfrom cache_wire import transport, bind_compound_reads')
change("REPO = '/workspace/scratch/2eaa00d0f93a/codecortex'","REPO = '/workspace/scratch/2eaa00d0f93a/p8-G4-exact-source'")
change("G2 = 'd2d492b329a5630bf4a5fa6bc4b6eac30d07b13c'","G4 = '260f596582f2d82b8d7c707b61a6b8b6a43b069f'")
text=text.replace('G2','G4')
change("ZIP_SHA = 'cfb1a236ec0b0652dd978642135f3b46cec9a33419faf6f5ea2934b39e7b9e56'","RUN, JOB = 37854847820, 113576447137")
change("    archive = HERE/'artifact-11581055784.zip'\n    require(archive.stat().st_size == 21033272 and sha(archive.read_bytes()) == ZIP_SHA, 'GitHub ZIP digest')",'''    expected=json.loads((HERE/'expected-artifact.json').read_bytes())
    require(expected['source']==G4 and expected['run_id']==RUN and expected['run_attempt']==1 and expected['job_id']==JOB, 'actual fixed G4 expected metadata required')
    api_run=json.loads((HERE/'run.json').read_bytes());api_jobs=json.loads((HERE/'jobs.json').read_bytes());api_artifacts=json.loads((HERE/'artifacts.json').read_bytes())
    require(api_run['id']==RUN and api_run['head_sha']==G4 and api_run['run_attempt']==1,'actual workflow identity')
    require(api_jobs['total_count']==len(api_jobs['jobs']),'complete jobs page')
    jobs=[j for j in api_jobs['jobs'] if j['id']==JOB]
    require(len(jobs)==1 and jobs[0]['name']=='soak' and jobs[0]['status']=='completed' and jobs[0]['conclusion']=='success' and jobs[0]['head_sha']==G4,'actual soak job success')
    require(api_artifacts['total_count']==len(api_artifacts['artifacts']),'complete artifacts page')
    artifacts=[a for a in api_artifacts['artifacts'] if a['id']==expected['artifact_id']]
    require(len(artifacts)==1 and artifacts[0]['name']=='p8-soak-'+G4 and artifacts[0]['workflow_run']['id']==RUN and artifacts[0]['workflow_run']['head_sha']==G4 and artifacts[0]['expired'] is False,'actual artifact role/source')
    require(artifacts[0]['size_in_bytes']==expected['bytes'] and artifacts[0]['digest']=='sha256:'+expected['sha256'],'actual GitHub artifact bytes')
    job_log=(HERE/f'job-{JOB}.log').read_text()
    require('git checkout --progress --force '+G4 in job_log and re.search(r'git log -1 --format=%H\\n[^\\n]*'+G4,job_log),'actual fixed-head checkout')
    archive = HERE/f"artifact-{expected['artifact_id']}.zip"
    ZIP_SHA=expected['sha256']
    with archive.open('rb') as f: archive_hash=hashlib.file_digest(f,'sha256').hexdigest()
    require(archive.stat().st_size == expected['bytes'] and archive_hash == ZIP_SHA, 'GitHub ZIP digest')
    output=HERE/'independent-review-01';output.mkdir()''')
change("require(not path.is_absolute() and '..' not in path.parts and info.filename not in inventory, 'unsafe duplicate member')","require(not path.is_absolute() and '..' not in path.parts and path.as_posix()==info.filename and '\\\\' not in info.filename and not info.flag_bits&1 and info.filename not in inventory, 'unsafe duplicate member')")
change("require(source['source_commit']==G4 and source['input_count']==len(source['inputs'])==1087, 'G4 source scope')","require(source['source_commit']==G4 and source['source_tree']=='645404431ca15770d6e729785a3ada68b096c593' and source['input_count']==len(source['inputs'])==1087, 'G4 source scope')")
change("        require(plan['build_identity']==report['final_build_verification'],'final build identity recheck')",'''        require(plan['build_identity']==report['final_build_verification'],'final build identity recheck')
        require(plan['build_identity']['source']==source and plan['build_identity']['observer']==observer and plan['build_identity']['artifacts']==build['artifacts'],'full initial identity')
        require(plan['build_identity']['build_seal_sha256']==sha(z.read('p8-build/seal.json')),'build seal identity')
        for name,row in plan['retained_build_evidence'].items():
            require(z.read('p8-build/'+name)==z.read('p8-runtime/build-evidence/'+name) and row=={k:v for k,v in inventory['p8-build/'+name].items() if k!='crc32'},'all original retained build proof copies')''')
change("        for name, identity in build['artifacts'].items():",'''        require(build['schema_version']==2 and build['status']=='passed','strict builder schema/status')
        require(build['build_command']==['cargo','build','--release','--locked','--offline','--no-default-features','-p','cc-server','--bin','codecortex','-p','cc-eval','--bin','p8-oracle','--bin','p8-runtime-statistics','--message-format=json-render-diagnostics','--target-dir',build['target_dir']],'original exact Cargo argv')
        require(sha(z.read('p8-build/product-build.jsonl'))==build['cargo_log_sha256'] and sha(z.read('p8-build/product-build.stderr'))==build['stderr_sha256'],'both Cargo log hashes')
        targets={'codecortex':('cc-server','src/main.rs','binary'),'p8-oracle':('cc-eval','src/bin/p8-oracle.rs','oracle'),'p8-runtime-statistics':('cc-eval','src/bin/p8-runtime-statistics.rs','statistics')}
        require(set(build['artifacts'])==set(targets),'original three release artifacts')
        for name, identity in build['artifacts'].items():''')
change("            require(a['executable']==identity['copy_source']['path'] and a['manifest_path'].startswith('/home/runner/work/codecortex/codecortex/crates/') and a['target']['src_path'].startswith('/home/runner/work/codecortex/codecortex/crates/'),'producer paths')",'''            package,relative,field=targets[name]
            require(a['target']['kind']==['bin'] and a['features']==[] and a['executable']==build['target_dir']+'/release/'+name==identity['copy_source']['path'] and a['manifest_path']=='/home/runner/work/codecortex/codecortex/crates/'+package+'/Cargo.toml' and a['target']['src_path']=='/home/runner/work/codecortex/codecortex/crates/'+package+'/'+relative,'exact producer paths/profile')
            require(identity['binary_sha256']==build[field+'_sha256'],'binary role binding')''')
change("        names={'median','rss_trend','sample_coverage','latency_summary'}",'''        names={'median','rss_trend','sample_coverage','latency_summary','owned','require_stable_symbol','cache_identity','cache_lookup','require_stable_hybrid','validate_cache_probe','soak_cache_summary'}
        constants={'MARKER','QUERY','CACHE_COUNTERS','SOAK_READ_PROTOCOL','SOAK_READ_ROLES'}
        assignments=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in constants for t in n.targets)]''')
change("pure=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[])","pure=ast.Module(body=assignments+[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[])")
change("ns={'math':math,'require':require};exec(compile(pure,'fixed_G4_pure_summaries','exec'),ns)","ns={'math':math,'Counter':Counter,'hashlib':hashlib};rollback=ast.parse(z.read('p8-build/observer-source/scripts/p8_rollback.py'));original_require=next(n for n in rollback.body if isinstance(n,ast.FunctionDef) and n.name=='require');exec(compile(ast.Module(body=[original_require],type_ignores=[]),'fixed_G4_require','exec'),ns);exec(compile(pure,'fixed_G4_pure_summaries','exec'),ns)")
change("        # Stream all original transport JSON, ensuring both owned sessions close cleanly.",'''        project=output/'archived-stable-fixture';project.mkdir()
        for name in ('.p8-owned','stable.py'):
            b=z.read('p8-runtime/project/'+name)
            require(b==z.read('p8-runtime/fresh-full/'+name),'original endpoint stable fixture bytes differ')
            with (project/name).open('xb') as f:f.write(b)
        cache=ns['soak_cache_summary'](rows,3601,cov['work_start_ns'],cov['work_end_ns'],project)
        require(cache==report['cache_reuse'] and cache['passed'] and cache['validated_reads']==2400,'full exact original cache summary replay')
        require(cache['request_counts']=={role:{'success':2400} for role in ns['SOAK_READ_ROLES']} and cache['status_request_counts']=={'success':4800},'9600 original cache RPC denominator')
        protocol=plan['read_protocol']
        require(protocol['name']==ns['SOAK_READ_PROTOCOL'] and protocol['offered_read_operations']==2400 and protocol['planned_request_counts']=={role:2400 for role in ns['SOAK_READ_ROLES']} and protocol['request_roles']==list(ns['SOAK_READ_ROLES']) and protocol['strategy']=='local','original compound read plan')
        require(protocol['rpc_timeout_seconds']==dict(before_status=30,symbol=60,hybrid=60,after_status=30) and protocol['rpc_timeout_sum_seconds']==180,'per-RPC budgets; no new whole-read SLA')
        (output/'cache-replay.json').write_text(json.dumps(cache,sort_keys=True,indent=2)+'\\n')
        replay_binary=output/'original-p8-runtime-statistics'
        with replay_binary.open('xb') as f:f.write(z.read('p8-build/p8-runtime-statistics'))
        replay_binary.chmod(0o555)
        for name in ('plan.json','raw.jsonl'):
            with (output/name).open('xb') as f:f.write(z.read('p8-runtime/'+name))
        command=[str(replay_binary),'--plan',str(output/'plan.json'),'--raw',str(output/'raw.jsonl'),'--output',str(output/'statistics.json')]
        (output/'statistics-command.json').write_text(json.dumps(command)+'\\n')
        started=time.monotonic()
        with (output/'statistics.stdout').open('xb') as stdout,(output/'statistics.stderr').open('xb') as stderr:
            replayed=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=120)
        require(replayed.returncode==0 and (output/'statistics.json').read_bytes()==z.read('p8-runtime/statistics.json'),'actual offline retained Rust statistics replay')
        require(sha(replay_binary.read_bytes())==build['statistics_sha256'] and all(sha((output/name).read_bytes())==inventory['p8-runtime/'+name]['sha256'] for name in ('plan.json','raw.jsonl')),'offline replay inputs/binary unchanged')
        statistics_replay=dict(argv=command,exit_code=replayed.returncode,seconds=time.monotonic()-started,byte_identical=True)
        # Stream all original transport JSON, ensuring both owned sessions close cleanly.''')
start=text.index('        transport={}')
end=text.index("        endpoint=next",start)
text=text[:start]+'''        transports={};cache_wire=None
        for prefix in ['product','full-product']:
            events=(json.loads(line) for line in z.open('p8-runtime/'+prefix+'/rpc.jsonl'))
            requests,responses,times,kinds=transport(events)
            process=read('p8-runtime/'+prefix+'/process.json')
            require(process['exit_code']==0 and process['cleanup']=='completed' and process['tool_count']==14 and process['binary_sha256']==build['binary_sha256'],'original process closure')
            if prefix=='product':
                cache_wire=bind_compound_reads(rows,requests,responses,times)
                require(cache_wire['compound_reads']==2400 and cache_wire['bound_RPCs']==9600,'all compound reads bound to original stdio')
                require(all(r['cache_probe']['server_pid']==process['pid'] for r in rows if r['operation']=='read'),'cache probes from actual owned server')
                indexes=[p for p in requests.values() if p.get('method')=='tools/call' and p.get('params',{}).get('name')=='index']
                require(len(indexes)==1202 and indexes[0]['params']['arguments']['full'] is True and all(p['params']['arguments']['full'] is False for p in indexes[1:]),'initialfull+1201increments; no endpoint repair')
                (output/'cache-wire-binding.json').write_text(json.dumps(cache_wire,sort_keys=True,indent=2)+'\\n')
            transports[prefix]={'kinds':kinds,'process_exit_0_observed':True,'stdout_eof_observed':True}
''' +text[end:]
start=text.index("        result={'decision':")
end=text.index("        (HERE/'member-hashes.json')",start)
text=text[:start]+'''        result={'decision':'accepted_scoped_original_G4_soak_observation','source_commit':G4,'run_id':RUN,'job_id':JOB,'artifact_id':expected['artifact_id'],'artifact_sha256':ZIP_SHA,'artifact_bytes':expected['bytes'],'all_member_count':len(inventory),'all_member_bytes':sum(x['bytes'] for x in inventory.values()),'all_member_CRC_SHA_verified':True,'run_seal_files':2108,'build_seal_files':15,'source_inputs_exact_Git':1087,'observer_files_exact_Git':7,'operations':dict(operations),'outcomes':{'success':3601},'observed_work_ns':report['observed_work_ns'],'rss':report['rss'],'resource_coverage':cov,'branch_switches':switches,'catalog_compactions':compactions,'configured_C':4,'observed_workload_peak':report['actual_concurrency']['maximum'],'parity_tables':15,'original_parity_exit_code':0,'statistics_replay':statistics_replay,'cache_reuse':cache,'bound_cache_RPCs':cache_wire['bound_RPCs'],'endpoint_search_cache':endpoint['search_cache'],'transport':transports,'limitations':['Offline receipt/raw replay only; no product/Cargo/new performance measurement. Original full parity evidence retained without rerunning product or oracle.','Compound read is one offered sample containing two status, symbol and local hybrid calls. All 9600 subrequests stay within 2400 read samples.','Same native server and bounded shared query-pool counters are observed; no individual OS-thread, semantic-worker, provider or actual C4-peak claim.','Per-RPC timeout sum is180 seconds excluding admission wait; no new performance SLA. Uniform soak timings are not directly comparable to previous symbol-only reads.','Original IID intervals retain serial-correlation limitations; original Rust statistics replay is byte-identical without creating a new estimator.'],'TODO_closed':0,'TODO_remaining':29}
        with archive.open('rb') as f:require(hashlib.file_digest(f,'sha256').hexdigest()==ZIP_SHA,'original ZIP unchanged after replay')
''' +text[end:]
text=text.replace("'transport':transport}","'transport':transports}")
ast.parse(text)
(HERE/'inspect.py').write_text(text)
(HERE/'adapter.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile=str(BASE),tofile=str(HERE/'inspect.py'))))
(HERE/'adapter-plan.json').write_text(json.dumps({'status':'draft_not_executed_no_actual_G4_artifact','original':str(BASE),'original_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(text.encode()).hexdigest(),'source':'260f596582f2d82b8d7c707b61a6b8b6a43b069f','fixed_run':37854847820,'fixed_job':113576447137,'actual_expected_artifact_required':True,'product_or_Cargo_execution':False,'actual_offline_statistics_replay_planned':True,'TODO_closed':0,'TODO_remaining':29},indent=2,sort_keys=True)+'\n')
print(hashlib.sha256(text.encode()).hexdigest())
