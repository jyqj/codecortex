from pathlib import Path
import json,hashlib,tarfile,shutil,gzip,re,subprocess
r=Path('/workspace/owner-boundary-validation');dest=Path('/workspace/codecortex/artifacts/reviews/query-owner-source-boundary-correction-20261004');dest.mkdir(parents=True,exist_ok=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=dest.parents[2],text=True).strip()=='142549a65b7eaee78ae5a06a82ba8695a6f33bd9'
s=json.loads((r/'comparison.json').read_text());identities=json.loads((r/'identities.json').read_text());counts={a:sum(v['pair'][0]==a for v in s['bonus_changes']) for a in ['base','candidate','rejected']}
files=[p for p in r.iterdir() if p.is_file() and p.suffix in ['.py','.rs','.json','.jsonl','.log','.txt','.patch'] and p.name!='archive-manifest.json']
files+=list((r/'source-snapshots').rglob('*'));files+=list((r/'prior-author').rglob('*'));files+=list((r/'results').rglob('results.json'));files += [p for p in (r/'fixtures').rglob('*') if p.name in ['micro.go','.codecortex.json']]
files=sorted({p for p in files if p.is_file()});manifest={str(p.relative_to(r)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files};(r/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert 'boundary_driver.rs' in manifest and 'prior-author/comparison_driver.rs' in manifest
assert "root/'boundary_driver.rs'" in (r/'link_driver.py').read_text()
assert len(re.findall(r'^\s*\(("(?:[^"\\]|\\.)*"),',(r/'boundary_driver.rs').read_text(),re.M))==85
assert len(re.findall(r'^\s*\(("(?:[^"\\]|\\.)*"),',(r/'prior-author/comparison_driver.rs').read_text(),re.M))==32
with tarfile.open(dest/'evidence.tar.gz','w:gz') as tar:
 for p in files+[r/'archive-manifest.json']:tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
with tarfile.open(dest/'evidence.tar.gz','r:gz') as tar:
 for name,record in manifest.items():
  b=tar.extractfile(name).read();assert hashlib.sha256(b).hexdigest()==record['sha256'] and len(b)==record['bytes']
 assert hashlib.sha256(tar.extractfile('boundary_driver.rs').read()).hexdigest()==identities['drivers']['boundary_driver.rs']
 assert hashlib.sha256(tar.extractfile('prior-author/comparison_driver.rs').read()).hexdigest()==identities['drivers']['prior-author/comparison_driver.rs']
 assert not any(name.endswith(('.db','.rlib')) or '/target-' in name for name in tar.getnames())
for source,target in [('comparison.json','comparison.json'),('boundary_driver.rs','boundary_driver.rs'),('prior-author/comparison_driver.rs','prior-author-32-query-driver.rs')]:shutil.copyfile(r/source,dest/target)
(dest/'correction.patch.gz').write_bytes(gzip.compress((r/'correction.patch').read_bytes(),mtime=0))
arc=dest/'evidence.tar.gz';binding={'tested_source_sha':identities['correction']['commit'],'base_sha':identities['base']['commit'],'candidate_sha':identities['candidate']['commit'],'rejected_delivery_sha':identities['rejected']['commit'],'preserved_rejection_evidence_sha':'ca65b7073f78687a2e6286d7bf8a549d1a3e6443','original_lock_sha256':identities['correction']['files']['Cargo.lock'],'source_files':identities['correction']['files'],'invariants':identities['invariants'],'drivers':identities['drivers'],'counts':{'queries_per_variant':85,'four_arm_query_api_comparisons':s['four_arm_query_api_comparisons'],'arm_outputs':s['four_arm_query_api_comparisons']*4,'common_hit_pair_checks':s['common_hit_pair_checks'],'bonus_changes':counts,'rank_derived_metadata_changes':len(s['rank_derived_metadata_changes']),'exact_independent_code_reference_observations':len(s['code_reference_challenges']),'tests':{'base':6,'candidate':10,'rejected':13,'correction':15}},'archive':{'path':arc.name,'sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'bytes':arc.stat().st_size,'manifest_entries':len(manifest)},'scope':'Focused synthetic engine/in-process MCP; no general NL or public DEV qualification'}
(dest/'binding.json').write_text(json.dumps(binding,indent=2)+'\n');print(json.dumps(binding['counts'],indent=2));print(binding['archive'])
