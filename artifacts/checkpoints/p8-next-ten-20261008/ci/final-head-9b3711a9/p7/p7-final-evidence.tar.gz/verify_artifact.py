"""Read-only verification of the official new-head P7 artifact and job log."""
from collections import Counter
import argparse
import gzip
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--repo", type=Path, required=True, help="Git checkout containing the fixed 8e12 and 9b commits")
parser.add_argument("--output-dir", type=Path, help="Optional empty destination for recomputed JSON; default is read-only")
options = parser.parse_args()
REPO = options.repo.resolve()
RESULT_OUT = options.output_dir
ZIP = OUT / "p7-engineering-run37674979650.zip"
HEAD = "9b3711a9346b64868b64cf6cc1f6e38162a59a43"
CHECKOUT = "0b69df3ca6c3fc1a76d28b363c3f0e3d6d23a998"
TREE = "5fd3e14bfabd98346a4fb0b18c28b04c8b212bec"
PRODUCT = "8e12c3884edbb2743eb2aee82fafa285e8b28ef7"
CANONICAL = "4c9aeb9cac2eea382d2dbce6d85220af3e10f6483b4c1f696b7874ecaff0fdb4"


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, data):
    if RESULT_OUT is None:
        return
    RESULT_OUT.mkdir(parents=True, exist_ok=True)
    with (RESULT_OUT / name).open("x") as stream:
        stream.write(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n")


def git(*args, data=None):
    return subprocess.check_output(["git", *args], cwd=REPO, input=data)


def source_inputs(ref):
    entries = git("ls-tree", "-r", "-z", ref, "--", "crates", "Cargo.toml", "Cargo.lock")
    objects = {}
    for entry in entries.split(b"\0"):
        if not entry:
            continue
        metadata, name = entry.split(b"\t", 1)
        mode, kind, oid = metadata.decode().split()
        require(mode in ("100644", "100755") and kind == "blob", "non-regular fixed input")
        objects[name.decode()] = oid
    names = sorted(objects)
    raw = git("cat-file", "--batch", data=("\n".join(objects[n] for n in names) + "\n").encode())
    offset, result = 0, {}
    for name in names:
        end = raw.index(b"\n", offset)
        oid, kind, size = raw[offset:end].decode().split()
        require(oid == objects[name] and kind == "blob", "batch response identity")
        length = int(size)
        content = raw[end + 1:end + 1 + length]
        offset = end + 1 + length
        require(len(content) == length and raw[offset:offset + 1] == b"\n", "batch framing")
        result[name] = sha(content)
        offset += 1
    require(offset == len(raw), "unexpected batch bytes")
    return result


log_path = OUT / "job-112976034193.log"
log_raw = (log_path.read_bytes() if log_path.is_file()
           else gzip.decompress(log_path.with_suffix(".log.gz").read_bytes()))
ansi = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
lines = [ansi.sub("", re.sub(r"^\d{4}-\d{2}-\d{2}T\S+\s", "", line))
         for line in log_raw.decode().splitlines()]
pattern = re.compile(r"^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; "
                     r"(\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s$")
rows, python_rows, ignored_rows, target = [], [], [], None
for number, line in enumerate(lines, 1):
    if line.lstrip().startswith("Running "):
        target = line.strip()
    match = pattern.fullmatch(line)
    if match:
        require(target is not None, "result without harness identity")
        rows.append(dict(target=target, result_line=number, status=match[1],
                         **{name: int(match[index]) for index, name in enumerate(
                             ["passed", "failed", "ignored", "measured", "filtered_out"], 2)},
                         seconds=float(match[7]), original_result=line))
    if re.fullmatch(r"test .+ \.\.\. ignored(?:, .*)?", line):
        ignored_rows.append(dict(line_number=number, target=target, original_line=line))
    match = re.fullmatch(r"Ran (\d+) tests? in ([0-9.]+)s", line)
    if match:
        status = next(s for s in lines[number:] if s.strip())
        require(status == "OK", "Python suite not successful")
        python_rows.append(dict(tests=int(match[1]), seconds=float(match[2]), status=status,
                                result_line=number))
require(rows and all(row["status"] == "ok" and row["failed"] == 0 for row in rows), "Rust failure")
totals = {key: sum(row[key] for row in rows) for key in ("passed", "failed", "ignored", "measured", "filtered_out")}
require(len(ignored_rows) == totals["ignored"], "ignored lines and totals differ")
require(len(python_rows) == 1 and python_rows[0]["tests"] == 15, "unexpected Python inventory")

run = json.loads((OUT / "official-run.json").read_text())
jobs = json.loads((OUT / "official-jobs.json").read_text())["jobs"]
artifacts = json.loads((OUT / "official-artifacts.json").read_text())["artifacts"]
require(len(artifacts) == 1, "unexpected artifact inventory")
artifact = artifacts[0]
checkout = json.loads((OUT / "official-checkout-commit.json").read_text())
require(checkout["sha"] == CHECKOUT and checkout["tree"]["sha"] == TREE, "official checkout differs")
require([row["sha"] for row in checkout["parents"]] == ["d53a4972af92fd10a5cddb9f15ffdf06414b3d54", HEAD],
        "actual checkout parent identities differ")
require(run["id"] == 37674979650 and run["head_sha"] == HEAD and run["conclusion"] == "success", "wrong run")
require(len(jobs) == 1 and jobs[0]["id"] == 112976034193 and jobs[0]["conclusion"] == "success", "wrong job")
require(all(s["status"] == "completed" and s["conclusion"] == "success" for s in jobs[0]["steps"]), "incomplete step")
zip_raw = ZIP.read_bytes()
require(artifact["id"] == 11506792469 and artifact["workflow_run"]["head_sha"] == HEAD, "wrong artifact")
require(artifact["digest"] == "sha256:" + sha(zip_raw), "official ZIP digest differs")
require(artifact["size_in_bytes"] == len(zip_raw), "official ZIP size differs")
fixed = source_inputs(PRODUCT)
require(len(fixed) == 785 and sha(json.dumps(fixed, sort_keys=True, separators=(",", ":")).encode()) == CANONICAL,
        "fixed product inventory differs")
require(source_inputs(HEAD) == fixed, "published head differs from fixed product")

with zipfile.ZipFile(ZIP) as archive:
    names = archive.namelist()
    require(len(names) == len(set(names)), "duplicate ZIP members")
    require(not any("request-failures" in name for name in names), "worker failure file present")
    members = {name: archive.read(name) for name in names}
    before_raw, after_raw = members["source-before.json"], members["source-after.json"]
    before, after = json.loads(before_raw), json.loads(after_raw)
    require(before_raw == after_raw and before == after, "source changed during CI")
    require(before["source_commit"] == CHECKOUT and before["source_tree"] == TREE, "unexpected checkout identity")
    require(before["input_count"] == 785 and before["inputs"] == fixed, "artifact input inventory differs")
    pretty = (json.dumps(fixed, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()
    require(before["manifest_sha256"] == sha(pretty), "internal manifest digest differs")
    require(any(line == CHECKOUT for line in lines), "checkout SHA absent from actual log")
    seed_rows = []
    for seed in (7, 19, 43):
        prefix = f"worker-contention/seed-{seed}/"
        protocol = json.loads(members[prefix + "protocol.json"])
        summary = json.loads(members[prefix + "summary.json"])
        require(protocol["seed"] == summary["seed"] == seed, "seed identity differs")
        require(protocol["concurrency_cells"] == [1, 4] and protocol["samples_per_cell"] == 32,
                "protocol cells differ")
        require(protocol["phases"] == ["quiet", "held"] and protocol["query_watchdog_ms"] == 2000
                and protocol["progress_watchdog_ms"] == 5000, "protocol phase or watchdog differs")
        require(summary["old_held_input_publications"] == 0 and summary["full_p7_015_complete"] is False,
                "unexpected publication or certification claim")
        phases = {}
        for phase in ("quiet", "held"):
            raw = members[prefix + phase + "-requests.json"]
            requests = json.loads(raw)
            require(len(requests) == 64, "incomplete phase requests")
            require(set(r["concurrency"] for r in requests) == {1, 4}, "unknown concurrency")
            for concurrency in (1, 4):
                cell = [r for r in requests if r["concurrency"] == concurrency]
                require(len(cell) == 32 and sorted(r["ordinal"] for r in cell) == list(range(32)),
                        "missing or duplicated request ordinal")
            require(all(any(h["file_path"] == "stable.rs" for h in r["hits"]) for r in requests),
                    "missing stable local hit")
            for row in requests:
                timings = [row[key] for key in ("caller_schedule_us", "capture_admission_us", "retrieval_us", "offered_to_api_return_us")]
                require(all(type(value) is int and value >= 0 for value in timings), "invalid timing")
                require(sum(timings[:3]) <= timings[3] <= sum(timings[:3]) + 2, "timing projection mismatch")
            require({s["concurrency"]: s["n"] for s in summary[phase]} == {1: 32, 4: 32},
                    "summary projection differs")
            phases[phase] = dict(request_count=len(requests), concurrency_cells=[1, 4],
                                 ordinals_per_cell="0..31 exactly once", all_requests_have_stable_rs_hit=True,
                                 raw_sha256=sha(raw))
        seed_rows.append(dict(seed=seed, phases=phases, old_held_input_publications=0, full_p7_015_complete=False))
    artifact_results = [line for name, raw in members.items() if name.endswith(".log")
                        for line in raw.decode().splitlines() if pattern.fullmatch(ansi.sub("", line))]
    require(Counter(ansi.sub("", line) for line in artifact_results) == Counter(row["original_result"] for row in rows),
            "artifact and official job Rust result lines differ")

parsed = dict(schema_version=1, verified_at=datetime.now(timezone.utc).isoformat(),
              run_id=run["id"], job_id=jobs[0]["id"], head_sha=HEAD,
              official_job_log=dict(bytes=len(log_raw), sha256=sha(log_raw)),
              rust=dict(result_groups=len(rows), **totals, groups=rows, ignored_lines=ignored_rows),
              python=dict(suites=python_rows, total_tests=sum(row["tests"] for row in python_rows)),
              steps=jobs[0]["steps"])
save("parsed-results.json", parsed)
verified = dict(schema_version=1, artifact_id=artifact["id"], archive_path=str(ZIP),
                archive_bytes=len(zip_raw), archive_sha256=sha(zip_raw), members=len(members),
                source=dict(source_commit=CHECKOUT, source_tree=TREE, before_after_byte_equal=True,
                            input_count=785, fixed_product=PRODUCT, input_map_sha256=CANONICAL,
                            manifest_sha256=before["manifest_sha256"], raw_snapshot_sha256=sha(before_raw)),
                seed_results=seed_rows, total_cells=12, total_requests=sum(
                    p["request_count"] for row in seed_rows for p in row["phases"].values()),
                member_hashes={name: dict(bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(members.items())},
                scope="New-head fixed P7 regression evidence only; no P7-015 completion, performance SLA or release certification.")
save("artifact-check.json", verified)
print(json.dumps(dict(status="passed", rust_result_groups=len(rows), rust=totals,
                      python_tests=parsed["python"]["total_tests"], worker_requests=verified["total_requests"],
                      source_inputs=785, source_map_sha256=CANONICAL, checkout=CHECKOUT, source_tree=TREE)))
