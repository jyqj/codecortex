def stable_00338():
    return 338
