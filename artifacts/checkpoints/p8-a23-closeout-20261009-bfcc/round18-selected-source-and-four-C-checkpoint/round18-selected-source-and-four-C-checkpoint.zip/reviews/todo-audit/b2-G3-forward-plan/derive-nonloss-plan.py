#!/usr/bin/env python3
"""Local, read-only Git object calculation; no git mutation or product execution."""
import ast
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
def read(path):
    return json.loads(Path(path).read_text())
def save(name, value):
    (ROOT / name).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')
pure = ast.parse(Path('/dev/shm/todo-audit-P3-H-d22-candidate-plan/verify-prospective-plan.py').read_text())
ns = {'hashlib': hashlib}
exec(compile(ast.Module(body=[n for n in pure.body if isinstance(n, ast.FunctionDef) and n.name in {'oid', 'tree_oid', 'leaf_map'}], type_ignores=[]), '<retained-pure-tree-functions>', 'exec'), ns)
oid, tree_oid, leaf_map = (ns[n] for n in ('oid', 'tree_oid', 'leaf_map'))
stages = {}
leaves = leaf_map(read('/dev/shm/todo-audit-p8007-final-main-integration/actual-P2/actual-P2-complete-derived-Git-tree.json'))
assert tree_oid(leaves) == '964af30886e142c6284dddab4e4451b4dc5e26cb'
def manifest(path, expected):
    for row in read(path)['files']:
        assert row['repository_path'] not in leaves
        leaves[row['repository_path']] = {'mode': row.get('mode', '100644'), 'type': 'blob', 'sha': row['git_blob']}
    assert tree_oid(leaves) == expected
def request(path, expected):
    req = read(path)
    assert tree_oid(leaves) == req['base_tree']
    for row in req['tree']:
        leaves[row['path']] = {k: row[k] for k in ('mode', 'type', 'sha')}
    assert tree_oid(leaves) == expected
manifest('/dev/shm/execution-recon-recovery-20261009/final-R2/upload-manifest.json', '90d4c0aec835c9b5fff9d809c433d353d409dcf8')
request('/dev/shm/todo-audit-G2-cd68-binding/two-binding-create-tree-request.json', '41a1708082eb49432e8e22aac2c0400f80337cfb')
request('/dev/shm/todo-audit-G2-cd68-binding/future-H-20-artifact-create-tree-request.json', '9755e717368ffb51bc084c3348c1715b00b34d0d')
H = copy.deepcopy(leaves)
request('/dev/shm/todo-audit-P3-H-d22-candidate-plan/prospective-P3-create-tree-request.json', '5ac4d3fb96cfb11433d529b8292d1e7652471036')
request('/dev/shm/todo-audit-H-dependency-exclusion-v3/P3f-create-tree-request.json', 'c61707e398739be23b01570af025c412a723689c')
manifest('/dev/shm/execution-recon-recovery-20261009/final-R3/upload-manifest.json', '11db88d8c60b6be658f40d419dd46c915c716b93')
request('/dev/shm/todo-audit-G3-4ec7543d-binding/two-binding-create-tree-request.json', 'e7a7f5a685c44aee34b8716377308f0af8782fdd')
G3 = copy.deepcopy(leaves)
compare_path = Path('/dev/shm/root-round17/H-to-b2-official-compare.json')
compare_raw = compare_path.read_bytes()
compare = json.loads(compare_raw)
assert compare['base_commit']['sha'] == compare['merge_base_commit']['sha'] == '0e6b07c75183da79c5a6679d4c2b66c65f7db663'
assert compare['total_commits'] == len(compare['commits']) == 14
assert compare['status'] == 'ahead' and compare['behind_by'] == 0
assert compare['commits'][-1]['sha'] == 'b2a17adc188338c48b95d01761836916e5d0fcdb'
assert len(compare['files']) == 42
b2 = copy.deepcopy(H)
for row in compare['files']:
    path = row['filename']
    assert row['status'] in {'added', 'modified'}
    assert (path not in H) == (row['status'] == 'added')
    b2[path] = {'mode': '100644', 'type': 'blob', 'sha': row['sha']}
# Mode assumptions above are validated over the full tree, not accepted on naming alone.
assert tree_oid(b2) == compare['commits'][-1]['commit']['tree']['sha'] == '8e82c2c60188148f91c2c8bfa58c1e158a94b8af'
sql_paths = ['crates/cc-db/src/resolution_dependency_store.rs', 'crates/cc-db/tests/p2b_resolution_store.rs']
own_artifacts = [x['repository_path'] for x in read('/dev/shm/execution-recon-recovery-20261009/final-R3/upload-manifest.json')['files']]
incoming_artifacts = [x['filename'] for x in compare['files'] if x['filename'].startswith('artifacts/')]
assert len(incoming_artifacts) == 36 and all(p not in G3 for p in incoming_artifacts)
assert len(own_artifacts) == 2 and all(p not in b2 for p in own_artifacts)
assert all(b2[p] == H[p] for p in sql_paths)
assert b2['docs/BENCHMARK.md'] == G3['docs/BENCHMARK.md']
bindings = ['scripts/reviewed-source-registry-v15.json', 'scripts/verify_reviewed_source_v15.py']
overlap = sorted(p for p in H if H[p] != G3[p] and H[p] != b2[p])
assert overlap == sorted(bindings + ['docs/BENCHMARK.md'])
assert all(b2[p] != G3[p] for p in bindings)
prospective = copy.deepcopy(b2)
for p in sql_paths + own_artifacts:
    prospective[p] = G3[p]
changed_from_b2 = sorted(p for p in prospective if prospective[p] != b2.get(p))
assert changed_from_b2 == sorted(sql_paths + own_artifacts)
assert set(b2).issubset(prospective) and set(G3).issubset(prospective)
assert all(prospective[p] == b2[p] for p in b2 if p not in sql_paths)
assert all(prospective[p] == G3[p] for p in G3 if p.startswith('artifacts/'))
changes_from_G3 = sorted(p for p in prospective if prospective[p] != G3.get(p))
assert len(changes_from_G3) == 41
req = {'base_tree': tree_oid(b2), 'tree': [{'path': p, **prospective[p]} for p in changed_from_b2]}
save('prospective-four-leaf-create-tree-request.json', req)
maps = read('/dev/shm/todo-audit-P3f-G3-binding-preparation/actual-P3f-mechanical-input-maps.json')
maps['source'] = None
maps['source_tree'] = tree_oid(prospective)
maps['ordered_parents'] = ['b2a17adc188338c48b95d01761836916e5d0fcdb', '67b7f4ee15a9c9633868b446870fec1358dda3d9']
maps['scope'] = 'prospective mechanical union only; no actual product commit, independent review, source admission, or execution claim'
raw_items = []
for p, name in [('crates/cc-search/src/preselect.rs', 'preselect.rs'), ('crates/cc-eval/tests/p8_scale.rs', 'p8_scale.rs'), ('.github/workflows/p8-db-lock-observation.yml', 'p8-db-lock-observation.yml')]:
    raw = (ROOT / 'source' / name).read_bytes()
    assert oid('blob', raw) == b2[p]['sha']
    digest = hashlib.sha256(raw).hexdigest()
    raw_items.append({'path': p, **b2[p], 'sha256': digest, 'bytes': len(raw), 'local_path': str(ROOT / 'source' / name)})
    if p in maps['complete_inputs']:
        before = maps['complete_inputs'][p]
        if p not in maps['paths']:
            maps['paths'][p] = {'before_sha256': before, 'sha256': digest}
        else:
            maps['paths'][p]['sha256'] = digest
        maps['complete_inputs'][p] = digest
    else:
        assert p in maps['validation_inputs']
        maps['validation_inputs'][p] = digest
assert [len(maps[k]) for k in ('complete_inputs', 'paths', 'validation_inputs')] == [1095, 71, 142]
save('prospective-complete-product-validation-inputs.json', maps)
save('bounded-source-readback.json', raw_items)
save('prospective-1237-mode-blob-map.json', {p: {**prospective[p], 'sha256': maps['complete_inputs'].get(p, maps['validation_inputs'].get(p))} for p in sorted(set(maps['complete_inputs']) | set(maps['validation_inputs']))})
summary = {
    'scope': 'read-only prospective source integration; no remote mutation or execution', 'actual_new_P': None,
    'sources': {'H': {'sha': compare['base_commit']['sha'], 'tree': tree_oid(H)}, 'b2': {'sha': compare['commits'][-1]['sha'], 'tree': tree_oid(b2)}, 'G3': {'sha': maps['ordered_parents'][1], 'tree': tree_oid(G3)}},
    'ordered_parent_proposal': maps['ordered_parents'], 'prospective_tree': tree_oid(prospective),
    'counts': {'product': 1095, 'BASE_delta': 71, 'validation': 142, 'input_domain': 1237},
    'official_compare': {'path': str(compare_path), 'bytes': len(compare_raw), 'sha256': hashlib.sha256(compare_raw).hexdigest(), 'changes': 42, 'commits': 14, 'reconstructed_full_tree_matches': True},
    'nonloss': {'all_b2_paths_retained': True, 'all_G3_artifact_paths_mode_blob_retained': True, 'incoming_b2_artifacts': incoming_artifacts, 'our_R3_artifacts': own_artifacts, 'shared_docs_identical': ['docs/BENCHMARK.md'], 'TODO_ledger_blob_unchanged': prospective['docs/roadmap/code-index-v2/tasks.json'] if 'docs/roadmap/code-index-v2/tasks.json' in prospective else None},
    'changes_from_b2': [{ 'path': p, 'before': b2.get(p), 'after': prospective[p]} for p in changed_from_b2],
    'changes_from_G3': [{ 'path': p, 'before': G3.get(p), 'after': prospective[p]} for p in changes_from_G3],
    'shared_changed_paths': overlap,
    'temporary_source_binding_choice': 'Keep the b2 registry and guard pair together byte-for-byte in the prospective product commit; these describe old b2 product/review and do NOT admit the new SQL union. After actual P and non-author R, rebind exactly the original four constants and necessary registry fields. G3 pair remains in actual G3 ancestor. No validation algorithm or CI selector changes.',
    'current_G3_engineering': 'not_run in source review; independent PR188 CI remains exact G3 and does not become combined-source execution',
    'source_review_required': 'new actual P complete 1095 / BASE delta 71 / validation 142; original b2 workflow byte change must be included',
    'measurements': 'No old cohort re-label; no study dispatch; original full-study acceptance remains separate from this engineering plan.'
}
save('nonloss-integration-plan.json', summary)
print(json.dumps({'actual_new_P': None, 'tree': tree_oid(prospective), 'request_elements': len(req['tree']), 'counts': summary['counts'], 'b2_complete_tree_reconstructed': True, 'preserved_b2_artifacts': len(incoming_artifacts), 'preserved_R3_artifacts': len(own_artifacts)}, sort_keys=True))
