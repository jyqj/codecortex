"""Verify only exact reproducible expanded bytes; no cleanup or measurement."""
import datetime, hashlib, json, pathlib, stat, zipfile
base = pathlib.Path('/dev/shm/a217aaae3bde/runtime-review/e-a23-artifact-review')
archive = pathlib.Path('/workspace/scratch/a217aaae3bde/ci-artifacts/11591607348/11591607348.zip')
root = base / 'actual-originals/11591607348/extracted'
out = base / 'lifecycle-11591607348-derived-cleanup-candidate.json'
inventory_path = base / 'lifecycle-11591607348-derived-cleanup-files.json'
assert not out.exists() and not inventory_path.exists()
def sha(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()
def ref(path):
    path = pathlib.Path(path)
    return dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path))
before_zip = ref(archive)
assert before_zip['sha256'] == '63aadf94879ea86782e9759828e853c1a030d70014fdc3fbdc127a18ca2eb055'
actual_files, actual_dirs = set(), set()
for p in root.rglob('*'):
    assert not p.is_symlink()
    if p.is_dir(): actual_dirs.add(str(p.relative_to(root)))
    else:
        assert p.is_file()
        actual_files.add(str(p.relative_to(root)))
items = []
with zipfile.ZipFile(archive) as z:
    expected_files = {m.filename for m in z.infolist() if not m.is_dir()}
    expected_dirs = set()
    for name in expected_files:
        expected_dirs.update(str(p) for p in pathlib.PurePosixPath(name).parents if str(p) != '.')
    assert actual_files == expected_files and actual_dirs == expected_dirs
    for name in sorted(expected_files):
        member = z.getinfo(name)
        p = root / name
        before = p.stat()
        assert before.st_size == member.file_size and stat.S_IMODE(before.st_mode) == 0o444
        digest = hashlib.sha256();size = 0
        with z.open(name) as original, p.open('rb') as derived:
            for block in iter(lambda: original.read(1048576), b''):
                assert derived.read(len(block)) == block
                digest.update(block);size += len(block)
            assert derived.read(1) == b''
        after = p.stat()
        assert (before.st_size,before.st_ino,before.st_mtime_ns,before.st_ctime_ns) == (after.st_size,after.st_ino,after.st_mtime_ns,after.st_ctime_ns)
        assert size == member.file_size
        items.append(dict(path=name,bytes=size,sha256=digest.hexdigest(),mode='0444',device=after.st_dev,inode=after.st_ino,nlink=after.st_nlink,mtime_ns=after.st_mtime_ns,ctime_ns=after.st_ctime_ns,allocated_bytes=after.st_blocks*512))
assert ref(archive) == before_zip
inventory_path.write_text(json.dumps(items,sort_keys=True,indent=2)+'\n')
review = base / 'accepted/lifecycle-11591607348-a23bb72d-independent'
record = dict(schema_version=1,checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='exact_single_derived_extraction_eligible_for_parent_cleanup',candidate_directory=str(root),file_count=len(items),directory_count=len(actual_dirs),logical_bytes=sum(x['bytes'] for x in items),possible_allocated_release_bytes=sum(x['allocated_bytes'] for x in items if x['nlink']==1),every_member_streamed_byte_identical_to_original_zip=True,no_extra_files_or_directories=True,no_symlinks=True,inventory=ref(inventory_path),original_zip=before_zip,original_metadata=ref(archive.parent/'artifact-metadata.json'),path_alias=ref(base/'lifecycle-11591607348-path-alias.json'),preserved_review=ref(review/'independent-review.json'),preserved_replay_report=ref(review/'relocated-report.json'),preserved_process_receipt=ref(base/'lifecycle-11591607348-review-process.json'),preserved_frozen_helper_manifest=ref(base/'frozen-helper-manifest.json'),preserve_all_siblings_and_review_files=True,deletion_performed=False,no_active_writer_basis='Original review process session2371 completed with actual exit0; original retained Rust replay subprocess completed exit0. Runtime owner has no current/future reader/writer dependency on this extraction. Source ZIP and all acceptance reports remain preserved; no system-wide PID assertion.',required_parent_action='Recheck exact file set, sizes and hashes against inventory and the immutable original ZIP. Delete only candidate_directory after no other owner dependency is confirmed. Do not delete ZIP alias, metadata, any review/replay report, frozen source or helper.',native_measurement_or_acceptance_rerun=False,formal_task_completion=False,done=163,remaining=29)
out.write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(receipt=ref(out),files=len(items),possible_allocated_release_bytes=record['possible_allocated_release_bytes'])))
