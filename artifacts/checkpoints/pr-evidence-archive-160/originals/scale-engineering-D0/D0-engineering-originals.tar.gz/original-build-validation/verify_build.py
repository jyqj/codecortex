#!/usr/bin/env python3
import hashlib, json, os, pathlib, stat, sys, zipfile, zlib

OUT=pathlib.Path('/dev/shm/p8-D0-build-independent-review')
ROOT=pathlib.Path('/workspace/scratch/2eaa00d0f93a/p8-D0-exact-source')
RECEIVED=pathlib.Path('/workspace/scratch/2eaa00d0f93a/p8-D0-build-11582571291')
ZIP=RECEIVED/'original.zip'
SOURCE='d0cb69c601e530dcef738af0c2dffb8d3b8bcf28'
EXPECTED='42d0c06359eaf0f0dd68e7683d491c662778cd64e9a621a2b501da1ed7f68d92'
assert len(ZIP.read_bytes())==9214914 and hashlib.sha256(ZIP.read_bytes()).hexdigest()==EXPECTED
build=RECEIVED/'original'; build.mkdir(exist_ok=False)
members={}
with zipfile.ZipFile(ZIP) as z:
    assert len(z.infolist())==6
    for i in z.infolist():
        assert i.filename not in members and pathlib.PurePosixPath(i.filename).name==i.filename
        assert stat.S_ISREG(i.external_attr>>16)
        body=z.read(i)
        assert len(body)==i.file_size and zlib.crc32(body)&0xffffffff==i.CRC
        with (build/i.filename).open('xb') as f:f.write(body)
        members[i.filename]={'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'crc32':i.CRC,'zip_mode':i.external_attr>>16}
sys.path.insert(0,str(ROOT/'scripts'))
import p8_scale_matrix as original
before=original.source_snapshot(ROOT); driver_before=original.driver_snapshot(ROOT)
assert before['source_commit']==SOURCE
(build/'p8-scale').chmod(0o755)
built,binary=original.validate_build(build,ROOT)
assert built['source_commit']==SOURCE and built['binary_sha256']==members['p8-scale']['sha256']
after=original.source_snapshot(ROOT);driver_after=original.driver_snapshot(ROOT)
assert before==after and driver_before==driver_after
assert original.inventory(build)=={k:{'bytes':v['bytes'],'sha256':v['sha256']} for k,v in members.items()}
assert hashlib.sha256(ZIP.read_bytes()).hexdigest()==EXPECTED
report={'schema':'p8-D0-original-build-independent-reception-v1','source_commit':SOURCE,
 'source_root':str(ROOT),'artifact_id':11582571291,'zip_path':str(ZIP),'zip_bytes':9214914,'zip_sha256':EXPECTED,
 'original_bundle':str(build),'members':members,'expanded_bytes':sum(v['bytes'] for v in members.values()),
 'original_validate_build_passed':True,'original_Cargo_copy_source_release_and_identity_checks_unmodified':True,
 'native_calls_scope':'Original validate_build invokes only native_digest(binary,binary): p8-scale --hash-file p8-scale',
 'binary_sha256':built['binary_sha256'],'binary_blake3':built['binary_blake3'],'build_receipt_sha256':members['build.json']['sha256'],
 'source_manifest_sha256':before['manifest_sha256'],'driver_source':driver_before,'source_and_driver_before_after_equal':True,
 'binary_mode_change':'Only freshly extracted owned p8-scale set0755; all ZIP member bytes remain original',
 'files_unchanged_after_validation':True,'workload_executed':False,'cargo_executed':False,
 'diagnostics_and_formal_study':'not_accepted_or_executed_here','TODO_closed':0,'TODO_remaining':29}
for name,body in [('source-before',before),('source-after',after),('driver-before',driver_before),('driver-after',driver_after),('review',report)]:
    (OUT/(name+'.json')).write_bytes(original.json_bytes(body))
print(json.dumps({'status':'accepted_scoped_original_D0_release_build','binary_sha256':built['binary_sha256'],'binary_blake3':built['binary_blake3'],'review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest()}))
