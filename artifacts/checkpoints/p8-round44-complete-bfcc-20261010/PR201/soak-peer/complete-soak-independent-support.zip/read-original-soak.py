"""Parse retained log and official terminal responses; no Actions or product execution."""
import collections,datetime,hashlib,json,re
from pathlib import Path
ROOT=Path('/workspace/scratch/bfccb8494ba0');OUT=Path(__file__).resolve().parent
G='f97c5068d056969705e8387ba1f37d83847f5bee';TREE='39a053ae49b486764751a570d164e7cd41d7ff29'
LP=ROOT/'round44-PR201-final-CI/114135223703-original-soak.log'
OP=ROOT/'round44-PR201-final-CI/0601-official-originals.json'
def ident(p,b):return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git_blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
def save(n,j):
 with (OUT/n).open('x') as f:f.write(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
raw=LP.read_bytes();identity=ident(LP,raw)
assert identity['bytes']==289033 and identity['sha256']=='04def35a76d107effa9776068ba3ec93dbf6db7e5b36e6c0bdec2b812fa41a7a'
assert identity['git_blob']=='51da3c3ac69c19bd4915666d81a9597eb58753ce'
lines=raw.decode('utf-8-sig').splitlines();body=[re.sub(r'^\S+Z ','',line) for line in lines]
def object_at(first,last):return json.loads('\n'.join(body[first-1:last]))
build=object_at(864,871);summary=object_at(888,2427);verify=json.loads(body[2438])
assert body[191]==G and f'git checkout --progress --force {G}' in body[107]
assert build['build_exit_code']==0
assert summary['status']=='passed_observation' and summary['exit_code']==0 and summary['task_complete'] is False
assert summary['profile']=='soak' and summary['offered']==3601 and summary['outcomes']=={'success':3601} and summary['failures']==[]
assert summary['observed_work_ns']>=3600*10**9
assert summary['statistics']['exit_code']==0 and summary['statistics']['replay_identical'] is True
assert summary['parity_exit_code']==0 and summary['artifact_seal_status']=='sealed'
assert summary['resource_time_coverage']['passed'] is True and summary['rss']['passed'] is True
assert summary['cache_reuse']['passed'] is True and summary['cache_reuse']['temporal_cache_coverage'] is True
assert summary['cache_reuse']['errors']==[]
assert sum(q['reads'] for q in summary['cache_reuse']['time_quarters'])==summary['cache_reuse']['validated_reads']==2400
assert summary['owned_cleanup']['unfinished_work']==0 and summary['owned_cleanup']['product_stopped'] is True
assert summary['semantic_backfill']=='not_run_in_default_product_profile' and summary['release_approval'] is False
fv=summary['final_build_verification'];source=fv['source'];observer=fv['observer']
assert source['source_commit']==observer['source_commit']==G and source['source_tree']==TREE
assert source['input_count']==len(source['inputs'])==1096 and len(observer['files'])==10
assert set(fv['artifacts'])=={'codecortex','p8-oracle','p8-runtime-statistics'}
for name,a in fv['artifacts'].items():
 ca=a['cargo_artifact'];assert ca['reason']=='compiler-artifact' and ca['target']['name']==name
 assert ca['profile']['opt_level']=='3' and ca['profile']['debug_assertions'] is False and ca['fresh'] is False
 assert ca['features']==[]
assert fv['artifacts']['codecortex']['binary_sha256']==build['binary_sha256']==summary['product_sha256']
assert fv['artifacts']['p8-oracle']['binary_sha256']==build['oracle_sha256']==summary['oracle_sha256']
assert fv['artifacts']['p8-runtime-statistics']['binary_sha256']==build['statistics_sha256']
tests=[{'line':i+1,'original':b} for i,b in enumerate(body) if re.match(r'^test_.* \.\.\. ok$',b)]
assert len(tests)==77 and body[849]=='Ran 77 tests in 17.728s' and body[851]=='OK'
assert verify=={'status':'sealed_artifacts_verified','files':2111,'observation_status':'passed_observation','observation_exit_code':0}
assert 'With the provided path, there will be 2131 files uploaded' in body[2460]
assert 'Artifact ID 11661147993' in body[2475] and 'Final size is 51028840 bytes' in body[2476]
assert '7649f77bac03768b44698150e32f343ce6ffdcb2228d9a6ff343e75ec81f291c' in body[2473]
assert not any('##[error]' in b for b in body)
warnings=[{'line':i+1,'original':b} for i,b in enumerate(body) if '##[warning]' in b or 'DeprecationWarning:' in b]
ob=OP.read_bytes();official=json.loads(ob)
parsed={url:json.loads(result['value']['structuredContent']['content']) for url,result in zip(official['urls'],official['results'])}
assert all(result['status']=='fulfilled' and not result['value'].get('isError',False) for result in official['results'])
runtime=next(v for u,v in parsed.items() if '/runs/38025451807/jobs?' in u)
job=next(j for j in runtime['jobs'] if j['id']==114135223703)
assert job['head_sha']==G and job['status']=='completed' and job['conclusion']=='success'
assert all(s['conclusion']=='success' for s in job['steps'])
checks=next(v['check_runs'] for u,v in parsed.items() if '/check-runs?' in u)
runs={38025451919,38025451862,38025451825,38025451807,38025451979,38025451790,38025451863}
ordinary=[c for c in checks if any('/runs/'+str(r)+'/' in c['details_url'] for r in runs)]
assert len(ordinary)==26 and all(c['head_sha']==G and c['status']=='completed' and c['conclusion']=='success' for c in ordinary)
pr=next(v for u,v in parsed.items() if u.endswith('/pulls/201'))
main=next(v for u,v in parsed.items() if u.endswith('/git/ref/heads/main'))
assert pr['head']['sha']==G and pr['base']['sha']==main['object']['sha']=='b9b089bb4eae072affe9326681d4980eae15fd84'
assert pr['mergeable'] is True and pr['state']=='open'
newjobs=next(v['jobs'] for u,v in parsed.items() if '/runs/38026411200/jobs?' in u)
measure=[j for j in newjobs if j['name'].startswith('measure (')]
assert len(measure)==45 and sum(j['conclusion']=='success' for j in measure)==37
assert sum(j['status']=='in_progress' for j in measure)==8
oldpeer=ROOT/'round44-next10-independent-review/independent-new-ten-review.final.json'
oldpeerraw=oldpeer.read_bytes();old=json.loads(oldpeerraw)
jobsbyid={j['id']:j for j in newjobs}
bridge=[]
for c in old['cells']:
 current=jobsbyid[c['producer_at_0557']['id']]
 assert current['head_sha']==G and current['status']=='completed' and current['conclusion']=='success'
 bridge.append({'slot':c['slot'],'job_id':current['id'],'prior_snapshot':c['producer_at_0557'],
                'current_status':current['status'],'current_conclusion':current['conclusion'],'completed_at':current['completed_at']})
producerbridge={'schema':'new10-producer-terminal-append-only-v1','source':G,'run_id':38026411200,'attempt':1,
 'prior_independent_report':ident(oldpeer,oldpeerraw),'prior_actual_git':'371478d1693fa502036266b2a772fba3b6449860',
 'current_snapshot':ident(OP,ob),'observed_start':official['started'],'observed_end':official['ended'],
 'all37_measure_producers_success':True,'build_success':True,'remaining_measure_running':8,'new10_terminal_bridge':bridge,
 'new_native_validations':0,'new_raw_ZIP_ELF_reads':0,'new_sample_acceptance':0,'cumulative_accepted_cells':37,'cumulative_accepted_records':69,
 'boundary':'Appends producer tail success only. Original05:57 nine success/one running report and original peer bytes remain unchanged.'}
save('new10-producer-completion-0601-bridge.json',producerbridge)
save('original-log-summary-and-controls.json',{'log_identity':identity,'build_lines':[864,871],'build_original':build,
 'workload_lines':[888,2427],'workload_summary_original':summary,'negative_controls':tests,
 'retained_verification_line':2439,'retained_verification_original':verify,'warnings':warnings})
evidence={'snapshot_identity':ident(OP,ob),'started':official['started'],'ended':official['ended'],
 'ordinary26_original_checks':ordinary,'soak_original_job':job,
 'PR_source':{'head':pr['head']['sha'],'base':pr['base']['sha'],'draft':pr['draft'],'mergeable':pr['mergeable'],'state':pr['state']},
 'main_original_ref':main,'projection_boundary':'Exact ordinary26 check objects and soak job retained here; root original file retains full97 checks, full study jobs and fullPR response.'}
save('selected-official-engineering-terminal-evidence.json',evidence)
report={'schema':'PR201-final-soak-independent-original-log-review-v1','reviewer':'/root/pr_triage',
 'source':G,'source_tree':TREE,'runtime_run_id':38025451807,'job_id':114135223703,
 'conclusion':'engineering_merge_eligible_at_fixed_head_and_observed_base','original_log':identity,
 'read_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_binding':{'checkout':'Direct G2 checkout; not testmerge for this soak job','checkout_lines':[108,189,191,192],
                   'source':{k:v for k,v in source.items() if k!='inputs'},'observer':observer,
                   'final_build_receipt_sha256':fv['receipt_sha256'],'build_seal_sha256':fv['build_seal_sha256'],
                   'artifacts':fv['artifacts'],'verification_scope':fv['verification_scope']},
 'negative_controls':{'command':"python3 -m unittest discover -s scripts/tests -p 'test_p8_runtime*.py' -v",'passed':77,'seconds':17.728,'result':'OK',
 'boundary':'Original runtime receipt/retention/cache/build/seal failure controls. Not77 workload samples and not all workspace Rust tests.'},
 'workload':{k:v for k,v in summary.items() if k!='final_build_verification'},
 'duration_seconds_derived':summary['observed_work_ns']/1e9,
 'API_workload_step':next(s for s in job['steps'] if s['number']==7),
 'API_verify_step':next(s for s in job['steps'] if s['number']==8),
 'API_upload_step':next(s for s in job['steps'] if s['number']==9),
 'retained_verification':verify,
 'upload':{'artifact_id':11661147993,'name':'p8-soak-'+G,'bytes':51028840,
           'sha256':'7649f77bac03768b44698150e32f343ce6ffdcb2228d9a6ff343e75ec81f291c','upload_file_count':2131,
           'verified_seal_file_count':2111,'count_boundary':'2111 retained runtime seal entries; upload2131 includes the separately retained build folder. These are different scopes.'},
 'ordinary_CI':{'observed_start':official['started'],'observed_end':official['ended'],'original_workflow_runs':sorted(runs),
                'ordinary_total':26,'success':26,'failure':0,'pending':0,'total_head_checks_including_nonordinary':len(checks),
                'unrelated_manual_skips_or_running_studies_are_not_ordinary_success_credit':True},
 'already_accepted_main_and_closeout':{'main_job':114135224079,'main_original_git':'b42f2f685f4f2caaaa0497db6706399d9f89d998',
 'main_peer_git':'a1c7594462f7d33ea7ebcb8998a46d0e3163086a','closeout_job':114135223961,'closeout_original_git':'703de5825d10906a0fb8e19e9f28f971357955a7',
 'source_v15_and_task_plan':'Original successful commands inherited from accepted main review; not rerun or recounted here.',
 'new_methods':'Six unique new nonignored methods passed in default workspace and eval-http,12 observations, not12 unique methods.'},
 'warnings':warnings,
 'limits':['The one-hour log supports observed runtime semantics; it explicitly has task_complete:false,release_approval:false and semantic_backfill:not_run_in_default_product_profile.',
 'Actual maxconcurrency1 and read_build_overlap:false are retained despite command concurrency4; not a mixed-C4 throughput claim.',
 '3601 offered operation outcomes,2400 compoundreads and their componentRPCs have different denominators. Never add componentRPCs as latency samples.',
 'Observed RSS samples and time coverage are reported; CPUquota unobserved, no process-tree peak or stable-tail claim.',
 'Original parity_exit_code0 and SHA are proven in log. This peer did not fetch artifact or independently open/recompute parity.json table rows.',
 'Artifact bytes/ID/digest are proven by original upload log; no independent ZIP/ELF/CRC verification performed or required anew for the engineering merge.',
 'New45 descriptive study is37/45 accepted cells69/85records with8running, no terminalaggregate; this does not block engineering merge or grantTODOcompletion.',
 'OldG750 fmt failure remains preserved; this success belongs only to fixedG2f97c.',
 'Root remains owner of freshlease/Ready/normalmerge; no refs, PR mutations or product executions by this review.'],
 'missing_engineering_merge_evidence':[],'additional_full_artifact_download_required_for_engineering_merge':False,
 'task_changes':0,'reader_product_validator_ELF_CRC_or_Actions_calls':0}
save('independent-soak-engineering-merge-review.json',report)
print(json.dumps({'conclusion':report['conclusion'],'ordinary_success':26,'negative_controls':77,'work_seconds':report['duration_seconds_derived'],
 'offered':3601,'retained_verified':2111,'upload_files':2131,'source':G,'missing_engineering_evidence':[]}))
