# CodeCortex benchmark baseline

Suite: `gin-v19-candidate-compat-dev`
Adapter: `mcp-stdio`
Scoring: `OceCompat`
Measurement profile: `quality`

Status: **gate_failed** (exit 1)

Queries: 55; measured rows: 165.
Mean Top-1: 0.800000; mean nDCG@10: 0.814703.

These are baseline observations, not a release quality certificate.
Latency: Distribution { samples: 0, p50_us: None, p95_us: None, max_us: None, tail_claim: "insufficient_for_tail_claim" }; samples are retained, not best-of.
Source evidence: 0 invalid, 0 unverified hits.

| Case | Top-1 | nDCG@10 | Repetitions |
|---|---:|---:|---:|
| v19.gin.f0003.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0005.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0008.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0012.en01 | 1.000000 | 0.638788 | 3 |
| v19.gin.f0013.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0015.en01 | 1.000000 | 0.760188 | 3 |
| v19.gin.f0021.en01 | 0.000000 | 0.000000 | 3 |
| v19.gin.f0022.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0023.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0026.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0027.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0029.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0032.en01 | 1.000000 | 0.923885 | 3 |
| v19.gin.f0033.en01 | 1.000000 | 0.638788 | 3 |
| v19.gin.f0034.en01 | 1.000000 | 0.638788 | 3 |
| v19.gin.f0035.en01 | 1.000000 | 0.760188 | 3 |
| v19.gin.f0036.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0037.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0042.en01 | 0.000000 | 0.630930 | 3 |
| v19.gin.f0044.en01 | 0.000000 | 0.000000 | 3 |
| v19.gin.f0045.en01 | 0.000000 | 0.000000 | 3 |
| v19.gin.f0046.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0047.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0048.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0050.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0053.en01 | 1.000000 | 0.722424 | 3 |
| v19.gin.f0054.en01 | 1.000000 | 0.722424 | 3 |
| v19.gin.f0056.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0057.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0062.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0063.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0064.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0066.en01 | 0.000000 | 0.630930 | 3 |
| v19.gin.f0067.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0068.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0069.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0071.en01 | 0.000000 | 0.630930 | 3 |
| v19.gin.f0072.en01 | 1.000000 | 0.840303 | 3 |
| v19.gin.f0073.en01 | 1.000000 | 0.638788 | 3 |
| v19.gin.f0074.en01 | 1.000000 | 0.760188 | 3 |
| v19.gin.f0075.en01 | 1.000000 | 0.760188 | 3 |
| v19.gin.f0076.en01 | 0.000000 | 0.630930 | 3 |
| v19.gin.f0077.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0081.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0082.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0083.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0085.en01 | 0.000000 | 0.630930 | 3 |
| v19.gin.f0086.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0087.en01 | 0.000000 | 0.430677 | 3 |
| v19.gin.f0089.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0090.en01 | 0.000000 | 0.000000 | 3 |
| v19.gin.f0093.en01 | 0.000000 | 0.619906 | 3 |
| v19.gin.f0095.en01 | 1.000000 | 0.798485 | 3 |
| v19.gin.f0096.en01 | 1.000000 | 1.000000 | 3 |
| v19.gin.f0097.en01 | 1.000000 | 1.000000 | 3 |

## Failures

- v19.gin.f0085.en01 Partial
- v19.gin.f0087.en01 Partial
- v19.gin.f0047.en01 Partial
- v19.gin.f0095.en01 Partial
- v19.gin.f0072.en01 Partial
- v19.gin.f0050.en01 Partial
- v19.gin.f0056.en01 Partial
- v19.gin.f0012.en01 Partial
- v19.gin.f0008.en01 Partial
- v19.gin.f0053.en01 Partial
- v19.gin.f0015.en01 Partial
- v19.gin.f0029.en01 Partial
- v19.gin.f0057.en01 Partial
- v19.gin.f0034.en01 Partial
- v19.gin.f0048.en01 Partial
- v19.gin.f0045.en01 Partial
- v19.gin.f0063.en01 Partial
- v19.gin.f0090.en01 Partial
- v19.gin.f0044.en01 Partial
- v19.gin.f0069.en01 Partial
- v19.gin.f0093.en01 Partial
- v19.gin.f0027.en01 Partial
- v19.gin.f0089.en01 Partial
- v19.gin.f0075.en01 Partial
- v19.gin.f0066.en01 Partial
- v19.gin.f0042.en01 Partial
- v19.gin.f0097.en01 Partial
- v19.gin.f0083.en01 Partial
- v19.gin.f0062.en01 Partial
- v19.gin.f0081.en01 Partial
- v19.gin.f0035.en01 Partial
- v19.gin.f0046.en01 Partial
- v19.gin.f0074.en01 Partial
- v19.gin.f0032.en01 Partial
- v19.gin.f0054.en01 Partial
- v19.gin.f0068.en01 Partial
- v19.gin.f0005.en01 Partial
- v19.gin.f0067.en01 Partial
- v19.gin.f0086.en01 Partial
- v19.gin.f0096.en01 Partial
- v19.gin.f0003.en01 Partial
- v19.gin.f0021.en01 Partial
- v19.gin.f0036.en01 Partial
- v19.gin.f0076.en01 Partial
- v19.gin.f0064.en01 Partial
- v19.gin.f0026.en01 Partial
- v19.gin.f0033.en01 Partial
- v19.gin.f0022.en01 Partial
- v19.gin.f0077.en01 Partial
- v19.gin.f0071.en01 Partial
- v19.gin.f0037.en01 Partial
- v19.gin.f0082.en01 Partial
- v19.gin.f0073.en01 Partial
- v19.gin.f0013.en01 Partial
- v19.gin.f0023.en01 Partial
- v19.gin.f0082.en01 Partial
- v19.gin.f0045.en01 Partial
- v19.gin.f0093.en01 Partial
- v19.gin.f0057.en01 Partial
- v19.gin.f0069.en01 Partial
- v19.gin.f0013.en01 Partial
- v19.gin.f0071.en01 Partial
- v19.gin.f0068.en01 Partial
- v19.gin.f0046.en01 Partial
- v19.gin.f0076.en01 Partial
- v19.gin.f0047.en01 Partial
- v19.gin.f0074.en01 Partial
- v19.gin.f0015.en01 Partial
- v19.gin.f0033.en01 Partial
- v19.gin.f0086.en01 Partial
- v19.gin.f0062.en01 Partial
- v19.gin.f0035.en01 Partial
- v19.gin.f0026.en01 Partial
- v19.gin.f0027.en01 Partial
- v19.gin.f0073.en01 Partial
- v19.gin.f0048.en01 Partial
- v19.gin.f0023.en01 Partial
- v19.gin.f0054.en01 Partial
- v19.gin.f0081.en01 Partial
- v19.gin.f0003.en01 Partial
- v19.gin.f0067.en01 Partial
- v19.gin.f0097.en01 Partial
- v19.gin.f0075.en01 Partial
- v19.gin.f0096.en01 Partial
- v19.gin.f0090.en01 Partial
- v19.gin.f0083.en01 Partial
- v19.gin.f0053.en01 Partial
- v19.gin.f0032.en01 Partial
- v19.gin.f0021.en01 Partial
- v19.gin.f0005.en01 Partial
- v19.gin.f0037.en01 Partial
- v19.gin.f0085.en01 Partial
- v19.gin.f0077.en01 Partial
- v19.gin.f0034.en01 Partial
- v19.gin.f0066.en01 Partial
- v19.gin.f0036.en01 Partial
- v19.gin.f0029.en01 Partial
- v19.gin.f0064.en01 Partial
- v19.gin.f0012.en01 Partial
- v19.gin.f0022.en01 Partial
- v19.gin.f0042.en01 Partial
- v19.gin.f0063.en01 Partial
- v19.gin.f0044.en01 Partial
- v19.gin.f0095.en01 Partial
- v19.gin.f0072.en01 Partial
- v19.gin.f0050.en01 Partial
- v19.gin.f0056.en01 Partial
- v19.gin.f0087.en01 Partial
- v19.gin.f0008.en01 Partial
- v19.gin.f0089.en01 Partial
- v19.gin.f0027.en01 Partial
- v19.gin.f0026.en01 Partial
- v19.gin.f0076.en01 Partial
- v19.gin.f0089.en01 Partial
- v19.gin.f0015.en01 Partial
- v19.gin.f0067.en01 Partial
- v19.gin.f0081.en01 Partial
- v19.gin.f0082.en01 Partial
- v19.gin.f0032.en01 Partial
- v19.gin.f0005.en01 Partial
- v19.gin.f0047.en01 Partial
- v19.gin.f0036.en01 Partial
- v19.gin.f0096.en01 Partial
- v19.gin.f0034.en01 Partial
- v19.gin.f0064.en01 Partial
- v19.gin.f0069.en01 Partial
- v19.gin.f0068.en01 Partial
- v19.gin.f0083.en01 Partial
- v19.gin.f0048.en01 Partial
- v19.gin.f0022.en01 Partial
- v19.gin.f0029.en01 Partial
- v19.gin.f0013.en01 Partial
- v19.gin.f0072.en01 Partial
- v19.gin.f0075.en01 Partial
- v19.gin.f0062.en01 Partial
- v19.gin.f0023.en01 Partial
- v19.gin.f0053.en01 Partial
- v19.gin.f0071.en01 Partial
- v19.gin.f0090.en01 Partial
- v19.gin.f0086.en01 Partial
- v19.gin.f0085.en01 Partial
- v19.gin.f0066.en01 Partial
- v19.gin.f0003.en01 Partial
- v19.gin.f0046.en01 Partial
- v19.gin.f0012.en01 Partial
- v19.gin.f0093.en01 Partial
- v19.gin.f0095.en01 Partial
- v19.gin.f0050.en01 Partial
- v19.gin.f0037.en01 Partial
- v19.gin.f0044.en01 Partial
- v19.gin.f0077.en01 Partial
- v19.gin.f0042.en01 Partial
- v19.gin.f0056.en01 Partial
- v19.gin.f0008.en01 Partial
- v19.gin.f0074.en01 Partial
- v19.gin.f0057.en01 Partial
- v19.gin.f0097.en01 Partial
- v19.gin.f0063.en01 Partial
- v19.gin.f0087.en01 Partial
- v19.gin.f0054.en01 Partial
- v19.gin.f0045.en01 Partial
- v19.gin.f0073.en01 Partial
- v19.gin.f0035.en01 Partial
- v19.gin.f0033.en01 Partial
- v19.gin.f0021.en01 Partial