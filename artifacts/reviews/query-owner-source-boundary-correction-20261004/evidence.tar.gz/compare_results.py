from pathlib import Path
import json,math,hashlib
r=Path('/workspace/owner-boundary-validation');contract=json.loads((r/'control-contract.json').read_text());positive=set(contract['genuine_phrases']);negative=set(contract['code_reference_negatives'])
summary={'queries_per_variant':contract['total_queries'],'four_arm_query_api_comparisons':0,'common_hit_pair_checks':0,'bonus_changes':[],'rank_derived_metadata_changes':[],'regression':[],'code_reference_challenges':[],'scores':[],'top_k_1':[]}
def canonical(e):return dict(hits=e['raw']['machine_pack']['hits'],normalized=e['normalized'],status=e['status'],scores=e.get('scores'))
for variant in ['base','receiver','inversion']:
 arms={a:json.loads((r/f'results/{a}-{variant}/results.json').read_text()) for a in ['base','candidate','rejected','correction']}
 assert len({o['source_text'] for o in arms.values()})==1
 assert set(arms['base']['queries'])==set(contract['queries'])
 for q in arms['base']['queries']:
  for api in ['engine','mcp']:
   summary['four_arm_query_api_comparisons']+=1
   entries={a:o['queries'][q][api] for a,o in arms.items()}
   maps={a:{h['chunk_id']:h for h in e['raw']['machine_pack']['hits']} for a,e in entries.items()}
   assert all(maps['base'].keys()==m.keys() for m in maps.values()),('top-k10 identity set',variant,q,api)
   norm={a:{(h['path'],h['start_line'],h['end_line'],h['symbol_name'],h['kind']):h for h in e['normalized']} for a,e in entries.items()}
   assert all(norm['base']==v for v in norm.values()),('normalized evidence',variant,q,api)
   for before,expected in [('base',-.18),('candidate',.18),('rejected',-.18)]:
    after='correction'
    for cid in maps[before]:
     x,y=maps[before][cid],maps[after][cid];summary['common_hit_pair_checks']+=1
     for k in x:
      if k not in ['score_trace','rerank_score','reasons','metadata']:assert x[k]==y[k],(variant,q,api,cid,k)
     assert {k:v for k,v in x['metadata'].items() if k!='evidence_priority'}=={k:v for k,v in y['metadata'].items() if k!='evidence_priority'}
     if x['metadata'].get('evidence_priority')!=y['metadata'].get('evidence_priority'):
      summary['rank_derived_metadata_changes'].append(dict(variant=variant,query=q,api=api,pair=[before,after],chunk_id=cid,before=x['metadata'].get('evidence_priority'),after=y['metadata'].get('evidence_priority')))
     assert [t for t in x['score_trace'] if t[0]!='boost:symbol-exact']==[t for t in y['score_trace'] if t[0]!='boost:symbol-exact']
     assert [v for v in x['reasons'] if v!='symbol-exact']==[v for v in y['reasons'] if v!='symbol-exact']
     for h in [x,y]:assert math.isclose(sum(v for _,v in h['score_trace']),h['rerank_score'],abs_tol=1e-9)
     if x['score_trace']!=y['score_trace']:
      assert x['symbol_name']=='Beacon' and x['symbol_kind']=='class' and 'exact-target' not in x['reasons']
      assert math.isclose(y['rerank_score']-x['rerank_score'],expected,abs_tol=1e-9)
      bonus=lambda h:[v for k,v in h['score_trace'] if k=='boost:symbol-exact']
      assert (bonus(x),bonus(y))==(([],[.18]) if expected>0 else ([.18],[]))
      if before=='candidate':assert q in positive,('not a genuine phrase',q)
      if before=='rejected':assert q in negative,('unexpected behavior change',q)
      summary['bonus_changes'].append(dict(variant=variant,query=q,api=api,pair=[before,after],chunk_id=cid,delta=expected))
     else:
      assert x['rerank_score']==y['rerank_score'] and x['reasons']==y['reasons']
   if q in positive:assert canonical(entries['base'])==canonical(entries['correction']),('prose must preserve baseline',variant,q,api)
   else:assert canonical(entries['candidate'])==canonical(entries['correction']),('unsupported/identifier behavior must preserve candidate',variant,q,api)
   if q not in negative:assert canonical(entries['rejected'])==canonical(entries['correction']),('unrelated rejected-head behavior',variant,q,api)
   tops={a:e['raw']['machine_pack']['hits'][0]['symbol_name'] if e['raw']['machine_pack']['hits'] else None for a,e in entries.items()}
   if q=='Which Beacon API rather than Sink accepts state?':
    assert tops==dict(base='Beacon',candidate='Sink',rejected='Beacon',correction='Beacon')
    summary['regression'].append(dict(variant=variant,api=api,top1=tops))
   if q in ['Which Beacon API calls `rather()` `than()` with Commit?','Which Beacon API calls $rather $than with Commit?']:
    owner={a:next(h for h in m.values() if h['symbol_name']=='Beacon') for a,m in maps.items()}
    assert all(not any(k=='boost:symbol-exact' for k,v in owner[a]['score_trace']) for a in ['candidate','correction'])
    assert any(k=='boost:symbol-exact' for k,v in owner['rejected']['score_trace'])
    if variant=='inversion':assert tops['candidate']==tops['correction']=='Commit' and tops['rejected']=='Beacon'
    summary['code_reference_challenges'].append(dict(query=q,variant=variant,api=api,top1=tops,owner_scores={a:h['rerank_score'] for a,h in owner.items()}))
   if q in ['Which Beacon API changes the ready state with Commit?','Which method on Beacon changes the ready state with Commit?']:
    scores={a:e['scores'] for a,e in entries.items()};summary['scores'].append(dict(variant=variant,query=q,api=api,scores=scores))
    if variant=='receiver':assert scores['base']['top1']==0 and scores['correction']['top1']==1 and scores['correction']['mrr10']==1
    if variant=='inversion' and ' API ' in q:assert scores['base']['top1']==scores['correction']['top1']==0 and scores['correction']['mrr10']==.5
 small=lambda o:[(h['chunk_id'],h['symbol_name']) for h in o['top_k_1']['machine_pack']['hits']]
 assert arms['candidate']['top_k_1']['machine_pack']['hits']==arms['rejected']['top_k_1']['machine_pack']['hits']==arms['correction']['top_k_1']['machine_pack']['hits']
 summary['top_k_1'].append(dict(variant=variant,**{a:small(o) for a,o in arms.items()}))
summary['input_hashes']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in r.glob('results/*/results.json')}
(r/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
counts={a:sum(v['pair'][0]==a for v in summary['bonus_changes']) for a in ['base','candidate','rejected']}
print('PASS',summary['four_arm_query_api_comparisons'],'four-arm query/API comparisons;',summary['common_hit_pair_checks'],'common-hit pair checks; bonus changes',counts)
print('Exact code-reference challenges PASS:',len(summary['code_reference_challenges']))
print('Original comparative regression restored; receiver gain preserved; stronger lexical API inversion remains Top1=0.')
