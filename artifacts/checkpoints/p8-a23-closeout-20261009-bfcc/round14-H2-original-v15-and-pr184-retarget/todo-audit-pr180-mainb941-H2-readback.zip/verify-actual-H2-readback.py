import ast, copy, hashlib, json, sys
from pathlib import Path
OUT=Path(__file__).resolve().parent
EXPECTED_TREE='73b93b60865daf5d9b6b02afa8974688c64191a4'
EXPECTED_PARENTS=['399a71a4c11e7041ce9946fba4d3f72200c47155','b9412406e11422d7cf914458a8bfbbd58cf94eaa']
def digest(b): return hashlib.sha256(b).hexdigest()
def read(path):
 p=Path(path); b=p.read_bytes(); return json.loads(b), {'path':str(p),'bytes':len(b),'sha256':digest(b)}
def include_functions(path):
 m=ast.parse(Path(path).read_text())
 exec(compile(ast.Module(body=[x for x in m.body if isinstance(x,ast.FunctionDef)],type_ignores=[]),str(path),'exec'),globals())
include_functions('/dev/shm/todo-audit-pr180-merge-plan/audit-complete-trees.py')
include_functions(OUT/'audit-H2.py')
base,base_receipt=read('/workspace/scratch/bfccb8494ba0/root-round13/current-merge-trees-transfer/extracted/pr180head4652.json')
rows={r['path']:r for r in base['tree']}
request_P,request_P_receipt=read('/dev/shm/todo-audit-pr180-tree-elements/create-tree-request.json')
rows=updated(rows,request_P['tree_elements'])
assert compute_trees(list(rows.values()))['']=='9ae248f8e0c42a8a7389e26e3f44710dfb029640'
P=leafmap(list(rows.values()))
install,install_receipt=read('/dev/shm/todo-audit-pr180-generated-G-f89d5fee/prepared-R9-G2-H7-installation-map.json')
for name,key in [('R','only_added_leaves'),('G','only_changed_leaves'),('H','only_added_leaves')]:
 rows=updated(rows,install[name][key])
assert compute_trees(list(rows.values()))['']=='50fbb7abde9de3535b91beb3265cedc30ff86681'
H=leafmap(list(rows.values()))
request,request_receipt=read(OUT/'H2-create-tree-request.json')
assert request['base_tree_sha']=='50fbb7abde9de3535b91beb3265cedc30ff86681'
rows=updated(rows,request['tree_elements'])
computed=compute_trees(list(rows.values()))
assert computed['']==EXPECTED_TREE
H2=leafmap(list(rows.values()))
official,official_receipt=read(sys.argv[1])
actual_commit=official['sha']
assert len(actual_commit)==40 and actual_commit!=EXPECTED_PARENTS[0]
assert official['tree']['sha']==computed['']
assert [v['sha'] for v in official['parents']]==EXPECTED_PARENTS
inputs,inputs_receipt=read('/dev/shm/todo-audit-pr180-v15-binding-preparation/actual-P-mechanical-review-inputs.json')
assert inputs['source']=='c92eb5ac7ece70d1f62271d7e2dacac513c285b5'
inventory=inputs['actual_input_mode_blob_inventory']
assert set(inventory)==set(inputs['complete_inputs'])|set(inputs['validation_inputs'])
assert (len(inputs['complete_inputs']),len(inputs['paths']),len(inputs['validation_inputs']))==(1093,59,139)
assert all(identity(H2[p])==identity(P[p])==identity(v) for p,v in inventory.items())
R_path='artifacts/checkpoints/p8-public-api-merge-bfcc-20261009/independent-source-review.json'
Rfile=Path('/workspace/scratch/bfccb8494ba0/scale-intake-primary/round14-actual-P-independent/independent-source-review.json')
Rraw=Rfile.read_bytes();Rdata=json.loads(Rraw)
assert digest(Rraw)=='9fa93a69e2e4be49f1262ff349fcddad18967a5c8e732144292456a24751208f'
assert Rdata['source']==inputs['source']
assert Rdata['paths']==inputs['paths'] and Rdata['complete_inputs']==inputs['complete_inputs'] and Rdata['validation_inputs']==inputs['validation_inputs']
Rblob=hashlib.sha1(b'blob '+str(len(Rraw)).encode()+b'\0'+Rraw).hexdigest()
assert H2[R_path]['sha']==Rblob=='5459118ebc88091fa62e6064ab386a711500a01a'
binding_paths=['scripts/verify_reviewed_source_v15.py','scripts/reviewed-source-registry-v15.json','.github/workflows/ci.yml',R_path]
assert all(identity(H2[p])==identity(H[p]) for p in binding_paths)
protected,protected_receipt=read('/workspace/scratch/bfccb8494ba0/scale-intake-primary/H-historical-input-preparation/protected-input-whitelist.json')
assert len(protected['protected_inputs'])==236
assert protected['historical_head']=='7354db236c9d9850a75f31672697ae9eab44565e'
for r in protected['protected_inputs']:
 p=r['path'];assert H2[p]['mode']==r['mode'] and H2[p]['sha']==r['git_blob']
 assert identity(H2[p])==identity(H[p])
newmain,newmain_receipt=read(OUT/'mainb941-complete-derived-tree.json')
M=leafmap(newmain['tree'])
changed=different(H,H2)
assert changed==sorted(v['path'] for v in request['tree_elements'])
docs=[p for p in changed if p=='README.md' or p.startswith('docs/')]
added_artifacts=[p for p in changed if p.startswith('artifacts/') and p not in H]
assert len(docs)==6 and len(added_artifacts)==242 and len(changed)==248
assert all(identity(H2[p])==identity(v) for p,v in M.items() if p.startswith('artifacts/'))
assert all(identity(H2[p])==identity(v) for p,v in H.items() if p not in docs)
assert all(identity(H2[p])==identity(M[p]) for p in docs)
result={
 'scope':'Actual H2 official commit readback and complete Git object reconstruction; no new independent semantic R, original v15 execution, Rust tests, benchmark or task acceptance',
 'actual_H2':{'commit':actual_commit,'tree':official['tree']['sha'],'ordered_parents':[p['sha'] for p in official['parents']]},
 'P':inputs['source'],'R':'f89d5feec91ae611d52614b8fe217bcd7fd5cf64','G':'b2bbd5817ce00367cea52696b098c6eafe4aa0a6','H':EXPECTED_PARENTS[0],
 'full_tree_leaf_count':len(H2),'full_tree_objects_recomputed':len(computed),
 'counts':{'complete_product':1093,'BASE_delta':59,'retained_validation':139,'retained_current_historical_protected':236,'immutable_BASE_historical_catalogue':protected['catalogue_count'],'new_artifacts':242,'updated_docs':6,'removed':0},
 'all_1093_product_139_validation_mode_blobs_equal_actual_P':True,
 'all_59_review_delta_entries_equal_actual_independent_R':True,
 'all_236_protected_mode_blobs_equal_H_and_immutable_BASE_whitelist':True,
 'source_guard_registry_CI_and_canonical_R_mode_blobs_unchanged':{p:H2[p] for p in binding_paths},
 'all_H_and_new_main_artifact_mode_blobs_preserved':True,
 'input_receipts':{'actual_official_commit':official_receipt,'original_4652_tree':base_receipt,'P_tree_request':request_P_receipt,'R_G_H_assembly':install_receipt,'H2_tree_request':request_receipt,'P_complete_maps':inputs_receipt,'historical_protected_whitelist':protected_receipt,'new_main_full_tree':newmain_receipt,'canonical_R':{'path':str(Rfile),'bytes':len(Rraw),'sha256':digest(Rraw),'git_blob':Rblob}},
 'important_execution_boundary':'Actual H2 original CLI remains separately owned by root; this metadata readback does not infer it passed. Prior H or other source executions are not relabeled.',
 'P8_007_DB_lock_wait_and_Gc8_scale_gaps_unchanged':True,'TODO_changes':0,
}
b=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode()
p=OUT/'actual-H2-readback.json';p.write_bytes(b)
print(json.dumps({'path':str(p),'bytes':len(b),'sha256':digest(b),'actual_H2':actual_commit,'tree':computed[''],'counts':result['counts']}))
