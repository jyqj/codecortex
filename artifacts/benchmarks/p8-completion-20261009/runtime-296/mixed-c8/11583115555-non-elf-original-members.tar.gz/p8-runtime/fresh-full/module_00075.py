def stable_00075():
    return 75
