import pathlib,json,hashlib,datetime,zipfile
R=pathlib.Path('/workspace/scratch/bfccb8494ba0');D=R/'round42-new45-build-original-intake';S=D/'sealed';S.mkdir()
def rd(p):return json.loads(p.read_text())
def dump(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def meta(p):
 b=p.read_bytes();return {'local_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'mode':'100644'}
execution=rd(D/'original-validator-execution.json');ret=rd(D/'validation-attempt01/original-validate-build-return.json');transport=rd(D/'transport-original.json');binding=rd(D/'recovered-contract/binding.template.json');before=rd(D/'validation-attempt01/inputs-before.json');after=rd(D/'validation-attempt01/inputs-after.json');calls=rd(D/'validation-attempt01/native-hash-subprocess-original.json')
assert execution['exit_code']==0 and before==after and len(calls)==1 and calls[0]['returncode']==0
report={'schema':'original-task-build-intake-review-v1','recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'receiver':'execution_recon','authorship_boundary':'Receiver authored the task driver, not a new independent source review. This records one execution of the already reviewed unchanged original validator; pr_triage independently reviews producer log and these receipts.','verdict':'accepted_original_build_scoped','source':binding['source'],'source_tree':binding['source_tree'],'product':binding['product'],'review':binding['review'],'official_artifact':transport['official_metadata']['original_artifact'],'run_id':38026411200,'attempt':1,'build_job_id':114138076763,'workflow':'.github/workflows/p8-task-profile.yml','protocol':'p8-profile-task-descriptive-v1','stage_scope':'profile_task_descriptive_v1','original_command_and_exit':execution,'original_validator':'p8_task_profile_matrix.validate_build(directory, root=source_root)','original_validator_calls':1,'original_build_tuple':meta(D/'validation-attempt01/original-validate-build-return.json'),'build_directory':str(D/'original-build'),'source_directory':str(D/'source-exact-G2'),'source_restore':{'reason':'Prior filesystem lost; frozen contract, binding and exact Git source restored. Original missing-file observations preserved separately.','fixed_commit_fetch_exit':0,'fixed_commit_checkout_exit':0,'source_count':1096,'observer_count':11,'input_count':1107,'original_complete_source_manifest_sha256':ret['built']['source_manifest_sha256'],'observer_manifest_sha256':ret['outer']['driver_source']['manifest_sha256'],'real_git_HEAD_and_index':True,'guard_reexecution':False},'binary':{k:ret['built'][k] for k in ['binary_bytes','binary_sha256','binary_blake3']},'native_hash_utility':calls,'native_hash_trace_method':'Python profiling observes original subprocess.run return without replacing functions, modifying arguments/results, or invoking the ELF independently. Raw stdout/stderr retained.','native_utility_was_executed':True,'measurements_locally_executed':False,'compilation_locally_executed':False,'shard_validators_executed':0,'original_registry':{'bytes':meta(D/'original-build/task-registry.json')['bytes'],'sha256':ret['outer']['registration_sha256'],'exact_original_registration_predicate_passed':True,'cell_count':45,'record_count':85,'native_deadline_ms':18000000,'repetitions':1},'source_build_index_before_after_equal':True,'official_whole_zip':transport['whole_zip'],'transport':{'member_count':len(transport['members']),'uncompressed_bytes':sum(x['bytes'] for x in transport['members']),'complete_member_CRC_reads':1,'duplicate_unsafe_symlink_members':False,'original_bytes_and_modes_retained':True,'whole_zip_external_custody':'Root uniquely downloaded/materialized and independently retains whole ZIP or ordered byte chunks; this support omits original ZIP and ELF.'},'producer_release_plan_control':{'scope':'Separate producer job step; build-bundle passed does not stand in for this control.','official_metadata':'round42-new45-study/0515-build-and-publication-originals.json','original_log':meta(R/'round42-new45-study/114138076763-original-build.log'),'independent_review_owner':'pr_triage','not_locally_rerun':True},'execution_credit':{'accepted_builds_for_this_run':1,'accepted_cells':0,'accepted_records':0,'task_credit':0,'cohort_150_credit':0,'old_diagnostic_credit':0},'next_use':'Reuse complete outer/built/binary tuple and original-build directory for each new same-run shard; do not repeat validate_build.','source_scripts_unchanged':True,'external_ref_mutations':False,'new_Actions_downloads_by_receiver':0}
dump(D/'original-build-intake-review.json',report)
selected=[]
for p in sorted(D.rglob('*')):
 if not p.is_file() or S in p.parents or 'source-exact-G2' in p.parts or p.name=='p8-scale':continue
 selected.append(p)
for name in binding['observer_inputs']:selected.append(D/'source-exact-G2'/name)
for name in ['build-artifact-original-metadata.json','0515-build-and-publication-originals.json']:
 selected.append(R/'round42-new45-study'/name)
rows=[]
for p in selected:
 m=meta(p);m['archive_path']=p.relative_to(R).as_posix();rows.append(m)
selection={'schema':'selected-original-build-intake-support-v1','files':rows,'whole_zip_and_ELF_external':True,'old_study_archives_not_embedded':True,'actual_exit':0,'original_validate_build_calls':1,'accepted_cells':0}
dump(S/'archive-selection.json',selection)
with zipfile.ZipFile(S/'complete-build-intake-originals.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for m in rows:
  info=zipfile.ZipInfo(m['archive_path'],date_time=(2026,10,10,0,0,0));info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED
  z.writestr(info,pathlib.Path(m['local_path']).read_bytes())
 info=zipfile.ZipInfo('archive-selection.json',date_time=(2026,10,10,0,0,0));info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED
 z.writestr(info,(S/'archive-selection.json').read_bytes())
prefix='artifacts/checkpoints/p8-round42-complete-bfcc-20261010/fresh45/build/'
leaves=[]
for p in [D/'original-build-intake-review.json',S/'complete-build-intake-originals.zip',S/'archive-selection.json']:
 m=meta(p);m.update(repository_path=prefix+p.name,actual_created=False);leaves.append(m)
dump(S/'upload-manifest.pending.json',{'files':leaves,'support_members':len(rows)+1,'source':binding['source'],'run':38026411200,'attempt':1,'refs_updated':False})
print(json.dumps({'members':len(rows)+1,'leaves':leaves},indent=2))
