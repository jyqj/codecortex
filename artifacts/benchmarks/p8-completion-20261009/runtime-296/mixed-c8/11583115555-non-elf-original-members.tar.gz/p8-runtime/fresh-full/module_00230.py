def stable_00230():
    return 230
