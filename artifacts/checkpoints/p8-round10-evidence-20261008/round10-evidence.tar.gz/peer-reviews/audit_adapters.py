#!/usr/bin/env python3
"""Static adapter review with historical synthetic storage-only controls."""
from pathlib import Path
import ast
import copy
import hashlib
import json
import zipfile

BASE=Path('/workspace/scratch/2eaa00d0f93a')
OUT=Path(__file__).resolve().parent
def sha(b): return hashlib.sha256(b).hexdigest()
old=(BASE/'p8-formal-evidence-G/mixed/review_mixed.py').read_text()
new=(BASE/'p8-formal-evidence-G4/mixed/review_mixed.py').read_text()
assert sha(new.encode())=='e0e6002810aa7722ed070483532a7853e9971f7f45f38ea5355caf9e5920825b'
expected=old.replace("REPO=Path('/workspace/scratch/2eaa00d0f93a/codecortex-platform-replay-G')","REPO=Path('/workspace/scratch/2eaa00d0f93a/p8-G4-exact-source')").replace("G='bb9a96d71622458c39a143055360cc97f0d11d78'","G='260f596582f2d82b8d7c707b61a6b8b6a43b069f'").replace("len(data)==975288","len(data)==receipt['artifacts']['p8-runtime-statistics']['binary_bytes']")
assert expected==new
lifecycle=BASE/'p8-formal-evidence-G4/lifecycle/independent_review.py'
body=lifecycle.read_text()
assert sha(body.encode())=='3f4cd2e2cfbeb2a639caf478652c47fbc8ae60f148d7aadf653ea079746e4caf'
tree=ast.parse(body)
main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
start=next(i for i,n in enumerate(main.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='storage' for t in n.targets))
end=next(i for i,n in enumerate(main.body[start:],start) if isinstance(n,ast.Expr) and 'physical storage not double counted' in ast.unparse(n))+1
chunk=ast.Module(body=main.body[start:end],type_ignores=[])
code=compile(chunk,str(lifecycle),'exec')
prior=BASE/'p8-formal-evidence-G/lifecycle'
receipt=json.loads((prior/'files/measurement/receipt.json').read_text())
data=json.loads((prior/'files/measurement/replay-input.json').read_text())
report=json.loads((prior/'files/measurement/report.json').read_text())
events=[]
with (prior/'files/measurement/events.jsonl').open() as f:
    for line in f:
        if '"final_closed_fixture_storage"' in line:
            row=json.loads(line)
            if row['kind']=='final_closed_fixture_storage': events.append(row)
with zipfile.ZipFile(prior/'original-artifact.zip') as z: zipped={i.filename:{'bytes':i.file_size} for i in z.infolist() if not i.is_dir()}
def require(ok,message):
    if not ok: raise AssertionError(message)
def state(): return {'Path':Path,'receipt':copy.deepcopy(receipt),'data':{'disk_partitions':copy.deepcopy(data['disk_partitions'])},'report':{'disk_ledger':copy.deepcopy(report['disk_ledger'])},'by_kind':{'final_closed_fixture_storage':copy.deepcopy(events)},'zipped':copy.deepcopy(zipped),'require':require}
positive=state();exec(code,positive)
assert len(positive['storage_paths'])==90
results={'old_G_original_90_storage_objects':{'status':'passed','bytes':sum(x['bytes'] for x in positive['parts'])}}
def rejected(name,mutate):
    s=state();mutate(s)
    try: exec(code,s)
    except (AssertionError,ValueError,KeyError) as e: results[name]={'status':'rejected','reason':str(e)}
    else: raise AssertionError('negative unexpectedly accepted: '+name)
def omit(s):
    x=s['receipt']['storage'][0]['objects'].pop(0)
    s['by_kind']['final_closed_fixture_storage'][0]['objects'].pop(0)
    s['data']['disk_partitions'].pop(0)
    s['report']['disk_ledger']['total_bytes']-=x['bytes']
rejected('omit_object_from_all_accounting_but_retained_in_ZIP',omit)
rejected('extra_unaccounted_ZIP_cache_file',lambda s:s['zipped'].update({'measurement/fixtures/cold-000/.cache/hidden-extra':{'bytes':7}}))
rejected('duplicate_cold_project',lambda s:s['receipt']['storage'][1].update(project=s['receipt']['storage'][0]['project']))
rejected('actual_ZIP_size_differs',lambda s:s['zipped']['measurement/fixtures/cold-000/.codecortex/index.sqlite3'].update(bytes=1))
result={'status':'accepted_scoped_offline_adapter_preparation','mixed_sha256':sha(new.encode()),'mixed_exact_changes':['fixed G4 commit','exact G4 source directory','statistics byte count from already-verified original Cargo copy-chain'],'lifecycle_sha256':sha(body.encode()),'lifecycle_storage_control_source_commit':'bb9a96d71622458c39a143055360cc97f0d11d78','storage_controls':results,'lifecycle_preserved':['30cold/400reopen/400warm/400cache samples','1230 denominator,431sessions,1261native resource snapshots','actual closed-fixture physical objects,unique storage IDs,complete reverse ZIP membership','actual archived source_root32 files and full hash equality; existing location never overwritten and parents cannot be symlink','same original evaluator binary/input/report replay and sealed inventory before/after'],'limits':['Historical G retained synthetic fixture bytes were used only for storage accounting controls.','The full G4 receivers have not been executed by this reviewer; no G4 measurement accepted here.','No Cargo or product execution and no source changes.','Statistics replay by future receiver is offline using retained source-bound binary; not a new product measurement.'],'TODO_closed':0,'TODO_remaining':29}
(OUT/'adapter-audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':result['status'],'sha256':sha((OUT/'adapter-audit.json').read_bytes()),'controls':results}))
