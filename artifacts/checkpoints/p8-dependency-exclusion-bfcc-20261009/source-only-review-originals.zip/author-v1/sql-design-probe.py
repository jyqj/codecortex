"""Small local SQL design comparison; no Rust, native worker, or study execution."""
from pathlib import Path
import json
import re
import sqlite3

base = Path(__file__).resolve().parent
ddl = (base / 'original/crates/cc-db/src/sql/index_v1.sql').read_text()
table = re.search(r'CREATE TABLE IF NOT EXISTS resolution_dependencies \(.*?\n\);', ddl, re.S).group()
index = re.search(r'CREATE INDEX IF NOT EXISTS idx_resolution_dependency_reverse .*?;', ddl).group()
connection = sqlite3.connect(':memory:')
connection.executescript(table + '\n' + index)
connection.executemany('INSERT INTO resolution_dependencies(file_path,kind,key) VALUES(?,?,?)',
                       [(f'f{i:05d}.py', 'name_bucket', k) for i in range(5000) for k in ['shared', 'other']])
connection.commit()
connection.execute('PRAGMA query_only=ON')

def execute(sql, args):
    count = 0
    def progress():
        nonlocal count
        count += 1
        return 0
    connection.set_progress_handler(progress, 1)
    result = [r[0] for r in connection.execute(sql, args)]
    connection.set_progress_handler(None, 0)
    return result, count

results = []
for mode, excluded in [('empty', []), ('prefix', [f'f{i:05d}.py' for i in range(4800)]),
                       ('scattered', [f'f{i:05d}.py' for i in range(0, 5000, 2)]),
                       ('all', [f'f{i:05d}.py' for i in range(5000)])]:
    for keys in [['shared'], ['shared', 'other'], ['unmatched']]:
        cap = 201
        placeholders = ','.join('?' for _ in keys)
        old = f'SELECT DISTINCT file_path FROM resolution_dependencies WHERE kind=? AND key IN ({placeholders}) ORDER BY file_path LIMIT ?'
        new = f'SELECT DISTINCT file_path FROM resolution_dependencies WHERE kind=? AND key IN ({placeholders}) AND file_path NOT IN (SELECT value FROM json_each(?)) ORDER BY file_path LIMIT ?'
        before, before_work = execute(old, ['name_bucket', *keys, cap + len(set(excluded))])
        after, after_work = execute(new, ['name_bucket', *keys, json.dumps(sorted(set(excluded))), cap])
        reference = sorted(set(before) - set(excluded))[:cap]
        assert after == reference
        results.append({'excluded': mode, 'excluded_unique': len(set(excluded)), 'keys': keys,
                        'old_returned_rows': len(before), 'new_returned_rows': len(after),
                        'old_progress_vm_callbacks': before_work, 'new_progress_vm_callbacks': after_work,
                        'outputs_equal': True})
report = {'scope': 'Local SQLite SQL-only design probe using exact dependency table/index DDL; not retained Rust binary, native runtime, elapsed benchmark or task acceptance',
          'sqlite_version': sqlite3.sqlite_version, 'fixture_files': 5000, 'fixture_dependency_rows': 10000,
          'foreign_key_enforcement': False, 'query_only': connection.execute('PRAGMA query_only').fetchone()[0],
          'work_counter': 'Python SQLite progress callback at each VM instruction; not Rust StatementStatus receipt',
          'results': results}
print(json.dumps(report, indent=2))
