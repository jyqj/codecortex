import hashlib
import json
import pathlib
import zipfile

ROOT = pathlib.Path('/workspace/scratch/bfccb8494ba0')
BASE = ROOT / 'scale-intake-primary'
OUT = BASE / 'db-wait-cleanup-P-bb29-independent'
REPO = 'artifacts/checkpoints/p8-db-acquisition-cleanup-bfcc-20261009'

def identity(path):
    data = path.read_bytes()
    return {'local_path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}

def write_new(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True, ensure_ascii=False)
        f.write('\n')

entries = []
for directory, label in [(BASE / 'db-wait-cleanup-P-3ced-independent', 'P0-source'), (OUT, 'P1-source')]:
    for path in sorted(directory.rglob('*')):
        if not path.is_file() or path.name in ['independent-source-review.json', 'archive-selection.json', 'upload-manifest.json', 'package-receipt.json'] or path.suffix == '.zip':
            continue
        entries.append({**identity(path), 'archive_path': label + '/' + str(path.relative_to(directory))})
peer_dir = pathlib.Path('/dev/shm/pr-triage-round15-P1-native-peer')
peer_selection = json.loads((peer_dir / 'archive-selection.json').read_text())
for entry in peer_selection['files']:
    path = pathlib.Path(entry['local_path'])
    current = identity(path)
    for key in ['bytes', 'sha256', 'git_blob']:
        assert current[key] == entry[key]
    entries.append({**current, 'archive_path': 'native-peer/' + path.name})
entries.append({**identity(peer_dir / 'archive-selection.json'), 'archive_path': 'native-peer/archive-selection.json'})
external = [
 ('/dev/shm/pr-triage-round15-db-lock-semantics/independent-acquisition-semantics-review.json', 'donor-review/independent-acquisition-semantics-review.json'),
 ('/dev/shm/pr-triage-round15-db-lock-semantics/controls-and-four-cells-plan.json', 'donor-review/controls-and-four-cells-plan.json'),
 ('/dev/shm/pr-triage-round15-pr184-review/independent-source-retarget-review.json', 'donor-review/PR184-independent-source-retarget-review.json'),
 ('/dev/shm/todo-audit-p8007-lock-observation-review/mac-fixture-path-diagnosis/source-diagnosis.json', 'negative-history/P1-Python-path-source-diagnosis.json'),
 ('/dev/shm/todo-audit-p8007-lock-observation-review/format-v2/two-test-whitespace.patch', 'negative-history/P0-to-P1-two-test-whitespace.patch'),
]
for source, member in external:
    entries.append({**identity(pathlib.Path(source)), 'archive_path': member})
native = ROOT / 'root-round15/native-controls-transfer/native-db-observation-P0-P1-controls-round15.zip'
selection = {
 'schema_version': 1,
 'scope': 'Source/semantic/native-peer supporting originals for actual P1; pending source drafts and initial failures are retained historically. Native135-member original ZIP is referenced separately without duplicating or expanding it into this source archive.',
 'source_P1': 'bb290be2deaf4334863e09dbf47fe4ccc9625f2b',
 'file_count': len(entries), 'total_bytes': sum(e['bytes'] for e in entries), 'files': entries,
 'canonical_review_separate': identity(OUT / 'independent-source-review.json'),
 'native_original_separate': identity(native),
 'previous_review_already_published': {
    'commit': 'f89d5feec91ae611d52614b8fe217bcd7fd5cf64',
    'repository_path': 'artifacts/checkpoints/p8-public-api-merge-bfcc-20261009/independent-source-review.json',
    'bytes': 788895, 'sha256': '9fa93a69e2e4be49f1262ff349fcddad18967a5c8e732144292456a24751208f',
    'git_blob': '5459118ebc88091fa62e6064ab386a711500a01a'},
}
selection_path = OUT / 'archive-selection.json'
write_new(selection_path, selection)
zip_path = OUT / 'source-audit-and-peer-originals.zip'
with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for entry in entries:
        archive.write(entry['local_path'], entry['archive_path'])
    archive.write(selection_path, 'archive-selection.json')
with zipfile.ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(entries) + 1
    for entry in entries:
        data = archive.read(entry['archive_path'])
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
    assert archive.read('archive-selection.json') == selection_path.read_bytes()
upload_files = []
for path, name, reuse in [
    (OUT / 'independent-source-review.json', 'independent-source-review.json', False),
    (zip_path, 'source-audit-and-peer-originals.zip', False),
    (native, 'native-db-observation-P0-P1-controls-round15.zip', True),
]:
    upload_files.append({**identity(path), 'repository_path': REPO + '/' + name, 'reuse_existing_remote_git_blob': reuse})
upload = {'schema_version': 1, 'R_sole_parent': 'bb290be2deaf4334863e09dbf47fe4ccc9625f2b', 'R_base_tree': '4dbe8ee3d09701c8563f42695b483ae104da0a2a', 'protected_domain_mutations': [], 'files': upload_files, 'source_support_selection': identity(selection_path)}
write_new(OUT / 'upload-manifest.json', upload)
receipt = {'schema_version': 1, 'source_P1': selection['source_P1'], 'members': len(entries) + 1, 'all_CRC_member_sizes_SHA_and_selection_verified': True, 'source_support_ZIP': identity(zip_path), 'upload_manifest': identity(OUT / 'upload-manifest.json')}
write_new(OUT / 'package-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
