def stable_00012():
    return 12
