def stable_00251():
    return 251
