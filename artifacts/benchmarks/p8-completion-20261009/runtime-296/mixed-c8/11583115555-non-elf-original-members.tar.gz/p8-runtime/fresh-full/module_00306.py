def stable_00306():
    return 306
