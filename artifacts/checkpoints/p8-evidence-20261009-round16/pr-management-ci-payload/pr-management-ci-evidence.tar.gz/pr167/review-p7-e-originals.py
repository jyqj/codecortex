#!/usr/bin/env python3
"""Read original ZIP members and replay trace parsing; never execute products."""
import hashlib, json, re, stat, sys, tempfile, zipfile
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
sys.dont_write_bytecode = True
BASE = Path('/dev/shm/a217aaae3bde')
SOURCE = BASE / 'codecortex-combined-guard-view'
OUT = BASE / 'platform-review/pr167-execution/p7-e-originals-review'
HEAD = 'a23bb72d3c954f385b99fe81ce9189885c208557'
sys.path.insert(0, str(SOURCE / 'scripts'))
from p7_build_identity import source_snapshot
import p7_offline_trace as trace

def check(ok, text):
    if not ok: raise AssertionError(text)

def digest_bytes(data): return hashlib.sha256(data).hexdigest()
def file_hash(path):
    with path.open('rb') as f:
        h = hashlib.sha256()
        for block in iter(lambda: f.read(1024 * 1024), b''): h.update(block)
    return h.hexdigest()

snapshot = source_snapshot(SOURCE)
check(snapshot['source_commit'] == HEAD and snapshot['input_count'] == 1087, 'wrong frozen source')
identity = {k:v for k,v in snapshot.items() if k != 'inputs'}
OUT.mkdir(parents=True, exist_ok=True)
reviews = []
for aid in (11591249346, 11592301062, 11591113592, 11591814707):
    home = Path('/workspace/scratch/a217aaae3bde/ci-artifacts') / str(aid)
    archive = home / (str(aid) + '.zip')
    metadata = json.loads((home / 'artifact-metadata.json').read_text())
    ziphash = file_hash(archive)
    check(metadata['workflow_run']['head_sha'] == HEAD and archive.stat().st_size == metadata['size_in_bytes'] and 'sha256:' + ziphash == metadata['digest'], 'original ZIP binding differs')
    with zipfile.ZipFile(archive) as zipped:
        names = zipped.namelist()
        check(len(names) == len(set(names)), 'duplicate ZIP member')
        inventory = {}
        for member in zipped.infolist():
            path = PurePosixPath(member.filename)
            check(not path.is_absolute() and '..' not in path.parts and '\\' not in member.filename and not stat.S_ISLNK(member.external_attr >> 16), 'unsafe ZIP member')
            if member.is_dir(): continue
            h = hashlib.sha256()
            with zipped.open(member) as f:
                for block in iter(lambda: f.read(1024 * 1024), b''): h.update(block)
            inventory[member.filename] = dict(bytes=member.file_size, sha256=h.hexdigest())
        read = lambda name: json.loads(zipped.read(name))
        sha = lambda name: inventory[name]['sha256']
        log_groups = []
        for name in names:
            if not name.endswith('.log') or '/reference/' in name or '/sources/' in name or '/candidate/' in name: continue
            text = zipped.read(name).decode('utf-8', 'strict')
            groups = [dict(passed=int(a), failed=int(b), ignored=int(c)) for a,b,c in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)]
            check('test result: FAILED.' not in text, 'failed original Rust regression: ' + name)
            if groups:
                log_groups.append(dict(path=name, sha256=sha(name), groups=groups, ignored_lines=re.findall(r'^test .*\.\.\. ignored.*$', text, re.M)))
        details = {}
        if aid == 11591249346:
            source = read('p7-019-build/reference-inventory.json')
            check(source == snapshot['inputs'], 'mechanism reference differs from E')
            check(read('p7-019-build/source-binding.json')['source_commit'] == HEAD, 'mechanism source label differs')
            for name, expected in source.items(): check(sha('p7-019-build/reference/' + name) == expected, 'archived mechanism reference byte differs')
            build = read('p7-019-build/mechanism-build.json')
            check(build['source_commit'] == HEAD and len(build['variants']) == 4 and len(build['controls']) == 2, 'mechanism variants differ')
            variants = []
            for variant in build['variants']:
                label = variant['id']
                receipt = read('p7-019-build/builds/' + label + '/receipt.json')
                check(receipt['exit_code'] == 0 and receipt['build_options']['binding']['source_commit'] == HEAD, 'mechanism build failed/source differs')
                expected = dict(source)
                for control in build['controls']:
                    body = zipped.read('p7-019-build/reference/' + control['path']).decode()
                    check(body.count(control['on_text']) == 1, 'mechanism control does not select unique source')
                    if control['id'] not in variant['enabled']:
                        body = body.replace(control['on_text'], control['off_text'], 1)
                    expected[control['path']] = digest_bytes(body.encode())
                check(receipt['source_files'] == expected, 'mechanism has source delta outside declared two controls')
                for name, wanted in expected.items(): check(sha('p7-019-build/sources/' + label + '/' + name) == wanted, 'archived mechanism variant differs')
                check(sha('p7-019-build/products/' + label) == receipt['binary_sha256'], 'mechanism binary differs')
                witness = zipped.read('p7-019-evidence/run/' + label + '/lane-execution.jsonl').splitlines()
                queries = zipped.read('p7-019-evidence/run/' + label + '/profile-queries.jsonl').splitlines()
                check(len(witness) == len(queries) == 9, 'mechanism original request/witness coverage differs')
                variants.append(dict(cell=label, source_inputs=len(expected), source_delta=[k for k in expected if expected[k] != source[k]], binary_sha256=receipt['binary_sha256'], actual_lane_witnesses=9, requests_including_warmup=9))
            acceptance = read('p7-019-evidence/acceptance.json')
            check(acceptance['passed'] is True and acceptance['source_commit'] == HEAD and acceptance['all_36_requests_preserved'] is True, 'mechanism acceptance failed')
            check(all(acceptance[k] is True for k in ('actual_hybrid_mislabel_rejected','aliased_binary_rejected','aliased_source_rejected','misattributed_source_commit_rejected','paired_bootstrap_replayed','same_locked_inputs_and_effective_budgets')), 'mechanism existing controls missing')
            check('1 passed; 0 failed; 0 ignored;' in zipped.read('p7-019-runner/actual-mechanism.log').decode(), 'actual mechanism test did not run')
            details = dict(kind='original_four_lane_fake_mechanism_regression', variants=variants, acceptance=acceptance, original_ignored_stdio_single_test_not_claimed_passed=True)
        elif aid == 11592301062:
            check(read('source-before.json') == read('source-after.json') == snapshot, 'P7 closeout source changed')
            build = read('http-build-receipt.json')
            check(build['source_before'] == build['source_after'] == snapshot and build['build_exit_code'] == 0, 'HTTP build source/exit differs')
            check(sha('http-codecortex') == build['binary_sha256'] and sha('http-product-build.jsonl') == build['cargo_log_sha256'], 'HTTP original Cargo/binary differs')
            cargo = [json.loads(x) for x in zipped.read('http-product-build.jsonl').splitlines() if x.strip()]
            check(sum(x == build['cargo_artifact'] for x in cargo) == 1 and cargo[-1] == {'reason':'build-finished','success':True}, 'HTTP Cargo producer missing')
            check(sorted(build['cargo_artifact']['features']) == ['semantic','semantic-http'], 'HTTP feature package differs')
            summary = read('fault-lifecycle/summary.json')
            check(summary['passed'] is True and summary['complete_declared_matrix'] is True and summary['declared_seeds'] == summary['executed_seeds'] == [197,199,211], 'fault seeds incomplete')
            check(summary['binary_sha256'] == build['binary_sha256'] and summary['script_sha256'] == file_hash(SOURCE / 'scripts/p7_fault_lifecycle_stdio.py'), 'fault driver/product differs')
            events = [json.loads(x) for x in zipped.read('fault-lifecycle/events.jsonl').splitlines()]
            seeds = []
            for seed in (197,199,211):
                result = read(f'fault-lifecycle/seed-{seed}/result.json')
                check(result in summary['results'] and result['passed'] is True and result['paid_cost'] is None and result['manual_database_or_clock_changes'] is False and result['observed_sigkill_count'] == 1, 'fault original seed differs')
                sessions = []
                for process in result['exits']:
                    name = process['session']
                    check(process['exit_code'] == (-9 if process['requested_sigkill'] else 0) and process['cleanup'] is False and process['stdout_reader_joined'] is True and process['stdout_errors'] == [], 'fault process incomplete')
                    for stream in ('stdout','stderr'): check(sha('fault-lifecycle/' + name + '.' + stream + '.log') == process[stream + '_sha256'], 'fault stream changed')
                    wire = [json.loads(x) for x in zipped.read('fault-lifecycle/' + name + '.stdout.log').decode('utf-8','strict').splitlines()]
                    responses = [x['response'] for x in events if x['kind'] == 'mcp_response' and x['session'] == name]
                    check(wire == responses and len({x['id'] for x in responses}) == len(responses), 'fault raw stdout differs/duplicate response')
                    sessions.append(dict(session=name, exit_code=process['exit_code'], responses=len(responses)))
                check(len(sessions) == 4, 'fault missing sessions')
                seeds.append(dict(seed=seed, sessions=sessions, observed_document_posts=result['observed_document_posts'], observed_sigkill_count=1, paid_cost=None, phases=[x['phase'] for x in result['checkpoints']]))
            lifecycle = read('lifecycle/summary.json')
            check(lifecycle['passed'] is True and lifecycle['binary_sha256'] == build['binary_sha256'], 'original lifecycle matrix failed')
            details = dict(kind='existing_P7_closeout_regressions', source_verified_inputs=1087, http_product_sha256=build['binary_sha256'], actual_fault_seeds=seeds, original_lifecycle_case_names=[x['case'] for x in lifecycle['cases']])
        else:
            package = 'semantic' if aid == 11591113592 else 'default'
            build = read('product/build-receipt.json')
            check(build['source_before'] == build['source_after'] == identity and read('product/source-inputs.json') == snapshot['inputs'], 'offline source differs')
            check(build['build_exit_code'] == 0 and sha('product/codecortex') == build['binary_sha256'] and build['package_kind'] == package, 'offline product differs')
            messages = [json.loads(x) for x in zipped.read('product/cargo-build.jsonl').splitlines() if x.strip()]
            check(sum(x == build['cargo_artifact'] for x in messages) == 1 and messages[-1] == {'reason':'build-finished','success':True}, 'offline original Cargo product missing')
            check(build['cargo_artifact']['features'] == ([] if package == 'default' else ['semantic']), 'offline feature package differs')
            runner = read('runner-identity.json')
            check(runner['source_before'] == runner['source_after'] == identity and read('runner-source-inputs.json') == snapshot['inputs'], 'offline runner source differs')
            runner_messages = [json.loads(x) for x in zipped.read('runner-build.jsonl').splitlines() if x.strip()]
            check(sum(x == runner['cargo_artifact'] for x in runner_messages) == 1 and runner_messages[-1] == {'reason':'build-finished','success':True}, 'offline runner original Cargo missing')
            report = read('trace-matrix/verification.json')
            check(report['source'] == identity and report['status'] == 'passed' and report['violations'] == [] and report['network_socket_attempts'] == 0, 'offline trace report failed')
            check(report['product_sha256'] == build['binary_sha256'] and report['build_receipt_sha256'] == sha('product/build-receipt.json') and report['runner_receipt_sha256'] == sha('runner-identity.json') and report['runner_sha256'] == runner['sha256'], 'offline trace/binary binding differs')
            check(report['guard_sha256'] == file_hash(SOURCE / 'scripts/p7_offline_network.py') and report['verifier_sha256'] == file_hash(SOURCE / 'scripts/p7_offline_trace.py'), 'offline loaded observer differs')
            observation_name = 'trace-matrix/observations/p7-017-' + package + '.json'
            check(sha(observation_name) == report['observations_sha256'], 'offline observations differ')
            observations = read(observation_name)
            check(observations['build_receipt'] == build, 'offline observations used another receipt')
            with tempfile.TemporaryDirectory(prefix='p7-trace-read-', dir=OUT) as temporary:
                temporary = Path(temporary)
                for name, expected in report['trace_run']['raw_files'].items():
                    member = 'trace-matrix/trace/' + name
                    check(sha(member) == expected and Path(name).name == name, 'offline raw trace mismatch')
                    (temporary / name).write_bytes(zipped.read(member))
                traces = trace.read_traces(temporary / 'syscalls', require_timestamps=True)
                # The original CLI serializes integer PID mapping keys to JSON strings.
                repeated = json.loads(json.dumps(trace.verify_product_observations(observations, traces, build['binary_sha256'])))
                check(all(report[k] == v for k,v in repeated.items()), 'offline actual trace replay differs')
            details = dict(kind='existing_P7_offline_product_regression', package=package, source_verified_inputs=1087, independent_raw_trace_replay=True, product_trees=len(report['product_trees']), positive_controls=len(report['positive_controls_outside_product_trees']), network_socket_attempts=0, raw_trace_files=len(report['trace_run']['raw_files']), product_sha256=build['binary_sha256'], source_commit=HEAD)
        inventory_path = OUT / (str(aid) + '-original-member-inventory.json')
        inventory_path.write_text(json.dumps(inventory, sort_keys=True, indent=2) + '\n')
        reviews.append(dict(artifact_id=aid, name=metadata['name'], zip_sha256=ziphash, zip_bytes=archive.stat().st_size, original_members_rehashed=len(inventory), original_uncompressed_bytes=sum(x['bytes'] for x in inventory.values()), inventory_path=str(inventory_path), inventory_sha256=file_hash(inventory_path), original_rust_log_groups=log_groups, details=details))
    check(file_hash(archive) == ziphash, 'original ZIP changed')

result = dict(schema_version=1, reviewer='pr_audit', created_at_utc=datetime.now(timezone.utc).isoformat(), assessment='accepted_scoped_original_P7_regression_artifacts', source_commit=HEAD, artifacts=reviews, unresolved_blockers_in_reviewed_scope=[], task_completion_certified=False, limits=['All original ZIP members were streamed and hashed without extracting entire products or changing originals.', 'Only trace interpretation was replayed; product builds and executions were not rerun.', 'Rust groups overlap and are not added into a unique global test total. Ignored tests remain explicitly ignored and are not counted as passed.', 'The dedicated four-lane actual mechanism test is distinct from the legacy ignored single stdio mechanism test; no silent substitution or relabelling.', 'Controlled provider and fake semantic cases do not certify live provider quality or billing.', 'Original P8 hard dependencies, scale/runtime/lifecycle actual acceptance and final CI remain separate.'])
path = OUT / 'independent-review.json'
path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(assessment=result['assessment'], path=str(path), artifacts=len(reviews), source_commit=HEAD)))
