def stable_00396():
    return 396
