#!/usr/bin/env python3
"""Mechanically verify one candidate against the actual CI rustfmt output.

This script does not run rustfmt, Rust, a source-admission CLI, or a workload.
"""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
PATH = 'crates/cc-db/tests/p2b_resolution_store.rs'
LOG = Path('/dev/shm/pr-triage-round18-G3-C3ff-observation/failed-check-113861171381.decoded.log')
TOKENIZER = Path('/dev/shm/todo-audit-H-dependency-exclusion-v3/verify-and-freeze-formatting.py')

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def record(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': digest(raw), 'git_blob': blob(raw)}

def write(name, value):
    with (ROOT/name).open('x') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, sort_keys=True)
        stream.write('\n')

before = (ROOT/'original'/PATH).read_bytes()
after = (ROOT/'candidate'/PATH).read_bytes()
raw_log = LOG.read_bytes()
assert digest(raw_log) == '1189bd605ebf6e967502fe98b65fb3b112c451485659668217168fd2a2680fcc'
assert blob(before) == '265e2b7ae7660c7dbd07e2f8d8c26efe8206ff7c'
assert digest(before) == '6a97ff39428569cebc6bbeaf61bf069fe472ac8653111225e551b4956871203f'

# Extract actual formatter hunks from retained original decoded log. Timestamps
# and diff prefix columns are transport/display syntax, not source bytes.
hunks = []
active = None
for line in raw_log.decode('utf-8-sig').splitlines():
    match = re.match(r'^\S+Z (.*)$', line)
    if not match:
        continue
    payload = match.group(1)
    if payload.startswith('Diff in '):
        assert '/'+PATH+':' in payload
        active = {'header': payload, 'old': [], 'new': []}
        hunks.append(active)
    elif active is not None and payload[:1] in [' ', '+', '-']:
        prefix, content = payload[0], payload[1:]+'\n'
        if prefix in [' ', '-']:
            active['old'].append(content)
        if prefix in [' ', '+']:
            active['new'].append(content)
    else:
        active = None
assert len(hunks) == 3
reconstructed = before.decode()
for hunk in hunks:
    old, new = ''.join(hunk['old']), ''.join(hunk['new'])
    assert reconstructed.count(old) == 1, hunk['header']
    reconstructed = reconstructed.replace(old, new, 1)
assert reconstructed.encode() == after

# Load only the pure tokenizer definition, not the author's executable main.
module = ast.parse(TOKENIZER.read_text())
definition = next(x for x in module.body if isinstance(x, ast.FunctionDef) and x.name == 'tokens')
namespace = {'re': re}
exec(compile(ast.Module(body=[definition], type_ignores=[]), str(TOKENIZER), 'exec'), namespace)
a = namespace['tokens'](before.decode())
b = namespace['tokens'](after.decode())
at = [row['token'] for row in a]
bt = [row['token'] for row in b]
changes = []
for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(a=at, b=bt, autojunk=False).get_opcodes():
    if tag == 'equal':
        continue
    assert tag == 'insert' and i1 == i2 and j2 == j1+1
    token = bt[j1]
    assert token in ['{', '}', ',']
    changes.append({'old_token_position': i1, 'new_token_position': j1, 'new_line': b[j1]['line'], 'token': token, 'before_context': bt[max(0,j1-6):j1], 'after_context': bt[j1+1:j1+7]})
assert [row['token'] for row in changes] == ['{', '}', ',', ',']
left, right = changes[:2]
assert bt[left['new_token_position']-3:left['new_token_position']] == ['|', 'row', '|']
assert bt[left['new_token_position']+1:right['new_token_position']] == ['row', '.', 'get', '::', '<', '_', ',', 'String', '>', '(', '0', ')']
assert bt[right['new_token_position']+1] == ')'
assert bt[changes[2]['new_token_position']-1] == '"😀.py"'
assert bt[changes[2]['new_token_position']+1] == ']'
assert bt[changes[3]['new_token_position']-4:changes[3]['new_token_position']] == ['map', '(', 'unit', ')']
assert bt[changes[3]['new_token_position']+1] == ')'
normalized = bt.copy()
for row in reversed(changes):
    del normalized[row['new_token_position']]
assert normalized == at

patch = 'diff --git a/'+PATH+' b/'+PATH+'\nindex '+blob(before)+'..'+blob(after)+' 100644\n'
patch += ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile='a/'+PATH, tofile='b/'+PATH))
with (ROOT/'source.patch').open('xb') as stream:
    stream.write(patch.encode())

report = {
    'schema': 'PR188-original-rustfmt-output-minimal-fix-v4',
    'author': '/root/execution_recon',
    'actual_parent_source': '67b7f4ee15a9c9633868b446870fec1358dda3d9',
    'actual_parent_tree': 'e7a7f5a685c44aee34b8716377308f0af8782fdd',
    'actual_failed_checkout': '645cbe3e04a8efe97a2063e2f65b0c637edbe526',
    'actual_failed_command': 'cargo fmt --all -- --check',
    'actual_failed_command_exit': 1,
    'actual_failure_toolchain': 'stable rustc 1.99.0',
    'failed_job': 113861171381,
    'candidate_commit': None,
    'source_scope': 'one test file; three exact original formatter hunks',
    'before': record(ROOT/'original'/PATH),
    'after': record(ROOT/'candidate'/PATH),
    'exact_original_formatter_hunks': [{k:v for k,v in h.items() if k == 'header'} for h in hunks],
    'candidate_bytes_exactly_reconstructed_from_original_formatter_output': True,
    'all_prior_tokens_including_literals_and_comments_retained_in_order': True,
    'only_nonwhitespace_token_insertions': changes,
    'semantic_boundary': 'The added braces wrap the same single closure tail expression with no semicolon or extra statement. The two commas are optional trailing commas in a multi-element array and an ordinary function argument list. No production expression, SQL, fixture value, assertion, loop, budget, or source-validation logic changed.',
    'normalized_token_sha256': digest(json.dumps(at, ensure_ascii=False, separators=(',', ':')).encode()),
    'normalization_is_not_a_parser_or_compiler_claim': True,
    'production_file_unchanged': True,
    'counts_unchanged': {'product': 1095, 'historical_delta': 70, 'validation': 142},
    'source_binding_followup': 'A new actual product commit and independent R/G bindings are required before moving the PR; current G3 pins are not retargeted in this candidate.',
    'candidate_rustfmt_execution': 'not_run',
    'candidate_Rust_Clippy_tests_source_admission': 'not_run',
    'old_CI_failure_retained': True,
    'old_Python_sparse_SQL_regression_22_57_percent_retained': True,
    'TODO_credit': 0,
    'inputs': [record(LOG), record(TOKENIZER)],
    'patch': record(ROOT/'source.patch'),
}
write('format-output-equivalence-and-impact.json', report)
write('one-path-source-manifest.json', {'actual_parent': report['actual_parent_source'], 'actual_parent_tree': report['actual_parent_tree'], 'candidate_commit': None, 'files': [{'path': PATH, 'mode': '100644', 'type': 'blob', 'before_git_blob': blob(before), 'after_git_blob': blob(after), 'bytes': len(after), 'sha256': digest(after), 'local_path': str(ROOT/'candidate'/PATH)}], 'protected_validation_unchanged': True, 'production_unchanged': True, 'runtime_execution': 'not_run'})
print(json.dumps({'candidate': report['after'], 'patch': report['patch'], 'exact_formatter_hunks': 3, 'nonwhitespace_insertions': ['{','}',',',','], 'runtime': 'not_run'}, sort_keys=True))
