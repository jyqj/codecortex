def stable_00176():
    return 176
