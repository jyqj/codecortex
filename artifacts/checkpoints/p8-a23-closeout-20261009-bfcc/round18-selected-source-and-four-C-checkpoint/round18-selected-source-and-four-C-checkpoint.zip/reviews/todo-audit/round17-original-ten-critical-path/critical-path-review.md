原十项的直接阻塞目前分两条：完整规模与增量验收（P8-005/006），以及原四并发范围的实际 DB 获取等待记录（P8-007）。其余七项已有独立接受的组件，尚不能越过硬依赖改为 done。当前仍是 163 done、29 remaining。

| 原任务 | 硬依赖 | 已有组件 | 真正剩余原门 / 可独立动作 |
|---|---|---|---|
| P8-005 | P8-004 已 done | fixed-e3 三个 local 子门已关闭；Gc8 4 个成功分片、41 样本保留 | 完整五容量固定 seed/release 证据与相关回归；Gc8 100k deadline、aggregate failure，不能计完整。先验证 P3f 工程正确性；既有完整独立研究若存在，可按它自己的源审查。 |
| P8-006 | P7-020、P8-001 已 done；P8-005 open | 既有完整 oracle 控制和局部样本 | 完整 no-op/body/API/config/batch/fanout、闭包终态与 full parity。同一合格规模研究可同时覆盖 005/006，不要求为了 006 再复制整套研究。 |
| P8-007 | P8-006 open | Gc8 四 C 的 read/build、offered/queue/service/timeout，以及独立 fake-backfill 组件；G1 C1/C4 新测量终态已由 owner 报告成功 | 核收 C1/C4 原件；原 §9 要求的 C8/C16 实际 DB wait 记录仍缺。不能从两格外推另外两格；但没有“必须使用某 Mac controller/新增 workflow/四个一小时”的原门。 |
| P8-008 | P8-007 open | Gc8 lifecycle 1230 样本、431 sessions 已独审 | 依赖未闭合；复用有真实分层、N、分布、CI 的原组件，不改为新源测量。 |
| P8-009 | P8-008 open | 原 mixed/lifecycle/backfill/soak 的资源、磁盘与费用归属已独审 | 依赖未闭合；保留单位、reported/estimated 与真实 unavailable，不新增“未知峰值必须补成数值”的门。 |
| P8-010 | P8-009 open | Gc8 原一小时、3601 operations、cache/RSS/stdio 与完整 oracle 已独审 | 依赖未闭合；不因新增锁观察而要求重新做四个一小时 soak。 |
| P8-011 | P7-020 已 done；P8-007/010 open | Gc8 故障/恢复原件已审；当前台账另有 G275 独立组件 | 依赖未闭合；引用实际版本/故障范围，不能重标为 P3f 执行。 |
| P8-012 | P8-011 open | Gc8 完整八格全新 target 与原 collector 已审；G275 另有独立八格 | 依赖未闭合；普通新 Linux CI 不冒充新源八格。旧八格保留自己的 source/平台身份。 |
| P8-013 | P8-012 open | 原六 Rust 合同及七 CLI 非零退出/保留报告控制已审 | 依赖未闭合；fixture 的门控正确性不冒充实际质量/性能通过。 |
| P8-016 | P7-020 已 done；P8-012/013 open | 实际 277f/schema24 与当前 schema25、缓存隔离及恢复备份已审 | 依赖未闭合；保留真实历史 binary 身份，不追加不存在的 release-tag 要求。 |

N 与分片数必须分层解释：

- `tasks.json` 的 P8-005 原文写五容量、固定 seed、release、chunk/edge/vector 和相关回归，没有直接写 N30、150 个分片或 1500 个样本。`full_1k_5k_10k_50k_100k_scale_acceptance=open` 也没有自行给出这些数字。
- P8-008 原文是“无 best-of，sample N/分布/CI 齐全”。`09-BENCHMARK.md` §9 L173 写“起始建议每层至少 30 个重复”，并把正式尾延迟 profile 的至少 200 个同类样本另列，末句说明这些是可在 P0 资源评估后锁定的设计下限。当前没有已验证的另一份更低 N 锁定方案，不能临时把不足当通过。
- 当前已有 `P8-SCALE.md` L29 的 release 驱动明确要求至少 30 次；L149–156 将五容量的九主阶段与五个独立 fanout 定义为 50 组×30=1500。九主阶段是 005 冷建和 006 增量/fanout 的共享研究内容，不能将其全部伪引为 P8-005 单条文字。
- `scale_capacity_v1` 的 L212–222、L261–281 明确每规模 30 片、首五片加后 145 片。150 是这套已启动研究的固定分片身份，不是原任务要求每一种合法执行方式都必须开 150 个 GitHub job。已开始 cohort 的源、二进制、N、阶段、预算与失败记录不能改变，也不能跨源补位。

不同任务组件可以在一个证据总表中并列引用，并各自保留 source、binary、features、platform、run 及声明范围；没有读到“台账提交必须等于所有性能原件 SHA”的条文。这个原则不允许把 Gc8 的平台/恢复/性能改标为 P3f，也不自动认定任意代码变更仍被旧执行覆盖。要声称某一新候选已认证，仍须解释实际相关输入和行为的适用性，并有真实整合回归。`06-VALIDATION.md` L61 对完整 gate 的当前 run-id 要求及 G8 的全量 release 范围保留；十项任务的源码限定闭环不等于最新主线全 G8 发行认证。

此报告只读核对已有原件与台账语义。当前 main ledger 输入是 root 从已核 Git blob `959a25ba851ff88f286bab0fa14167878129b1dd` 解析后重新序列化的副本，不能把它的本地字节摘要冒充原 Git blob 字节。十项的状态、依赖、步骤、acceptance 与 acceptance_subgates 对照 Gc8 全部未变，仅 evidence/implementation_notes 增补。未执行新的测试、测量、workflow 或远端写操作。
