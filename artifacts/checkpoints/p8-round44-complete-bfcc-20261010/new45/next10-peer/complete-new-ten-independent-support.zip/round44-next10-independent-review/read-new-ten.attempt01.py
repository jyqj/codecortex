"""Read new ten original results only; no ZIP/CRC/ELF/validator/product execution."""
import collections
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = Path(__file__).resolve().parent
IN = ROOT / 'round44-next10-original-intake'
BUILD = ROOT / 'round42-new45-build-original-intake'
G = 'f97c5068d056969705e8387ba1f37d83847f5bee'
RUN = 38026411200
ids = {}

def read(path):
    raw = path.read_bytes()
    ids[str(path)] = dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                         git_blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest())
    return raw

def load(path):
    return json.loads(read(path))

def dump(name, value):
    with (OUT/name).open('x') as f:
        f.write(json.dumps(value, indent=2, ensure_ascii=False)+'\n')

t = load(IN/'terminal.json')
registry = load(BUILD/'original-build/task-registry.json')
bt = load(BUILD/'validation-attempt01/original-validate-build-return.json')
assert (t['source'], t['run_id'], t['attempt']) == (G, RUN, 1)
assert (t['accepted_cells'], t['failed_cells'], t['accepted_records']) == (10, 0, 15)
assert t['validate_build_calls'] == t['compile_or_measurement_calls'] == t['old_slots_reexecuted'] == 0
assert t['stdio_custody_complete'] is True
assert load(IN/'shared-source-build-before.json') == load(IN/'shared-source-build-after.json')
expected = {('batch_1000', s, 0) for s in (1000,5000,10000,50000)} | {('batch_100',50000,0)} | {('fanout',n,0) for n in (1,4,16,64,128)}
assert {tuple(row['slot']) for row in t['records']} == expected
prior_paths = [ROOT/'round42-new45-first12-independent-review/independent-first12-review.json',
               ROOT/'round43-next6-independent-review/independent-new-six-review.json',
               ROOT/'round43-next9-independent-review/independent-new-nine-review.final.json']
prior = [load(p) for p in prior_paths]
oldslots = {tuple(c['slot']) for p in prior for c in p['cells']}
assert len(oldslots) == 27 and oldslots.isdisjoint(expected)
assert all(p['source'] == G and p['run_id'] == RUN and p['registry_sha256'] == bt['outer']['registration_sha256'] for p in prior)
official_path = ROOT/'round44-new45-study/0557-new45-jobs-and-full-artifacts.original.json'
official = load(official_path)
jobs_original = official['jobs_original']
jobs = json.loads(jobs_original['structuredContent']['content'])['jobs']
dump('producer-jobs-0557.original.json', jobs_original)
TABLES = {'document_manifest','resolution_frontier','semantic_edges','dispatch_sites','resolution_manifests','resolution_dependencies','public_surfaces','files','symbols','imports','symbol_refs','call_edges','chunks','test_edges','routes'}
cells = []
selected = []
for item in t['records']:
    profile, scale, rep = item['slot']
    fanout = profile == 'fanout'
    d = IN/f'{profile}-{scale}-{rep}'
    sd = d/'original-shard'
    nd = sd/'native-shard/native'
    ret = load(d/'original-validate-shard-return.json')
    ex = load(d/'original-validator-execution.json')
    assert ex['exit_code'] == 0 and ex['original_validate_shard_calls'] == 1
    assert ex['validate_build_calls'] == ex['measurement_or_compile_calls'] == 0
    stdout = read(d/'original-validator.stdout')
    assert stdout == read(d/'captured-stdout.frozen-original') == read(d/'original-validate-shard-return.json')
    assert len(stdout) == ex['stdout']['bytes'] and hashlib.sha256(stdout).hexdigest() == ex['stdout']['sha256']
    assert read(d/'original-validator.stderr') == read(d/'captured-stderr.frozen-original') == b''
    assert load(d/'shard-before.json') == load(d/'shard-after.json')
    sr = load(sd/'task-shard.json')
    nr = load(nd/'report.json')
    assert nr['summary'] == load(nd/'worker-summary.json')
    assert ret['plan'] == sr['plan'] and ret['plan'] in registry['plans']
    plan = ret['plan']
    assert plan['deadline_ms'] == 18000000 and plan['max_output_bytes'] == 536870912
    assert plan['dirty_budget'] == 200 and plan['max_resume_builds'] == 1024
    assert plan['profile'] == 'release' and plan['capacity_profile'] == 'scale_capacity_v1'
    assert plan['repetitions'] == 1 and plan['shard'] == {'count':1,'index':0}
    assert plan['stage_scope'] == 'profile_task_descriptive_v1' and plan['seed'] == 12648430
    assert ret['study'] == sr['study'] == registry['study']
    assert ret['driver_source'] == sr['driver_source'] == registry['driver_source'] and len(ret['driver_source']['inputs']) == 11
    assert ret['registration_sha256'] == bt['outer']['registration_sha256']
    assert ret['build_receipt_sha256'] == sr['task_build_receipt_sha256'] == prior[0]['task_build_receipt_sha256']
    assert sr['passed'] is True and sr['status'] == 'passed' and sr['task_statuses_changed'] is False
    assert sr['files']['native-shard/source-before.json'] == sr['files']['native-shard/source-after.json']
    assert ret['engine']['engine_head_observed'] == G and ret['engine']['binary_digest'] == registry['binary_blake3']
    assert ret['engine']['eval_debug_assertions'] is False
    assert nr['status'] == 'measurement_complete' and nr['exit_code'] == nr['worker_exit_code'] == 0
    assert nr['stderr_complete'] is True and nr['worker_binary_unchanged'] is True
    assert nr['worker_binary_digest_before'] == nr['worker_binary_digest_after'] == registry['binary_blake3']
    assert nr['fixture_cleanup']['error'] is None and nr['summary']['passed'] is True
    assert nr['summary']['sample_count'] == (1 if fanout else 2)
    assert [m['group'] for m in ret['measurements']] == ([f'fanout-{scale}'] if fanout else [f'scale-{scale}/cold', f'scale-{scale}/{profile}'])
    hashes = load(d/'native-hash-subprocess-originals.json')
    assert len(hashes) == 2
    for h, key in zip(hashes, ('plan_digest','raw_digest')):
        assert h['returncode'] == 0 and '--hash-file' in h['argv'] and read(d/h['stderr']['file']) == b''
        assert read(d/h['stdout']['file']).decode().strip() == nr[key]
    events = collections.Counter()
    parities, stages, builds, fanout_events, fanout_cases = [], [], [], [], []
    with (nd/'raw.jsonl').open() as f:
        for line, text in enumerate(f, 1):
            e = json.loads(text)
            events[e.get('event')] += 1
            if e.get('event') in ('cold_parity','stage_finished'):
                p = e['parity']
                assert p['equal'] is True and p['status'] == 'equal' and p['different_tables'] == []
                assert len(p['tables']) == 15 and {v['table'] for v in p['tables']} == TABLES
                for v in p['tables']:
                    assert type(v['equal']) is bool and v['equal']
                    assert type(v['full_rows']) is int and type(v['incremental_rows']) is int and v['full_rows'] == v['incremental_rows']
                    assert isinstance(v['full_digest'],str) and v['full_digest'] == v['incremental_digest']
                    assert type(v['different_row_count']) is int and v['different_row_count'] == 0 and v['different_row_examples'] == []
                parities.append({'line':line, 'event':e['event'], 'equal_tables':15, 'original_parity':p})
                selected.append({'slot':item['slot'], 'line':line, 'path':str(nd/'raw.jsonl'), 'event':e})
                if e['event'] == 'stage_finished':
                    assert e['complete'] is True and e['full_complete'] is True and e['passed'] is True
                    stages.append({k:v for k,v in e.items() if k != 'parity'})
            elif e.get('event') == 'build_finished':
                r = e['report']
                builds.append({'line':line, 'label':e['label'], 'full':e['full'], 'resolution_freshness':r.get('resolution_freshness'),
                               'dirty_propagation':r.get('dirty_propagation'), 'dirty_plan':r.get('dirty_plan'), 'build_timing':r.get('build_timing')})
            elif e.get('event') == 'fanout_started':
                fanout_cases.append(e)
            elif e.get('event') == 'fanout_finished':
                fanout_events.append((line,e))
    if fanout:
        assert len(fanout_cases) == len(fanout_events) == 1 and not parities and not stages
        case = fanout_cases[0]['case']
        assert case['dirty_budget'] == 8 and case['max_resume_builds'] == 128
        assert set(case['initial']) == {'api.ts'} | {f'use_{i:03}.ts' for i in range(scale)}
        line,e = fanout_events[0]
        result = e['result']
        assert e['passed'] is True and result['passed'] is True and result['failure_signature'] is None
        assert e['fanout'] == scale and e['fixture_files'] == scale+1 and e['repetition'] == 0
        assert set(result['tables']) == TABLES and len(result['tables']) == 15
        initial = result['initial_evidence']
        assert initial['equal'] is True and set(initial['tables']) == TABLES and len(initial['tables']) == 15
        assert set(initial['incremental']) == set(initial['full']) == TABLES and initial['incremental'] == initial['full']
        assert len(initial['incremental']['files']) == scale+1
        assert initial['runtime_config'] == {'auto_index':{'enabled':False},'indexing':{'dirty_propagation_max_files':8,'db_read_pool_size':1}}
        assert len(result['checkpoints']) == 1
        point = result['checkpoints'][0]
        assert point['status'] == 'compared' and point['settle_required'] is True and point['different_tables'] == []
        assert set(point['incremental']) == set(point['full']) == TABLES and point['incremental'] == point['full']
        truth = [{'id':f'caller_{i}','expected':1,'actual':1,'passed':True} for i in range(scale)]
        assert point['truth'] == truth
        for i in range(scale):
            wanted = dict(file_path=f'use_{i:03}.ts',callee_symbol='scale_ping',target_file_path='api.ts')
            assert sum(all(row.get(k)==v for k,v in wanted.items()) for row in point['incremental']['call_edges']) == 1
        reports = point['reports']
        assert 1 <= len(reports) <= 129
        assert reports[-1]['resolution_freshness']['complete'] is True
        assert all(r['resolution_freshness']['complete'] is False for r in reports[:-1])
        assert all(r['build_timing']['full_staging_us'] is None for r in reports)
        assert e['incremental_builds'] == len(reports) and e['incremental_engine_elapsed_ms'] == sum(r['elapsed_ms'] for r in reports)
        incomplete = reports[0]['resolution_freshness']['complete'] is False
        assert e['first_build_incomplete'] is incomplete and ret['measurements'][0]['first_build_incomplete'] is incomplete
        assert ret['measurements'][0]['initial_evidence'] == initial
        for r in (initial['incremental_report'],initial['full_report'],point['full_report']):
            assert r['resolution_freshness']['complete'] is True and r['build_timing']['full_staging_us'] is not None
        observations = {'first_build_incomplete':incomplete, 'incremental_builds':len(reports), 'dirty_budget':8,'max_resume_builds':128,
                        'first_dirty_propagation':reports[0]['dirty_propagation'], 'first_resolution_freshness':reports[0]['resolution_freshness'],
                        'final_resolution_freshness':reports[-1]['resolution_freshness'],'truth_controls':len(truth),
                        'initial_files':len(initial['incremental']['files']), 'initial_parity_tables':15,'final_parity_tables':15,
                        'initial_row_counts':{k:len(v) for k,v in initial['incremental'].items()},
                        'final_row_counts':{k:len(v) for k,v in point['incremental'].items()},
                        'complete_fanout_original_event_sha256':hashlib.sha256(json.dumps(e,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
        selected.append({'slot':item['slot'],'line':line,'path':str(nd/'raw.jsonl'), 'derived_fanout_summary':observations,
                         'original_first_build_report':reports[0], 'original_last_build_report':reports[-1], 'original_truth':truth})
    else:
        assert len(parities) == 2 and len(stages) == 1 and not fanout_events
        incremental = [b for b in builds if not b['full']]
        assert len(incremental) == stages[0]['incremental_builds'] and incremental[-1]['resolution_freshness']['complete'] is True
        observations = {'first_build_incomplete':incremental[0]['resolution_freshness']['complete'] is False,
                        'incremental_builds':len(incremental),'parities':parities,'stage_finished':stages[0]}
    name = f'measure (fanout-{scale}, fanout, {scale})' if fanout else f'measure ({profile}-{scale}, {profile}, {scale})'
    job = next(j for j in jobs if j['name'] == name)
    assert job['head_sha'] == G
    a = item['artifact']
    assert a['workflow_run']['id'] == RUN and a['workflow_run']['head_sha'] == G
    assert a['digest'] == 'sha256:'+item['whole_zip']['sha256']
    cells.append({'slot':item['slot'],'artifact':a,'whole_zip':item['whole_zip'],
                  'return_identity':ids[str(d/'original-validate-shard-return.json')], 'execution':ex,
                  'producer_at_0557':{k:job[k] for k in ('id','name','head_sha','status','conclusion','started_at','completed_at')},
                  'plan':plan,'engine':ret['engine'],'environment':ret['environment'], 'profile_environment':ret['profile_environment'],
                  'measurement_environment':ret['measurement_environment'],'native_report':nr,'observations':observations,
                  'roles':['fanout'] if fanout else ['setup','mutation'], 'stdio_two_copies_plus_return_equal':True,
                  'raw_event_counts':dict(events)})

assert sum(c['observations']['first_build_incomplete'] for c in cells if c['slot'][0]=='fanout') >= 1
shortcells = [{'slot':c['slot'],'roles':c['roles'],'artifact_id':c['artifact']['id'],'artifact_name':c['artifact']['name'],
               'whole_zip':c['whole_zip'],'original_return':c['return_identity'],'producer_at_0557':c['producer_at_0557'],
               'native_exit':c['native_report']['exit_code'],'native_wall_ms':c['native_report']['wall_ms'],
               'incremental_builds':c['observations']['incremental_builds'],
               'first_build_incomplete':c['observations']['first_build_incomplete'],
               'final_complete':True,'parity_observations':2,'tables_per_parity':15,'cpu_model':c['environment']['cpu_model'],
               'fanout_details':c['observations'] if c['slot'][0]=='fanout' else None,
               'stdio_complete':True} for c in cells]
report = {'schema':'independent-new-ten-original-receipts-v1','reviewer':'/root/pr_triage','source':G,'run_id':RUN,'attempt':1,
          'result':'accepted_scoped_new10_original_receipts','accepted_new_cells':10,'accepted_new_records':15,
          'new_roles':{'setup':5,'mutation':5,'fanout':5},
          'cumulative':{'cells':37,'expected_cells':45,'records':69,'expected_records':85,'setup':32,'mutation':32,'fanout':5,
                        'cold_curve_selected_setup':4,'cold_curve_selected_scales':[1000,5000,10000,50000],'cold_100k':None},
          'remaining':{'cells':8,'records':16,'setup':8,'mutation':8,'fanout':0},
          'registry_sha256':bt['outer']['registration_sha256'],'binary_blake3':registry['binary_blake3'],'binary_sha256':registry['binary_sha256'],
          'observer':registry['driver_source'],'original_new_validator_calls':10,'original_new_hash_utility_calls':20,
          'peer_validator_ELF_CRC_ZIP_calls':0,'old_shard_raw_or_ZIP_reads':0,'task_credit':0,
          'new_parity_observations':20,'new_equal_table_observations':300,
          'fanout_actual_overbudget_observed':[c['slot'][1] for c in cells if c['slot'][0]=='fanout' and c['observations']['first_build_incomplete']],
          'producer_snapshot':{'source_file':str(official_path),'started':official['started'],'ended':official['ended'],
                               'new10_status_counts':dict(collections.Counter((c['producer_at_0557']['conclusion'] or c['producer_at_0557']['status']) for c in cells)),
                               'boundary':'Native accepted originals and producer tail completion remain distinct; no claim of37 successful jobs from05:57 snapshot.'},
          'receiver_immutable_manifest':'pending sealed upload-manifest at peer read time; add separately after actual publication',
          'cells':shortcells,'read_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'limitations':['N1 fresh independent cells; preserve CPU/host/cache/environment differences, no pooled tails or old study credit.',
                         'Fanout plan retains main200/1024 fields while the registered fanout fixture explicitly uses8/128; both original fields are retained.',
                         'Fanout initial and final canonical15-table snapshots are exact equal; this reader does not rerun DB comparison.',
                         'Five fanout records do not create setup or mutation records; cold no_op4 remains a subset of32 setup records.',
                         'No100k cell is supplied by this batch. Registered45/85 and original terminal aggregate remain incomplete.',
                         'Original untracked Python cache observations are retained; do not claim pristine working tree.',
                         'No product/compiler/measurement/semantic validator/ELF/CRC/ZIP operation during this peer review.',
                         'One preparatory metadata read assumed input.slot and raised KeyError before any original slot read; corrected to actual artifact/local_path schema, no product execution.']}
dump('selected-new-ten-parity-and-fanout-evidence.json',selected)
dump('detailed-new-ten-review.json',{'report':report,'cells':cells,'input_identities':list(ids.values())})
dump('independent-new-ten-review.json',report)
print(json.dumps({'result':report['result'],'accepted_cells':10,'accepted_records':15,'cumulative':[37,69],
                  'fanout_overbudget':report['fanout_actual_overbudget_observed'],'producer_snapshot':report['producer_snapshot']['new10_status_counts']}))
