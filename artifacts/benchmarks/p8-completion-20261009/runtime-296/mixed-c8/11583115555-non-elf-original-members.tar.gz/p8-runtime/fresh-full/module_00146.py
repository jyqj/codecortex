def stable_00146():
    return 146
