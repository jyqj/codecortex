def stable_00223():
    return 223
