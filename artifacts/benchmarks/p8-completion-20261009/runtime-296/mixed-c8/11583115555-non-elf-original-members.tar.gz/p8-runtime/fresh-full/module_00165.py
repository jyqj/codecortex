def stable_00165():
    return 165
