import ast,copy,difflib,hashlib,json
from pathlib import Path
OUT=Path(__file__).resolve().parent
PLAN=Path('/dev/shm/todo-audit-pr180-merge-plan')
INPUT=Path('/workspace/scratch/bfccb8494ba0/root-round13/current-merge-trees-transfer/extracted/pr180head4652.json')
module=ast.parse((PLAN/'audit-complete-trees.py').read_text())
exec(compile(ast.Module(body=[x for x in module.body if isinstance(x,ast.FunctionDef)],type_ignores=[]),str(PLAN/'audit-complete-trees.py'),'exec'))
rows=json.loads(INPUT.read_text())['tree'];base={r['path']:r for r in rows}
def updated(rows, entries):
 result=copy.deepcopy(rows)
 for item in entries:
  p=item['path'];result[p]=item
  parts=p.split('/')
  for i in range(1,len(parts)):
   d='/'.join(parts[:i]);result.setdefault(d,{'path':d,'mode':'040000','type':'tree','sha':'0'*40})
 return result
P=updated(base,json.loads(Path('/dev/shm/todo-audit-pr180-tree-elements/create-tree-request.json').read_text())['tree_elements'])
assert compute_trees(list(P.values()))['']=='9ae248f8e0c42a8a7389e26e3f44710dfb029640'
prefix='artifacts/checkpoints/p8-public-api-merge-bfcc-20261009/'
archive=json.loads((OUT/'R-tree-objects/f41ee86b03179baeafedf58e7c3dbbc685b77f2e.json').read_text())
assert archive['truncated'] is False and len(archive['tree'])==9
R9=[dict(r,path=prefix+r['path']) for r in archive['tree']]
assert all(r['type']=='blob' and r['mode']=='100644' for r in R9)
assert all(r['path'] not in P for r in R9)
R=updated(P,R9);R_tree=compute_trees(list(R.values()))['']
assert R_tree=='24081c8e62f3cb085ada800d3083d7ca4fb31521'
files=json.loads((OUT/'generated-G-file-manifest.json').read_text())['files']
G2=[{'path':r['path'],'type':r['type'],'mode':r['mode'],'sha':r['git_blob'],'size':r['bytes']} for r in files]
G=updated(R,G2);G_tree=compute_trees(list(G.values()))['']
H7=json.loads(Path('/dev/shm/todo-audit-pr180-head1d39-forward/publication-additions.json').read_text())['tree_elements']
assert len(H7)==7 and all(r['path'] not in G for r in H7)
H=updated(G,H7);H_tree=compute_trees(list(H.values()))['']
Pm,Rm,Gm,Hm=(leafmap(list(x.values())) for x in [P,R,G,H])
assert set(Pm)<=set(Rm) and all(identity(Pm[p])==identity(Rm[p]) for p in Pm)
assert different(Rm,Gm)==sorted(r['path'] for r in G2)
assert different(Gm,Hm)==sorted(r['path'] for r in H7)
E=leafmap(json.loads(Path('/dev/shm/todo-audit-pr180-head1d39-forward/head1d39-complete-derived-tree.json').read_text())['tree'])
changes_E_H=different(E,Hm)
our_new_review_paths=sorted(r['path'] for r in R9)
fix=['crates/cc-db/src/index_db_write_batch.rs','crates/cc-db/src/snapshot_write_txn.rs','crates/cc-db/tests/p2b_resolution_store.rs']
assert set(changes_E_H)==set(fix+[r['path'] for r in G2]+our_new_review_paths)
assert all(identity(Hm[p])==identity(v) for p,v in E.items() if p.startswith('artifacts/'))
def tree_request(tree,items):
 return {'repository_full_name':'jyqj/codecortex','base_tree_sha':tree,'tree_elements':[{k:r[k] for k in ['path','mode','type','sha']} for r in items]}
Grequest=write('G-create-tree-request.json',tree_request(R_tree,G2))
Hrequest=write('H-create-tree-request.json',tree_request(G_tree,H7))
old_guard=(PLAN/'180guard.raw').read_text().splitlines(keepends=True)
new_guard=(OUT/'staged/scripts/verify_reviewed_source_v15.py').read_text().splitlines(keepends=True)
(OUT/'guard-four-pin.diff').write_text(''.join(difflib.unified_diff(old_guard,new_guard,fromfile='4652/scripts/verify_reviewed_source_v15.py',tofile='generated-G/scripts/verify_reviewed_source_v15.py')))
result={
 'scope':'actual R and predicted G/H full Git object identities only; no remote mutation or original admission execution',
 'P':{'commit':'c92eb5ac7ece70d1f62271d7e2dacac513c285b5','tree':'9ae248f8e0c42a8a7389e26e3f44710dfb029640'},
 'R':{'commit':'f89d5feec91ae611d52614b8fe217bcd7fd5cf64','tree':R_tree,'sole_parent':'c92eb5ac7ece70d1f62271d7e2dacac513c285b5','only_added_leaves':R9},
 'G':{'commit':None,'predicted_tree':G_tree,'sole_parent':'f89d5feec91ae611d52614b8fe217bcd7fd5cf64','only_changed_leaves':G2,'create_tree_request':Grequest},
 'H':{'commit':None,'predicted_tree':H_tree,'ordered_parents':['1d39f382d4e08e702a55693c9c614fa477bf7e0c','ACTUAL_OUR_G'],'only_added_leaves':H7,'create_tree_request':Hrequest},
 'counts':{'product':1093,'delta':59,'validation':139,'R_additions':9,'G_changes':2,'H_additions':7},
 'all_P_README_docs_tasks_and_prior_artifacts_preserved_through_R_G_H':True,
 'all_external_1d39_artifact_mode_blobs_preserved_in_H':True,
 'compared_with_external_1d39_H_changes':changes_E_H,
 'exact_frozen_inputs_remain_equal':'Only three v2 product fixes and our selected bindings supersede external1d39; all validation/CI/currentmain files match admitted P except these planned changes.',
 'G_and_H_still_require_actual_commit_metadata_readback':True,
 'original_CI_and_v15_at_actual_final_checkout_still_required':True,
 'P8_007_DB_lock_wait_and_original_scale_task_gaps_remain':True,
}
receipt=write('prepared-R9-G2-H7-installation-map.json',result)
print(json.dumps({'report':receipt,'predicted_G_tree':G_tree,'predicted_H_tree':H_tree,'G_request':Grequest,'H_request':Hrequest},indent=2))
