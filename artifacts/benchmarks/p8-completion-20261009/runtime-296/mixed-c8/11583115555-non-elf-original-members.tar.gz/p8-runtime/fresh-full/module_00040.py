def stable_00040():
    return 40
