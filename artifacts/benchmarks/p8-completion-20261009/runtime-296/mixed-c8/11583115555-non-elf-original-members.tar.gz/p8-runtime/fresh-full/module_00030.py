def stable_00030():
    return 30
