def stable_00420():
    return 420
