#!/usr/bin/env python3
"""Offline original-G integrity review of the preregistered thirty local1k cells.

Never generates a workload or changes the original150-cell aggregate gate.
The native executable is used only by original validators for --hash-file.
Refuse before creating output until all30 cells and their sequencer terminate.
"""
import argparse
from collections import defaultdict
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

G = 'bb9a96d71622458c39a143055360cc97f0d11d78'
TREE = 'bd7f0abc21650a1656783ddb26961c212aa1f2ae'
REGISTRATION_SHA = 'a2301a5b016cdba7c5ce85e55431d0a473a451bbec831f4d8fedffed7f45d874'
PUBLICATION = 'b94a93a9d92a237e0c55a23fd8e931c5dae659f0'
WRAPPER_SHA = '08f72c7a7187dea2d94053ac45666ae11210984709b6e21b0f18d14e6f08c991'
BUILD_SHA = '414b1767f2ee3a1c94f05ef12f5f6b58fd604202cfaba66522a348f7a9627a02'
REGISTRATION_ROOT = Path('/dev/shm/p8-local-G-1k-registration-root')
ROOT = Path('/home/runner/work/codecortex/codecortex')
COHORT = Path('/workspace/scratch/2eaa00d0f93a/p8-local-G-1k-20261008')
DRIVER_HASHES = {
    'scripts/p8_scale_matrix.py': 'f169b0f26cf2a87d3e2548d734431c530cbf63d353ac054045ec8be80889f957',
    'scripts/p7_build_identity.py': '5003305105464936edf8f444fc0b93cd14a5d5f074dc650f16de2259e86f1cc5',
}
COMMON_ENGINE = ('engine_head_observed', 'source_files_digest', 'cargo_lock_digest',
                 'binary_digest', 'eval_version', 'os', 'arch', 'rustflags', 'eval_debug_assertions')
STAGES = ('cold', 'no_op', 'body', 'api', 'config', 'batch_1', 'batch_10', 'batch_100', 'batch_1000')
GROUPS = {f'scale-1000/{stage}' for stage in STAGES} | {f'fanout-{n}' for n in (1, 4, 16, 64, 128)}


def require(value, message):
    if not value:
        raise ValueError(message)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def decode(raw):
    return json.loads(raw, object_pairs_hook=unique_object,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError('nonfinite JSON: ' + value)))


def read(path):
    require(path.is_file() and not path.is_symlink(), 'missing/nonregular closed receipt: ' + str(path))
    require(path.stat().st_size <= 8 * 1024**2, 'oversized control receipt')
    return decode(path.read_bytes())


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def regular_directory(path):
    require(path.is_absolute() and path.resolve(strict=True) == path,
            'noncanonical directory: ' + str(path))
    for part in (path, *path.parents):
        require(part.is_dir() and not part.is_symlink(), 'nonregular directory ancestor: ' + str(part))


def validate_completion_records(finished, sequence, executions):
    """Pure completion gate: no binary call, output write or mutable-log hashing."""
    require(finished.get('status') == 'all_29_remaining_wrappers_exit_zero', 'sequencer is not complete')
    require(len(sequence) == 29 and [row.get('shard_index') for row in sequence] == list(range(1, 30)),
            'sequence missing/duplicate/reordered index')
    require(all(type(row.get('wrapper_exit_code')) is int and row['wrapper_exit_code'] == 0 for row in sequence),
            'a selected wrapper did not exit zero')
    require(len(executions) == 30, 'all30 terminal execution records required')
    for index, record in enumerate(executions):
        require(record.get('shard_index') == index and record.get('scale') == 1000,
                'execution index/scale mismatch')
        require(record.get('status') == 'passed_original_cell_and_validation'
                and record.get('cli_stopped_confirmed') is True
                and type(record.get('cli_exit_code')) is int and record['cli_exit_code'] == 0
                and record.get('errors') == [], 'cell is failed/incomplete/unsealed')
        require(record.get('source') == G and record.get('registration_sha256') == REGISTRATION_SHA
                and record.get('registration_publication') == PUBLICATION
                and record.get('executor_sha256') == WRAPPER_SHA
                and record.get('source_or_gate_modifications') is False,
                'execution source/origin/observer identity mismatch')


def closed_inputs():
    raw = (REGISTRATION_ROOT / 'registration.json').read_bytes()
    require(hashlib.sha256(raw).hexdigest() == REGISTRATION_SHA, 'registration changed')
    registration = decode(raw)
    publication = read(REGISTRATION_ROOT / 'publication.json')
    require(publication.get('sha') == PUBLICATION and publication.get('branch_created') is True
            and publication.get('registration_sha256') == REGISTRATION_SHA, 'publication mismatch')
    require(registration['compiled_source_root'] == str(ROOT)
            and registration['local_output_root'] == str(COHORT), 'registered paths changed')
    regular_directory(ROOT)
    regular_directory(COHORT)
    chosen = sorted((row for row in registration['primary_cells'] if row['scale'] == 1000),
                    key=lambda row: row['shard_index'])
    require(len(chosen) == 30 and [row['shard_index'] for row in chosen] == list(range(30)),
            'registration local population differs')
    for index, row in enumerate(chosen):
        require(row['primary_origin'] == 'local-G-1k-20261008'
                and row['primary_local_directory'] == str(COHORT / f'shard-1000-{index:02}'),
                'primary selected origin/path differs')
    sequence_root = COHORT / 'controls/remaining-sequence'
    finished = read(sequence_root / 'finished.json')
    sequence_path = sequence_root / 'completed.jsonl'
    require(sequence_path.is_file() and not sequence_path.is_symlink(), 'sequence log absent')
    raw_sequence = sequence_path.read_bytes()
    require(len(raw_sequence) <= 65536 and raw_sequence.endswith(b'\n'), 'sequence log incomplete')
    sequence = [decode(line) for line in raw_sequence.splitlines()]
    executions = [read(COHORT / 'controls' / f'{index:02}' / 'execution.json') for index in range(30)]
    validate_completion_records(finished, sequence, executions)
    return registration, chosen, executions


def load_original_driver():
    require(subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip() == G,
            'source HEAD changed')
    require(subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD^{tree}'], text=True).strip() == TREE,
            'source tree changed')
    for relative, digest in DRIVER_HASHES.items():
        path = ROOT / relative
        require(path.is_file() and not path.is_symlink() and sha(path) == digest, 'original observer changed')
        committed = subprocess.check_output(['git', '-C', str(ROOT), 'show', G + ':' + relative])
        require(committed == path.read_bytes(), 'observer differs from G blob')
    sys.path.insert(0, str(ROOT / 'scripts'))
    spec = importlib.util.spec_from_file_location('original_G_cohort_driver', ROOT / 'scripts/p8_scale_matrix.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_population(shards, driver):
    """Local420-sample integrity only; never relax original combine's150 cells."""
    require(len(shards) == 30, 'exactly30 selected local shards required')
    groups = defaultdict(list)
    sources, input_digests, indices = set(), set(), set()
    environments = {}
    for shard in shards:
        plan = shard['plan']
        index = plan['shard']['index']
        require(type(index) is int and index in range(30) and index not in indices, 'duplicate/unregistered local shard')
        indices.add(index)
        require(driver.exact_equal(plan, driver.registered_plan(1000, index, 30, 30, 12648430, 18000000,
                                                                driver.CAPACITY_PROFILE)), 'original plan changed')
        engine = shard['engine']
        sources.add(tuple(engine.get(key) for key in COMMON_ENGINE))
        input_digests.add(shard['input_digest'])
        environment = dict(shard['environment'])
        environment['engine_cpu_parallelism'] = engine.get('cpu_parallelism')
        driver.integer(environment['engine_cpu_parallelism'], 'engine CPU parallelism', 1)
        require(isinstance(environment.get('host'), str) and environment['host'], 'missing measured host')
        identity = hashlib.sha256(driver.json_bytes(environment)).hexdigest()
        environments[identity] = environment
        rows = shard['measurements']
        require(len(rows) == 14 and {row['group'] for row in rows} == GROUPS, 'cell does not have14 exact groups')
        for row in rows:
            expected_id = row['group'].split('/')[0] + f'/repetition-{index}'
            require(row['sample'] == expected_id, 'sample belongs to another repetition')
            groups[row['group']].append(row | {'environment_id': identity})
    require(indices == set(range(30)) and len(sources) == len(input_digests) == 1,
            'local source/engine/input population mismatch')
    require(set(groups) == GROUPS and sum(map(len, groups.values())) == 420, 'local group population mismatch')
    summaries = []
    for name, rows in sorted(groups.items()):
        prefix = name.split('/')[0]
        require(len(rows) == 30 and {row['sample'] for row in rows}
                == {f'{prefix}/repetition-{index}' for index in range(30)}, 'group has missing/duplicate sample')
        rows.sort(key=lambda row: int(row['sample'].rsplit('-', 1)[1]))
        strata = defaultdict(list)
        for row in rows:
            strata[row['environment_id']].append(row)
        summaries.append({'group': name, 'n': 30,
                          'sample_environments': [{'sample': row['sample'], 'environment_id': row['environment_id']} for row in rows],
                          'environment_strata': [{'environment_id': identity, **driver.summarize_group(name, members)}
                                                 for identity, members in sorted(strata.items())],
                          'pooled_latency_statistics': 'not_computed_heterogeneous_coverage'})
    require(any(row.get('first_build_incomplete') is True for name, rows in groups.items()
                if name.startswith('fanout-') for row in rows), 'no actual over-budget fanout observed')
    return {'registered_local_cells': 30, 'measurements': 420, 'groups': summaries,
            'environments': environments, 'common_engine_fields': dict(zip(COMMON_ENGINE, next(iter(sources)))),
            'input_digest': next(iter(input_digests)), 'missing_other_scales': [5000, 10000, 50000, 100000],
            'full150_matrix': 'not_evaluated', 'original_aggregate_gate': 'unchanged; still requires all150 cells'}


def write(path, body):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(body, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write('\n')


def run(output):
    # This completion check precedes lock/output creation/native checksum calls.
    registration, chosen, executions = closed_inputs()
    lock_path = COHORT / 'cohort.lock'
    require(lock_path.is_file() and not lock_path.is_symlink(), 'missing regular cohort lock')
    with lock_path.open('rb') as lock:
        fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        registration, chosen, executions = closed_inputs()
        driver = load_original_driver()
        source_before, observer_before = driver.source_snapshot(ROOT), driver.driver_snapshot(ROOT)
        require(output.is_absolute() and output.parent.resolve(strict=True) == output.parent
                and not output.exists() and not output.is_symlink(), 'new absolute owned output required')
        require(COHORT not in output.parents and ROOT not in output.parents,
                'review output must remain outside original source/cohort')
        output.mkdir()
        started = time.monotonic_ns()
        report = {'schema': 'p8-original-G-local1k-offline-cohort-review-v1',
                  'status': 'failed', 'passed': False, 'source': G, 'registration_sha256': REGISTRATION_SHA,
                  'registration_publication': PUBLICATION, 'reviewer_script_sha256': sha(Path(__file__)),
                  'started_utc': datetime.now(timezone.utc).isoformat(), 'cells': [],
                  'scope': 'Pure offline original validator replay; native --hash-file only, no indexing/workload/Cargo.',
                  'release_certification': 'not_run', 'full150_matrix': 'not_evaluated', 'TODO_closed': 0, 'TODO_remaining': 29}
        try:
            build = COHORT / 'original-build'
            require(sha(build / 'build.json') == BUILD_SHA == registration['original_build']['receipt_sha256'],
                    'selected original build receipt changed')
            built, binary = driver.validate_build(build, ROOT)
            original_build = Path(registration['original_build']['directory'])
            require(driver.inventory(original_build) == driver.inventory(build), 'original build/copy bytes differ')
            require(source_before == driver.read_json(build / 'source-before.json')
                    and observer_before == built['driver_source'], 'source/observer differs from original build')
            sequence_inventory = driver.inventory(COHORT / 'controls/remaining-sequence')
            shards, closed_inventories = [], {}
            for index, (cell, execution) in enumerate(zip(chosen, executions)):
                path = Path(cell['primary_local_directory'])
                regular_directory(path)
                control = COHORT / 'controls' / f'{index:02}'
                regular_directory(control)
                require(not (control / 'unsealed-execution.json').exists(), 'unsealed control exists')
                require(driver.inventory(control, ('execution.json',)) == execution['artifact_files'],
                        'outer control inventory changed')
                expected_argv_tail = ['-B', str(ROOT / 'scripts/p8_scale_matrix.py'), 'run', '--root', str(ROOT),
                                      '--build', str(build), '--scale', '1000', '--shard-index', str(index),
                                      '--shard-count', '30', '--repetitions', '30', '--seed', '12648430',
                                      '--deadline-ms', '18000000', '--capacity-profile', 'scale_capacity_v1', '--output', str(path)]
                require(execution['argv'][1:] == expected_argv_tail and Path(execution['argv'][0]).is_absolute(),
                        'original CLI args changed')
                require(execution['cell_directory'] == str(path) and execution['control_directory'] == str(control)
                        and execution['owned_execution_build'] == str(build)
                        and execution['original_build'] == str(original_build), 'outer control paths changed')
                require(execution['environment'].get('RUSTFLAGS') == '', 'original RUSTFLAGS not empty')
                process = read(control / 'process.json')
                launch = read(control / 'launch.json')
                require(process['argv'] == execution['argv'] == launch['argv']
                        and process['pid'] == execution['cli_pid'], 'launch/process identity mismatch')
                require(sha(path / 'shard.json') == execution['original_shard_receipt_sha256'], 'shard receipt changed')
                validated = driver.validate_shard(path, built, binary, BUILD_SHA)
                require(driver.exact_equal(validated, driver.read_json(control / 'original-validation.json')),
                        'original validator replay differs from preserved result')
                require(driver.exact_equal(validated['plan'], cell['registered_plan']), 'registered plan changed')
                require(execution['measurements'] == 14
                        and execution['measurement_groups'] == sorted(row['group'] for row in validated['measurements']),
                        'outer operation count differs')
                closed_inventories[str(path)] = driver.inventory(path)
                closed_inventories[str(control)] = driver.inventory(control)
                report['cells'].append({'index': index, 'primary_origin': cell['primary_origin'],
                                        'shard_receipt_sha256': sha(path / 'shard.json'),
                                        'execution_sha256': sha(control / 'execution.json'),
                                        'measurements': len(validated['measurements'])})
                shards.append(validated)
            report.update(verify_population(shards, driver))
            require(driver.source_snapshot(ROOT) == source_before and driver.driver_snapshot(ROOT) == observer_before,
                    'source or original observer changed during replay')
            require(driver.inventory(COHORT / 'controls/remaining-sequence') == sequence_inventory, 'sequence record changed')
            for path, inventory in closed_inventories.items():
                require(driver.inventory(Path(path)) == inventory, 'closed artifact changed during replay: ' + path)
            # Recheck preserved build bytes without a second product workload.
            require(driver.inventory(original_build) == driver.inventory(build), 'build changed during replay')
            write(output / 'closed-artifact-inventories.json', {'cells_and_controls': closed_inventories,
                                                              'sequence': sequence_inventory,
                                                              'build': driver.inventory(build)})
            write(output / 'source-before-after.json', {'before': source_before, 'after': driver.source_snapshot(ROOT),
                                                       'observer': observer_before})
            report.update(status='complete_selected_local1k_cohort_integrity', passed=True,
                          source_and_artifacts_before_after_unchanged=True,
                          cleanup_observation_scope='Original receipts only; no claim that cross-tool residual directories vanished. Residual views excluded from closed final evidence.')
        except BaseException as error:
            report['error'] = type(error).__name__ + ': ' + str(error)
        finally:
            report['elapsed_ns'] = time.monotonic_ns() - started
            report['finished_utc'] = datetime.now(timezone.utc).isoformat()
            report['review_files'] = driver.inventory(output)
            write(output / 'report.json', report)
        return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    try:
        result = run(args.output)
        print(json.dumps({key: result.get(key) for key in ('status', 'passed', 'measurements', 'error')}, sort_keys=True))
        return 0 if result.get('passed') else 1
    except (OSError, ValueError, KeyError, subprocess.SubprocessError) as error:
        print(json.dumps({'status': 'not_run_or_not_admitted', 'error': type(error).__name__ + ': ' + str(error)}))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
