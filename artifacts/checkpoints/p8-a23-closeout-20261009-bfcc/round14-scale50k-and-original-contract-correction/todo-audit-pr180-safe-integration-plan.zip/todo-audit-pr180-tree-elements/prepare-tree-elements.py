import ast,hashlib,json
from pathlib import Path
OUT=Path(__file__).resolve().parent
SOURCE=Path('/dev/shm/todo-audit-pr180-merge-plan')
INPUT=Path('/workspace/scratch/bfccb8494ba0/root-round13/current-merge-trees-transfer/extracted/pr180head4652.json')
V2=Path('/dev/shm/todo-audit-pr180-public-dependency-fix-v2')
module=ast.parse((SOURCE/'audit-complete-trees.py').read_text())
helpers=ast.Module(body=[x for x in module.body if isinstance(x,ast.FunctionDef)],type_ignores=[])
import copy
exec(compile(helpers,str(SOURCE/'audit-complete-trees.py'),'exec'))
audit=json.loads((SOURCE/'55aa-full-union-audit.json').read_text())
manifest=json.loads((V2/'source-manifest.json').read_text())
rows=json.loads(INPUT.read_text())['tree'];by_path={x['path']:x for x in rows}
changes={p:{'path':p,**{k:v[k] for k in ['mode','type','sha']}}
         for p,v in audit['latest_main_changes_from_fd9'].items()
         if p not in ['scripts/verify_reviewed_source_v15.py','scripts/reviewed-source-registry-v15.json']}
uploads=[]
for f in manifest['modified_files']:
 p=f['path'];v=f['after'];raw=(V2/'candidate'/p).read_bytes()
 assert sha(raw)==v['sha256'] and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==v['git_blob']
 changes[p]={'path':p,'mode':v['mode'],'type':'blob','sha':v['git_blob']}
 uploads.append({'path':p,'local_path':str(V2/'candidate'/p),'encoding':'utf-8','bytes':len(raw),'sha256':sha(raw),'expected_created_blob':v['git_blob']})
assert len(changes)==120
for p,v in changes.items():
 assert identity(by_path.get(p))!=identity(v)
 by_path[p]=v
 # Git tree API reconstructs parent directories; synthesise those locally for the exact hash check.
 parts=p.split('/')
 for i in range(1,len(parts)):
  d='/'.join(parts[:i]);by_path.setdefault(d,{'path':d,'mode':'040000','type':'tree','sha':'0'*40})
predicted=compute_trees(list(by_path.values()))['']
assert predicted=='9ae248f8e0c42a8a7389e26e3f44710dfb029640'
request={'repository_full_name':'jyqj/codecortex','base_tree_sha':'6737ba0b700344853b6bce17cb3ee4bd792363d5','tree_elements':[changes[p] for p in sorted(changes)]}
req=write('create-tree-request.json',request)
info={
 'scope':'Data-only exact arguments, no create_blob/create_tree/commit/ref action executed by this author',
 'request':req,'expected_tree':predicted,'expected_P_ordered_parents':['4652cad11dde4b41126544a38fddf25eb2fb7474','55aa2bcf355441585bcf980e1d6f4fab8eebe59d'],
 'three_local_blob_inputs':uploads,
 'existing_remote_blob_entries':117,'frozen_v2_blob_entries':3,
 'counts':{'total_leaf_updates':120,'main_source':7,'v2_source':3,'README_docs_tasks':8,'main_added_artifacts':102,'deletions':0},
 'minimality':'Every listed leaf differs from base4652; no unchanged leaf or directory is included. All existing remote OIDs come from fully verified55aa tree; three v2 blobs must be created/verified if not already present remotely.',
 'unchanged_selected_bindings':['scripts/reviewed-source-registry-v15.json','scripts/verify_reviewed_source_v15.py'],
 'required_PR_head_lease':'4652cad11dde4b41126544a38fddf25eb2fb7474',
 'candidate_counts':{'product':1093,'BASE_delta':59,'validation':139},
 'execution_scope':'No tests have been executed against this uncreated combination by this task. New actual P needs separately bound validation; original3ff+v2 and Gc8 samples retain their source identity.',
 'P8_007_open_gap':{
  'source':'Original09-BENCHMARK §9 L175, independently re-read; root/pr_triage identified missing actual DB acquisition timing',
  'requirement':'mixed read/build must collect DB lock wait in addition to other original observations',
  'existing_client_admission_timing':'does not measure DB lock acquisition wait',
  'status':'pending original acceptance; no TODO closed',
  'scope_boundary':'Existing non-scale workflow success remains its actual result, but neither this new P nor originalGc8 full-scale study is represented as completeP8-007 acceptance. Separate implementation/thread may supply a default-off feature; that code is not included in these120 elements.',
 },
}
write('tree-elements-manifest-and-open-gap.json',info)
entries=[]
for p in sorted(OUT.iterdir()):
 if p.is_file() and p.name!='archive-selection.json':
  b=p.read_bytes();entries.append({'path':str(p),'bytes':len(b),'sha256':sha(b)})
sel=write('archive-selection.json',{'entries':entries,'file_count':len(entries),'total_bytes':sum(x['bytes'] for x in entries),'prior_plan_selection_unchanged':str(SOURCE/'archive-selection.json')})
print(json.dumps({'request':req,'expected_tree':predicted,'uploads':uploads,'selection':sel},indent=2))
