def stable_00366():
    return 366
