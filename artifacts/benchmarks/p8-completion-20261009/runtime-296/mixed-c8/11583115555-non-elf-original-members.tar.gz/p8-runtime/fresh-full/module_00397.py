def stable_00397():
    return 397
