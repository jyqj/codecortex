def stable_00128():
    return 128
