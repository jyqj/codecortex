"""Materialize exact G2 product/observer bytes for later original intake only.

No module import, validator, ELF, build, workload or remote fetch is performed.
"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess

HERE = Path(__file__).resolve().parent
ADMISSION = HERE.parent / 'round41-PR201-format-admission'
SOURCE = ADMISSION / 'guard-view'
VIEW = HERE / 'source-exact-G2'
G = 'f97c5068d056969705e8387ba1f37d83847f5bee'
ENV = {**os.environ, 'GIT_NO_LAZY_FETCH': '1', 'GIT_OPTIONAL_LOCKS': '0', 'GIT_TERMINAL_PROMPT': '0'}


def git(*args, cwd=SOURCE):
    return subprocess.check_output(['git', *args], cwd=cwd, env=ENV)


def assignment(path, name):
    tree = ast.parse(path.read_text())
    return next(node.value for node in tree.body if isinstance(node, ast.Assign)
                and any(isinstance(target, ast.Name) and target.id == name for target in node.targets))


def main():
    binding = json.loads((ADMISSION / 'inputs/actual-G-binding.json').read_text())
    review = json.loads((ADMISSION / 'inputs/independent-source-review.json').read_text())
    assert binding['source'] == G and git('rev-parse', 'HEAD').decode().strip() == G
    assert json.loads((ADMISSION / 'actual-original-validation-attempt01/terminal.json').read_text())['passed'] is True
    full_path = SOURCE / 'scripts/p8_scale_matrix.py'
    task_path = SOURCE / 'scripts/p8_task_profile_matrix.py'
    common = ast.literal_eval(assignment(full_path, 'DRIVER_FILES'))
    extension = assignment(task_path, 'DRIVER_FILES')
    assert isinstance(extension, ast.BinOp) and isinstance(extension.op, ast.Add)
    assert isinstance(extension.left, ast.Attribute) and isinstance(extension.left.value, ast.Name)
    assert extension.left.value.id == 'full' and extension.left.attr == 'DRIVER_FILES'
    observers = list(common + ast.literal_eval(extension.right))
    assert len(observers) == len(set(observers)) == 11
    paths = sorted(set(review['complete_inputs']) | set(observers))
    entries = {}
    inventory = review['actual_input_mode_blob_inventory']
    for path in paths:
        raw = git('show', G + ':' + path)
        item = inventory[path]
        assert hashlib.sha256(raw).hexdigest() == item['sha256']
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == item['sha']
        entries[path] = {'mode': item['mode'], 'git_blob': item['sha'], 'sha256': item['sha256'], 'bytes': len(raw)}
    VIEW.mkdir(exist_ok=False)
    git('init', '--quiet', cwd=VIEW)
    (VIEW / '.git/objects/info/alternates').write_text(str(SOURCE / '.git/objects') + '\n')
    shallow = SOURCE / '.git/shallow'
    if shallow.exists():
        (VIEW / '.git/shallow').write_bytes(shallow.read_bytes())
    git('read-tree', G, cwd=VIEW)
    git('update-ref', '--no-deref', 'HEAD', G, cwd=VIEW)
    for path, item in entries.items():
        raw = git('cat-file', 'blob', item['git_blob'], cwd=VIEW)
        target = VIEW / path
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(raw)
        target.chmod(int(item['mode'][-3:], 8))
    assert git('write-tree', '--missing-ok', cwd=VIEW).decode().strip() == binding['source_tree']
    receipt = {'source': G, 'source_tree': binding['source_tree'], 'product': binding['product'],
               'review': binding['review'], 'source_root': str(VIEW), 'product_count': len(review['complete_inputs']),
               'observer_paths': observers, 'selected_count': len(entries), 'selected_entries': entries,
               'read_only_alternate': str(SOURCE / '.git/objects'), 'full_checkout': False,
               'native_or_validator_executed': False, 'remote_fetches': 0,
               'run_id': None, 'run_attempt': None, 'build_artifact': None, 'binary': None}
    with (HERE / 'source-materialization-receipt.json').open('x') as stream:
        json.dump(receipt, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({key: receipt[key] for key in ('source', 'source_root', 'product_count', 'selected_count', 'native_or_validator_executed')}))


if __name__ == '__main__':
    main()
