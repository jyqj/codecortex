import hashlib,json,pathlib,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
def meta(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git_blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
files=[]
for dirname in ['actual-original-task-plan-attempt01','actual-original-task-plan-attempt02']:
    files += [p for p in (ROOT/dirname).iterdir() if p.is_file()]
for pat in ['*task-plan*.py','task-plan-controller*','task-plan-docs-fetch.*','task-plan-exact-docs-preparation.json','actual-G-task-plan-inputs.json']:
    files+=list(ROOT.glob(pat))
files=sorted(set(files));entries=[]
for p in files:entries.append(dict(path=p.relative_to(ROOT).as_posix(),local_path=str(p),**meta(p.read_bytes())))
out=ROOT/'task-plan-final-addendum';out.mkdir()
selection=(json.dumps(dict(schema='original-task-plan-two-attempts-v1',files=entries),indent=2)+'\n').encode();(out/'archive-selection.json').write_bytes(selection)
zpath=out/'original-task-plan-attempts.zip'
with zipfile.ZipFile(zpath,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for e in entries:z.write(e['local_path'],e['path'])
    z.writestr('archive-selection.json',selection)
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None and len(z.infolist())==len(entries)+1
    for e in entries:assert meta(z.read(e['path']))=={k:e[k] for k in ['bytes','sha256','git_blob']}
first=json.loads((ROOT/'actual-original-task-plan-attempt01/terminal.json').read_text());second=json.loads((ROOT/'actual-original-task-plan-attempt02/terminal.json').read_text())
assert first['records'][0]['exit_code']==1 and second['records'][0]['exit_code']==0
assert first['records'][0]['inputs_unchanged'] and second['records'][0]['inputs_unchanged']
report=dict(schema='pr190-main-original-task-plan-addendum-v1',source='4786c1457b47c5baf4c09d32b96048795e863111',source_tree='6518a5b317683a24ded3a69b027da6a04b8c996c',first_attempt=first,complete_original_document_attempt=second,original_result=json.loads((ROOT/'actual-original-task-plan-attempt02/original-task-plan.stdout').read_text()),input_preparation=json.loads((ROOT/'task-plan-exact-docs-preparation.json').read_text()),previous_v15_report_git_blob='805eb45b514673a68dbb72378d87b512c5bc5b1e',previous_v15_originals_zip_git_blob='07f160feb2dedb1da9f524ee6698b374e72ed3ed',previous_v15_not_reexecuted=True,source_or_task_state_changed=False,originals_zip=meta(zpath.read_bytes()),scope='Original task-plan consistency check only. First failure is a missing selected-view document, not a failed source assertion. Exact unchanged current-G documents were materialized; no task states or source code were edited. No Rust, CI or performance credit.')
b=(json.dumps(report,indent=2)+'\n').encode();(out/'original-task-plan-addendum.json').write_bytes(b)
prefix='artifacts/checkpoints/p8-borrowed-oracle-main-integration-bfcc-20261009'
manifest={'files':[dict(local_path=str(out/'original-task-plan-addendum.json'),path=prefix+'/original-task-plan-addendum.json',**meta(b)),dict(local_path=str(zpath),path=prefix+'/original-task-plan-attempts.zip',**meta(zpath.read_bytes()))]}
(out/'upload-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest))
