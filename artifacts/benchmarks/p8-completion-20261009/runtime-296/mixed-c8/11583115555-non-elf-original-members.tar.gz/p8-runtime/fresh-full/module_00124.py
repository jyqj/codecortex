def stable_00124():
    return 124
