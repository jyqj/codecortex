def stable_00113():
    return 113
