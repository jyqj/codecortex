#!/usr/bin/env python3
"""Apply an inherited, process-local network filter, verify it, then exec a gate.

This is not a network namespace or a system policy change. The caller records
the final gate exit separately; this receipt describes pre-exec observations.
"""
import argparse
import ctypes
import ctypes.util
import errno
import hashlib
import json
import os
from pathlib import Path
import socket
import stat
import subprocess
import sys


def security_status(pid="self"):
    wanted = {"NoNewPrivs", "Seccomp", "Seccomp_filters"}
    return {key: value.strip() for line in Path(f"/proc/{pid}/status").read_text().splitlines()
            if ":" in line for key, value in [line.split(":", 1)] if key in wanted}


def socket_fds():
    result = []
    for name in os.listdir("/proc/self/fd"):
        descriptor = int(name)
        try:
            mode = os.fstat(descriptor).st_mode
        except OSError as error:
            if error.errno == errno.EBADF:
                continue
            raise
        if stat.S_ISSOCK(mode):
            result.append(descriptor)
    return sorted(result)


def socket_probe(family):
    try:
        with socket.socket(family, socket.SOCK_STREAM):
            pass
    except OSError as error:
        if error.errno != errno.EPERM:
            raise RuntimeError(f"unexpected network probe errno {error.errno}") from error
        return {"blocked": True, "errno": error.errno}
    raise RuntimeError("network socket creation remained possible")


def apply_filter():
    name = ctypes.util.find_library("seccomp")
    if not name:
        raise RuntimeError("libseccomp is unavailable")
    library = ctypes.CDLL(name, use_errno=True)
    library.seccomp_init.argtypes = [ctypes.c_uint32]
    library.seccomp_init.restype = ctypes.c_void_p
    library.seccomp_syscall_resolve_name.argtypes = [ctypes.c_char_p]
    library.seccomp_syscall_resolve_name.restype = ctypes.c_int
    library.seccomp_rule_add_array.argtypes = [ctypes.c_void_p, ctypes.c_uint32,
                                              ctypes.c_int, ctypes.c_uint, ctypes.c_void_p]
    library.seccomp_rule_add_array.restype = ctypes.c_int
    library.seccomp_load.argtypes = [ctypes.c_void_p]
    library.seccomp_load.restype = ctypes.c_int
    library.seccomp_release.argtypes = [ctypes.c_void_p]
    library.seccomp_release.restype = None
    context = library.seccomp_init(0x7fff0000)  # SCMP_ACT_ALLOW
    if not context:
        raise RuntimeError("seccomp_init failed")
    denied, unavailable = [], []
    try:
        for syscall in ("socket", "connect", "socketcall", "io_uring_setup",
                        "io_uring_enter", "io_uring_register"):
            number = library.seccomp_syscall_resolve_name(syscall.encode("ascii"))
            if number < 0:
                unavailable.append(syscall)
                continue
            result = library.seccomp_rule_add_array(
                context, 0x00050000 | errno.EPERM, number, 0, None)
            if result != 0:
                raise RuntimeError(f"seccomp rule {syscall} failed: {result}")
            denied.append(syscall)
        if "socket" not in denied or "connect" not in denied:
            raise RuntimeError("essential network syscall rules unavailable")
        # NoNewPrivs is local to this process and inherited across exec. No
        # parent process or machine-wide policy is modified.
        libc = ctypes.CDLL(None, use_errno=True)
        libc.prctl.argtypes = [ctypes.c_int, ctypes.c_ulong, ctypes.c_ulong,
                              ctypes.c_ulong, ctypes.c_ulong]
        libc.prctl.restype = ctypes.c_int
        if libc.prctl(38, 1, 0, 0, 0) != 0:  # PR_SET_NO_NEW_PRIVS
            raise OSError(ctypes.get_errno(), "PR_SET_NO_NEW_PRIVS")
        result = library.seccomp_load(context)
        if result != 0:
            raise RuntimeError(f"seccomp_load failed: {result}")
    finally:
        library.seccomp_release(context)
    return denied, unavailable


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command or args.receipt.exists() or args.receipt.is_symlink():
        parser.error("an actual exec command and a new receipt path are required")
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "schema_version": 1,
        "scope": "inherited per-process seccomp denial; not a network namespace",
        "system_settings_changed": False,
        "namespace_attempted": False,
        "wrapper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "exec_command": command,
        "before": security_status(),
    }
    try:
        inherited = socket_fds()
        if any(descriptor < 3 for descriptor in inherited):
            raise RuntimeError("standard stream is a socket; refusing to inherit it")
        for descriptor in inherited:
            os.close(descriptor)
        record["closed_socket_fds"] = inherited
        record["denied_syscalls"], record["unavailable_syscalls"] = apply_filter()
        record["after"] = security_status()
        if record["after"].get("NoNewPrivs") != "1" or record["after"].get("Seccomp") != "2":
            raise RuntimeError("NoNewPrivs/seccomp status did not confirm the filter")
        record["ipv4"] = socket_probe(socket.AF_INET)
        record["ipv6"] = socket_probe(socket.AF_INET6)
        left, right = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM)
        left.close()
        right.close()
        record["local_unix_pair"] = "allowed"
        probe = """import errno,json,socket
r={}
for family in (socket.AF_INET,socket.AF_INET6):
 try:
  with socket.socket(family,socket.SOCK_STREAM): pass
 except OSError as error:
  if error.errno != errno.EPERM: raise
  r[str(int(family))]={'blocked':True,'errno':error.errno}
 else: raise RuntimeError('exec child network was not denied')
print(json.dumps(r,sort_keys=True))
"""
        result = subprocess.run([sys.executable, "-c", probe], check=True,
                                stdin=subprocess.DEVNULL, capture_output=True,
                                text=True, close_fds=True)
        record["exec_child_ipv4_ipv6"] = json.loads(result.stdout)
        record["socket_fds_before_exec"] = socket_fds()
        if record["socket_fds_before_exec"]:
            raise RuntimeError("a socket descriptor remains before exec")
        record["result"] = "filter_loaded_and_probes_passed_before_exec"
        record["final_gate_exit"] = "recorded_by_parent_executor_not_this_receipt"
    except Exception as error:
        record["result"] = "blocked_before_gate_exec"
        record["error"] = f"{type(error).__name__}: {error}"
        with args.receipt.open("x") as handle:
            json.dump(record, handle, indent=2)
            handle.write("\n")
        raise
    with args.receipt.open("x") as handle:
        json.dump(record, handle, indent=2)
        handle.write("\n")
    os.environ["P7_017_NETWORK_POLICY"] = "process_seccomp_deny_network"
    os.execvpe(command[0], command, os.environ)


if __name__ == "__main__":
    main()
