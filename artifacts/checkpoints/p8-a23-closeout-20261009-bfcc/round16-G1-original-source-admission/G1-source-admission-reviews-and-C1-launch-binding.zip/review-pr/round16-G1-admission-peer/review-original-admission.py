"""Read and verify retained original evidence only; never execute product code."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import stat
import zipfile

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = Path('/dev/shm/pr-triage-round16-G1-admission-peer')
TRANSFER = ROOT / 'root-round16/native-G-admission-transfer'
ZIP = TRANSFER / 'native-db-observation-G-d7f-original-v15-round16.zip'
EX = TRANSFER / 'extracted'
RAW = EX / 'G-admission'
P1_DIR = ROOT / 'scale-intake-primary/db-wait-cleanup-P-bb29-independent'
G = 'd7f21ab52ee2068c45ab5f7781e9e1db57f613de'
TREE = '23f0f69fef9d62229fd947e7747aefdfea78d024'
P = 'bb290be2deaf4334863e09dbf47fe4ccc9625f2b'
R = '51d5ed91e14ddb13eccb93ebd28311a3235075cc'
RP = 'artifacts/checkpoints/p8-db-acquisition-cleanup-bfcc-20261009/independent-source-review.json'

def identity_bytes(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}

def identity(path):
    return {'path': str(path), **identity_bytes(path.read_bytes())}

def readj(path):
    return json.loads(path.read_bytes())

def writej(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write('\n')

zip_id = identity(ZIP)
assert zip_id['bytes'] == 413296
assert zip_id['sha256'] == '6133e513c6c47aae9d84b02b388e2c8f88f8ae8d5b802d279b2ff5a9f063fa13'
assert zip_id['git_blob'] == '9b7ce01e7d4b52fb168b68e44abcc50e5a8a62e5'
manifest = readj(EX / 'archive-manifest.json')
assert (manifest['actual_G'], manifest['product_P'], manifest['review_R']) == (G, P, R)
assert len(manifest['files']) == 31
expected = {f['path']: f for f in manifest['files']}
assert len(expected) == 31
members = []
seen = set()
with zipfile.ZipFile(ZIP) as z:
    assert len(z.infolist()) == 32
    for info in z.infolist():
        original = info.orig_filename
        assert '\0' not in original and original == info.filename
        path = PurePosixPath(original)
        assert not path.is_absolute() and '..' not in path.parts and '\\' not in original
        assert path.as_posix() == original and original not in seen
        seen.add(original)
        mode = (info.external_attr >> 16) & 0xffff
        assert not stat.S_ISLNK(mode) and not info.is_dir()
        data = z.read(info)  # ZipFile verifies CRC while reading the complete member.
        ident = identity_bytes(data)
        assert len(data) == info.file_size
        disk = EX / original
        assert not disk.is_symlink() and disk.read_bytes() == data
        if original != 'archive-manifest.json':
            want = expected[original]
            assert ident['bytes'] == want['bytes'] and ident['sha256'] == want['sha256']
            assert stat.S_IMODE(disk.stat().st_mode) == int(want['mode'], 8)
        members.append({'path': original, **ident, 'zip_crc32': f'{info.CRC:08x}',
                        'full_crc_read': True, 'extracted_bytes_identical': True})
assert seen == set(expected) | {'archive-manifest.json'}

prep = readj(RAW / 'preparation-receipts.json')
assert len(prep) == 10
for rec in prep:
    assert type(rec['exit_code']) is int and rec['exit_code'] == 0
    assert 'controller_timeout_seconds' not in rec
    for stream in ['stdout', 'stderr']:
        got = identity(RAW / rec[stream]['path'])
        assert all(got[k] == rec[stream][k] for k in ['bytes', 'sha256'])

commit = (RAW / 'actual-G-commit.stdout').read_bytes()
assert hashlib.sha1(b'commit ' + str(len(commit)).encode() + b'\0' + commit).hexdigest() == G
header = commit.split(b'\n\n', 1)[0].decode().splitlines()
assert header[0] == 'tree ' + TREE
assert [line[7:] for line in header if line.startswith('parent ')] == [R]

def parse_tree(path):
    rows = {}
    for item in path.read_bytes().split(b'\0'):
        if not item:
            continue
        meta, name = item.split(b'\t', 1)
        mode, kind, blob = meta.decode().split()
        assert kind == 'blob' and mode in ['100644', '100755']
        name = name.decode()
        assert name not in rows
        rows[name] = {'mode': mode, 'git_blob': blob}
    return rows

initial = parse_tree(RAW / 'initial-G-ls-tree.stdout')
history = parse_tree(RAW / 'current-G-historical-ls-tree.stdout')
base_history = parse_tree(RAW / 'original-BASE-historical-ls-tree.stdout')
assert len(initial) == 1251 and len(history) == 236 and history == base_history
assert len(set(initial) & set(history)) == 47
binding = readj(RAW / 'preparation-binding.json')
assert (binding['guard'], binding['tree'], binding['product'], binding['review'], binding['review_path']) == (G, TREE, P, R, RP)
assert set(binding['historical_paths']) == set(history)
expected_tree = dict(initial)
for path, item in history.items():
    if path in expected_tree:
        assert expected_tree[path] == item
    expected_tree[path] = item

baseline = readj(RAW / 'complete-domain-before-v15.json')
assert identity(RAW / 'complete-domain-before-v15.json')['sha256'] == '54da4876a15a0d1a71322b24bc8183d84f1babff778140027fbeb6dbd22259ee'
assert (baseline['source_G'], baseline['tree'], baseline['product_P'], baseline['review_R']) == (G, TREE, P, R)
assert baseline['combined_selected_count'] == 1440
entries = {item['path']: item for item in baseline['entries']}
assert len(entries) == len(baseline['entries']) == 1440
assert set(entries) == set(expected_tree)
for path, row in entries.items():
    assert {k: row[k] for k in ['mode', 'git_blob']} == expected_tree[path]
    assert row['mode'] in ['100644', '100755']

before = readj(RAW / 'original-v15-domain-before.json')
after = readj(RAW / 'original-v15-domain-after.json')
assert (RAW / 'original-v15-domain-before.json').read_bytes() == (RAW / 'original-v15-domain-after.json').read_bytes()
assert before == after and before['head'] == before['source_G'] == G
assert before['entries'] == baseline['entries']

source_audit = readj(P1_DIR / 'actual-P1-complete-source-audit.json')
assert source_audit['source'] == P
assert identity(P1_DIR / 'actual-P1-complete-source-audit.json')['sha256'] == '3a15a6b13bd76dd78118b620070c7d2dfad9e2d7ca08c4f069ea9b55f56f6d66'
canonical = P1_DIR / 'independent-source-review.json'
canonical_id = identity(canonical)
assert canonical_id['bytes'] == 778906
assert canonical_id['sha256'] == '9a8a494481ac0acb2a2199b2df5697fe3727092abe1644bd91a6717d11418eeb'
review = readj(canonical)
assert review['source'] == P and len(review['complete_inputs']) == 1095 and len(review['validation_inputs']) == 142
assert review['author_independence']['reviewer'] == '/root/execution_recon'
assert review['author_independence']['reviewer_authored_current_product_or_validation_changes'] is False
inv = source_audit['actual_input_mode_blob_inventory']
assert len(inv) == 1237 and inv == review['actual_input_mode_blob_inventory']
for path, row in inv.items():
    got = entries[path]
    assert (got['mode'], got['git_blob'], got['bytes'], got['sha256']) == (row['mode'], row['sha'], row['size'], row['sha256'])
assert entries[RP]['bytes'] == canonical_id['bytes']
assert entries[RP]['sha256'] == canonical_id['sha256']
assert entries[RP]['git_blob'] == canonical_id['git_blob']

receipt = readj(RAW / 'original-v15-command-receipt.json')
assert identity(RAW / 'original-v15-command-receipt.json')['sha256'] == 'c7bdad64302f97ae966baac142a96995dd3f794f79928286dc5e0fa3c35ea68b'
assert (receipt['source_G'], receipt['guard_G'], receipt['product_P'], receipt['review_R']) == (G, G, P, R)
assert type(receipt['exit_code']) is int and receipt['exit_code'] == 0
assert 'controller_exception' not in receipt and 'controller_timeout_seconds' not in receipt
assert receipt['argv'] == ['python3', 'scripts/verify_reviewed_source_v15.py', '--source-version', 'p8-completion-source-20261009-v15']
assert receipt['cwd'] == '/Users/jin/Desktop/codecortex-rust/artifacts/benchmarks/p8-bfccb8494ba0/candidate-db-observation-G-d7f21ab5'
assert receipt['resolved_python3'] == '/usr/bin/python3'
for field in ['domain_before', 'domain_after', 'stdout', 'stderr']:
    ident = identity(RAW / receipt[field]['path'])
    assert all(ident[k] == receipt[field][k] for k in ['bytes', 'sha256'])
assert receipt['domain_before']['count'] == receipt['domain_after']['count'] == 1440
assert receipt['parent_head_before'] == receipt['parent_head_after'] == 'ff458bc591b4e7e444af4464d6eef2513cdb335c'
assert (RAW / 'parent-head-before.stdout').read_bytes() == (RAW / 'parent-head-after.stdout').read_bytes()
assert (RAW / 'original-v15.stderr').stat().st_size == 0
stdout = readj(RAW / 'original-v15.stdout')
assert stdout['schema_version'] == 10 and stdout['status'] == 'passed' and stdout['complete_inputs'] == 1095
assert (stdout['product_source'], stdout['review_source']) == (P, R)
assert stdout['source_version'] == 'p8-completion-source-20261009-v15'
assert stdout['previous_source_version'] == stdout['executed_previous_proof'] == 'p8-oracle-compat-source-20261008-v14'
assert stdout['base_source'] == '7354db236c9d9850a75f31672697ae9eab44565e'

writej(OUT / 'original-member-verification.json', {'schema_version': 1, 'zip': zip_id,
    'archive_manifest': identity(EX / 'archive-manifest.json'), 'member_count': 32,
    'original_member_count': 31, 'unsafe_or_duplicate_members': 0, 'members': members})
report = {
 'schema_version': 1, 'reviewer': '/root/pr_triage',
 'verdict': 'accepted_scoped_actual_G1_original_selected_v15_execution',
 'scope': 'Read-only independent original-evidence review; no product code, native command, v15 or measurement rerun.',
 'source_G': G, 'tree': TREE, 'sole_parent_R': R, 'product_P1': P,
 'zip': zip_id, 'original_receipt': identity(RAW / 'original-v15-command-receipt.json'),
 'original_execution': receipt, 'original_stdout_document': stdout,
 'archive_checks': {'members': 32, 'originals': 31, 'all_CRCs_read': True,
                    'all_manifest_bytes_SHA_and_extracted_bytes_verified': True,
                    'all_manifest_file_modes_verified': True, 'original_preparation_commands_exit_zero': len(prep)},
 'source_checks': {'raw_G_commit_reconstructed': True, 'tree_and_sole_parent_match': True,
   'initial_selected_count': 1251, 'historical_protected_count': 236, 'overlap_count': 47,
   'combined_selected_count': 1440, 'selected_mode_blob_equal_original_git_ls_tree_receipts': True,
   'historical_mode_blob_equal_original_BASE': True, 'all_before_after_entries_equal_baseline': True,
   'before_after_files_byte_identical': True, 'complete_product_inputs_equal_canonical_P1': 1095,
   'validation_inputs_equal_canonical_P1': 142, 'other_selected_inputs': 203,
   'canonical_review_matches_original_G_selected_entry': True,
   'canonical_review': canonical_id, 'canonical_author_independence': review['author_independence'],
   'actual_P1_source_audit': identity(P1_DIR / 'actual-P1-complete-source-audit.json'),
   'controller_basis': 'Read original preparation/run controllers; native snapshots recompute every selected raw SHA, Git blob, mode and byte count before and after, require actual G HEAD, and retain integer child exit.'},
 'boundaries': [
   'This is direct actual G1 checkout execution, not P2 engineering execution or a relabeled P1 test run.',
   'The selected original v15 CLI passed and stdout records execution of original previous v14. This archive does not represent the separate 181-test suite.',
   'Selected 1440 input scope is verified. Unselected repository documentation/artifacts need not be checked out; no whole-repository cleanliness claim.',
   'Raw source files are represented by retained native input snapshots and original ls-tree receipts; this small ZIP is not a complete source archive. The independent previously fixed P1 audit and canonical R are checked by their exact SHA and complete 1237 maps.',
   'Elapsed time is an execution receipt, not isolated timing or performance evidence; concurrent P2 engineering provides no cold/cache/performance credit.',
   'No C1/4/8/16 result, P2 result, full-scale study completion or original TODO closure is granted by this review.',
   'Root owns the already started C1 observation; this reviewer did not launch, poll, cancel or repeat it.'
 ],
 'todo_ledger_unchanged': {'done': 163, 'remaining': 29},
 'unresolved_blockers_within_this_scope': []}
writej(OUT / 'independent-G1-original-v15-execution-review.json', report)
files=[]
for name in ['independent-G1-original-v15-execution-review.json','original-member-verification.json','review-original-admission.py']:
    path=OUT/name
    ident=identity(path)
    files.append({'local_path':str(path),'repository_path':'review-pr/round16-G1-admission-peer/'+name,
                  **{k:ident[k] for k in ['bytes','sha256','git_blob']}})
writej(OUT/'archive-selection.json',{'schema_version':1,'file_count':len(files),
    'total_bytes':sum(f['bytes'] for f in files),'files':files,
    'outside_selection_original_zip':zip_id,'note':'Do not duplicate original ZIP in this small reviewer selection.'})
for name in ['independent-G1-original-v15-execution-review.json','archive-selection.json']:
    print(json.dumps(identity(OUT/name)))
