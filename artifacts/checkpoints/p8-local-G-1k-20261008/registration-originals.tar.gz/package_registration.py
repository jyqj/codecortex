#!/usr/bin/env python3
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
def sha(raw): return hashlib.sha256(raw).hexdigest()

def main():
    paths = {p.name:p for p in HERE.iterdir() if p.is_file() and p.name in {
        'registration.json','preregister.py','README.md','package_registration.py',
        'G-run.json','G-jobs-page-1.json','G-jobs-page-2.json'}}
    for name, path in {
        'feasibility.json':'/dev/shm/p8-local-formal-scale-feasibility-G/feasibility.json',
        'path-metadata-contract.json':'/dev/shm/p8-local-formal-scale-feasibility-G/path-metadata-contract.json',
        'independent-registration-review.json':'/dev/shm/p8-mixed-origin-scale-independent-review/registration-review.json',
        'independent-contract-review.json':'/dev/shm/p8-mixed-origin-scale-independent-review/contract-review.json',
    }.items(): paths[name]=Path(path)
    files={}
    archive=HERE/'registration-originals.tar.gz'
    with archive.open('xb') as output:
        with gzip.GzipFile(filename='',fileobj=output,mode='wb',mtime=0) as gz:
            with tarfile.open(fileobj=gz,mode='w') as tar:
                for name,path in sorted(paths.items()):
                    assert path.is_file() and not path.is_symlink()
                    raw=path.read_bytes(); mode=path.stat().st_mode&0o777
                    files[name]={'bytes':len(raw),'sha256':sha(raw),'mode':mode}
                    info=tarfile.TarInfo(name);info.size=len(raw);info.mode=mode;info.mtime=0
                    tar.addfile(info,io.BytesIO(raw))
    with tarfile.open(archive,'r:gz') as tar:
        members=tar.getmembers();assert len(members)==len(files) and {x.name for x in members}==set(files)
        for m in members:
            raw=tar.extractfile(m).read();assert m.isfile() and len(raw)==files[m.name]['bytes'] and sha(raw)==files[m.name]['sha256'] and m.mode==files[m.name]['mode']
    raw=archive.read_bytes()
    manifest={'schema_version':1,'archive':archive.name,'bytes':len(raw),'sha256':sha(raw),'files':files,
              'member_count':len(files),'original_bytes':sum(x['bytes'] for x in files.values()),'actual_roundtrip_all_members':True}
    (HERE/'registration-archive-manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:v for k,v in manifest.items() if k!='files'}))

if __name__=='__main__':main()
