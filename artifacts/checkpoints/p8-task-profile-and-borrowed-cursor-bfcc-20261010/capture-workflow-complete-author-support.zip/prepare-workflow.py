from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "candidate/.github/workflows/p8-task-profile.yml"


class WorkflowDumper(yaml.SafeDumper):
    pass


def represent_string(dumper, value):
    return dumper.represent_scalar("tag:yaml.org,2002:str", value, style="|" if "\n" in value else None)


WorkflowDumper.add_representer(str, represent_string)


def expr(value):
    return "$" + "{{ " + value + " }}"


SOURCE = expr("github.event.pull_request.head.sha || github.sha")
RUN = expr("github.run_id")
ATTEMPT = expr("github.run_attempt")
CELL = expr("matrix.cell")
TEMP = expr("runner.temp")
SUFFIX = f"{RUN}-{ATTEMPT}"
CELL_SUFFIX = f"{CELL}-{SUFFIX}"
LAUNCHED = "always() && steps.launch.outcome == 'success'"


def checkout():
    return dict(uses="actions/checkout@v4", **{"with": dict(
        ref=SOURCE, **{"sparse-checkout-cone-mode": False, "sparse-checkout": "/*\n!/artifacts/\n"}
    )})


def rust():
    return dict(uses="dtolnay/rust-toolchain@stable", **{"with": dict(toolchain="1.95.0")})


def upload(name, path, condition="always()", step_id=None, title=None):
    result = dict(uses="actions/upload-artifact@v4", **{"if": condition, "with": dict(
        name=name, path=path, **{"if-no-files-found": "error"}
    )})
    if step_id:
        result["id"] = step_id
    if title:
        result["name"] = title
    return result


def download(name=None, pattern=None, path=None):
    values = dict(path=path)
    values["name" if name is not None else "pattern"] = name if name is not None else pattern
    return dict(uses="actions/download-artifact@v4", **{"with": values})


build_steps = [
    checkout(), rust(),
    dict(name="Compile and bind the task executable and exact 45-cell registry", run="\n".join([
        "python3 scripts/p8_task_profile_matrix.py build \\",
        '  --root "$GITHUB_WORKSPACE" --output "$RUNNER_TEMP/p8-task-build" \\',
        '  --target-directory "$RUNNER_TEMP/p8-task-cargo" \\',
        '  --run-id "$GITHUB_RUN_ID" --attempt "$GITHUB_RUN_ATTEMPT"',
    ]) + "\n"),
    dict(name="Validate all 45 release-mode plans without executing a measurement", run="\n".join([
        "cargo test --release -p cc-eval --test p8_scale --locked \\",
        '  --target-dir "$RUNNER_TEMP/p8-task-cargo" \\',
        "  task_descriptive_scope_is_explicit_n1_without_weakening_old_n30 -- --exact",
    ]) + "\n"),
    upload(f"p8-task-build-{SUFFIX}", f"{TEMP}/p8-task-build",
           title="Preserve original build, binary, registry and unsuccessful preparation"),
]
cells = [
    dict(cell=f"{profile}-{scale}", profile=profile, scale=scale, fanout="")
    for profile in ("no_op", "body", "api", "config", "batch_1", "batch_10", "batch_100", "batch_1000")
    for scale in (100000, 50000, 10000, 5000, 1000)
] + [dict(cell=f"fanout-{fanout}", profile="fanout", scale=1000, fanout=fanout)
     for fanout in (1, 4, 16, 64, 128)]
extra_array = "$" + "{extra[@]}"
measure_steps = [
    checkout(), rust(), download(name=f"p8-task-build-{SUFFIX}", path=f"{TEMP}/p8-task-build"),
    dict(name="Prepare original registered capacity on the disposable hosted VM",
         env=dict(P8_EXPECTED_SOURCE=SOURCE, P8_CAPACITY_PREPARE_ALLOWED=expr(
             "github.repository == 'jyqj/codecortex' && runner.environment == 'github-hosted' && runner.os == 'Linux'"
         )), run="\n".join([
             'python3 scripts/p8_runner_capacity.py --scale "$P8_TASK_SCALE" \\',
             '  --output "$RUNNER_TEMP/p8-task-capacity-$P8_TASK_CELL" --prepare-ephemeral',
         ]) + "\n"),
    upload(f"p8-task-capacity-{CELL_SUFFIX}", f"{TEMP}/p8-task-capacity-{CELL}",
           title="Preserve original capacity observations"),
    dict(name="Launch one exact fresh task cell with setup and parity inside its native deadline",
         id="launch", env=dict(P8_EXPECTED_SOURCE=SOURCE), run="\n".join([
             'chmod +x "$RUNNER_TEMP/p8-task-build/native-build/p8-scale"',
             "extra=()",
             'if [[ "$P8_TASK_PROFILE" == "fanout" ]]; then',
             '  extra=(--fanout "$P8_TASK_FANOUT")',
             "fi",
             "python3 scripts/p8_task_profile_capture.py launch \\",
             '  --root "$GITHUB_WORKSPACE" --build "$RUNNER_TEMP/p8-task-build" \\',
             '  --directory "$RUNNER_TEMP/p8-task-cell-$P8_TASK_CELL" \\',
             '  --expected-source "$P8_EXPECTED_SOURCE" \\',
             '  --run-id "$GITHUB_RUN_ID" --attempt "$GITHUB_RUN_ATTEMPT" \\',
             '  --mutation-profile "$P8_TASK_PROFILE" --scale "$P8_TASK_SCALE" "' + extra_array + '"',
         ]) + "\n"),
]
for index in range(20):
    current = f"{index:02d}"
    step = dict(
        name=f"Freeze original byte prefix at absolute interval {index + 1} of 20",
        id=f"freeze_{current}", **{"if": LAUNCHED},
        run="python3 scripts/p8_task_profile_capture.py checkpoint \\\n"
            f'  --directory "$RUNNER_TEMP/p8-task-cell-$P8_TASK_CELL" --index {index}\n',
    )
    if index:
        previous = f"{index - 1:02d}"
        step["env"] = dict(PREVIOUS_ARTIFACT_ID=expr(f"steps.upload_{previous}.outputs.artifact-id"),
                           PREVIOUS_ARTIFACT_DIGEST=expr(f"steps.upload_{previous}.outputs.artifact-digest"))
    measure_steps += [
        step,
        upload(f"p8-task-progress-{CELL_SUFFIX}-{current}", expr(f"steps.freeze_{current}.outputs.bundle"),
               condition=f"always() && steps.freeze_{current}.outputs.ready == 'true'",
               step_id=f"upload_{current}"),
    ]
measure_steps += [
    dict(name="Preserve final or interrupted task diagnostic boundary", id="finish", **{"if": LAUNCHED},
         env=dict(PREVIOUS_ARTIFACT_ID=expr("steps.upload_19.outputs.artifact-id"),
                  PREVIOUS_ARTIFACT_DIGEST=expr("steps.upload_19.outputs.artifact-digest")),
         run="python3 scripts/p8_task_profile_capture.py finish \\\n"
             '  --directory "$RUNNER_TEMP/p8-task-cell-$P8_TASK_CELL" --index 20\n'),
    upload(f"p8-task-progress-{CELL_SUFFIX}-final", expr("steps.finish.outputs.bundle"),
           condition="always() && steps.finish.outputs.ready == 'true'"),
    upload(f"p8-task-shard-{CELL_SUFFIX}", f"{TEMP}/p8-task-cell-{CELL}/shard",
           title="Preserve the complete task shard separately from diagnostic prefixes"),
    dict(name="Return actual task driver and native outcome", **{"if": LAUNCHED},
         run="python3 scripts/p8_task_profile_capture.py verdict \\\n"
             '  --directory "$RUNNER_TEMP/p8-task-cell-$P8_TASK_CELL"\n'),
]
aggregate_steps = [
    checkout(), download(name=f"p8-task-build-{SUFFIX}", path=f"{TEMP}/p8-task-build"),
    download(pattern=f"p8-task-shard-*-{SUFFIX}", path=f"{TEMP}/p8-task-shards"),
    dict(name="Validate all 45 cells and retain every failed or missing result", **{"if": "always()"},
         run="\n".join([
             "python3 - <<'PY'", "import os, pathlib, sys", "sys.path.insert(0, 'scripts')",
             "import p8_task_profile_matrix as matrix",
             "root = pathlib.Path(os.environ['RUNNER_TEMP'])",
             "binary = root / 'p8-task-build/native-build/p8-scale'",
             "if binary.exists():", "    binary.chmod(0o755)",
             "inputs = sorted((root / 'p8-task-shards').glob('p8-task-shard-*'))",
             "result = matrix.aggregate(root / 'p8-task-build', inputs, root / 'p8-task-matrix')",
             "print({key: result.get(key) for key in ('status', 'error', 'sample_count', 'cell_count')})",
             "sys.exit(0 if result.get('passed') is True else 1)", "PY",
         ]) + "\n"),
    upload(f"p8-task-matrix-{SUFFIX}", f"{TEMP}/p8-task-matrix", title="Preserve task review including failure"),
]
workflow = dict(
    name="P8 complete descriptive task profile measurements",
    on=dict(workflow_dispatch=None, pull_request=dict(types=["labeled"])),
    permissions=dict(contents="read"),
    env=dict(CARGO_TERM_COLOR="never", CARGO_INCREMENTAL="0", CARGO_BUILD_JOBS="2", RUSTFLAGS=""),
    jobs=dict(
        build={"if": "github.event_name == 'workflow_dispatch' || github.event.label.name == 'p8-task-profile-run'",
               "runs-on": "ubuntu-24.04", "timeout-minutes": 45, "steps": build_steps},
        measure={"needs": ["build"], "runs-on": "ubuntu-24.04", "timeout-minutes": 350,
                 "strategy": {"fail-fast": False, "max-parallel": 10, "matrix": {"include": cells}},
                 "env": dict(P8_TASK_CELL=CELL, P8_TASK_PROFILE=expr("matrix.profile"),
                             P8_TASK_SCALE=expr("matrix.scale"), P8_TASK_FANOUT=expr("matrix.fanout")),
                 "steps": measure_steps},
        aggregate={"if": "always() && needs.build.result == 'success'", "needs": ["build", "measure"],
                   "runs-on": "ubuntu-24.04", "timeout-minutes": 30, "steps": aggregate_steps},
    ),
)
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(yaml.dump(workflow, Dumper=WorkflowDumper, sort_keys=False, width=120, allow_unicode=True))
print(OUT)
