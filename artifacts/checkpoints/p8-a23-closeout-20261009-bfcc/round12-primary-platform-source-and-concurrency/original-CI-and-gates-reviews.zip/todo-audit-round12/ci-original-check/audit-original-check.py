"""Read original CI logs and existing official Git tree proofs; execute no tests."""
from pathlib import Path
import hashlib
import json
import re
import datetime

BASE = Path('/workspace/scratch/bfccb8494ba0')
OUT = BASE / 'todo-audit-round12/ci-original-check'
G = 'c8be5afaac568ffd40ef86d3795423c3b73c9f39'
M = '39ae6437c417236f40110f0d18f29aa1ac3db3de'
P = '35a7b3412e5fdee9e8ff88951735c06b0e371465'
R = 'a9706a90a72226cb59c3bfd374ef9c1e3d66cbcb'

def ref(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

log = OUT / 'job-113726259355-original.log'
lines = log.read_text().splitlines()
clean = [re.sub(r'\x1b\[[0-9;]*m', '', x.split('Z ', 1)[1] if 'Z ' in x else x) for x in lines]
jobs_path = OUT / 'original-final-jobs-api.json'
jobs = json.loads(jobs_path.read_text())['jobs']
job = next(x for x in jobs if x['id'] == 113726259355)
assert job['run_id'] == 37901930820 and job['head_sha'] == G
assert job['status'] == 'completed' and job['conclusion'] == 'success'
steps = job['steps']
assert all(x['status'] == 'completed' and x['conclusion'] == 'success' for x in steps)
fixed = next(x for x in steps if x['name'] == 'Fixed resource driver harmless fixtures and TODO consistency')
head_lines = [i for i,x in enumerate(clean) if x == '[command]/usr/bin/git log -1 --format=%H']
assert len(head_lines) == 1 and clean[head_lines[0] + 1] == M
assert any('HEAD is now at 39ae6437 Merge ' + G in x for x in clean)
assert any('fetch --no-tags --prune --no-recurse-submodules --depth=1 origin +' + M + ':refs/remotes/pull/178/merge' in x for x in clean)
command = 'PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests/source_integrity -v'
guard_command = 'python3 scripts/verify_reviewed_source_v15.py --source-version p8-completion-source-20261009-v15'
assert clean.count(command) == clean.count(guard_command) == 1
assert 'shell: /usr/bin/bash -e {0}' in clean
summaries = [(i,re.fullmatch(r'Ran (\d+) tests in ([0-9.]+)s',x)) for i,x in enumerate(clean)]
summaries = [(i,int(m[1]),float(m[2])) for i,m in summaries if m]
source_summary = [(i,n,s) for i,n,s in summaries if n == 181]
assert len(source_summary) == 1
end,n,seconds = source_summary[0]
assert clean[end + 2] == 'OK'
prior = max(i for i,_,_ in summaries if i < end)
test_rows = []
for i in range(prior + 1, end):
    m = re.fullmatch(r'(test_\S+) \(([^)]+)\) \.\.\. (.+)', clean[i])
    if m:
        test_rows.append(dict(line=i+1,name=m[1],qualified_name=m[2],result=m[3]))
assert len(test_rows) == 181 and len({x['qualified_name'] for x in test_rows}) == 181
assert all(x['result'] == 'ok' for x in test_rows)
guard_rows = []
for i,x in enumerate(clean):
    if x.startswith('{'):
        try:
            value = json.loads(x)
        except json.JSONDecodeError:
            continue
        if value.get('source_version') == 'p8-completion-source-20261009-v15':
            guard_rows.append((i,value))
assert len(guard_rows) == 1
gi,guard = guard_rows[0]
assert gi > end and guard['status'] == 'passed' and guard['complete_inputs'] == 1090
assert guard['product_source'] == P and guard['review_source'] == R
assert guard['base_source'] == '7354db236c9d9850a75f31672697ae9eab44565e'
assert guard['executed_previous_proof'] == guard['previous_source_version'] == 'p8-oracle-compat-source-20261008-v14'
assert guard['scope'] == 'independently_reviewed_source_and_validation_inputs'
assert guard['runtime_and_quality_claims'] == 'require_separate_execution_evidence'
mapping_path = BASE / 'todo-audit-round12/ci-prospective-source-map-v2.json'
mapping = json.loads(mapping_path.read_text())
assert ref(mapping_path)['sha256'] == 'c547a111cff6ef8ff6fbf3a299603dd27287142b6e829247e6de36707423d076'
assert mapping['prospective_merge'] == M and mapping['source_commit'] == G
assert mapping['coverage']['whole_repository_equal'] is False
domain = ['Cargo.toml','Cargo.lock','crates','scripts','.github','tests']
assert all(mapping['maps'][0][p] == mapping['maps'][1][p] for p in domain)
assert mapping['coverage']['p8_facts_inputs_and_managed_docs_equal'] is True
assert mapping['coverage']['review_dir_equal'] is True
assert mapping['review_file']['sha'] == '7f6d2bd8d105c20fd5110cfe0bb9caf8007175c1'
canonical = BASE / 'pr-triage-primary-recovery/runtime-review-Gc8/exact-canonical-R.json'
assert ref(canonical)['sha256'] == 'c38d10f1b0d5935384039a6af7df6e8d222bc351a68d3137b09e664735ee9404'
review = json.loads(canonical.read_text())
assert len(review['complete_inputs']) == 1090 and len(review['validation_inputs']) == 139
assert review['source'] == P

report = dict(schema_version=1, recorded_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    verdict='accepted_original_CI_source_admission_and_job_success',
    run_id=37901930820,run_attempt=job['run_attempt'],job_id=job['id'],
    event_head=G,actual_checkout=M,actual_checkout_kind='GitHub synthetic merge, not direct Gc8 checkout',
    started_at=job['started_at'],completed_at=job['completed_at'],actual_job_conclusion=job['conclusion'],
    original_job_api=ref(jobs_path),original_log=ref(log),
    actual_checkout_log_line=head_lines[0]+2,fixed_step=fixed,
    source_integrity=dict(command=command,observed_tests=181,observed_ok=181,observed_skipped=0,
        observed_failed=0,seconds=seconds,summary_log_line=end+1,original_summary=lines[end],
        original_terminal=lines[end+2],tests=test_rows),
    selected_v15=dict(command=guard_command,log_line=gi+1,original_output=guard,
        exit_evidence='Original unwrapped command printed passed, subsequent historical command ran, and Bash -e step succeeded. No separate per-child integer receipt is invented.'),
    current_source_domain_bridge=dict(source_equivalence=ref(mapping_path),
        prospective_bridge_now_confirmed_by_actual_job_log=True,
        exact_equal_domains={p:mapping['maps'][0][p] for p in domain},
        canonical_review_directory_tree=mapping['same_review_dir_tree'],canonical_R=ref(canonical),
        product_inputs=1090,validation_inputs=139,whole_repository_tree_equal=False,
        differing_unrelated_paths=mapping['unrelated_observed_differences']),
    source_admission_applies_to=dict(G=G,P=P,R=R),
    other_original_unittest_summary_observations=[dict(line=i+1,tests=n,seconds=s) for i,n,s in summaries if n!=181],
    limits=['No local181/v15/Rust rerun; only original CI result observed.',
            'Actual checkout remains synthetic merge; whole repo includes unrelated docs/artifact differences.',
            'Source/CI acceptance does not grant scale150/1500, full platform aggregation, release or TODO completion.',
            'No oldG9f/a23 source-admission or execution credit is transferred.'],
    task_credit=False,remaining_todos=29)
(OUT / 'independent-original-check-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(verdict=report['verdict'],actual_checkout=M,source_tests=181,source_tests_ok=181,
                     v15_status=guard['status'],P=P,R=R,job_conclusion='success',original_log=ref(log))))
