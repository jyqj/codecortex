def stable_00127():
    return 127
