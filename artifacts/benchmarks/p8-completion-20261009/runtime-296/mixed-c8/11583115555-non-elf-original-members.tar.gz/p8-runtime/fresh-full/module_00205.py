def stable_00205():
    return 205
