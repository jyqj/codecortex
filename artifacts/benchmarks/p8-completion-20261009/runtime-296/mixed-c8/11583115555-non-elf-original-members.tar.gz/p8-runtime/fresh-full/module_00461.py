def stable_00461():
    return 461
