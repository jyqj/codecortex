"""Archive review records while preserving the immutable bulk artifact references."""
from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import re
import stat
import tarfile

ROOT = Path(__file__).resolve().parent
WORK = Path('/workspace/scratch/2eaa00d0f93a')
items = {}

def add(path, name):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError(f'not a regular input: {path}')
    if name in items:
        raise ValueError(f'duplicate archive path: {name}')
    items[name] = path

def top(directory, label, exclude=()):
    directory = Path(directory)
    for path in sorted(directory.iterdir()):
        if path.is_file() and not path.is_symlink() and path.suffix not in ('.zip', '.pyc') and path.name not in exclude:
            add(path, label + '/' + path.name)

for directory, label in [
    ('/dev/shm/p8-staging-receiver-independent-pr-audit', 'staging-independent-receiver'),
    ('/dev/shm/p8-staging-publication-bridge-pr-audit', 'staging-publication-bridge'),
    ('/dev/shm/p8-staging-source-admission-preparation', 'staging-source-admission-preparation'),
    ('/dev/shm/p8-original-ten-gap-audit', 'original-ten-gap-audit'),
    ('/dev/shm/p8-per-file-batching-design-independent-review', 'per-file-design-independent'),
    ('/dev/shm/p8-peer-current-runtime-review', 'peer-current-runtime-review'),
    ('/dev/shm/p8-G4-lifecycle-expansion-reclaim-root', 'lifecycle-reclaim-root'),
    ('/dev/shm/p8-G4-lifecycle-reclaim-independent-pr-audit', 'lifecycle-reclaim-independent'),
    ('/dev/shm/p8-G4-C16-integrity-independent-pr-audit', 'mixed-C16-independent'),
    ('/dev/shm/p8-round11-archive-independent-pr-audit', 'round11-publication-independent'),
    ('/dev/shm/p8-G-additional-deadline-reception-20261009', 'G-additional-deadlines'),
    ('/dev/shm/p8-G4-recovery-reception-20261009', 'G4-recovery-reception'),
    ('/dev/shm/p8-G4-recovery-reception-20261009/recovery-rollback', 'G4-recovery-reception/recovery-rollback'),
    ('/dev/shm/p8-G4-mixed-reception-20261009', 'G4-mixed-C16-integrity'),
    (WORK/'p8-G-first-deadline-failures-20261009', 'G-first-deadlines'),
]:
    top(directory, label)

reception = Path('/dev/shm/p8-staging-engineering-reception')
top(reception, 'staging-actual-reception')
for aid in ('11587252940', '11587547695'):
    for path in sorted((reception/aid).rglob('*')):
        if not path.is_file() or path.is_symlink() or path.name == 'p8-scale':
            continue
        # The build's 9 MB original ZIP stays unchanged in Actions and locally.
        # The small controls ZIP is included in full alongside every log.
        if aid == '11587547695' and path.name == 'original.zip':
            continue
        add(path, 'staging-actual-reception/' + str(path.relative_to(reception)))

publication = WORK/'p8-staging-engineering-publication-root'
for name in ('receive_engineering.py', 'test-expectations.json', 'actual-commit.json',
             'actual-root-tree.json', 'actual-source-materialization.json',
             'actual-source-snapshot.json', 'actual-driver-snapshot.json',
             'materialize_actual_source.py', 'plan_lifecycle_expansion_reclaim.py',
             'execute_lifecycle_expansion_reclaim.py'):
    add(publication/name, 'root-fixed-scripts/' + name)
for name in ('remaining-hotspots.md', 'per-file-batching-design.md'):
    add(WORK/'p8-staging-cached-review-41236c3e'/name, 'performance-design/' + name)
add(WORK/'p8-scale-observations-20261008/G-first-four-deadline-artifacts-manifest.json', 'G-first-deadlines/original-delivery-manifest.json')
add(Path(__file__), 'prepare_round12.py')

entries = []
for name, path in sorted(items.items()):
    data = path.read_bytes()
    if re.search(rb'https?://[^\s<>"\']+[?&](?:sig|skoid|sktid|ske|skt)=', data):
        raise ValueError(f'private signed URL in public input: {name}')
    entries.append({'path': name, 'source_path': str(path), 'bytes': len(data),
                    'sha256': hashlib.sha256(data).hexdigest(), 'mode': stat.S_IMODE(path.stat().st_mode)})

bulk = [
    {'artifact_id': 11587547695, 'run_id': 37863581678, 'scope': 'actual8e release build', 'bytes': 9214483, 'sha256': '0c6afba4022398faf23cc2387e53414d67c19ff849b1fd3262d758f0078273fe'},
    {'artifact_id': 11588128186, 'run_id': 37854847808, 'scope': 'G4 recovery and rollback', 'bytes': 121429720, 'sha256': '924563afef37b2111ba2857ffc6c5d3cc234adc264a942dad64c54f6392c9d48'},
    {'artifact_id': 11588372461, 'run_id': 37854847820, 'scope': 'G4 mixed C16, integrity only', 'bytes': 16388340, 'sha256': 'ad788f605deb6e55e7ad3d944394e079a5983ea774560869d2a9b09624e22e2a'},
]
for folder in (WORK/'p8-G-first-deadline-failures-20261009', Path('/dev/shm/p8-G-additional-deadline-reception-20261009')):
    for path in sorted(folder.glob('*.zip')):
        bulk.append({'artifact_id': int(path.stem), 'run_id': 37830173594, 'scope': 'original G failed shard; never a replacement', 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
for row in bulk:
    row['actions_url'] = f"https://github.com/jyqj/codecortex/actions/runs/{row['run_id']}/artifacts/{row['artifact_id']}"
    row['storage_scope'] = 'Original ZIP remains unchanged in GitHub Actions and in the existing local reception. This metadata packet does not duplicate its bulk payload.'

archive = ROOT/'round12-review-records.tar.gz'
with archive.open('xb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for entry in entries:
                data = items[entry['path']].read_bytes()
                assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
                info = tarfile.TarInfo(entry['path'])
                info.size = len(data)
                info.mode = entry['mode']
                info.mtime = 0
                tar.addfile(info, io.BytesIO(data))
for entry in entries:
    path = items[entry['path']]
    assert path.stat().st_size == entry['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256']

manifest = {'schema_version': 1, 'round': 12, 'captured_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'status': 'review_metadata_checkpoint_not_acceptance_or_release',
            'source_engineering': '8e542e644b06a83fc82d18d9896cf82f5b2d796e',
            'source_G4': '260f596582f2d82b8d7c707b61a6b8b6a43b069f',
            'source_original_G': 'bb9a96d71622458c39a143055360cc97f0d11d78',
            'previous_checkpoint': 'b2aede645d76cf44f58d70de1df94de00c32031b',
            'TODO': {'total': 192, 'done': 163, 'remaining': 29, 'new_done': 0},
            'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                        'members': len(entries), 'uncompressed_bytes': sum(row['bytes'] for row in entries)},
            'members': entries, 'bulk_originals_referenced_not_embedded': bulk,
            'scope_limits': ['41 actual engineering controls and build identity are not N30 scale acceptance.',
                             'G4 recovery is scoped evidence; C16 is archive integrity only pending all four cells and original independent statistics replay.',
                             'All eight received native-deadline failures and the separate runner shutdown remain failures in original G. D0 still has its missing mandatory shard.',
                             'A successful owned-duplicate deletion was followed by recreation with another inode. Both records remain; durable free space is not claimed.',
                             'Source-admission preparation and batching design remain drafts. The original TODO ledger and all fixed study branches are unchanged.']}
with (ROOT/'manifest.json').open('x') as output:
    json.dump(manifest, output, indent=2, ensure_ascii=False)
    output.write('\n')
print(json.dumps({'members': len(entries), 'uncompressed_bytes': manifest['archive']['uncompressed_bytes'], 'archive_bytes': archive.stat().st_size,
                  'archive_sha256': manifest['archive']['sha256'], 'manifest_sha256': hashlib.sha256((ROOT/'manifest.json').read_bytes()).hexdigest(),
                  'new_TODO_done': 0, 'TODO_remaining': 29}))
