import hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent
plan=json.loads((P/'prepared-R9-G2-H7-installation-map.json').read_text())
source=json.loads(Path('/dev/shm/todo-audit-pr180-v15-binding-preparation/actual-P-official.json').read_text())
actual={'P':source,'R':json.loads((P/'actual-R-official.json').read_text()),'G':json.loads((P/'actual-G-official.json').read_text()),'H':json.loads((P/'actual-H-official.json').read_text())}
expected={
 'P':('c92eb5ac7ece70d1f62271d7e2dacac513c285b5',plan['P']['tree'],['4652cad11dde4b41126544a38fddf25eb2fb7474','55aa2bcf355441585bcf980e1d6f4fab8eebe59d']),
 'R':('f89d5feec91ae611d52614b8fe217bcd7fd5cf64',plan['R']['tree'],['c92eb5ac7ece70d1f62271d7e2dacac513c285b5']),
 'G':('b2bbd5817ce00367cea52696b098c6eafe4aa0a6',plan['G']['predicted_tree'],['f89d5feec91ae611d52614b8fe217bcd7fd5cf64']),
 'H':('399a71a4c11e7041ce9946fba4d3f72200c47155',plan['H']['predicted_tree'],['1d39f382d4e08e702a55693c9c614fa477bf7e0c','b2bbd5817ce00367cea52696b098c6eafe4aa0a6'])}
for key,(sha,tree,parents) in expected.items():
 x=actual[key];assert x['sha']==sha and x['tree']['sha']==tree and [v['sha'] for v in x['parents']]==parents,key
binding_rows=[]
for kind,name in [('registry','reviewed-source-registry-v15.json'),('guard','verify_reviewed_source_v15.py')]:
 r=json.loads((P/f'actual-H-{kind}-response.json').read_text());b=r['content'].encode();local=P/'staged/scripts'/name
 assert b==local.read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['sha']
 binding_rows.append({'path':'scripts/'+name,'actual_H_git_blob':r['sha'],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'remote_H_bytes_equal_generated_G':True})
reg=json.loads((P/'staged/scripts/reviewed-source-registry-v15.json').read_text());review_r=json.loads((P/'actual-R-canonical-response.json').read_text());review=review_r['content'].encode();assert hashlib.sha256(review).hexdigest()==reg['review_sha256'];canonical=json.loads(review)
assert canonical['source']==reg['product_source']==expected['P'][0]
assert reg['review_source']==expected['R'][0]
assert canonical['paths']==reg['delta'] and canonical['complete_inputs']==reg['complete_inputs'] and canonical['validation_inputs']==reg['validation_inputs']
assert len(reg['delta'])==59 and len(reg['complete_inputs'])==1093 and len(reg['validation_inputs'])==139
result={
 'schema':'actual-P-R-G-H-installation-readback-v1','observed_at_utc':'2026-10-09 10:59:16 UTC',
 'status':'passed_read_only_actual_commit_and_complete_tree_identity_checks',
 'scope':'Mechanical identity and original contract applicability; author does not sign independent R, run Rust, run original v15 or certify runtime/scale/tasks',
 'actual_commits':{k:{'sha':v[0],'tree':v[1],'parents':v[2]} for k,v in expected.items()},
 'complete_tree_method':'Every P leaf came from independently reconstructed full immutable maps. R adds9 exact official archive leaves; G changes2 locally generated blob identities; H adds7 exact external archive leaves. Every full tree SHA was recomputed before observing actual G/H and equals official committed tree identities.',
 'counts':{'product':1093,'BASE_delta':59,'validation':139,'R_additions':9,'G_binding_changes':2,'H_additions':7},
 'actual_H_binding_bytes':binding_rows,
 'canonical_R':{'path':'artifacts/checkpoints/p8-public-api-merge-bfcc-20261009/independent-source-review.json','git_blob':review_r['sha'],'bytes':len(review),'sha256':hashlib.sha256(review).hexdigest(),'actual_independent_reviewers':canonical['independent_reviewers'],'all_required_maps_equal_registry':True},
 'guard_changed_only_original_four_pins':True,
 'source_integrity_CI_v14_validation_and_internal_budgets_unchanged':True,
 'latest_main_README_docs_tasks_all_old_Rs_and_all_external_1d39_archive_leaves_preserved':True,
 'original_v15_at_H_is_permitted_by_fixed_input_contract':True,
 'actual_original_v15_and_original_CI_status':'pending separately observed actual execution; not inferred from this receipt',
 'no_old_execution_cohort_relabelled':True,
 'P8_007_DB_acquisition_wait_gap_remains_open':True,
 'original_TODO_remaining':29,
 'remote_write_or_dispatch_performed_by_this_verifier':False,
}
target=P/'actual-installed-P-R-G-H-readback.json';raw=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode();target.write_bytes(raw)
print(json.dumps({'report':str(target),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'status':result['status']},indent=2))
