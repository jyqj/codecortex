#![allow(dead_code)]
extern crate self as cc_model;
pub mod symbol {
/// Symbol kind — replaces string constants from Python version.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum SymbolKind {
    Function,
    Class,
    Method,
    Variable,
    Constant,
    Interface,
    TypeAlias,
    Enum,
    Module,
    Namespace,
    Property,
    Export,
    Hook,
    Component,
    Middleware,
    Controller,
    RouteHandler,
    Route,
}

impl SymbolKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Function => "function",
            Self::Class => "class",
            Self::Method => "method",
            Self::Variable => "variable",
            Self::Constant => "constant",
            Self::Interface => "interface",
            Self::TypeAlias => "type_alias",
            Self::Enum => "enum",
            Self::Module => "module",
            Self::Namespace => "namespace",
            Self::Property => "property",
            Self::Export => "export",
            Self::Hook => "hook",
            Self::Component => "component",
            Self::Middleware => "middleware",
            Self::Controller => "controller",
            Self::RouteHandler => "route_handler",
            Self::Route => "route",
        }
    }

    /// Parse from string (lenient — returns None for unknown kinds).
    pub fn from_str_lenient(s: &str) -> Option<Self> {
        match s {
            "function" => Some(Self::Function),
            "class" => Some(Self::Class),
            "method" => Some(Self::Method),
            "variable" | "var" | "let" | "const" => Some(Self::Variable),
            "constant" => Some(Self::Constant),
            "interface" => Some(Self::Interface),
            "type_alias" | "type" => Some(Self::TypeAlias),
            "enum" => Some(Self::Enum),
            "module" => Some(Self::Module),
            "namespace" => Some(Self::Namespace),
            "property" => Some(Self::Property),
            "export" => Some(Self::Export),
            "hook" => Some(Self::Hook),
            "component" => Some(Self::Component),
            "middleware" => Some(Self::Middleware),
            "controller" => Some(Self::Controller),
            "route_handler" => Some(Self::RouteHandler),
            "route" => Some(Self::Route),
            _ => None,
        }
    }
}


}
mod dsl {
//! Search DSL parser: extracts structured filters from query strings.
//!
//! Supported filter keys (case-insensitive):
//! - `kind:` — filter by symbol kind (e.g. `kind:function`, `kind:"type alias"`)
//! - `lang:` — filter by language (e.g. `lang:python`, `lang:rust`)
//! - `path:` — filter by path prefix (e.g. `path:src/api`)
//! - `name:` — filter/boost by symbol name (e.g. `name:handle_request`)

/// Parsed search query with extracted structured filters.
#[derive(Debug, Clone, Default)]
pub struct ParsedQuery {
    /// Remaining free-text after filter extraction.
    pub text: String,
    /// `kind:` filter — matches against `SymbolKind::as_str()` (case-insensitive).
    pub kind_filter: Option<String>,
    /// Every `lang:` constraint, including repeated/empty values for validation.
    pub lang_filters: Vec<String>,
    /// Every `path:` prefix constraint; repeated filters intersect, not overwrite.
    pub path_filters: Vec<String>,
    /// `name:` filter — matches against symbol name.
    pub name_filter: Option<String>,
}

/// Known filter keys.
const FILTER_KEYS: &[&str] = &["kind", "lang", "path", "name"];

/// Parse a raw search query, extracting `kind:`, `lang:`, `path:`, `name:` filters.
/// Remaining text (after filter removal) becomes `text`.
/// Supports quoted values: `kind:"type alias"`.
pub fn parse_search_dsl(raw: &str) -> ParsedQuery {
    let mut result = ParsedQuery::default();
    let mut remaining_tokens: Vec<&str> = Vec::new();

    let input = raw.trim();
    if input.is_empty() {
        return result;
    }

    let chars: Vec<char> = input.chars().collect();
    let len = chars.len();
    let mut pos = 0;

    while pos < len {
        // Skip whitespace
        if chars[pos].is_whitespace() {
            pos += 1;
            continue;
        }

        // Try to match a filter key
        let mut matched_key: Option<&str> = None;
        for &key in FILTER_KEYS {
            let key_colon = format!("{}:", key);
            let key_colon_len = key_colon.len();
            if pos + key_colon_len <= len {
                let candidate: String = chars[pos..pos + key_colon_len].iter().collect();
                if candidate.eq_ignore_ascii_case(&key_colon) {
                    matched_key = Some(key);
                    pos += key_colon_len;
                    break;
                }
            }
        }

        if let Some(key) = matched_key {
            // Extract value — either quoted or unquoted
            let value = if pos < len && chars[pos] == '"' {
                // Quoted value: consume until closing quote
                pos += 1; // skip opening quote
                let start = pos;
                while pos < len && chars[pos] != '"' {
                    pos += 1;
                }
                let val: String = chars[start..pos].iter().collect();
                if pos < len && chars[pos] == '"' {
                    pos += 1; // skip closing quote
                }
                val
            } else {
                // Unquoted value: consume until whitespace
                let start = pos;
                while pos < len && !chars[pos].is_whitespace() {
                    pos += 1;
                }
                chars[start..pos].iter().collect()
            };

            match key {
                "lang" => result.lang_filters.push(value),
                "path" => result.path_filters.push(value),
                "kind" if !value.is_empty() => result.kind_filter = Some(value),
                "name" if !value.is_empty() => result.name_filter = Some(value),
                _ => {}
            }
        } else {
            // Regular token: consume until whitespace
            let start = pos;
            while pos < len && !chars[pos].is_whitespace() {
                pos += 1;
            }
            let token: &str = &input[byte_offset(&chars, start)..byte_offset(&chars, pos)];
            remaining_tokens.push(token);
        }
    }

    result.text = remaining_tokens.join(" ");
    result
}

/// Convert a char index to a byte offset in the original string.
fn byte_offset(chars: &[char], char_idx: usize) -> usize {
    chars[..char_idx].iter().map(|c| c.len_utf8()).sum()
}


}
mod query_target {
//! Conservative target hints for the additive exact-name bonus only.
//! This is an explicit syntax recognizer, not a natural-language intent model.
use cc_model::symbol::SymbolKind;

use crate::dsl::ParsedQuery;

#[derive(Debug, PartialEq, Eq)]
pub(crate) enum QueryTarget {
    /// No explicit evidence: retain the historical token-based fallback.
    Ambiguous,
    Named {
        name: String,
        kind: Option<SymbolKind>,
    },
    /// A container is mentioned, but no member name was requested.
    ContainerMethods,
}

impl QueryTarget {
    pub(crate) fn parse(query: &ParsedQuery) -> Self {
        // Reuse the caller's existing explicit target filter, before prose.
        if let Some(name) = &query.name_filter {
            return Self::Named {
                name: name.to_lowercase(),
                kind: None,
            };
        }
        let text = query.text.trim();
        if let Some(name) = member_name(text) {
            return Self::Named {
                name: name.to_lowercase(),
                kind: None,
            };
        }
        let words: Vec<_> = text.split_whitespace().collect();
        if let [methods, on, container] = words.as_slice() {
            if methods.eq_ignore_ascii_case("methods")
                && on.eq_ignore_ascii_case("on")
                && identifier(container)
            {
                return Self::ContainerMethods;
            }
        }
        // Whole-query grammar prevents a keyword elsewhere in prose from
        // being mistaken for the user's target. Unknown syntax stays ambiguous.
        let (kind_word, name) = match words.as_slice() {
            [kind, name] => (*kind, *name),
            [kind, name, on, container]
                if kind.eq_ignore_ascii_case("method")
                    && on.eq_ignore_ascii_case("on")
                    && identifier(container) =>
            {
                (*kind, *name)
            }
            _ => return Self::Ambiguous,
        };
        let kind = match kind_word.to_ascii_lowercase().as_str() {
            "class" => SymbolKind::Class,
            "interface" => SymbolKind::Interface,
            "type" => SymbolKind::TypeAlias,
            "function" => SymbolKind::Function,
            "method" => SymbolKind::Method,
            _ => return Self::Ambiguous,
        };
        if !identifier(name) {
            return Self::Ambiguous;
        }
        Self::Named {
            name: name.to_lowercase(),
            kind: Some(kind),
        }
    }

    pub(crate) fn permits(&self, name: &str, kind: Option<&str>, legacy_tokens: &[String]) -> bool {
        let lower = name.to_lowercase();
        match self {
            Self::Ambiguous => legacy_tokens.contains(&lower),
            Self::Named {
                name,
                kind: target_kind,
            } => name == &lower && target_kind.is_none_or(|k| kind == Some(k.as_str())),
            Self::ContainerMethods => false,
        }
    }
}

fn identifier(text: &str) -> bool {
    let mut chars = text.chars();
    chars.next().is_some_and(|c| c == '_' || c.is_alphabetic())
        && chars.all(|c| c == '_' || c.is_alphanumeric())
}

/// Only pure `::` chains and the narrow `(*Receiver).member` form give a hint.
/// Bare dotted strings can be filenames, modules or members: no extension,
/// capitalization or filesystem evidence can make them explicit here.
/// This does not resolve qualifiers or infer that every member is callable.
fn member_name(text: &str) -> Option<&str> {
    if text.chars().any(char::is_whitespace) {
        return None;
    }
    let text = if let Some(rest) = text.strip_prefix("(*") {
        let (receiver, member) = rest.split_once(").")?;
        return (identifier(receiver) && identifier(member)).then_some(member);
    } else {
        text
    };
    let parts: Vec<_> = text.split("::").collect();
    (parts.len() > 1 && parts.iter().all(|part| identifier(part))).then(|| *parts.last().unwrap())
}


#[cfg(test)]
mod isolated_matrix {
use super::*;
#[test]
fn case_000_v2_literal_type() {
let raw = "Lantern";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_001_v2_direct_class() {
let raw = "class Lantern";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:lantern:class","target: {raw}");
}
#[test]
fn case_002_v2_direct_interface() {
let raw = "interface Listener";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:listener:interface","target: {raw}");
}
#[test]
fn case_003_v2_direct_type() {
let raw = "type SignalLabel";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:signallabel:type_alias","target: {raw}");
}
#[test]
fn case_004_v2_literal_callable() {
let raw = "Ignite";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_005_v2_direct_callable() {
let raw = "method Ignite";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:ignite:method","target: {raw}");
}
#[test]
fn case_006_v2_qualified_dot() {
let raw = "Lantern.Ignite";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_007_v2_qualified_colon() {
let raw = "Store::refresh";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:refresh:any","target: {raw}");
}
#[test]
fn case_008_v2_pointer_receiver() {
let raw = "(*Lantern).Ignite";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:ignite:any","target: {raw}");
}
#[test]
fn case_009_v2_named_method_on() {
let raw = "method Ignite on Lantern";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:ignite:method","target: {raw}");
}
#[test]
fn case_010_v2_methods_on_container() {
let raw = "methods on Lantern";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"no-name-boost","target: {raw}");
}
#[test]
fn case_011_v2_ambiguous_pair() {
let raw = "Lantern Ignite";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_012_v2_ambiguous_prose() {
let raw = "Which Lantern API changes the lighting state with Ignite?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_013_v2_same_name_type() {
let raw = "class Ignite";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:ignite:class","target: {raw}");
}
#[test]
fn case_014_v2_split_type() {
let raw = "class Reservoir";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:reservoir:class","target: {raw}");
}
#[test]
fn case_015_v2_split_context() {
let raw = "method Drain on Reservoir";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:drain:method","target: {raw}");
}
#[test]
fn case_016_v2_python_class() {
let raw = "class Shelf";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:shelf:class","target: {raw}");
}
#[test]
fn case_017_v2_python_method() {
let raw = "method arrange on Shelf";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:arrange:method","target: {raw}");
}
#[test]
fn case_018_v2_python_function() {
let raw = "function arrange";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:arrange:function","target: {raw}");
}
#[test]
fn case_019_v2_rust_interface() {
let raw = "interface Observer";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:observer:interface","target: {raw}");
}
#[test]
fn case_020_v2_rust_type() {
let raw = "type Label";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:label:type_alias","target: {raw}");
}
#[test]
fn case_021_v2_rust_callable() {
let raw = "function refresh";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:refresh:function","target: {raw}");
}
#[test]
fn case_022_v2_dsl_name() {
let raw = "name:Ignite";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:ignite:any","target: {raw}");
}
#[test]
fn case_023_v2_dsl_kind() {
let raw = "name:Ignite kind:method";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:ignite:any","target: {raw}");
}
#[test]
fn case_024_v2_dsl_over_prose() {
let raw = "name:Ignite Lantern";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:ignite:any","target: {raw}");
}
#[test]
fn case_025_v2_fallback_sentence() {
let raw = "explain class Lantern initialization";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_026_v2_ambiguous_qualified_prose() {
let raw = "compare Lantern.Ignite and Store.refresh";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_027_v2_qualified_field() {
let raw = "Lantern.Ready";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_028_v2_dot_no_extension() {
let raw = "Lantern.Ignite";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_029_v2_dot_lowercase() {
let raw = "lantern.ignite";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_030_v2_dot_module() {
let raw = "lights.Beacon";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_031_v2_dot_arbitrary_suffix() {
let raw = "Lantern.orchard";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_032_v2_dot_file_existing() {
let raw = "shelf.py";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_033_v2_dot_file_absent() {
let raw = "Shelf.yaml";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_034_v2_dot_multi_file() {
let raw = "Shelf.spec.py";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_035_v2_mixed_dot_colon() {
let raw = "Store::refresh.member";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_036_v2_mixed_colon_dot() {
let raw = "garden.Lantern::Ignite";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_037_v2_pure_colon_chain() {
let raw = "garden::Lantern::Ignite";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:ignite:any","target: {raw}");
}
#[test]
fn case_038_v2_pointer_direct() {
let raw = "(*Lantern).Ignite";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:ignite:any","target: {raw}");
}
#[test]
fn case_039_v2_pointer_chain() {
let raw = "(*Lantern).Ignite.more";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_040_v2_pointer_space() {
let raw = "(*Lantern) .Ignite";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_041_v2_explicit_name_dot() {
let raw = "name:Ignite Lantern.Ignite";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:ignite:any","target: {raw}");
}
#[test]
fn case_042_v2_explicit_kind_dot() {
let raw = "kind:method name:Ignite Lantern.Ignite";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:ignite:any","target: {raw}");
}
#[test]
fn case_043_v2_explicit_kind_target() {
let raw = "method Ignite";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"named:ignite:method","target: {raw}");
}
#[test]
fn case_044_v2_explicit_container() {
let raw = "methods on Lantern";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"no-name-boost","target: {raw}");
}
#[test]
fn case_045_api_receiver() {
let raw = "Which Harbor API resets the stored flag with Seal?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["which".into(),"harbor".into(),"api".into(),"resets".into(),"the".into(),"stored".into(),"flag".into(),"with".into(),"seal".into()];
assert_eq!(target.permits("Harbor",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_046_method_receiver() {
let raw = "What Harbor method resets the stored flag with Seal?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["what".into(),"harbor".into(),"method".into(),"resets".into(),"the".into(),"stored".into(),"flag".into(),"with".into(),"seal".into()];
assert_eq!(target.permits("Harbor",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_047_function_module() {
let raw = "Which Harbor function resets the stored flag with Seal?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["which".into(),"harbor".into(),"function".into(),"resets".into(),"the".into(),"stored".into(),"flag".into(),"with".into(),"seal".into()];
assert_eq!(target.permits("Harbor",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_048_member_container() {
let raw = "Which Harbor member updates the stored flag with Seal?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["which".into(),"harbor".into(),"member".into(),"updates".into(),"the".into(),"stored".into(),"flag".into(),"with".into(),"seal".into()];
assert_eq!(target.permits("Harbor",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_049_field_container() {
let raw = "Which Harbor field records the latest Depth?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["which".into(),"harbor".into(),"field".into(),"records".into(),"the".into(),"latest".into(),"depth".into()];
assert_eq!(target.permits("Harbor",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_050_property_container() {
let raw = "What Harbor property records the latest Depth?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["what".into(),"harbor".into(),"property".into(),"records".into(),"the".into(),"latest".into(),"depth".into()];
assert_eq!(target.permits("Harbor",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_051_explicit_on() {
let raw = "Which method on Harbor resets the flag with Seal?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["which".into(),"method".into(),"on".into(),"harbor".into(),"resets".into(),"the".into(),"flag".into(),"with".into(),"seal".into()];
assert_eq!(target.permits("Harbor",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_052_explicit_of() {
let raw = "What member of Harbor contains Depth?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["what".into(),"member".into(),"of".into(),"harbor".into(),"contains".into(),"depth".into()];
assert_eq!(target.permits("Harbor",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_053_explicit_in() {
let raw = "Which function in Harbor resets the flag with Seal?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["which".into(),"function".into(),"in".into(),"harbor".into(),"resets".into(),"the".into(),"flag".into(),"with".into(),"seal".into()];
assert_eq!(target.permits("Harbor",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Seal",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_054_lowercase() {
let raw = "which harbor api resets the flag with seal?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["which".into(),"harbor".into(),"api".into(),"resets".into(),"the".into(),"flag".into(),"with".into(),"seal".into()];
assert_eq!(target.permits("harbor",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("harbor",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("harbor",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("harbor",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("harbor",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("harbor",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("harbor",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("harbor",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("harbor",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("harbor",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("harbor",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("seal",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("seal",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("seal",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("seal",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("seal",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("seal",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("seal",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_055_uppercase() {
let raw = "WHICH HARBOR API RESETS THE FLAG WITH SEAL?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["which".into(),"harbor".into(),"api".into(),"resets".into(),"the".into(),"flag".into(),"with".into(),"seal".into()];
assert_eq!(target.permits("HARBOR",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("HARBOR",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("HARBOR",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("HARBOR",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("HARBOR",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("HARBOR",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("HARBOR",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("HARBOR",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("HARBOR",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("HARBOR",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("HARBOR",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("SEAL",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("SEAL",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("SEAL",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("SEAL",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("SEAL",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("SEAL",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("SEAL",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_056_underscore() {
let raw = "Which Cargo_Bay method retrieves Load_Item?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["which".into(),"cargo_bay".into(),"method".into(),"retrieves".into(),"load_item".into()];
assert_eq!(target.permits("Cargo_Bay",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Cargo_Bay",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Cargo_Bay",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Cargo_Bay",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Cargo_Bay",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Cargo_Bay",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Cargo_Bay",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Cargo_Bay",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Cargo_Bay",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Cargo_Bay",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Cargo_Bay",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Load_Item",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Load_Item",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Load_Item",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Load_Item",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Load_Item",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Load_Item",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Load_Item",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_057_unicode_owner() {
let raw = "Which 港湾 method retrieves 搬入?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["which".into(),"港湾".into(),"method".into(),"retrieves".into(),"搬入".into()];
assert_eq!(target.permits("港湾",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("港湾",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("港湾",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("港湾",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("港湾",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("港湾",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("港湾",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("港湾",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("港湾",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("港湾",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("港湾",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("搬入",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("搬入",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("搬入",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("搬入",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("搬入",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("搬入",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("搬入",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_058_new_domain() {
let raw = "Which Ledger method records the transaction with Append?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["which".into(),"ledger".into(),"method".into(),"records".into(),"the".into(),"transaction".into(),"with".into(),"append".into()];
assert_eq!(target.permits("Ledger",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Ledger",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Ledger",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Ledger",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Ledger",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Ledger",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Ledger",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Ledger",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Ledger",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Ledger",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Ledger",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Append",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Append",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Append",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Append",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Append",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Append",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Append",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_059_different_domain() {
let raw = "What Palette member changes the active pigment with Blend?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["what".into(),"palette".into(),"member".into(),"changes".into(),"the".into(),"active".into(),"pigment".into(),"with".into(),"blend".into()];
assert_eq!(target.permits("Palette",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Palette",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Palette",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Palette",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Palette",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Palette",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Palette",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Palette",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Palette",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Palette",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Palette",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Blend",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Blend",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Blend",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Blend",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Blend",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Blend",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Blend",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_060_plural_member() {
let raw = "Which Harbor members expose Depth?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["which".into(),"harbor".into(),"members".into(),"expose".into(),"depth".into()];
assert_eq!(target.permits("Harbor",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_061_plural_api() {
let raw = "Which Harbor APIs expose Depth?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["which".into(),"harbor".into(),"apis".into(),"expose".into(),"depth".into()];
assert_eq!(target.permits("Harbor",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_062_newline_whitespace() {
let raw = "Which\nHarbor\tmethod reads Depth?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
let tokens:Vec<String>=vec!["which".into(),"harbor".into(),"method".into(),"reads".into(),"depth".into()];
assert_eq!(target.permits("Harbor",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("enum"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("module"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("namespace"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Harbor",Some("unknown"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("method"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("function"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("property"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("class"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("interface"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",Some("type_alias"),&tokens),true,"probe: {raw}");
assert_eq!(target.permits("Depth",None,&tokens),true,"probe: {raw}");
assert_eq!(target.permits("UnrelatedSymbol",Some("method"),&tokens),false,"probe: {raw}");
}
#[test]
fn case_063_literal_owner() {
let raw = "Harbor";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_064_literal_interface() {
let raw = "Port";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_065_literal_named_type() {
let raw = "CargoCode";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_066_ambiguous_pair() {
let raw = "Harbor Seal";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_067_bare_dot() {
let raw = "Harbor.Seal";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_068_absent_file() {
let raw = "Harbor.yaml";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_069_multidot_file() {
let raw = "Harbor.spec.py";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_070_mixed_dot_colon() {
let raw = "harbor.Harbor::Seal";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_071_direct_type_prose() {
let raw = "Which type stores the Harbor state?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_072_direct_class_prose() {
let raw = "Which class implements the Harbor interface?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_073_direct_interface_prose() {
let raw = "What interface accepts the CargoCode value?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_074_explain_owner() {
let raw = "Explain the Harbor class initialization";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_075_compare_direct() {
let raw = "Compare Harbor.Seal and Vessel.Open";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_076_compare_head() {
let raw = "Which Harbor API compares Seal with Open?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_077_compare_coordination() {
let raw = "Which Harbor API calls Seal and Open?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_078_compare_versus() {
let raw = "Which Harbor API uses Seal versus Open?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_079_compare_alternative() {
let raw = "Which Harbor method selects Seal or Open?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_080_compare_similar() {
let raw = "Which Harbor API is similar to the Vessel API?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_081_invalid_owner() {
let raw = "Which 42Harbor API invokes Seal?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_082_dotted_owner() {
let raw = "Which dock.Harbor API invokes Seal?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_083_empty_tail() {
let raw = "Which Harbor API?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_084_malformed_head() {
let raw = "Tell me which Harbor API invokes Seal?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_085_no_question_head() {
let raw = "Harbor API resets the flag with Seal";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_086_unsupported_possessive() {
let raw = "Which Harbor's method invokes Seal?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_087_unsupported_indirect() {
let raw = "How does Harbor invoke Seal?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_088_unsupported_nonenglish() {
let raw = "哪个 Harbor 方法调用 Seal？";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_089_type_noun_head() {
let raw = "Which Harbor type stores the latest state?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
#[test]
fn case_090_explicit_kind_prose() {
let raw = "kind:class Which Harbor API invokes Seal?";
let parsed=crate::dsl::parse_search_dsl(raw);
let target=QueryTarget::parse(&parsed);
let model=match &target { QueryTarget::Ambiguous=>"fallback".to_owned(),QueryTarget::ContainerMethods=>"no-name-boost".to_owned(),QueryTarget::Named {name,kind}=>format!("named:{name}:{}",kind.map_or("any",|k|k.as_str())) };
assert_eq!(model,"fallback","target: {raw}");
}
}

}
