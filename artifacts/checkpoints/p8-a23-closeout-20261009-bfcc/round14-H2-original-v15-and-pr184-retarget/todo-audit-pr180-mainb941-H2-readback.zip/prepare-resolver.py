from pathlib import Path
p=Path('/dev/shm/todo-audit-pr180-head1d39-forward/resolve-head1d39-trees.py').read_text()
p=p.replace("ROOT='7a87a8e335de5c09d041b01f8802973ea96cd595'", "ROOT='6ed5ad8ed24aa6563184b737a36c4e2fe5d87de8'")
p=p.replace("sorted((OUT/'new-head-trees').glob('*.json'))", "sorted(Path('/dev/shm/todo-audit-pr180-head1d39-forward/new-head-trees').glob('*.json')) + sorted((OUT/'new-main-trees').glob('*.json'))")
p=p.replace('head1d39-complete-derived-tree.json','mainb941-complete-derived-tree.json').replace('head1d39-tree-origin-map.json','mainb941-tree-origin-map.json')
Path('/dev/shm/todo-audit-pr180-mainb941-forward/resolve-mainb941-trees.py').write_text(p)
