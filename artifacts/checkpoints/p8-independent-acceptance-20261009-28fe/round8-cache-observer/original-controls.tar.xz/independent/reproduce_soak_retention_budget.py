"""Independent synthetic low raw-budget control of the real run retention path."""
import json,hashlib,sys,time,threading,shutil,argparse
from pathlib import Path
from types import SimpleNamespace
from unittest import mock
from contextlib import ExitStack
BASE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,default=BASE.parents[1]/'pr-audit/cache-observer-candidate/candidate');p.add_argument('--output',type=Path,required=True);args0=p.parse_args()
CANDIDATE=args0.candidate.resolve();out=args0.output;out.mkdir(parents=True,exist_ok=False)
sys.path[:0]=[str(CANDIDATE/'scripts'),str(CANDIDATE/'scripts/tests')]
import p8_runtime as rt
from test_p8_runtime import RuntimeDriverControls
from test_p8_runtime_cache import ProtocolProduct
helper=RuntimeDriverControls();args,identity=helper.prepare_control(0)
args.profile='soak';args.operations=3601;args.interval_ms=1000;args.concurrency=4
budget_hit=threading.Event();killed=threading.Event();guard=[];REAL_TIME=time
class SyntheticProduct(ProtocolProduct):
 def __init__(self,identity,project,output,cache):
  super().__init__(project);self.output=output;output.mkdir();(output/'product-stderr.log').write_text('synthetic protocol only\n')
  self.closed=False;self.builds=0;self.pid=9001;self.process=SimpleNamespace(pid=self.pid,poll=lambda:0 if self.closed or killed.is_set() else None,kill=lambda:killed.set())
  self.transport=SimpleNamespace(reader=SimpleNamespace(is_alive=lambda:False),exit_watcher=SimpleNamespace(is_alive=lambda:False))
 def initialize(self):return 14
 def close(self):self.closed=True;(self.output/'process.json').write_text(json.dumps({'synthetic':True,'closed':True}))
 def tool(self,name,arguments,timeout=45):
  if killed.is_set():raise RuntimeError('synthetic owned process killed')
  if name=='index':
   self.builds+=1;self.epoch+=1
   return dict(parse_errors=[],resolution_freshness=dict(complete=True,index_epoch=self.epoch))
  if name=='status':return self.status()
  return super().tool(name,arguments,timeout)
class BudgetRaw(rt.Raw):
 def emit(self,kind,**fields):
  if kind=='operation' and fields.get('operation')=='read' and fields.get('status')=='success' and not budget_hit.is_set():
   rt.MAX_RAW_BYTES=self.size;guard.append(dict(id=fields['id'],limit=self.size,row_reference=fields,metadata=[{k:v for k,v in c.items() if k!='response'} for c in fields['cache_probe']['requests']]));budget_hit.set()
  return super().emit(kind,**fields)
sleeps=[]
def sleep(seconds):
 sleeps.append(seconds)
 if budget_hit.is_set():raise RuntimeError('bounded synthetic scheduler stop after raw-budget guard')
 assert len(sleeps)<20,'read never reached retention guard'
 REAL_TIME.sleep(.03)
try:
 with ExitStack() as stack:
  for obj,key,replacement in ((rt,'Product',SyntheticProduct),(rt,'verify_build',lambda *a,**k:identity),(rt,'verify_receipt',lambda *a,**k:identity['build_identity']),
     (rt,'Raw',BudgetRaw),(rt,'MAX_RAW_BYTES',rt.MAX_RAW_BYTES),(rt,'time',SimpleNamespace(monotonic_ns=REAL_TIME.monotonic_ns,sleep=sleep))):
   stack.enter_context(mock.patch.object(obj,key,replacement))
  report=rt.run(args)
 assert budget_hit.is_set() and report['status']=='failed' and report['exit_code']==2
 missing_path=args.output/report['terminal_retention_failures'];missing=json.loads(missing_path.read_text())
 body_paths=[];retained_bytes=0
 for row in missing:
  assert 'response' not in row
  for i,call in enumerate(row.get('cache_probe',{}).get('requests',[])):
   if 'response' in call:
    body_paths.append(f"id{row['id']}.cache_probe.requests[{i}].response")
    retained_bytes+=len(json.dumps(call['response']).encode())
 target=next(r for r in missing if r['id']==guard[0]['id'])
 actual_calls=target['cache_probe']['requests']
 assert len(actual_calls)==len(guard[0]['metadata'])==4
 for actual,expected in zip(actual_calls,guard[0]['metadata']):
  assert all(actual.get(k)==v for k,v in expected.items()),'request metadata changed during sidecar projection'
 memory_response_count=sum('response' in c for c in guard[0]['row_reference']['cache_probe']['requests'])
 assert memory_response_count==4,'sidecar projection mutated in-memory original response records'
 assert all(r.get('raw_retention_error') for r in missing)
 assert 'runtime raw evidence budget exhausted' in missing[0]['raw_retention_error']
 assert report['cache_reuse']['passed'] is False and not (args.output/'statistics.json').exists()
 rt.verify_output(args.output);shutil.copytree(args.output,out/'original-run')
 result=dict(scope='Synthetic protocol responses only; actual Raw.emit guard and run sidecar path; no 512MiB allocation or native product run',runtime_sha256=hashlib.sha256((CANDIDATE/'scripts/p8_runtime.py').read_bytes()).hexdigest(),raw_limit=guard[0]['limit'],raw_bytes=(args.output/'raw.jsonl').stat().st_size,sidecar_bytes=missing_path.stat().st_size,terminal_rows=len(missing),nested_response_paths=body_paths,nested_response_bytes=retained_bytes,report_status=report['status'],report_exit_code=report['exit_code'],cache_passed=report['cache_reuse']['passed'],statistics_created=False,raw_seal_verified=True,defect_reproduced=bool(body_paths),request_metadata_preserved=True,in_memory_original_responses_preserved=memory_response_count)
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
finally:killed.set();helper.doCleanups()
