def stable_00123():
    return 123
