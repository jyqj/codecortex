import importlib.util, json, hashlib, sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('original_history',ROOT/'v15_historical_context.py')
h=importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
def api(name):
    data=json.loads((ROOT/name).read_text()); return json.loads(data['content'])
historical={}
for prefix,name in [('scripts','scripts'),('.github','github'),('tests','tests')]:
    data=api('BASE-'+name+'-tree-api.json'); assert not data['truncated']
    for e in data['tree']:
        path=prefix+'/'+e['path']
        if e['type']=='blob' and any(path==v or path.startswith(v+'/') for v in h.VALIDATION_ROOTS):
            assert e['mode'] in ('100644','100755')
            h.relative(path); historical[path]={**e,'path':path}
records=set(h.EXPLICIT_RECORDS); declared={}
for path in h.REGISTRIES:
    data=json.loads((ROOT/'registries'/Path(path).name).read_text())
    for p,r in data.get('records',{}).items():
        records.add(h.relative(p)); declared.setdefault(p,[]).append({'registry':path,'sha256':r['sha256'],'kind':'records'})
    for r in data.get('deltas',{}).values():
        p=h.relative(r['review_path']); records.add(p); declared.setdefault(p,[]).append({'registry':path,'sha256':r['review_sha256'],'kind':'deltas.review_sha256'})
names=set(historical)|records
protected=records|{p for p in names if p.startswith('tests/source_integrity/') or p.startswith('scripts/source_snapshots/') or (p.startswith('scripts/') and Path(p).name.startswith(('verify_','current-source-','reviewed-source-','v14_historical_'))) or p=='scripts/p0_historical_corpus.py'}
for p in sorted(names): h.relative(p)
for p,r in declared.items(): assert len(set(x['sha256'] for x in r))==1
out={'scope':'Input preparation only; not original CLI execution or current filesystem verification','current_head':'399a71a4c11e7041ce9946fba4d3f72200c47155','historical_head':h.HISTORICAL_HEAD,'helper_sha256':hashlib.sha256((ROOT/'v15_historical_context.py').read_bytes()).hexdigest(),'catalogue_count':len(names),'protected_count':len(protected),'records_count':len(records),'historical_validation_count':len(historical),'paths':sorted(protected),'all_catalogue_paths':sorted(names),'declared_hashes':declared,'historical_validation_entries':historical,'explicit_records':list(h.EXPLICIT_RECORDS)}
(ROOT/'protected-paths.initial.json').write_text(json.dumps(out,indent=2)+'\n')
(ROOT/'protected-paths.txt').write_text(''.join(p+'\n' for p in sorted(protected)))
print(json.dumps({k:out[k] for k in ['catalogue_count','protected_count','records_count','historical_validation_count']}))
print('path_list_sha256',hashlib.sha256((ROOT/'protected-paths.txt').read_bytes()).hexdigest())
