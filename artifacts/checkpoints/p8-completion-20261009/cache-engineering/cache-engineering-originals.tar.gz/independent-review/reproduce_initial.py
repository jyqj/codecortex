from pathlib import Path
import os,json,hashlib,subprocess,sys,copy
p=Path(__file__).resolve().parent
c=Path('/dev/shm/p8-soak-cache-candidate-G2')
os.environ['TMPDIR']=str(p/'tmp');os.environ['PYTHONDONTWRITEBYTECODE']='1'
sys.path.insert(0,str(c/'scripts'));sys.path.insert(0,str(c/'scripts/tests'))
import test_p8_runtime_cache as t
case=t.SoakCacheProtocolTests();case.setUp()
try:
 rows=case.complete_rows();ordinary=t.runtime.soak_cache_summary(rows,72,0,72_000_000_000,case.project)
 for row in rows:
  for key in ['started_ns','call_started_ns','finished_ns']:
   if key in row:
    old=row[key];row[key]=71_500_000_000+(old//1_000_000_000)*1000+old%1_000_000_000
  for call in row.get('cache_probe',{}).get('requests',[]):
   for key in ['started_ns','finished_ns']:
    old=call[key];call[key]=71_500_000_000+(old//1_000_000_000)*1000+old%1_000_000_000
 clustered=t.runtime.soak_cache_summary(rows,72,0,72_000_000_000,case.project)
 case.product=t.ProtocolProduct(case.project)
 probe=case.successful_probe()
 for call in [probe['requests'][0],probe['requests'][-1]]:
  outer=call['response'];diag=outer['diagnostics'];fresh=diag.pop('resolution_freshness');outer['resolution_freshness']=copy.deepcopy(fresh);diag['retrieval']['resolution_freshness']=copy.deepcopy(fresh)
 try: t.runtime.validate_cache_probe(probe,None,case.project);realshape={'accepted':True}
 except Exception as e: realshape={'accepted':False,'error':type(e).__name__+': '+str(e)}
 report={'scope':'explicit synthetic protocol reproductions; no product execution','candidate_sha256':hashlib.sha256((c/'scripts/p8_runtime.py').read_bytes()).hexdigest(),'normal_fixture_passed':ordinary['passed'],'all_actual_calls_final_quarter_but_offered_distributed':{'incorrectly_passed':clustered['passed'],'reported_quarters':clustered['time_quarters'],'minimum_actual_hybrid_start_ns':min(r['cache_probe']['requests'][2]['started_ns'] for r in rows if r['operation']=='read'),'maximum_actual_hybrid_finish_ns':max(r['cache_probe']['requests'][2]['finished_ns'] for r in rows if r['operation']=='read')},'actual_status_shape_contract':realshape,'prior_repro_harness_attempt':'Initial inline attempt reused already-warmed ProtocolProduct for fresh probe and stopped on expected-miss assertion; this script resets the explicit fake before that probe. No source/product ran in that failed harness attempt.'}
 (p/'initial-blockers.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
finally: case.doCleanups()
env=os.environ.copy();cmd=['python3','-B','-m','unittest','discover','-s','scripts/tests','-p','test_p8_runtime*.py','-v']
r=subprocess.run(cmd,cwd=c,env=env,capture_output=True);(p/'initial-controls.stdout').write_bytes(r.stdout);(p/'initial-controls.stderr').write_bytes(r.stderr)
print('CONTROL EXIT',r.returncode,r.stderr.decode().splitlines()[-4:]);print('REVIEW BYTES',sum(f.stat().st_size for f in p.rglob('*') if f.is_file()))
