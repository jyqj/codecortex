# Source-bound hotspot diagnosis and bounded optimization proposal

This is engineering analysis of two preserved peer shards. It does not certify our G matrix, change an original source identity, estimate a causal speedup, or close a TODO. No product execution or Cargo build was performed for this analysis. Both complete raw files passed the original G `inspect_raw` event/closure/15-table checks under their own recorded plans; build provenance was not fully re-admitted because the new peer executable was not downloaded.

The authoritative inputs are original ZIPs 11576387472 (6e3eb4f, 50,000 files, repetition 0) and 11577518538 (599a705, 10,000 files, repetition 0). `zip-member-verification.json` binds every original member. `analysis.json` contains exact integer timing/work sums and all stage breakdowns; `analyze.py` reproduces them. The data sets differ in scale and source. Their equal reported CPU/host strings do not establish a paired, controlled performance experiment.

## Actual attribution

| Original shard | Child wall | 10 full builds | Full staging, nested | Incremental builds | Incremental commit write, nested | 9 complete oracle comparisons |
|---|---:|---:|---:|---:|---:|---:|
| 6e3, 50k | 5793.327 s | 2029.192 s | 1579.716 s | 2156.365 s / 501 builds | 1759.799 s | 1582.866 s |
| 599, 10k | 450.011 s | 211.095 s | 157.718 s | 88.491 s / 105 builds | 61.311 s | 145.893 s |

Full staging is inside full prepare and is not another additive phase. Incremental commit write and scan are likewise inside incremental wall. The non-overlapping full/incremental/oracle/other fractions are 35.03/37.22/27.32/0.43 percent for the old 50k and 46.91/19.66/32.42/1.01 percent for the new 10k.

Old 50k batch-1000 alone took 1067.298 s; batch-100 took 113.598 s. The child-key `doc_key` index addresses a proved repeated FK scan in this incremental deletion path. It does not explain fresh full staging. Old 50k incremental prepare was only 266.732 s (4.60% of child wall), and scan_diff was 155.645 s (2.69%). The prepare-local prefix reuse remains a valid optimization but cannot plausibly explain most of this recorded shard's wall time.

The old 50k oracle comparisons execute 59,898,384 canonical row insertions and serialize 46,344,950,148 bytes cumulatively across nine independent comparisons. The new 10k executes 11,994,066 insertions and serializes 9,278,949,674 bytes. These cumulative values are not per-comparison limit exhaustion: every comparison retains its original 16 GiB cumulative allowance and 8 GiB scratch ceiling. Observed scratch maxima are 3,002,945,536 and 608,780,288 bytes respectively.

## Exact source boundary

`hotspot-source-map.json` compares sealed raw source manifest SHA-256 values with the exact local G/G2 Git blob bytes. Both oracle implementations, snapshot.rs, snapshot_write_txn.rs, index_db_rebuild.rs, index_db_write_batch.rs, index_db_multi_insert.rs, direct_writer.rs, document_store.rs, symbol_identity_store.rs and signature_agg.rs are identical across G, G2, old 6e3 and new 599. Cargo.toml and Cargo.lock are also identical. The scale driver Rust file differs only in the equivalent `is_some_and`/`is_none_or` lint expression between G/G2 and the peer sources. DDL and same-version maintenance differ only because 599 contains the reviewed child-key index.

## What the code already avoids

The canonical spool uses one transaction per side/table, a prepared INSERT, journal/synchronous OFF, and the primary WITHOUT ROWID B-tree to read exact serialized order. There is no per-row fsync and no additional ORDER BY temporary sort in the existing verified design. String-identical rows already bypass reparsing into Value; unequal serializations retain original Value equality, including signed zero. Source snapshots still execute full integrity_check and foreign_key_check.

Full staging already places all content writes in one transaction, uses synchronous OFF on the private staging DB, and drops then restores explicit indexes. Per-row durable commits are not its problem. The available raw timings do not divide staging into content insert, index restoration and close/checkpoint; similarly they do not divide oracle snapshot checks, projection/spool, ordered compare and cleanup. Those boundaries need measurement before attributing all time to one internal operation.

## First oracle candidate: bounded multi-row INSERT only

Keep `project_row`, serialized canonical bytes, row-size checks, aggregate canonical byte accounting, ordinal assignment, exact full-value primary key, sorted read SQL, Value equality, digests and all fifteen tables unchanged. Replace only the spool's repeated single-row execute with prepared multi-VALUES statements in a small fixed tier set (64/8/1 rows).

Use a bounded pending buffer, at most 64 KiB of serialized bytes and at most 64 rows; an original legal row larger than 64 KiB is inserted alone. This does not enlarge the 1 MiB individual row limit. Keep the original 2 MiB SQLite sorting page cache, mmap disabled, 8 GiB page-count limit, and unchanged capacity profile. A buffer is not another sort cache and must never reorder rows. Canonical bytes/count are checked as each row is read, before admission to the buffer; each original ordinal is retained. Flush before a byte/count boundary, at table end, and before an oversized-but-legal single row. Every failure remains an error with private scratch cleanup, never equality.

The largest statement binds 192 values, safely below the existing SQLite limit. Each row follows the same conflict-free `(side, value, ordinal)` insertion order, retaining every duplicate. The deterministic benefit is fewer SQLite statement executions. Overall speedup is unproved: B-tree insertion, I/O, projection, source checks and comparisons remain.

Necessary controls:

- Compare original single-row spool and candidate streams/digests/counts/Value results on identical fixtures, including 0/1/7/8/63/64/65 row boundaries, mixed row lengths crossing the byte boundary, and a legal oversized single row.
- Preserve duplicate multiplicity, different insertion orders, a missing duplicate, null/integer/real/text/blob projections, Unicode/escaping, and signed zero semantics; do not replace full Value equality with text/digest equality.
- Exact old row limit, individual row byte limit, aggregate canonical byte limit and real max_page_count exhaustion remain failures; pending unflushed rows cannot bypass accounting or produce a partial success.
- Existing EXPLAIN control continues to prove primary-key ordered reads without TEMP B-TREE. All original fifteen tables, full counts, integrity/FK checks, configured profile and canonical/scratch ceilings remain unchanged.
- Record actual executed statement counts and separate spool/compare/snapshot durations on one fixed-source engineering diagnostic. It is not N30 completion or a new SLA.

This candidate requires a small buffer and explicit accounting review; do not implement it until the root selects the design. No Rust has been changed here.

## Staging candidate: group index restoration commits

`execute_temp_db_staging_build` commits the content transaction, then calls `execute_batch(extract_index_statements(...))` without an explicit transaction. The accepted G schema contains 70 explicit CREATE INDEX statements, or 71 with the child-key index. SQLite therefore performs individual DDL autocommits during restoration, with corresponding opportunities for WAL automatic checkpoint work.

A narrow candidate wraps only this existing index restoration batch in one independent transaction, after the unchanged content commit. Keep the exact SQL/order, bulk pragmas, schema version, error propagation, restore/close, generation finalization and atomic publication protocol. It reduces DDL commit boundaries without moving logical writes across the live database fence. Any disk/busy/DDL failure remains a build error; no partial staging result is published.

The raw evidence does not prove restoration dominates staging. First measure content write, index restoration, pragma restoration and connection close separately on the existing implementation. A grouped index transaction may increase temporary WAL occupancy; it must remain within the unchanged registered disk preflight and measured capacity, not receive an automatic larger allowance.

Necessary controls are exact sqlite_schema plus complete table/FTS row parity, FK/integrity success, forced index-restoration failure leaving the live database/generation unchanged, original stale prepared-build and swap recovery/epoch controls, and an observer showing the intended restoration transaction is non-autocommit. Reuse original schema-guard target and rebuild canonical-schema tests. No request to change the 15-table acceptance surface or recovery rules is implied.

Do not blindly substitute the incremental `insert_file_units_batch` into full staging: it reads new chunk rowids through file_path IN batches after inserting all chunks, while staging deliberately drops `idx_chunks_file`. Reusing it without an access-path proof could introduce another repeated whole-chunk-table scan. Cross-file replace/identity association order also needs explicit equivalence evidence.

Both proposals are optional engineering implementations awaiting review. No original task is marked completed by this report; 29 original TODOs remain.
