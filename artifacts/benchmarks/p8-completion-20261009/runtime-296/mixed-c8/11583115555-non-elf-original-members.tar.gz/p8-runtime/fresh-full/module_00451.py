def stable_00451():
    return 451
