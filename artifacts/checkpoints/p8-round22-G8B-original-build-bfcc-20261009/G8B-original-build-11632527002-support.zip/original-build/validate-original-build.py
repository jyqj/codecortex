#!/usr/bin/env python3
"""Replay unchanged original validate_build + source-map identity, no measurement."""
from pathlib import Path
import datetime,hashlib,json,os,stat,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent/'round21-G8B-study-37962416564/source-exact-G8B-attempt02'
REVIEW=Path('/dev/shm/pr-triage-round21-P8B-source-review/final-R8B/independent-source-review.json')
TARGET='4fe927488d5cb7f26bd27c7624745fb1b6ca202b'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def main():
 sys.path.insert(0,str(ROOT/'scripts'));import p8_scale_matrix as m
 assert sha(ROOT/'scripts/p8_scale_matrix.py')=='f169b0f26cf2a87d3e2548d734431c530cbf63d353ac054045ec8be80889f957'
 assert sha(ROOT/'scripts/p7_build_identity.py')=='5003305105464936edf8f444fc0b93cd14a5d5f074dc650f16de2259e86f1cc5'
 dirs=[q.parent for q in (HERE/'intake-attempt01/extracted').rglob('build.json')];assert len(dirs)==1;build=dirs[0]
 before=m.inventory(build);binary=build/'p8-scale';binaryhash=sha(binary);mode_before=oct(stat.S_IMODE(binary.stat().st_mode));binary.chmod(stat.S_IMODE(binary.stat().st_mode)|0o111)
 write(HERE/'binary-executable-mode-receipt.json',{'binary':str(binary),'bytes':binary.stat().st_size,'sha256':binaryhash,'mode_before':mode_before,'mode_after':oct(stat.S_IMODE(binary.stat().st_mode)),'reason':'Execute original --hash-file helper required by unchanged validate_build; no measurement. Original ZIP untouched.'})
 record,preserved_binary=m.validate_build(build)
 assert record['source_commit']==TARGET
 snapshots=[m.read_json(build/n) for n in ('source-before.json','source-after.json')];assert snapshots[0]==snapshots[1]
 canonical=json.loads(REVIEW.read_text());assert canonical['source']=='44e6248106335b5f0625e53de38f76d26aeeadcf'
 assert snapshots[0]['inputs']==canonical['complete_inputs'] and len(snapshots[0]['inputs'])==1095
 assert snapshots[0]['source_commit']==TARGET and snapshots[0]['source_tree']=='d8891f547c92044fd40b63165d6ef54cb6de8bab'
 assert m.inventory(build)==before and sha(binary)==binaryhash
 transport=json.loads((HERE/'intake-attempt01/transport-receipt.json').read_text());assert transport['status']=='transport_received' and transport['official_digest_verified'] is True
 original=Path(transport['original_zip']['path']);assert sha(original)==transport['original_zip']['sha256']=='de07e97e358bf2ba24197276aba791fa94a78a9107df060fcdc7d3cce1ce0640'
 report={'schema':'original-G8B-build-independent-replay-v1','observed_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'original_validate_build_passed','source_G':TARGET,'product_P':canonical['source'],'review_R':'cb57d6e39f446e68ed5bd5bce26a7a76d1a26e5c','run_id':37962416564,'run_attempt':1,'artifact_id':11632527002,'build_directory':str(build),'build_receipt_sha256':sha(build/'build.json'),'source_manifest_sha256':record['source_manifest_sha256'],'source_before_after_equal':True,'all_1095_product_inputs_exactly_equal_canonical_R':True,'canonical_R_sha256':sha(REVIEW),'original_binary_sha256':record['binary_sha256'],'original_binary_blake3':record['binary_blake3'],'binary_bytes':record['binary_bytes'],'driver_source':record['driver_source'],'original_validate_build_unmodified':True,'original_native_hash_file_actually_executed':True,'original_bytes_inventory_before_after_equal':True,'ZIP_sha256':sha(original),'full_checkout_or_source_snapshot_root_claim':False,'sparse_checkout_scope':'Exact original Git commit/root/scripts tree plus two driver/helper files. Canonical1095 comparison uses the original source snapshots and independent R map.','new_measurements':0,'accepted_shards':0,'accepted_samples':0,'new_TODO_completions':0,'TODO_remaining':29}
 write(HERE/'original-validate-build-output.json',record);write(HERE/'independent-build-review.json',report);print(json.dumps(report))
if __name__=='__main__':main()
