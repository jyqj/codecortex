"""Read-only evidence verification; does not compile or run CodeCortex."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import tempfile

W = Path('/workspace/scratch/031390cf22eb')
REPO = W / 'codecortex-integration'
PRODUCT = 'df140ad1dc97f080afd748e9571b360e0cade5fe'
FIXED = '363de9201cc99faed793dda050874fb31afcde56'
REVIEW = 'b2a6c135444ef61d629cac1d739b120c8a3158d2'
OUT = W / 'validation-integration/scale-10k-independent-evidence-review.json'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def packed(value, sort=False):
    return json.dumps(value, ensure_ascii=False, sort_keys=sort, separators=(',', ':')).encode()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def source(ref):
    entries = []
    for row in git('ls-tree', '-r', '-z', ref, '--', 'crates', 'Cargo.toml', 'Cargo.lock').split(b'\0'):
        if not row:
            continue
        meta, path = row.split(b'\t')
        mode, kind, oid = meta.split()
        assert mode in (b'100644', b'100755') and kind == b'blob'
        entries.append((path.decode(), oid.decode()))
    raw = subprocess.check_output(['git', '-C', str(REPO), 'cat-file', '--batch'],
                                  input=''.join(oid + '\n' for _, oid in entries).encode())
    offset, contents = 0, {}
    for path, oid in entries:
        end = raw.index(b'\n', offset)
        header = raw[offset:end].split()
        assert header[:2] == [oid.encode(), b'blob']
        size = int(header[2])
        contents[path] = raw[end + 1:end + 1 + size]
        offset = end + 2 + size
    assert offset == len(raw)
    return {path: sha(body) for path, body in contents.items()}, contents


assert not OUT.exists(), 'Keep the existing frozen record; select a new additive output for another observation.'
fixed_inputs, _ = source(FIXED)
product_inputs, _ = source(PRODUCT)
assert fixed_inputs == product_inputs and len(fixed_inputs) == 798
hasher_source = '''use std::io::Read;
fn main() {
    let mut data = Vec::new();
    std::io::stdin().read_to_end(&mut data).expect("stdin");
    println!("{}", blake3::hash(&data).to_hex());
}
'''
records = {}
with tempfile.TemporaryDirectory(prefix='independent-b3-audit-') as temporary:
    temp = Path(temporary)
    (temp / 'digest.rs').write_text(hasher_source)
    env = dict(os.environ, RUSTUP_HOME=str(W / 'toolchains/rustup'),
               CARGO_HOME=str(W / 'cargo-cache'), RUSTUP_TOOLCHAIN='1.95.0')
    env['PATH'] = str(W / 'cargo-cache/bin') + ':' + env.get('PATH', '')
    command = [str(W / 'cargo-cache/bin/rustc'), '--edition=2021', str(temp / 'digest.rs'),
               '--extern', 'blake3=' + str(W / 'target-scale/debug/deps/libblake3-3137830a6319d942.rlib'),
               '-L', 'dependency=' + str(W / 'target-scale/debug/deps'), '-o', str(temp / 'digest')]
    subprocess.run(command, env=env, check=True, capture_output=True, timeout=60)

    def b3(raw):
        return subprocess.check_output([str(temp / 'digest')], input=raw).decode().strip()

    assert b3(b'') == 'af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262'
    for label in ['scale-10k-control', 'scale-10k-forwarding-fixed']:
        folder = W / 'validation-scale' / label
        receipt_path = W / 'validation-scale' / (label + '.json')
        receipt = json.loads(receipt_path.read_bytes())
        report = json.loads((folder / 'report.json').read_bytes())
        plan_raw = (folder / 'plan.json').read_bytes()
        plan = json.loads(plan_raw)
        raw = (folder / 'raw.jsonl').read_bytes()
        lines = [json.loads(line) for line in raw.splitlines()]
        assert raw.endswith(b'\n')
        start = next(row for row in lines if row['event'] == 'run_started')
        inp = next(row for row in lines if row['event'] == 'input')
        assert plan == start['plan']
        assert b3(plan_raw) == report['plan_digest'] and b3(raw) == report['raw_digest']
        assert report['max_output_bytes'] == plan['max_output_bytes'] > len(raw)
        assert report['exit_code'] == receipt['exit_code'] and report['worker_binary_unchanged'] is True
        assert report['worker_binary_digest_before'] == report['worker_binary_digest_after'] == start['engine']['binary_digest']
        assert receipt['source_unchanged'] is True and receipt['source_before'] == receipt['source_after']
        executed = receipt['source_before']['source_commit']
        assert executed == start['engine']['engine_head_observed']
        inputs, contents = source(executed)
        assert inputs == receipt['source_before']['inputs'] and len(inputs) == receipt['source_before']['input_count']
        assert b3(contents['Cargo.lock']) == start['engine']['cargo_lock_digest']
        source_rows = sorted([[path, b3(body)] for path, body in contents.items()
                              if path.startswith('crates/') and Path(path).suffix in ('.rs', '.toml')])
        assert b3(packed(source_rows)) == start['engine']['source_files_digest']
        # serde serializes FileRecord in declaration order: path, bytes, digest.
        # The raw JSON Value object is sorted, so restore that actual struct order.
        input_records = [{key: row[key] for key in ('path', 'bytes', 'digest')} for row in inp['files']]
        assert b3(packed(input_records)) == inp['input_digest']
        assert len(inp['files']) == len({row['path'] for row in inp['files']}) == 10001
        assert inp['synthetic_files_requested'] == inp['synthetic_files_written'] == 10000
        assert inp['auxiliary_visible_config_files'] == 1
        builds = []
        for row in lines:
            if row['event'] not in ('build_finished', 'build_failed'):
                continue
            build = {key: row[key] for key in ('event', 'full', 'label', 'start_us', 'end_us', 'wall_us')}
            assert build['wall_us'] == build['end_us'] - build['start_us']
            if row['event'] == 'build_finished':
                rep = row['report']
                keys = ('files_added', 'files_parsed', 'files_scanned', 'files_skipped', 'files_updated',
                        'files_removed', 'symbols_total', 'chunks_total', 'parse_errors', 'elapsed_ms',
                        'phase_timing', 'resolution_freshness', 'public_surface_coverage', 'resolution_coverage')
                build['report'] = {key: rep[key] for key in keys}
                assert rep['files_parsed'] == rep['files_added'] == rep['files_scanned'] == 10000
                assert rep['symbols_total'] == 55620 and rep['chunks_total'] == 63619 and not rep['parse_errors']
            else:
                build['error'] = row['error']
            builds.append(build)
        files = [receipt_path, W / 'validation-scale' / (label + '.log'),
                 *sorted(path for path in folder.iterdir() if path.is_file())]
        records[label] = {
            'receipt': {key: value for key, value in receipt.items() if key not in ('source_before', 'source_after', 'rustc')},
            'executed_source': {key: value for key, value in receipt['source_before'].items() if key != 'inputs'},
            'report': report, 'plan': plan, 'plan_file_sha256': sha(plan_raw),
            'input': {key: value for key, value in inp.items() if key != 'files'},
            'input_files_count': len(inp['files']), 'input_files_canonical_sha256': sha(packed(inp['files'], sort=True)),
            'raw_line_count': len(lines), 'events': dict(Counter(row['event'] for row in lines)),
            'builds': builds, 'raw_engine': start['engine'],
            'hashes_verified': {
                'report_plan_blake3': True, 'report_raw_blake3': True, 'binary_before_after_and_raw_match': True,
                'complete_executed_source_matches_receipt_sha256': True,
                'raw_source_digest_matches_immutable_git_rs_toml': True, 'cargo_lock_blake3': True,
                'input_inventory_blake3_with_actual_struct_field_order': True},
            'files': {str(path.relative_to(W)): {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())} for path in files}}

    before, after = records['scale-10k-control'], records['scale-10k-forwarding-fixed']
    assert before['plan'] == after['plan'] and before['plan_file_sha256'] == after['plan_file_sha256']
    assert before['input'] == after['input'] and before['input_files_canonical_sha256'] == after['input_files_canonical_sha256']
    assert before['report']['exit_code'] == 2 and before['report']['status'] == 'measurement_failed'
    assert 'reexport_file_budget_exceeded' in before['builds'][0]['error']
    assert after['report']['exit_code'] == 3 and after['report']['status'] == 'deadline_exceeded'
    assert after['report']['summary'] is None
    assert len(after['builds']) == 2 and all(row['event'] == 'build_finished' and row['full'] for row in after['builds'])
    assert not any(name in after['events'] for name in ('cold_parity', 'run_completed', 'summary'))
    build_path = W / 'validation-scale/forwarding-scale-build.json'
    build_receipt = json.loads(build_path.read_bytes())
    assert build_receipt['source_before']['source_commit'] == FIXED and build_receipt['source_before']['inputs'] == fixed_inputs
    assert build_receipt['source_unchanged'] is True and build_receipt['exit_code'] == 0
    assert b3((W / 'target-scale/debug/p8-scale').read_bytes()) == after['raw_engine']['binary_digest']

review_path = 'artifacts/checkpoints/p8-oracle-compat-20261008/independent-source-review.json'
review_blob = git('show', REVIEW + ':' + review_path)
assert review_blob == (W / 'validation-integration/independent-source-review-df140ad1.json').read_bytes()
review_json = json.loads(review_blob)
assert review_json['source'] == PRODUCT and review_json['verdict'] == 'accepted_scoped' and review_json['unresolved_blockers'] == []
record = {
    'schema_version': 1, 'record_type': 'independent_original_and_repeated_10k_raw_evidence_review',
    'created_utc': datetime.now(timezone.utc).isoformat(), 'reviewer': '/root/pr_audit',
    'verdict': 'evidence_consistent_control_not_completed', 'product': PRODUCT, 'review': REVIEW,
    'review_record_path': review_path, 'review_record_sha256': sha(review_blob),
    'review_commit_matches_frozen_independent_review': True,
    'original_and_repeated_plan_identical': True, 'original_and_repeated_input_inventory_identical': True,
    'run_records': records,
    'fixed_source_continuity': {
        'executed_source': FIXED, 'product': PRODUCT, 'domain': ['crates/**', 'Cargo.toml', 'Cargo.lock'],
        'input_count': 798, 'all_input_paths_and_sha256_equal': True, 'complete_inputs': fixed_inputs,
        'receipt_manifest_sha256': build_receipt['source_before']['manifest_sha256'],
        'execution_build_receipt': str(build_path), 'execution_build_receipt_sha256': sha(build_path.read_bytes()),
        'built_binary_still_matches_raw_blake3': True},
    'independent_digest_audit': {
        'algorithm': 'BLAKE3 using a temporary standalone stdin hasher linked to the existing blake3 crate; empty-vector known digest checked',
        'source': hasher_source, 'source_sha256': sha(hasher_source.encode()),
        'audit_script_sha256': sha(Path(__file__).read_bytes()), 'compiled_or_executed_product_again': False},
    'conclusion': [
        'Original failure is retained: reexport_file_budget_exceeded during first cold full build, exit 2, 23.633 seconds.',
        'After the minimal forwarding correction, both cold full builds process 10000 files and produce 55620 symbols and 63619 chunks, with no parse errors.',
        'The repeated control still exceeded its fixed 300000 ms deadline: exit 3, deadline_exceeded, null summary. No completed cold parity or scale matrix exists.',
        'Individual build resolution_freshness.complete=true does not establish control completion, oracle equality or P8 TODO completion.',
        'All 798 immutable executed source inputs at 363de920 equal published PRODUCT. The distinct actual execution identity is preserved.'],
    'todo_completion_claims': [], 'full_100k_certification': 'not_run', 'release_certification': 'not_run',
    'limitations': [
        'The supervisor cleaned the fixture. This review verifies retained raw inventory equality and cryptographic binding, not a fresh regeneration.',
        'The last event is the second full build finishing. Source order places cold parity next, but no parity result was retained. Raw evidence does not establish the exact interrupted internal operation.',
        'The earlier failed binary was superseded by the recorded rebuild. Its historical report/raw digests agree; the current corrected binary was independently hashed.'],
    'product_file_mutations': [], 'unresolved_evidence_blockers': []}
OUT.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': str(OUT), 'sha256': sha(OUT.read_bytes()), 'verdict': record['verdict'],
                  'source_count': 798, 'input_files_each': 10001, 'before_exit': 2, 'after_exit': 3,
                  'builds_after': 2, 'all_blake3_checks_passed': True}, indent=2))
