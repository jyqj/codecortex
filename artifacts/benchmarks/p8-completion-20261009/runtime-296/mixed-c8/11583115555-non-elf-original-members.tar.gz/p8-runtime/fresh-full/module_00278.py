def stable_00278():
    return 278
