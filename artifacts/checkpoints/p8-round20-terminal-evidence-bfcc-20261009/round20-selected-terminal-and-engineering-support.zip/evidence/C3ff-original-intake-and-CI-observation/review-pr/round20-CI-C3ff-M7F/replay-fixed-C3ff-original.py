#!/usr/bin/env python3
"""Read-only replay of immutable C3ff evidence functions; no workload or ELF execution."""
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
SOURCE = '3ffcefc3b28ee1a4ed80caecebd7208a45c3e302'
sys.dont_write_bytecode = True
sys.path.insert(0, str(BASE / 'source/scripts'))
EXPECTED = {
    'p8_scale_matrix.py': ('f169b0f26cf2a87d3e2548d734431c530cbf63d353ac054045ec8be80889f957', 'b4ba4b57f8d23a16128ef82927e78799ae70f886'),
    'p7_build_identity.py': ('5003305105464936edf8f444fc0b93cd14a5d5f074dc650f16de2259e86f1cc5', '4f2213705984effd6aa3cdb75a99cbb03a08c39e'),
}
for name, (sha256, git_blob) in EXPECTED.items():
    data = (BASE / 'source/scripts' / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == sha256
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == git_blob
import p8_scale_matrix as original

directory = BASE / 'raw/11626430756/attempt01/extracted'
record = original.read_json(directory / 'shard.json')
plan = original.read_json(directory / 'registered-plan.json')
mode = sys.argv[1]
if mode == 'validate_shard':
    print(json.dumps({'scope': 'original validate_shard first gate only; failed record rejects before build_record/binary use', 'source': SOURCE, 'build_record': None, 'binary': None}), flush=True)
    original.validate_shard(directory, None, None, record['build_receipt_sha256'])
elif mode == 'inspect_raw':
    print(json.dumps({'scope': 'original complete raw-coverage replay on retained failed raw, not a new measurement', 'source': SOURCE}), flush=True)
    print(json.dumps(original.inspect_raw(directory / 'native/raw.jsonl', plan), sort_keys=True))
elif mode == 'integrity':
    assert record['source_commit'] == SOURCE
    actual_inventory = original.inventory(directory, ('shard.json',))
    assert original.exact_equal(actual_inventory, record['files'])
    before = original.read_json(directory / 'source-before.json')
    after = original.read_json(directory / 'source-after.json')
    original.validate_snapshot(before)
    assert original.exact_equal(before, after)
    assert before['source_commit'] == SOURCE and before['manifest_sha256'] == record['source_manifest_sha256']
    expected_plan = original.registered_plan(100000, 0, 30, 30, 12648430, 18000000, original.CAPACITY_PROFILE)
    assert original.exact_equal(plan, expected_plan)
    assert original.exact_equal(plan, record['plan'])
    assert original.exact_equal(plan, original.read_json(directory / 'native/plan.json'))
    assert original.exact_equal(record['capacity_contract'], original.capacity_contract())
    driver_inputs = {'scripts/' + name: digest[0] for name, digest in EXPECTED.items()}
    assert record['driver_source']['source_commit'] == SOURCE
    assert record['driver_source']['inputs'] == driver_inputs
    assert hashlib.sha256(original.json_bytes(driver_inputs)).hexdigest() == record['driver_source']['manifest_sha256']
    preflight = original.read_json(directory / 'disk-preflight.json')
    required = 100000 * original.capacity_contract()['minimum_free_bytes_per_file'] + original.capacity_contract()['minimum_free_fixed_bytes']
    assert preflight['passed'] is True and preflight['required_free_bytes'] == required and preflight['available_bytes'] >= required
    assert record['temporary_environment'] == {key: preflight['temporary_root'] for key in ('TMPDIR', 'TMP', 'TEMP')}
    report = original.read_json(directory / 'native/report.json')
    assert (directory / 'native/report.json').read_bytes() == (directory / 'supervisor.stdout').read_bytes()
    assert report['status'] == 'deadline_exceeded' and report['exit_code'] == 3
    assert report['worker_exit_code'] is None and report['stderr_complete'] is False and report['summary'] is None
    assert not (directory / 'native/worker-summary.json').exists()
    print(json.dumps({'scope': 'seal/source/registered-plan integrity only; failed shard remains rejected', 'source': SOURCE,
        'source_tree': before['source_tree'], 'input_count': before['input_count'],
        'source_manifest_sha256': before['manifest_sha256'], 'source_snapshots_byte_equal': (directory / 'source-before.json').read_bytes() == (directory / 'source-after.json').read_bytes(),
        'sealed_file_count': len(actual_inventory), 'registered_plan_exact': True, 'driver_source_exact': True,
        'disk_preflight_record': preflight, 'native_report': report, 'native_summary_exists': False,
        'native_worker_stderr_bytes': (directory / 'native/worker.stderr').stat().st_size,
        'full_build_record_or_ELF_revalidated': False,
        'measurement_acceptance': False}, sort_keys=True, indent=2))
else:
    raise ValueError('unsupported mode')
