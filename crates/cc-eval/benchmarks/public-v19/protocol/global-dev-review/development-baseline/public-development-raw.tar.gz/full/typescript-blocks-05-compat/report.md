# CodeCortex benchmark baseline

Suite: `V19 TypeScript 05 oce-compat-v1 candidate; review/custody pending`
Adapter: `mcp-stdio`
Scoring: `OceCompat`
Measurement profile: `quality`

Status: **gate_failed** (exit 1)

Queries: 11; measured rows: 33.
Mean Top-1: 0.818182; mean nDCG@10: 0.805668.

These are baseline observations, not a release quality certificate.
Latency: Distribution { samples: 0, p50_us: None, p95_us: None, max_us: None, tail_claim: "insufficient_for_tail_claim" }; samples are retained, not best-of.
Source evidence: 0 invalid, 0 unverified hits.

| Case | Top-1 | nDCG@10 | Repetitions |
|---|---:|---:|---:|
| v19.typescript.f0082.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0083.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0084.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0089.en01 | 0.000000 | 0.630930 | 3 |
| v19.typescript.f0090.en01 | 0.000000 | 0.630930 | 3 |
| v19.typescript.f0091.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0093.en01 | 1.000000 | 0.840303 | 3 |
| v19.typescript.f0094.en01 | 1.000000 | 0.380094 | 3 |
| v19.typescript.f0095.en01 | 1.000000 | 0.380094 | 3 |
| v19.typescript.f0096.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0097.en01 | 1.000000 | 1.000000 | 3 |

## Failures

- v19.typescript.f0093.en01 Partial
- v19.typescript.f0083.en01 Partial
- v19.typescript.f0091.en01 Partial
- v19.typescript.f0089.en01 Partial
- v19.typescript.f0094.en01 Partial
- v19.typescript.f0096.en01 Partial
- v19.typescript.f0084.en01 Partial
- v19.typescript.f0082.en01 Partial
- v19.typescript.f0090.en01 Partial
- v19.typescript.f0097.en01 Partial
- v19.typescript.f0095.en01 Partial
- v19.typescript.f0090.en01 Partial
- v19.typescript.f0082.en01 Partial
- v19.typescript.f0083.en01 Partial
- v19.typescript.f0094.en01 Partial
- v19.typescript.f0084.en01 Partial
- v19.typescript.f0096.en01 Partial
- v19.typescript.f0097.en01 Partial
- v19.typescript.f0089.en01 Partial
- v19.typescript.f0093.en01 Partial
- v19.typescript.f0095.en01 Partial
- v19.typescript.f0091.en01 Partial
- v19.typescript.f0089.en01 Partial
- v19.typescript.f0091.en01 Partial
- v19.typescript.f0096.en01 Partial
- v19.typescript.f0094.en01 Partial
- v19.typescript.f0084.en01 Partial
- v19.typescript.f0082.en01 Partial
- v19.typescript.f0090.en01 Partial
- v19.typescript.f0097.en01 Partial
- v19.typescript.f0095.en01 Partial
- v19.typescript.f0083.en01 Partial
- v19.typescript.f0093.en01 Partial