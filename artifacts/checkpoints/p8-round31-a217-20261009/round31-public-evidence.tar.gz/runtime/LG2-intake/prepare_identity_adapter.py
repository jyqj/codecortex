#!/usr/bin/env python3
"""Copy the admitted LG intake with only the observed G2 identity substituted."""
import ast
import datetime
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys

B = Path('/workspace/scratch/a217aaae3bde')
OLD = B / 'original-LG-runtime'
OUT = B / 'original-LG2-runtime'
HELPERS = OUT / 'helpers-LG2-v1'
VIEW = B / 'p8-lock-observation-P2-validated'
HEAD = '4d18dcdb34b5d7a277566b57801cc882d8b1eb61'
RUN = 37930392164
MANIFEST = '32368b4a21bd1fec7a63a23b431f6295363e8163ac50e04d06fcc8a16df8445d'


def identity(path, raw=None):
    raw = path.read_bytes() if raw is None else raw
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                git_blob=hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest())


def save(path, value):
    path.open('xb').write((json.dumps(value, sort_keys=True, indent=2) + '\n').encode())
    return identity(path)


def main():
    assert not HELPERS.exists()
    HELPERS.mkdir()
    oldmanifest = json.loads((OLD / 'frozen-helper-manifest.json').read_bytes())
    oldrecords = {Path(r['path']).name: r for r in oldmanifest['files']}
    files = []
    for name in ['review_e_runtime_original.py', 'e_raw_cache_audit.py',
                 'preflight_e_runtime_zip.py', 'lg_counter_audit.py']:
        src = OLD / 'helpers-LG-v2' / name
        raw = src.read_bytes()
        assert identity(src) == oldrecords[name]
        edits = []
        if name == 'e_raw_cache_audit.py':
            edits = [dict(old="HEAD = '18255c53b7fa153bb71c96f57f1b97ca139e427f'", new="HEAD = '" + HEAD + "'", expected_matches=1),
                     dict(old='RUN = 37919399759', new='RUN = ' + str(RUN), expected_matches=1),
                     dict(old="PRODUCT_MANIFEST = '11b8922962005ba5feb55d8c998d815db93825c84a24052054ab02eddead0f65'", new="PRODUCT_MANIFEST = '" + MANIFEST + "'", expected_matches=1)]
        text = raw.decode()
        for edit in edits:
            assert text.count(edit['old']) == edit['expected_matches']
            text = text.replace(edit['old'], edit['new'])
        reverse = text
        for edit in reversed(edits):
            assert reverse.count(edit['new']) == edit['expected_matches']
            reverse = reverse.replace(edit['new'], edit['old'])
        assert reverse.encode() == raw
        before_ast = ast.parse(raw)
        after_ast = ast.parse(text)
        before_predicates = [ast.dump(n, include_attributes=False) for n in ast.walk(before_ast) if isinstance(n, ast.Assert)]
        after_predicates = [ast.dump(n, include_attributes=False) for n in ast.walk(after_ast) if isinstance(n, ast.Assert)]
        assert before_predicates == after_predicates
        dst = HELPERS / name
        dst.open('xb').write(text.encode())
        diff = ''.join(difflib.unified_diff(raw.decode().splitlines(True), text.splitlines(True),
                                          fromfile='LG/' + name, tofile='LG2/' + name))
        (HELPERS / (name + '.diff')).open('xb').write(diff.encode())
        files.append(dict(before=identity(src), after=identity(dst), edits=edits,
                          unchanged_assert_count=len(after_predicates),
                          reverse_bytes_and_ast_equal=True))
    assert subprocess.check_output(['git', '-C', str(VIEW), 'rev-parse', 'HEAD'], text=True).strip() == HEAD
    sys.path.insert(0, str(VIEW / 'scripts'))
    import p8_runtime_build as owner
    source = owner.source_snapshot(VIEW)
    observers = owner.observer_snapshot(VIEW)
    assert source['source_commit'] == observers['source_commit'] == HEAD
    assert source['input_count'] == len(source['inputs']) == 1094 and source['manifest_sha256'] == MANIFEST
    assert len(observers['files']) == 10 and set(observers['files']) == set(owner.OBSERVER_FILES)
    oldproof = json.loads((OLD / 'source-and-observer-proof.json').read_bytes())
    assert observers['files'] == oldproof['observer']['files']
    product = json.loads((B / 'p8-db-lock-observation-integration/LG2-actual-P2-proof-v2/product-domain.json').read_bytes())
    assert source['inputs'] == product
    sourceproof = save(OUT / 'source-and-observer-proof.json',
                       dict(source=source, observer=observers, root=str(VIEW),
                            previous_observer_bytes_exact=True, previous_source=oldproof['source']['source_commit'],
                            scope='Actual fixed G2 filesystem/Git input identity only; no native or original-artifact acceptance.',
                            task_complete=False, todo_done=163, todo_remaining=29))
    plan = json.loads((OLD / 'intake-plan.json').read_bytes())
    oldplan = json.loads(json.dumps(plan))
    replacements = [('18255c53b7fa153bb71c96f57f1b97ca139e427f', HEAD),
                    ('11b8922962005ba5feb55d8c998d815db93825c84a24052054ab02eddead0f65', MANIFEST),
                    ('/workspace/scratch/a217aaae3bde/p8-lock-observation-validated', str(VIEW)),
                    ('/workspace/scratch/a217aaae3bde/original-LG-runtime/helpers-LG-v2', str(HELPERS))]
    def replace(value):
        if isinstance(value, dict):
            return {k: replace(v) for k, v in value.items()}
        if isinstance(value, list):
            return [replace(v) for v in value]
        if isinstance(value, str):
            for a, b in replacements:
                value = value.replace(a, b)
            return value
        return value
    plan = replace(plan)
    plan.update(run=RUN, event='push', tree='383716945d2d5f2404578d726afb317e4490c181',
                schema='LG2-four-mixed-original-intake-plan-v1')
    assert plan['operations_each'] == oldplan['operations_each'] == 900
    assert plan['files_each'] == oldplan['files_each'] == 1000
    assert plan['offer_interval_ms'] == oldplan['offer_interval_ms'] == 500
    assert plan['configured_C'] == oldplan['configured_C'] == [1, 4, 8, 16]
    planref = save(OUT / 'intake-plan.json', plan)
    manifest = dict(schema='LG2-identity-only-intake-adaptation-v1', head=HEAD, run=RUN, attempt=1,
                    event='push', source_inputs=1094, source_manifest=MANIFEST, observer_count=10,
                    created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    original_frozen_manifest=identity(OLD / 'frozen-helper-manifest.json'),
                    original_peer=identity(OLD / 'LG-runtime-helper-independent-review.json'),
                    files=files, source_and_observer_proof=sourceproof, plan=planref,
                    unchanged_runtime_asserts=89, unchanged_shared_asserts=46,
                    unchanged_preflight_asserts=12, unchanged_counter_asserts=17,
                    original_C_runtime_87_predicates_retained_by_previous_admission=True,
                    synthetic_controls='not_repeated', native_or_original_artifact_execution='not_run',
                    old_helpers_unchanged=True, review_status='awaiting_identity_only_peer',
                    formal_task_completion=False, todo_done=163, todo_remaining=29)
    print(json.dumps(save(OUT / 'identity-adaptation-manifest.json', manifest)), flush=True)


if __name__ == '__main__':
    main()
