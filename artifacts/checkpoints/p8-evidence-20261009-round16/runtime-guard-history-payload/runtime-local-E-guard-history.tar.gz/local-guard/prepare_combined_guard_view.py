#!/usr/bin/env python3
"""Prepare actual fixed Git inputs in a private required-file projection."""
import datetime
import hashlib
import itertools
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

META=Path('/workspace/scratch/a217aaae3bde/combined-scale-cache-candidate')
OLD=Path('/dev/shm/a217aaae3bde/codecortex-round6-frozen')
ROOT=Path('/dev/shm/a217aaae3bde/codecortex')
PRIOR=Path('/dev/shm/a217aaae3bde/prospective-combined-tree-prep/checkout')
VIEW=Path('/dev/shm/a217aaae3bde/codecortex-combined-guard-view')
OUT=Path(__file__).parent/'guard-view-preparation'
PRODUCT='254009277688d64677361a0ca33e5dea73f295ef'
REVIEW='3a11f30f9f00a89fe3cd481b3b7609066728baad'
assert not VIEW.exists()
OUT.mkdir(exist_ok=False)

def sha(raw):return hashlib.sha256(raw).hexdigest()
def oid(kind,raw):return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def j(path):return json.loads(path.read_bytes())
def save(name,value):
    raw=(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
    (OUT/name).write_bytes(raw);return dict(path=str(OUT/name),bytes=len(raw),sha256=sha(raw))
def git(*args,data=None,cwd=VIEW):return subprocess.check_output(['git',*args],cwd=cwd,input=data)
def store(kind,raw,expected=None):
    found=oid(kind,raw)
    if expected:assert found==expected,(kind,found,expected)
    assert git('hash-object','-t',kind,'-w','--stdin',data=raw).decode().strip()==found
    return found
def tree(entries,expected=None):
    rows=sorted(entries,key=lambda e:(e['path']+('/' if e['type']=='tree' else '')).encode())
    raw=b''.join(e['mode'].lstrip('0').encode()+b' '+e['path'].encode()+b'\0'+bytes.fromhex(e['sha']) for e in rows)
    return store('tree',raw,expected)
def import_tree(metadata):
    assert metadata['truncated'] is False
    rows=metadata['tree']; dirs={'':metadata['sha'],**{e['path']:e['sha'] for e in rows if e['type']=='tree'}}
    for directory,expected in sorted(dirs.items(),key=lambda x:x[0].count('/'),reverse=True):
        children=[dict(e,path=e['path'].rpartition('/')[2]) for e in rows if e['path'].rpartition('/')[0]==directory]
        tree(children,expected)
    return len(dirs)
def commit_obj(meta):
    assert not meta['verification']['signature']
    header='tree '+meta['tree']['sha']+'\n'+''.join('parent '+p['sha']+'\n' for p in meta['parents'])
    for oa,oc,end in itertools.product(['+0000','+0800'],['+0000','+0800'],['','\n']):
        parts=[header]
        for kind,off in [('author',oa),('committer',oc)]:
            d=meta[kind];ts=int(datetime.datetime.fromisoformat(d['date'].replace('Z','+00:00')).timestamp())
            parts.append(f'{kind} {d["name"]} <{d["email"]}> {ts} {off}\n')
        raw=(''.join(parts)+'\n'+meta['message']+end).encode()
        if oid('commit',raw)==meta['sha']:
            store('commit',raw,meta['sha']);return dict(sha=meta['sha'],bytes=len(raw),sha256=sha(raw),author_offset=oa,committer_offset=oc,added_final_newline=bool(end))
    raise AssertionError('exact official commit bytes not reconstructible')
def entries(ref,paths=()):
    result={}
    for row in git('ls-tree','-r','-z',ref,'--',*paths).split(b'\0'):
        if row:
            md,p=row.decode().split('\t',1);mode,kind,blob=md.split()
            result[p]=dict(mode=mode,type=kind,sha=blob)
    return result
def direct_tree(ref):
    result={}
    for row in git('ls-tree','-z',ref).split(b'\0'):
        if row:
            md,p=row.decode().split('\t',1);mode,kind,blob=md.split()
            result[p]=dict(path=p,mode=mode,type=kind,sha=blob)
    return result
def overlay_tree(base,changes):
    rows=direct_tree(base) if base else {}
    grouped={}
    for p,e in changes.items():
        top,sep,tail=p.partition('/')
        if sep:grouped.setdefault(top,{})[tail]=e
        else:rows[top]=dict(e,path=top)
    for top,children in grouped.items():
        before=rows.get(top)
        assert before is None or before['type']=='tree'
        rows[top]=dict(path=top,mode='040000',type='tree',sha=overlay_tree(before['sha'] if before else None,children))
    return tree(list(rows.values()))

overlay=j(META/'prepared-source-overlay.json')
expected=j(OUT.parent/'independent-git-inputs.json')
base_head=git('rev-parse','HEAD',cwd=ROOT).decode().strip()
base_index=Path(git('rev-parse','--path-format=absolute','--git-path','index',cwd=ROOT).decode().strip())
base_index_sha=sha(base_index.read_bytes())
primary=set(expected['complete_inputs'])|set(expected['validation_inputs'])|{'scripts/verify_reviewed_source_v15.py','scripts/reviewed-source-registry-v15.json','.github/workflows/ci.yml'}
sources={p:(META/'overlay'/p if (META/'overlay'/p).is_file() else OLD/p) for p in primary}
required=sum(p.stat().st_size for p in sources.values())
free=shutil.disk_usage(VIEW.parent).free
assert free>required+64*1024*1024
save('preflight.json',dict(allocated_primary_bytes=required,free_bytes=free,private_object_allowance_bytes=64*1024*1024,primary_count=len(primary),scope='Required input projection, not complete candidate checkout'))
VIEW.mkdir();subprocess.run(['git','init','-q',str(VIEW)],check=True)
alternates=[str(Path(git('rev-parse','--path-format=absolute','--git-path','objects',cwd=PRIOR).decode().strip())),str(ROOT/'.git/objects')]
(VIEW/'.git/objects/info/alternates').write_text('\n'.join(alternates)+'\n')
for k,v in [('core.autocrlf','false'),('core.filemode','true'),('gc.auto','0')]:git('config',k,v)
tree(j(META/'official-product-root-tree.json')['tree'],expected['source_tree'])
tree_counts={p:import_tree(j(META/f'official-product-{p}-recursive.json')) for p in ['crates','scripts']}
commits=[commit_obj(j(META/'official-product-commit.json'))]
for p,e in overlay['changes'].items():store('blob',Path(e['source_path']).read_bytes(),e['git_blob'])
# Review adds only exact original proof files. Rebuild its tree over product tree.
review_info=j(META/'review-commit-created.json')
review_changes={}
for e in review_info['entries']:
    raw=(META/'review-payload'/e['path']).read_bytes()
    store('blob',raw,e['sha']);review_changes[e['path']]=dict(mode=e['mode'],type=e['type'],sha=e['sha'])
actual_review_tree=overlay_tree(expected['source_tree'],review_changes)
assert actual_review_tree==review_info['review_tree']
official_review=j(META/'official-review-commit.json')
assert official_review['sha']==REVIEW and official_review['tree']['sha']==actual_review_tree
commits.append(commit_obj(official_review))
(VIEW/'.git/HEAD').write_text(PRODUCT+'\n')
selected=entries(PRODUCT,('crates','Cargo.toml','Cargo.lock','scripts','.github/workflows','tests/source_integrity'))
assert primary <= set(selected)
records={}
for p in sorted(primary):
    e=selected[p];raw=sources[p].read_bytes()
    assert e['type']=='blob' and e['mode'] in ('100644','100755') and oid('blob',raw)==e['sha']
    assert git('cat-file','blob',e['sha'])==raw
    target=VIEW/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    target.chmod(0o555 if e['mode']=='100755' else 0o444)
    records[p]=dict(mode=e['mode'],git_blob=e['sha'],bytes=len(raw),sha256=sha(raw),origin=str(sources[p]),materialization='independent readonly copy')
# Enumerate original historical protection reads without changing/executing the proof.
sys.dont_write_bytecode=True;sys.path.insert(0,str(VIEW/'scripts'))
import v15_historical_context as hist
blobs,protected=hist.catalogue()
closure=j(Path('/workspace/scratch/a217aaae3bde/prospective-combined-tree-prep/historical-v2-complete-read-closure.json'))
extra=set(protected)|{x['path'] for x in closure['current_files']}|set(review_changes)
for p in sorted(extra-primary):
    e=entries(REVIEW,(p,))
    assert set(e)=={p},p
    e=e[p];assert e['type']=='blob' and e['mode'] in ('100644','100755')
    candidates=[META/'review-payload'/p,PRIOR/p,ROOT/p]
    source=next((s for s in candidates if s.is_file() and not s.is_symlink() and oid('blob',s.read_bytes())==e['sha']),None)
    assert source is not None,('missing real exact current record',p,e['sha'])
    raw=source.read_bytes();assert git('cat-file','blob',e['sha'])==raw
    if p in protected:assert raw==blobs[p]
    target=VIEW/p;target.parent.mkdir(parents=True,exist_ok=True)
    same_device=source.stat().st_dev==target.parent.stat().st_dev
    if same_device:os.link(source,target)
    else:target.write_bytes(raw);target.chmod(0o555 if e['mode']=='100755' else 0o444)
    records[p]=dict(mode=e['mode'],git_blob=e['sha'],bytes=len(raw),sha256=sha(raw),origin=str(source),materialization='readonly hardlink; never edit inode' if same_device else 'independent readonly copy',device=target.stat().st_dev,inode=target.stat().st_ino)
# Index real materialized files only. This does not assert a complete checkout.
index=''.join(f'{r["mode"]} {r["git_blob"]}\t{p}\n' for p,r in sorted(records.items()))
git('update-index','--index-info',data=index.encode())
assert git('remote')==b''
import p7_build_identity,p8_runtime_build
source=p7_build_identity.source_snapshot(VIEW);observer=p8_runtime_build.observer_snapshot(VIEW)
assert source['source_commit']==PRODUCT and source['inputs']==expected['complete_inputs']
assert source['manifest_sha256']=='4e0aa6bbfd4d5bea00416bca2cd99318d865ffc526fdcb45897c4d300de3ac00'
assert len(observer['files'])==9 and observer['source_commit']==PRODUCT
assert source['input_count']==1087
assert base_head==git('rev-parse','HEAD',cwd=ROOT).decode().strip() and sha(base_index.read_bytes())==base_index_sha
save('source-snapshot-product.json',source);save('observer-snapshot-product.json',observer)
save('materialized-files-product.json',records)
save('v15-current-protection-read-set.json',{p:sha(blobs[p]) for p in sorted(protected)})
receipt=dict(status='prepared_product_view_waiting_final_execution_head',product=PRODUCT,review=REVIEW,view=str(VIEW),source_input_count=1087,validation_input_count=138,observer_count=9,materialized_count=len(records),materialized_logical_bytes=sum(x['bytes'] for x in records.values()),copied_bytes=sum(x['bytes'] for x in records.values() if x['materialization']=='independent readonly copy'),historical_catalogue_count=len(blobs),historical_catalogue_bytes=sum(map(len,blobs.values())),historical_protected_count=len(protected),v2_original_current_read_count=len(closure['current_files']),commits_reconstructed=commits,tree_counts=tree_counts,alternates_readonly=alternates,root_head=base_head,root_index_sha256=base_index_sha,root_unchanged=True,remotes_configured=False,complete_checkout_claim=False,guard_executed=False,native_executed=False,task_statuses_changed=False,done=163,remaining=29)
print(json.dumps(save('preparation-receipt.json',receipt),indent=2))
