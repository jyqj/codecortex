import hashlib, json, sys, zipfile
from pathlib import Path

ROOT=Path('/workspace/scratch/bfccb8494ba0')
tag=sys.argv[1]
OUT=ROOT/f'round46-{tag}-100k-independent-review'
src=ROOT/f'round46-{tag}-100k-original-intake'
profile={'batch1000':'batch_1000'}[tag]
cell=src/f'{profile}-100000-0'
def identity(p):
 b=p.read_bytes()
 return {'local_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def write(p,v):
 with p.open('x') as f: json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
exclude={'publication-selection.json','upload-manifest.prepared.json','upload-manifest.actual.json','peer-source-support.zip'}
paths=[p for p in OUT.rglob('*') if p.is_file() and p.name not in exclude and not p.name.endswith('.actual-create-blob.json')]
paths += [ROOT/f'round46-new45-original-artifacts/{tag}-100k-original-inputs.json', src/'terminal.json',src/'outer-execution.json',src/'sealed/upload-manifest.actual.json']
names=['original-validate-shard-return.json','original-validator-execution.json','original-validator.stdout','original-validator.stderr','captured-stdout.frozen-original','captured-stderr.frozen-original','stdio-custody-check.json','native-hash-subprocess-originals.json','original-shard/native-shard/native/report.json']
names += [f'native-hash-{i}-{stream}.original' for i in range(2) for stream in ['stdout','stderr']]
paths += [cell/n for n in names]
paths=sorted(set(paths))
rows=[{'archive_path':str(p.relative_to(ROOT)),**identity(p)} for p in paths]
selection={'schema':f'one-original-{tag}-100k-peer-selection-v1','files':rows,'no_whole_zip_raw_or_ELF_embedded':True,'original_functions_or_transport_validation_repeated':False}
write(OUT/'publication-selection.json',selection)
with zipfile.ZipFile(OUT/'peer-source-support.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for row in rows: z.write(row['local_path'],row['archive_path'])
 z.write(OUT/'publication-selection.json','publication-selection.json')
with zipfile.ZipFile(OUT/'peer-source-support.zip') as z:
 assert set(z.namelist())=={r['archive_path'] for r in rows}|{'publication-selection.json'}
 assert z.testzip() is None
 for row in rows: assert hashlib.sha256(z.read(row['archive_path'])).hexdigest()==row['sha256']
prefix=f'artifacts/checkpoints/p8-round46-complete-bfcc-20261010/new45/{tag}-100k-peer/'
files=[{'repository_path':prefix+n,**identity(OUT/n)} for n in [f'independent-{tag}-100k-review.json','peer-source-support.zip','publication-selection.json']]
manifest={'schema':'one-original-cell-peer-upload-v1','repository_full_name':'jyqj/codecortex','files':files}
write(OUT/'upload-manifest.prepared.json',manifest)
print(json.dumps({'members':len(rows)+1,'files':files},indent=2))
