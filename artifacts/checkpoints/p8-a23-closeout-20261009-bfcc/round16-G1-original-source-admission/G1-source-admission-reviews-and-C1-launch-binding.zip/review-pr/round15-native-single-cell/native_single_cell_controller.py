#!/usr/bin/env python3
"""Run one original opt-in mixed cell. JSON stdin, immutable source, no retries.

This controller is not a product/validator replacement. Root launches it once
per C after the exact G original v15 has really succeeded. All work is local.
"""
from pathlib import Path, PurePosixPath
import datetime
import hashlib
import json
import os
import platform
import re
import shutil
import signal
import subprocess
import sys
import time
import traceback

CELL_SECONDS = 5400
COUNT = 1440
PYTHON = "/usr/bin/python3"
GIT = "/usr/bin/git"
ACTIVE = None

def require(condition, message):
    if not condition:
        raise ValueError(message)

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()

def blob_bytes(raw, kind="blob"):
    return hashlib.sha1(kind.encode() + b" " + str(len(raw)).encode() + b"\0" + raw).hexdigest()

def metadata(path):
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": digest(path)}

def write_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = value if isinstance(value, bytes) else (json.dumps(value, sort_keys=True, indent=2) + "\n").encode()
    with path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    return metadata(path)

def absolute(value, exists=False):
    path = Path(value)
    require(path.is_absolute() and path == path.resolve(strict=exists), "path must have canonical absolute spelling: " + str(path))
    return path

def relative(value):
    require(isinstance(value, str) and "\0" not in value, "invalid relative input")
    path = PurePosixPath(value)
    require(value and not path.is_absolute() and ".." not in path.parts and str(path) == value, "unsafe relative path")
    return value

def read_ref(spec):
    path = absolute(spec["path"], True)
    require(path.is_file() and digest(path) == spec["sha256"], "referenced file changed: " + str(path))
    if "bytes" in spec:
        require(path.stat().st_size == spec["bytes"], "referenced file size changed")
    return path, json.loads(path.read_bytes())

def entry_map(value):
    rows = value["entries"]
    require(isinstance(rows, list) and len(rows) == COUNT, "expected exact 1440 selected entries")
    result = {}
    for row in rows:
        require(set(row) == {"path", "bytes", "sha256", "git_blob", "mode"}, "unexpected selected-entry fields")
        name = relative(row["path"])
        require(name not in result and row["mode"] in ("100644", "100755"), "duplicate path or unsupported selected mode")
        require(type(row["bytes"]) is int and row["bytes"] >= 0, "bad selected byte count")
        require(re.fullmatch("[0-9a-f]{64}", row["sha256"]) and re.fullmatch("[0-9a-f]{40}", row["git_blob"]), "bad selected hash")
        result[name] = row
    return result

def git(root, *arguments):
    env = os.environ.copy()
    env["GIT_OPTIONAL_LOCKS"] = "0"
    # A command-local compatibility setting, never a repository config edit.
    result = subprocess.run([GIT, "--literal-pathspecs", "-c", "core.commitGraph=false", *arguments],
                            cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
    require(result.returncode == 0, "read-only Git command failed: " + result.stderr.decode(errors="replace"))
    return result.stdout

def check_head(binding):
    require(git(binding["root"], "rev-parse", "HEAD").decode().strip() == binding["source"]["G"], "actual HEAD differs from fixed G")

def selected_snapshot(binding, output):
    check_head(binding)
    rows = []
    for name, expected in sorted(binding["entries"].items()):
        path = binding["root"] / name
        require(path.is_file() and not path.is_symlink() and path.resolve() == path, "selected file missing or aliased: " + name)
        raw = path.read_bytes()
        actual = {"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
                  "git_blob": blob_bytes(raw), "mode": "100755" if path.stat().st_mode & 0o111 else "100644"}
        require(actual == expected, "selected source changed: " + name)
        rows.append(actual)
    check_head(binding)
    return write_new(output, {"source_G": binding["source"]["G"], "tree": binding["source"]["tree"],
                              "entries": rows, "count": len(rows),
                              "scope": "exact selected source/validation/CI/binding/review/historical inputs; not whole Git status"})

def committed_domain(binding):
    paths = sorted(binding["entries"])
    actual = {}
    for offset in range(0, len(paths), 96):
        raw = git(binding["root"], "ls-tree", "-r", "-z", binding["source"]["G"], "--", *paths[offset:offset + 96])
        for item in raw.split(b"\0"):
            if not item:
                continue
            left, raw_name = item.split(b"\t", 1)
            mode, kind, oid = left.decode().split()
            name = raw_name.decode()
            require(kind == "blob" and name not in actual, "unexpected or duplicate Git selection")
            actual[name] = {"mode": mode, "git_blob": oid}
    require(set(actual) == set(binding["entries"]), "actual G selected path set differs")
    for name, row in binding["entries"].items():
        require(actual[name] == {key: row[key] for key in ("mode", "git_blob")}, "baseline differs from actual G: " + name)

def commit_object(root, oid):
    raw = git(root, "cat-file", "commit", oid)
    require(blob_bytes(raw, "commit") == oid, "actual commit object hash differs")
    headers = raw.split(b"\n\n", 1)[0].decode().splitlines()
    return {"commit": oid, "tree": next(x[5:] for x in headers if x.startswith("tree ")),
            "parents": [x[7:] for x in headers if x.startswith("parent ")]}

def referenced_child_file(receipt, key, directory):
    spec = receipt[key]
    name = relative(spec["path"])
    path = directory / name
    require(path.is_file() and path.resolve() == path, "admission evidence path missing/aliased")
    require(path.stat().st_size == spec["bytes"] and digest(path) == spec["sha256"], "original admission evidence changed")
    return path

def verify_admission(binding, spec):
    rp, receipt = read_ref(spec)
    source_key = spec.get("source_field", "source_G")
    argv_key = spec.get("argv_field", "argv")
    require(receipt.get(source_key) == binding["source"]["G"], "original admission belongs to another source")
    require(type(receipt.get("exit_code")) is int and receipt["exit_code"] == 0, "original admission child not exit 0")
    require(not receipt.get("controller_exception") and "controller_timeout_seconds" not in receipt, "admission was incomplete/timed out")
    require(absolute(receipt["cwd"], True) == binding["root"], "admission cwd differs")
    argv = receipt[argv_key]
    require(len(argv) == 4 and Path(argv[0]).name == "python3" and argv[1:] ==
            ["scripts/verify_reviewed_source_v15.py", "--source-version", "p8-completion-source-20261009-v15"], "admission argv differs")
    so = referenced_child_file(receipt, "stdout", rp.parent)
    se = referenced_child_file(receipt, "stderr", rp.parent)
    proof = json.loads(so.read_bytes())
    require(proof.get("status") == "passed" and proof.get("source_version") == "p8-completion-source-20261009-v15", "original v15 stdout not passed")
    require(proof.get("product_source") == binding["source"]["P1"] and proof.get("review_source") == binding["source"]["R"], "v15 proof belongs to different P/R")
    require(proof.get("complete_inputs") == 1095 and proof.get("executed_previous_proof") == "p8-oracle-compat-source-20261008-v14", "original complete/previous proof absent")
    refs = []
    for key in (spec.get("before_field", "domain_before"), spec.get("after_field", "domain_after")):
        p = referenced_child_file(receipt, key, rp.parent)
        require(entry_map(json.loads(p.read_bytes())) == binding["entries"], "admission input domain differs from current G")
        refs.append(metadata(p))
    return {"receipt": metadata(rp), "actual_integer_exit": receipt["exit_code"],
            "stdout": metadata(so), "stderr": metadata(se), "proof": proof, "input_domains": refs,
            "field_mapping": {"source": source_key, "argv": argv_key,
                              "before": spec.get("before_field", "domain_before"),
                              "after": spec.get("after_field", "domain_after")}}

def tool_record(argv, root, env):
    result = subprocess.run(argv, cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
    return {"argv": argv, "exit_code": result.returncode, "stdout": result.stdout.decode(errors="replace"),
            "stderr": result.stderr.decode(errors="replace")}

def stop_owned(child, pgid):
    result = {"requested_at": utc(), "signal": "SIGKILL", "owned_pgid": pgid,
              "cleanup_known": False}
    try:
        current = os.getpgid(child.pid)
        require(current == pgid == child.pid, "refusing to signal changed/unowned child group")
        os.killpg(pgid, signal.SIGKILL)
        result["signal_sent"] = True
    except ProcessLookupError:
        result["signal_sent"] = False
        result["group_leader_already_gone"] = True
        # We never guess another PID/PGID or run broad process-name cleanup.
        result["cleanup_status"] = "unknown_group_descendants_after_leader_disappeared"
    except (OSError, ValueError) as error:
        result["signal_sent"] = False
        result["cleanup_status"] = "unknown_owned_group_cleanup"
        result["error"] = repr(error)
    try:
        result["actual_returncode"] = child.wait(timeout=15)
    except subprocess.TimeoutExpired:
        result["actual_returncode"] = None
        result["wait_status"] = "unknown_after_owned_signal"
    if result.get("signal_sent") and result["actual_returncode"] is not None:
        result["cleanup_known"] = True
        result["cleanup_status"] = "signal_sent_to_verified_owned_group_and_leader_reaped"
    return result

def run_step(binding, cell, step, argv, env, deadline):
    global ACTIVE
    directory = cell / "controller" / step
    directory.mkdir()
    if time.monotonic() >= deadline:
        result = {"step": step, "status": "not_started_budget_exhausted", "exit_code": None, "source_binding_ok": True}
        write_new(directory / "receipt.json", result)
        return result
    try:
        before = selected_snapshot(binding, directory / "source-before.json")
    except BaseException as error:
        result = {"step": step, "status": "not_started_source_binding_failed", "exit_code": None,
                  "source_binding_ok": False, "error": repr(error), "traceback": traceback.format_exc()}
        write_new(directory / "receipt.json", result)
        return result
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        result = {"step": step, "status": "not_started_budget_exhausted", "exit_code": None,
                  "source_binding_ok": True, "source_before": before}
        write_new(directory / "receipt.json", result)
        return result
    # Only approved non-secret variables are retained, not the whole inherited env.
    env_keys = ["PATH", "RUSTUP_TOOLCHAIN", "SDKROOT", "CARGO_TERM_COLOR", "CARGO_INCREMENTAL",
                "CARGO_BUILD_JOBS", "CARGO_TARGET_DIR", "PYTHONDONTWRITEBYTECODE", "TMPDIR",
                "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "CC", "CXX"]
    command = {"step": step, "argv": argv, "cwd": str(binding["root"]), "source_G": binding["source"]["G"],
               "started_at": utc(), "remaining_cell_seconds_at_spawn": remaining,
               "environment": {key: env.get(key) for key in env_keys}, "start_new_session": True,
               "source_before": before}
    write_new(directory / "command.json", command)
    stdout_path, stderr_path = directory / "stdout", directory / "stderr"
    started = time.monotonic()
    terminal = {"step": step, "exit_code": None, "timeout": False}
    try:
        with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
            child = subprocess.Popen(argv, cwd=binding["root"], env=env, stdout=stdout, stderr=stderr,
                                     stdin=subprocess.DEVNULL, start_new_session=True)
            ACTIVE = (child, child.pid)
            try:
                actual_pgid = os.getpgid(child.pid)
                require(actual_pgid == child.pid, "child did not own its new process group")
            except ProcessLookupError:
                actual_pgid = None
            write_new(directory / "spawn.json", {"pid": child.pid, "owned_pgid": child.pid,
                      "observed_pgid": actual_pgid, "started_at": command["started_at"], "argv": argv})
            terminal["pid"], terminal["owned_pgid"] = child.pid, child.pid
            try:
                terminal["exit_code"] = child.wait(timeout=max(0, deadline - time.monotonic()))
                terminal["status"] = "completed"
            except subprocess.TimeoutExpired:
                terminal["timeout"] = True
                terminal["status"] = "cell_deadline_exceeded"
                terminal["termination"] = stop_owned(child, child.pid)
                terminal["exit_code"] = terminal["termination"]["actual_returncode"]
    except BaseException as error:
        terminal["status"] = "controller_or_spawn_error"
        terminal["error"], terminal["traceback"] = repr(error), traceback.format_exc()
        if ACTIVE is not None:
            terminal["termination"] = stop_owned(*ACTIVE)
            terminal["exit_code"] = terminal["termination"]["actual_returncode"]
    finally:
        ACTIVE = None
        terminal["ended_at"], terminal["elapsed_seconds"] = utc(), time.monotonic() - started
        for key, path in (("stdout", stdout_path), ("stderr", stderr_path)):
            if path.exists():
                terminal[key] = metadata(path)
        # Persist actual native outcome first. Postcheck never changes this exit.
        write_new(directory / "exit.json", terminal)
    result = dict(terminal, source_before=before, source_binding_ok=True,
                  owned_cleanup_known=terminal.get("termination", {}).get("cleanup_known", True))
    try:
        result["source_after"] = selected_snapshot(binding, directory / "source-after.json")
    except BaseException as error:
        result["source_binding_ok"] = False
        result["source_postcheck_error"], result["source_postcheck_traceback"] = repr(error), traceback.format_exc()
    write_new(directory / "receipt.json", result)
    return result

def successful(result):
    return result.get("status") == "completed" and type(result.get("exit_code")) is int and result["exit_code"] == 0 and not result.get("timeout") and result.get("source_binding_ok") is True

def main():
    cfg = json.load(sys.stdin)
    require(cfg.get("schema_version") == 1 and cfg["concurrency"] in (1, 4, 8, 16) and type(cfg["concurrency"]) is int, "bad controller binding")
    require(digest(Path(__file__).resolve()) == cfg["controller_sha256"], "controller bytes differ")
    source = cfg["source"]
    for key in ("G", "tree", "P1", "R"):
        require(isinstance(source[key], str) and re.fullmatch("[0-9a-f]{40}", source[key]), "null/invalid source pin")
    root = absolute(source["cwd"], True)
    execution = absolute(cfg["execution_root"])
    require(not execution.is_relative_to(root) and not root.is_relative_to(execution), "execution outputs must be outside selected source")
    common_git_dir = Path(git(root, "rev-parse", "--git-common-dir").decode().strip())
    if not common_git_dir.is_absolute():
        common_git_dir = root / common_git_dir
    common_git_dir = common_git_dir.resolve(strict=True)
    require(not execution.is_relative_to(common_git_dir) and not common_git_dir.is_relative_to(execution),
            "execution outputs must not overlap shared Git metadata")
    require(execution.parent.is_dir(), "execution-root parent must already exist")
    if not execution.exists():
        execution.mkdir()
    require(execution.is_dir() and not execution.is_symlink(), "bad execution root")
    canonical_tmp = execution / "canonical-tmp"
    if not canonical_tmp.exists():
        canonical_tmp.mkdir(mode=0o700)
    require(canonical_tmp.is_dir() and not canonical_tmp.is_symlink() and canonical_tmp.resolve() == canonical_tmp, "noncanonical TMPDIR")
    cell = execution / "cells" / ("C" + str(cfg["concurrency"]))
    cell.parent.mkdir(exist_ok=True)
    cell.mkdir(exist_ok=False)
    (cell / "controller").mkdir()
    write_new(cell / "controller" / "binding.input.json", cfg)
    write_new(cell / "controller" / "native_single_cell_controller.py", Path(__file__).read_bytes())
    summary = {"schema_version": 1, "source": source, "concurrency": cfg["concurrency"],
               "cell_root": str(cell), "started_at": utc(), "status": "preflight", "steps": [],
               "workload_acceptance": False, "continue_other_independent_cells": False,
               "native_workload_rerun": False, "task_complete": False}
    blocked = execution / "source-binding-failed.json"
    cleanup_blocked = execution / "owned-cleanup-unknown.json"
    try:
        require(not blocked.exists(), "earlier cell source/admission binding failure forbids later cells")
        require(not cleanup_blocked.exists(), "earlier owned cleanup is unknown; later cells may not start")
        baseline_path, baseline = read_ref(cfg["baseline"])
        entries = entry_map(baseline)
        binding = {"root": root, "source": source, "entries": entries}
        check_head(binding)
        objects = {key: commit_object(root, source[key]) for key in ("G", "R", "P1")}
        require(objects["G"]["tree"] == source["tree"] and objects["G"]["parents"] == [source["R"]], "G tree or sole R parent differs")
        require(objects["R"]["parents"] == [source["P1"]], "R sole P1 parent differs")
        committed_domain(binding)
        review_path = root / relative(source["review_path"])
        require(review_path.is_file() and digest(review_path) == source["review_sha256"], "canonical R bytes differ")
        review = json.loads(review_path.read_bytes())
        require(review.get("source") == source["P1"] and len(review["complete_inputs"]) == 1095 and len(review["validation_inputs"]) == 142, "canonical R source/domain differs")
        require(review.get("author_independence"), "canonical non-author review provenance absent")
        for domain in ("complete_inputs", "validation_inputs"):
            for name, sha in review[domain].items():
                require(name in entries and entries[name]["sha256"] == sha, "canonical R input differs: " + name)
        require(source["review_path"] in entries and entries[source["review_path"]]["sha256"] == source["review_sha256"], "canonical R not in selected baseline")
        admission = verify_admission(binding, cfg["admission"])
        common = {"source": source, "baseline": metadata(baseline_path),
                  "admission_receipt": admission["receipt"], "controller_sha256": cfg["controller_sha256"]}
        common_path = execution / "single-cell-controller-binding.json"
        common_bytes = (json.dumps(common, sort_keys=True, indent=2) + "\n").encode()
        if common_path.exists():
            require(common_path.read_bytes() == common_bytes, "execution root belongs to another binding")
        else:
            write_new(common_path, common_bytes)
        preflight = {"objects": objects, "baseline": metadata(baseline_path), "canonical_review": metadata(review_path),
                     "review_author_independence": review["author_independence"], "original_admission": admission,
                     "shared_git_common_dir": str(common_git_dir),
                     "selected_before": selected_snapshot(binding, cell / "controller" / "preflight-source-before.json"),
                     "scope": "selected 1440 entries and actual HEAD, no whole-checkout cleanliness requirement"}
        write_new(cell / "controller" / "preflight.json", preflight)
        for leaf in ("target", "build", "runtime"):
            require(not (cell / leaf).exists(), "target/build/runtime must be initially absent")
        env = os.environ.copy()
        env["PATH"] = "/Users/jin/.cargo/bin:" + env.get("PATH", "")
        env.update(RUSTUP_TOOLCHAIN="1.95.0", SDKROOT="/Library/Developer/CommandLineTools/SDKs/MacOSX15.4.sdk",
                   CARGO_TERM_COLOR="never", CARGO_INCREMENTAL="0", CARGO_BUILD_JOBS="2",
                   PYTHONDONTWRITEBYTECODE="1", TMPDIR=str(canonical_tmp))
        env.pop("CARGO_TARGET_DIR", None)
        tc = {"platform": platform.platform(), "machine": platform.machine(), "python": sys.version,
              "python_executable": sys.executable, "SDKROOT": env["SDKROOT"],
              "cargo_resolved": shutil.which("cargo", path=env["PATH"]),
              "rustc_resolved": shutil.which("rustc", path=env["PATH"]),
              "commands": [tool_record([PYTHON, "--version"], root, env),
                           tool_record(["cargo", "--version"], root, env),
                           tool_record(["rustc", "-vV"], root, env),
                           tool_record([GIT, "--version"], root, env)],
              "scope": "tool versions; original builder independently enforces and records compiler/binary identity"}
        write_new(cell / "controller" / "toolchain-and-platform.json", tc)
        require(all(x["exit_code"] == 0 for x in tc["commands"]), "toolchain version command failed")
        require(Path(env["SDKROOT"]).is_dir(), "recorded SDK not available")
        require("1.95.0" in tc["commands"][1]["stdout"] and "1.95.0" in tc["commands"][2]["stdout"], "actual Rust toolchain differs")
        start = time.monotonic()
        deadline = start + CELL_SECONDS
        summary["cell_work_started_at"], summary["cell_budget_seconds"] = utc(), CELL_SECONDS
        build, runtime, target = cell / "build", cell / "runtime", cell / "target"
        steps = [("fetch", ["cargo", "fetch", "--locked"], env),
                 ("build", [PYTHON, "scripts/p8_runtime_build.py", "--lock-observation", "--output", str(build)], dict(env, CARGO_TARGET_DIR=str(target))),
                 ("workload", [PYTHON, "scripts/p8_runtime.py", "--binary", str(build / "codecortex"),
                               "--oracle", str(build / "p8-oracle"), "--statistics", str(build / "p8-runtime-statistics"),
                               "--build-receipt", str(build / "build-receipt.json"), "--lock-observation", "--profile", "mixed",
                               "--concurrency", str(cfg["concurrency"]), "--operations", "900", "--files", "1000",
                               "--interval-ms", "500", "--output", str(runtime)], env)]
        source_ok, cleanup_known = True, True
        for step, argv, child_env in steps:
            result = run_step(binding, cell, step, argv, child_env, deadline)
            summary["steps"].append(result)
            source_ok = source_ok and result["source_binding_ok"]
            cleanup_known = cleanup_known and result.get("owned_cleanup_known", True)
            if not successful(result):
                break
        # Equivalent to original if:always within remaining original cell budget.
        if source_ok and cleanup_known:
            result = run_step(binding, cell, "verify",
                              [PYTHON, "scripts/p8_runtime.py", "verify", "--output", str(runtime), "--build-output", str(build)],
                              env, deadline)
            summary["steps"].append(result)
            source_ok = result["source_binding_ok"]
            cleanup_known = result.get("owned_cleanup_known", True)
        else:
            summary["verify_not_started_reason"] = "source_binding_failed" if not source_ok else "owned_cleanup_unknown"
        summary["cell_elapsed_through_final_checks_seconds"] = time.monotonic() - start
        summary["original_artifact_paths"] = {"target": str(target), "build": str(build), "runtime": str(runtime)}
        if (runtime / "report.json").is_file():
            summary["original_report"] = metadata(runtime / "report.json")
            try:
                report = json.loads((runtime / "report.json").read_bytes())
                summary["observation_status"], summary["observation_exit_code"] = report.get("status"), report.get("exit_code")
                summary["acquisition_status"] = report.get("db_lock_observation", {}).get("status")
                summary["workload_acceptance"] = (source_ok and len(summary["steps"]) == 4 and all(successful(x) for x in summary["steps"])
                                                  and report.get("status") == "passed_observation" and report.get("exit_code") == 0
                                                  and report.get("db_lock_observation", {}).get("status") == "complete_acquisition_observation")
            except (ValueError, TypeError, AttributeError) as error:
                # A malformed original report stays a cell failure, not a
                # fabricated source-drift finding or a repaired observation.
                summary["original_report_parse_error"] = repr(error)
        summary["continue_other_independent_cells"] = bool(source_ok and cleanup_known)
        summary["status"] = "passed_observation" if summary["workload_acceptance"] else "retained_failure"
        if not source_ok:
            summary["status"] = "source_binding_failed"
            if not blocked.exists():
                write_new(blocked, {"source": source, "cell": cfg["concurrency"], "created_at": utc(),
                                    "reason": "selected source/admission binding failure", "summary_path": str(cell / "controller" / "summary.json")})
        if not cleanup_known:
            summary["status"] = "owned_cleanup_unknown"
            if not cleanup_blocked.exists():
                write_new(cleanup_blocked, {"source": source, "cell": cfg["concurrency"], "created_at": utc(),
                                           "reason": "cannot establish scoped termination; no wider process cleanup attempted",
                                           "summary_path": str(cell / "controller" / "summary.json")})
    except BaseException as error:
        summary["status"] = "preflight_or_controller_failure"
        summary["error"], summary["traceback"] = repr(error), traceback.format_exc()
        summary["continue_other_independent_cells"] = False
        if not blocked.exists():
            write_new(blocked, {"source": source, "cell": cfg["concurrency"], "created_at": utc(), "reason": repr(error)})
    finally:
        summary["ended_at"] = utc()
        write_new(cell / "controller" / "summary.json", summary)
        print(json.dumps({key: summary.get(key) for key in ("source", "concurrency", "cell_root", "status",
                        "workload_acceptance", "continue_other_independent_cells", "observation_status",
                        "observation_exit_code", "acquisition_status", "error")}), flush=True)
    return 0 if summary["workload_acceptance"] else 1

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        if ACTIVE is not None:
            stop_owned(*ACTIVE)
        raise

