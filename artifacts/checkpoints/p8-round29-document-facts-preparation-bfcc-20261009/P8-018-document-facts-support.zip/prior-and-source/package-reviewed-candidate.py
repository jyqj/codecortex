#!/usr/bin/env python3
"""Package already reviewed documentation bytes. Never executes product or tests."""
from pathlib import Path
import argparse
import hashlib
import json
import stat
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--peer', required=True, type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parent
out = root / 'sealed'
out.mkdir(exist_ok=False)

def identity(data):
    return {'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}

names = ['candidate.patch','candidate-source-proof.json','scope-review.md','pending-closeout.json',
         'original-task-and-validation-excerpt.json','read-scope-and-source-locators.json',
         'original/facts-check-output.json','original/retained-compatibility-log-lines.json',
         'original/docs/BENCHMARK.md','original/crates/cc-eval/src/benchmark/oracle.rs',
         'original/crates/cc-eval/src/benchmark/mutation_case.rs','candidate/docs/BENCHMARK.md',
         'package-reviewed-candidate.py']
selected = [(name,root/name) for name in names] + [('independent-document-review.json',args.peer)]
members = []
data_by_name = {}
for name,path in selected:
    assert path.is_file() and not path.is_symlink(), str(path)
    data = path.read_bytes()
    assert b'sig=' not in data and b'X-Amz-Signature=' not in data
    data_by_name[name] = data
    members.append({'member':name,'original_path':str(path),'mode':format(stat.S_IMODE(path.stat().st_mode),'04o'),**identity(data)})
assert json.loads(data_by_name['pending-closeout.json'])['apply_now'] is False
assert identity(data_by_name['candidate/docs/BENCHMARK.md'])['git_blob'] == '69827051bc4e27c91d2061e1b80ee8b1c5db0e0f'
manifest = {'schema_version':1,'scope':'selected documentary evidence; not whole repository or new test execution',
            'existing_full_CI_log':{'git_blob':'907b9a33cb22d7a13b947e4fac6aaa121c594d55','bytes':1081030,'included_again':False},
            'member_count':len(members),'members':members}
manifest_bytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
(out/'member-manifest.json').write_bytes(manifest_bytes)
with zipfile.ZipFile(out/'P8-018-document-facts-support.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for row in members:
        zi=zipfile.ZipInfo(row['member'],(1980,1,1,0,0,0));zi.create_system=3
        zi.external_attr=(stat.S_IFREG|int(row['mode'],8))<<16;zi.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(zi,data_by_name[row['member']])
    z.writestr('member-manifest.json',manifest_bytes)
with zipfile.ZipFile(out/'P8-018-document-facts-support.zip') as z:
    assert z.testzip() is None
    assert set(z.namelist()) == set(data_by_name)|{'member-manifest.json'}
    for row in members:
        assert z.read(row['member']) == data_by_name[row['member']]
for name,path in selected:
    assert path.read_bytes() == data_by_name[name], str(path)
summary={'task':'P8-018','status':'in_progress','apply_now':False,'base':'51138c236cf2ed47858e2306f9c7bfd3600aaef9',
         'latest_main_progress_bridge':'379099a4a7b09ebe9928c190017bae53d8d1edf6',
         'only_candidate_product_path':'docs/BENCHMARK.md','change':'mutation-case oracle table count 14 to actual 15; add source link',
         'mcp_tool_count_unchanged':14,'original_dependency_still_open':'P8-017','new_tests_run':False,
         'remaining_tasks':28,'new_task_credit':0,'selected_members':len(members),'peer':identity(args.peer.read_bytes())}
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
prefix='artifacts/checkpoints/p8-round29-document-facts-preparation-bfcc-20261009/'
upload={'candidate_product_blob':{'repository_path':'docs/BENCHMARK.md','local_path':str(root/'candidate/docs/BENCHMARK.md'),
                                 **identity(data_by_name['candidate/docs/BENCHMARK.md'])},'checkpoint_leaves':[]}
for name in ['P8-018-document-facts-support.zip','member-manifest.json','summary.json']:
    upload['checkpoint_leaves'].append({'repository_path':prefix+name,'local_path':str(out/name),**identity((out/name).read_bytes())})
(out/'upload-manifest.json').write_text(json.dumps(upload,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'packaged','manifest':str(out/'upload-manifest.json'),'members':len(members),'original_bytes_unchanged':True}))
