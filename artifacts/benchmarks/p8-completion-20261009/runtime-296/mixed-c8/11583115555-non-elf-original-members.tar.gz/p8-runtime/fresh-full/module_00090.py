def stable_00090():
    return 90
