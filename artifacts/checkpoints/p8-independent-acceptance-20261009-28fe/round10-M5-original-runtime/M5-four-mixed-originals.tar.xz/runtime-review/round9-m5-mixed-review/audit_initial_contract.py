from pathlib import Path
import hashlib,json,sys,datetime
ROOT=Path('/workspace/scratch/28fef0db5e01');RUN=ROOT/'runtime-review/m5-local-mixed';SOURCE=ROOT/'runtime-review/m5-local-soak/source';BUILD=ROOT/'runtime-review/m5-local-soak/build';OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
raw=(RUN/'execution-receipt.json').read_bytes();receipt=json.loads(raw)
assert receipt['plan']=={'concurrency_caps':[1,4,8,16],'operations_per_cell':900,'files_per_cell':1000,'interval_ms':500,'profile':'mixed'}
assert receipt['source_and_build_before']['head']=='fec0698c7fa4d76076b828cc17cf277ad8b307e0'
assert receipt['source_and_build_before']['runtime_sha256']==sha(SOURCE/'scripts/p8_runtime.py')
assert all(sha(BUILD/name)==value for name,value in receipt['source_and_build_before']['build_inputs'].items())
sys.path.insert(0,str(SOURCE/'scripts'));import p8_runtime_build as build
identity=build.verify_receipt(SOURCE,BUILD/'build-receipt.json',{name:BUILD/name for name in build.TARGETS})
assert identity['source']['source_commit']==receipt['source_and_build_before']['head']
cells=[]
for cell in receipt['cells']:
 phase=cell['phases'][0];assert phase['source_and_build_before']==receipt['source_and_build_before'];argv=phase['argv'];assert argv[:3]==['python3','-B','scripts/p8_runtime.py'];args=dict(zip(argv[3::2],argv[4::2]));assert args['--concurrency']==str(cell['concurrency']) and args['--operations']=='900' and args['--files']=='1000' and args['--interval-ms']=='500' and args['--profile']=='mixed'
 folder=RUN/f"c{cell['concurrency']}/runtime";plan=json.loads((folder/'plan.json').read_bytes());assert plan['concurrency']==cell['concurrency'] and plan['profile']=='mixed' and plan['operations']==900 and plan['files']==1000 and plan['offer_interval_ms']==500 and plan['build_identity']==identity
 n=(folder/'raw.jsonl').stat().st_size
 with (folder/'raw.jsonl').open('rb') as f:rawprefix=f.read(n)
 complete=rawprefix[:rawprefix.rfind(b'\n')+1];rows=[json.loads(line) for line in complete.splitlines()];initial=[r for r in rows if r['kind']=='initial_build'];resources=[r for r in rows if r['kind']=='resources'];operations=[r for r in rows if r['kind']=='operation']
 assert len(initial)==1 and resources and operations and initial[0]['report']['parse_errors']==[]
 cells.append({'cap':cell['concurrency'],'argv':argv,'original_plan_sha256':sha(folder/'plan.json'),'complete_raw_prefix_sha256':hashlib.sha256(complete).hexdigest(),'complete_raw_prefix_bytes':len(complete),'operation_prefix_count':len(operations),'resource_prefix_count':len(resources),'observed_native_server_pids':sorted({r['server']['pid'] for r in resources}),'source_and_build_match':True,'final_acceptance':False})
assert {c['cap'] for c in cells}=={1,4,8,16};(OUT/'execution-receipt-at-contract-read.json').write_bytes(raw)
report={'schema':1,'conclusion':'four_original_M5_mixed_invocations_have_native_observation_prefixes_and_verified_contract','observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':receipt['source_and_build_before']['head'],'original_wrapper_sha256':sha(RUN/'run_original_mixed_matrix.py'),'source_and_build':receipt['source_and_build_before'],'verified_build_identity':identity,'cells':cells,'execution_environment':receipt['execution_environment'],'build_scope':receipt['build_scope'],'final_acceptance':False,'reviewer_product_execution':False,'remaining':29,'limits':['No /proc process for the root-owned session is visible from this tool execution namespace; startup is evidenced by each original plan and growing native raw observations, not an asserted direct process inspection.','Final execution/verify exit and full RPC/process receipts remain pending.']}
(OUT/'initial-contract-independent.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'contract':'verified','source':report['source'],'cells':cells,'same_host_overlap_preserved':True},indent=2))
