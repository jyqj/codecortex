"""Prepare identity-only recovery evidence readers; do not execute them."""
from pathlib import Path
import ast,difflib,hashlib,json
B=Path('/workspace/scratch/a217aaae3bde/original-173-runtime')
P=Path('/workspace/scratch/a217aaae3bde/original-173-platform-gates/helper-provenance')
O=B/'recovery-helpers-275e-v2';O.mkdir(exist_ok=False)
def info(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git_blob_sha1=hashlib.sha1(('blob %d\0'%len(b)).encode()+b).hexdigest())
mapping=[('/dev/shm/a217aaae3bde',str(B)),('11592146562','11597639035'),('ci-artifacts/11597639035','artifacts/11597639035'),
 ('BASE / "codecortex-combined-guard-view"','Path("/workspace/scratch/a217aaae3bde/scale-original-275e")'),
 ('platform-review/pr167-execution/recovery-e-review','reviews/recovery-11597639035-275e8799-independent'),
 ('a23bb72d3c954f385b99fe81ce9189885c208557','275e8799d4947d297329073eaa3ca675d3fd0777'),
 ('recovery-e-review.json','recovery-173-review.json'),
 ('recovery-e-011-review.json','recovery-173-011-review.json'),('"reviewer":"pr_audit"','"reviewer":"runtime_closeout"'),
 ("reviewer='pr_audit'","reviewer='runtime_closeout'"),('original E execution scope','original 173 execution scope'),
 ('retained E recovery','retained 173 recovery')]
records=[]
for name in ['review-recovery-e.py','review-recovery-e-011.py']:
 before=(P/name).read_text();after=before;edits=[]
 for a,b in mapping:
  n=after.count(a)
  if n:after=after.replace(a,b);edits.append(dict(old=a,new=b,count=n))
 restored=after
 for e in reversed(edits):restored=restored.replace(e['new'],e['old'])
 assert restored==before
 checks=lambda s:[ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(s)) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='check']
 assert checks(restored)==checks(before)
 path=O/name;path.write_text(after);path.chmod(0o444)
 (O/(name+'.diff')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(P/name),tofile=str(path))))
 records.append(dict(path=str(path),original_path=str(P/name),original=info(before.encode()),candidate=info(after.encode()),edits=edits,original_check_count=len(checks(before)),candidate_check_count=len(checks(after)),all_original_check_AST_preserved_after_declared_identity_normalization=True))
src=B/'helpers-275e-v1/preflight_e_runtime_zip.py';before=src.read_text()
after=before.replace('from e_raw_cache_audit import HEAD,RUN,file_hash','from e_raw_cache_audit import HEAD,file_hash\nRUN = 37890757129')
assert before.count('from e_raw_cache_audit import HEAD,RUN,file_hash')==1
path=O/'preflight_recovery_zip.py';path.write_text(after);path.chmod(0o444)
(O/'preflight_recovery_zip.py.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(src),tofile=str(path))))
records.append(dict(path=str(path),original_path=str(src),original=info(before.encode()),candidate=info(after.encode()),only_change='bind original runtime ZIP safety preflight to official recovery workflow run 37890757129; bounds/extraction byte validation identical'))
out=dict(schema='exact-173-recovery-readers-v1',source_commit='275e8799d4947d297329073eaa3ca675d3fd0777',artifact_id=11597639035,workflow_run=37890757129,files=records,scope='Only exact source/artifact/paths/reviewer labels change; original 84+55 checks retained. Read-only SQLite and retained raw verification only; no new fault/test/product execution. Official ZIP metadata preflight separately mandatory.',acceptance_executed=False,tasks_changed=False)
p=O/'adaptation-manifest.json';p.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(str(p),info(p.read_bytes()))
