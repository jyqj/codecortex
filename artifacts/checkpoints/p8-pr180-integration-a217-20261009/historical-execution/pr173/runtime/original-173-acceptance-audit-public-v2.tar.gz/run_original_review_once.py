"""Capture one preflight and one existing evidence-reader invocation, not a workload."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
B=Path(__file__).resolve().parent
S=Path('/workspace/scratch/a217aaae3bde/scale-original-275e')
H=B/'helpers-275e-v1'
HEAD='275e8799d4947d297329073eaa3ca675d3fd0777'
scope=sys.argv[1];aid=int(sys.argv[2]);R=B/'reviews';R.mkdir(exist_ok=True)
E=B/'executions'/str(aid);E.mkdir(parents=True,exist_ok=False)
A=B/'artifacts'/str(aid);metadata=A/'artifact-metadata.json';m=json.loads(metadata.read_text())
assert m['id']==aid and m['workflow_run']['head_sha']==HEAD
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for v in iter(lambda:f.read(1024*1024),b''):h.update(v)
 return h.hexdigest()
receipt={'source':HEAD,'artifact_id':aid,'scope':scope,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'measurement_rerun':False,'commands':[],'status':'started'}
record=E/'execution.json'
def save():record.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONPATH']=str(H)
def run(label,argv):
 item={'label':label,'command':argv,'cwd':str(B),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()};receipt['commands'].append(item);save()
 start=time.monotonic()
 with (E/(label+'.stdout')).open('xb') as out,(E/(label+'.stderr')).open('xb') as err:
  try:
   result=subprocess.run(argv,cwd=B,env=env,stdout=out,stderr=err,timeout=900)
   item['exit_code']=result.returncode
  except Exception as exc:item['exception']=repr(exc);raise
  finally:item['elapsed_seconds']=time.monotonic()-start;save()
 item.update(stdout_sha256=sha(E/(label+'.stdout')),stderr_sha256=sha(E/(label+'.stderr')));save()
 assert item['exit_code']==0,label+' failed; retain all originals and command evidence'
try:
 receipt['helper_inputs_before']={str(p):sha(p) for p in H.glob('*.py')}
 receipt['original_zip_sha256_before']=sha(A/(str(aid)+'.zip'))
 assert receipt['original_zip_sha256_before']==m['digest'].removeprefix('sha256:')
 assert (A/(str(aid)+'.zip')).stat().st_size==m['size_in_bytes']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==HEAD
 descriptor={'artifact_id':aid,'zip_bytes':m['size_in_bytes'],'zip_sha256':m['digest'].removeprefix('sha256:')}
 if scope=='recovery':
  G=B/'recovery-helpers-275e-v2';preflight=G/'preflight_recovery_zip.py'
  receipt['helper_inputs_before'].update({str(p):sha(p) for p in G.glob('*.py')})
 elif scope=='lifecycle':preflight=H/'preflight_e_lifecycle_zip.py'
 else:preflight=H/'preflight_e_runtime_zip.py'
 run('preflight-extract',[sys.executable,'-B',str(preflight),str(A/(str(aid)+'.zip')),str(metadata),str(A/'extracted'),str(E/'preflight.json'),'--extract'])
 if scope=='recovery':
  assert not (R/'recovery-11597639035-275e8799-independent').exists()
  for script in ['review-recovery-e.py','review-recovery-e-011.py']:run(script,[sys.executable,'-B',str(G/script)])
 else:
  if scope.startswith('mixed-c') or scope=='soak':
   c=int(scope.split('c')[-1]) if scope.startswith('mixed-c') else 4
   descriptor=[[c,aid,m['size_in_bytes'],m['digest'].removeprefix('sha256:')]]
   reviewer=H/'review_e_runtime_original.py'
  else:reviewer=H/('review_e_lifecycle_original.py' if scope=='lifecycle' else 'review_e_backfill_original.py')
  manifest=E/'original-manifest.json';manifest.write_text(json.dumps(descriptor,indent=2)+'\n')
  run('original-review',[sys.executable,'-B',str(reviewer),str(manifest),str(B/'artifacts'),HEAD,str(S),str(R)])
 receipt['helper_inputs_after']={p:sha(p) for p in receipt['helper_inputs_before']}
 assert receipt['helper_inputs_after']==receipt['helper_inputs_before']
 receipt['original_zip_sha256_after']=sha(A/(str(aid)+'.zip'))
 assert receipt['original_zip_sha256_after']==receipt['original_zip_sha256_before']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==HEAD
 receipt['status']='accepted_scoped_original_evidence'
except BaseException as exc:
 receipt['status']='failed_or_blocked_original_review';receipt['exception']=repr(exc);save();raise
finally:
 receipt['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps({'status':receipt['status'],'artifact_id':aid,'scope':scope,'receipt':str(record),'sha256':sha(record)}))
