def stable_00171():
    return 171
