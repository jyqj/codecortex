# 固定 head 9b3711a9 的正式 CI 归档

本目录只绑定 `9b3711a9346b64868b64cf6cc1f6e38162a59a43` / tree `5fd3e14bfabd98346a4fb0b18c28b04c8b212bec`。
官方 run：https://github.com/jyqj/codecortex/actions/runs/37674979736，最终 `completed/success`。
各 job/step 原状态见 `official-jobs.json`；`verification-index.json` 汇总实际结果和日志内源码控制、任务状态输出。

check 日志实际含 392 组 Rust result：3119 passed、0 failed、126 ignored、1855 filtered out，其中 151 组没有实际执行测试。
Python 共 5 组、388 tests；逐组数量、状态和模块分布均保留。
这些是执行组累计，可能重复同一 suite；不是去重库存或全量未筛选测试通过声明。ignored 原名、原因与行号没有删去。

完整官方 decoded 日志无损 gzip，原文件继续留在 scratch；解压后 1001039 bytes，SHA256 `bb8043f85357c2d813b21ae39773cdfbdce6a36c1b481badf1e653a86a842433`。
可用 `python3 parse_log.py <解压后的log路径> <新的输出JSON路径>` 重算结果，禁止覆盖既有文件再冒充新运行。
解析脚本只读取日志，不运行产品或测试。所有归档载荷由 `file-manifest.json` 绑定。本次没有修改 PR head、源码、任务或 CI。
