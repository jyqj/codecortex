def stable_00288():
    return 288
