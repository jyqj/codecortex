from pathlib import Path
import hashlib,json,zipfile,subprocess,base64,datetime,sys,time,re
base=Path.cwd()/'artifacts/benchmarks/p8-bfccb8494ba0'
p0=base/'native-db-observation-combined-P-3ced-evidence'
p1=base/'native-db-observation-combined-P1-bb29-evidence'
cont=p1/'continuation-canonical-temp'
(p1/'package-P0-P1-controller.py').write_bytes(Path(sys.argv[0]).read_bytes())
r0=json.loads((p0/'controls-progress.json').read_text())
r1=json.loads((p1/'controls-progress.json').read_text())
r2=json.loads((cont/'controls-progress.json').read_text())
assert len(r0)==2 and [r['exit_code'] for r in r0]==[0,1]
assert len(r1)==5 and [r['exit_code'] for r in r1]==[0,0,0,0,1]
assert len(r2)==10 and all(r['exit_code']==0 and r['nonzero_test_check_passed'] for r in r2)
assert all(r['source_P']=='3ced45d1f4bbfc38eeab3fbe1a1ef17eae26721a' for r in r0)
assert all(r['source_P']=='bb290be2deaf4334863e09dbf47fe4ccc9625f2b' for r in r1+r2)
rust1=sum(s['passed'] for r in r1 for s in r.get('rust_test_summaries',[]))
rust2=sum(s['passed'] for r in r2 for s in r.get('rust_test_summaries',[]))
assert (rust1,rust2)==(10,50)
assert r1[4]['python_test_count']==77 and r2[0]['python_test_count']==77
assert r2[0]['python_skipped']==0
bad=(p1/'all-original-runtime-python-controls.stderr').read_text()
assert 'FAILED (failures=10, errors=6)' in bad
def h(b):return hashlib.sha256(b).hexdigest()
def readref(folder,ref):
 b=(folder/ref['path']).read_bytes()
 assert len(b)==ref['bytes'] and h(b)==ref['sha256'],ref
 return b
for folder,receipts in [(p0,r0),(p1,r1),(cont,r2)]:
 for r in receipts:
  for s in ['stdout','stderr']:readref(folder,r[s])
  a=json.loads(readref(folder,r['before']))
  b=json.loads(readref(folder,r['after']))
  assert len(a['entries'])==1250 and a['entries']==b['entries']
  assert a['source_P']==b['source_P']==r['source_P']
summary={'schema_version':1,'P0':'3ced45d1f4bbfc38eeab3fbe1a1ef17eae26721a','P1':'bb290be2deaf4334863e09dbf47fe4ccc9625f2b','P0_actual_negative':{'commands':2,'locked_fetch_exit':0,'fmt_exit':1,'tests_started':0},'P1_first_phase':{'commands':5,'fmt_exit':0,'rust_passed':10,'python_executed':77,'python_failures':10,'python_errors':6,'python_exit':1},'P1_continuation':{'commands':10,'rust_passed':50,'python_passed':77,'python_skipped':0,'both_strict_clippy_exit':0},'final_unique_passing_controls':{'rust':60,'python':77,'rust_ignored':0,'python_skipped':0},'input_domain_files_per_before_after':1250,'scope':'Original P0 and P1 executions with negative history intact. Same actual P1 continuation changes only child TMPDIR to a fresh canonical path. Original source, tests, assertions and command semantics unchanged. Ordinary cached engineering controls, no cold build, original workflow, four-cell diagnostic or TODO completion claim.'}
(p1/'package-phase-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
roots={'P0-negative':p0,'P1-controls':p1};files=[]
for label,folder in roots.items():
 for p in sorted(folder.rglob('*')):
  assert not p.is_symlink(),str(p)
  if p.is_dir():continue
  assert p.is_file(),str(p)
  b=p.read_bytes();files.append({'path':label+'/'+p.relative_to(folder).as_posix(),'original_path':str(p),'bytes':len(b),'sha256':h(b),'mode':oct(p.stat().st_mode&0o777)})
manifest={'schema_version':1,'scope':summary,'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files}
mb=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
zp=base/'native-db-observation-P0-P1-controls-round15.zip';assert not zp.exists()
with zipfile.ZipFile(zp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in files:z.writestr(f['path'],Path(f['original_path']).read_bytes())
 z.writestr('archive-manifest.json',mb)
with zipfile.ZipFile(zp) as z:
 assert z.testzip() is None and len(z.infolist())==len(files)+1
 for f in files:
  b=z.read(f['path']);assert len(b)==f['bytes'] and h(b)==f['sha256']
raw=zp.read_bytes();oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();transport=base64.b64encode(raw).decode()
receipt={'zip_path':str(zp),'zip_bytes':len(raw),'zip_sha256':h(raw),'git_blob':oid,'members':len(files)+1,'selected_files':len(files),'expanded_bytes':sum(f['bytes'] for f in files)+len(mb),'base64_chars':len(transport),'base64_sha256':h(transport.encode()),'summary':summary}
assert len(raw)<8*1024*1024
for label,encoding in [('binary','base64'),('base64-transport','utf-8')]:
 body=json.dumps({'content':transport,'encoding':encoding}).encode();cmd=['/opt/homebrew/bin/gh','api','-X','POST','repos/jyqj/codecortex/git/blobs','--input','-'];start=time.monotonic();p=subprocess.run(cmd,input=body,capture_output=True)
 receipt[label]={'command':cmd,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':h(p.stdout),'stderr_sha256':h(p.stderr)}
 if p.returncode:
  (base/'native-db-observation-P0-P1-controls-round15-transport.json').write_text(json.dumps(receipt,indent=2)+'\n');print(p.stderr.decode(errors='replace'));sys.exit(p.returncode)
 result=json.loads(p.stdout);receipt[label]['sha']=result['sha'];expected=oid if encoding=='base64' else hashlib.sha1(b'blob '+str(len(transport)).encode()+b'\0'+transport.encode()).hexdigest();assert result['sha']==expected
 (base/'native-db-observation-P0-P1-controls-round15-transport.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
