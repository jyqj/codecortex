from pathlib import Path
import json,hashlib,datetime
D=Path(__file__).resolve().parent;A=Path('/dev/shm/pr-triage-round23-wide-dirty-candidate');V=A/'v2';m=json.loads((V/'source-manifest.json').read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
for x in m['files']:
 b=(V/'candidate'/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['git_blob']
for n in ['scripts/p8_scale_matrix.py','scripts/tests/test_p8_scale_matrix.py']:
 assert(V/'candidate'/n).read_bytes()==(A/'candidate'/n).read_bytes()
w='.github/workflows/p8-scale-wide-dirty.yml';o=(A/'candidate'/w).read_text();n=(V/'candidate'/w).read_text()
step='''      - name: Check formatting and both native scale protocol profiles
        env:
          CARGO_TARGET_DIR: ${{ runner.temp }}/p8-scale-wide-dirty-protocol-cargo
        run: |
          cargo fmt --all -- --check
          cargo test --locked -p cc-eval --test p8_scale
'''
assert n.count(step)==1 and n.replace(step,'')==o
assert n.index(step)<n.index('      - name: Compile and bind one immutable release executable')
assert 'p8-scale-wide-dirty-protocol-cargo'!='p8-scale-wide-dirty-cargo'
r={'schema':'wide-dirty-v2-workflow-docs-independent-addendum-v1','observed_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/todo_audit','verdict':'accepted_scoped_source','unresolved_blockers':[],'base_review':{'path':str(D/'python-workflow-independent-review.json'),'sha256':sha((D/'python-workflow-independent-review.json').read_bytes())},'final_four_path_manifest':{'path':str(V/'source-manifest.json'),'sha256':sha((V/'source-manifest.json').read_bytes()),'files':m['files']},'checked':['Driver andtest byteequalv1; retainedactual44Python0 applies to these same bytes, no test rerun or executioncredit fornewworkflow.','Onlynewworkflow change is exact2command step aftertoolchain andbeforefreshreleasebuild, independentprotocoltarget; originalrelease targetpath and buildproducer untouched.','Defaultbash failure stopsjobbeforebuild and150shards; no continue-on-error. Commands areengineering controls outsideexistingnative5h clock.','Newdocs distinguish unregisteredbenchmark8/128 from unchangedproductiondefaults and discloseoriginalcommands; previous nonblockingwordingnote resolved.','Originalp8-scale.yml and143? validationfuturecounts not assumedactual; thisreviewcovers4localcandidatepaths only.'],'execution':{'newworkflow_fmt':'not_run','newworkflow_p8_scale_Rust_tests':'not_run','Rust_Clippy':'not_run','product_or_study':'not_run','retained_python':{'actual44pass':True,'source_identity':'unchangedv1 driver/test','reviewer_reexecuted':False}},'TODO_newly_complete':0,'TODO_remaining':29}
# The count is a future mapping matter, not a literal question in final evidence.
r['checked'][-1]='Original p8-scale.yml remains unchanged; full future validation count must be checked against actualPW. This review covers four local candidate paths only.'
p=D/'python-workflow-v2-independent-addendum.json';p.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'verdict':r['verdict']}))
