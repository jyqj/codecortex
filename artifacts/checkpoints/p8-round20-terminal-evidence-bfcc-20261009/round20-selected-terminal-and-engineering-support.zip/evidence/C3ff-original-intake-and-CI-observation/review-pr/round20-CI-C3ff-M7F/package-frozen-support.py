#!/usr/bin/env python3
"""Create a byte-verified selected support ZIP; original artifact ZIPs stay separate."""
from pathlib import Path
import hashlib
import json
import zipfile

B = Path(__file__).resolve().parent
PREFIX = 'review-pr/round20-CI-C3ff-M7F'
def ent(path, repository_path):
    data = path.read_bytes()
    return {'local_path': str(path), 'repository_path': repository_path, 'bytes': len(data),
        'sha256': hashlib.sha256(data).hexdigest(),
        'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}
def save(path, data):
    with path.open('x') as out: out.write(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
chosen = []
for path in sorted(B.rglob('*')):
    if not path.is_file(): continue
    relative = path.relative_to(B).as_posix()
    if path.name in ('original.zip', 'archive-selection.json', 'support-originals.zip', 'upload-index.json', 'support-zip-verification.json'): continue
    if relative.endswith('/extracted/native/raw.jsonl'): continue
    assert not path.is_symlink()
    chosen.append(ent(path, PREFIX + '/' + relative))
external = [
    (Path('/dev/shm/execution-recon-recovery-20261009/intake_once.v2.py'), 'reviewer-source/intake_once.v2.py'),
    (Path('/dev/shm/root-round20/C3ff-official-two-original-materialization.json'), 'root-originals/C3ff-official-two-original-materialization.json'),
    (Path('/dev/shm/root-round20/C3ff-original-zip-created-blob-receipts.json'), 'root-originals/C3ff-original-zip-created-blob-receipts.json'),
]
for path, name in external: chosen.append(ent(path, PREFIX + '/' + name))
assert len({row['repository_path'] for row in chosen}) == len(chosen)
originals = []
for aid, name, expected_blob in [
    (11626430756, 'p8-scale-shard-100000-0-C3ff-37910924354-original.zip', 'ac44c156dd7932cf9b42aa03c35392dc89283581'),
    (11626127365, 'p8-scale-matrix-C3ff-37910924354-original.zip', '860c80771c980babfa31b9b09f2b2543868f9064')]:
    row = ent(B / 'raw' / str(aid) / 'attempt01/original.zip', 'originals/' + name)
    assert row['git_blob'] == expected_blob
    row.update(artifact_id=aid, existing_created_git_blob=expected_blob,
        official_locator=f'https://api.github.com/repos/jyqj/codecortex/actions/artifacts/{aid}/zip',
        complete_original=True, nested_in_support_zip=False)
    originals.append(row)
selection = {'schema_version': 1, 'scope': 'Selected support files; complete original ZIPs are separate immutable leaves.',
    'file_count': len(chosen), 'total_bytes': sum(row['bytes'] for row in chosen), 'files': chosen,
    'outside_selection_complete_originals': originals,
    'excluded_unpacked_large_file': ent(B / 'raw/11626430756/attempt01/extracted/native/raw.jsonl',
        'complete original 11626430756 ZIP member native/raw.jsonl'),
    'TODO_newly_done': 0, 'TODO_remaining': 29}
save(B / 'archive-selection.json', selection)
members = chosen + [ent(B / 'archive-selection.json', PREFIX + '/archive-selection.json')]
zip_path = B / 'support-originals.zip'
with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
    for row in members:
        data = Path(row['local_path']).read_bytes()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
        info = zipfile.ZipInfo(row['repository_path'], (2026, 10, 9, 0, 0, 0))
        info.create_system = 3
        info.external_attr = 0o100644 << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, data)
with zipfile.ZipFile(zip_path) as archive:
    assert len(archive.infolist()) == len(members)
    assert len(set(archive.namelist())) == len(members)
    for row in members:
        data = archive.read(row['repository_path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    assert archive.testzip() is None
support = ent(zip_path, 'C3ff-failed-originals-and-CI-observation-support.zip')
assert support['bytes'] <= 8 * 1024 * 1024
save(B / 'support-zip-verification.json', {'schema_version': 1, 'support': support, 'member_count': len(members),
    'uncompressed_bytes': sum(row['bytes'] for row in members), 'every_member_bytes_sha256_crc_verified': True,
    'whole_original_zip_nested': False, 'new_measurement_or_validation_execution': False})
save(B / 'upload-index.json', {'schema_version': 1, 'files': [support] + originals,
    'support_member_layout': PREFIX + '/', 'original_git_blobs_already_created_by_root': True,
    'remote_mutations_performed_here': False, 'TODO_newly_done': 0, 'TODO_remaining': 29})
print(json.dumps({'selection': ent(B / 'archive-selection.json', PREFIX + '/archive-selection.json'),
    'upload_index': ent(B / 'upload-index.json', 'upload-index.json'), 'support': support,
    'selection_file_count': len(chosen), 'selection_bytes': selection['total_bytes']}, indent=2))
