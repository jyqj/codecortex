def stable_00175():
    return 175
