def stable_00158():
    return 158
