def stable_00352():
    return 352
