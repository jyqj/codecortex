# G6B mechanical binding checkpoint

Actual P6B is 5534ebf38cc31efec1590d132ca57c30e2f77f1b. Actual R6B is 22975e49107b3832f438f85b17275110fc0afa02, tree 6538f382443f8975d252b4ff084ef32688f31ac1, with P6B as sole parent. The official comparison contains only the two reviewed artifact additions. Their raw bytes and Git blob identities match the frozen upload manifest.

This bundle records local mechanical generation only. Expected G6B tree is e039a817291934b15cc018fd74d2c83982bb7f37; actual G remains unknown/null. Root and scripts tree objects were independently rehashed and precisely two binding leaf OIDs were replaced. The suggested sole parent is actual R6B.

Registry changes are exactly complete_inputs, delta, product_source, review_sha256, review_source. Guard changes are exactly PRODUCT, REVIEW, REVIEW_PATH, REGISTRY_SHA256. Counts are 1095 product inputs, 72 BASE deltas, 142 validation inputs. All prior 71 deltas and the M7F preselect formatter correction remain exact; only the existing crash-ready fixture adds a BASE delta. All validation hashes and the guard algorithm, BASE/FROZEN/historical controls and CI are unchanged.

The generator child exited 0. This is not original v15 source admission, Rust/fmt/Clippy execution, runtime or performance acceptance, or TODO completion. Source-only R6B remains not_run for current execution. Old b2 closeout failure and the candidate's historical review remain under their original identities. No remote mutation was performed by this agent.

The prepared generator's inherited docstring says independent R4; this is a stale label only. Its executable assertions, input metadata, canonical path and generation receipt bind the exact actual P6B/R6B above. No product guard logic uses that label.

The canonical R6B and its compact support ZIP are not duplicated in this checkpoint. Their immutable locators and exact hashes are recorded in actual-R6B-two-leaf-installation-review.json; the original two payloads remain frozen in /dev/shm/todo-audit-P6B-crash-ready-source-review/final-R6B/ and were installed in actual R6B.
