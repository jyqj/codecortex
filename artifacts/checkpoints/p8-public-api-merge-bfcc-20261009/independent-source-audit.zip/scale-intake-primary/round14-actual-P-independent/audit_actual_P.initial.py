import ast,datetime,hashlib,json
from pathlib import Path

OUT=Path(__file__).resolve().parent
API=OUT/'github-api'
PLAN=Path('/dev/shm/todo-audit-pr180-merge-plan')
P='c92eb5ac7ece70d1f62271d7e2dacac513c285b5'
BASE='7354db236c9d9850a75f31672697ae9eab44565e'
def load(p):return json.loads(p.read_text())
def api(p):return json.loads(load(p)['content'])
def sha256(b):return hashlib.sha256(b).hexdigest()
def git(kind,b):return hashlib.sha1((kind+' '+str(len(b))+'\0').encode()+b).hexdigest()
def identity(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha256(b)}
def tree_sha(entries):
    rows=[]
    for e in sorted(entries,key=lambda e:(e['path']+('/' if e['type']=='tree' else '')).encode()):
        name=e['path'];assert '/' not in name
        mode='40000' if e['mode']=='040000' else e['mode']
        rows.append(mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(e['sha']))
    return git('tree',b''.join(rows))
def verify_recursive(data):
    entries=data['tree'];assert data['truncated'] is False
    expected={'':data['sha']}
    for e in entries:
        if e['type']=='tree':expected[e['path']]=e['sha']
    for directory,want in expected.items():
        children=[]
        for e in entries:
            parent,_,leaf=e['path'].rpartition('/')
            if parent==directory:children.append(dict(e,path=leaf))
        assert tree_sha(children)==want,directory
    return len(expected)

commit=api(API/'actual-P-commit.json');root=api(API/'actual-P-root-tree.json')
assert commit['sha']==P and root['sha']==commit['tree']['sha']=='9ae248f8e0c42a8a7389e26e3f44710dfb029640'
assert [x['sha'] for x in commit['parents']]==['4652cad11dde4b41126544a38fddf25eb2fb7474','55aa2bcf355441585bcf980e1d6f4fab8eebe59d']
assert tree_sha(root['tree'])==root['sha']
raw='tree '+commit['tree']['sha']+'\n'+''.join('parent '+x['sha']+'\n' for x in commit['parents'])
for role in ['author','committer']:
    x=commit[role];stamp=int(datetime.datetime.fromisoformat(x['date'].replace('Z','+00:00')).timestamp())
    raw+=f"{role} {x['name']} <{x['email']}> {stamp} +0000\n"
raw+='\n'+commit['message']+'\n'
assert git('commit',raw.encode())==P
(OUT/'actual-P.commit').write_bytes(raw.encode())
actual={e['path']:e for e in root['tree'] if e['type']=='blob'}
tree_count=1
for prefix,filename in [('crates','crates'),('scripts','scripts'),('tests','tests'),('.github','github')]:
    data=api(API/f'actual-P-{filename}-tree.json')
    assert data['sha']==next(x['sha'] for x in root['tree'] if x['path']==prefix)
    tree_count+=verify_recursive(data)
    for e in data['tree']:
        if e['type']!='tree':actual[prefix+'/'+e['path']]=dict(e,path=prefix+'/'+e['path'])

plan=load(PLAN/'prospective-55aa-product-input-maps.json')
old=load(Path('/dev/shm/execution-recon-bfcc/pr180181/inventory-audit.json'))['inventories']['180']
oldprod={x['path']:x for x in old['product']}
oldval={x['path']:x for x in old['validation']}
product={p:x for p,x in actual.items() if p.startswith('crates/') or p in ['Cargo.toml','Cargo.lock']}
exclude={'scripts/verify_reviewed_source_v15.py','scripts/reviewed-source-registry-v15.json','.github/workflows/ci.yml'}
validation={p:x for p,x in actual.items() if (p.startswith('scripts/') or p.startswith('.github/workflows/') or p.startswith('tests/source_integrity/')) and p not in exclude and not ('__pycache__' in Path(p).parts and p.endswith('.pyc'))}
assert len(product)==1093 and len(validation)==139
assert set(product)==set(plan['complete_inputs']) and set(validation)==set(plan['validation_inputs'])
sources={}
donors={}
seven=load(PLAN/'55aa-full-union-audit.json')['latest_main_additional_product_inputs']
fixroot=Path('/dev/shm/todo-audit-pr180-public-dependency-fix-v2/candidate')
for path,e in {**product,**validation}.items():
    assert e['type']=='blob' and e['mode'] in ['100644','100755']
    expect=plan['actual_input_mode_blob_inventory'][path]
    assert {k:e[k] for k in ['mode','type','sha','size']}==expect,path
    if path in seven:
        p=OUT/'source'/path;b=p.read_bytes();digest=sha256(b)
        assert git('blob',b)==e['sha'] and len(b)==e['size']
        assert digest==seven[path]['sha256'];donors[path]='actual main55aa raw blob independently fetched and rehashed'
    elif plan['input_donors'].get(path)=='frozen_v2':
        p=fixroot/path;b=p.read_bytes();digest=sha256(b)
        assert git('blob',b)==e['sha'] and len(b)==e['size']
        donors[path]='previous independently reviewed frozen v2 raw bytes, actual P Git blob equal'
    else:
        prior=oldprod.get(path,oldval.get(path));assert prior is not None,path
        assert all(e[k]==prior[k] for k in ['mode','type','sha','size']),path
        digest=prior['sha256'];donors[path]='previous independently verified actual3ff path/mode/blob/size equal; SHA reused by immutable Git identity'
    expected_hash=plan['complete_inputs'].get(path,plan['validation_inputs'].get(path))
    assert digest==expected_hash,path
    sources[path]={**{k:e[k] for k in ['mode','type','sha','size']},'sha256':digest}

previous_review=load(Path('/workspace/scratch/bfccb8494ba0/pr180181-readonly/review180.json'))
mainreview_response=load(PLAN/'55aa-review-response.json')
mainreview_raw=mainreview_response['content'].encode();assert git('blob',mainreview_raw)=='ec0dc0747ac1c036e249bbf1f22ff472c42aba64'
assert sha256(mainreview_raw)=='1c29eb3e9f2509de538cb0b737ded099a7ee771c44b2afdde24d868525ce9eca'
mainreview=json.loads(mainreview_raw)
base_hash=dict(previous_review['complete_inputs'])
for p,delta in previous_review['paths'].items():
    if delta['before_sha256'] is None:del base_hash[p]
    else:base_hash[p]=delta['before_sha256']
assert set(base_hash)<=set(product)
generated_delta={p:{'before_sha256':base_hash.get(p),'sha256':sources[p]['sha256']} for p in sorted(product) if base_hash.get(p)!=sources[p]['sha256']}
assert generated_delta==plan['delta'] and len(generated_delta)==59
for p in seven:assert generated_delta[p]==mainreview['paths'][p]
for p in previous_review['paths']:
    assert generated_delta[p]['before_sha256']==previous_review['paths'][p]['before_sha256']
assert sum(donors[p].startswith('previous independently verified') for p in product)==1083
assert all(sources[p]['sha256']==oldval[p]['sha256'] for p in validation)
for p in ['.github/workflows/ci.yml','scripts/verify_reviewed_source_v15.py','scripts/reviewed-source-registry-v15.json']:
    assert actual[p]['sha'] in {'8c7325eb88b791f909e72c4b6c79b417185e4386','caf26bf55794ceae66e591a390df8ae9be39bfb4','53dae35d245acf7ca084d90a31b3086362adc7cf'}

result={'schema_version':1,'source':P,'tree':root['sha'],'base':BASE,'parents':[x['sha'] for x in commit['parents']],'raw_commit_sha_reconstructed':True,'Git_tree_objects_independently_reconstructed':tree_count,'product_count':len(product),'validation_count':len(validation),'delta_count':len(generated_delta),'complete_inputs':{p:sources[p]['sha256'] for p in sorted(product)},'validation_inputs':{p:sources[p]['sha256'] for p in sorted(validation)},'paths':generated_delta,'actual_input_mode_blob_inventory':sources,'input_identity_sources':donors,'counts':{'unchanged_3ff_product_path_mode_blob_size':1083,'new_main_raw_blobs':7,'reviewed_v2_raw_blobs':3,'all_validation_equal3ff':139},'execution_credit':'Source audit only. Root executes exact new P separately; old3ff and Gc8 execution retained at original identities.','audit_scope':'Protected current source and validation inputs plus root Git identity. Artifact/README/docs subtrees retained at official root SHA; no holdout contents read.'}
with (OUT/'actual-P-complete-source-audit.json').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({k:result[k] for k in ['source','tree','raw_commit_sha_reconstructed','Git_tree_objects_independently_reconstructed','product_count','validation_count','delta_count','counts']}))
