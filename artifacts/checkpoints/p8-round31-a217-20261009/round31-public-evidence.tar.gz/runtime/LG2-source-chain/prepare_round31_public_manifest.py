#!/usr/bin/env python3
"""Inventory the finite G2 approval execution and identity-only intake evidence."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import stat

B = Path('/workspace/scratch/a217aaae3bde')
I = B / 'p8-db-lock-observation-integration'
OUT = B / 'original-LG2-runtime/round31-public-archive'


def identity(p):
    raw = p.read_bytes()
    assert not re.search(rb'"(?:file_id|file_uri|authorization|signed_url)"\s*:', raw, re.I), str(p)
    assert not re.search(rb'[?&](?:X-Amz-Signature|sig)=[A-Za-z0-9%]{12,}', raw), str(p)
    return dict(source=p.relative_to(B).as_posix(), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest(),
                git_blob=hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
                mode=format(stat.S_IMODE(p.stat().st_mode), '04o'))


def main():
    OUT.mkdir(exist_ok=True)
    assert not any(OUT.iterdir()), 'do not overwrite a frozen public manifest'
    selected = []
    def add(p, target):
        assert p.is_file() and not p.is_symlink()
        selected.append(dict(target=target, **identity(p)))
    for folder in ['LG2-actual-P2-proof-v2', 'LG2-actual-G2-proof', 'LG2-remote-originals']:
        for p in sorted((I / folder).rglob('*')):
            if p.is_file():
                add(p, 'runtime/LG2-source-chain/' + folder + '/' + p.relative_to(I / folder).as_posix())
    names = ['prepare_P2_actual_view.v1.py', 'prepare_P2_actual_view.py',
             'LG2-actual-P2-preparation.stdout.txt', 'LG2-actual-P2-preparation.stderr.txt',
             'LG2-actual-P2-preparation-v2.stdout.txt', 'LG2-actual-P2-preparation-v2.stderr.txt',
             'LG2-three-path-repair-inputs.json', 'LG2-final-composition-inputs.json',
             'prepare_G2_actual_view.py', 'LG2-actual-G2-preparation.stdout.txt',
             'LG2-actual-G2-preparation.stderr.txt', 'run_G2_original_v15_once.py',
             'LG2-original-v15-wrapper.stdout.txt', 'LG2-original-v15-wrapper.stderr.txt']
    for name in names:
        add(I / name, 'runtime/LG2-source-chain/' + name)
    base = B / 'original-LG2-runtime'
    for name in ['identity-adaptation-manifest.json', 'intake-plan.json', 'source-and-observer-proof.json',
                 'prepare_identity_adapter.py', 'identity-preparation.stdout.txt', 'identity-preparation.stderr.txt']:
        add(base / name, 'runtime/LG2-intake/' + name)
    for folder in ['helpers-LG2-v1', 'monitor-initial']:
        for p in sorted((base / folder).rglob('*')):
            if p.is_file():
                add(p, 'runtime/LG2-intake/' + folder + '/' + p.relative_to(base / folder).as_posix())
    peer = base / 'LG2-intake-identity-independent-review.json'
    if peer.exists():
        add(peer, 'runtime/LG2-intake/' + peer.name)
    add(Path(__file__).resolve(), 'runtime/LG2-source-chain/prepare_round31_public_manifest.py')
    for name in ['prepare_round31_public_manifest.v1.py', 'public-manifest-preparation-v1-failure.json']:
        add(base / name, 'runtime/LG2-source-chain/' + name)
    assert len({x['source'] for x in selected}) == len(selected)
    assert len({x['target'] for x in selected}) == len(selected)
    selected.sort(key=lambda x: x['target'])
    record = dict(schema='round31-G2-chain-and-intake-public-inventory-v1',
                  created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  source='4d18dcdb34b5d7a277566b57801cc882d8b1eb61',
                  product='b79f7749eb8f0a6c728493adfb073ca7db5563be',
                  review='87c697343f9d5a465cac7527f2e16933410ccd26',
                  diagnostic_run=37930392164, diagnostic_run_attempt=1, diagnostic_event='push',
                  file_count=len(selected), total_bytes=sum(x['bytes'] for x in selected), files=selected,
                  preserved_preparation_failure='First P2 preparation exit1: missing new workflow Git blob before any guard/native execution; original script/stdout/stderr retained.',
                  accepted_execution='One exact G2 original v15 invocation: exit0, 260.052307088 seconds, 1851 inputs unchanged, 187 historical materialized inputs retained.',
                  native_or_rust_controls='not_run_by_this_agent',
                  diagnostic_artifact_acceptance='not_run; no diagnostic raw artifact existed at the initial official capture',
                  custody_scope='This manifest only inventories the listed small source/approval/observer records; it is not an original ZIP archive or proof of remote publication.',
                  excluded=['private transfer captures and identifiers', 'original native ZIPs and executables',
                            'derived historical Git checkouts', 'old LG failure relabeling',
                            'old C or other-source measurement relabeling'],
                  other_round31_evidence='Current C final soak has separate preserved acceptance records, outside this finite G2 manifest.',
                  formal_task_completion=False, formal_done=163, formal_remaining=29)
    raw = (json.dumps(record, sort_keys=True, indent=2) + '\n').encode()
    path = OUT / 'new-public-files-manifest.json'
    path.open('xb').write(raw)
    print(json.dumps(dict(manifest=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                          file_count=len(selected), total_bytes=record['total_bytes'])), flush=True)


if __name__ == '__main__':
    main()
