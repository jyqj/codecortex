import pathlib,json,hashlib,zipfile,stat,datetime
R=pathlib.Path('/workspace/scratch/bfccb8494ba0')
D=R/'round42-new45-build-original-intake'
zpath=R/'round42-new45-original-artifacts/p8-task-build-38026411200-1-original.zip'
meta=json.loads((R/'round42-new45-study/build-artifact-original-metadata.json').read_text())
original=meta['original_artifact'];data=zpath.read_bytes()
assert len(data)==original['size_in_bytes']==9250795
assert hashlib.sha256(data).hexdigest()==original['digest'].removeprefix('sha256:')=='65ae643b212d826533aa74a55c69e875ea964751966c5487434adbdfb57ac3b9'
assert meta['source']==original['workflow_run']['head_sha']=='f97c5068d056969705e8387ba1f37d83847f5bee'
assert meta['run_id']==original['workflow_run']['id']==38026411200 and meta['attempt']==1
assert original['id']==11659139900 and original['name']=='p8-task-build-38026411200-1'
out=D/'original-build';out.mkdir()
entries=[];seen=set()
with zipfile.ZipFile(zpath) as z:
 for item in z.infolist():
  p=pathlib.PurePosixPath(item.filename)
  assert item.filename not in seen and not p.is_absolute() and '..' not in p.parts and '\\' not in item.filename
  seen.add(item.filename);mode=(item.external_attr>>16)&0xffff
  assert not stat.S_ISLNK(mode) and not item.flag_bits&1
  dest=out.joinpath(*p.parts)
  if item.is_dir(): dest.mkdir(parents=True,exist_ok=True);continue
  assert item.file_size < 128*1024*1024
  b=z.read(item) # one full read with original member CRC validation
  assert len(b)==item.file_size
  dest.parent.mkdir(parents=True,exist_ok=True)
  with dest.open('xb') as f:f.write(b)
  restored=(mode&0o777) or 0o644;dest.chmod(restored)
  entries.append({'path':item.filename,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'zip_crc32':f'{item.CRC:08x}','zip_mode':oct(mode),'restored_mode':oct(restored)})
record={'schema':'original-build-transport-v1','recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'official_metadata':meta,'whole_zip':{'path':str(zpath),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()},'member_read_and_crc_passes':1,'members':entries,'extracted_directory':str(out),'original_validate_build_calls':0,'native_measurements':0}
(D/'transport-original.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'members':len(entries),'bytes':sum(x['bytes'] for x in entries),'directory':str(out)}))
