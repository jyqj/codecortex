def stable_00190():
    return 190
