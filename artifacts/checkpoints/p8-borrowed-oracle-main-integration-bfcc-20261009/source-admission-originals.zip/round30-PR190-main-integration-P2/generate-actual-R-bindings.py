#!/usr/bin/env python3
"""Generate two binding files for an actual installed independent R; does not execute guard."""
import copy, hashlib, json, pathlib, re
ROOT=pathlib.Path(__file__).resolve().parent
P="2b6e9ebf2baeb8102df72d09360700e23487f870"
REVIEW_PATH="artifacts/checkpoints/p8-borrowed-oracle-main-integration-bfcc-20261009/independent-source-review.json"
ALLOWED={"product_source","review_source","review_sha256","complete_inputs","delta"}
def h(b):return hashlib.sha256(b).hexdigest()
def oid(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def load(p):return json.loads((ROOT/p).read_text())
def tree_id(entries):
    entries=sorted(entries,key=lambda x:(x["path"]+("/" if x["type"]=="tree" else "")).encode())
    b=b"".join((("40000" if x["type"]=="tree" else x["mode"])+" "+x["path"]).encode()+b"\0"+bytes.fromhex(x["sha"]) for x in entries)
    return hashlib.sha1(b"tree "+str(len(b)).encode()+b"\0"+b).hexdigest()
def main():
    config=load("actual-R-binding-input.json")
    r=load("official/actual-R-commit.original.json")
    compare=load("official/actual-R-compare.original.json")
    assert re.fullmatch("[0-9a-f]{40}",config["review_commit"]) and r["sha"]==config["review_commit"]
    assert [x["sha"] for x in r["parents"]]==[P]
    assert len(compare["files"])==2 and all(x["status"]=="added" for x in compare["files"])
    assert {x["filename"] for x in compare["files"]}==set(config["installed_artifact_paths"])
    raw=(ROOT/"independent-source-review.json").read_bytes();review=json.loads(raw)
    assert review["source"]==P and review["source_tree"]=="87c26e8953a648bdaa9be90cf7dfbb553adeb106"
    assert review["review_path"]==REVIEW_PATH and review["unresolved_blockers"]==[]
    record=next(x for x in compare["files"] if x["filename"]==REVIEW_PATH)
    assert oid(raw)==record["sha"]==config["canonical_git_blob"]
    maps=load("actual-P2-complete-domain.json")
    for key in ("complete_inputs","paths","validation_inputs","actual_input_mode_blob_inventory"):
        assert review[key]==maps[key],key
    assert (len(review["complete_inputs"]),len(review["paths"]),len(review["validation_inputs"]))==(1096,79,146)
    seed=load("seed-main-registry.json")
    assert seed["complete_inputs"].keys()==review["complete_inputs"].keys()
    assert seed["validation_inputs"]==review["validation_inputs"]
    registry=copy.deepcopy(seed)
    registry.update(product_source=P,review_source=r["sha"],review_sha256=h(raw),
                    complete_inputs=review["complete_inputs"],delta=review["paths"])
    differences={k for k in seed if seed[k]!=registry[k]}
    assert differences==ALLOWED and seed.keys()==registry.keys(),differences
    assert [k for k in seed["complete_inputs"] if seed["complete_inputs"][k]!=registry["complete_inputs"][k]]==["crates/cc-eval/src/benchmark/oracle.rs", "crates/cc-server/tests/p7_v18_parameter_contract.rs"]
    assert [k for k in seed["delta"] if seed["delta"][k]!=registry["delta"][k]]==["crates/cc-eval/src/benchmark/oracle.rs"]
    assert all(seed["delta"][k]["before_sha256"]==registry["delta"][k]["before_sha256"] for k in seed["delta"])
    added_delta=set(registry["delta"])-set(seed["delta"])
    assert added_delta=={"crates/cc-server/tests/p7_v18_parameter_contract.rs"}
    assert set(seed["delta"]).issubset(registry["delta"])
    added_path=next(iter(added_delta))
    assert registry["delta"][added_path]["before_sha256"]=="48ca0e43e6a1b673f4e4ec3e7bb8fab2710e387b8d2fe4a21f216db83b277361"
    registry_raw=(json.dumps(registry,ensure_ascii=False,indent=2,sort_keys=True)+"\n").encode()
    before=(ROOT/"seed-main-guard.py").read_text()
    new_values={"PRODUCT":P,"REVIEW":r["sha"],"REVIEW_PATH":REVIEW_PATH,"REGISTRY_SHA256":h(registry_raw)}
    guard=before;old_values={}
    for key,value in new_values.items():
        pattern=r"^"+key+r' = "([^"]+)"$'
        matches=re.findall(pattern,guard,re.M);assert len(matches)==1,key;old_values[key]=matches[0]
        guard,n=re.subn(pattern,lambda m:key+' = "'+value+'"',guard,flags=re.M);assert n==1
    restored=guard
    for key,value in old_values.items():
        restored,n=re.subn(r"^"+key+r' = "([^"]+)"$',lambda m:key+' = "'+value+'"',restored,flags=re.M);assert n==1
    assert restored==before
    guard_raw=guard.encode()
    root=load("official/actual-R-root-tree.original.json");scripts=load("official/actual-R-scripts-tree.original.json")
    assert root["truncated"] is False and scripts["truncated"] is False
    assert tree_id(root["tree"])==root["sha"]==r["tree"]["sha"]
    assert tree_id(scripts["tree"])==scripts["sha"]==next(x for x in root["tree"] if x["path"]=="scripts")["sha"]
    seed_paths={"reviewed-source-registry-v15.json":(ROOT/"seed-main-registry.json").read_bytes(),
                "verify_reviewed_source_v15.py":(ROOT/"seed-main-guard.py").read_bytes()}
    for name,data in seed_paths.items():
        assert next(x for x in scripts["tree"] if x["path"]==name)["sha"]==oid(data)
    payloads={"scripts/reviewed-source-registry-v15.json":registry_raw,"scripts/verify_reviewed_source_v15.py":guard_raw}
    elements=[]
    out=ROOT/"generated";out.mkdir(exist_ok=False)
    for path,data in payloads.items():
        f=out/path;f.parent.mkdir(parents=True,exist_ok=True)
        with f.open("xb") as stream:stream.write(data)
        elements.append({"path":path,"type":"blob","mode":"100644","sha":oid(data)})
    se=copy.deepcopy(scripts["tree"])
    for e in elements:next(x for x in se if x["path"]==e["path"].split("/")[-1])["sha"]=e["sha"]
    new_scripts=tree_id(se);re_=copy.deepcopy(root["tree"]);next(x for x in re_ if x["path"]=="scripts")["sha"]=new_scripts
    manifest={"schema":"pr190-main-two-bindings-generation-v1","actual_product":P,"actual_review":r["sha"],
              "expected_G":None,"expected_G_tree":tree_id(re_),"expected_G_parent":r["sha"],
              "registry_changed_fields":sorted(differences),"guard_changed_pins":new_values,
              "all_other_guard_bytes_unchanged":True,"validation_inputs_unchanged":True,
              "all_existing_BASE_before_hashes_unchanged":True,"new_BASE_delta":sorted(added_delta),"counts":{"product":1096,"BASE_delta":79,"validation":146},
              "files":[{"path":k,"bytes":len(v),"sha256":h(v),"git_blob":oid(v)} for k,v in payloads.items()],
              "execution_boundary":"Binding generator only, not v15/Rust execution or source performance acceptance.",
              "reviewer_admission":"The canonical independent source review is separate from this mechanical author generation."}
    (ROOT/"generation-manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
    (ROOT/"two-binding-create-tree-request.json").write_text(json.dumps({"repository_full_name":"jyqj/codecortex","base_tree_sha":root["sha"],"tree_elements":elements},indent=2)+"\n")
    print(json.dumps(manifest,sort_keys=True))
if __name__=="__main__":main()

