def stable_00220():
    return 220
