# CodeCortex benchmark baseline

Suite: `V19 TypeScript 03 codecortex-native-v1 candidate; review/custody pending`
Adapter: `mcp-stdio`
Scoring: `Native`
Measurement profile: `quality`

Status: **gate_failed** (exit 1)

Queries: 16; measured rows: 48.
Mean Top-1: 0.538462; mean nDCG@10: 0.521700.

These are baseline observations, not a release quality certificate.
Latency: Distribution { samples: 0, p50_us: None, p95_us: None, max_us: None, tail_claim: "insufficient_for_tail_claim" }; samples are retained, not best-of.
Source evidence: 0 invalid, 0 unverified hits.

| Case | Top-1 | nDCG@10 | Repetitions |
|---|---:|---:|---:|
| v19.typescript.f0041.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0045.en01 | 0.000000 | 0.000000 | 3 |
| v19.typescript.f0046.en01 | 0.000000 | 0.000000 | 3 |
| v19.typescript.f0047.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0048.en01 | 0.000000 | 0.630930 | 3 |
| v19.typescript.f0049.en01 | 0.000000 | 0.000000 | 3 |
| v19.typescript.f0050.en01 | 1.000000 | 0.703918 | 3 |
| v19.typescript.f0051.en01 | 0.000000 | 0.469279 | 3 |
| v19.typescript.f0052.en01 | 1.000000 | 0.703918 | 3 |
| v19.typescript.f0053.en01 | 1.000000 | 0.570141 | 3 |
| v19.typescript.f0055.en01 | 0.000000 | 0.000000 | 3 |
| v19.typescript.f0056.en01 | 1.000000 | 0.703918 | 3 |
| v19.typescript.f0057.en01 | 1.000000 | 1.000000 | 3 |

## Failures

- v19.typescript.f0060.en01 Partial
- v19.typescript.f0060.en01 no-answer failure
- v19.typescript.f0052.en01 Partial
- v19.typescript.f0056.en01 Partial
- v19.typescript.f0051.en01 Partial
- v19.typescript.f0050.en01 Partial
- v19.typescript.f0048.en01 Partial
- v19.typescript.f0053.en01 Partial
- v19.typescript.f0059.en01 Partial
- v19.typescript.f0059.en01 no-answer failure
- v19.typescript.f0045.en01 Partial
- v19.typescript.f0041.en01 Partial
- v19.typescript.f0046.en01 Partial
- v19.typescript.f0057.en01 Partial
- v19.typescript.f0049.en01 Partial
- v19.typescript.f0047.en01 Partial
- v19.typescript.f0058.en01 Partial
- v19.typescript.f0058.en01 no-answer failure
- v19.typescript.f0055.en01 Partial
- v19.typescript.f0053.en01 Partial
- v19.typescript.f0049.en01 Partial
- v19.typescript.f0050.en01 Partial
- v19.typescript.f0060.en01 Partial
- v19.typescript.f0060.en01 no-answer failure
- v19.typescript.f0056.en01 Partial
- v19.typescript.f0059.en01 Partial
- v19.typescript.f0059.en01 no-answer failure
- v19.typescript.f0046.en01 Partial
- v19.typescript.f0041.en01 Partial
- v19.typescript.f0057.en01 Partial
- v19.typescript.f0051.en01 Partial
- v19.typescript.f0048.en01 Partial
- v19.typescript.f0047.en01 Partial
- v19.typescript.f0045.en01 Partial
- v19.typescript.f0055.en01 Partial
- v19.typescript.f0052.en01 Partial
- v19.typescript.f0058.en01 Partial
- v19.typescript.f0058.en01 no-answer failure
- v19.typescript.f0053.en01 Partial
- v19.typescript.f0048.en01 Partial
- v19.typescript.f0052.en01 Partial
- v19.typescript.f0059.en01 Partial
- v19.typescript.f0059.en01 no-answer failure
- v19.typescript.f0049.en01 Partial
- v19.typescript.f0047.en01 Partial
- v19.typescript.f0050.en01 Partial
- v19.typescript.f0055.en01 Partial
- v19.typescript.f0041.en01 Partial
- v19.typescript.f0058.en01 Partial
- v19.typescript.f0058.en01 no-answer failure
- v19.typescript.f0051.en01 Partial
- v19.typescript.f0046.en01 Partial
- v19.typescript.f0060.en01 Partial
- v19.typescript.f0060.en01 no-answer failure
- v19.typescript.f0056.en01 Partial
- v19.typescript.f0045.en01 Partial
- v19.typescript.f0057.en01 Partial