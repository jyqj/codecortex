from pathlib import Path
import sys,json,hashlib,shutil,subprocess,datetime
B=Path('/dev/shm/execution-recon-recovery-20261009')
D=B/'round23-G8B-shard-1000-11634192619';D.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(name,obj):
 with (D/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
O=B/'round23-study-observation-1738'
run=json.loads(json.loads((O/'G8-run.original.json').read_text())['response_content'])
arts=json.loads(json.loads((O/'G8-artifacts.original.json').read_text())['response_content'])['artifacts']
artifact=next(x for x in arts if x['id']==11634192619)
assert run['head_sha']=='4fe927488d5cb7f26bd27c7624745fb1b6ca202b' and run['run_attempt']==1
write('run.json',run);write('artifact.json',artifact)
s=Path('/workspace/scratch/bfccb8494ba0/G8B-scale-intake/raw/37962416564/11634192619/attempt01/p8-scale-shard-1000-0-37962416564-original.zip')
raw=s.read_bytes();assert len(raw)==artifact['size_in_bytes']==953353
assert sha(raw)=='55f268870819dc27f379db0a4d88f76f717cecb8030632221ed51b2ce5ce7c82'
with (D/'original.zip').open('xb') as f:f.write(raw)
assert s.read_bytes()==(D/'original.zip').read_bytes()==raw
write('materialize-to-RAM-copy-receipt.json',{'source':str(s),'destination':str(D/'original.zip'),'bytes':len(raw),'sha256':sha(raw),'source_destination_before_after_equal':True,'file_id':'file_000000006b8481f5bc4eb7e86f51cb91','formal_root_transfer_receipt':'/dev/shm/root-round23/G8-1000-materialize-original.json'})
old=(B/'round23-G8B-shard-5000-11633585491/validate-original-shard.py').read_text()
new=old.replace("[5000]","[1000]").replace("original-5k-shard","original-1k-shard").replace('11633585491','11634192619').replace("'scale':5000","'scale':1000")
assert new!=old
(D/'validate-original-shard.py').write_text(new)
base=B/'round21-G8B-study-37962416564'
adapter=base/'receive-materialized-once.py'
assert sha(adapter.read_bytes())=='977eb3fe621bb54863a3ae593b1ca6932556b55a7989a8ec965a37292ee855b8'
commands=[('intake',[sys.executable,str(adapter),'--binding',str(base/'binding.actual-G8B-run37962416564.json'),'--run-metadata',str(D/'run.json'),'--artifact-metadata',str(D/'artifact.json'),'--zip',str(D/'original.zip'),'--output',str(D/'intake-attempt01')]),('validate',[sys.executable,str(D/'validate-original-shard.py')])]
for name,argv in commands:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (D/(name+'.stdout')).open('xb') as out,(D/(name+'.stderr')).open('xb') as err:
  proc=subprocess.run(argv,cwd='/',stdout=out,stderr=err)
 end=datetime.datetime.now(datetime.timezone.utc).isoformat()
 stdio={kind:{'bytes':(D/(name+'.'+kind)).stat().st_size,'sha256':sha((D/(name+'.'+kind)).read_bytes())} for kind in ['stdout','stderr']}
 write(name+'-command-receipt.json',{'argv':argv,'cwd':'/','started_UTC':start,'ended_UTC':end,'exit_code':proc.returncode,'stdio':stdio})
 print(name,proc.returncode,(D/(name+'.stdout')).read_text())
 if proc.returncode:raise SystemExit(proc.returncode)
