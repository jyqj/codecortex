// Cargo feature-label protocol fixture only; this is not the CodeCortex product.
#[test]
fn explicit_contract_fixture() {}
