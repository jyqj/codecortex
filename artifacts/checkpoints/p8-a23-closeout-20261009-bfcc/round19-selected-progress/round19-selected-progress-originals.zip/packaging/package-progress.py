#!/usr/bin/env python3
"""Append-only selected evidence sealing. No network, product execution or Git writes."""
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

ROOT=Path(__file__).resolve().parent
CONFIG=ROOT/'frozen-input-selection-config.json'
config=json.loads(CONFIG.read_text())
OUT=ROOT/'sealed-attempt01'
OUT.mkdir(exist_ok=False)
PREFIX='artifacts/checkpoints/p8-a23-closeout-20261009-bfcc/round19-selected-progress'
PARENT='62401c68e95af17034eb7a93a13d8cab4a3d6f2a'
PARENT_TREE='a9d45ad81f997c13051214540be485522b4d534a'
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def js(value):return (json.dumps(value,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode()
def rec(p):
    b=p.read_bytes()
    return {'local_path':str(p),'bytes':len(b),'sha256':sha(b),'git_blob':blob(b),'mode':'100644'}

payload={};members=[];sources=[]
R5_ZIP_MEMBER='unpublished-R5B-object-preservation/P5B-source-only-originals.zip'
def add_bytes(member,raw,mode=0o644):
    path=PurePosixPath(member)
    assert member not in payload and not path.is_absolute() and '..' not in path.parts
    assert '\x00'not in member and '\\'not in member
    assert not member.lower().endswith('.zip') or member==R5_ZIP_MEMBER
    payload[member]=(raw,mode)
    members.append({'path':member,'bytes':len(raw),'sha256':sha(raw),'git_blob':blob(raw),'posix_mode':format(mode,'04o')})
def add_file(path,member,expected=None,origin=None):
    assert path.is_file() and not path.is_symlink()
    st=path.stat();assert stat.S_ISREG(st.st_mode)
    raw=path.read_bytes();mode=stat.S_IMODE(st.st_mode)
    if expected:
        assert len(raw)==expected['bytes'] and sha(raw)==expected['sha256'],str(path)
        oid=expected.get('git_blob',expected.get('expected_git_blob'))
        if oid:assert blob(raw)==oid
        declared=expected.get('posix_mode',expected.get('mode'))
        if declared and len(str(declared))<=4:assert mode==int(str(declared),8)
    add_bytes(member,raw,mode)
    sources.append({'local_path':str(path),'member':member,'bytes':len(raw),'sha256':sha(raw),'git_blob':blob(raw),'posix_mode':format(mode,'04o'),'source_mtime_ns':st.st_mtime_ns,'origin':origin})

assert config['missing_required_items']==[]
closeout=json.loads(Path('/dev/shm/root-round19/round19-formal-closeout.json').read_text())
assert closeout['round']==19 and closeout['state']=='closed'
assert closeout['recorded_at']=='2026-10-09 15:26:31 UTC'
assert closeout['next_round']=={'round':20,'state':'active'}
assert closeout['original_ledger']['remaining']==29 and closeout['original_ledger']['new_original_completions_this_round']==0
for group in config['groups']:
    p=Path(group['selection_path']);raw=p.read_bytes()
    assert sha(raw)==group['sha256'] and len(raw)==group['bytes']
    data=json.loads(raw);rows=data['files']
    assert len(rows)==group['file_count']
    assert sum(x['bytes']for x in rows)==group['selected_bytes']
    add_file(p,'selections/'+group['name']+'.json',origin=group['name'])
    for row in rows:
        path=Path(row.get('local_path',row.get('source_path')))
        relative=row.get('archive_path',row.get('relative_path',row.get('repository_path')))
        assert relative
        add_file(path,'evidence/'+group['name']+'/'+relative,row,group['name'])
for row in config['root_receipts']:
    add_file(Path(row['local_path']),'evidence/root-round19/'+Path(row['local_path']).name,row,'root-public-original-receipts')

# These own R5B objects have no published source ref. Preserve their exact bytes
# once, together with the original installation manifest. The one small ZIP is
# explicitly permitted; no prior checkpoint/R4/R3 archive is nested.
upload_path=Path('/dev/shm/pr-triage-P5B-preselect-format-source-review/upload-manifest.json')
upload=json.loads(upload_path.read_text())
assert upload['source_P']=='d21e140ca9ebb5a73294358d64a839466c5a0076'
assert len(upload['files'])==2
add_file(upload_path,'unpublished-R5B-object-preservation/original-upload-manifest.json',origin='R5B-unpublished-object-preservation')
for row in upload['files']:
    path=Path(row['local_path'])
    add_file(path,'unpublished-R5B-object-preservation/'+path.name,row,'R5B-unpublished-object-preservation')
zip_path=Path(next(x['local_path']for x in upload['files']if x['local_path'].endswith('.zip')))
with zipfile.ZipFile(zip_path)as z:
    assert len(z.namelist())==54 and z.testzip() is None
    assert not any(n.lower().endswith('.zip')for n in z.namelist())

equiv=json.loads(Path('/dev/shm/pr-triage-P5B-preselect-format-source-review/external-M7F-equivalence/independent-M7F-versus-G5B-equivalence-review.json').read_text())
assert equiv['entire_P_trees_equal'] and equiv['own_P5B_tree']==equiv['external_P_tree']=='7fb46257805e9da89737ef7a6a05574b83f50d79'
assert equiv['published_external_G']=='fffd950d5b34b0180f308db1428a57d5bf358bf1'
prior_upload=json.loads(Path('/dev/shm/execution-recon-recovery-20261009/round18-closeout-package/sealed-attempt01/final-root-upload-manifest.json').read_text())
prior_zip=next(x for x in prior_upload['files']if x['repository_path'].endswith('.zip'))
oldlocators=json.loads(Path('/dev/shm/execution-recon-recovery-20261009/round18-closeout-package/sealed-attempt01/immutable-evidence-locators.json').read_text())
locators={'schema':'already-published-evidence-locators-v1','not_nested':[{'commit':PARENT,'repository_path':prior_zip['repository_path'],'bytes':prior_zip['bytes'],'sha256':prior_zip['sha256'],'git_blob':prior_zip['git_blob'],'purpose':'round18-closeout-92-members'},*oldlocators['not_nested_in_this_archive']], 'R3_reference':{'commit':'4ec7543db94699077fe4075dd4b3606e92482460','repository_path':'artifacts/checkpoints/p8-dependency-exclusion-bfcc-20261009/source-only-review-originals.zip','git_blob':'1286272bda6b1e1b75b8b12e733b867ffb87b9bd','sha256':'97f34cd80db4c4b258a6e9440aa0e5fbcc5f447a7b15e4a6b40941b89a443748','not_nested':True}}
summary={'schema':'round19-in-progress-selected-checkpoint-v1','sealed_at_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'round19_status':'in_progress','original_TODO':{'new_complete':0,'done':163,'remaining':29,'total':192},'prior_checkpoint':{'commit':PARENT,'tree':PARENT_TREE},'management_scope':{'PR3_PR4':'retain historical draft scope per original bounded decisions; no broad whole-repository coverage claim','PR127_PR137':'preserve original bounded reviews and retention decisions; no new closure or execution claim','PR65':'retain open draft; metadata-limited decision and uncertainty retained'},'own_unpublished_chain':{'P5B':'d21e140ca9ebb5a73294358d64a839466c5a0076','R5B':'cef789c9072e659e2026c33b537833edeaf775c9','G5B':'666eadb8d30392305373c6701b53e300182c5355','product_tree':'7fb46257805e9da89737ef7a6a05574b83f50d79','remote_objects_created':True,'source_ref_published':False,'duplicate_CI_triggered':False,'R5B_canonical_and_support_original_bytes_preserved_once':True},'published_external_M7F':{'G':equiv['published_external_G'],'R':equiv['external_R'],'P':equiv['external_P'],'product_tree':equiv['external_P_tree'],'entire_product_tree_equals_own_P5B':True,'independent_source_binding_review_accepted':True,'R_G_identities_not_interchangeable':True,'CI_source_not_transferred_to_own_G5B':True,'seven_existing_workflows_retained_as_observed_not_repolled':True,'CI_runtime_acceptance_not_granted_by_equivalence':True},'PR188_G4':{'source':'cc177ddc9e6b8180b8d847539787672e7b689a1a','head_base_not_modified_by_this_package':True,'included_observation':'15:19 original check in_progress; default regression step success, resource/source gate in_progress; no individual nine-test/source-CLI terminal claim'},'C3ff_scale':{'run':37910924354,'source':'3ffcefc3b28ee1a4ed80caecebd7208a45c3e302','attempt':1,'included_observation':'15:19 original 100k step7 in_progress; original10artifact index unchanged; no elapsed-time terminal inference','new_samples_accepted':0},'b2_original_failures':'Original main-CI formatter failure and separately selected actual ready-PID failure retained with their own source/job/first-error scope. No rerun or candidate runtime result inferred.', 'external_SQL_narrative':'External canonical wording is retained as its authors statement. It does not pin a rejected exact SQL candidate SHA/blob or concrete correctness counterexample; this package does not adopt it as rejection of exact G4 or identify it with the already-retained +22.57% sparse Python VM counterexample. See the scoped independent note.', 'source_selections':config['groups'],'root_receipt_count':len(config['root_receipts']),'missing_required_items':[],'evidence_scope':'Selected original evidence, not a complete repository/archive mirror. Prior pending/negative bytes are preserved. No measurement, source CLI, test, remote ref, PR, label or workflow action was executed by this packager.'}
original_manifest={'schema':'round19-original-byte-custody-v1','files':list(sources),'file_count':len(sources),'all_declared_selection_bytes_SHA_Gitblob_and_modes_checked':True}
summary.update({'schema':'round19-closed-selected-checkpoint-v1','round19_status':'closed','formal_closeout_at_UTC':closeout['recorded_at'],'next_round':closeout['next_round'],'sealed_at_clock_scope':'Local packaging runtime clock; formal round boundary is the separately preserved root record.','cross_round_ready_PID_review':'Work began in round19 and finished during round20; included source-applicability materials do not claim candidate execution or a TODO completion.','later_round20_C3ff_terminal_evidence_included':False,'round20_P6B_creation_included':False,'historical_in_progress_snapshots_unchanged':True})
for name,value in [('checkpoint-summary.json',summary),('immutable-evidence-locators.json',locators),('selected-original-manifest.json',original_manifest)]:
    raw=js(value);(OUT/name).write_bytes(raw);add_bytes(name,raw)
add_file(CONFIG,'packaging/frozen-input-selection-config.json',origin='actual-packaging-config')
add_file(Path(__file__),'packaging/package-progress.py',origin='actual-packager')
archive=OUT/'round19-selected-progress-originals.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
    for name in sorted(payload):
        raw,mode=payload[name];i=zipfile.ZipInfo(name,date_time=(2026,10,9,0,0,0));i.create_system=3;i.external_attr=(stat.S_IFREG|mode)<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,raw)
with zipfile.ZipFile(archive)as z:
    assert z.testzip()is None and sorted(z.namelist())==sorted(payload)
    for i in z.infolist():
        raw,mode=payload[i.filename]
        assert z.read(i)==raw and stat.S_IMODE(i.external_attr>>16)==mode
for row in sources:
    p=Path(row['local_path']);raw=p.read_bytes()
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256'] and blob(raw)==row['git_blob']
    assert format(stat.S_IMODE(p.stat().st_mode),'04o')==row['posix_mode']
member_manifest={'schema':'round19-ZIP-member-manifest-v1','ZIP':rec(archive),'member_count':len(members),'total_uncompressed_bytes':sum(x['bytes']for x in members),'files':sorted(members,key=lambda x:x['path']),'all_members_bytes_SHA_Gitblob_CRC_POSIX_mode_verified':True,'source_before_after_equal':True,'ZIP_timestamp_normalized_source_mtime_recorded_separately':True}
(OUT/'zip-member-manifest.json').write_bytes(js(member_manifest))
result={'schema':'round19-actual-packaging-result-v1','status':'sealed_verified','ZIP':rec(archive),'ZIP_members':len(members),'selection_groups':len(config['groups']),'selected_files':sum(x['file_count']for x in config['groups']),'root_receipts':len(config['root_receipts']),'unpublished_R5B_original_artifacts':2,'allowed_nested_ZIP_exactly_one_R5B_54_members':True,'prior_checkpoint_R4_R3_ZIPs_nested':False,'all_original_before_after_hashes_modes_equal':True,'all_ZIP_members_CRC_SHA_mode_verified':True,'remote_uploaded':False,'TODO_new_complete':0,'TODO_remaining':29,'round19_status':'closed','formal_closeout_at_UTC':closeout['recorded_at'],'next_round':closeout['next_round'],'cross_round_ready_PID_review_included':True,'later_round20_C3ff_terminal_evidence_included':False}
(OUT/'packaging-result.json').write_bytes(js(result))
manifest={'schema':'round19-root-upload-manifest-v1','suggested_parent':PARENT,'suggested_parent_tree':PARENT_TREE,'artifact_only':True,'remote_uploaded':False,'files':[]}
for name in ['round19-selected-progress-originals.zip','zip-member-manifest.json','checkpoint-summary.json','immutable-evidence-locators.json','selected-original-manifest.json','packaging-result.json']:
    row=rec(OUT/name);row['repository_path']=PREFIX+'/'+name;manifest['files'].append(row)
(OUT/'upload-manifest.pending-command-receipt.json').write_bytes(js(manifest))
print(json.dumps(result,sort_keys=True))
