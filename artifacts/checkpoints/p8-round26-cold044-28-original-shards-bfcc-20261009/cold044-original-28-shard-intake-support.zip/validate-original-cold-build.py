import pathlib,json,hashlib,subprocess,sys,datetime,time,traceback,os
B=pathlib.Path(__file__).resolve().parent
ROOT=B/"source"; BUILD=B/"build-restoration/extracted"; OUT=B/"original-build-validation-attempt01"
OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/"scripts")); import p8_cold_matrix as cold; import p8_scale_matrix as full
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snap():
 return {"head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip(),"index_sha256":sha(ROOT/".git/index"),"source":full.source_snapshot(ROOT),"observer":cold.driver_snapshot(ROOT),"build_inventory":full.inventory(BUILD)}
binary=BUILD/"native-build/p8-scale"; mode_before=oct(binary.stat().st_mode&0o777); binary.chmod((binary.stat().st_mode&0o777)|0o111)
(OUT/"executable-mode-receipt.json").write_text(json.dumps({"before":mode_before,"after":oct(binary.stat().st_mode&0o777),"sha256":sha(binary),"bytes":binary.stat().st_size,"method":"restore executable bit on extracted original ELF; no byte changes"},indent=2)+"\n")
started=full.utc();begin=time.monotonic();code=0;error=None
before=snap();(OUT/"source-before.json").write_text(json.dumps(before,indent=2)+"\n")
try:
 assert before["head"]=="044c008c9459cfa61e7701db2eb868342c508a39"
 outer,built,elf=cold.validate_build(BUILD,ROOT)
 (OUT/"original-validate-build-output.json").write_text(json.dumps({"outer":outer,"built":built,"binary":str(elf)},indent=2)+"\n")
 print(json.dumps({"original_build_validator":"passed","source":before["head"],"input_count":before["source"]["input_count"],"binary_sha256":built["binary_sha256"]}),flush=True)
except BaseException as exc:code=1;error=type(exc).__name__+": "+str(exc);traceback.print_exc()
finally:
 after=snap();(OUT/"source-after.json").write_text(json.dumps(after,indent=2)+"\n")
 if before!=after:code=1;error=(error or "")+";input drift"
 (OUT/"receipt.json").write_text(json.dumps({"argv":[sys.executable,str(pathlib.Path(__file__).resolve())],"started":started,"finished":full.utc(),"elapsed_seconds":time.monotonic()-begin,"exit_code":code,"error":error,"source_unchanged":before==after,"scope":"original cold.validate_build; original retained ELF --hash-file only; no workload","accepted_samples":0},indent=2)+"\n")
raise SystemExit(code)

