def stable_00296():
    return 296
