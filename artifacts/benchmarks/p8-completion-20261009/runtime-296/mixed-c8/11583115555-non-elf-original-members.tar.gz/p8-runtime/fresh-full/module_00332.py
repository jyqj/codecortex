def stable_00332():
    return 332
