def stable_00414():
    return 414
