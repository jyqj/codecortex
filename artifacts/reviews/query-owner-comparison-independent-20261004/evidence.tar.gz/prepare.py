from pathlib import Path
import json
r=Path('/workspace/independent-comparison-review')
s=Path('/workspace/codecortex/artifacts/reviews/query-owner-hint-independent-20261004/independent_driver.rs').read_text()
probes=[]
def add(q, expected): probes.append({'query':q,'expected_owner_suppressed':expected})
for p in ['rather than','RATHER THAN','rather\tthan','rather\nthan','rather\u2003than','(rather than)','rather, than','"rather than"','`rather than`','instead of','INSTEAD OF','instead\tof','(instead of)','instead, of','“instead of”']:
 add(f'Which Beacon API {p} Sink accepts state?',False)
for p in ['RatherThan','rather_than','rather.than','rather-than','rather/than','rather::than','ratherX than','rather thanX','_rather than','rather than_','rather 2than','rather θthan','rather then','rather something than','instead_of','insteadof','instead.of','instead-of','instead x of','instead ofX','notrather than','rather thanSink','"rather_than"','`rather.than`','rаther than']:
 add(f'Which Beacon API calls {p} with Commit?',True)
for q in ['Which Beacon API rather lang:go than Sink accepts state?', 'Which Beacon API calls `rather()` `than()` with Commit?', 'Which Beacon API calls $rather $than with Commit?', 'Which Beacon API calls rather: than: with Commit?']:
 add(q,False)
for q in ['Which Beacon API changes the ready state with Commit?','Which method on Beacon changes the ready state with Commit?','Which Beacon API is deprecated?','Which Beacon API calls Commit/Accept?']: add(q,True)
for q in ['name:Beacon Which Beacon API rather than Sink accepts state?','kind:class Which Beacon API rather than Sink accepts state?','name:Commit kind:method Which Beacon API instead of Sink accepts state?','class Beacon','method Commit on Beacon','methods on Beacon','Beacon::Commit','(*Beacon).Commit','Which Beacon API calls Commit and Accept?']: add(q,False)
(r/'probes.json').write_text(json.dumps(probes,ensure_ascii=False,indent=2))
# Independent additions preserve historical cases/scorer/fixture and obtain fresh real API responses.
extra=''.join('        ('+json.dumps(x['query'],ensure_ascii=False).replace('\\u2003','\u2003')+', None),\n' for x in probes if x['query'] not in s)
s=s.replace('    ];\n    let mut result',extra+'    ];\n    let mut result').replace('22 synthetic queries','independent synthetic queries')
(r/'driver.rs').write_text(s)
for arm,src in [('delivery',Path('/workspace/codecortex')),('base',r/'base'),('candidate',r/'candidate')]:
 wrapper=f'''#[path = "{src}/crates/cc-search/src/dsl.rs"] mod dsl;
#[path = "{src}/crates/cc-search/src/query_target.rs"] mod query_target;
fn main() {{
let rows: serde_json::Value = serde_json::from_str(include_str!("{r}/probes.json")).unwrap();
let mut out=Vec::new();
for row in rows.as_array().unwrap() {{
 let q=row["query"].as_str().unwrap(); let parsed=dsl::parse_search_dsl(q);
 let t=query_target::QueryTarget::parse(&parsed); let ctx=query_target::NameBonusContext::parse(&parsed,&t);
 let tokens=cc_db::fts::tokenize_codeish(&parsed.text);
 let kinds=["class","interface","type_alias","enum","module","namespace","method","function","unknown"];
 let flags:Vec<_>=kinds.iter().map(|k| serde_json::json!({{"kind":k,"owner":ctx.permits("Beacon",Some(k)),"other":ctx.permits("Sink",Some(k)),"target":t.permits("Beacon",Some(k),&tokens)}})).collect();
 out.push(serde_json::json!({{"query":q,"dsl":parsed.text,"target":format!("{{:?}}",t),"context":format!("{{:?}}",ctx),"flags":flags,"expected_owner_suppressed":row["expected_owner_suppressed"]}}));
}}
println!("{{}}",serde_json::to_string_pretty(&out).unwrap());
}}
'''
 (r/f'probe-{arm}.rs').write_text(wrapper)
print(len(probes),'independent direct probes; engine/MCP total cases',s.count('        ("'))
