import pathlib,json,hashlib,subprocess,sys,time,datetime,zipfile,stat,shutil
B=pathlib.Path(__file__).resolve().parent;WORK=B.parent;NUM=8;request=json.loads((B/"increment-final-53/materialize-request.json").read_text());artifacts=json.loads((B/"increment-final-53/artifact-reference-ledger.json").read_text());byname={r["file_name"]:r["artifact"] for r in artifacts["items"]};out=B/"increment-final-53/intake";out.mkdir(exist_ok=False);records=[];code=0
sys.path.insert(0,str(B/"source/scripts")); import p8_scale_matrix as full
source_before=full.source_snapshot(B/"source"); assert source_before==json.loads((B/"original-build-validation-attempt01/source-before.json").read_text())["source"]
(out/"whole-source-before.json").write_text(json.dumps(source_before,indent=2)+"\n")
for item in request["items"]:
 a=byname[item["file_name"]];dest=B/"raw"/str(a["id"]);dest.mkdir(exist_ok=True);original=WORK/item["file_name"];copy=dest/item["file_name"]
 rec={"artifact":a,"file_id":item["file_id"],"source_workspace_path":str(original),"original_copy":str(copy),"sample_credit":0}
 try:
  assert original.is_file() and not original.is_symlink()
  data=original.read_bytes();h=hashlib.sha256(data).hexdigest();assert len(data)==a["size_in_bytes"] and "sha256:"+h==a["digest"]
  assert not copy.exists();shutil.copy2(original,copy)
  rec.update(original_zip_bytes=len(data),original_zip_sha256=h)
  if "-shard-" in a["name"]:
   argv=[sys.executable,str(B/"validate-original-cold-shard.final53.py"),str(a["id"])];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
   with (dest/"validator.stdout").open("xb") as stdout,(dest/"validator.stderr").open("xb") as stderr: child=subprocess.run(argv,stdout=stdout,stderr=stderr)
   terminal={"argv":argv,"started":started,"finished":datetime.datetime.now(datetime.timezone.utc).isoformat(),"exit_code":child.returncode}
   (dest/"validator-child.json").write_text(json.dumps(terminal,indent=2)+"\n");rec["validator_child"]=terminal
   assert child.returncode==0, "original validator failed; inspect retained stderr"
   rec["sample_credit"]=1
  else:
   target=dest/"capacity-transport-extracted";target.mkdir();members=[]
   with zipfile.ZipFile(copy) as z:
    seen=set()
    for i in z.infolist():
     p=pathlib.PurePosixPath(i.filename);m=i.external_attr>>16;assert not p.is_absolute() and ".." not in p.parts and not stat.S_ISLNK(m) and str(p) not in seen;seen.add(str(p))
     if i.is_dir():(target/p).mkdir(parents=True,exist_ok=True);continue
     raw=z.read(i);f=target/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);members.append({"path":str(p),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"crc32":i.CRC,"zip_mode":oct(m)})
   (dest/"capacity-zip-members.json").write_text(json.dumps(members,indent=2)+"\n");rec["capacity_transport_only"]=True;rec["members"]=members
  rec["status"]="accepted_original_shard" if rec["sample_credit"] else "transport_verified_capacity_no_sample"
 except BaseException as e:
  rec["status"]="failed";rec["error"]=type(e).__name__+": "+str(e);code=1
 records.append(rec);(out/"progress.json").write_text(json.dumps(records,indent=2)+"\n");print(json.dumps({"id":a["id"],"status":rec["status"],"sample_credit":rec["sample_credit"],"error":rec.get("error")}),flush=True)
 if code:break
source_after=full.source_snapshot(B/"source");(out/"whole-source-after.json").write_text(json.dumps(source_after,indent=2)+"\n"); assert source_before==source_after,"whole product input drift"
(out/"terminal.json").write_text(json.dumps({"exit_code":code,"batch":NUM,"records":len(records),"expected":len(request["items"]),"accepted_samples":sum(r["sample_credit"] for r in records),"newly_completed_todos":0,"remaining_todos":29,"workload_executed":False},indent=2)+"\n")
raise SystemExit(code)

