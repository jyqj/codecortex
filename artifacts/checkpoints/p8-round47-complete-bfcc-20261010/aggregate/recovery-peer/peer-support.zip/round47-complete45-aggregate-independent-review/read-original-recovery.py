import pathlib,json,hashlib,datetime,collections
ROOT=pathlib.Path('/workspace/scratch/bfccb8494ba0');D=ROOT/'round47-complete45-original-aggregate-recovery';O=pathlib.Path(__file__).parent;ids={};checks=0
G='f97c5068d056969705e8387ba1f37d83847f5bee'
def read(p):
 b=p.read_bytes();ids[str(p)]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'computed_git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()};return b
def load(p):return json.loads(read(p))
def eq(a,b,s):
 global checks
 assert a==b,s;checks+=1
def ok(a,s):eq(bool(a),True,s)
def put(n,j):(O/n).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
r=load(D/'original-aggregate-return.json');m=load(D/'aggregate-output/task-matrix.json');eq(r,m,'return/matrix semantic exact')
e=load(D/'original-recovery-execution.json');eq(e['exit_code'],0,'actualexit0');eq(e['child_invocations'],1,'once');eq(e['retries'],0,'no retries');eq(e['custody_faults'],[],'custody');ok(e['return_equals_actual_stdout'],'return stdout')
stdout=read(D/'original-aggregate.stdout');eq(stdout,read(D/'captured-stdout.frozen-original'),'dualstdout');eq(stdout,read(D/'original-aggregate-return.json'),'return actual stdout');eq(len(stdout),e['stdout']['bytes'],'stdoutsize');eq(hashlib.sha256(stdout).hexdigest(),e['stdout']['sha256'],'stdouthash');eq(read(D/'original-aggregate.stderr'),b'','stderr0');eq(read(D/'captured-stderr.frozen-original'),b'','dualstderr0')
before=load(D/'inputs-before.json');after=load(D/'inputs-after.json');eq(before,after,'fullinputsbeforeafter');eq(before['head'],G,'head');eq(len(before['source']),1107,'1096+11');eq(len(before['input_directories']),45,'whole45')
eq(load(D/'original-function-call-counts.json'),{'aggregate':1,'validate_build':1,'validate_shard':45,'combine':1},'actual functioncalls')
for n in ['invoke-original-aggregate-once.py','capture-original-recovery-once.py']:read(D/n)
eq((r['status'],r['passed'],r['cell_count'],r['record_count'],r['sample_count'],r['setup_pair_count'],r['mutation_sample_count'],r['fanout_sample_count']),('complete_task_descriptive_coverage',True,45,85,85,40,40,5),'counts')
eq(r['input_errors'],[],'noerrors');eq(r['missing_slots'],[],'nomissing');eq(r['accepted_cell_count'],45,'accepted45');eq(r['validated_input_count'],45,'validated45');eq(r['registered_repetitions'],1,'N1');eq(r['release_certification'],'not_run','notrelease');eq(r['G8'],'not_evaluated','notG8');eq(r['task_statuses_changed'],False,'tasksnotchanged')
cat=load(ROOT/'round47-new45-descriptive-analysis/accepted-45-descriptive-pending-aggregate-draft.json');cmap={tuple(c['slot']):c for c in cat['cells']};eq(len(cmap),45,'catalog45')
inputs={tuple(x['slot']):x for x in r['input_results']};cells={tuple(x['slot']):x for x in r['cells']};eq(set(cmap),set(cells),'exact45slots');eq(set(cmap),set(inputs),'exactinputslots')
expected_hash_targets={};retids=[]
build=ROOT/'round42-new45-build-original-intake';reg=load(build/'original-build/task-registry.json');binary=str(build/'original-build/native-build/p8-scale');expected_hash_targets[binary]=reg['binary_blake3']
eq(r['engine']['engine_head_observed'],G,'source');eq(r['engine']['binary_digest'],reg['binary_blake3'],'binary');eq(r['driver_source'],reg['driver_source'],'observer');eq(r['study'],reg['study'],'same study');eq(r['registration_sha256'],cat['cells'][0]['registered_plan'] and 'b0a22aefd5964c1287f5496abbd5b2b22ae8a4c485714cb826fee8a4477acd78','registry')
for slot,c in cmap.items():
 ret=load(pathlib.Path(c['original_result']['local_path']));directory=pathlib.Path(ret['directory']);entry=inputs[slot];cell=cells[slot]
 eq(entry['passed'],True,'inputpassed');eq(entry['status'],'passed','status');eq(entry['receipt_sha256'],ret['receipt_sha256'],'same receipt');eq(cell['receipt_sha256'],ret['receipt_sha256'],'cellreceipt');eq(cell['measurements'],ret['measurements'],'all original measurements retained');eq(cell['directory'],ret['directory'],'source directory')
 eq(entry['files'],before['input_directories'][str(directory)],'inventory exact') if all('mode' in v for v in entry['files'].values()) else eq(entry['files'],{p:{k:v for k,v in q.items() if k!='mode'} for p,q in before['input_directories'][str(directory)].items()},'inventory bytes/SHA exact')
 eq(entry['original_task_receipt']['plan'],ret['plan'],'plan');eq(entry['original_task_receipt']['driver_source'],ret['driver_source'],'perobserver');eq(ret['study'],r['study'],'perstudy');eq(ret['registration_sha256'],r['registration_sha256'],'perregistry');eq(ret['build_receipt_sha256'],r['task_build_receipt_sha256'],'perbuild')
 env=dict(ret['environment'],engine_cpu_parallelism=ret['engine'].get('cpu_parallelism'),measurement_environment=ret['measurement_environment'],profile_environment=ret['profile_environment']);eq(r['environments'][cell['environment_id']],env,'each environment exact')
 nr=load(directory/'native-shard/native/report.json');expected_hash_targets[str(directory/'native-shard/native/plan.json')]=nr['plan_digest'];expected_hash_targets[str(directory/'native-shard/native/raw.jsonl')]=nr['raw_digest']
 retids.append({'slot':list(slot),'receipt_sha256':ret['receipt_sha256'],'return_sha256':c['original_result']['sha256'],'environment_id':cell['environment_id']})
trace=load(D/'actual-native-hash-child-trace.json');eq(len(trace),91,'91observedcalls');observed=[]
for i,h in enumerate(trace):
 eq(h['index'],i,'orderedtrace');eq(h['returncode'],0,'real0');eq(h['argv'][:2],[binary,'--hash-file'],'hashonly argv');eq(len(h['argv']),3,'argv3');target=h['argv'][2];ok(target in expected_hash_targets,'registered target');observed.append(target)
 for stream in ['stdout','stderr']:
  b=read(D/h[stream]['file']);eq(len(b),h[stream]['bytes'],'streamsize');eq(hashlib.sha256(b).hexdigest(),h[stream]['sha256'],'streamSHA')
  if stream=='stdout':eq(b.decode().strip(),expected_hash_targets[target],'actual native digest matches accepted original report')
  else:eq(b,b'','childstderr0')
eq(collections.Counter(observed),collections.Counter(expected_hash_targets.keys()),'binaryonce+45planonce+45rawonce')
old=load(ROOT/'round47-original-Actions-aggregate/task-matrix.original.json');eq(old['passed'],False,'oldfailurepreserved');eq(old['accepted_cell_count'],42,'old42')
for entry in old['input_results']:
 new=inputs[tuple(entry['slot'])];eq(entry['original_task_receipt'],new['original_task_receipt'],'original42same full receipt');eq(entry['files'],new['files'],'original42same bytes inventory')
eq({tuple(x['slot']) for x in r['cold_curve_from_no_op']},{('no_op',s,0) for s in [1000,5000,10000,50000,100000]},'fixedcoldsubset')
setup={tuple(x['slot']):x for x in r['setup_pairs']};mut={tuple(x['slot']):x for x in r['mutation_samples']};fan={tuple(x['slot']):x for x in r['fanout_samples']}
for x in r['cold_curve_from_no_op']:eq(x,setup[tuple(x['slot'])],'not newrecord')
eq(len(setup),40,'setup40');eq(len(mut),40,'mutation40');eq(len(fan),5,'fanout5');ok(any(v['sample'].get('first_build_incomplete') is True for v in fan.values()),'actualoverbudgetobserved')
for slot,x in setup.items():eq(x['sample'],cells[slot]['measurements'][0],'setup exact')
for slot,x in mut.items():eq(x['sample'],cells[slot]['measurements'][1],'mutationexact')
for slot,x in fan.items():eq(x['sample'],cells[slot]['measurements'][0],'fanout exact')
report={'schema':'independent-complete45-original-aggregate-recovery-review-v1','reviewer':'/root/pr_triage','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decision':'accepted_complete_original45_input_aggregate_recovery','checks':checks,'source':G,'run_id':38026411200,'attempt':1,'execution':e,'original_return_identity':ids[str(D/'original-aggregate-return.json')],'original_matrix_identity':ids[str(D/'aggregate-output/task-matrix.json')],'returned_stdout_matrix_boundary':'Original return/stdout byte-identical; output task-matrix differs only JSON serialization ordering and is structurally exact. Both original byte hashes retained.','accepted':{'cells':45,'records':85,'setup':40,'mutation':40,'fanout':5,'cold_subset':5,'validated_input_count':45,'input_errors':[],'missing_slots':[],'registry_sha256':r['registration_sha256'],'task_build_receipt_sha256':r['task_build_receipt_sha256'],'binary_blake3':reg['binary_blake3'],'observer':r['driver_source']},'observed_function_calls':{'aggregate':1,'validate_build':1,'validate_shard':45,'combine':1},'native_hash_trace':{'actual_calls':91,'success':91,'binary':1,'plans':45,'raw':45,'fullargv_stdio_hashes_read':True,'source':'sys.setprofile records original Python calls and subprocess.CompletedProcess return; no monkeypatch or replacement validator'},'input_preservation':{'head_index_source_build_all45_before_after_equal':True,'source_observer_files':1107,'original42_Actions_receipts_and_inventory_equal':True},'role_environment_preservation':'Every original measurement, registered slot/plan/build/registry/observer/source/run/attempt and full per-slot environment equals original accepted return. Cold no_op5 are exact setup subset. Existing original incomplete/resume and full15table predicates accepted by unchanged original validators.','prior_failure':{'job_id':114158378120,'Actions_outcome':'failure','accepted_inputs':42,'missing_slots':old['missing_slots'],'never_relabelled_success':True},'scope':'Recovery re-assembles original measurements under the same fixed source/build/45 registration. It does not remeasure or replace original Actions outcome, and this peer did not call aggregate/validator/ELF/CRC. This supplies complete original aggregate evidence for subsequent original47-clause task review.','limits':['N1 per cell and separate measured environments; no N30, stable tail, cross-host speedup, old150/1350 slot credit or release certification.','Raw PID snapshots remain snapshots, vectors disabled/countnull; no invented peaks or provider success.','Task definitions/dependencies/status remain unchanged here. Formal006 and dependent task application require separate decisions.'],'peer_original_calls':0,'peer_ZIP_CRC_ELF_measurement_calls':0,'task_credit':0}
put('independent-complete45-aggregate-recovery-review.json',report);put('checked45-identity-role-and-child-trace.json',{'cells':retids,'expected_hash_targets':expected_hash_targets,'observed_call_counts':report['observed_function_calls']});put('read-input-identities.json',ids)
print(json.dumps({'decision':report['decision'],'checks':checks,'cells':45,'records':85,'actual_hashcalls':91,'peer_original_calls':0}))
