def stable_00479():
    return 479
