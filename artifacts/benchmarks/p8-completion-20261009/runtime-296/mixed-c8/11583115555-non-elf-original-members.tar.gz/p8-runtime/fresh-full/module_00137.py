def stable_00137():
    return 137
