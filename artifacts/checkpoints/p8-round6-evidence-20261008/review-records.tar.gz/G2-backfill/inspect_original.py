#!/usr/bin/env python3
"""Review preserved G2 backfill observations without rerunning the product."""
import collections
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/2eaa00d0f93a/codecortex')
SOURCE = 'd2d492b329a5630bf4a5fa6bc4b6eac30d07b13c'
TREE = '50b528be5d14d42e5eca7d45ed4148815a907eab'
REVIEW = Path('/workspace/scratch/2eaa00d0f93a/p8-final-independent-source-review/independent-source-review-P3.json')
EXPECTED_ZIP_SHA = '6fb2ef75e1fa129a4d70d0cb58df7de760309011856f541cdbc1f360aeda6571'
FILES = ROOT / 'files'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(path.read_bytes())

def git(path):
    return subprocess.check_output(['git', '-C', str(REPO), 'show', SOURCE + ':' + path])

def valid_int(value):
    return type(value) is int and value >= 0

def main():
    original = ROOT / 'original-artifact.zip'
    assert original.stat().st_size == 7708843
    assert digest(original.read_bytes()) == EXPECTED_ZIP_SHA
    member_digests = {}
    total_bytes = 0
    with zipfile.ZipFile(original) as archive:
        assert len(archive.infolist()) == 22
        for member in archive.infolist():
            name = PurePosixPath(member.filename)
            assert not member.is_dir() and not name.is_absolute() and '..' not in name.parts
            assert member.filename not in member_digests
            assert stat.S_IFMT(member.external_attr >> 16) in (0, stat.S_IFREG)
            data = archive.read(member)  # zipfile verifies the original CRC as it reads.
            assert len(data) == member.file_size
            member_digests[member.filename] = digest(data)
            total_bytes += len(data)
            if member.filename != 'p7_worker_contention':
                assert (FILES / member.filename).read_bytes() == data
        assert archive.read('p7_worker_contention')[:4] == b'\x7fELF'
    assert total_bytes == 27752381
    receipt = load(FILES / 'receipt.json')
    assert set(receipt['files']) == set(member_digests) - {'receipt.json'}
    assert receipt['files'] == {name: value for name, value in member_digests.items() if name != 'receipt.json'}
    source = load(FILES / 'source-before.json')
    assert source == receipt['source_before'] == receipt['source_after'] == receipt['source_final']
    assert source['source_commit'] == SOURCE and source['source_tree'] == TREE
    assert source['input_count'] == len(source['inputs']) == 1087
    review_bytes = REVIEW.read_bytes()
    assert digest(review_bytes) == '9e19bdf897af21fef00a78e3291921aa445d68f77b7115a44ff0f719580785e9'
    review = json.loads(review_bytes)
    assert source['inputs'] == review['complete_inputs']
    source_bindings = {}
    for path in ['scripts/p8_backfill.py', 'scripts/p7_build_identity.py', '.github/workflows/p8-runtime.yml', 'crates/cc-eval/tests/p7_worker_contention.rs']:
        actual = digest(git(path))
        expected = review['validation_inputs'].get(path, review['complete_inputs'].get(path))
        assert actual == expected
        source_bindings[path] = actual

    command = ['cargo', 'test', '--release', '--locked', '--offline', '-p', 'cc-eval', '--no-default-features', '--features', 'semantic', '--test', 'p7_worker_contention', '--no-run', '--message-format=json-render-diagnostics']
    assert receipt['build_command'] == command
    assert receipt['build_exit_code'] == 0
    messages = [json.loads(line) for line in (FILES / 'build.jsonl').read_text().splitlines() if line.strip()]
    assert any(row.get('reason') == 'build-finished' and row.get('success') is True for row in messages)
    artifact = receipt['cargo_artifact']
    assert messages.count(artifact) == 1
    assert artifact['features'] == ['semantic'] and artifact['fresh'] is False
    assert artifact['profile']['test'] is True and artifact['profile']['debug_assertions'] is False
    assert artifact['profile']['opt_level'] == '3' and artifact['profile']['debuginfo'] == 0
    assert artifact['target']['kind'] == ['test'] and artifact['target']['name'] == 'p7_worker_contention'
    assert artifact['target']['src_path'].endswith('/crates/cc-eval/tests/p7_worker_contention.rs')
    assert receipt['cargo_log_sha256'] == member_digests['build.jsonl']
    assert receipt['executable_sha256'] == receipt['executable_sha256_after'] == member_digests['p7_worker_contention']
    assert receipt['compiler'].startswith('rustc 1.95.0 ')
    assert receipt['execution_command'] == ['/home/runner/work/_temp/p8-backfill/p7_worker_contention', '--exact', 'real_slow_backfill_preserves_local_progress_and_records_every_request', '--nocapture']
    assert receipt['execution_exit_code'] == receipt['exit_code'] == 0
    stdout = (FILES / 'execution.stdout').read_text()
    assert re.search(r'test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', stdout)
    assert (FILES / 'execution.stderr').read_bytes() == b''
    job_log = (ROOT / 'original-job.log').read_text()
    assert 'git checkout --progress --force ' + SOURCE in job_log
    assert 'python3 scripts/p8_backfill.py --output' in job_log
    assert 'Artifact ID 11577192736' in job_log
    assert '##[error]' not in job_log
    assert receipt['paid_provider_requests'] == 0
    assert receipt['release_approval'] is False and receipt['task_complete'] is False

    reviewed_seeds = []
    offered_count = 0
    for seed in [7, 19, 43]:
        base = FILES / 'raw' / f'seed-{seed}'
        assert {p.name for p in base.iterdir()} == {'protocol.json', 'held-before.json', 'quiet-requests.json', 'held-requests.json', 'summary.json'}
        protocol, before, summary = (load(base / name) for name in ['protocol.json', 'held-before.json', 'summary.json'])
        assert protocol['seed'] == summary['seed'] == seed
        assert protocol['concurrency_cells'] == [1, 4, 8, 16] and protocol['samples_per_cell'] == 32
        assert protocol['phases'] == ['quiet', 'held'] and protocol['mutable_files'] == 24
        assert protocol['query_watchdog_ms'] == 2000 and protocol['progress_watchdog_ms'] == 5000
        assert protocol['worker_claim_round_cap'] == 16 and protocol['worker_local_attempt_width'] == 4
        provider = before['provider']
        assert provider['active'] == provider['waiting'] == provider['maximum_active'] == 4
        assert provider['entered'] == 30 and provider['fake_completed_calls'] == 26
        assert len(set(provider['held_inputs'])) == 4
        assert before['queue']['claimed'] == 4 and before['queue']['pending'] == 20
        assert before['queue']['published'] == 2 and before['queue']['uncovered'] == 24
        phase_results = {}
        for phase in ['quiet', 'held']:
            rows = load(base / (phase + '-requests.json'))
            assert len(rows) == 128
            offered_count += len(rows)
            computed = []
            rounding = collections.Counter()
            for concurrency in [1, 4, 8, 16]:
                selected = [row for row in rows if row['concurrency'] == concurrency]
                assert len(selected) == 32 and sorted(row['ordinal'] for row in selected) == list(range(32))
                for row in selected:
                    fields = ['caller_schedule_us', 'capture_admission_us', 'retrieval_us', 'offered_to_api_return_us']
                    assert all(valid_int(row[key]) for key in fields)
                    difference = row[fields[-1]] - sum(row[key] for key in fields[:-1])
                    assert difference in (0, 1, 2)  # Three separately floored microsecond spans.
                    rounding[difference] += 1
                    assert row['offered_to_api_return_us'] < 2000000
                    stable = [hit for hit in row['hits'] if hit['file_path'] == 'stable.rs']
                    assert stable and all(hit['text'] == f'pub fn stable_signal() -> u64 {{ {seed} }}\n' for hit in stable)
                    assert all(hit['metadata']['source_freshness']['status'] == 'current_verified' for hit in stable)
                    assert row['originating_work'] is None and row['source_freshness'] is None
                times = sorted(row['offered_to_api_return_us'] for row in selected)
                value = {'concurrency': concurrency, 'n': len(times), 'max_us': max(times)}
                value.update({f'p{p}_us': times[math.ceil(p * len(times) / 100) - 1] for p in [50, 95, 99]})
                reported = next(row for row in summary[phase] if row['concurrency'] == concurrency)
                assert all(reported[key] == result for key, result in value.items())
                computed.append(value)
            phase_results[phase] = {'offered_and_successful': len(rows), 'cells': computed, 'microsecond_floor_residual_counts': dict(rounding)}
        db = summary['db_availability']
        assert db['generation_before'] == db['generation_after'] and db['generation_unchanged'] is True
        assert db['read_rows'] == 26 and db['writer_busy_timeout_ms'] == 100
        assert summary['old_held_input_publications'] == 0
        old = summary['old_provider']
        assert old['entered'] == old['fake_completed_calls'] == 30
        assert old['active'] == old['waiting'] == 0 and old['maximum_active'] == 4
        assert old['held_inputs'] == provider['held_inputs']
        assert summary['new_provider_calls'] == 25
        assert summary['queue_final']['claimed'] == summary['queue_final']['pending'] == summary['queue_final']['uncovered'] == 0
        assert summary['queue_final']['published'] == 25 and summary['queue_final']['attempt_count'] == 55
        assert summary['full_p7_015_complete'] is False
        for key in ['initial_build_us', 'held_build_us', 'write_delete_us', 'switch_and_drain_us']:
            assert valid_int(summary[key]) and summary[key] < 5000000
        resource_stages = [summary['quiet_resources'], before['resources'], summary['held_after_resources'], summary['final_resources']]
        usage = [stage['shared_process_owner']['usage'] for stage in resource_stages]
        assert all(item['pid'] == 6575 and item['resident_bytes'] > 0 and item['peak_resident_bytes'] > 0 for item in usage)
        for key in ['user_cpu_ns', 'system_cpu_ns']:
            assert [item[key] for item in usage] == sorted(item[key] for item in usage)
        for stage in resource_stages:
            pool = stage['cpu_pool_slots']
            assert pool['cpu_in_flight'] == pool['cpu_admitted'] == pool['async_in_flight'] == pool['async_admitted'] == pool['rejected'] == 0
            assert stage['server']['separate_pid'] is None and stage['server_tree']['child_process_usage'] is None
            assert stage['raw_sampler']['server_rss_bytes'] is None and stage['raw_sampler']['server_tree_rss_bytes'] is None
        reviewed_seeds.append({'seed': seed, 'phases': phase_results, 'held_provider': provider, 'db_availability': db,
                               'progress_us': {key: summary[key] for key in ['initial_build_us', 'held_build_us', 'write_delete_us', 'switch_and_drain_us']},
                               'old_provider_final': old, 'new_provider_calls': summary['new_provider_calls'], 'queue_final': summary['queue_final'],
                               'current_rss_stage_bytes': [item['resident_bytes'] for item in usage],
                               'native_lifetime_peak_rss_bytes': [item['peak_resident_bytes'] for item in usage],
                               'query_pool_completed_stage_counts': [stage['cpu_pool_slots']['completed'] for stage in resource_stages]})
    assert offered_count == 768
    report = {
        'schema_version': 1, 'verdict': 'accepted_scoped_original_G2_backfill_observation',
        'reviewer': '/root', 'source': SOURCE, 'source_tree': TREE,
        'run_id': 37837227959, 'job_id': 113517255181, 'artifact_id': 11577192736,
        'artifact': {'bytes': original.stat().st_size, 'sha256': EXPECTED_ZIP_SHA, 'members': 22, 'uncompressed_bytes': total_bytes, 'receipt_bound_files': 21},
        'source_input_count': 1087, 'reviewed_P3_complete_source_input_map_identical': True,
        'independent_source_review_sha256': digest(review_bytes), 'git_validation_and_test_bindings': source_bindings,
        'source_before_after_final_identical': True, 'cargo_profile': artifact['profile'], 'cargo_features': artifact['features'],
        'compiler': receipt['compiler'], 'build_command': command, 'execution_command': receipt['execution_command'],
        'executable_sha256': receipt['executable_sha256'], 'execution_elapsed_ns': receipt['execution_elapsed_ns'],
        'original_test_counts': {'passed': 1, 'failed': 0, 'ignored': 0, 'filtered_out': 0},
        'offered_requests': offered_count, 'successful_recorded_requests': offered_count, 'seeds': reviewed_seeds,
        'original_job_log_sha256': digest((ROOT / 'original-job.log').read_bytes()),
        'receipt_sha256': member_digests['receipt.json'], 'zip_member_sha256': member_digests,
        'inspector_sha256': digest(Path(__file__).read_bytes()),
        'source_assertions_reviewed': [
            'All quiet and held waves join every offered task before checking failure; rows are saved on each wave.',
            'Held-provider gate remains closed across DB control and all 128 held queries; original executed assertions compare provider and outbox before/after.',
            'Original executed assertions require write/delete progress while provider is held; obsolete symbols disappear and the latest symbol is present.',
            'Original executed assertions reject scheduling the retired worker, then release and drain; held old-space responses have zero publications.'
        ],
        'limitations': [
            'Actual original Actions execution reviewed; no local product executable or provider was run by this inspection.',
            'The 1087 source hashes are compared to the retained independently reviewed P3 map; no heldout corpus bodies are read.',
            'Observer source is bound through exact G2 checkout and reviewed Git bytes. This backfill format has no separate runtime-loaded observer seal; none is invented.',
            'C1/4/8/16 are controlled offered wave sizes; rows do not record absolute in-flight intervals, so actual peak concurrency is not invented.',
            'Timings include caller scheduling and capture admission, but do not separate MCP transport or backend queue/service times.',
            'Three seeds share one process. All 768 requests remain in their 24 original cells of N32; no pooled CI, new SLA, or causal quiet-versus-held claim.',
            'Provider gates/retirement and symbol assertions execute inside the original passed test; missing separate snapshots are not described as independently replayed database observations.',
            'Fake providers only, paid external requests zero. Counts are in-process provider calls, not an estimate of paid-provider cost or real semantic quality.',
            'Runner, CodeIndex and fake provider share PID6575; native SELF CPU/RSS are attributed once. Separate server/process-tree costs remain unknown, and stage samples may miss transient peaks.',
            'Original failed G backfill remains a separate failed attempt. This successful G2 observation does not replace or relabel it.',
            'No TODO closed; original dependencies, related regressions and combined P8 acceptance remain required.'
        ],
        'task_complete': False, 'release_approval': False, 'remaining_original_todos': 29,
    }
    (ROOT / 'inspection.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'verdict': report['verdict'], 'offered_requests': offered_count, 'seeds': len(reviewed_seeds),
                      'inspection_sha256': digest((ROOT / 'inspection.json').read_bytes()), 'remaining_original_todos': 29}))

if __name__ == '__main__':
    main()
