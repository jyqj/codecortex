# Round 19: PR127 and PR137 retention review

Both PRs should remain open Drafts. This bounded read-only review found explicit keep-open/migration decisions and no complete product-plus-evidence adoption proof. It did not change either PR or any task.

| PR | Fixed head | Current exact-head checks | Reason to retain | Next concrete action |
|---|---|---|---|---|
| 127 | 222da64761971a3b546458aa16e2c2c9ea46cea7 | check, MSRV, security succeeded | Independent bounded group-publication API and seven added test/doc/evidence paths are not adopted at their original main paths; no queue integration or performance claim | Non-author scope and migration review, preserving original failure/green evidence; keep queue integration separate |
| 137 | bc4e5602e10841258fb5583138419335bc9098dd | Default regression failed; MSRV/security succeeded | Diagnosis-only public DEV namespace-contract investigation remains unresolved; diagnostic directory and scoped test absent at their original main paths | Preserve diagnosis and quality FAIL; decide field contract and inspect the actual failed regression before proposing migration |

Main observed: d22d36dddf8b38f1a864c933deefe0b6d3b5baf3. Exact-path absence does not prove that no renamed equivalent exists anywhere. No whole repository scan was used and no closure recommendation relies on such an inference. Both PRs currently have zero issue comments, inline comments and review submissions; the explicit retention decision is in each complete current body.

The full current body, official metadata, changed-path lists, checks and original scope documents are retained. Two generic endpoint fetch rejections are retained separately; the purpose-built job-steps call established the failed PR137 step without a full log download. Historical tests and diagnostics were not rerun.

Round 19 remains in progress. This review adds zero completed tasks; 29 original TODOs remain.
