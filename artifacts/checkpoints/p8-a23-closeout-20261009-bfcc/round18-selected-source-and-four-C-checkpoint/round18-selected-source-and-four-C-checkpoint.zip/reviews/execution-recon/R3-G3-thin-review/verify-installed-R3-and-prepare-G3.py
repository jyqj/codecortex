#!/usr/bin/env python3
"""Exact tree/identity proof; no source CLI, compilation or native calls."""
import ast, hashlib, json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'P3-source-review'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def write(p,d):
    with p.open('x') as f:json.dump(d,f,sort_keys=True,indent=2);f.write('\n')
mod=ast.parse((SOURCE/'verify-actual-P3-tree-and-inputs.py').read_text());nodes=[]
for n in mod.body:
    if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='spec' for t in n.targets):break
    nodes.append(n)
ns={'__file__':str(SOURCE/'verify-actual-P3-tree-and-inputs.py')};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<reviewed pure tree reconstruction>','exec'),ns)
leaves=ns['leaves'];hash_leaves=ns['hash_leaves']
for p,row in read(SOURCE/'actual-P3-independent-tree-input-review.json')['actual_deltas_from_H'].items():leaves[p]=dict(row['after'])
canonical=read(ROOT.parent/'final-R3/independent-source-review.json')
for p in ['crates/cc-db/src/resolution_dependency_store.rs','crates/cc-db/tests/p2b_resolution_store.rs']:leaves[p]=dict(canonical['actual_input_mode_blob_inventory'][p])
assert hash_leaves(leaves)['']==canonical['tree']=='c61707e398739be23b01570af025c412a723689c'
p_leaves={p:dict(r) for p,r in leaves.items()}
manifest=read(ROOT.parent/'final-R3/upload-manifest.json');assert len(manifest['files'])==2
for row in manifest['files']:
    p=Path(row['local_path']);raw=p.read_bytes()
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256'] and blob(raw)==row['git_blob']
    assert row['repository_path'] not in leaves
    leaves[row['repository_path']]={'mode':'100644','type':'blob','sha':row['git_blob'],'size':row['bytes']}
meta=json.loads(read(ROOT/'official-R3-commit.json')['response_content'])
assert meta['sha']=='4ec7543db94699077fe4075dd4b3606e92482460'
assert [x['sha'] for x in meta['parents']]==[canonical['source']]
dirs=hash_leaves(leaves);assert dirs['']==meta['tree']['sha']=='11db88d8c60b6be658f40d419dd46c915c716b93'
api=json.loads(read(ROOT/'official-R3-root-tree.json')['response']['content'])
assert api['sha']==dirs[''] and not api['truncated']
for row in api['tree']:
    expected=dirs[row['path']] if row['type']=='tree' else leaves[row['path']]['sha']
    assert row['sha']==expected
assert all(leaves[p]==r for p,r in p_leaves.items())
for p,r in canonical['actual_input_mode_blob_inventory'].items():assert all(r[k]==leaves[p][k] for k in ('mode','type','sha'))
report={'schema':'actual-installed-R3-independent-thin-review-v1','reviewer':'/root/execution_recon','verdict':'accepted_scoped_exact_artifact_installation','R3':meta['sha'],'tree':dirs[''],'sole_parent':canonical['source'],'parent_tree':canonical['tree'],'new_artifact_leaves':manifest['files'],'all_parent_leaves_exact':True,'complete_product_inputs':1095,'validation_inputs':142,'BASE_deltas':70,'actual_canonical_blob':manifest['files'][0]['git_blob'],'actual_canonical_sha256':manifest['files'][0]['sha256'],'source_and_validation_mutations':0,'source_only':True,'current_source_runtime':'not_run','source_semantics_not_repeated':True,'no_large_ZIP_redownload':True,'draft_PR_source_boundary':'Exact independent source-only review installed. Original engineering/runtime checks remain to execute on the new bound source. No TODO/scale credit.','TODO_remaining':29}
write(ROOT/'actual-installed-R3-independent-thin-review.json',report)
print(json.dumps(report))
