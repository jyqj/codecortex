def stable_00192():
    return 192
