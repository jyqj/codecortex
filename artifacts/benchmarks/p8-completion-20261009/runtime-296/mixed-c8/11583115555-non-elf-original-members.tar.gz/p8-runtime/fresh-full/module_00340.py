def stable_00340():
    return 340
