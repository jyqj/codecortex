import datetime
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'root-round12' / 'publication-secondary'
PREFIX = 'artifacts/checkpoints/p8-a23-closeout-20261009-bfcc/round12-primary-lifecycle-gates-and-diagnostics'
OUT.mkdir(parents=True, exist_ok=True)
groups = {}
selected = []
direct = []
entries = []

def sha(b):
    return hashlib.sha256(b).hexdigest()

def blob(b):
    return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()

def add(group, p, e=None):
    p = Path(p)
    assert p.is_file() and not p.is_symlink()
    rel = p.resolve().relative_to(ROOT).as_posix()
    data = p.read_bytes()
    if e:
        assert len(data) == e['bytes'] and sha(data) == e['sha256'], rel
    if rel.endswith('lifecycle-original-json-stdio-and-fixtures.tar.gz'):
        direct.append({'file_name': p.name, 'local_path': str(p), 'repository_path': e['repository_path'],
                       'bytes': len(data), 'sha256': sha(data), 'git_blob_sha': blob(data),
                       'scope': 'Lossless selected original JSON/stdio/fixture container; not the official GitHub ZIP.'})
        entries.append({'direct_repository_path': e['repository_path'], 'original_local_path': str(p),
                        'bytes': len(data), 'sha256': sha(data)})
        return
    try:
        text = data.decode('utf-8')
    except UnicodeDecodeError:
        text = ''
    for pattern in [r'(?:[?&]|\\u0026)(?:sig|signature|x-amz-signature|x-goog-signature|token|access_token)=[A-Za-z0-9%/+_-]{12,}',
                    r'(?im)^set-cookie:\s*(?!\[?REDACTED)[^\r\n]{12,}']:
        assert not re.search(pattern, text, re.I), (rel, 'potential private transfer value')
    g = groups.setdefault(group, {})
    assert rel not in g or g[rel] == data
    g[rel] = data

def select(group, rel):
    p = ROOT / rel
    d = json.loads(p.read_text())
    add(group, p)
    selected.append({'local_path': rel, 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())})
    for e in d.get('files', d.get('entries', [])):
        p2 = Path(e.get('local_path', e.get('path')))
        if not p2.is_absolute():
            p2 = Path(d.get('base', str(p.parent))) / p2
        add(group, p2, e)

select('lifecycle-review', 'pr-triage-primary-recovery/runtime-review-Gc8/lifecycle-publication-selection.json')
select('backfill-original-evidence', 'pr-triage-primary-recovery/runtime-review-Gc8/backfill-publication-selection.json')
select('gates-and-security', 'todo-audit-round12/gates-Gc8/archive-selection.json')
select('gates-and-security', 'todo-audit-round12/ci-original-security/archive-selection.json')
add('gates-and-security', ROOT / 'scale-intake-primary/gates-Gc8-peer/independent-review.json')
select('old-G2-failed-diagnostic', 'g2-terminal-readonly/archive-selection.json')
for rel in ['backfill-and-third-platform-transfer-receipt.json', 'first-primary-git-publication-receipt.json',
            'linux-first3-original-transfer-receipt.json', 'closeout-original-preparation-receipt.json',
            'prepare-secondary-publication.py']:
    add('root-coordination', ROOT / 'root-round12' / rel)

bundles = []
for group, files in sorted(groups.items()):
    p = OUT / (group + '.zip')
    assert not p.exists(), str(p)
    with zipfile.ZipFile(p, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel, data in sorted(files.items()):
            info = zipfile.ZipInfo(rel, date_time=(2026, 10, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
            entries.append({'archive': p.name, 'archive_member': rel, 'original_local_path': str(ROOT / rel),
                            'bytes': len(data), 'sha256': sha(data)})
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None and z.namelist() == sorted(files)
        assert all(z.read(n) == b for n, b in files.items())
    b = p.read_bytes()
    bundles.append({'file_name': p.name, 'local_path': str(p), 'repository_path': PREFIX + '/' + p.name,
                    'bytes': len(b), 'sha256': sha(b), 'git_blob_sha': blob(b),
                    'members': len(files), 'uncompressed_bytes': sum(map(len, files.values()))})

manifest = {'schema': 'codecortex.primary-second-acceptance-publication.v1',
            'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'parent_commit': '9a84a516cfa24be9cd0103ca4f57c84ee36db8cd',
            'current_source_G': 'c8be5afaac568ffd40ef86d3795423c3b73c9f39',
            'original_tasks': {'total': 192, 'done': 163, 'remaining': 29, 'new_completed': 0},
            'accepted_scopes': ['Gc8 lifecycle1230 original samples and full stdio/resource/disk review.',
                                'Gc8 backfill768 original requests and original bounded progress/retirement/end-state gates.',
                                'Gc8 gates6 original Rust tests and7 retained-ELF deterministic CLI replays with independent peer review.',
                                'Original CI security audit on observed synthetic merge39ae6437; no181/v15 substitution.'],
            'separate_failed_source': {'G2': '0272a1fb152fd76a7cfb22386a580629d4038a64',
                                      'run': 37877604259, 'job': 113654983347, 'artifact': 11604421042,
                                      'status': 'deadline_exceeded', 'native_exit': 3, 'driver_and_GitHub_exit': 1,
                                      'stderr_complete': False, 'worker_exit_code': None,
                                      'scope': 'Original failed diagnostic and complete retained raw; not a Gc8 or N30 success.'},
            'limits': ['No task closeout or complete scale/platform/source-admission assertion.',
                       'Original large GitHub ZIPs/ELFs/DBs remain at their exact artifact locators; included new compressed containers are distinctly identified.',
                       'All input bytes, exit boundaries and earlier incomplete/static-only reports remain unchanged.',
                       'Selection repository_path fields for ZIP-contained files describe expanded layouts; actual locations are archive/member entries here. The lifecycle tar.gz is published directly at its specified repository path.',
                       'Resource stage observations are not continuous process-tree peaks; disabled-provider cost unavailable values remain null.',
                       'Final closeout input restoration preserved all original task states and did not run the generator or claim a complete checkout.'],
            'selections': selected, 'direct_files': direct, 'bundles': bundles,
            'file_count': len(entries), 'files': entries}
p = OUT / 'publication-manifest.json'
p.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
index = {'prefix': PREFIX, 'files_to_upload': bundles + direct,
         'manifest': {'local_path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}}
(OUT / 'upload-index.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps({'file_count': len(entries), 'bundles': bundles, 'direct_files': direct,
                  'manifest_bytes': p.stat().st_size}, ensure_ascii=False))
