def stable_00480():
    return 480
