def stable_00098():
    return 98
