from pathlib import Path
import json,hashlib,re,subprocess
r=Path('/workspace/independent-boundary-review');repo=Path('/workspace/codecortex');a=r/'author';b=json.loads((repo/'artifacts/reviews/query-owner-source-boundary-correction-20261004/binding.json').read_text());m=json.loads((a/'archive-manifest.json').read_text());bad=[]
for p,i in m.items():
 f=a/p
 if not f.exists() or hashlib.sha256(f.read_bytes()).hexdigest()!=i['sha256']:bad.append(p)
assert not bad and len(m)==113
qre=r'^\s*\(("(?:[^"\\]|\\.)*"),\s*(.*)\),$'
def cases(p):return [(json.loads(q),x) for q,x in re.findall(qre,p.read_text(),re.M)]
new=cases(a/'boundary_driver.rs');old=cases(a/'prior-author/comparison_driver.rs');initial=cases(repo/'artifacts/reviews/query-owner-hint-independent-20261004/independent_driver.rs')
assert len(new)==85 and len(old)==32 and len(initial)==22
assert dict(new).items()>=dict(initial).items() and dict(old).items()>=dict(initial).items()
assert set(q for q,_ in old)==set(json.loads(Path('/workspace/independent-comparison-review/author/results/correction-base/results.json').read_text())['queries'])
assert dict(new).items()>=dict(old).items()
for name,path in [('boundary_driver.rs',a/'boundary_driver.rs'),('prior-author/comparison_driver.rs',a/'prior-author/comparison_driver.rs')]:assert hashlib.sha256(path.read_bytes()).hexdigest()==b['drivers'][name]
assert (repo/'artifacts/reviews/query-owner-source-boundary-correction-20261004/boundary_driver.rs').read_bytes()==(a/'boundary_driver.rs').read_bytes()
assert (repo/'artifacts/reviews/query-owner-source-boundary-correction-20261004/prior-author-32-query-driver.rs').read_bytes()==(a/'prior-author/comparison_driver.rs').read_bytes()
ident={}
for arm,src in [('delivery',repo),('rejected',r/'rejected'),('candidate',r/'candidate'),('base',r/'base')]:
 files=['Cargo.lock','crates/cc-search/src/query_target.rs','crates/cc-search/src/engine_lane_tests.rs','crates/cc-search/src/plan.rs','crates/cc-search/src/dsl.rs'];t=(src/files[1]).read_text();target=t.split('// Bounded English owner-role context')[0].split('#[cfg(test)]')[0].strip()
 ident[arm]={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'files':{f:hashlib.sha256((src/f).read_bytes()).hexdigest() for f in files},'QueryTarget_sha256':hashlib.sha256(target.encode()).hexdigest()}
assert len({i['QueryTarget_sha256'] for i in ident.values()})==1
assert len({i['files']['Cargo.lock'] for i in ident.values()})==1
assert len({i['files']['crates/cc-search/src/dsl.rs'] for i in ident.values()})==1
assert ident['delivery']['files']['crates/cc-search/src/plan.rs']==ident['candidate']['files']['crates/cc-search/src/plan.rs']==ident['rejected']['files']['crates/cc-search/src/plan.rs']
for f,h in b['source_files'].items():assert ident['delivery']['files'][f]==h
ident['author_audit']={'manifest_entries':len(m),'invalid_entries':bad,'driver_case_counts':{'boundary':len(new),'restored_prior_author':len(old)},'original_22_expected_semantics_preserved':True,'restored_prior_32_output_query_set_preserved':True,'archive_sha256':hashlib.sha256((repo/'artifacts/reviews/query-owner-source-boundary-correction-20261004/evidence.tar.gz').read_bytes()).hexdigest()};assert ident['author_audit']['archive_sha256']==b['archive']['sha256']
(r/'identities.json').write_text(json.dumps(ident,indent=2));print('PASS: 113/113 manifest entries; durable 85/32 query drivers; original 22 expectations and 32 query set preserved; source/plan/DSL/lock pins')
s=(a/'compare_results.py').read_text().replace("Path('/workspace/owner-boundary-validation')", "Path('/workspace/independent-boundary-review/author')");(r/'audit-author-results.py').write_text(s)
