def stable_00295():
    return 295
