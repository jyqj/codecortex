# CodeCortex benchmark baseline

Suite: `V19 TypeScript 02 oce-compat-v1 candidate; review/custody pending`
Adapter: `mcp-stdio`
Scoring: `OceCompat`
Measurement profile: `quality`

Status: **gate_failed** (exit 1)

Queries: 12; measured rows: 36.
Mean Top-1: 0.750000; mean nDCG@10: 0.791806.

These are baseline observations, not a release quality certificate.
Latency: Distribution { samples: 0, p50_us: None, p95_us: None, max_us: None, tail_claim: "insufficient_for_tail_claim" }; samples are retained, not best-of.
Source evidence: 0 invalid, 0 unverified hits.

| Case | Top-1 | nDCG@10 | Repetitions |
|---|---:|---:|---:|
| v19.typescript.f0021.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0023.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0025.en01 | 0.000000 | 0.000000 | 3 |
| v19.typescript.f0026.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0027.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0029.en01 | 0.000000 | 0.630930 | 3 |
| v19.typescript.f0030.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0031.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0033.en01 | 1.000000 | 0.380094 | 3 |
| v19.typescript.f0034.en01 | 1.000000 | 0.859719 | 3 |
| v19.typescript.f0036.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0037.en01 | 0.000000 | 0.630930 | 3 |

## Failures

- v19.typescript.f0036.en01 Partial
- v19.typescript.f0034.en01 Partial
- v19.typescript.f0021.en01 Partial
- v19.typescript.f0033.en01 Partial
- v19.typescript.f0027.en01 Partial
- v19.typescript.f0025.en01 Partial
- v19.typescript.f0037.en01 Partial
- v19.typescript.f0029.en01 Partial
- v19.typescript.f0026.en01 Partial
- v19.typescript.f0031.en01 Partial
- v19.typescript.f0023.en01 Partial
- v19.typescript.f0030.en01 Partial
- v19.typescript.f0033.en01 Partial
- v19.typescript.f0027.en01 Partial
- v19.typescript.f0026.en01 Partial
- v19.typescript.f0034.en01 Partial
- v19.typescript.f0037.en01 Partial
- v19.typescript.f0036.en01 Partial
- v19.typescript.f0030.en01 Partial
- v19.typescript.f0031.en01 Partial
- v19.typescript.f0025.en01 Partial
- v19.typescript.f0021.en01 Partial
- v19.typescript.f0023.en01 Partial
- v19.typescript.f0029.en01 Partial
- v19.typescript.f0021.en01 Partial
- v19.typescript.f0030.en01 Partial
- v19.typescript.f0037.en01 Partial
- v19.typescript.f0033.en01 Partial
- v19.typescript.f0023.en01 Partial
- v19.typescript.f0031.en01 Partial
- v19.typescript.f0036.en01 Partial
- v19.typescript.f0025.en01 Partial
- v19.typescript.f0026.en01 Partial
- v19.typescript.f0029.en01 Partial
- v19.typescript.f0034.en01 Partial
- v19.typescript.f0027.en01 Partial