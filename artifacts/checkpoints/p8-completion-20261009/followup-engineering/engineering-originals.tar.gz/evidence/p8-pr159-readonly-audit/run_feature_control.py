import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parent
fixture = root / "feature-control"
records = []
version = subprocess.run(["rustc", "--version", "--verbose"], capture_output=True, check=True)
(root / "rustc-version.stdout").write_bytes(version.stdout)
assert b"release: 1.95.0\n" in version.stdout
lock = subprocess.run(["cargo", "generate-lockfile", "--offline"], cwd=fixture, capture_output=True)
(root / "lock.stdout").write_bytes(lock.stdout)
(root / "lock.stderr").write_bytes(lock.stderr)
assert lock.returncode == 0
for label, flags in (("original", []), ("explicit-no-default", ["--no-default-features"])):
    target = root / ("target-" + label)
    assert not target.exists()
    argv = ["cargo", "test", "--release", "--locked", "--offline", *flags,
            "--features", "semantic", "--test", "feature_contract", "--no-run",
            "--message-format=json-render-diagnostics", "--target-dir", str(target)]
    start = time.monotonic_ns()
    result = subprocess.run(argv, cwd=fixture, capture_output=True, timeout=30)
    duration = time.monotonic_ns() - start
    stdout, stderr = root / (label + ".stdout"), root / (label + ".stderr")
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    assert result.returncode == 0
    messages = [json.loads(line) for line in result.stdout.splitlines()]
    artifacts = [message for message in messages if message.get("reason") == "compiler-artifact"]
    assert len(artifacts) == 1 and artifacts[0]["target"]["name"] == "feature_contract"
    artifact = artifacts[0]
    assert artifact["features"] == (["default", "semantic"] if label == "original" else ["semantic"])
    records.append(dict(label=label, command=argv, exit_code=result.returncode, elapsed_ns=duration,
                        features=artifact["features"], profile=artifact["profile"], fresh=artifact["fresh"],
                        original_strict_gate_accepts=artifact["features"] == ["semantic"],
                        stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),
                        stderr_sha256=hashlib.sha256(result.stderr).hexdigest()))
report = dict(schema_version=1, source_under_review="bb9a96d71622458c39a143055360cc97f0d11d78",
              comparison_source="f8ca8070592a1bc03cedc2df4e27e1382a3077a7",
              classification="actual Cargo 1.95 compiler-artifact feature labels on explicit dependency-free protocol fixture; not a product build or backfill execution",
              copied_feature_declarations="default=[] and semantic=[], matching the empty default-feature label property in cc-eval",
              results=records, conclusion="Original command includes the default feature label even when default is empty; strict semantic-only gate rejects it. --no-default-features makes original strict gate satisfiable without relaxing it.")
(root / "feature-control-report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
print(json.dumps(report, indent=2, sort_keys=True))
