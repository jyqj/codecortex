from pathlib import Path
import hashlib
import json
import zipfile

B = Path(__file__).resolve().parent
O = B / 'sealed-evidence'
O.mkdir(exist_ok=False)
PREFIX = 'artifacts/checkpoints/p8-round26-GW4-first-three-shards-bfcc-20261009'


def identity(path):
    data = path.read_bytes()
    return {'local_path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


transfer = json.loads((B / 'transfers.public-derived.json').read_text())
terminal = json.loads((B / 'terminal.json').read_text())
assert terminal['exit_code'] == 0 and len(terminal['commands']) == 3
reviews = [json.loads((B / f'scale-{scale}-attempt01/independent-shard-intake-review.json').read_text())
           for scale in (1000, 5000, 10000)]
assert [review['measurement_count'] for review in reviews] == [14, 9, 9]
originals = []
for entry in transfer['originals']:
    item = identity(Path(entry['workspace_path']))
    assert item['bytes'] == entry['metadata']['size_in_bytes']
    assert 'sha256:' + item['sha256'] == entry['metadata']['digest']
    item.update({'artifact_id': entry['metadata']['id'], 'artifact_name': entry['metadata']['name'],
                 'repository_path': PREFIX + '/original-zips/' + Path(item['local_path']).name})
    originals.append(item)
summary = {'schema': 'GW4-first-three-original-shards-intake-v1',
           'source': '008f1ec0ae16b9b6aff9f20d033b17b2219168f8', 'run_id': 37982220020, 'run_attempt': 1,
           'workload_profile': 'scale_wide_dirty_v1', 'oracle_physical_profile': 'scale_capacity_v1',
           'original_build': {'artifact_id': 11642471195, 'zip_git_blob': 'd6bf17c610c18701345a1a58a414ca4762dc251d',
                              'review_git_blob': '4ffa93afa05d410be04e281e84a306515634096d',
                              'revalidated_in_this_intake': False},
           'status': 'three_original_validate_shard_calls_passed', 'terminal': terminal,
           'shards': reviews, 'accepted_shards': 3, 'planned_shards': 150,
           'accepted_measurements': 32, 'planned_measurements': 1500,
           'capacity_receipts': 3, 'capacity_sample_credit': 0,
           'original_zip_leaves': originals, 'new_product_workload_executions': 0,
           'new_TODO_completions': 0, 'TODO_remaining': 29,
           'limits': ['Original aggregate has not passed; this is not complete-study/release certification.',
                      'All counts belong only to source 008f / run 37982220020 attempt1.',
                      'Original G8, cold044 and failed studies remain separate populations.',
                      'The accepted build was reused unchanged; native invocations only original --hash-file checks.',
                      'Signed URLs omitted from public-derived transfer record; private original SHA retained.',
                      'No extra receiver test, product measurement, benchmark or automatic ledger mutation.']}
(O / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
files = [path for path in B.iterdir() if path.is_file() and path.name != 'root-private-transfers.json']
files += sorted((B / 'descriptors').glob('*.json'))
for scale in (1000, 5000, 10000):
    directory = B / f'scale-{scale}-attempt01'
    files += [path for path in directory.iterdir() if path.is_file()]
for directory in sorted(B.glob('capacity-*')):
    if directory.is_dir():
        files += [path for path in directory.iterdir() if path.is_file()]
peer = B.parent / 'round26-GW4-shard-intake-static-peer/independent-static-review.json'
adapter = B.parent / 'GW4-original-shard-intake-preparation/intake-original-shard-once.py'
files += [peer, adapter]
entries = []
for path in sorted(set(files)):
    name = str(path.relative_to(B)) if path.is_relative_to(B) else 'external/' + path.parent.name + '/' + path.name
    entries.append(dict(identity(path), archive_path=name))
(O / 'archive-selection.json').write_text(json.dumps({'schema': 'selected-original-intake-evidence-v1',
    'entries': entries, 'original_zips_are_separate_leaves': True,
    'excluded': ['private signed-URL transfer response', 'duplicate extracted raw already in whole original ZIPs',
                 'original build ZIP/ELF already persisted by exact Git locators']}, indent=2) + '\n')
with zipfile.ZipFile(O / 'support.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for entry in entries:
        archive.write(entry['local_path'], entry['archive_path'])
    archive.write(O / 'archive-selection.json', 'archive-selection.json')
leaves = originals + [dict(identity(O / name), repository_path=PREFIX + '/' + name)
                       for name in ('support.zip', 'summary.json', 'archive-selection.json')]
manifest = {'schema': 'immutable-blob-upload-plan-v1', 'entries': leaves,
            'only_create_blob_authorized_here': True, 'ref_commit_tree_operations': 'root only',
            'selected_original_files': len(entries), 'all_original_zips_separate': True}
(O / 'root-upload-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'original_zips': len(originals), 'leaves': len(leaves), 'selected_files': len(entries),
                  'support': identity(O / 'support.zip'), 'manifest': identity(O / 'root-upload-manifest.json')}))
