from pathlib import Path
import difflib,hashlib
p=Path(__file__).resolve().parent
old=(p/'exact-retained-G9f-backfill-independent-review-v3.py').read_text()
new=old.replace('import sys,json,hashlib,collections,datetime,math','import sys,json,hashlib,collections,datetime,math,subprocess')
new=new.replace("root=Path.cwd();source=(root/'candidate-combined').resolve();sys.path.insert(0,str(source/'scripts'))", "root=Path.cwd();base=root/'raw-pr178-c8be5afa'/str(artifact_id)/'attempt01/extracted';source=base/'observer-source';sys.path.insert(0,str(source/'scripts'))")
new=new.replace('from p7_build_identity import source_snapshot','from p7_build_identity import json_bytes')
new=new.replace("base=root/'raw-pr178-9f7b16f'/str(artifact_id)/'extracted';read=",'read=')
new=new.replace("sha(root/'raw-pr178-9f7b16f'/str(artifact_id)/'original.zip')", "sha(Path(read(base.parent/'transport-receipt.json')['original_zip_path']))")
new=new.replace('snap=source_snapshot(source);observer=observer_snapshot(source)',"""canonical_path=root/'runtime-review-Gc8/exact-canonical-R.json'
check(sha(canonical_path)=='c38d10f1b0d5935384039a6af7df6e8d222bc351a68d3137b09e664735ee9404','fixed_canonical_R_digest')
canonical=read(canonical_path);inputs=canonical['complete_inputs']
check(canonical['source']=='35a7b3412e5fdee9e8ff88951735c06b0e371465' and canonical['verdict']=='accepted_scoped' and len(inputs)==1090,'reviewed_P_complete_map')
snap=dict(source_commit='c8be5afaac568ffd40ef86d3795423c3b73c9f39',source_tree='9b031be22a430e51e153cce6e80770ed885818e3',input_count=len(inputs),inputs=inputs,manifest_sha256=hashlib.sha256(json_bytes(inputs)).hexdigest())
from p8_runtime_build import OBSERVER_FILES
observer_files={}
for relative in OBSERVER_FILES:
 path=source/relative;data=path.read_bytes();digest=hashlib.sha256(data).hexdigest()
 check(not path.is_symlink() and digest==canonical['validation_inputs'][relative],'retained_observer_matches_reviewed_validation_domain')
 check(format(path.stat().st_mode&0o777,'o')==canonical['validation_modes'][relative][-3:],'retained_observer_mode')
 observer_files[relative]=dict(git_blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\\0'+data).hexdigest(),git_mode=canonical['validation_modes'][relative],bytes=len(data),sha256=digest)
 module_name=relative.removeprefix('scripts/').removesuffix('.py').replace('/','.')
 if module_name.endswith('.__init__'):module_name=module_name.removesuffix('.__init__')
 module=sys.modules.get(module_name)
 if module is not None:check(Path(module.__file__).resolve()==path.resolve(),'imported_original_module_from_retained_artifact')
observer=dict(source_commit=snap['source_commit'],files=observer_files,manifest_sha256=hashlib.sha256(json_bytes(observer_files)).hexdigest())
cli=subprocess.run([sys.executable,'-B',str(source/'scripts/p8_backfill.py'),'verify','--output',str(base)],capture_output=True,text=True,timeout=60)
check(cli.returncode==0,'original_backfill_verify_cli')""")
new=new.replace('9f7b16f0758eb79f306cf44605b84550f02de441','c8be5afaac568ffd40ef86d3795423c3b73c9f39').replace('exact_G9f_source','exact_Gc8_source').replace("'run_id':37896539291","'run_id':37901930897")
new=new.replace("'source_input_count':snap['input_count']", "'local_full_source_snapshot_executed':False,'local_original_observer_snapshot_executed':False,'original_verify_cli':{'actual_exit':cli.returncode,'stdout':cli.stdout,'stderr':cli.stderr},'source_input_count':snap['input_count']")
oldscope='Original released Linux integration test executed once with the original worker and fake provider. Mac reused original source/observer/inventory verifiers, independently reconstructed all request populations/quantiles and original gate facts. No primary rerun, no external provider certification, no standalone task completion or new tail-performance SLA. Original Linux compiler binaries were not re-executed on macOS.'
newscope='Original Gc8 Linux integration test executed once on GitHub with the original worker and fake provider. This separate Linux primary review independently bound all1090 raw source inputs to exact-P canonical R and Gc8 tree, all9 retained observer bytes/modes/Gitblobs to canonical139 map, and reconstructed all original request populations/quantiles and gate facts. Exact retained original seal verifier/verify CLI executed; original source_snapshot/observer_snapshot were not called against the partial restored host and no original function was monkeypatched. No primary rerun, native compiler/test execution, external provider certification, standalone task completion or new tail-performance SLA.'
assert oldscope in new;new=new.replace(oldscope,newscope)
new=new.replace("dest=root/'review-pr/pr178-ci-observation/raw-review'","dest=root/'runtime-review-Gc8'").replace("+'-review-v3.json'","+'-primary-review-v1.json'")
with (p/'primary-backfill-reviewer-v1.py').open('x') as f:f.write(new)
with (p/'backfill-v3-to-primary-v1.diff').open('x') as f:f.write(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='retained-G9f-backfill-v3.py',tofile='primary-Gc8-backfill-v1.py')))
print(len(new.encode()),hashlib.sha256(new.encode()).hexdigest())
