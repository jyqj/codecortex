"""Integrate only the fixed cache observer delta into the preserved M4 scripts."""
from pathlib import Path
import ast, difflib, hashlib, json, subprocess

ROOT=Path('/workspace/scratch/28fef0db5e01')
REPO=ROOT/'codecortex'
HERE=ROOT/'pr-audit/cache-observer-candidate'
OUT=HERE/'candidate'
BASE='d381f413bee3606bdc7410a73be855a0aab4aabb'
OLD='d2d492b329a5630bf4a5fa6bc4b6eac30d07b13c'
OWNER='24b0cba53178d14ef6c02355ee271fa0067be3e0'

def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def raw(ref,path):return git('show',ref+':'+path)
def sha(value):return hashlib.sha256(value).hexdigest()
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

def main():
    OUT.mkdir(exist_ok=False)
    inventory={}
    for row in git('ls-tree','-rz',BASE,'--','scripts').split(b'\0'):
        if not row:continue
        meta,p=row.split(b'\t',1);mode,kind,oid=meta.decode().split();path=p.decode()
        assert kind=='blob' and mode in ('100644','100755')
        value=git('cat-file','blob',oid);dest=OUT/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(value)
        dest.chmod(0o755 if mode=='100755' else 0o644)
        inventory[path]={'mode':mode,'git_blob':oid,'bytes':len(value),'sha256':sha(value)}
    path='scripts/p8_runtime.py';base=raw(BASE,path).decode();old=raw(OLD,path).decode().splitlines(True);new=raw(OWNER,path).decode().splitlines(True)
    candidate=base;transforms=[]
    changes=[op for op in difflib.SequenceMatcher(None,old,new,autojunk=False).get_opcodes()if op[0]!='equal']
    assert len(changes)==13
    for tag,a,b,c,d in reversed(changes):
        before=''.join(old[a:b]);after=''.join(new[c:d]);prev=old[a-1] if a else '';nxt=old[b] if b<len(old) else ''
        # Parent-specific cleanup/admission lines are deliberately never copied.
        if before:
            anchor=before+nxt;replacement=after+nxt
        elif prev=='                      release_approval=False)\n':
            anchor=prev;replacement=prev+after
        else:
            anchor=prev+nxt;replacement=prev+after+nxt
        assert candidate.count(anchor)==1,(tag,a,b,anchor)
        candidate=candidate.replace(anchor,replacement,1)
        transforms.append({'tag':tag,'owner_old_lines':[a+1,b],'owner_new_lines':[c+1,d],
            'original_anchor':anchor,'replacement':replacement,'inserted_or_replacement_sha256':sha(after.encode())})
    reconstructed=candidate
    for change in reversed(transforms):
        assert reconstructed.count(change['replacement'])==1
        reconstructed=reconstructed.replace(change['replacement'],change['original_anchor'],1)
    assert reconstructed==base
    (OUT/path).write_text(candidate)
    test='scripts/tests/test_p8_runtime_cache.py';assert test not in inventory
    (OUT/test).write_bytes(raw(OWNER,test))
    old_ast=ast.parse(base);new_ast=ast.parse(candidate)
    owner_ast=ast.parse(''.join(new));helpers=['cache_identity','cache_lookup','require_stable_hybrid','validate_cache_probe','soak_read','soak_cache_summary']
    def function(tree,name):return next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name==name)
    helper_hashes={}
    for name in helpers:
        expected=ast.dump(function(owner_ast,name),include_attributes=False);actual=ast.dump(function(new_ast,name),include_attributes=False)
        assert actual==expected;helper_hashes[name]=sha(actual.encode())
    for node in old_ast.body:
        if isinstance(node,ast.FunctionDef)and node.name!='run':assert ast.dump(node,include_attributes=False)==ast.dump(function(new_ast,node.name),include_attributes=False)
    # Original test file, including all31 controls, is exported unchanged.
    assert (OUT/'scripts/tests/test_p8_runtime.py').read_bytes()==raw(BASE,'scripts/tests/test_p8_runtime.py')
    delta=[]
    for p in sorted(inventory):
        if (OUT/p).read_bytes()!=raw(BASE,p):delta.append(p)
    assert delta==[path]
    patches=[]
    for p in [path,test]:
        before=raw(BASE,p).decode().splitlines(True) if p in inventory else []
        after=(OUT/p).read_text().splitlines(True)
        patches.append(''.join(difflib.unified_diff(before,after,fromfile='a/'+p if before else '/dev/null',tofile='b/'+p)))
    patch=''.join(patches);(HERE/'candidate.patch').write_text(patch)
    manifest={'schema_version':1,'base':BASE,'owner_cache_source':OWNER,'owner_pre_cache_runtime':OLD,'candidate_root':str(OUT),
        'base_scripts_inventory':inventory,'changed_existing_files':[path],'added_files':[test],
        'final_inputs':{p:{'bytes':(OUT/p).stat().st_size,'sha256':sha((OUT/p).read_bytes())}for p in [path,test,'scripts/tests/test_p8_runtime.py']},
        'cache_helpers_exact_owner_AST':helper_hashes,'reverse_delta_recovers_exact_M4_runtime':True,'original31_runtime_controls_bytes_unchanged':True,
        'all_other_M4_scripts_bytes_unchanged':True,'patch':{'path':'candidate.patch','bytes':len(patch.encode()),'sha256':sha(patch.encode())},
        'scope':'Only selected observer helpers/constants/imports and run injections from the fixed cache delta; every unrelated M4 runtime line and all other scripts retained.',
        'not_run':['product binary','artifact binary','formal3601operation1hoursoak','Actions','source admission proof'],
        'original_tasks_completed':0,'remaining_original_todos':29}
    write(HERE/'input-manifest.json',manifest);write(HERE/'integration-transform-record.json',transforms)
    print(json.dumps({'candidate_root':str(OUT),'final_inputs':manifest['final_inputs'],'patch':manifest['patch'],'exported_scripts':len(inventory)}))

if __name__=='__main__':main()
