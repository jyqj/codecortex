# Round19: existing PR180 crash-ready repair applicability

The old b2 failure is real and the existing candidate addresses its source-level readiness race. The fixed external M7F head still contains the failed fixture bytes; its only source change from b2 was the already-equivalent preselect formatter repair.

Original closeout run37942313114/job113859546794 checked out b2 exactly and failed with `ParseIntError { kind: Empty }` in `isolated_sigkill_reopen_replay_preparation`, original exit101 and result0pass/1fail/1ignored. Later lifecycle/retry/contention steps independently succeeded. The full connector-decoded log is retained; no original artifact ZIP was downloaded.

Existing candidate P2 c04033a02a7ed27f35a77247c0e5d45d0bb000a7 changes only `signal_and_wait` from a directly-created final ready file to a same-directory staged PID file followed by rename, after the unchanged durable helper has written/synced/closed it. Whole-file comparison proves all remaining bytes identical, including15seconds, PID equality, actual SIGKILL, fresh roots, all seeds/crash points and recovery assertions. Its original independent review R3f9 explicitly claims source-only acceptance, not execution.

Minimum successor scope is that one existing test-file blob atop a fresh-confirmed M7F descendant while preserving its four artifacts and new bindings. Keep the old independent review/source ancestry as historical evidence; a future complete canonical review must name the future actual P. No new P/ref was created here. Do not transplant the old whole candidate tree or reapply preselect. Expected source counts would be1095/72/142 because the fixture is not an existing b2 BASE delta; this count is prospective, not a completed new-source audit.

This package is read-only evidence and source applicability, not runtime or TODO acceptance. Original remaining count29; new completions0.
