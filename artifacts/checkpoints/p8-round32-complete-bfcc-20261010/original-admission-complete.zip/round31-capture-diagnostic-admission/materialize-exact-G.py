#!/usr/bin/env python3
import datetime, hashlib, json, os, pathlib, subprocess
ROOT=pathlib.Path(__file__).resolve().parent
REPO=ROOT/'guard-view'
PEER=ROOT.parent/'round30-PR191-equal-lifetime-admission'
SOURCE=ROOT.parent/'round31-capture-diagnostic-binding-preparation'
ENV={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0','GIT_OPTIONAL_LOCKS':'0'}
def dump(p,obj):
    with p.open('x') as f: json.dump(obj,f,indent=2,sort_keys=True); f.write('\n')
def meta(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git_blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
def command(name,argv,input=None):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    r=subprocess.run(argv,cwd=REPO,env=ENV,input=input,capture_output=True)
    for suffix,b in [('stdout',r.stdout),('stderr',r.stderr)]:
        with (ROOT/(name+'.'+suffix)).open('xb') as f:f.write(b)
    dump(ROOT/(name+'.receipt.json'),dict(argv=argv,cwd=str(REPO),exit_code=r.returncode,started_at=start,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout=meta(r.stdout),stderr=meta(r.stderr)))
    assert r.returncode==0,(name,r.returncode,r.stderr.decode(errors='replace'))
    return r.stdout
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO,env=ENV)
def main():
    config=json.loads((SOURCE/'actual-G-binding.json').read_text());G=config['source'];R=config['review'];P=config['product']
    review=json.loads((SOURCE/'independent-source-review.json').read_text())
    assert review['source']==P
    ownshallow=REPO/'.git/shallow';old=ownshallow.read_bytes();shared=(PEER/'guard-view-attempt02/.git/shallow').read_bytes()
    union=sorted(set(old.splitlines()+shared.splitlines()))
    ownshallow.write_bytes(b'\n'.join(union)+b'\n')
    dump(ROOT/'updated-readonly-history-cache.json',dict(shared_path=str(PEER/'guard-view-attempt02/.git/objects'),copied_shallow=meta(shared),previous_own_shallow=meta(old),only_own_shallow_updated=True))
    command('final-G-R-P-metadata-fetch',['git','-c','fetch.negotiationAlgorithm=noop','fetch','--no-tags','--filter=blob:none','--depth=1','origin',G,R,P])
    assert json.loads(git('show','-s','--format={"head":"%H","tree":"%T"}',G))==dict(head=G,tree=config['source_tree'])
    protected=json.loads((PEER/'historical-protected-paths.json').read_text())
    task_docs={'README.md'}|{'docs/roadmap/code-index-v2/'+n for n in ['tasks.json','06-VALIDATION.md','05-TODO.md','README.md','08-HANDOFF.md']}
    paths=set(review['complete_inputs'])|set(review['validation_inputs'])|set(protected)|task_docs|{review['review_path'],'scripts/verify_reviewed_source_v15.py','scripts/reviewed-source-registry-v15.json','.github/workflows/ci.yml'}
    rows=git('ls-tree','-rz',G,'--',*sorted(paths));entries={}
    for row in rows.split(b'\0'):
        if not row:continue
        metadata,path=row.decode().split('\t',1);mode,kind,oid=metadata.split();assert kind=='blob' and mode in ('100644','100755');entries[path]=dict(mode=mode,git_blob=oid)
    assert set(entries)==paths
    inventory=review['actual_input_mode_blob_inventory']
    for path,entry in inventory.items():assert entries[path]==dict(mode=entry['mode'],git_blob=entry['sha']),path
    unique=sorted({v['git_blob'] for v in entries.values()})
    check=subprocess.run(['git','cat-file','--batch-check=%(objectname) %(objecttype)'],input=('\n'.join(unique)+'\n').encode(),cwd=REPO,env=ENV,capture_output=True,check=True)
    missing=[line.split()[0] for line in check.stdout.decode().splitlines() if line.endswith(' missing')]
    dump(ROOT/'selected-current-blob-presence.json',dict(unique_blobs=len(unique),missing=missing,source=G))
    if missing: command('selected-current-missing-blobs-fetch',['git','-c','fetch.negotiationAlgorithm=noop','fetch','--no-tags','--no-write-fetch-head','origin','--stdin'],('\n'.join(missing)+'\n').encode())
    command('read-exact-G-index',['git','read-tree',G])
    command('set-exact-G-detached-head',['git','update-ref','--no-deref','HEAD',G])
    process=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=REPO,env=ENV)
    for path,entry in sorted(entries.items()):
        process.stdin.write((entry['git_blob']+'\n').encode());process.stdin.flush()
        header=process.stdout.readline().decode().split();assert header[:2]==[entry['git_blob'],'blob'],(path,header)
        b=process.stdout.read(int(header[2]));assert process.stdout.read(1)==b'\n';assert meta(b)['git_blob']==entry['git_blob']
        if path in inventory:assert meta(b)['sha256']==inventory[path]['sha256']
        target=REPO/path;target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as f:f.write(b)
        target.chmod(int(entry['mode'][-3:],8));entry.update(meta(b))
    process.stdin.close();err=process.stderr.read();code=process.wait();assert code==0,(code,err)
    assert git('rev-parse','HEAD').decode().strip()==G
    assert git('write-tree','--missing-ok').decode().strip()==config['source_tree']
    dump(ROOT/'actual-G-pre-admission-inputs.json',dict(source=G,source_tree=config['source_tree'],product=P,review=R,selected_entries=entries,counts=dict(product=len(review['complete_inputs']),BASE_delta=len(review['paths']),validation=len(review['validation_inputs']),selected=len(entries)),scope='Exact selected real-G Git projection; not a full repository checkout. Shared history objects are read-only.'))
    print(json.dumps(dict(source=G,selected=len(entries),missing_current_blobs=len(missing),status='materialized')))
if __name__=='__main__':main()
