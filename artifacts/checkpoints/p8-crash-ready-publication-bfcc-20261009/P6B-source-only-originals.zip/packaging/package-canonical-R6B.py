#!/usr/bin/env python3
"""Seal an independently reviewed actual source record and compact originals."""
from pathlib import Path
import json,hashlib,zipfile,stat,datetime,copy
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'final-R6B'
PRIOR=Path('/dev/shm/pr-triage-P5B-preselect-format-source-review')
READY=Path('/dev/shm/todo-audit-round19-PR180-crash-ready-review')
PREFIX='artifacts/checkpoints/p8-crash-ready-publication-bfcc-20261009'
P='5534ebf38cc31efec1590d132ca57c30e2f77f1b'
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def meta(p):
 p=Path(p);b=p.read_bytes();return {'local_path':str(p),'bytes':len(b),'sha256':sha(b),'git_blob':oid(b)}
def write(p,d):p.write_text(json.dumps(d,indent=2,sort_keys=True,ensure_ascii=False)+'\n')
assert not OUT.exists();OUT.mkdir()
maps=read(ROOT/'actual-P6B-complete-product-validation-inputs.json')
bridge=read(ROOT/'actual-P6B-independent-source-bridge.json')
assert read(ROOT/'source-bridge-receipt.json')['actual_exit_code']==0
assert maps['source']==P and maps['source_tree']=='3d3d5a6ef11f3e632eb5ab8ce2502d7854aa2bd1'
assert [len(maps[k]) for k in ('complete_inputs','paths','validation_inputs','actual_input_mode_blob_inventory')]==[1095,72,142,1237]
assert all(set(x)=={'before_sha256','sha256'} for x in maps['paths'].values())
prior=read(PRIOR/'independent-source-review.json')
external=read(PRIOR/'external-M7F-equivalence/external-canonical-R.json')
old=read(READY/'source/candidate-independent-review.json')
scope=read(READY/'independent-existing-repair-applicability-review.json')
assert scope['verdict']=='existing_candidate_applicable_scoped_source_only'
selected=[]
def add(p,name):
 p=Path(p);assert p.is_file() and not p.is_symlink();b=p.read_bytes()
 selected.append({'source_path':str(p),'member':name,'bytes':len(b),'sha256':sha(b),'git_blob':oid(b),'mode':format(stat.S_IMODE(p.stat().st_mode),'04o')})
for p in sorted((ROOT/'official-responses').glob('*.json')):add(p,'actual-P6B/official-responses/'+p.name)
for n in ('verify-P6B-bridge.py','actual-P6B-complete-product-validation-inputs.json','actual-P6B-independent-source-bridge.json','source-bridge-receipt.json','source-bridge.stdout','source-bridge.stderr'):
 add(ROOT/n,'actual-P6B/'+n)
for n in ('independent-source-review.json','external-M7F-equivalence/independent-M7F-versus-G5B-equivalence-review.json','external-M7F-equivalence/external-canonical-R.json'):
 add(PRIOR/n,'inherited-source/'+n)
for n in ('source/b2-p7_crash_preparation.rs','source/candidate-p7_crash_preparation.rs','source/M7F-p7_crash_preparation.rs','source/candidate-independent-review.json','source/b2-p7-closeout.yml','source/original-v15-guard-b2.py','original-closeout-113859546794.decoded.log','original-log-selected-line-references.json','independent-existing-repair-applicability-review.json','original-v15-reuse-and-forward-boundary.json','existing-candidate-applicability.patch','official-responses/original-closeout-steps.json','official-responses/candidate-product-diff.json','official-responses/candidate-review-diff.json','official-responses/candidate-commit.json','official-responses/PR180-external-M7F-original-commit.json','official-responses/PR180-external-M7F-original-compare.json'):
 add(READY/n,'original-existing-candidate/'+n)
add('/dev/shm/root-round20/P6B-created-objects-original.json','actual-P6B/root-created-objects-original.json')
add(Path(__file__),'packaging/package-canonical-R6B.py')
assert len({x['member'] for x in selected})==len(selected)
manifest={'schema':'P6B-source-only-selected-originals-v1','file_count':len(selected),'total_original_bytes':sum(x['bytes'] for x in selected),'files':selected,'no_full_original_measurement_ZIP_ELF_or_runtime_database':'No original large artifact body is included; original b2 artifact locator/digest retained in applicability report.','no_new_source_execution':True}
write(OUT/'support-member-manifest.json',manifest)
support=OUT/'P6B-source-only-originals.zip'
with zipfile.ZipFile(support,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as z:
 for row in selected:
  p=Path(row['source_path']);b=p.read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'] and oid(b)==row['git_blob']
  zi=zipfile.ZipInfo(row['member'],(2026,10,9,0,0,0));zi.create_system=3;zi.external_attr=(stat.S_IFREG|int(row['mode'],8))<<16;zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,b)
 b=(OUT/'support-member-manifest.json').read_bytes();zi=zipfile.ZipInfo('support-member-manifest.json',(2026,10,9,0,0,0));zi.create_system=3;zi.external_attr=(stat.S_IFREG|0o644)<<16;zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,b)
with zipfile.ZipFile(support) as z:
 assert z.testzip() is None and len(z.infolist())==len(selected)+1
 for row in selected:
  b=z.read(row['member']);assert len(b)==row['bytes'] and sha(b)==row['sha256'] and oid(b)==row['git_blob']
  assert stat.S_IMODE(z.getinfo(row['member']).external_attr>>16)==int(row['mode'],8)
  p=Path(row['source_path']);assert p.read_bytes()==b and stat.S_IMODE(p.stat().st_mode)==int(row['mode'],8)

canonical={
 'schema_version':1,'source':P,'source_tree':maps['source_tree'],'source_parents':maps['source_parents'],'base':maps['base'],
 'scope':'independently_reviewed_source_and_validation_inputs','verdict':'accepted_scoped','independent_reviewers':['/root/todo_audit'],'unresolved_blockers':[],
 'unresolved_blocker_scope':'No source-level blocker in the existing one-function fixture repair or exact inherited input composition. Formatting, compilation, Rust tests, selected v15 source admission and any runtime/measurement of actual P6B remain not_run. These pending executions are not called source-review passes.',
 'complete_inputs':maps['complete_inputs'],'paths':maps['paths'],'validation_inputs':maps['validation_inputs'],'actual_input_mode_blob_inventory':maps['actual_input_mode_blob_inventory'],
 'review_path':PREFIX+'/independent-source-review.json',
 'author_independence':{'current_reviewer':'/root/todo_audit','actual_commit_creator':'/root','candidate_authorship':'Existing published P2 c04033a02a7ed27f35a77247c0e5d45d0bb000a7 from the separate PR180 repair workstream; this reviewer did not write or edit that candidate or create P6B.','current_work':'Read full original failure and old/new fixture, independently verify existing one-function patch, actual official commit/one-leaf compare and four directory tree nodes, inherit already-reviewed unchanged domain by immutable equality.','prior_reviewers_are_historical_only':'/root/pr_triage and the original external reviewers retain their own fixed scopes; they are not listed as current signers.'},
 'primary_review':{'actual_source_bridge':bridge,'directly_reviewed_path':'crates/cc-semantic/tests/p7_crash_preparation.rs','direct_semantics':{'old_race':'The old durable helper File::create made the final ready path visible before PID write_all and sync_all. Parent waited only for path existence before parsing the contents. Original b2 log observed Empty at that parser; no interleaving instrumentation is claimed.','repair':'Write PID to same-directory ready.<pid>.tmp using unchanged durable; helper return closes the synced file; rename it to ready before parking. Parent sees final ready only after the PID content is complete.','whole_file_equivalence':'All bytes outside signal_and_wait are identical, including existing durable helper and parent.','preserved':scope['existing_candidate']['preserved'],'platform_boundary':'Original cfg(unix) retained; observed failure was Linux GitHub runner. This is process-kill preparation, not power-loss or directory-fsync certification.','no_production_or_budget_change':True},'inherited_71_deltas':'Exact current hashes and BASE-before values retained from independently reviewed P5B/M7F. Their source semantics retain their original non-author review history; current reviewer verifies the identity bridge and directly reviews only this new fixture delta.','ordinary_validation':'All142 reviewed validation bytes/modes, CI and historical controls unchanged; future guard binding is outside product review.','new_original_tests':'None added. The original three seeds, four crash points, ignored owned child entry, assertions and deadlines remain unchanged.'},
 'previous_fixed_reviews':[
  {'review':'90634915eb13b9c2ccc0aa046da5927059b5434c','source':'3c0bffefb0aa49e65dae5df92e2302cf7a635acf','source_tree':'7fb46257805e9da89737ef7a6a05574b83f50d79','path':'artifacts/checkpoints/p8-M7F-preselect-format-a217-20261009/independent-source-review.json',**{k:v for k,v in meta(PRIOR/'external-M7F-equivalence/external-canonical-R.json').items() if k!='local_path'},'scope':'Published M7F predecessor complete maps and retained source chain; its unrelated narrative concerning PR188/SQL is not adopted by this review.'},
  {'review':'cef789c9072e659e2026c33b537833edeaf775c9','source':prior['source'],'source_tree':prior['source_tree'],'path':prior['review_path'],**{k:v for k,v in meta(PRIOR/'independent-source-review.json').items() if k!='local_path'},'scope':'Independent complete1095/71/142 map and non-author formatter review; whole source tree is identical to external M7F P3c0. Original negative and source-only execution boundaries are retained unchanged in support ZIP.'},
  {'review':'3f9dcce4d072b04f21fcfcf1712bacb6171274c4','source':'c04033a02a7ed27f35a77247c0e5d45d0bb000a7','path':'artifacts/checkpoints/p8-pr180-b2a-ci-repair-28fe-20261009/independent-review.json',**{k:v for k,v in meta(READY/'source/candidate-independent-review.json').items() if k!='local_path'},'scope':'Original narrow existing two-file repair review, not a canonical v15 record and not execution. Current PID file is its exact candidate blob; preselect was already absorbed in M7F.'}],
 'current_execution':{'actual_P6B':{'rustfmt':'not_run','Clippy':'not_run','Rust_tests':'not_run','source_CLI':'not_run','runtime_or_scale':'not_run'},'source_review_mechanical_receipt':meta(ROOT/'source-bridge-receipt.json'),'source_review_mechanical_actual_exit':0,'original_b2_failure':scope['source_failure'],'M7F_and_prior_successes':'All earlier execution retains actual checkout/source/environment. Current P6B receives no execution credit from M7F, P5B, old c040/R3f9, G4/PR188 or any old scale cohort.'},
 'historical_preservation':{'entire_M7F_tree_other_than_one_fixture':'Preserved exactly by reverting that leaf in four hashed official directory objects and recovering the full M7F root. All four M7F artifacts and its old binding history remain intact.','old_original_review':'R3f9 remains its original historical scope; no original file or status was overwritten.','earlier_negative_evidence':'Original formatter, compile/test, sampling/ready failures, incomplete/failed scale, prior source/transport preparation failures and any explicitly pending historical claims stay bound to their old identities. The complete prior R5B and its chain are retained in support.','unrelated_PR188':'This review does not adjudicate its SQL tradeoff or transfer its source/execution claims.'},
 'review_support':{'originals_zip_repository_path':PREFIX+'/P6B-source-only-originals.zip',**{k:v for k,v in meta(support).items() if k!='local_path'},'selected_files':len(selected),'zip_members':len(selected)+1,'all_selected_before_after_bytes_modes_and_CRC_verified':True,'all_original_failure_log':'Complete connector-decoded original job log included; not claimed as original HTTP binary bytes or whole artifact ZIP.'},
 'task_and_release_boundary':{'newly_completed':0,'done':163,'remaining':29,'formal_completion':False,'release_or_full_scale_pass':False,'no_additional_test_or_study_gate':True}}
assert canonical['scope']==prior['scope'] and canonical['base']=='7354db236c9d9850a75f31672697ae9eab44565e'
assert canonical['independent_reviewers']==['/root/todo_audit'] and canonical['unresolved_blockers']==[]
write(OUT/'independent-source-review.json',canonical)
upload={'schema_version':1,'source_P':P,'source_tree':maps['source_tree'],'parent':maps['source_parents'][0],'source_only':True,'file_count':2,'files':[]}
for name in ('independent-source-review.json','P6B-source-only-originals.zip'):
 upload['files'].append({**meta(OUT/name),'repository_path':PREFIX+'/'+name,'mode':'100644'})
write(OUT/'upload-manifest.json',upload)
print(json.dumps({'upload_manifest':meta(OUT/'upload-manifest.json'),'files':upload['files'],'support_selected':len(selected),'support_members':len(selected)+1,'source_only':True},sort_keys=True))
