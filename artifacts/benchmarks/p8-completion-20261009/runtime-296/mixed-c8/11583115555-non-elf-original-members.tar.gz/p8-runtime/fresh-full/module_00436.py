def stable_00436():
    return 436
