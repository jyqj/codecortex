def stable_00465():
    return 465
