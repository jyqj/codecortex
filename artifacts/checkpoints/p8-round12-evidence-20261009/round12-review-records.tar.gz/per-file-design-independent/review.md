结论：接受“同一文件、同一表的连续行，64/8/1 层级”作为下一份隔离实现草稿的设计方向，附下列必须保留的实施条件。它不是现成实现或 CI 准入，更没有证明性能收益。固定被审设计与 8e 源码的 SHA 见 review.json；本次未修改任一原文件，未执行 Cargo、SQLite 产品负载或基准。

六个现有 binder 的列序和原 full writer 对应：symbols 25、symbol_refs 18、call_edges 30、routes 19、semantic_edges 10、dispatch_sites 11。选择 OR REPLACE 的分支后，INSERT head/列序与原单行循环一致；最大一条 64×30=1920 个参数。没有发现需要另造 SQL owner 的理由。

1. **只接 full 入口。** `SnapshotWriteTxn::write_file_data` 目前逐文件调用 `insert_file_data_precompressed`；后者最终进入共用的 `insert_file_data_impl`。不能直接把共用方法的六个循环全改批写，然后声称默认 incremental 未变。应增加明确 full 专用入口，只由 SnapshotWriteTxn 调用；现有 per-file/config/incremental 调用者和现有 `multi_insert` 的全局分批行为保持原样。共用的是六个绑定器，不是 `insert_file_units_batch` 的跨文件执行顺序。

2. **事务与失败只证明原范围。** 普通 staging 在 `execute_temp_db_staging_build` 的私有 WAL、foreign_keys=ON、一个 transaction 中运行，write_fn 错误不进入 commit/swap；因此同一批中较晚一行失败导致的 statement 回滚差异不会使部分 live 索引发布。不能在失败后继续处理下一文件，也不能另加 savepoint/commit/epoch bump。`DirectWriter` 原来是 journal_mode=OFF，且没有在此路径显式启用 FK；SnapshotWriteTxn 的文档明确可被这两种 adapter 使用。必须分别保留各 adapter 的实际 PRAGMA 和失败行为，不能把普通 WAL 的 FK 错误/物理回滚结论套在 DirectWriter 上。后者只主张错误传播、私有失败工件不发布与 live generation/内容不变；不宣称私有 OFF-journal 文件可逐字回滚。

3. **FK 的具体反例。** 在普通 staging 的 file A 中放一条 `symbol_refs.file_path=B`（B 尚未写入），之后再写 file B。原路径在 A 的这条 FK 处失败；候选也必须失败。同表 batching 不会引入 files 父行，不能通过“先写全部文件”把该错误变成成功。这里有 FK 的是 symbols、symbol_refs、call_edges 和 routes；semantic_edges、dispatch_sites 的 file_path 只有 NOT NULL，没有该 FK，不能给这两表虚构同样约束。重复 files.rel_path 仍必须在第二个原文件 INSERT 失败。

4. **OR REPLACE 不仅是主键。** `symbols` 还存在 `symbol_uid TEXT UNIQUE`，删掉显式索引并不会移除表级 UNIQUE 的 autoindex。需要分别测试同 symbol_id、不同 symbol_id 但同 symbol_uid、一个新行同时撞两个旧行的情形，并把冲突放在第 8/9、64/65 行两侧。检查最终 symbols、实际 rowid、完整 symbols_fts 内容与 MATCH 结果；不能只比较幸存主键。原触发器与 recursive_triggers 的实际配置保持原样，不顺手修补旧 OR REPLACE/FTS 行为。其余五表也保留原 keyed replacement 顺序及字段值，不能去重或排序。

5. **身份 readback 的确切时点。** 原 full writer 完成本文件全部 symbols 后，立即执行本文件 `symbol_identity_store::insert_on`，其中先检 SQL survivor，再插入 association，再完整 `load_on` 核 qname/源 JSON。候选必须在同一时点、同一连接调用原 helper。构造本文件前后 symbol_id/uid 冲突，并带被替换和幸存声明的身份；还要保留后续文件用同键覆盖的异常输入。原来跳过的 association 不能新出现；不能把所有文件 symbols 写完才读身份，也不能在跨文件覆盖后追溯修改原 association。这是准确重现当前行为，不是宣布所有异常输入均产生可查询身份。

6. **64 KiB 是新增缓冲界限，不是产品合法行限制。** 只保存最多 64 个借用行引用；不得先 collect 全文件/全 outcome 再分块。按六个 binder 实际绑定的全部 TEXT/BLOB UTF-8 字节与固定宽度标量，使用不会溢出的计数；NULL/Option 和 i32/i64 cast 必须与原绑定一致。加入下一行前检查上限，先按 64/8/1 排空；单行合法但大于 64 KiB 时走原单行路径而不是拒绝。边界至少覆盖 65535/65536/65537 字节、空/NULL/多字节字符串，以及 0/1/7/8/9/63/64/65 行。选择的六表现在不需要新的 JSON 序列化；若未来加入，额外所有权/临时分配必须重新审计。不能从最多 64 个引用推导 RSS≤64KiB，SQLite bind/statement/cache 自有开销仍存在。

7. **FTS、行数与验证范围。** files/chunks/literal 的单行镜像和 last_insert_rowid 配对不变，不加入 file_path 扫描。大块压缩 chunk 仍由原明文镜像；literal OR IGNORE 的 first winner/affected-row 分支不变。测试在显式索引移除的真实 schema 上比较旧、新两条路径，原 15 表 oracle 之外补充所有 FTS、依赖 rowid 的镜像、document/identity 记录，因为 15 表相等不能代替这些额外断言。较晚的非法 identity 应在已写过若干 batch 后失败，并保持旧 live generation/内容。保留原并发 rebuild fence、checkpoint busy、schema、49 文件 resume 和 scale/oracle 控制。若没有足够同文件行数，计数必须如实表现为单行；不能宣称总行数/64 就是实际 statements。

该设计已自行限制竞争物理故障下的“首个错误类型”承诺；这个限制合理。对于成功数据，仍须证明行值、冲突赢家和触发副作用等价；对于失败数据，仍须证明错误没有被吞掉且 live 不会发布。新实现将改变 statement 粒度，因此没有这些实际控制前，不能以本次静态设计审查作为产品源码审批。

作者已经明确同意以上 full-only、双 UNIQUE/FTS/identity、分 adapter 证明范围，且保留原设计字节。没有新增实现、测量、任务关闭或加速声明；仍 29 项未完成。
