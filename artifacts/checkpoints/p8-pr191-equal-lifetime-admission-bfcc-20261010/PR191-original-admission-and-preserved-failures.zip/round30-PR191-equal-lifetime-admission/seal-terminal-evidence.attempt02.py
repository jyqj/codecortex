from pathlib import Path
import datetime
import hashlib
import json
import os
import stat
import zipfile

root = Path(__file__).resolve().parent
workspace = root.parent
out = root / 'sealed-terminal-attempt02'
out.mkdir()
terminal_path = root / 'actual-original-validation-attempt03/terminal.json'
terminal = json.loads(terminal_path.read_bytes())
assert terminal['passed'] and len(terminal['records']) == 2
assert all(r['exit_code'] == 0 and r['inputs_unchanged'] and not r['error'] and not r['after_snapshot_error'] for r in terminal['records'])

def meta(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

objects = json.loads((root / 'actual-P-R-G-original-objects.json').read_bytes())
identities = {}
for kind, expected in [('P', '595789f80a76a83b921aec8c6e2a225b25790b40'), ('R', 'f0ca176ad1d22d4236bcce5848d8c45493be8df0'), ('G', '1ebb6208f2f5f8fe8a5bf237c00a3d963f44bb08')]:
    original = json.loads(objects['PR191-' + kind + '-official']['structuredContent']['content'])
    assert original['sha'] == expected
    identities[kind] = {'commit': expected, 'tree': original['tree']['sha'], 'parents': [r['sha'] for r in original['parents']]}
assert identities['P']['parents'] == ['7da43a80bc00698101de5619dd486a3393a667a3']
assert identities['R']['parents'] == [identities['P']['commit']]
assert identities['G']['parents'] == [identities['R']['commit']]

selected = set()
def select(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    selected.add(path)

# These are original preparation/execution records. Repositories and product
# source bytes are referenced by their immutable Git identities, not re-packed.
for path in root.iterdir():
    if path.is_file() and not path.name.startswith('seal-terminal-evidence'):
        if path.name in {'independent-P-review-support.json', 'history-required-blob-locators.json', 'current-selected-tree.json', 'actual-P-materialized-selected-inputs.json', 'historical-BASE-declared-tree.json'}:
            continue
        select(path)
for dirname in ('generated-G', 'actual-original-validation-attempt02', 'actual-original-validation-attempt03'):
    for path in (root / dirname).iterdir():
        if path.is_file():
            select(path)
peer = workspace / 'round30-PR191-equal-lifetime-peer'
for name in ('actual-G-independent-thin-review.json', 'actual-G-peer-blob-create-original.json', 'actual-P-independent-bridge.json'):
    select(peer / name)
select(Path(__file__))

failure = json.loads((root / 'actual-original-validation-attempt02/original-v15-execution.json').read_bytes())
assert failure['exit_code'] == 1 and failure['inputs_unchanged']
v15_stdout = (root / 'actual-original-validation-attempt03/original-v15.stdout').read_bytes()
v15 = json.loads(v15_stdout)
assert v15['status'] == 'passed' and v15['complete_inputs'] == 1096
assert v15['product_source'] == identities['P']['commit'] and v15['review_source'] == identities['R']['commit']
plan = json.loads((root / 'actual-original-validation-attempt03/original-task-plan.stdout').read_bytes())
assert plan['status'] == 'passed' and plan['task_count'] == 192 and plan['states']['done'] == 163

report = {
    'schema': 'pr191-equal-lifetime-unpublished-admission-terminal-v1',
    'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'verdict': 'accepted_scoped_original_v15_and_task_plan_execution',
    'identities': identities,
    'fixed_PR191_base': 'fffd950d5b34b0180f308db1428a57d5bf358bf1',
    'current_PR_and_ref_mutated_by_this_task': False,
    'product_paths': 1096, 'BASE_delta_paths': 72, 'validation_paths': 144,
    'P_change_scope': {'modified': ['crates/cc-db/src/rebuild_chunk_statement_tests.rs'], 'added': ['.github/workflows/p8-rebuild-chunk-equal-lifetime-cost.yml']},
    'P_behavior_scope': 'New independently named ignored finite diagnostic and exact-label workflow. The old probe prefix, old workflow and production source remain unchanged.',
    'author': '/root/execution_recon',
    'non_author_source_and_binding_reviewer': '/root/todo_audit',
    'canonical_review': {'path': 'artifacts/checkpoints/p8-rebuild-chunk-equal-lifetime-bfcc-20261009/independent-source-review.json', 'commit': identities['R']['commit'], 'git_blob': '95c41ab6f4ae9f1801039ea81a4e583bc0f0852d', 'bytes': 196454, 'sha256': 'cb0ca245699efa7e9d2899230f9b61322dde2b454cdaead003dd9762e67054aa'},
    'immutable_support_locators': {'author_evidence_git_blob': '9d56aed826774b129ed394d5030dfcc5261c5a83', 'independent_P_review_support_git_blob': 'c7da6a3e53d92be24fd0b509219f62b3a54de4e8', 'actual_G_independent_peer_git_blob': '718acf453b9de8e20c6d29736ffe2d05ea7c6a76'},
    'binding_scope': json.loads((root / 'generated-G/generation-manifest.json').read_bytes()),
    'original_executions': terminal['records'],
    'original_v15_stdout': v15,
    'original_task_plan_stdout': plan,
    'task_plan_scope': 'This fixed M7F-based PR191 branch retains 163 done / 29 remaining. This is not a rollback or replacement of current main ledger 164 done / 28 remaining.',
    'input_preservation': 'Each original command has complete before/after 1439 selected mode/blob/SHA records plus actual HEAD and full tracked index evidence, byte-identical. Partial checkout omits unrelated artifact bodies; index is genuine and write-tree --missing-ok proves its actual tree.',
    'historical_closure': json.loads((root / 'recursive-declared-closure.complete-review.json').read_bytes()),
    'negative_history': [
        'Initial exact fetch with an older read-only alternate failed on missing shallow-parent connectivity; new isolated Git repository was prepared without that alternate.',
        'Mechanical G generator attempt01 rejected an overly narrow reviewer-string assumption; no canonical/guard changes were made to bypass it. Exact canonical reviewer value was used by attempt02.',
        'Host controller attempt01 stopped before any original CLI on write-tree requiring an unrelated absent promisor blob; host-only --missing-ok authentic index proof was used thereafter.',
        {'original_v15_attempt02': failure, 'reason': 'Missing historical data-driven v1 review_imports record, not a source acceptance result; task-plan was not run.'},
        'All statically declared v1-v15 records, packing inputs, bounded review imports and Python migration/import references were enumerated before the next original CLI. Exactly 63 missing blobs were recovered in one batch; complete required union 1611 blobs was present before attempt03.'
    ],
    'execution_not_performed': ['Rust compilation', 'rustfmt', 'Clippy', 'ignored cost probe', 'workflow', 'scale workload', 'benchmark'],
    'new_samples': 0, 'task_completion_credit': 0,
    'label_event_boundary': json.loads((root / 'final-label-event-boundary.json').read_bytes()),
    'round_boundary': 'Candidate and retained failed attempts began in round30; round30 closed 2026-10-10 00:05:39 UTC with 0 new completions, cumulative 1 completed and 28 remaining. Final successful admission was in continuing round31. No earlier file was relabeled or overwritten.'
}
report_path = out / 'actual-unpublished-admission-review.json'
save(report_path, report)
select(report_path)
files = []
for path in sorted(selected):
    raw = path.read_bytes()
    files.append({'local_path': str(path), 'archive_path': path.relative_to(workspace).as_posix(), 'mode': oct(stat.S_IMODE(path.stat().st_mode)), **meta(raw)})
assert all(meta(Path(row['local_path']).read_bytes()) == {k:row[k] for k in ('bytes','sha256','git_blob')} for row in files)
selection = {'schema': 'exact-selected-original-files-v1', 'files': files, 'file_count': len(files), 'total_bytes': sum(r['bytes'] for r in files), 'excluded_source_objects': 'Existing P/R/G immutable repository objects; no product checkout, old study ZIP or binary is embedded.'}
selection_path = out / 'archive-selection.json'
save(selection_path, selection)
zip_path = out / 'PR191-original-admission-and-preserved-failures.zip'
with zipfile.ZipFile(zip_path, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for row in files:
        archive.write(row['local_path'], row['archive_path'])
    archive.write(selection_path, 'archive-selection.json')
with zipfile.ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    assert len(archive.infolist()) == len(files) + 1
    for row in files:
        assert meta(archive.read(row['archive_path'])) == {k: row[k] for k in ('bytes', 'sha256', 'git_blob')}
        assert stat.S_IMODE(archive.getinfo(row['archive_path']).external_attr >> 16) == int(row['mode'], 8)
prefix = 'artifacts/checkpoints/p8-pr191-equal-lifetime-admission-bfcc-20261010/'
manifest = {'schema': 'root-artifact-only-upload-manifest-v1', 'refs_or_commits_changed': False, 'files': [
    {'local_path': str(path), 'repository_path': prefix + name, 'mode': '100644', **meta(path.read_bytes())}
    for path, name in [(report_path, 'actual-unpublished-admission-review.json'), (zip_path, zip_path.name), (selection_path, 'archive-selection.json')]
]}
save(out / 'root-upload-manifest.json', manifest)
print(json.dumps({'selected_files': len(files), 'selected_bytes': selection['total_bytes'], 'zip_members': len(files) + 1, 'files': manifest['files']}, indent=2))
