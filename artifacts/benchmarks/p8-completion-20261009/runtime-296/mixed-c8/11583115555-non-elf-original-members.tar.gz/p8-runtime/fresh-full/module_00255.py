def stable_00255():
    return 255
