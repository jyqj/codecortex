"""Root-authorized removal of six completed historical runtime extractions only."""
import datetime
import hashlib
import json
import pathlib
import shutil
import stat
import zipfile

B = pathlib.Path(__file__).resolve().parent
IDS = ("11597519732", "11598543621", "11598690899", "11598815621", "11598875346", "11600492680")
OUT = B / "round30-derived-reclamation"
assert not OUT.exists()
OUT.mkdir()


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def ss(path):
    value = path.lstat()
    assert stat.S_ISREG(value.st_mode) and not path.is_symlink(), str(path)
    return dict(bytes=value.st_size, sha256=sha(path), mode=stat.S_IMODE(value.st_mode),
                inode=value.st_ino, device=value.st_dev, nlink=value.st_nlink,
                mtime_ns=value.st_mtime_ns, ctime_ns=value.st_ctime_ns,
                allocated_bytes=value.st_blocks * 512)


def dump(path, obj):
    with path.open("x") as stream:
        stream.write(json.dumps(obj, indent=2, sort_keys=True) + "\n")


protected_paths = [path for path in B.iterdir() if path.is_file()]
for name in ("reviews", "executions", "helpers-275e-v1", "recovery-helpers-275e-v2", "peer-reviews"):
    protected_paths.extend(path for path in (B / name).rglob("*") if path.is_file())
for area in (B / "artifacts").iterdir():
    if area.is_dir():
        protected_paths.extend(path for path in area.iterdir() if path.is_file())
protected = {str(path): ss(path) for path in sorted(set(protected_paths))}
protected_file = OUT / "protected-before.json"
dump(protected_file, protected)
protected[str(protected_file)] = ss(protected_file)

plans = []
for artifact in IDS:
    area = B / "artifacts" / artifact
    archive = area / (artifact + ".zip")
    derived = area / "extracted"
    metadata = json.loads((area / "artifact-metadata.json").read_text())
    accepted = json.loads((B / "executions" / artifact / "execution.json").read_text())
    preflight = json.loads((B / "executions" / artifact / "preflight.json").read_text())
    assert accepted["status"] == "accepted_scoped_original_evidence"
    assert all(row["exit_code"] == 0 for row in accepted["commands"])
    digest = metadata["digest"].removeprefix("sha256:")
    assert metadata["id"] == int(artifact) and metadata["workflow_run"]["head_sha"] == "275e8799d4947d297329073eaa3ca675d3fd0777"
    assert sha(archive) == digest == accepted["original_zip_sha256_after"]
    assert archive.stat().st_size == metadata["size_in_bytes"]
    assert derived.is_dir() and not derived.is_symlink()
    files = {row["path"]: row for row in preflight["extraction"]["extracted_files"]}
    directories = {parent.as_posix() for name in files for parent in pathlib.PurePosixPath(name).parents if str(parent) != "."}
    entries = {path.relative_to(derived).as_posix(): path for path in derived.rglob("*")}
    assert set(entries) == set(files) | directories, (artifact, "unknown or missing entry; stop")
    assert all(entries[name].is_dir() and not entries[name].is_symlink() for name in directories)
    rows = []
    with zipfile.ZipFile(archive) as original:
        infos = [info for info in original.infolist() if not info.is_dir()]
        assert len(infos) == len(files) and {info.filename for info in infos} == set(files)
        for info in infos:
            current = ss(derived / info.filename)
            with original.open(info) as stream:
                digest_member = hashlib.file_digest(stream, "sha256").hexdigest()
            assert current["bytes"] == info.file_size == files[info.filename]["bytes"]
            assert current["sha256"] == digest_member == files[info.filename]["sha256"]
            assert current["mode"] == 0o444 and current["nlink"] == 1, (artifact, info.filename, "changed mode/link; preserve")
            rows.append(dict(path=info.filename, zip_external_mode=info.external_attr >> 16, **current))
    assert sha(archive) == digest
    candidate = dict(schema="historical-173-runtime-derived-candidate-v1", artifact_id=int(artifact),
                     directory=str(derived), original_zip=dict(path=str(archive), bytes=archive.stat().st_size, sha256=digest),
                     original_preflight=dict(path=str(B / "executions" / artifact / "preflight.json"), sha256=sha(B / "executions" / artifact / "preflight.json")),
                     original_accepted_execution=dict(path=str(B / "executions" / artifact / "execution.json"), sha256=sha(B / "executions" / artifact / "execution.json")),
                     files=rows, directories=sorted(directories), selected_file_count=len(rows),
                     selected_content_bytes=sum(row["bytes"] for row in rows),
                     selected_allocated_file_bytes=sum(row["allocated_bytes"] for row in rows),
                     protected_manifest=dict(path=str(protected_file), sha256=sha(protected_file)),
                     activity="All original task-owned evidence readers have completed and have no current/future dependency on these six extractions. No system-wide PID claim.",
                     authorization="Root authorized only matching, completed historical173 runtime-derived files. Original ZIPs, reports, helpers, unknown/changed paths and all C lifecycle/recovery paths remain outside deletion scope.",
                     stat_scope="Original preflight retained bytes/hash and0444. Current inode/nlink/times captured here and checked immediately before unlink; original inode history is not claimed.",
                     created_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    path = OUT / (artifact + "-candidate.json")
    dump(path, candidate)
    protected[str(path)] = ss(path)
    plans.append((derived, rows, directories, path, candidate))

# No mutation until all six complete original-member proofs and protected snapshots agree.
for derived, rows, directories, path, candidate in plans:
    assert set(p.relative_to(derived).as_posix() for p in derived.rglob("*")) == {row["path"] for row in rows} | directories
    for row in rows:
        assert ss(derived / row["path"]) == {key: value for key, value in row.items() if key not in ("path", "zip_external_mode")}
for name, before in protected.items():
    assert ss(pathlib.Path(name)) == before
receipt = dict(schema="historical-173-runtime-derived-execution-v1", status="verified_before_unlink",
               started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               candidates=[dict(path=str(path), sha256=sha(path), files=len(rows), bytes=candidate["selected_content_bytes"]) for _, rows, _, path, candidate in plans],
               protected_before=protected, free_bytes_before=shutil.disk_usage(B).free)
execution = OUT / "execution.json"
dump(execution, receipt)
for derived, rows, directories, path, candidate in plans:
    # Each unlink has the same frozen stat/hash checked again; changed files remain untouched.
    for row in rows:
        target = derived / row["path"]
        assert ss(target) == {key: value for key, value in row.items() if key not in ("path", "zip_external_mode")}
        target.unlink()
    for name in sorted(directories, key=lambda name: len(pathlib.PurePosixPath(name).parts), reverse=True):
        (derived / name).rmdir()
    derived.rmdir()
after = {name: ss(pathlib.Path(name)) for name in protected}
assert after == protected
receipt.update(status="only_six_verified_derived_extractions_removed", protected_after=after,
               all_protected_stat_and_bytes_unchanged=True,
               removed_files=sum(len(rows) for _, rows, _, _, _ in plans),
               removed_content_bytes=sum(candidate["selected_content_bytes"] for _, _, _, _, candidate in plans),
               free_bytes_after=shutil.disk_usage(B).free, finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
execution.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
print(json.dumps(dict(path=str(execution), bytes=execution.stat().st_size, sha256=sha(execution),
                     removed_files=receipt["removed_files"], removed_content_bytes=receipt["removed_content_bytes"],
                     free_bytes_after=receipt["free_bytes_after"])))
