from pathlib import Path
import json,hashlib,os,shutil,stat,datetime
BASE=Path('/workspace/scratch/bfccb8494ba0/pr-triage-primary-recovery')
OUT=BASE/'derived-copy-migration-round15'
RAM=Path('/dev/shm/pr-triage-derived-copies-round15')
assert not RAM.exists();RAM.mkdir()
IDS=['11604900056','11604870469']
def sha_file(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
 return h.hexdigest()
def meta(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha_file(p)}
def space(p):return dict(zip(['total','used','free'],shutil.disk_usage(p)))
def write(p,d):
 with p.open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
plans=[]
for aid in IDS:
 attempt=BASE/'raw-pr178-c8be5afa'/aid/'attempt01';receipt=json.loads((attempt/'transport-receipt.json').read_text());index=json.loads((attempt/'zip-members.json').read_text());src=attempt/'extracted';dst=RAM/'raw-pr178-c8be5afa'/aid/'attempt01'/'extracted'
 assert src.is_dir() and not src.is_symlink() and receipt['status']=='transport_verified'
 original=Path(receipt['original_zip_path']);assert original.stat().st_size==receipt['zip_bytes'] and sha_file(original)==receipt['zip_sha256']
 rows={r['normalized_name']:r for r in index if not r['is_directory']};files={str(p.relative_to(src)):p for p in src.rglob('*') if p.is_file()}
 assert files.keys()==rows.keys() and len(files)==receipt['members']
 verified=[]
 for name,p in sorted(files.items()):
  s=p.lstat();r=rows[name];assert stat.S_ISREG(s.st_mode) and s.st_size==r['bytes'] and sha_file(p)==r['sha256'],str(p)
  verified.append({'path':name,'bytes':s.st_size,'sha256':r['sha256'],'mode':stat.S_IMODE(s.st_mode),'mtime_ns':s.st_mtime_ns,'allocated_bytes':s.st_blocks*512})
 assert sum(r['bytes'] for r in verified)==receipt['uncompressed_bytes']
 assert not any(p.is_symlink() for p in src.rglob('*'))
 plans.append({'artifact_id':int(aid),'source':str(src),'destination':str(dst),'original_zip':meta(original),'intake_receipt':meta(attempt/'transport-receipt.json'),'zip_member_inventory':meta(attempt/'zip-members.json'),'official_run':receipt['run_id'],'source_commit':receipt['source'],'files':verified,'file_count':len(verified),'content_bytes':sum(r['bytes'] for r in verified),'source_allocated_bytes':sum(r['allocated_bytes'] for r in verified)})
need=sum(x['source_allocated_bytes'] for x in plans);assert shutil.disk_usage(RAM).free>need+256*1024*1024
before={'primary':space(BASE),'RAM':space(RAM)}
write(OUT/'migration-plan-and-content-manifest.json',{'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Only two owned extracted derivative copies; formal ZIPs, evidence/review selections, failure records and intake metadata stay in place. Original ZIP SHA and prior per-member digest inventory bind every copy.','plans':plans,'before_space':before,'peer_reader_coordination':'todo_audit confirmed no reader uses either extracted real directory; all own reports/selection unchanged.'})
progress=[]
for plan in plans:
 src=Path(plan['source']);dst=Path(plan['destination']);dst.parent.mkdir(parents=True,exist_ok=True)
 shutil.copytree(src,dst,copy_function=shutil.copy2,symlinks=False)
 expected={r['path']:r for r in plan['files']};actual={str(p.relative_to(dst)):p for p in dst.rglob('*') if p.is_file()}
 assert actual.keys()==expected.keys()
 for name,p in actual.items():
  r=expected[name];s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_size==r['bytes'] and stat.S_IMODE(s.st_mode)==r['mode'] and s.st_mtime_ns==r['mtime_ns'] and sha_file(p)==r['sha256']
 # Re-read original source before reclaim; abort on any concurrent modification.
 for r in plan['files']:
  p=src/r['path'];s=p.lstat();assert s.st_size==r['bytes'] and stat.S_IMODE(s.st_mode)==r['mode'] and s.st_mtime_ns==r['mtime_ns'] and sha_file(p)==r['sha256']
 linktemp=src.parent/'extracted.round15-verified-link';backup=src.parent/'extracted.round15-verified-backup';assert not linktemp.exists() and not backup.exists()
 linktemp.symlink_to(dst,target_is_directory=True);src.rename(backup);linktemp.rename(src)
 assert src.is_symlink() and src.resolve()==dst
 # Both verified complete copies are present before removing only the owned disk derivative.
 shutil.rmtree(backup)
 assert not backup.exists()
 for r in plan['files']:
  p=src/r['path'];s=p.stat();assert s.st_size==r['bytes'] and stat.S_IMODE(s.st_mode)==r['mode'] and sha_file(p)==r['sha256']
 progress.append({'artifact_id':plan['artifact_id'],'source':str(src),'destination':str(dst),'compatibility_symlink_verified':True,'all_content_SHA_and_modes_verified_before_copy_after_copy_before_reclaim_and_via_original_path':True,'file_count':plan['file_count'],'content_bytes':plan['content_bytes'],'reclaimed_allocated_file_bytes':plan['source_allocated_bytes'],'original_zip':plan['original_zip']})
 write(OUT/(str(plan['artifact_id'])+'-migration-receipt.json'),progress[-1]);print(json.dumps({'migrated':plan['artifact_id'],'files':plan['file_count'],'bytes':plan['content_bytes']}),flush=True)
for plan in plans:
 for key in ['original_zip','intake_receipt','zip_member_inventory']:
  m=plan[key];assert meta(Path(m['path']))==m
final={'schema_version':1,'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'completed_all_content_verified','scope':'Owned derivative relocation only. No source, workload, validator threshold, formal materialization path, original ZIP, intake/failure record or another owner file modified.','migrations':progress,'file_count':sum(x['file_count'] for x in progress),'content_bytes':sum(x['content_bytes'] for x in progress),'reclaimed_allocated_file_bytes':sum(x['reclaimed_allocated_file_bytes'] for x in progress),'before_space':before,'after_space':{'primary':space(BASE),'RAM':space(RAM)},'restoration':'Every file is reconstructible from its unchanged formal original ZIP using the retained original zip-members.json manifest. Current old paths remain readable via explicit compatibility symlinks; source maps identify content, not new execution. RAM is transient.','publication_provenance':{'lifecycle':'Original source-specific selection and raw publication at da00e2802bd9304de698b263be9924e2dc96242f; own lifecycle-publication-selection.json remains unchanged.','recovery':'Original GitHub published artifact/run and retained original ZIP; independent recovery/platform archived selection retained under todo-audit-round12/recovery-platform-Gc8. This migration does not claim every ELF was duplicated into Git.'}}
assert final['reclaimed_allocated_file_bytes']>=600*1024*1024
write(OUT/'migration-receipt.json',final)
print(json.dumps({'receipt':meta(OUT/'migration-receipt.json'),'manifest':meta(OUT/'migration-plan-and-content-manifest.json'),'file_count':final['file_count'],'content_bytes':final['content_bytes'],'reclaimed_allocated_file_bytes':final['reclaimed_allocated_file_bytes'],'after_space':final['after_space']}))
