from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import time
import yaml

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "candidate"
VIEW = ROOT / "validation-view"
OUT = ROOT / "actual-host-controls-attempt01"
OUT.mkdir()
inputs = {
    "scripts/p8_task_profile_capture.py": SOURCE / "scripts/p8_task_profile_capture.py",
    "scripts/tests/test_p8_task_profile_capture.py": SOURCE / "scripts/tests/test_p8_task_profile_capture.py",
    ".github/workflows/p8-task-profile.yml": SOURCE / ".github/workflows/p8-task-profile.yml",
    "scripts/p8_scale_diagnostic_capture.py": ROOT.parent / "round32-capture-context-admission/guard-view/scripts/p8_scale_diagnostic_capture.py",
}


def meta(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                git_blob=hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest())


before = {}
for relative, path in inputs.items():
    raw = path.read_bytes()
    before[relative] = meta(raw)
    target = VIEW / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as stream:
        stream.write(raw)
    if relative.endswith(".py"):
        ast.parse(raw.decode(), filename=relative)
workflow = yaml.safe_load(inputs[".github/workflows/p8-task-profile.yml"].read_text())
jobs = workflow["jobs"]
cells = jobs["measure"]["strategy"]["matrix"]["include"]
expected = {(profile, scale, "") for profile in (
    "no_op", "body", "api", "config", "batch_1", "batch_10", "batch_100", "batch_1000"
) for scale in (1000, 5000, 10000, 50000, 100000)}
expected |= {("fanout", 1000, fanout) for fanout in (1, 4, 16, 64, 128)}
assert len(cells) == 45 and len({x["cell"] for x in cells}) == 45
assert {(x["profile"], x["scale"], x["fanout"]) for x in cells} == expected
assert set(jobs) == {"build", "measure", "aggregate"} and jobs["measure"]["needs"] == ["build"]
assert jobs["measure"]["strategy"]["fail-fast"] is False
assert jobs["measure"]["strategy"]["max-parallel"] == 10
assert jobs["measure"]["timeout-minutes"] == 350
assert workflow["permissions"] == {"contents": "read"}
assert "p8-task-profile-run" in jobs["build"]["if"] and "p8-profile-run" not in jobs["build"]["if"]
assert jobs["aggregate"]["needs"] == ["build", "measure"]
assert jobs["aggregate"]["if"] == "always() && needs.build.result == 'success'"
steps = jobs["measure"]["steps"]
ids = {step["id"]: step for step in steps if "id" in step}
for index in range(20):
    current = f"{index:02d}"
    freeze, upload = ids[f"freeze_{current}"], ids[f"upload_{current}"]
    assert freeze["if"] == "always() && steps.launch.outcome == 'success'"
    assert f"--index {index}\n" in freeze["run"]
    assert steps.index(freeze) < steps.index(upload)
    if index:
        previous = f"{index - 1:02d}"
        assert steps.index(ids[f"upload_{previous}"]) < steps.index(freeze)
        assert freeze["env"]["PREVIOUS_ARTIFACT_ID"] == "$" + "{{ steps.upload_" + previous + ".outputs.artifact-id }}"
        assert freeze["env"]["PREVIOUS_ARTIFACT_DIGEST"] == "$" + "{{ steps.upload_" + previous + ".outputs.artifact-digest }}"
assert "--index 20\n" in ids["finish"]["run"]
assert ids["finish"]["env"]["PREVIOUS_ARTIFACT_ID"] == "$" + "{{ steps.upload_19.outputs.artifact-id }}"
full_upload = [s for s in steps if s.get("uses") == "actions/upload-artifact@v4"
               and s["with"]["name"].startswith("p8-task-shard-")]
assert len(full_upload) == 1 and full_upload[0]["if"] == "always()"
assert full_upload[0]["with"]["path"].endswith("/shard")
aggregate_patterns = [s["with"]["pattern"] for s in jobs["aggregate"]["steps"]
                      if s.get("uses") == "actions/download-artifact@v4" and "pattern" in s["with"]]
assert len(aggregate_patterns) == 1 and aggregate_patterns[0].startswith("p8-task-shard-*")
assert "progress" not in aggregate_patterns[0]
assert "task_descriptive_scope_is_explicit_n1_without_weakening_old_n30 -- --exact" in jobs["build"]["steps"][-2]["run"]
shell_records = []
for job, definition in jobs.items():
    for index, step in enumerate(definition["steps"]):
        if "run" not in step:
            continue
        script = step["run"]
        parsed = subprocess.run(["bash", "-n"], input=script.encode(), capture_output=True, check=False)
        shell_records.append(dict(job=job, step=index, exit_code=parsed.returncode,
                                  stdout=meta(parsed.stdout), stderr=meta(parsed.stderr)))
        assert parsed.returncode == 0, (job, index, parsed.stderr.decode())
        match = re.search(r"python3 - <<'PY'\n(.*?)\nPY\n", script, re.S)
        if match:
            ast.parse(match.group(1), filename=f"{job}-inline-python")
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
command = ["python3", "-B", "-m", "unittest", "discover", "-s", "scripts/tests",
           "-p", "test_p8_task_profile_capture.py", "-v"]
environment = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
test = subprocess.run(command, cwd=VIEW, env=environment, capture_output=True, check=False, timeout=30)
(OUT / "capture-controls.stdout").write_bytes(test.stdout)
(OUT / "capture-controls.stderr").write_bytes(test.stderr)
after = {relative: meta(path.read_bytes()) for relative, path in inputs.items()}
assert after == before
report = dict(
    scope="Actual three new harmless capture controls plus exact workflow/AST/bash syntax checks; no Rust, native workload or study",
    started_at=started, finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    wall_seconds=time.monotonic() - clock, command=command, cwd=str(VIEW),
    exit_code=test.returncode, stdout=meta(test.stdout), stderr=meta(test.stderr),
    yaml_version=yaml.__version__, cells=45, periodic_checkpoints=20, final_index=20,
    independent_measure_matrix=True, maximum_parallel=10, complete_artifact_upload="always",
    aggregate_excludes_diagnostic_prefixes=True, shell_syntax=shell_records,
    exact_inputs_before=before, exact_inputs_after=after, inputs_unchanged=True,
    rust_compilation="not_run", rustfmt="not_run", clippy="not_run", native_measurements="not_run",
)
(OUT / "actual-controls-and-workflow-review.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({key: report[key] for key in (
    "exit_code", "cells", "periodic_checkpoints", "inputs_unchanged", "scope"
)}))
if test.returncode:
    print(test.stderr.decode(errors="replace"))
raise SystemExit(test.returncode)
