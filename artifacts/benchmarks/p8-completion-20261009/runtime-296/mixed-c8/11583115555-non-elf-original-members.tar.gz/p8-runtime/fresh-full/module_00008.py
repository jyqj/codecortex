def stable_00008():
    return 8
