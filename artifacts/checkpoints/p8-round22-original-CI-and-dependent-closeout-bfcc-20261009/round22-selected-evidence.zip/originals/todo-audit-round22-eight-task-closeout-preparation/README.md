# 原十项待执行结项输入：本轮不改状态

当前原账本仍为 **192 项、163 done、29 剩余**。本次只复用已经接受的组件及原定义，未重新运行产品、原 validator、测试或测量。八项自身组件没有发现新的未满足原门；它们仍须等待原硬依赖，不能提前改为 done。

| 原任务 | 原自身要求及已接受组件 | 当前未满足的直接硬依赖 |
|---|---|---|
| P8-007 多并发与混合负载 | 原 C1/4/8/16 mixed read/build/backfill、offered/queue、timeout/尾部与不饥饿：Gc8 四格各 900 操作及三 seed fake backfill 已接受；独立 G2=`4d18dcdb…` 四格各 900 的真实 DB acquisition 补项也已完整接受。默认与观测 feature 的分布不合并。 | P8-006 |
| P8-008 冷建/重开/热查分层 | Gc8 lifecycle 30 cold、400 reopen、400 uncached、400 cache-hit，1230 样本、431 会话；全样本/N/分布/CI 已接受。OS cache 未清及冷样本尾部 CI 上界 null 保持，不声称稳定 p99。 | P8-007 |
| P8-009 内存/磁盘/费用总账 | 既有 Gc8 mixed/lifecycle/backfill/soak 的 client/server/process-tree、artifact/FTS、reported/estimated 与 unavailable 归属已接受。005/006 真正到来后追加其自身账目，未知不填零、重叠不相加。 | P8-008 |
| P8-010 长时 soak 与连续修改 | 原 Gc8 3600.054553094 秒、3601 操作（1201 build/2400 compound read）、真实修改/删除/切分支/压实/cache 复用及终点完整 15 表一致、原增长判据已接受。 | P8-009 |
| P8-011 端到端故障与恢复 | 原 Gc8 kill/网络/缓存损坏/数据库忙/换库对应的故障组件、原 raw 与恢复/费用边界已接受。local 子报告的 3 passed/4 not_run 不改写；独立 active/生产控制按各自范围引用。 | P8-007、P8-010；P7-020 已 done |
| P8-012 MSRV 与平台冷构建 | Gc8 Linux/macOS × Rust1.95/stable × default/semantic 原 8 格全新 target、工具链/SDK/产物与最终原 collector 已接受。不是 G8 或最新 main 的八平台实测声明。 | P8-011 |
| P8-013 红线与非零退出 | Gc8 原 6 个 Rust 故障合同与保留 CLI 七例退出 `[1,1,1,1,2,2,2]` 已接受；quality/performance/lock、inconclusive、invalid 与原件保留边界明确。 | P8-012 |
| P8-016 数据库/配置/包回滚 | 原 Gc8/schema25 与真实历史 277f/schema24 的 25→24→25/备份恢复、缓存隔离及语义关闭回退已接受；用户源码/配置保留。历史 dev binary 不冒称发行 tag。 | P8-012、P8-013；P7-020 已 done |

完整原 `steps`、`acceptance`、依赖及未来字段在 `eight-task-pending-closeout-fields.json`。持久证据位置、原 source/run/artifact 和范围在 `reused-accepted-evidence-index.json`。主要已有归档为：

- Gc8 故障恢复/平台及原 CI/gates：`56cf243df673a0745644ff17351353c8e416d349` 下 `round12-primary-platform-source-and-concurrency/` 的三个明确 ZIP。原官方 commit 文件清单已复用，未重新下载 ZIP。
- Gc8 最后一格及原 collector：`16ce2a5623b51b6dc4ae23df4912f939791fe7d8` 下 `round12-primary-platform-complete-and-C1/`。
- Gc8 完整 runtime 汇总与 soak：`b66afc3a4967d7047b038fa8e6f9e20118018b5c` 下 `round13-primary-soak-c8be5afa/soak-review-evidence.zip`，精确成员和 blob 已列入索引。
- G2 独立四 C acquisition：`3548736f0dd42304e6b5f06f40007a756df6a361` 下 `round18-selected-source-and-four-C-checkpoint/round18-selected-source-and-four-C-checkpoint.zip`；索引使用外层真实 ZIP 与完整 member，不伪造直接叶路径。

原账本还已有其他审查者接受的 G275 源组件及精确 Git 链接。它们作为补充既有证据保留；本次没有把这些第三方既有接受改称为本代理新做的全量独审。任何没有现成证据的完整 checkout 或 archive-internal member 字段保留 null；已确认的不可变 ZIP/目录链接足以定位，并不因此新增测量门。

原十项的可执行更新顺序是 `005 → 006 → 007 → 008 → 009 → 010 → 011 → 012 → 013 → 016`，但每一步都要满足自己的真实验收与原依赖。005 的独立 cold 研究为 source044 / run37954851017；006 的连续历史研究为 G8=4fe927 / run37962416564。**不再沿用旧决策里“005 与 006 必须来自同一个研究”的过窄表述**。两套研究各自保留固定源、二进制、driver 和完整样本身份，不能拼接旧失败 cohort。005 先完整通过时可单独从 29 降到 28，无需等 006；只有十项各自真实接受并按依赖完成，才会达到 173 done / 19 剩余。

`ten-task-dependent-update-input.json` 是按原 ID 选取的待执行更新输入，`apply_now=false`。005/006 的旧 pending 模板按原字节复制，历史 null 未后见改写。新增 G8 build addendum 只引用 root 已接受并发布的原构建/源保全，明确 0 accepted shards/samples，不填 full-scale passed。

实际写入时必须先读取 fresh main，按 ID 核原定义/依赖并保留所有外部 notes/evidence；填入真实接受时间、原结果与持久引用后，才追加说明并更新符合条件的状态。005 仅关闭其原完整五容量子门，保留 `strict_paired_causal_performance=not_established`、`whole_tree_memory_peak=unknown` 等限制。之后运行原 `code_index_plan.py --write` 和无参检查生成四个既有视图。本次未执行这些写入命令。

不新增本机 G1 C8/C16、四个一小时、全 backend span、SQLite busy 分解、连续全树峰值、最新 head 全组件重跑、第二套重复规模研究、live/holdout 或发行 tag 条件。不同独立组件可以各用真实来源；这不等于当前 G8、main 或整个 release 已获统一性能认证。
