#!/usr/bin/env python3
"""Finite design probe, not the Rust benchmark or a P8 acceptance test."""
import hashlib
import json
import platform
import re
import sqlite3
import statistics
import time
from pathlib import Path

ROOT = Path('/workspace/scratch/a217aaae3bde')
OUT = Path(__file__).parent
SCHEMA = ROOT / 'p8-lock-observation-G2-recovered-1419/crates/cc-db/src/sql/index_v1.sql'
SOURCE_PATHS = [
    SCHEMA,
    ROOT / 'C8-resume-diagnostic/M6-source/crates/cc-db/src/resolution_dependency_store.rs',
    ROOT / 'C8-resume-diagnostic/M6-source/crates/cc-db/src/public_surface_store.rs',
    ROOT / 'C8-resume-diagnostic/candidate-M7/crates/cc-db/src/resolution_dependency_store.rs',
    ROOT / 'C8-resume-diagnostic/candidate-M7/crates/cc-db/src/public_surface_store.rs',
]

def record(p):
    b = p.read_bytes()
    return dict(path=str(p.relative_to(ROOT)), bytes=len(b), sha256=hashlib.sha256(b).hexdigest(),
                git_blob=hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest())

before = [record(p) for p in SOURCE_PATHS]
schema = SCHEMA.read_text()
ddl = []
for table in ['resolution_dependencies', 'imports', 'symbol_refs', 'call_edges']:
    ddl.append(re.search(r'CREATE TABLE IF NOT EXISTS ' + table + r' \(.*?\n\);', schema, re.S).group())
    ddl.extend(re.findall(r'CREATE INDEX IF NOT EXISTS [^;]+ ON ' + table + r'\([^;]+;', schema))

def fixture(family, keys_n, dense=False):
    db = sqlite3.connect(':memory:', cached_statements=128)
    db.executescript('\n'.join(ddl))
    # Canonical table/index DDL, only queried tables; foreign keys OFF in this
    # design database, so no unqueried files-table population is needed.
    keys = [f'key-{i:05d}' for i in range(keys_n)]
    paths = [f'src/f{i:05d}.py' for i in range(600 if dense else keys_n)]
    if family == 'resolution':
        rows = [(p, 'name', keys[0] if dense else k) for p, k in zip(paths, [keys[0]]*len(paths) if dense else keys)]
        db.executemany('INSERT INTO resolution_dependencies VALUES(?,?,?)', rows)
    else:
        db.executemany('INSERT INTO imports(file_path,import_string,resolved_path) VALUES(?,?,?)',
                       [(p,k,k) for p,k in zip(paths,keys)])
        db.executemany('INSERT INTO symbol_refs(ref_id,file_path,symbol_name,ref_kind,line,target_file_path) VALUES(?,?,?,?,?,?)',
                       [(str(i),p,'n','read',1,k) for i,(p,k) in enumerate(zip(paths,keys))])
        db.executemany('INSERT INTO call_edges(edge_id,file_path,callee_symbol,line,target_file_path) VALUES(?,?,?,?,?)',
                       [(str(i),p,'n',1,k) for i,(p,k) in enumerate(zip(paths,keys))])
    excluded = paths[:580] if dense else [f'retired/f{i:05d}.py' for i in range(10000)]
    db.commit()
    return db, keys, excluded, 10 if dense else 2

def query_plan(family, keys, excluded, cap, variant):
    js = json.dumps(sorted(set(excluded)), separators=(',', ':'))
    new = variant == 'candidate'
    size = (197 if new else 198) if family == 'resolution' else (198 if new else 199)
    limit = cap if new else cap + len(set(excluded))
    plan = []
    for offset in range(0,len(keys),size):
        batch = keys[offset:offset+size]
        if family == 'resolution':
            placeholders = ','.join(f'?{i}' for i in range(2,len(batch)+2))
            if new:
                sql = f'SELECT DISTINCT file_path FROM resolution_dependencies WHERE kind=?1 AND key IN ({placeholders}) AND (file_path IS NULL OR file_path COLLATE BINARY NOT IN (SELECT value FROM json_each(?{len(batch)+2}))) ORDER BY file_path LIMIT ?{len(batch)+3}'
            else:
                sql = f'SELECT DISTINCT file_path FROM resolution_dependencies WHERE kind=?1 AND key IN ({placeholders}) ORDER BY file_path LIMIT ?{len(batch)+2}'
            args = ['name',*batch] + ([js] if new else []) + [limit]
            plan.append((sql,args))
        else:
            for table,target in [('imports','resolved_path'),('symbol_refs','target_file_path'),('call_edges','target_file_path')]:
                nonlocal_filter = '' if table == 'imports' else f' AND file_path != {target}'
                exclusion = ' AND (file_path IS NULL OR file_path COLLATE BINARY NOT IN (SELECT value FROM json_each(?)))' if new else ''
                sql = f'SELECT DISTINCT file_path FROM {table} WHERE {target} IN ({",".join("?" for _ in batch)}){nonlocal_filter}{exclusion} ORDER BY file_path LIMIT ?'
                plan.append((sql,[*batch]+([js] if new else [])+[limit]))
    return plan

def execute(db, plan, excluded, cap):
    result = set()
    fetched = 0
    query_ns = 0
    start = time.perf_counter_ns()
    for sql,args in plan:
        t0 = time.perf_counter_ns()
        rows = db.execute(sql,args).fetchall()
        query_ns += time.perf_counter_ns()-t0
        fetched += len(rows)
        result.update(p for (p,) in rows if p not in excluded)
        result = set(sorted(result)[:cap])
    return dict(output=sorted(result), returned_rows=fetched, statements=len(plan),
                query_fetch_ns=query_ns, python_boundary_ns=time.perf_counter_ns()-start)

reports = []
for name,family,keycount,dense in [
    ('dense_prefix_600_rows_580_excluded','resolution',1,True),
    ('sparse_two_keys_10000_unrelated_excluded','resolution',2,False),
    ('sparse_400_keys_three_batches_10000_unrelated_excluded','resolution',400,False),
    ('surface_400_roots_three_tables_10000_unrelated_excluded','surface',400,False),
]:
    db,keys,excluded,cap = fixture(family,keycount,dense)
    excluded_set = set(excluded)
    plans = {v:query_plan(family,keys,excluded,cap,v) for v in ['old','candidate']}
    samples = {'old':[], 'candidate':[]}
    for variant in samples: execute(db,plans[variant],excluded_set,cap)
    # Warm cached statements, same database. Twenty alternating observations,
    # no progress callback in wall timing. Python transport/filter is separately
    # reported and is not the Rust boundary.
    for repeat in range(20):
        for variant in (['old','candidate'] if repeat%2==0 else ['candidate','old']):
            samples[variant].append(execute(db,plans[variant],excluded_set,cap))
    expected = samples['old'][0]['output']
    assert all(s['output']==expected for series in samples.values() for s in series)
    details = {}
    for variant,series in samples.items():
        ticks = [0]
        def progress():
            ticks[0] += 1
            return 0
        db.set_progress_handler(progress,1)
        counted = execute(db,plans[variant],excluded_set,cap)
        db.set_progress_handler(None,0)
        assert counted['output']==expected
        details[variant] = dict(statements=counted['statements'], returned_rows=counted['returned_rows'],
            vm_progress_callbacks=ticks[0],
            query_fetch_median_ns=statistics.median(s['query_fetch_ns'] for s in series),
            boundary_median_ns=statistics.median(s['python_boundary_ns'] for s in series),
            observations=series,
            explain_query_plan=[list(row) for row in db.execute('EXPLAIN QUERY PLAN '+plans[variant][0][0],plans[variant][0][1])],
            explain=[list(row) for row in db.execute('EXPLAIN '+plans[variant][0][0],plans[variant][0][1])],
            sql=[sql for sql,_ in plans[variant]])
    reports.append(dict(name=name, family=family,keys=keycount,excluded_count=len(excluded),
        excluded_json_bytes=len(json.dumps(sorted(set(excluded)),separators=(',',':')).encode()),
        cap=cap, output=expected, output_parity=True, variants=details,
        candidate_to_old_query_wall_ratio=details['candidate']['query_fetch_median_ns']/details['old']['query_fetch_median_ns'],
        candidate_to_old_vm_ratio=details['candidate']['vm_progress_callbacks']/details['old']['vm_progress_callbacks']))
    db.close()

after = [record(p) for p in SOURCE_PATHS]
assert before == after
report = dict(schema='sql-exclusion-finite-design-probe-v1', python=platform.python_version(),
    sqlite=sqlite3.sqlite_version, source_before=before, source_after=after,
    scope='Four constructed in-memory query scenarios; no Rust, native workload, P8 acceptance or whole-build performance measurement.',
    limits=dict(cases=4,alternating_repetitions=20,max_excluded=10000,max_keys=400,
                wall_callbacks_disabled=True,vm_callbacks_separate=True,ddl_only_queried_tables=True,
                source_mutation=False), ddl=ddl, cases=reports)
out=OUT/'probe-result.json'
with out.open('x') as f: json.dump(report,f,indent=2,sort_keys=True); f.write('\n')
for r in reports:
    print(r['name'],json.dumps({v:{k:d[k] for k in ['statements','returned_rows','vm_progress_callbacks','query_fetch_median_ns','boundary_median_ns']} for v,d in r['variants'].items()}), 'ratio',r['candidate_to_old_query_wall_ratio'])
print('REPORT',len(out.read_bytes()),hashlib.sha256(out.read_bytes()).hexdigest())
