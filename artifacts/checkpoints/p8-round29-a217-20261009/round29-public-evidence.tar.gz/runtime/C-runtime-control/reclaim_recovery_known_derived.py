"""Root-authorized narrower cleanup; preserve the unexplained-mode file verbatim."""
import datetime,hashlib,json,pathlib,shutil,stat,zipfile
B=pathlib.Path(__file__).resolve().parent;A=B/'artifacts/11611995300';D=A/'extracted';Z=A/'11611995300.zip';EX='p8-full-recovery/product-previous/codecortex';C=A/'derived-reclamation-candidate-v2.json';E=A/'derived-reclamation-execution-v2.json'
assert not C.exists() and not E.exists() and D.is_dir() and not D.is_symlink()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def ss(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink()
 return dict(bytes=s.st_size,sha256=sha(p),mode=stat.S_IMODE(s.st_mode),inode=s.st_ino,device=s.st_dev,nlink=s.st_nlink,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,allocated_bytes=s.st_blocks*512)
original_sha='cedbfc80ae8df8ce29c4c8478535e2af855cda143a5dfa6454aeebeb4ea808e4';assert sha(Z)==original_sha
pre=json.loads((A/'preflight-and-extraction.json').read_text());pre_files={x['path']:x for x in pre['extraction']['extracted_files']};assert len(pre_files)==499
entries={p.relative_to(D).as_posix():p for p in D.rglob('*')};expected_dirs={q.as_posix() for n in pre_files for q in pathlib.PurePosixPath(n).parents if str(q)!='.'};assert set(entries)==set(pre_files)|expected_dirs
for n in expected_dirs:assert entries[n].is_dir() and not entries[n].is_symlink()
rows=[];excluded=None
with zipfile.ZipFile(Z) as z:
 assert {i.filename for i in z.infolist() if not i.is_dir()}==set(pre_files)
 for info in z.infolist():
  if info.is_dir():continue
  n=info.filename;p=D/n;s=ss(p)
  with z.open(info) as f:zh=hashlib.file_digest(f,'sha256').hexdigest()
  assert s['bytes']==info.file_size==pre_files[n]['bytes'] and s['sha256']==zh==pre_files[n]['sha256'] and s['nlink']==1
  if n==EX:
   assert s['mode']==0o644
   excluded=dict(path=n,**s,reason='Unexplained post-extraction mode0644 versus preflight0444; bytes match original ZIP. Preserve file and ancestor directories without chmod.');continue
  assert s['mode']==0o444,(n,'unexpected mode')
  rows.append(dict(path=n,zip_external_mode=(info.external_attr>>16)&65535,**s))
assert len(rows)==498 and excluded and sha(Z)==original_sha
protected_paths=[p for p in A.iterdir() if p.is_file()]+list((B/'accepted/recovery-11611995300-3ffcefc3-independent').glob('*'))+list((B/'recovery-helpers-C3ff-v1').glob('*'))
protected={str(p):ss(p) for p in protected_paths};protected[str(D/EX)]=ss(D/EX)
value=dict(schema='C-recovery-narrow-derived-candidate-v2',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),directory=str(D),original_zip=dict(path=str(Z),bytes=Z.stat().st_size,sha256=original_sha),previous_stopped_precheck=dict(path=str(A/'derived-reclamation-v1-precheck-failure.json'),sha256=sha(A/'derived-reclamation-v1-precheck-failure.json')),files=rows,selected_file_count=498,selected_content_bytes=sum(x['bytes'] for x in rows),selected_allocated_file_bytes=sum(x['allocated_bytes'] for x in rows),excluded_files=[excluded],protected_before=protected,exact_499_original_paths_and_all_bytes_match=True,stat_scope='Original preflight retained every byte/hash and set0444. For the498 matching files, current inode/nlink/times are captured here and are rechecked immediately before unlink; no claim that original preflight recorded inodes.',activity='All task-owned recovery readers/SQLite connections ended; no current/future dependency on these498 derived files. No system-wide PID claim.',authorization='Root explicitly authorized this498-file subset only if immediate checks hold; preserve unexplained-mode file, originals and all protected records.',scope='Derived storage recovery only; not a product/original acceptance failure.')
C.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n');protected[str(C)]=ss(C)
# Verify the exact current set and every candidate/protected stat/hash again before any unlink.
assert set(p.relative_to(D).as_posix() for p in D.rglob('*'))==set(entries)
for x in rows:assert ss(D/x['path'])=={k:v for k,v in x.items() if k not in ('path','zip_external_mode')}
for name,s in protected.items():assert ss(pathlib.Path(name))==s
receipt=dict(schema='C-recovery-narrow-derived-execution-v2',started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidate=str(C),candidate_sha256=sha(C),selected_files=498,selected_content_bytes=value['selected_content_bytes'],preserved_exception=excluded,protected_before=protected,free_bytes_before=shutil.disk_usage(A).free,status='verified_before_unlink')
E.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
for x in rows:(D/x['path']).unlink()
removed_dirs=[]
for p in sorted((p for p in D.rglob('*') if p.is_dir()),key=lambda p:len(p.parts),reverse=True):
 if not any(p.iterdir()):p.rmdir();removed_dirs.append(str(p))
remaining={p.relative_to(D).as_posix() for p in D.rglob('*')};want={EX}|{p.as_posix() for p in pathlib.PurePosixPath(EX).parents if str(p)!='.'};assert remaining==want
protected_after={name:ss(pathlib.Path(name)) for name in protected};assert protected_after==protected
receipt.update(status='only_498_verified_derived_files_removed',protected_after=protected_after,all_protected_stat_and_bytes_unchanged=True,remaining_derived_paths=sorted(remaining),empty_directories_removed=removed_dirs,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_bytes_after=shutil.disk_usage(A).free)
E.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
for p in (C,E):print(json.dumps(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))))
print(json.dumps(dict(deleted_files=498,deleted_bytes=value['selected_content_bytes'],preserved_bytes=excluded['bytes'],preserved_mode=oct(excluded['mode']),free_bytes_after=receipt['free_bytes_after'])))
