def stable_00203():
    return 203
