#!/usr/bin/env python3
import collections, datetime, hashlib, importlib.util, json, pathlib, sys

OUT=pathlib.Path('/dev/shm/p8-D0-study-admission-first-review')
STORE=pathlib.Path('/workspace/scratch/2eaa00d0f93a/p8-D0-full-study-reception')
ROOT=pathlib.Path('/workspace/scratch/2eaa00d0f93a/p8-D0-exact-source')
SOURCE='d0cb69c601e530dcef738af0c2dffb8d3b8bcf28'
CONTROLLER='ca72a2dde363e35203f7b3cb30ed00729d460fd7'
RUN=37854240827
REG_SHA='4a56e31e9838f0db1d83a3efd4a10d0a51f8b443dbce4413e68253881740eebc'
SCRIPT_SHA='a65e819d3a00f8032e04d54c8da881a6efb160671f14252e96258f57813df189'
spec=importlib.util.spec_from_file_location('original_transport','/workspace/scratch/2eaa00d0f93a/p8-scale-sequential-receiver/receive.py')
transport=importlib.util.module_from_spec(spec);spec.loader.exec_module(transport)
assert transport.digest(spec.origin)=='a05743c0bdd15df5337287ca6861c6e88317623ebf53855d10dd83642a88528d'
sys.path.insert(0,str(ROOT/'scripts'));import p8_scale_matrix as matrix
source_before=matrix.source_snapshot(ROOT);driver_before=matrix.driver_snapshot(ROOT)
assert source_before['source_commit']==SOURCE
registry=transport.read_json('/dev/shm/p8-D0-full-study-controller-root/registration.json')
api=transport.read_json(OUT/'api-artifacts-page1.json');assert api['total_count']==len(api['artifacts'])==3
artifact_map={x['id']:x for x in api['artifacts']}
jobs1=transport.read_json(OUT/'api-jobs-page1.json');jobs2=transport.read_json(OUT/'api-jobs-page2.json')
assert jobs1['total_count']==jobs2['total_count']==151
jobs=jobs1['jobs']+jobs2['jobs'];assert len(jobs)==len({j['id'] for j in jobs})==151
job=next(j for j in jobs if j['id']==113574473097)
assert job['name']=='Receive and replay the fixed original D0 prerequisites' and job['run_id']==RUN and job['head_sha']==CONTROLLER and job['status']=='completed' and job['conclusion']=='success'
for name in ['Verify the completed upstream run and fixed original artifacts','Replay unchanged original validators at the D0 checkout']:
    assert next(s for s in job['steps'] if s['name']==name)['conclusion']=='success'
own=STORE/'first-admission-expanded';own.mkdir(exist_ok=False);expansion=transport.Expansions(own);expanded={};members={}
for id,kind in [(11584291128,'admission'),(11584016580,'build')]:
    item=artifact_map[id];assert item['workflow_run']['id']==RUN and item['workflow_run']['head_sha']==CONTROLLER and item['expired'] is False
    archive=STORE/'archives'/f'{id}.zip';members[id]=transport.zip_members(archive,item)
    expanded[id]=expansion.extract(f'p8-scale-{kind}-{RUN}',archive,item,members[id])
admission=expanded[11584291128];build=expanded[11584016580]
old_build=pathlib.Path('/workspace/scratch/2eaa00d0f93a/p8-D0-build-11582571291/original')
assert members[11584016580]['files']==matrix.inventory(old_build)
assert len(members[11584016580]['files'])==6
meta=transport.read_json(admission/'p8-d0-admission/metadata-receipt.json')
verified=transport.read_json(admission/'p8-d0-admission/verify-receipt.json')
for record,phase,status in [(meta,'metadata','metadata_passed_original_successful_upstream'),(verified,'verify','original_prerequisites_passed_for_new_registered_study')]:
    assert record['phase']==phase and record['status']=='passed' and record['source']==SOURCE and record['registration_sha256']==REG_SHA and record['controller_sha256']==SCRIPT_SHA
    assert record['result']['status']==status and record['result']['new_measurements_performed'] is False
    assert datetime.datetime.fromisoformat(record['started_utc'])<=datetime.datetime.fromisoformat(record['finished_utc'])
assert meta['result']['controller_source']==CONTROLLER and meta['result']['controller_run_id']==RUN and meta['result']['measured_source']==SOURCE and meta['result']['upstream_run']==registry['upstream_run']
assert verified['result']['source']==SOURCE and verified['result']['original_validate_build_passed'] is True and verified['result']['original_controls']==12 and verified['result']['new_primary_cells']==150
for folder in ['p8-d0-controller','p8-d0-admission']:
    assert transport.digest(admission/folder/'registration.json')==REG_SHA and transport.digest(admission/folder/'admit.py')==SCRIPT_SHA
    controller_inputs=transport.read_json(admission/folder/'controller-inputs.json')
    assert controller_inputs=={'source_commit':CONTROLLER,'registration_sha256':REG_SHA,'script_sha256':SCRIPT_SHA,'measured_source':SOURCE,'upstream_run':registry['upstream_run'],'new_primary_measurements_started':False}
upstream_run=transport.read_json(admission/'p8-d0-admission/upstream-run.json')
assert upstream_run['id']==registry['upstream_run'] and upstream_run['head_sha']==SOURCE and upstream_run['run_attempt']==1 and upstream_run['status']=='completed' and upstream_run['conclusion']=='success'
upstream_jobs=transport.read_json(admission/'p8-d0-admission/upstream-jobs.json')
assert upstream_jobs['total_count']==len(upstream_jobs['jobs'])==3
assert {x['id'] for x in upstream_jobs['jobs']}=={x['id'] for x in registry['upstream_jobs']}
assert all(x['head_sha']==SOURCE and x['status']=='completed' and x['conclusion']=='success' for x in upstream_jobs['jobs'])
upstream_artifacts=transport.read_json(admission/'p8-d0-admission/upstream-artifacts.json')
assert upstream_artifacts['total_count']==len(upstream_artifacts['artifacts'])==6
assert [{'id':a['id'],'name':a['name'],'bytes':a['size_in_bytes'],'sha256':a['digest'][7:]} for a in sorted(upstream_artifacts['artifacts'],key=lambda a:a['id'])]==registry['upstream_artifacts']
original_roots={11581509438:pathlib.Path('/dev/shm/p8-d0-controls-reception/original')}
original_roots.update({id:pathlib.Path('/dev/shm/p8-engineering-shard-reception')/str(id) for id in [11582252490,11582323631,11582922326,11583016525]})
for item in registry['upstream_artifacts']:
    if item['id']==11582571291:continue
    folder=admission/'p8-d0-upstream'/item['name']
    assert matrix.inventory(folder)==matrix.inventory(original_roots[item['id']])
control=admission/'p8-d0-upstream'/registry['controls']['artifact_name'];control_receipt=transport.read_json(control/'receipt.json')
assert transport.digest(control/'receipt.json')==registry['controls']['receipt_sha256'] and control_receipt['files']==matrix.inventory(control,('receipt.json',))
assert control_receipt['commands']==registry['controls']['commands']==[r['argv'] for r in control_receipt['results']]
assert len(control_receipt['results'])==12 and all(r['exit_code']==0 for r in control_receipt['results']) and control_receipt['not_run_command_indices']==[]
(build/'p8-scale').chmod(0o755)
built,binary=matrix.validate_build(build,ROOT);build_sha=transport.digest(build/'build.json')
assert build_sha==registry['build']['receipt_sha256']
diagnostics=[]
for item in registry['diagnostics']:
    raw=admission/'p8-d0-upstream'/item['artifact_name'];assert transport.digest(raw/'shard.json')==item['receipt_sha256']
    validated=matrix.validate_shard(raw,built,binary,build_sha)
    assert validated['plan']==matrix.registered_plan(item['scale'],0,30,30,12648430,18000000,matrix.CAPACITY_PROFILE)
    diagnostics.append({'scale':item['scale'],'receipt_sha256':item['receipt_sha256'],'original_full_raw_validation_passed':True})
assert diagnostics==verified['result']['diagnostics']
for id in [11584291128,11584016580]:
    expansion.prove(expanded[id],STORE/'archives'/f'{id}.zip',artifact_map[id],members[id])
assert matrix.source_snapshot(ROOT)==source_before and matrix.driver_snapshot(ROOT)==driver_before
measurements=[j for j in jobs if j['name'].startswith('measure (')]
assert len(measurements)==150
statuses=collections.Counter((j['status'],j['conclusion']) for j in measurements)
report={'schema':'p8-D0-study-first-actual-admission-independent-review-v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'accepted_scoped_actual_first_admission_and_unchanged_original_build','run_id':RUN,'attempt':1,'controller_commit':CONTROLLER,'measured_source':SOURCE,
 'admission_job_id':job['id'],'admission_job_success':True,'actual_metadata_and_verify_receipts_passed':True,
 'all_controller_and_registration_copies_match_published_bytes':True,'registration_sha256':REG_SHA,
 'received_build_six_member_bytes_exactly_equal_upstream_original11582571291':True,
 'new_build_ZIP_sha256':artifact_map[11584016580]['digest'][7:],'upstream_build_ZIP_sha256':'42d0c06359eaf0f0dd68e7683d491c662778cd64e9a621a2b501da1ed7f68d92',
 'ZIP_container_digest_difference_not_treated_as_member_change':True,
 'all_original_prerequisite_receipts_logs_and_raw_byte_equal_previously_accepted_upstream':True,
 'original_validate_build_and_both_validate_shard_executed_again_on_received_copies':True,'diagnostics':diagnostics,
 'archive_member_maps':{str(id):members[id] for id in members},'archives_persist':True,'temporary_expansions_retained_under_owned_directory':str(own),
 'source_driver_archives_and_received_members_unchanged_after_validation':True,
 'two_page_jobs_complete':151,'new_measurement_jobs':150,'observed_measurement_status_counts':[{'status':key[0],'conclusion':key[1],'count':count} for key,count in sorted(statuses.items())],
 'new_measurement_completion_not_inferred_from_admission':True,'new_workload_or_Cargo_launched_here':False,'local_native_scope':'Original --hash-file only',
 'TODO_closed':0,'TODO_remaining':29}
(OUT/'review.json').write_bytes(matrix.json_bytes(report))
print(json.dumps({'status':report['status'],'review_sha256':transport.digest(OUT/'review.json'),'members':sum(len(x['files']) for x in members.values()),'measurement_job_counts':report['observed_measurement_status_counts']}))
