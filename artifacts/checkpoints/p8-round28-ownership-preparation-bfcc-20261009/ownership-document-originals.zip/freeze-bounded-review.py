import difflib
import hashlib
import json
import pathlib
import re

ROOT = pathlib.Path(__file__).resolve().parent
WORKSPACE = ROOT.parent
MAIN = "51138c236cf2ed47858e2306f9c7bfd3600aaef9"
TREE = "24df8be11955fda1f2e320de483e9eb4ddd1ffb3"

def identity(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}

def write(name, obj):
    (ROOT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")

official = {}
for name in ("official-initial-sources.json", "official-targeted-owners.json", "official-compatibility-sources.json"):
    official.update(json.loads((ROOT / name).read_text()))
official["docs/roadmap/code-index-v2/P8-COMPAT.md"] = json.loads((ROOT / "official-P8-COMPAT.json").read_text())
official["crates/cc-eval/src/benchmark/metrics.rs"] = json.loads((ROOT / "official-metrics.json").read_text())
source_rows = []
unavailable = []
for path, response in official.items():
    structured = response.get("structuredContent", {})
    if "sha" not in structured or "content" not in structured:
        unavailable.append({"path": path, "error": response})
        continue
    raw = structured["content"].encode()
    assert (ROOT / "source" / path).read_bytes() == raw
    assert identity(raw)["git_blob"] == structured["sha"]
    source_rows.append({"path": path, "source_commit": MAIN, **identity(raw)})
write("bounded-official-source-manifest.json", {"source": MAIN, "tree": TREE, "files": source_rows, "unavailable_exact_path_attempts": unavailable})

task_file = WORKSPACE / "P8-005-closeout-preparation/baseline-main23eab/docs/roadmap/code-index-v2/tasks.json"
ledger = json.loads(task_file.read_text())
task_subset = [t for t in ledger["tasks"] if t["id"] in ("P8-017", "P8-018")]
write("original-two-task-excerpt.json", {"source_blob": identity(task_file.read_bytes()), "main_identity_basis": "The retained seven original plan inputs were unchanged by main 23eab -> 51138 / PR196; root and the independent P8-005 closeout reviewer already verified that bridge.", "tasks": task_subset})

peer_path = WORKSPACE / "round27-PR196-main-terminal/independent-terminal-review.json"
peer = json.loads(peer_path.read_text())
assert peer["actual_checkout_tree"] == TREE and peer["job_conclusion"] == "success"
log_path = pathlib.Path(peer["original_log"]["local_path"])
raw = log_path.read_bytes()
assert identity(raw) == {k: peer["original_log"][k] for k in ("bytes", "sha256", "git_blob")}
tests = [
    "distribution_and_interval_keep_one_nearest_rank_convention",
    "preserves_empty_single_and_submicrosecond_wire_values",
    "preserves_nearest_rank_boundaries_without_rounding_to_microseconds",
    "default_lanes_registry_keeps_fusion_order",
    "registry_cleanup_preserves_policy_wire_and_fingerprint",
    "current_schema_identity_index_preserves_rows_and_uses_indexed_fk_cascade",
    "fifo_physical_index_preserves_existing_current_logical_data",
    "v21_file_database_requires_reindex",
    "export_registration_matches_legacy_after_remove_and_readd",
    "export_registration_matches_legacy_for_alias_collisions",
    "one_pass_distance_preserves_original_ties_duplicates_and_order",
    "streamed_prefix_matches_original_path_segment_semantics",
    "compatibility_is_linear_gain",
    "compatibility_repeated_path_does_not_spend_rank",
    "partial_empty_is_not_a_correct_no_answer",
    "malformed_packing_status_cannot_be_interpreted_as_complete",
]
lines = raw.decode().splitlines()
selected = []
for test in tests:
    hits = [{"line": i + 1, "text": text} for i, text in enumerate(lines) if re.search(r"(?:test |::)" + re.escape(test) + r" \.\.\. ok$", text)]
    assert hits, test
    selected.append({"test": test, "original_passed_occurrences": hits})
write("existing-CI-named-controls.json", {"source_head": peer["source_head"], "actual_checkout": peer["actual_checkout"], "tree": TREE,
      "run_id": peer["run_id"], "job_id": peer["job_id"], "original_log": peer["original_log"], "peer_report": {"path": str(peer_path), **identity(peer_path.read_bytes())},
      "controls": selected, "reexecuted": False, "complete_V18_V21_claim": False})

candidate_rel = "docs/roadmap/code-index-v2/P8-OWNERSHIP.md"
candidate = ROOT / "candidate" / candidate_rel
candidate_bytes = candidate.read_bytes()
directory = json.loads((ROOT / "official-doc-directory.json").read_text())["structuredContent"]["content"]
directory = json.loads(directory) if isinstance(directory, str) else directory
assert "P8-OWNERSHIP.md" not in {entry["name"] for entry in directory}
patch = "".join(difflib.unified_diff([], candidate_bytes.decode().splitlines(keepends=True), fromfile="/dev/null", tofile="b/" + candidate_rel))
(ROOT / "candidate.patch").write_text(patch)
write("candidate-one-file-manifest.json", {"actual_base": MAIN, "base_tree": TREE, "actual_candidate_commit": None, "task_status_modified": False,
      "files": [{"path": candidate_rel, "change": "A", "mode": "100644", "type": "blob", "local_path": str(candidate), **identity(candidate_bytes)}],
      "patch": identity(patch.encode())})
review = {
    "schema_version": 1, "source": MAIN, "source_tree": TREE, "scope": "bounded P8-017 ownership and compatibility documentation preparation",
    "author": "/root/todo_audit", "independent_review": "pending", "product_code_changes": 0,
    "conclusion": "The named old duplicate-owner concerns are consolidated at this source. Test-only independent oracles and versioned public-wire profiles are necessary compatibility, not newly identified deletion targets. This bounded review does not prove that every source path is free of duplication.",
    "named_scope": ["Rust nearest-rank and Python legacy_ns consumption", "default lane registry and QueryPolicy", "canonical SQL and physical-index selection", "versioned benchmark score dispatch", "resolver test-only legacy reference helpers", "normalizer and historical schema compatibility"],
    "remaining_original_scope": {"P8-017": {"dependency": "P8-016 remains incomplete", "full_acceptance": "V18/V21 signoff is not granted by this bounded source/document review; existing controls retain their actual scope", "new_verified_production_duplicate": None},
                                  "P8-018": {"dependency": "P8-017 remains incomplete", "current_document_assessment": "P8-FACTS has a managed declaration table and deliberately retained historical execution statements. No verified factual contradiction requiring immediate replacement was identified in the bounded read; no historical statement is rewritten as current execution."}},
    "PR195_boundary": "Oracle scratch/public-output compatibility restoration is outside fixed main 51138 and is not claimed by this document or its prior CI evidence.",
    "checks_performed": ["Exact official UTF-8 source Git object IDs matched local bytes", "Existing CI decoded log identity and named passed lines were read, not reexecuted", "Candidate path absent from the fixed source directory listing"],
    "product_tests_executed": False, "formatter_executed": False, "heldout_or_live_provider_read_or_executed": False,
    "tasks_or_generated_views_modified": False, "TODO_credit": 0, "candidate_manifest": "candidate-one-file-manifest.json",
    "next_action": "Review the one-file documentation candidate; preserve the current task dependencies and original validation definitions. Reuse the listed source-bound regression records for their exact scopes. Do not schedule a new study merely for this document."
}
write("bounded-ownership-and-compatibility-review.json", review)
select = [p for p in ROOT.rglob("*") if p.is_file() and p.name != "archive-selection.json"]
write("archive-selection.json", {"scope": "bounded source/doc preparation; no new product execution", "source": MAIN, "files": [{"path": str(p), "relative_path": str(p.relative_to(ROOT)), **identity(p.read_bytes())} for p in sorted(select)]})
print(json.dumps({"status": "passed_bounded_document_preparation", "source_count": len(source_rows), "candidate": identity(candidate_bytes), "controls": len(selected), "product_test_runs": 0, "TODO_credit": 0}))
