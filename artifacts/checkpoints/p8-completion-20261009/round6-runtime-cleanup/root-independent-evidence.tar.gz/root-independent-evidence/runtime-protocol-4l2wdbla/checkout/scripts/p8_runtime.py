# committed protocol-control fixture: scripts/p8_runtime.py
