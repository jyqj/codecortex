def stable_00206():
    return 206
