"""Exactly one read-only preflight/replay per named new C mixed original."""
import datetime,hashlib,json,os,pathlib,subprocess,sys,time
B=pathlib.Path(__file__).resolve().parent;H=B/'helpers-C3ff-v1';S=B.parent/'scale-original-c3ff';HEAD='3ffcefc3b28ee1a4ed80caecebd7208a45c3e302'
allowed={11611524778:16};aid=int(sys.argv[1]);assert aid in allowed and len(sys.argv)==2;c=allowed[aid];A=B/'artifacts'/str(aid);O=B/'accepted';O.mkdir(exist_ok=True)
record=A/'actual-acceptance-execution.json';assert not record.exists() and not (A/'extracted').exists() and not (O/('artifact-'+str(aid)+'-'+HEAD[:8]+'-independent-final')).exists()
def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def snap():return {str(p):sha(p) for p in sorted(H.glob('*.py'))}
manifest=H/'adaptation-manifest.json';assert sha(manifest)=='b293187b0a46e1e02157986dbb23661da23cb6f9136866ac2050a73ad85f2e58'
for entry in json.loads(manifest.read_text())['files']:
 p=pathlib.Path(entry['path']);assert p.stat().st_size==entry['candidate']['bytes'] and sha(p)==entry['candidate']['sha256']
m=json.loads((A/'artifact-metadata.json').read_text());z=A/(str(aid)+'.zip')
assert m['id']==aid and m['workflow_run']['id']==37908825814 and m['workflow_run']['head_sha']==HEAD and m['name']=='p8-mixed-c'+str(c)+'-'+HEAD
assert z.stat().st_size==m['size_in_bytes'] and sha(z)==m['digest'].removeprefix('sha256:')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==HEAD
r=dict(schema='C-mixed-original-acceptance-execution-v1',source=HEAD,workflow_run=37908825814,artifact_id=aid,configured_concurrency=c,started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_zip_sha256_before=sha(z),original_zip_bytes=z.stat().st_size,helper_inputs_before=snap(),helper_adaptation_manifest_sha256=sha(manifest),commands=[],status='started',new_native_workload=False,native_replay_scope='Only original statistics over retained rows and no-repair full-table oracle on temporary database copies')
def save():record.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
def run(label,argv):
 item=dict(label=label,command=argv,cwd=str(B),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat());r['commands'].append(item);save();start=time.monotonic()
 with (A/(label+'.stdout')).open('xb') as out,(A/(label+'.stderr')).open('xb') as err:
  try:q=subprocess.run(argv,cwd=B,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','GIT_NO_LAZY_FETCH':'1'},stdout=out,stderr=err,timeout=900);item['exit_code']=q.returncode
  finally:item['elapsed_seconds']=time.monotonic()-start;save()
 item.update(stdout=dict(path=str(A/(label+'.stdout')),bytes=(A/(label+'.stdout')).stat().st_size,sha256=sha(A/(label+'.stdout'))),stderr=dict(path=str(A/(label+'.stderr')),bytes=(A/(label+'.stderr')).stat().st_size,sha256=sha(A/(label+'.stderr'))));save();assert q.returncode==0,label
try:
 run('preflight',[sys.executable,'-B',str(H/'preflight_e_runtime_zip.py'),str(z),str(A/'artifact-metadata.json'),str(A/'extracted'),str(A/'preflight-and-extraction.json'),'--extract'])
 descriptor=A/'acceptance-manifest.json';descriptor.write_text(json.dumps([[c,aid,m['size_in_bytes'],r['original_zip_sha256_before']]],indent=2)+'\n')
 run('runtime-review',[sys.executable,'-B',str(H/'review_e_runtime_original.py'),str(descriptor),str(B/'artifacts'),HEAD,str(S),str(O)])
 r['helper_inputs_after']=snap();assert r['helper_inputs_after']==r['helper_inputs_before']
 r['original_zip_sha256_after']=sha(z);assert r['original_zip_sha256_after']==r['original_zip_sha256_before']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==HEAD
 p=O/('artifact-'+str(aid)+'-'+HEAD[:8]+'-independent-final/independent-review.json');r['review']=dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p));r['status']='accepted_scoped_original_C_mixed'
except BaseException as e:r['status']='failed_or_blocked_original_review';r['exception']=repr(e);raise
finally:r['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(dict(status=r['status'],receipt=str(record),sha256=sha(record),review=r.get('review'))))
