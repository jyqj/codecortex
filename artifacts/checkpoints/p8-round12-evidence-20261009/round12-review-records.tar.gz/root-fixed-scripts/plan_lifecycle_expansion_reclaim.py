#!/usr/bin/env python3
"""Read-only proof for reclaiming one newly received expansion; keep its ZIP."""
from pathlib import Path, PurePosixPath
import datetime
import hashlib
import json
import os
import stat
import zipfile
import zlib

BASE = Path('/workspace/scratch/2eaa00d0f93a/p8-formal-evidence-G4/lifecycle')
TARGET = BASE / 'files'
ZIP = BASE / 'original-artifact.zip'
OUT = Path('/dev/shm/p8-G4-lifecycle-expansion-reclaim-root')
ZIP_SHA = '81756f7d1990147961c87f905625c33da69b57d703f8eb4afa7e0f690ca52c31'

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def identity(path):
    s = path.lstat()
    return {'device': s.st_dev, 'inode': s.st_ino, 'mode': s.st_mode, 'links': s.st_nlink,
            'bytes': s.st_size, 'mtime_ns': s.st_mtime_ns, 'uid': s.st_uid, 'gid': s.st_gid,
            'allocated_bytes': s.st_blocks * 512}

def main():
    OUT.mkdir(exist_ok=False)
    assert TARGET.resolve(strict=True) == TARGET and ZIP.resolve(strict=True) == ZIP
    for parent in [TARGET, *TARGET.parents]:
        assert stat.S_ISDIR(parent.lstat().st_mode) and not parent.is_symlink()
    assert ZIP.stat().st_size == 49348679 and sha(ZIP) == ZIP_SHA
    zip_before = identity(ZIP)
    target_before = identity(TARGET)
    files, directories = {}, {}
    for current, children, leaves in os.walk(TARGET, followlinks=False):
        directory = Path(current)
        relative = directory.relative_to(TARGET).as_posix()
        entry = identity(directory)
        assert stat.S_ISDIR(entry['mode']) and entry['device'] == target_before['device']
        assert not directory.is_symlink()
        directories[relative] = entry
        for name in children:
            assert not (directory / name).is_symlink()
        for name in leaves:
            path = directory / name
            entry = identity(path)
            assert stat.S_ISREG(entry['mode']) and entry['links'] == 1
            assert entry['device'] == target_before['device'] and not path.is_symlink()
            files[path.relative_to(TARGET).as_posix()] = entry
    seen = set()
    with zipfile.ZipFile(ZIP) as archive:
        assert len(archive.infolist()) == 2391
        for info in archive.infolist():
            name = PurePosixPath(info.filename)
            assert str(name) == info.filename and not name.is_absolute() and '..' not in name.parts
            assert not info.is_dir() and stat.S_ISREG(info.external_attr >> 16)
            assert info.filename in files and info.filename not in seen
            seen.add(info.filename)
            digest, crc, count = hashlib.sha256(), 0, 0
            with archive.open(info) as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    digest.update(block)
                    crc = zlib.crc32(block, crc)
                    count += len(block)
            assert count == info.file_size and crc & 0xffffffff == info.CRC
            path = TARGET / info.filename
            assert identity(path) == files[info.filename]
            assert files[info.filename]['bytes'] == count and sha(path) == digest.hexdigest()
            files[info.filename].update(sha256=digest.hexdigest(), zip_crc32=info.CRC,
                                        zip_mode=info.external_attr >> 16)
    assert seen == set(files)
    assert sha(ZIP) == ZIP_SHA and identity(ZIP) == zip_before and identity(TARGET) == target_before
    for relative, entry in directories.items():
        assert identity(TARGET if relative == '.' else TARGET / relative) == entry
    for relative, entry in files.items():
        assert identity(TARGET / relative) == {k: v for k, v in entry.items() if k not in ('sha256', 'zip_crc32', 'zip_mode')}
    review = BASE / 'independent-review-01/inspection.json'
    assert sha(review) == 'ffcf11913f4c8dad93da08558ee0f47499ac3dae5e21167c1232990b88046dc6'
    plan = {
        'status': 'read_only_plan_pending_nonauthor_review_no_deletion_performed',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'target': str(TARGET), 'target_identity': target_before,
        'purpose': 'Recover capacity only from this newly created receiver expansion; retain its complete original ZIP and every audit, metadata and log.',
        'source_kind': 'New G4 receiver-created decompressed copies, not original native measurement workspaces or old temporary directories.',
        'zip_to_keep': str(ZIP), 'zip_identity': zip_before, 'zip_sha256': ZIP_SHA,
        'complete_zip_member_count': 2391, 'expanded_file_count': len(files),
        'expanded_bytes': sum(e['bytes'] for e in files.values()),
        'expanded_allocated_bytes': sum(e['allocated_bytes'] for e in files.values()),
        'all_members_bidirectionally_equal_live_files': True, 'all_files_single_link_regular_same_device': True,
        'files': files, 'directories': directories,
        'existing_acceptance_review': {'path': str(review), 'sha256': sha(review)},
        'original_receiver': {'path': str(BASE / 'receive_archive.py'), 'sha256': sha(BASE / 'receive_archive.py')},
        'protected_scope': 'Everything outside target, including original ZIP, run/job/artifact metadata, original logs, receiver and all review results; no other checkout or measurement is included.',
        'execution_requirement': 'Nonauthor exact plan/ZIP/member/inode review first; recheck all fixed identities and digests immediately before only enumerated unlinks and bottom-up empty directory removals. Preserve ZIP after execution; no recursive deletion command.',
        'TODO_newly_completed': 0, 'TODO_remaining': 29,
    }
    path = OUT / 'plan.json'
    path.write_text(json.dumps(plan, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'plan': str(path), 'sha256': sha(path), 'file_count': len(files),
                      'expanded_bytes': plan['expanded_bytes'], 'allocated_bytes': plan['expanded_allocated_bytes'],
                      'zip_kept_bytes': ZIP.stat().st_size, 'no_deletion': True}))

if __name__ == '__main__':
    main()
