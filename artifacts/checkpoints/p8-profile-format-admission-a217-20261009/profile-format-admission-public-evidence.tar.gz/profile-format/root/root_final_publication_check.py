#!/usr/bin/env python3
"""Check the completed formatter handoff and actual API identities; no guard replay."""
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

B = Path(__file__).resolve().parent
VIEW = B / 'guard-view'
BASE_VIEW = B.parent / 'p8-profile-isolated-integration/guard-view'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def oid(b):
    return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()

def read(p):
    return json.loads(Path(p).read_bytes())

def git(*args):
    r = subprocess.run(['git', '-C', str(VIEW), *args], env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}, capture_output=True, check=True)
    return r.stdout.decode().strip()

def main():
    handoff_bytes = (B / 'final-handoff.json').read_bytes()
    assert len(handoff_bytes) == 10548
    assert sha(handoff_bytes) == '00a9742d0df8d090817fd4544db1f2bd450d812dfb154c2c998ad7e160905174'
    h = json.loads(handoff_bytes)
    referenced = {}
    def visit(x):
        if isinstance(x, dict):
            if all(k in x for k in ('path', 'bytes', 'sha256', 'git_blob')):
                b = Path(x['path']).read_bytes()
                assert (len(b), sha(b), oid(b)) == (x['bytes'], x['sha256'], x['git_blob']), x['path']
                referenced[x['path']] = x['sha256']
            for v in x.values(): visit(v)
        elif isinstance(x, list):
            for v in x: visit(v)
    visit(h)
    api = read(B / 'root-actual-API-publication-proof.json')
    chains = read(B / 'actual-complete-chain-tree-proof.json')['chain']
    for label, chain in zip(('P', 'R', 'G'), chains):
        a = api[label]
        assert (a['sha'], a['tree'], a['parents']) == (chain['commit'], chain['tree'], [chain['parent']])
        expected = {p: (v['after']['sha'], 'added' if v['before'] is None else 'modified') for p, v in chain['changes'].items()}
        assert {f['path']: (f['sha'], f['status']) for f in a['files']} == expected
    assert api['current_head'] == api['current_pr']['head'] == h['sole_base_execution']
    assert api['current_pr']['base'] == '10ec828beb94200ec679302c45115760ebd55ee9'
    assert api['current_pr']['labels'] == []
    core = read(B / 'independent-source-review.json')
    reg = read(B / 'scripts/reviewed-source-registry-v15.json')
    oldreg = read(BASE_VIEW / 'scripts/reviewed-source-registry-v15.json')
    assert core['complete_inputs'] == reg['complete_inputs'] and len(reg['complete_inputs']) == 1095
    assert core['paths'] == reg['delta'] and len(reg['delta']) == 72
    assert core['validation_inputs'] == reg['validation_inputs'] == oldreg['validation_inputs'] and len(reg['validation_inputs']) == 148
    changed = {f['path'] for f in api['P']['files']}
    assert {p for p, s in reg['complete_inputs'].items() if s != oldreg['complete_inputs'][p]} == changed
    assert {p for p, s in reg['delta'].items() if s != oldreg['delta'][p]} == changed
    for p in reg['delta']: assert reg['delta'][p]['before_sha256'] == oldreg['delta'][p]['before_sha256']
    assert reg['product_source'] == h['P'] and reg['review_source'] == h['R']
    assert reg['review_sha256'] == sha((B / 'independent-source-review.json').read_bytes())
    for k in set(reg) - {'complete_inputs', 'delta', 'product_source', 'review_source', 'review_sha256'}:
        assert reg[k] == oldreg[k], k
    pins = read(B / 'execution-pins-prepared.json')['pins']
    verifier = (B / 'scripts/verify_reviewed_source_v15.py').read_text()
    oldverifier = (BASE_VIEW / 'scripts/verify_reviewed_source_v15.py').read_text()
    assignments = {}
    for node in ast.parse(verifier).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id in pins:
            assignments[node.targets[0].id] = ast.literal_eval(node.value)
    assert assignments == pins
    assert pins['PRODUCT'] == h['P'] and pins['REVIEW'] == h['R']
    assert pins['REVIEW_PATH'] == core['review_path']
    assert pins['REGISTRY_SHA256'] == sha((B / 'scripts/reviewed-source-registry-v15.json').read_bytes())
    def mask(s):
        return re.sub(r'(?m)^(PRODUCT|REVIEW|REVIEW_PATH|REGISTRY_SHA256) = .*$', lambda m: m.group(1) + ' = SAME_IDENTITY_SLOT', s)
    assert mask(verifier) == mask(oldverifier)
    assert git('rev-parse', 'HEAD') == h['G'] and git('rev-parse', 'HEAD^{tree}') == h['tree']
    index = Path(git('rev-parse', '--git-path', 'index'))
    if not index.is_absolute(): index = VIEW / index
    for name in ('original-v15', 'original-task-plan'):
        e = h['executions'][name]
        assert e['actual']['exit_code'] == 0 and e['actual']['inputs_unchanged'] and e['actual']['error'] is None
        before = Path(e['before']['path']).read_bytes()
        after = Path(e['after']['path']).read_bytes()
        assert before == after
        snap = json.loads(after)
        assert snap['head'] == h['G'] and snap['index_sha256'] == sha(index.read_bytes())
        assert len(snap['inputs']) == 1256
        for p, digest in snap['inputs'].items(): assert sha((VIEW / p).read_bytes()) == digest, p
    projection = read(B / 'private-view-actual-source-proof.json')
    for f in projection['files']:
        b = (VIEW / f['path']).read_bytes()
        assert (len(b), sha(b), oid(b)) == (f['bytes'], f['sha256'], f['git_blob']), f['path']
    out = {'schema': 'root-profile-format-final-publication-check-v1', 'recorded_at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'passed', 'P': h['P'], 'R': h['R'], 'G': h['G'], 'tree': h['tree'], 'expected_parent_head': h['sole_base_execution'], 'actual_API_changes': {'product': 4, 'review': 10, 'guard': 2}, 'complete_product_inputs': 1095, 'BASE_delta': 72, 'validation_inputs': 148, 'current_projection_bytes_rechecked': len(projection['files']), 'sealed_input_hashes_rechecked': 1256, 'referenced_handoff_records_verified': len(referenced), 'original_v15_exit': 0, 'original_task_plan_exit': 0, 'no_guard_or_native_replay': True, 'formatter_22_hunks_peer_accepted': True, 'normal_Rust_CI_pending': True, 'profile_1350_not_triggered': True, 'newly_completed_todos': 0, 'remaining_todos': 29}
    (B / 'root-final-publication-check.json').write_text(json.dumps(out, sort_keys=True, indent=2) + '\n')
    print(json.dumps(out, ensure_ascii=False))

if __name__ == '__main__':
    main()
