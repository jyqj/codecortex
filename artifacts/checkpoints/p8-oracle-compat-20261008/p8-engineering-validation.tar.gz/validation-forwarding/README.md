# Forwarding 文件预算修复交接

## 固定身份

- 基线：`a20d269b5ba01a9bbbb394ba154bd5fa2b9eaa9c`。
- 测试反例提交：`14ab7843`；只增加 7 个控制及测试模块挂载，实际得到预期失败。
- 最终本地源码：`d62880a164b23461117507f143decebef1cb9517`。
- 工作区：`/workspace/scratch/031390cf22eb/codecortex-forwarding`，工作树干净。
- 完整源码输入：798 项；原 p7_build_identity 算法得出 manifest SHA-256 `ef3fcf15da0523391b9c25abbc589b3c14498896eff581df416228619ef22aa6`。
- 已独立比较 root 整合提交 `363de920`，全部 crates/Cargo 输入同字节。最终远程 source/review 身份仍由 root 冻结。

## 根因与最小修改

原 10k 控制在第一个 cold full build 报 `reexport_file_budget_exceeded`，尚未进入 oracle。外部命令耗时 23.633 秒，监督报告 wall 23,535 ms，失败 build 为 21,769,042 μs。原计划、raw、报告、日志和执行回执均保留，逐文件 hash 在 `forwarding-handoff.json`。

`install_forwarding` 原先把全部 direct resolved import 根先纳入 4096 个文件上限，之后才读取已经存在于当前解析批次的 PublicSurface。已知且没有 forwards 的目标只需要原 symbol catalog 的 direct export 查找，没有额外 forwarding 工作。

修复只在初始 frontier、每轮 frontier 和最后 depth 检查排除 **current 中 Known/KnownEmpty 且 forwards 为空**的节点。没有修改配置或添加 benchmark 专用参数。原 4096 文件、65536 resolved forwarding edges、32 轮与 catalog exported lookup 的 4096 节点限制不变。

Unknown 表面即使 forwards 为空仍扣预算；不在 current 的目标仍在数据库读取前扣预算，实际持久化为空或缺失均不能绕过限制。direct export 查找、scope、alias、cycle、缺失成员负例及旧断言保持原样。

## 实际前后对照

| 执行 | 结果 | 时间（含编译） |
|---|---|---:|
| 新增 7 控，修复前 | 6 passed / 1 expected failure：4097 个已知 direct roots 触发旧文件预算 | 38.300 s |
| 同 7 控，修复后 | 7 passed / 0 ignored | 16.411 s |
| 原 cc-eval P2C/P3B parser/SQLite 回归 | 18 passed / 2 原显式 MCP opt-in ignored | 54.547 s |
| 原 cc-index P3B 模块规则 | 19 passed / 0 ignored | 9.056 s |
| cc-index all-targets Clippy，`-D warnings` | exit 0 | 21.411 s |

最终不同测试合计 44 passed，2 个原 opt-in ignored 没有计作通过。全部执行使用独立 target-forwarding，原严格源码回执确认每条命令前后 `source_unchanged=true`。

新增正控真实执行 parser → captured module model → catalog → call binding，逐个验证 4097 个目标的文件、symbol ID 和 UID。其余控制真实调用 forwarding 阶段，验证 actual forwarding roots、current Unknown、真实 SQLite persisted-known-empty、missing-persisted 的文件预算；同时保留 32/33 轮边界和 65536 边预算。

每条命令的完整输出与原源码 manifest 在本目录同名前缀的 `.log` / `.json` 文件中。交接总表为 `forwarding-handoff.json`。本记录由实现作者生成，不替代 `/root/build_validation` 的非作者审查。

root 正用整合产品重新运行原 10k 计划；本记录不预先接受该运行，也不把本次修复计为 P8、heldout、矩阵或发行认证完成。
