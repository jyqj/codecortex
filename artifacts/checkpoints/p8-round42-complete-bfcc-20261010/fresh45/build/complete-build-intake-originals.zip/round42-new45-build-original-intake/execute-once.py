import pathlib,subprocess,time,json,datetime,hashlib
D=pathlib.Path('/workspace/scratch/bfccb8494ba0/round42-new45-build-original-intake')
argv=['python3','-B',str(D/'validate-original-build-once.py')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
with (D/'original-validator.stdout').open('xb') as out,(D/'original-validator.stderr').open('xb') as err:
 result=subprocess.run(argv,cwd='/workspace/scratch/bfccb8494ba0',stdout=out,stderr=err)
r={'argv':argv,'cwd':'/workspace/scratch/bfccb8494ba0','started_at_utc':start,'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_seconds':time.monotonic()-t,'exit_code':result.returncode,'original_validate_build_calls_requested':1,'source':'f97c5068d056969705e8387ba1f37d83847f5bee','run':38026411200,'attempt':1,'boundary':'Original ELF --hash-file utility only, no compile/measurement/shard validation.'}
for name in ['stdout','stderr']:
 b=(D/('original-validator.'+name)).read_bytes();r[name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(D/'original-validator-execution.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
raise SystemExit(result.returncode)
