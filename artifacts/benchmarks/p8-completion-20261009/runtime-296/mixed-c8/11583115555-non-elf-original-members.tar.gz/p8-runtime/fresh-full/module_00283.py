def stable_00283():
    return 283
