from pathlib import Path
import json,hashlib,collections,datetime,sys
root=Path(__file__).resolve().parent
base=root.parent/'raw-pr178-c8be5afa/11604870469/attempt01/extracted'
m=base/'measurement'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def key(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
events=[json.loads(line) for line in (m/'events.jsonl').open()]
starts={x['session']:x for x in events if x['kind']=='session_started'}
ends={x['session']:x for x in events if x['kind']=='session_closed'}
assert len(starts)==len(ends)==431 and starts.keys()==ends.keys()
groups=collections.defaultdict(list)
for x in events:
 if x['kind'] in ('cold_build','query_attempt'):groups[x['session']].append(x)
assert groups.keys()==starts.keys()
reports=[];counts=collections.Counter();line_index=[]
product=json.loads((base/'product/build-receipt.json').read_text())
for name in sorted(starts):
 d=m/'sessions'/name;process=json.loads((d/'process.json').read_text());rpc=d/'rpc.jsonl'
 assert process==ends[name]['process'] and process['pid']==starts[name]['pid']
 assert process['exit_code']==process['expected_exit_code']==0 and process['cleanup']=='completed' and process['binary_sha256']==product['binary_sha256']
 req={};res={};idx=[];offset=0;event_counts=collections.Counter()
 for lineno,line in enumerate(rpc.open('rb'),1):
  x=json.loads(line);event_counts[x['event']]+=1;idx.append([lineno,offset,len(line),hashlib.sha256(line).hexdigest()]);offset+=len(line)
  if x['event']=='request':assert x['payload']['id'] not in req;req[x['payload']['id']]=x['payload']
  if x['event']=='response':assert x['payload']['id'] not in res;res[x['payload']['id']]=x['payload']
 assert req.keys()==res.keys() and all('error' not in v for v in res.values())
 tools=collections.defaultdict(list)
 for i,r in req.items():
  if r['method']!='tools/call':continue
  result=res[i]['result'];assert result.get('isError') is not True and isinstance(result.get('structuredContent'),dict)
  value=result['structuredContent'];tools[r['params']['name']].append(value.get('result',value))
 expect=collections.Counter(index=1,status=2) if name.startswith('cold-') else collections.Counter(search=801,status=1602) if name=='warm' else collections.Counter(search=1,status=2)
 assert collections.Counter({k:len(v) for k,v in tools.items()})==expect
 expected_status=[];expected_work=[]
 for e in groups[name]:
  assert e['error'] is None
  expected_status.extend([e['before'],e['after']]);expected_work.append(e['raw'] if e['kind']=='cold_build' else e['response'])
 assert collections.Counter(map(key,tools['status']))==collections.Counter(map(key,expected_status))
 op='index' if name.startswith('cold-') else 'search'
 assert collections.Counter(map(key,tools[op]))==collections.Counter(map(key,expected_work))
 counts.update(expect)
 reports.append({'session':name,'pid':process['pid'],'exit_code':process['exit_code'],'process_sha256':sha(d/'process.json'),'rpc_sha256':sha(rpc),'rpc_bytes':rpc.stat().st_size,'event_counts':dict(event_counts),'requests':len(req),'tool_calls':dict(expect),'all_status_and_work_payloads_bound':True})
 line_index.append({'session':name,'path':str(rpc.relative_to(base)),'bytes':rpc.stat().st_size,'sha256':sha(rpc),'line_fields':['line','offset','bytes','sha256'],'lines':idx})
assert counts=={'index':30,'search':1201,'status':2462}
out={'schema_version':1,'reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'c8be5afaac568ffd40ef86d3795423c3b73c9f39','artifact_id':11604870469,'status':'independent_original_stdio_bindings_passed','sessions':431,'workload_counts':dict(counts),'original_events_sha256':sha(m/'events.jsonl'),'all_processes_closed':True,'all_raw_status_and_query_and_cold_payloads_bound':True,'no_extra_reopen_or_warm_index_calls':True,'original_rpc_reexecuted':False,'sessions_detail':reports}
for name,value in [('lifecycle-stdio-binding-review-v1.json',out),('lifecycle-stdio-byte-index.json',{'schema_version':1,'artifact_id':11604870469,'scope':'Original RPC bytes are retained in the original ZIP; this complete index records each line offset, byte length and SHA without copying large stdout.','sessions':line_index})]:
 with (root/name).open('x') as f:json.dump(value,f,ensure_ascii=False,separators=(',',':'));f.write('\n')
 print(name,(root/name).stat().st_size,sha(root/name))
print(json.dumps({'status':out['status'],'sessions':out['sessions'],'workload_counts':dict(counts)}))
