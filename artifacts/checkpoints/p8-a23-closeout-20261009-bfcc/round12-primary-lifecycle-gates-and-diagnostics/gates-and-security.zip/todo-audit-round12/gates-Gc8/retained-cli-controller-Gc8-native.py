import sys
sys.dont_write_bytecode=True
import pathlib,json,hashlib,subprocess,time,shutil,platform,os
base=pathlib.Path("/workspace/scratch/bfccb8494ba0")
root=base/"todo-audit-round12"/"gates-Gc8"/"retained-cli"
root.mkdir(parents=True)
original=base/"pr-triage-primary-recovery/raw-pr178-c8be5afa/11603892263/attempt01/extracted"
canonical=base/"pr-triage-primary-recovery/runtime-review-Gc8/exact-canonical-R.json"
def digest(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda:f.read(1024*1024),b""):h.update(block)
    return h.hexdigest()
canonical_sha=digest(canonical)
assert canonical_sha=="c38d10f1b0d5935384039a6af7df6e8d222bc351a68d3137b09e664735ee9404"
review=json.loads(canonical.read_bytes())
report=json.loads((original/"report.json").read_bytes())
source_before=report["source"]
assert source_before["source_commit"]=="c8be5afaac568ffd40ef86d3795423c3b73c9f39"
assert source_before["source_tree"]=="9b031be22a430e51e153cce6e80770ed885818e3"
assert source_before["inputs"]==review["complete_inputs"] and len(source_before["inputs"])==1090
assert review["source"]=="35a7b3412e5fdee9e8ff88951735c06b0e371465"
assert len(review["validation_inputs"])==139
shutil.copyfile(original/"cc-eval",root/"cc-eval")
(root/"cc-eval").chmod(0o555)
assert digest(root/"cc-eval")==digest(original/"cc-eval")==report["cli"]["executable_sha256"]=="e21fa0863c18ea447cf060384fc15ffe502ecb24f9a2627e2248c0373b037e9e"
original_before={p.relative_to(original).as_posix():digest(p) for p in original.rglob("*") if p.is_file()}
assert platform.system()=="Linux" and platform.machine()=="x86_64" and platform.libc_ver()==("glibc","2.39")
child_env={"PATH":"/usr/bin:/bin","LANG":"C.UTF-8","LC_ALL":"C.UTF-8"}
environment={"system":platform.system(),"machine":platform.machine(),"libc":platform.libc_ver(),"kernel":platform.release(),"network_namespace":"not isolated; unshare --net probe exited1/Operation not permitted before any product command","child_env":child_env,"input_scope":"original compare path uses only locked synthetic-gate-fixture files; no adapter/provider execution or URL/credential arguments","original_artifact":"not passed as CLI input; only independently copied fixture tree is passed; all original hashes checked before/after","performance_measurement":False}
(root/"actual-environment.json").write_text(json.dumps(environment,indent=2)+"\n")
outputs=root/"outputs-v2"
outputs.mkdir()
working=root/"inputs-copy-v2"
working.mkdir()
for index in (0,2,3,4,5):
    rel=pathlib.Path(f"case-{index:02}")/"retained-fixtures"
    (working/rel).parent.mkdir(parents=True,exist_ok=True)
    shutil.copytree(original/rel,working/rel)
working_before={p.relative_to(working).as_posix():digest(p) for p in working.rglob("*") if p.is_file()}
assert all(original_before[n]==h for n,h in working_before.items())
assert sum(p.stat().st_size for p in working.rglob("*") if p.is_file())==209265
fixtures={}
for index in (0,2,3,4,5):
    matches=list((original/f"case-{index:02}"/"retained-fixtures").iterdir())
    assert len(matches)==1
    fixtures[index]=matches[0]
def inside(path):
    return str(working/path.relative_to(original))
policy=fixtures[2]/"policy.json"
cases=[
("quality_failed",fixtures[2]/"base",fixtures[2]/"quality",policy,1,"failed","quality-comparison.json"),
("latency_failed",fixtures[2]/"base",fixtures[2]/"latency",policy,1,"failed","latency-comparison.json"),
("insufficient_samples",fixtures[3]/"base",fixtures[3]/"candidate",fixtures[3]/"policy.json",1,"inconclusive","comparison.json"),
("zero_latency_denominator",fixtures[0]/"base",fixtures[0]/"candidate",policy,1,"inconclusive",None),
("raw_lock_drift",fixtures[4]/"base",fixtures[4]/"candidate",fixtures[4]/"policy.json",2,"invalid_measurement","comparison.json"),
("bad_policy",fixtures[5]/"missing-run",fixtures[5]/"missing-run",fixtures[5]/"policy.json",2,"invalid_measurement","comparison.json")]
results=[]
lastcmd=None
try:
    for name,b,c,p,expected_exit,expected_status,oldreport in cases:
        output=outputs/(name+".json")
        args=["compare","--baseline",inside(b),"--candidate",inside(c),"--gate",inside(p),"--output",str(output)]
        command=[str(root/"cc-eval"),*args]
        start=time.monotonic()
        observed=subprocess.run(command,capture_output=True,timeout=20,env=child_env,close_fds=True,stdin=subprocess.DEVNULL,cwd=working)
        (root/("v2-"+name+".stdout.log")).write_bytes(observed.stdout)
        (root/("v2-"+name+".stderr.log")).write_bytes(observed.stderr)
        data=json.loads(output.read_text()) if output.exists() else None
        row={"case":name,"command":command,"cli_argv":["cc-eval",*args],"expected_exit_code":expected_exit,"actual_exit_code":observed.returncode,"expected_status":expected_status,"actual_status":data.get("status") if data else None,"actual_report":data,"stdout_sha256":hashlib.sha256(observed.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(observed.stderr).hexdigest(),"output_sha256":digest(output) if output.exists() else None,"wall_seconds_for_audit_only":time.monotonic()-start}
        results.append(row)
        assert observed.returncode==expected_exit and data and data["status"]==expected_status and data["exit_code"]==expected_exit,(name,row,observed.stderr.decode(errors="replace"))
        if name=="quality_failed":
            assert data["p95_ratio"]==1.0 and "Top-1 regression" in data["reasons"]
        elif name=="latency_failed":
            assert data["p95_ratio"]==10.0 and "p95 regression" in data["reasons"]
        elif name=="insufficient_samples":
            assert data["baseline_samples"]==data["candidate_samples"]==2 and "insufficient latency samples" in data["inconclusive_reasons"]
        elif name=="zero_latency_denominator":
            assert data["baseline_samples"]==data["candidate_samples"]==30 and data["p95_ratio"] is None
        elif name=="raw_lock_drift":
            assert data["reasons"]==["invalid benchmark input: raw response drift"]
        elif name=="bad_policy":
            assert any("JSON:" in x for x in data["reasons"])
        if oldreport:
            prior=json.loads((b.parent/oldreport).read_text())
            if expected_status=="invalid_measurement":
                assert data["reasons"]==prior["reasons"] and data["status"]==prior["status"] and data["exit_code"]==prior["exit_code"]
            else:
                assert data==prior
        lastcmd=command
    output=outputs/"bad_policy.json"
    before=output.read_bytes()
    start=time.monotonic()
    repeated=subprocess.run(lastcmd,capture_output=True,timeout=20,env=child_env,close_fds=True,stdin=subprocess.DEVNULL,cwd=working)
    (root/"v2-output_overwrite_refusal.stdout.log").write_bytes(repeated.stdout)
    (root/"v2-output_overwrite_refusal.stderr.log").write_bytes(repeated.stderr)
    results.append({"case":"output_overwrite_refusal","command":lastcmd,"expected_exit_code":2,"actual_exit_code":repeated.returncode,"output_before_sha256":hashlib.sha256(before).hexdigest(),"output_after_sha256":digest(output),"existing_report_unchanged":output.read_bytes()==before,"stdout_sha256":hashlib.sha256(repeated.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(repeated.stderr).hexdigest(),"stderr":repeated.stderr.decode(),"wall_seconds_for_audit_only":time.monotonic()-start})
    assert repeated.returncode==2 and output.read_bytes()==before
    assert {p.relative_to(original).as_posix():digest(p) for p in original.rglob("*") if p.is_file()}==original_before
    assert digest(canonical)==canonical_sha and json.loads((original/"report.json").read_bytes())["source"]==source_before and digest(root/"cc-eval")==report["cli"]["executable_sha256"]
    assert {p.relative_to(working).as_posix():digest(p) for p in working.rglob("*") if p.is_file()}==working_before
    final={"schema_version":1,"status":"accepted_all_7_original_retained_CLI_replays","source_commit":source_before["source_commit"],"artifact_id":11603892263,"artifact_zip_sha256":"c04f9d2da1abc5c1dd1b387e743835484705e7217ee44a9445eaff0f99f72c62","retained_cli_sha256":report["cli"]["executable_sha256"],"retained_cli_bytes":(root/"cc-eval").stat().st_size,"execution_context":environment,"original_artifact_files_unchanged":len(original_before),"working_fixture_files_before_after_equal":len(working_before),"working_fixture_bytes":209265,"working_fixture_manifest":working_before,"attempt_identity":{"number":1,"method_version":"retained-CLI-v2-native","note":"First Gc8 deterministic retained ELF comparison audit; no prior-source execution is relabeled."},"cases":results,"zero_plan_control":"separate original nonignored zero_measurement_gate_is_invalid Rust test, not a CLI case","canonical_review_sha256":canonical_sha,"todo_status_change":False}

except BaseException as error:
    final={"schema_version":1,"status":"replay_failed","error":str(error),"cases":results,"todo_status_change":False}
finally:
    (root/"replay-report-v2.json").write_text(json.dumps(final,indent=2)+"\n")
print(json.dumps({"status":final["status"],"error":final.get("error"),"execution_context":environment,"retained_cli_sha256":report["cli"]["executable_sha256"],"cases":[{"case":x["case"],"expected_exit_code":x["expected_exit_code"],"actual_exit_code":x["actual_exit_code"],"status":x.get("actual_status"),"output_sha256":x.get("output_sha256",x.get("output_after_sha256"))} for x in results]},indent=2))
if final["status"]!="accepted_all_7_original_retained_CLI_replays":
    raise SystemExit(1)
