def stable_00310():
    return 310
