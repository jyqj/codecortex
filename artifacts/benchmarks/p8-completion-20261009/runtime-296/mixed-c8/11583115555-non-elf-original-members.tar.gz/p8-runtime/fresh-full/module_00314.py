def stable_00314():
    return 314
