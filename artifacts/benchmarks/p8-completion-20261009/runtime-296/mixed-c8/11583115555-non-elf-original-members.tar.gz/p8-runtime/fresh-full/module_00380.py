def stable_00380():
    return 380
