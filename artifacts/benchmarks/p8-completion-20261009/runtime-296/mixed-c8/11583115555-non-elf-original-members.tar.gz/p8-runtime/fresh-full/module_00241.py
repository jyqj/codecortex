def stable_00241():
    return 241
