# Complete original G2 four-C DB acquisition observations

This is the final append-only acceptance for fixed G2 `4d18dcdb34b5d7a277566b57801cc882d8b1eb61`, tree `383716945d2d5f2404578d726afb317e4490c181`, P `b79f7749eb8f0a6c728493adfb073ca7db5563be`, R `87c697343f9d5a465cac7527f2e16933410ccd26`. Original GitHub run `37930392164`, push attempt 1, completed successfully. Each of its original C=1/4/8/16 cells has been received and independently accepted using its own exact source, fresh release feature build, raw 900 outcomes and original counter boundaries.

| Configured C | Actual peak | Read/build overlap | Writer attempts / total ns | Read-pool attempts / total ns | Read-checkout attempts / total ns |
|---|---:|---|---|---|---|
| 1 | 1 | no | 3550 / 177158 | 16850 / 997977 | 16850 / 86362596 |
| 4 | 4 | yes | 3550 / 117172 | 16848 / 901594 | 16848 / 68937811 |
| 8 | 7 | yes | 3550 / 130941 | 16846 / 1015497 | 16846 / 73025045 |
| 16 | 12 | yes | 3550 / 147338 | 16848 / 1040384 | 16848 / 78694013 |

Every cell has 300 successful builds and 600 successful reads, with the original 1000 files, 500 ms offer parameter and C-sized burst schedule. The four distributions are not pooled. All acquisition terminal counters are complete at drained boundaries, with observer-role acquisitions separately retained. Each original raw DB snapshot matches its exact owned product PID and the corresponding original no-SQL status RPC. Original 15-table endpoint parity, Rust statistics double replay, binary/source/observer identity, all 900 raw/stdio payload associations and original seals were reviewed. Read-only replays of the unchanged original Python verifier and acquisition collector returned integer 0; no Rust binary, compiler, native workload or new sample was run.

The original source admission was actually v15 success with previous v14, controls were 10 Rust plus 77 Python tests, and formatting succeeded. Historical expected panic output remains. The source domain has 1094 product and 142 validation inputs; all ten retained observer files match the exact G2 Git blobs, modes and canonical hashes.

The original P8-007 mixed-load DB acquisition-wait evidence omission is filled within this complete G2 diagnostic cohort. This is a feature-enabled observation, not G1/Gc8/main/SQL-G3 performance. Prior component passes retain their original source identity. P8-005/P8-006 remain hard blockers, P8-007 is not marked done, and the original ledger remains 163 done / 29 remaining / 0 new completions.

The times are acquisition-call elapsed including uncontended overhead. Read checkout can include validation or construction. They are not pure scheduler-blocked time or SQLite internal busy/BEGIN waiting; SQLite busy remains unobserved. Process-lifetime maxima remain their original values; interval maxima and interval wait quantiles are unavailable, not subtracted or invented. Report read/build active zeros mean final drained activity. Configured C8/C16 did not imply peaks of 8/16.

This publication selection contains deduplicated selected evidence and all four complete raw operation JSONL files. It is **not** a full-original-ZIP archive. Large original ZIPs, ELF binaries, complete product RPC streams and authored fixtures remain at the exact official artifact locators and original local paths/digests in the manifest and reports. Exact selected DB snapshot RPC lines include byte offsets and whole-stream hashes. Original ZIP member CRC/SHA inventories and unchanged raw receipts are included. Receiver extraction does not claim POSIX metadata equivalence. Prior C4/C8 and C1 pending selections/README facts are preserved as historical snapshots; this final report supplies their later complete-cohort result. Metadata endpoint/save-helper errors are retained and are not classified as original workload failures.
