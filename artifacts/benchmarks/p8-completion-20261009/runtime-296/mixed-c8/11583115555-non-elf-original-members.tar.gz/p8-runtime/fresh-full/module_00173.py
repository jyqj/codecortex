def stable_00173():
    return 173
