def stable_00013():
    return 13
