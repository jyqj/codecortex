def stable_00265():
    return 265
