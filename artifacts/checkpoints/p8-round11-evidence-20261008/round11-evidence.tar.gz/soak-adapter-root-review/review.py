#!/usr/bin/env python3
"""Independent adapter review and historical recorded-RPC replay only."""
from pathlib import Path
import ast
import copy
import datetime
import hashlib
import importlib.util
import json
import zipfile

HERE = Path(__file__).resolve().parent
ADAPTER = Path('/workspace/scratch/2eaa00d0f93a/p8-formal-evidence-G4/soak')
SOURCE = Path('/workspace/scratch/2eaa00d0f93a/p8-G4-exact-source')
PROBE = Path('/dev/shm/p8-soak-cache-real-probe-root/run-01')

def identity(path):
    b = path.read_bytes()
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def main():
    fixed = {
        'inspect.py': 'a9eaa4b0ac030d8b9569d3db5bbea3e9ba624c115bf4ae6966f75320af5add26',
        'cache_wire.py': '63486a0954a6e2d3b12077797e40a3256ce8aa6a179b1233f2947ab3473e4b35',
    }
    for name, digest in fixed.items():
        assert identity(ADAPTER / name)['sha256'] == digest
        ast.parse((ADAPTER / name).read_text())
    plan = json.loads((ADAPTER / 'adapter-plan.json').read_text())
    assert plan['candidate_sha256'] == fixed['inspect.py']
    assert identity(Path(plan['original']))['sha256'] == plan['original_sha256']
    assert plan['source'] == '260f596582f2d82b8d7c707b61a6b8b6a43b069f'
    assert plan['fixed_run'] == 37854847820 and plan['fixed_job'] == 113576447137
    assert not (ADAPTER / 'expected-artifact.json').exists()

    input_names = ['reads.json', 'mutations.json', 'receipt.json', 'product/rpc.jsonl', 'product/process.json']
    before = {name: identity(PROBE / name) for name in input_names}
    reads = json.loads((PROBE / 'reads.json').read_text())
    assert len(reads) == 14
    spec = importlib.util.spec_from_file_location('reviewed_cache_wire', ADAPTER / 'cache_wire.py')
    wire = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(wire)
    with (PROBE / 'product/rpc.jsonl').open() as f:
        requests, responses, times, kinds = wire.transport(json.loads(line) for line in f)
    result = wire.bind_compound_reads(reads, requests, responses, times)
    original_controls = json.loads((ADAPTER / 'cache-wire-controls.json').read_text())
    assert result == original_controls['result']
    assert result['bound_RPCs'] == 56 and result['compound_reads'] == 14
    assert result['role_counts'] == dict(before_status=14, symbol=14, hybrid=14, after_status=14)
    assert len({r['rpc_id'] for r in result['mapping']}) == 56
    assert original_controls['helper_sha256'] == fixed['cache_wire.py']
    assert {c['case'] for c in original_controls['negative_controls']} == {'response', 'timestamp', 'request'}
    assert all(c['rejected'] for c in original_controls['negative_controls'])
    # Independent corruption of a recorded tool result; originals are untouched.
    modified = copy.deepcopy(reads)
    modified[0]['cache_probe']['requests'][2]['response']['_review_corruption'] = True
    try:
        wire.bind_compound_reads(modified, requests, responses, times)
    except ValueError as e:
        rejected = str(e)
    else:
        raise AssertionError('changed original hybrid response was accepted')
    assert before == {name: identity(PROBE / name) for name in input_names}

    runtime = ast.parse((SOURCE / 'scripts/p8_runtime.py').read_text())
    names = {'median', 'rss_trend', 'sample_coverage', 'latency_summary', 'owned',
             'require_stable_symbol', 'cache_identity', 'cache_lookup',
             'require_stable_hybrid', 'validate_cache_probe', 'soak_cache_summary'}
    funcs = [n for n in runtime.body if isinstance(n, ast.FunctionDef) and n.name in names]
    assert {n.name for n in funcs} == names and len(funcs) == len(names)
    summary = next(n for n in funcs if n.name == 'soak_cache_summary')
    assert [a.arg for a in summary.args.args] == ['rows', 'operations', 'start_ns', 'end_ns', 'project']

    result_report = {
        'decision': 'accepted_scoped_G4_soak_adapter_pending_actual_original_run',
        'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'reviewer': 'root; adapter author pr_audit',
        'reviewed_files': {n: identity(ADAPTER / n) for n in ['inspect.py', 'cache_wire.py', 'adapter.diff', 'adapter-plan.json', 'cache-wire-controls.json']},
        'original_adapter': {'path': plan['original'], **identity(Path(plan['original']))},
        'source': plan['source'], 'run_id': plan['fixed_run'], 'job_id': plan['fixed_job'],
        'historical_probe_inputs': before,
        'actual_offline_wire_replay': {'reads': 14, 'RPCs': 56, 'all_four_roles': True,
            'binding_object_equal_to_author_report': True,
            'additional_changed_hybrid_response_rejected': rejected,
            'all_original_inputs_unchanged': True,
            'scope': 'Original G product plus observer 63ad small engineering probe only; not G4 acceptance and not one hour'},
        'review_findings': [
            'Actual fixed attempt/run/job/source/artifact digest and completed job are required before reception.',
            'All ZIP members retain CRC/SHA verification, exact two complete seals and canonical regular paths.',
            'All 1087 recorded production inputs and seven observer copies bind to immutable G4 Git objects; Cargo release identities and retained copies remain exact.',
            '3601 original operation IDs retain 2400 reads and 1201 builds, full hour resource coverage, 200 real branch switches, 25 compactions and all 15 parity tables.',
            'The exact original ValueError require and pure cache-summary functions are extracted without executing the runtime observer or product.',
            'Only exact retained stable fixture bytes are reconstructed in a new owned review directory; original source paths and measurements stay unchanged.',
            'All 9600 compound-read RPCs must bind to exact arguments, complete returned tool JSON, separately byte-verified wire responses, and one common monotonic origin interval.',
            'Status sampler RPCs may interleave; operation IDs are never assumed equal to transport IDs.',
            'Actual-time quarter cache hit/miss/invalidation, complete generation, native PID, exact current source witness and bounded shared query-pool counters are required by original source.',
            'Only the retained Rust statistics executable may run offline against original plan/raw, and its result must match original report bytes.',
            'Per-RPC timeouts and compound one-read denominator are preserved; no invented whole-read SLA, OS-thread identity or semantic-worker claim.',
        ],
        'formal_receiver_executed': False, 'actual_G4_soak_artifact_received': False,
        'product_execution': False, 'Cargo_execution': False, 'new_measurement': False,
        'TODO_closed': 0, 'TODO_remaining': 29,
    }
    out = HERE / 'review.json'
    out.write_text(json.dumps(result_report, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'decision': result_report['decision'], 'review': str(out), **identity(out)}))

if __name__ == '__main__':
    main()
