def stable_00292():
    return 292
