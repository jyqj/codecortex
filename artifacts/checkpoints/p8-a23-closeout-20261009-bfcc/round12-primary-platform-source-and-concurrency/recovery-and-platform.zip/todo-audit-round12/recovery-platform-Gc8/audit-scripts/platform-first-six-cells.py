"""Original portable validator with explicit canonical-R provenance adapter.

Does not invoke any retained ELF/Mach-O, compiler, provider or local Git source
validator. The original producer cold-build/toolchain/stdio assertions are kept.
"""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import json
import hashlib
base = Path.cwd()
sys.path.insert(0, str(base / 'todo-audit-round12/recovery-platform-Gc8'))
from provenance_adapter import (SOURCE, CURRENT, COMMIT, TREE, OUT, R,
                                artifact, digest, json_bytes, observer_from_archive)
import p8_cold_build as cold

# Only the receiver's absent full-checkout Git snapshot is replaced. Each row
# is separately matched to exact canonical R and its Git blob is recomputed.
# The original function body verify_portable_cell, verify_observers and
# validate_smoke all remain the exact archived, SHA-bound source bytes.
cold.observer_snapshot = observer_from_archive
api = OUT / 'historical-source-api'
root = json.loads((api / 'current-root-tree-api.json').read_text())
crates = json.loads((api / 'current-crates-tree-api.json').read_text())
assert root['truncated'] is False and crates['truncated'] is False
assert next(x for x in root['tree'] if x['path'] == 'crates')['sha'] == crates['sha']
rows = [x for x in root['tree'] if x['path'] in ('Cargo.toml', 'Cargo.lock')]
rows += [dict(x, path='crates/' + x['path']) for x in crates['tree'] if x['type'] == 'blob']
git_rows = {x['path']: x for x in rows}
assert set(git_rows) == set(R['complete_inputs'])
pairs = [(11604775379, 11604536450), (11604252892, 11604870476),
         (11604777455, 11604468186), (11605445357, 11605032856),
         (11605395767, 11605640173), (11604784110, 11605515306)]
results = []
for cell_id, raw_id in pairs:
    home, meta = artifact(cell_id)
    raw_home, raw_meta = artifact(raw_id)
    bundle = json.loads((home / 'bundle.json').read_text())
    record = json.loads((home / 'receipt.json').read_text())
    cell = record['cell']
    matrix = json.loads((home / 'matrix.json').read_text())
    actual = {p.relative_to(home).as_posix() for p in home.rglob('*') if p.is_file() and p != home / 'bundle.json'}
    assert actual == set(bundle['files']) and not any(p.is_symlink() for p in home.rglob('*'))
    assert all(digest(home / n) == h for n, h in bundle['files'].items())
    assert bundle['schema_version'] == 2 and bundle['status'] == 'passed'
    assert bundle['live_strict_receipt_and_stdio_replay'] is True and cell == bundle['cell']
    selected = cold.selected_inventory(matrix, cell)
    assert digest(home / 'receipt.json') == selected['receipt_sha256'] == bundle['receipt_sha256']
    assert Path(selected['receipt']).name == 'receipt.json'
    assert str(Path(selected['receipt']).parent / 'target') == record['target_directory']
    assert matrix['source'] == record['source_before'] == record['source_after']
    source = record['source_before']
    assert source['source_commit'] == COMMIT and source['source_tree'] == TREE and source['input_count'] == 1090
    manifest = json.loads((home / 'source-inputs.json').read_text())
    assert len(manifest) == 1090 and [x['path'] for x in manifest] == sorted(git_rows)
    for x in manifest:
        g = git_rows[x['path']]
        assert x == dict(path=x['path'], size=g['size'], sha256=R['complete_inputs'][x['path']], git_blob=g['sha'], git_mode=g['mode'])
        assert x['git_mode'] == R['source_modes'][x['path']]
    assert digest(home / 'source-inputs.json') == hashlib.sha256(json_bytes(manifest)).hexdigest() == source['manifest_sha256']
    assert digest(home / 'codecortex') == bundle['binary_sha256'] == record['binary_sha256']
    cold.verify_portable_cell(record, home, SOURCE, home / 'codecortex')
    cold.validate_smoke(home, record)
    label = '-'.join(cell[k] for k in ('platform', 'toolchain', 'package'))
    raw = raw_home / 'cold' / label
    overlap = 0
    for p in raw.rglob('*'):
        if p.is_file():
            rel = p.relative_to(raw)
            assert (home / rel).is_file() and digest(p) == digest(home / rel), str(rel)
            overlap += 1
    assert overlap == 17
    result = dict(schema_version=1, status='accepted_original_portable_cell_and_stdio_replay',
        source_commit=COMMIT, source_tree=TREE, source_input_count=1090,
        source_manifest_sha256=source['manifest_sha256'], cell=cell,
        rustc_release=record['toolchain']['rustc_release'], host=record['toolchain']['host'],
        binary_sha256=record['binary_sha256'], binary_bytes=record['binary_bytes'],
        cell_artifact_id=cell_id, raw_artifact_id=raw_id,
        cell_zip_digest=meta['digest'], raw_zip_digest=raw_meta['digest'],
        receipt_sha256=digest(home / 'receipt.json'), bundle_sha256=digest(home / 'bundle.json'),
        bundle_files=len(actual), raw_overlap_identical=overlap, wall_seconds=record['wall_seconds'],
        original_validator_source_sha256=digest(SOURCE / 'scripts/p8_cold_build.py'),
        receiver_provenance='Exact canonical R 1090/139 + official Git tree modes/blobs + recomputed observer Git blobs; no full local checkout claim',
        original_native_execution=True, receiver_executed_product=False, todo_status_change=False)
    (OUT / ('cell-' + label + '-audit.json')).write_bytes(json_bytes(result))
    results.append(result)
print(json.dumps(results, indent=2))
