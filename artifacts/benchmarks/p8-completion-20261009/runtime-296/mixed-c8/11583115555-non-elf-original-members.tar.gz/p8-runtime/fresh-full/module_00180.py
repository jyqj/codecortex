def stable_00180():
    return 180
