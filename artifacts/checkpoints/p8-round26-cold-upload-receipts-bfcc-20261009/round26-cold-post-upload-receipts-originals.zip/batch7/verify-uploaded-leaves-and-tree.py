import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path("/workspace/scratch/bfccb8494ba0/cold044-original-intake/increment-50k11-17")
repo=pathlib.Path("/workspace/scratch/bfccb8494ba0/cold044-original-intake/publication-repo.git")
m=json.loads((root/"all-21-leaf-upload-manifest.json").read_text())
r=json.loads((root/"connector-all-21-leaves-originals.json").read_text())
commands=[]
def git(*args,input=None):
    c=["git","--git-dir="+str(repo),*args]
    q=subprocess.run(c,input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={**os.environ,"GIT_NO_LAZY_FETCH":"1","GIT_INDEX_FILE":str(root/"increment-tree-index")})
    commands.append({"argv":c,"exit_code":q.returncode,"stdout":q.stdout.decode(),"stderr":q.stderr.decode()})
    if q.returncode: raise RuntimeError(commands[-1])
    return q.stdout
assert len(m["entries"])==21 and len({e["path"] for e in m["entries"]})==21
remote={e["path"]:e for e in r["small"]+r["large"]}
assert len(remote)==21
for e in m["entries"]:
    b=pathlib.Path(e["local_path"]).read_bytes()
    assert len(b)==e["bytes"] and hashlib.sha256(b).hexdigest()==e["sha256"]
    assert hashlib.sha1(b"blob "+str(len(b)).encode()+bytes([0])+b).hexdigest()==e["sha"]
    assert remote[e["path"]]["sha"]==remote[e["path"]]["response"]["structuredContent"]["sha"]==e["sha"]
    assert git("hash-object","-w","--",e["local_path"]).decode().strip()==e["sha"]
git("read-tree",m["parent_tree"])
payload=b"".join((e["mode"]+" "+e["type"]+" "+e["sha"]+"\t"+e["path"]).encode()+bytes([0]) for e in m["entries"])
git("update-index","-z","--index-info",input=payload)
tree=git("write-tree").decode().strip()
delta=git("diff-tree","--no-commit-id","--name-status","-r",m["parent_tree"],tree).decode().splitlines()
assert sorted(delta)==sorted("A\t"+e["path"] for e in m["entries"])
request={"repository_full_name":"jyqj/codecortex","base_tree":m["parent_tree"],"tree_elements":[{k:e[k] for k in ["path","mode","type","sha"]} for e in m["entries"]]}
(root/"create-tree-request.json").write_text(json.dumps(request,indent=2)+"\n")
result={"schema":"cold-original-intake-publication-bridge-v1","parent":m["parent"],"parent_tree":m["parent_tree"],"expected_tree":tree,"leaf_count":21,"delta":delta,"all_server_oid_matches":True,"remote_ref_changed":False,"new_product_execution":False,"commands":commands}
(root/"local-tree-and-server-oid-bridge.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({k:result[k] for k in ["parent","expected_tree","leaf_count","all_server_oid_matches","remote_ref_changed"]}))
