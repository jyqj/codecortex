# Third-round scale and execution-history evidence review

**Verdict: retained evidence is consistent; the 10k control is incomplete and does not complete a TODO.**

Product: `df140ad1dc97f080afd748e9571b360e0cade5fe`
Review: `b2a6c135444ef61d629cac1d739b120c8a3158d2`
Executed corrected source: `363de9201cc99faed793dda050874fb31afcde56`

## Same-plan 10k control

| Evidence | Original | Corrected |
| --- | --- | --- |
| Entire command exit | 2 | 3 |
| Report status | measurement_failed | deadline_exceeded |
| Command wall time | 23.633 s | 301.172 s |
| Configured deadline | 300000 ms | 300000 ms |
| Full builds completed | 0 | 2 |
| Files parsed in each completed build | — | 10000 |
| Symbols / chunks in each completed build | — | 55620 / 63619 |
| Completed cold parity | none | none |
| Full 100k / release certification | not_run | not_run |

The original first build failed with `reexport_file_budget_exceeded`. The corrected source crosses that failure point and completes two full builds without parse errors. Its entire control still exceeds the unchanged deadline, and the report has a null summary. Individual `resolution_freshness.complete` fields in build reports do not establish oracle parity or control completion.

The plan files are byte-identical. The retained inventory contains the same 10000 generated files plus one visible configuration file in both runs. BLAKE3 values for plans, raw logs, full input inventory, Cargo.lock and runtime source provenance were independently recomputed from retained bytes and immutable Git objects. The raw inventory digest uses the actual FileRecord field order.

All 798 `crates/**`, `Cargo.toml` and `Cargo.lock` input paths and SHA-256 values at corrected execution source `363de920` exactly match published product `df140ad1`. The recorded compile succeeds at that source, the source stays unchanged across compile and execution, and the current corrected binary matches the raw/report digest.

The supervisor cleaned the generated fixture. This review verifies the retained evidence; it does not regenerate the fixture or run the product. No parity result is retained, so the exact internal operation interrupted after the second build is not established.

## Execution-history recovery

The bundle contains exactly 9 refs, is 80318 bytes, and has SHA-256 `d1eb9b6c8cb82dd5f5c77250b91cef826629333493c913a5648e37b4c97a293f`. A fresh bare repository first rejected the missing immutable base, then successfully restored all refs after fetching only base `9f6684ac81fa82f2bc99903ff42fb532478c2aaf`. Each restored commit matched the original raw commit bytes, parent/tree identity and complete source Git inventory. `git fsck --full --strict --no-reflogs --no-dangling` succeeded. No alternates or source worktree were used for restoration.

The bundle intentionally requires the fixed base; it preserves exact local execution/source checkpoints despite different API-generated publication commit metadata. Preservation does not create a new test-pass receipt.

## Records

| Record | SHA-256 |
| --- | --- |
| `scale-10k-independent-evidence-review.json` | `ce927fb28eea7b9a5fd08028e25814ace63be00af99ef878c590da86d8c84ea1` |
| `executed-history-independent-review.json` | `d96512ea9ccbc3503368f487386b4103eadca8d80bd9bd872a1c618d0be5a92b` |
| `verify_scale10k_raw_evidence.py` | `50214c6182d55d97c9679ce573c70def3d3de0512f8ae736cc8c66636ee01a20` |

The published R review blob was independently checked against the frozen source review: SHA-256 `8a900584ff4ec4c3e86ba2a65b52a6d37909bb0c3bea66793448fbb9351e20e2`, exact bytes equal. New PR head, three workflow terminal states and mergeability will be reported in a separate observation once available.
