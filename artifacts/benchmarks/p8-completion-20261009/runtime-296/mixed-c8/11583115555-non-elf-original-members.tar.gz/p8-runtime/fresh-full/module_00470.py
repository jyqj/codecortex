def stable_00470():
    return 470
