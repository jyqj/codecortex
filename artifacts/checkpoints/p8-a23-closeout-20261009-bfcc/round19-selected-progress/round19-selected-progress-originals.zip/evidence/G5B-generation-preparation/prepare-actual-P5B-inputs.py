#!/usr/bin/env python3
"""Read-only tree/hash reconstruction. No product, test, network or Git mutation."""
from pathlib import Path
import hashlib,json,ast,copy
HERE=Path(__file__).resolve().parent
OLD=Path('/dev/shm/todo-audit-b2-G3-forward-plan')
FIX=Path('/dev/shm/execution-recon-recovery-20261009/PR180-preselect-format-fix-P5B')
def digest(b): return hashlib.sha256(b).hexdigest()
def oid(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def save(name,x): (HERE/name).write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
response=json.loads((HERE/'P5B-official-tool-response.json').read_text());assert not response['isError']
p=json.loads(response['structuredContent']['content'])
assert p['sha']=='d21e140ca9ebb5a73294358d64a839466c5a0076'
assert p['tree']['sha']=='7fb46257805e9da89737ef7a6a05574b83f50d79'
assert [x['sha'] for x in p['parents']]==['b2a17adc188338c48b95d01761836916e5d0fcdb']
save('P5B-official-commit.json',p)
# Reuse only the already-retained read-only reconstruction prefix. It has no save calls.
script=(OLD/'derive-nonloss-plan.py').read_text().split("sql_paths = ",1)[0]
tree=ast.parse(script)
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='save' for n in ast.walk(tree))
namespace={'__file__':str(OLD/'derive-nonloss-plan.py')}
exec(compile(tree,'<retained-b2-full-tree-reconstruction>','exec'),namespace)
leaves=copy.deepcopy(namespace['b2']);tree_oid=namespace['tree_oid']
assert tree_oid(leaves)=='8e82c2c60188148f91c2c8bfa58c1e158a94b8af'
compare=json.loads((OLD/'official-H-to-b2-compare.json').read_text())
seed_paths={
 'scripts/reviewed-source-registry-v15.json':('reviewed-source-registry-v15.json','seed-b2-registry.json'),
 'scripts/verify_reviewed_source_v15.py':('verify_reviewed_source_v15.py','seed-b2-guard.py')}
seed_receipts={}
for path,(old,new) in seed_paths.items():
 b=(OLD/'b2-original-bindings'/old).read_bytes()
 assert oid(b)==leaves[path]['sha']
 assert next(x['sha'] for x in compare['files'] if x['filename']==path)==oid(b)
 (HERE/new).write_bytes(b)
 seed_receipts[path]={'local_path':str(HERE/new),'bytes':len(b),'sha256':digest(b),'git_blob':oid(b),'mode':leaves[path]['mode']}
registry=json.loads((HERE/'seed-b2-registry.json').read_text())
assert [len(registry[k]) for k in ('complete_inputs','delta','validation_inputs')]==[1095,71,142]
path='crates/cc-search/src/preselect.rs'
before=(FIX/'original'/path).read_bytes();after=(FIX/'candidate'/path).read_bytes()
assert oid(before)==leaves[path]['sha']=='acee54f9100c012f18affae077aea92fdad97591'
assert digest(before)==registry['complete_inputs'][path]=='a3aea905493d4204cf00209a53918175e2b31b84eed643b76ea19c09bcb011bb'
assert oid(after)=='3d2daf9788173cb6fee2cb91350ea5c425e3e2a0'
assert digest(after)=='33fe2debd14d37f224ae8df56536bf3cfc697c0fb7f1ddde571a4298c85b2eea'
leaves[path]={**leaves[path],'sha':oid(after)}
assert tree_oid(leaves)==p['tree']['sha']
maps={'source':p['sha'],'source_tree':p['tree']['sha'],'ordered_parents':[x['sha'] for x in p['parents']],'base':registry['base_source'],'scope':'Actual P5B mechanically reconstructed full tree and complete maps; independent review and execution remain separate.','complete_inputs':copy.deepcopy(registry['complete_inputs']),'paths':copy.deepcopy(registry['delta']),'validation_inputs':copy.deepcopy(registry['validation_inputs'])}
maps['complete_inputs'][path]=digest(after);maps['paths'][path]['sha256']=digest(after)
prospective=json.loads((FIX/'prospective-P5B-complete-product-validation-inputs.json').read_text())
for key in ('complete_inputs','paths','validation_inputs'): assert maps[key]==prospective[key]
inventory={q:{**leaves[q],'sha256':h} for q,h in sorted((maps['complete_inputs']|maps['validation_inputs']).items())}
assert inventory==prospective['actual_input_mode_blob_inventory']
assert len(inventory)==1237
save('actual-P5B-mechanical-input-maps.json',maps)
save('actual-P5B-1237-mode-blob-input-map.json',inventory)
receipt={'actual_P5B':p['sha'],'actual_tree':p['tree']['sha'],'ordered_parents':maps['ordered_parents'],'actual_b2_tree':'8e82c2c60188148f91c2c8bfa58c1e158a94b8af','full_tree_reconstruction_equal_to_official':True,'tree_leaf_count':len(leaves),'counts':{'complete_product':1095,'BASE_delta':71,'validation':142,'input_mode_blob':1237},'changed_product_paths':[path],'validation_changes':[],'seeds':seed_receipts,'runtime_test_execution':'not_run','independent_R5B':None,'actual_R5B':None,'generated_G5B':None,'G4_SQL_not_introduced':True}
save('actual-P5B-tree-and-input-bridge.json',receipt)
print(json.dumps(receipt,sort_keys=True))
