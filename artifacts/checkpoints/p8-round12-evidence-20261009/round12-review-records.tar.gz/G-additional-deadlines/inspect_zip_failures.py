"""Read original failed raw through a CRC-checked ZIP stream, without extraction."""
import collections
import json
import sys
import types
import zipfile
from pathlib import Path

if sys.flags.optimize:
    raise SystemExit("optimized Python disables review assertions")
sys.dont_write_bytecode = True
sys.path.insert(0, "/workspace/scratch/2eaa00d0f93a/codecortex-scale-replay-G/scripts")
import p8_scale_matrix as matrix

HOME = Path(__file__).resolve().parent
BUILD = Path("/workspace/scratch/2eaa00d0f93a/p8-scale-actions-37830173594/artifacts/p8-scale-build-37830173594")
build = matrix.read_json(BUILD / "build.json")
source = matrix.read_json(BUILD / "source-before.json")
assert source == matrix.read_json(BUILD / "source-after.json")
assert matrix.file_sha256(BUILD / "p8-scale") == build["binary_sha256"]

class OriginalZipRaw:
    """The original inspector only needs the verified member size and rb open."""
    def __init__(self, archive):
        self.archive = archive
    def stat(self):
        return types.SimpleNamespace(st_size=self.archive.getinfo("native/raw.jsonl").file_size)
    def open(self, mode):
        assert mode == "rb"
        return self.archive.open("native/raw.jsonl")

for artifact, index in ((11588031517, 5), (11587609884, 3), (11587698572, 2), (11588316178, 9)):
    metadata = matrix.read_json(HOME / f"{artifact}-zip-inspection.json")
    path = HOME / f"{artifact}.zip"
    assert matrix.file_sha256(path) == metadata["zip_sha256"]
    with zipfile.ZipFile(path) as archive:
        def read(name):
            data = archive.read(name)
            import hashlib
            assert hashlib.sha256(data).hexdigest() == metadata["members"][name]["sha256"]
            return matrix.decode(data)
        receipt = read("shard.json")
        before = read("source-before.json")
        matrix.validate_snapshot(before)
        assert before == read("source-after.json") == source
        assert receipt["source_commit"] == "bb9a96d71622458c39a143055360cc97f0d11d78"
        assert receipt["build_receipt_sha256"] == matrix.file_sha256(BUILD / "build.json")
        for key in ("source_manifest_sha256", "binary_sha256", "binary_blake3", "driver_source"):
            assert receipt[key] == build[key]
        plan = matrix.registered_plan(100000, index, 30, 30, 12648430, 18000000, "scale_capacity_v1")
        assert plan == receipt["plan"] == read("registered-plan.json") == read("native/plan.json")
        assert receipt["capacity_contract"] == matrix.capacity_contract()
        native = read("native/report.json")
        assert receipt["status"] == "failed" and receipt["exit_code"] == 3
        assert native["status"] == "deadline_exceeded" and native["exit_code"] == 3
        assert native["worker_binary_unchanged"] is True
        assert native["worker_binary_digest_before"] == native["worker_binary_digest_after"] == build["binary_blake3"]
        try:
            matrix.inspect_raw(OriginalZipRaw(archive), plan)
        except ValueError as error:
            rejection = str(error)
        else:
            raise AssertionError("Incomplete failed raw was accepted")
        assert rejection == "missing registered mutation stages"
        events = collections.Counter()
        complete = []
        started = {}
        tail = collections.deque(maxlen=5)
        engine = None
        with archive.open("native/raw.jsonl") as raw:
            while line := raw.readline(matrix.MAX_LINE_BYTES + 1):
                assert len(line) <= matrix.MAX_LINE_BYTES
                event = matrix.decode(line)
                kind = event["event"]
                events[kind] += 1
                if kind == "run_started": engine = event["engine"]
                if kind in ("cold_parity", "stage_finished"):
                    matrix.check_parity(event["parity"], plan)
                    complete.append(event.get("sample", event.get("label")))
                if kind == "build_started": started[event["label"]] = event
                if kind == "build_finished": del started[event["label"]]
                tail.append({k: event[k] for k in ("event", "label", "full", "start_us", "end_us", "wall_us", "complete", "passed") if k in event})
        assert engine["engine_head_observed"] == build["source_commit"]
        assert engine["binary_digest"] == build["binary_blake3"] and engine["eval_debug_assertions"] is False
        result = {"artifact_id": artifact, "shard": index, "source": receipt["source_commit"],
            "status": "deadline_exceeded_not_certified", "original_raw_rejection": rejection,
            "transport": "Original inspector unmodified; rb stream and stat size supplied by fully SHA/CRC-verified ZIP member.",
            "no_native_execution": True, "source_before_after_build_equal": True,
            "raw_sha256": metadata["members"]["native/raw.jsonl"]["sha256"],
            "zip_sha256": metadata["zip_sha256"], "event_counts": dict(events),
            "complete_parity_groups": complete, "unfinished_builds": list(started.values()),
            "last_events": list(tail), "native_report": native, "TODO_closed": 0}
    assert matrix.file_sha256(path) == metadata["zip_sha256"]
    destination = HOME / f"{artifact}-raw-inspection.json"
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"artifact_id": artifact, "status": result["status"], "completed_groups": len(complete),
        "groups": complete, "unfinished_builds": result["unfinished_builds"], "sha256": matrix.file_sha256(destination)}))
