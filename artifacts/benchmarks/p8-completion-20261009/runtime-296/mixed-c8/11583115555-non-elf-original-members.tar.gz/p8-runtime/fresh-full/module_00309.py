def stable_00309():
    return 309
