"""Prove and remove only this completed C16 RAM transport/extraction/replay view."""
import datetime, hashlib, json, pathlib, shutil, stat, zipfile
B=pathlib.Path(__file__).resolve().parent
A=B/'artifacts/11611524778'
R=pathlib.Path('/dev/shm/a217aaae3bde/C3ff-round30-intake')
D=R/'artifacts/11611524778/extracted'
E=json.loads((A/'actual-acceptance-execution.json').read_text())
P=json.loads((A/'preflight-and-extraction.json').read_text())
C=A/'ram-derived-reclamation-candidate.json'
X=A/'ram-derived-reclamation-execution.json'
assert not C.exists() and not X.exists()
assert E['status']=='accepted_scoped_original_C_mixed'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def ss(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink()
 return dict(bytes=s.st_size,sha256=sha(p),mode=stat.S_IMODE(s.st_mode),inode=s.st_ino,device=s.st_dev,nlink=s.st_nlink,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,allocated_bytes=s.st_blocks*512)
z=A/'11611524778.zip';assert sha(z)==P['zip_sha256']==E['original_zip_sha256_after']
before={x['path']:x for x in P['extraction']['extracted_files']};assert len(before)==2129
rows=[]
with zipfile.ZipFile(z) as archive:
 infos=[i for i in archive.infolist() if not i.is_dir()]
 assert len(infos)==2129 and {i.filename for i in infos}==set(before)
 for i in infos:
  p=D/i.filename;s=ss(p)
  with archive.open(i) as f:h=hashlib.file_digest(f,'sha256').hexdigest()
  assert s['sha256']==h==before[i.filename]['sha256'] and s['bytes']==i.file_size==before[i.filename]['bytes']
  assert s['mode']==0o444 and s['nlink']==1
  rows.append(dict(path=str(p),original_zip=str(z),original_member=i.filename,zip_external_mode=i.external_attr>>16,**s))
preserved=[z,A/'artifact-metadata.json',A/'private-transfer.json',A/'actual-acceptance-execution.json',A/'preflight-and-extraction.json',A/'acceptance-manifest.json']
preserved += list(A.glob('*.stdout'))+list(A.glob('*.stderr'))+[pathlib.Path(p) for p in E['helper_inputs_after']]
preserved += [B/'helpers-C3ff-v1/adaptation-manifest.json',B/'run_mixed_c16_round30_ram_once.py',pathlib.Path(__file__).resolve()]
for pair in E['storage_mapping']['copies']:
 p=pathlib.Path(pair['ram_copy']);original=pathlib.Path(pair['original']);s=ss(p)
 assert s['bytes']==original.stat().st_size==pair['bytes'] and s['sha256']==sha(original)==pair['sha256'] and s['mode']==0o444 and s['nlink']==1
 rows.append(dict(path=str(p),original_copy=str(original),**s));preserved.append(original)
for pair in E['retained_output_copies']:
 p=pathlib.Path(pair['original_ram_output']);original=pathlib.Path(pair['workspace_preserved_output']);s=ss(p)
 assert s['bytes']==original.stat().st_size==pair['bytes'] and s['sha256']==sha(original)==pair['sha256'] and s['mode']==stat.S_IMODE(original.stat().st_mode) and s['nlink']==1
 rows.append(dict(path=str(p),original_copy=str(original),**s));preserved.append(original)
assert len(rows)==2139
files={pathlib.Path(row['path']) for row in rows}
dirs={parent for path in files for parent in path.parents if parent!=R and R in parent.parents}
assert {p for p in R.rglob('*')}==files|dirs
assert all(p.is_dir() and not p.is_symlink() for p in dirs)
protected={str(p):ss(p) for p in sorted(set(preserved))}
record=dict(schema='C16-RAM-exact-derived-candidate-v1',root=str(R),files=rows,protected_before=protected,
 source_receipt_sha256=sha(A/'actual-acceptance-execution.json'),original_zip_sha256=sha(z),
 original_file_count=2129,transport_copy_count=2,preserved_replay_output_count=8,
 activity='Original helper exited0. No task reader/writer or future dependency on this RAM view. No system-wide process claim.',
 authorization='Root authorized existing CLI RAM view and byte-preserved result return before own derived cleanup. Only these exact files/directories selected.',
 created_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
C.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');protected[str(C)]=ss(C)
assert {p for p in R.rglob('*')}==files|dirs
for row in rows:assert ss(pathlib.Path(row['path']))=={k:v for k,v in row.items() if k not in ('path','original_zip','original_member','zip_external_mode','original_copy')}
for path,s in protected.items():assert ss(pathlib.Path(path))==s
receipt=dict(schema='C16-RAM-exact-derived-execution-v1',candidate=str(C),candidate_sha256=sha(C),selected_files=len(rows),selected_bytes=sum(row['bytes'] for row in rows),protected_before=protected,status='verified_before_unlink',started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),ram_free_before=shutil.disk_usage(R).free)
X.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
for row in rows:
 p=pathlib.Path(row['path']);assert ss(p)=={k:v for k,v in row.items() if k not in ('path','original_zip','original_member','zip_external_mode','original_copy')};p.unlink()
for p in sorted(dirs,key=lambda p:len(p.parts),reverse=True):p.rmdir()
R.rmdir()
after={path:ss(pathlib.Path(path)) for path in protected};assert after==protected
receipt.update(status='only_exact_RAM_derived_view_removed',protected_after=after,all_protected_stat_and_bytes_unchanged=True,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),ram_free_after=shutil.disk_usage(R.parent).free)
X.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
for p in (C,X):print(json.dumps(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))))
