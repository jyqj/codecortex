def stable_00425():
    return 425
