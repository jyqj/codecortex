def stable_00356():
    return 356
