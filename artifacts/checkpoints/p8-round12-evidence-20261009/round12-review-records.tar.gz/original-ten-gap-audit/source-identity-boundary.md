对固定 8e 的源码关系判断：原合同没有规定“P8-005 换了 Git SHA，P8-007～013/016 就一律从头全量重跑”。它也没有允许把不同实现的通过报告只列一张差异表，就拼成同一最终候选已经完整认证。应分开处理原始证据的历史有效性、单项任务的适用验收范围、最终 G8 候选认证。

依据均来自未修改的原仓库合同，而不是本次另设门：

- tasks.json 的 P8-001 要求冻结 binary/config/corpus/scoring/model/环境；接受原文为“每份报告精确回到同一候选，后续改动使对应证据失效”。“对应”约束受变更影响的证据；不能无依据解释成全部历史记录消失，也不能解释成只要源码审过就自动迁移全部运行结论。
- 08-HANDOFF.md 第 32 行明确“任务完成数不等同发布认证；以各任务证据和适用验证范围为准”。第 50 行要求历史通过先与当前源码核对，再按原验收补齐独立复核。第 94 行要求 target_sha、worktree_digest、commands、exit codes、run_id/artifact paths、review、rollback_status，且 done 需对应 V 的全部适用项通过。第 107 行要求当前目标 SHA 的真实证据。
- 06-VALIDATION.md 第 15 行区分当前精确 stdio 构建的 L3 与 release runner 的 L5；V01/V02 第 23–24 行要求实际 SHA/binary/toolchain 和输入拒漂移；V20 第 42 行是规模、并发、资源、无 best-of 的运行验证。
- 09-BENCHMARK.md 第 130 行锁 engine SHA、binary digest、profile/features 与环境；第 173 行区分 release 性能与 debug/test 标签。任何旧报告不能改写成新引擎或新二进制运行。
- 06-VALIDATION.md 第 58–61 行把全量 release profile、当前 run-id 证据与 blocker=0 放在 G8 整体。不能把这个整体门偷加成每个单独011/016任务必须release/tagged版本；也不能绕过它认证最终发行。
- 原 `p8_release_review.py` 第 219–232 行对 G8 record 明确检查 candidate_source_different、candidate_input_digest_different 与 scoped_engineering_only。这是最终候选总评的实际合同，不是允许异源记录直接作为同源 release pass。
- v15 guard 的身份 scope 是 independently_reviewed_source_and_validation_inputs，runtime_and_quality_claims 明确 require_separate_execution_evidence。它验证独审、完整 source/validation bytes 与历史链；没有授予运行结果跨源码继承的能力。

因此，G4 已完整接收的 lifecycle、gate negatives 和 recovery/rollback 继续是 G4 的真实、有效、范围明确的原始证据。新 8e 出现不会把它们改成失败，也不需要为了保存历史结论重跑旧 G4。它们可以进入后续单项任务复核的证据集合，但现在仍不能自动将这些任务记 done：原硬依赖尚未关闭，而且还需按最终选定实现核对各 V 的适用部分。只称“G4 某域已实测通过”是成立的；称“8e 某域实测通过”则必须有实际 8e 或严格证明适用的当前验证，保留原运行身份。

单项任务可以包含来自多个固定 SHA 的不同历史及当前证据，而非强行抹平成一个假 SHA；但独审须逐条说明哪些仍适用、哪些已被变更影响以及补做了什么验证。**仅有差异说明，不等于已经证明跨源适用。** 最终 G8/发行按现有 collector 的精确候选输入要求收口；不能拿这一单项证据组织方式来绕过同一候选总评。

针对 G4→8e 的实际四个文件，三个 cached SQL 调用确实改变写路径的 statement 生命周期，另外两个文件扩展测试。完整1087生产字节不相同，不能沿用先前 D0→P5/G4 的全输入相等桥。

| 域 | 原 G4 证据仍能证明什么 | 当前 8e 适用性边界 |
|---|---|---|
| 005/006规模与阶段 | 原 G4/D0 运行的完整或失败结果 | 新规模研究必须锁自己的真实 source/binary；不得替换原缺片。新8e未完成正式150。 |
| 007 mixed、008冷建/热查、009资源、010soak | G4 原负载、分层、资源与长稳观测 | 写调用进入构建/修改路径，可能改变时间、排队、prepared statement内存；静态 SQL 相同与41功能回归不能证明这些新运行量，受影响的当前候选性能/资源/长稳结论需要新证据。不能因为 hot query 代码未改就假定整机观测完全相同。 |
| 011/016故障与回滚 | G4 原真实 crash、版本对、拒绝/恢复过程及 dev 标签 | 8e 的失败后 statement 复用和事务回滚有新41控中的相关实际回归；是否足以继承某条旧场景需明确映射原故障点与调用路径。原完整故障场景不能只凭源码差异变成8e执行，亦不额外要求全部旧场景无差别重跑或将dev改release。 |
| 012冷构建 | G4 已实际完成的原平台/toolchain/feature cold cells | 8e 可编译性只在真正运行的对应平台/toolchain/features成立；原G48格不能直接叫8e8格。剩余G4格未完成仍是缺口。 |
| 013失败退出门 | G4 原未修改gate算法、实际CLI非零及raw保留行为 | 这是最适合逐输入/依赖影响审查后继承的域；仍保留G4binary/receipt身份，核新集成是否改变被测CLI路径，并满足原旧功能回归。没有一条规则要求只因无关生产blob变化就重造所有故障fixture。 |

建议下一次 canonical source review 增加“历史证据适用性”逐条映射，而非一句全继承：原 target/run/hash、验证场景、实际变更调用边界、继承理由、当前补验证 receipt、剩余 not_run。这是一种满足现有证据字段与适用验证要求的整理方法，不是新增评分、阈值或豁免。是否可以最终关闭某个 task 要看该项完整证据和硬依赖，不能从本次源码准入草稿直接推导。

本次没有执行 Cargo、产品或新测试，没有修改原任务、源 guard 或任一原运行记录。新增 done 为0，仍29项未完成。
