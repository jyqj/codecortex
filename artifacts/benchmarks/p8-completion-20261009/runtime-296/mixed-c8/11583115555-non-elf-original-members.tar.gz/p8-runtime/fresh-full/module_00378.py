def stable_00378():
    return 378
