from pathlib import Path
import subprocess,datetime,json,hashlib,time
b=Path(__file__).resolve().parent;pfx=b/'execution-attempt01';pfx.mkdir(exist_ok=False);cmd=['python3',str(b/'validate-original-GW4-build.py')];s=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
with (pfx/'stdout').open('xb') as out,(pfx/'stderr').open('xb') as err:p=subprocess.run(cmd,cwd=b,stdout=out,stderr=err)
r={'argv':cmd,'cwd':str(b),'started_at':s,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-t,'exit_code':p.returncode,'stdout_bytes':(pfx/'stdout').stat().st_size,'stdout_sha256':hashlib.sha256((pfx/'stdout').read_bytes()).hexdigest(),'stderr_bytes':(pfx/'stderr').stat().st_size,'stderr_sha256':hashlib.sha256((pfx/'stderr').read_bytes()).hexdigest()};(pfx/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');(pfx/'exit-code.txt').write_text(str(p.returncode)+'\n');print(json.dumps(r));raise SystemExit(p.returncode)
