import collections,datetime,hashlib,json,pathlib,stat,zipfile
B=pathlib.Path('/workspace/scratch/a217aaae3bde');OUT=B/'scale-pr173-review';D=B/'recovered-originals/artifacts/11615980558';ZIP=D/'11615980558.zip';STATE=B/'scale-review-37896198208/state.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
state_raw=STATE.read_bytes();state=json.loads(state_raw);meta=json.loads((D/'artifact-metadata.json').read_bytes());assert meta['id']==11615980558 and meta['workflow_run']['id']==37896198208 and meta['workflow_run']['head_sha']==state['source_commit'];assert ZIP.stat().st_size==meta['size_in_bytes']==5210430 and 'sha256:'+sha(ZIP.read_bytes())==meta['digest']
members={};counts=collections.Counter();started={};finished={};stages=[];last=None;run=None;cold=None
with zipfile.ZipFile(ZIP) as z:
 assert len(z.infolist())==len(set(z.namelist()))==12
 for info in z.infolist():
  p=pathlib.PurePosixPath(info.filename);assert not p.is_absolute() and '..' not in p.parts and not info.is_dir() and not stat.S_ISLNK(info.external_attr>>16)
  h=hashlib.sha256();n=0
  with z.open(info) as f:
   while block:=f.read(1024*1024):h.update(block);n+=len(block)
  assert n==info.file_size;members[info.filename]={'bytes':n,'sha256':h.hexdigest()}
 shard=json.loads(z.read('shard.json'));report=json.loads(z.read('native/report.json'));plan=json.loads(z.read('native/plan.json'));source=json.loads(z.read('source-before.json'))
 for p,v in shard['files'].items():assert members[p]==v
 assert z.read('native/plan.json')==z.read('registered-plan.json') and plan==shard['plan']
 assert z.read('source-before.json')==z.read('source-after.json') and members['source-before.json']['sha256']==state['source_snapshot_sha256']
 for key in ['source_commit','source_manifest_sha256','binary_sha256','binary_blake3','build_receipt_sha256','driver_source']:assert shard[key]==state[key]
 assert source['input_count']==1089 and source['manifest_sha256']==state['source_manifest_sha256'] and source['source_commit']==state['source_commit']
 assert sha((pathlib.Path(state['build_directory'])/'build.json').read_bytes())==state['build_receipt_sha256']
 assert report['worker_binary_digest_before']==report['worker_binary_digest_after']==state['binary_blake3']
 assert report['status']=='deadline_exceeded' and report['exit_code']==shard['exit_code']==3 and shard['status']=='failed' and report['summary'] is None
 assert plan['deadline_ms']==18000000 and plan['max_output_bytes']==536870912 and plan['repetitions']==30 and plan['shard']=={'count':30,'index':0} and plan['files']==[100000]
 for line in z.open('native/raw.jsonl'):
  x=json.loads(line);event=x['event'];counts[event]+=1;last=x
  if event=='run_started':run=x
  elif event=='build_started':assert x['label'] not in started;started[x['label']]=x
  elif event=='build_finished':assert x['label'] not in finished;finished[x['label']]=x
  elif event=='cold_parity':cold=x
  elif event=='stage_finished':stages.append(x)
 assert run['engine']['engine_head_observed']==state['source_commit'] and run['engine']['binary_digest']==state['binary_blake3'] and run['plan']==plan
 assert set(finished)<=set(started)
 incomplete=[started[k] for k in started if k not in finished]
 compact_stages=[{k:x[k] for k in ['label','passed','complete','full_complete','incremental_builds','incremental_wall_us','parity_wall_us'] if k in x}|{'parity_equal':x['parity']['equal'],'parity_table_count':len(x['parity']['tables'])} for x in stages]
 disk={n:json.loads(z.read(n)) for n in ['disk-preflight.json','disk-after.json']}
 negatives={'schema':'historical-275e-failed100k-original-evidence-review-v1','reviewer':'/root/scale_closeout','reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':state['source_commit'],'source_manifest_sha256':state['source_manifest_sha256'],'source_input_count':1089,'run_id':37896198208,'attempt':1,'job_id':113710393672,'artifact':meta,'original_zip':ref(ZIP),'all_twelve_original_members':members,'original_job_log':ref(OUT/'failed100k-original-job.log'),'build_state':ref(STATE),'identity_checks':{'source_before_after_exact_registered_build_snapshot':True,'source_driver_binary_and_build_receipt_bind_to_existing_accepted_build_state':True,'registered_plan_exact':True,'report_binary_before_after_equal':True,'source_state_changed':False},'native_report':report,'capacity_contract':shard['capacity_contract'],'disk_observations':disk,'raw_event_counts':dict(counts),'completed_stage_records':compact_stages,'cold_parity_present':cold is not None,'incomplete_builds':incomplete,'last_raw_event':last,'failure_facts':{'supervisor_status':'deadline_exceeded','native_supervisor_exit_code':3,'driver_job_exit_code':1,'worker_exit_code':report['worker_exit_code'],'summary':report['summary'],'stderr_complete':report['stderr_complete'],'entire_child_lifetime_deadline_ms':18000000,'wall_ms':report['wall_ms'],'fixture_cleanup':report['fixture_cleanup']},'interpretation':{'last_fully_finished_stage':'batch_1','unfinished_next_operation':'batch_10 full_control build has start event and no finish event before the deadline','not_established':['specific unfinished full-build internal subphase','OOM or resource-exhaustion cause','current C3ff timing or outcome','full100k parity completion','statistical sample completion'],'disk_scope':'Registered capacity estimates and endpoint free space observations only; no peak or sufficiency proof.'},'acceptance':{'failed_artifact_accepted_as_success':False,'accepted_shards_remain':4,'accepted_samples_remain':41,'required_shards':150,'required_samples':1500,'full_study':'failed preflight; final aggregate pending at last collection','native_or_helper_reexecution':False,'originals_extracted':False,'task_status_changed':False,'remaining_todos':29}}
 assert STATE.read_bytes()==state_raw
 out=OUT/'historical-173-failed100k-original-evidence-review.json';raw=(json.dumps(negatives,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode();out.open('xb').write(raw);print(json.dumps(ref(out)));print(json.dumps({'event_counts':dict(counts),'unfinished':incomplete,'stage_labels':[x['label'] for x in stages]}))
