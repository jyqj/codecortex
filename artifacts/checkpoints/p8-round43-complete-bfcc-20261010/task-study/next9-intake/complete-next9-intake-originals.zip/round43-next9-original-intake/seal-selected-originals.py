import pathlib,json,hashlib,zipfile,datetime
from record_child_once import inspect_recorded_stdio
R=pathlib.Path('/workspace/scratch/bfccb8494ba0');D=pathlib.Path(__file__).resolve().parent;S=D/'sealed';S.mkdir()
def rd(p):return json.loads(p.read_text())
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def meta(p):
 b=p.read_bytes();return {'local_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'mode':'100644'}
t=rd(D/'terminal.json');assert t['accepted_cells']==9 and t['failed_cells']==0 and t['accepted_records']==18
custody=[inspect_recorded_stdio(pathlib.Path(x['receipt_directory'])) for x in t['records']]
dump(D/'stdio-preseal-custody-check.json',{'checks':custody,'all_complete':all(x['custody_complete'] for x in custody),'validator_reexecuted':False})
assert all(x['custody_complete'] for x in custody),'stdio custody fault before sealing'
catalog=[]
for x in t['records']:
 A=pathlib.Path(x['receipt_directory']);v=rd(A/'original-validate-shard-return.json');calls=rd(A/'native-hash-subprocess-originals.json');assert len(calls)==2 and all(c['returncode']==0 for c in calls)
 catalog.append({'slot':x['slot'],'artifact':x['artifact'],'whole_zip':x['whole_zip'],'original_result':meta(A/'original-validate-shard-return.json'),'execution_receipt':meta(A/'original-validator-execution.json'),'exit_code':x['validator_exit'],'record_count':len(v['measurements']),'record_roles':['setup','mutation'],'record_groups':[m['group'] for m in v['measurements']],'record_sample_labels':[m['sample'] for m in v['measurements']],'environment':v['environment'],'native_hash_calls':len(calls),'original_shard_directory':x['shard_directory'],'original_task_receipt_sha256':v['receipt_sha256']})
report={'schema':'next9-original-task-shards-intake-review-v1','recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'receiver':'execution_recon','authorship_boundary':'Receiver authored the task driver; this records unchanged original validation execution, not self-approval of the source or an independent semantic peer. pr_triage independently reviews the records.','source':t['source'],'source_tree':'39a053ae49b486764751a570d164e7cd41d7ff29','run_id':t['run_id'],'attempt':t['attempt'],'protocol':'p8-profile-task-descriptive-v1','stage_scope':'profile_task_descriptive_v1','verdict':'accepted_9_original_cells_scoped','counts':{'new_cells':9,'accepted_cells':9,'failed_cells':0,'setup_records':9,'mutation_records':9,'fanout_records':0,'accepted_records':18,'cumulative_accepted_cells':27,'cumulative_accepted_records':54,'registered_total_cells':45,'registered_total_records':85,'preselected_no_op_cold_points':4,'remaining_cells':18,'remaining_records':31},'catalog':catalog,'original_function':'p8_task_profile_matrix.validate_shard(directory, outer_build, built, binary, build_directory, root=source_root)','original_validate_shard_calls':9,'original_validate_build_calls':0,'native_hash_utility_calls':18,'all_hash_utility_returncodes_zero':True,'native_hash_raw_stdout_stderr_preserved':True,'source_build_index_before_after_equal':True,'new_stdio_before_seal_all_equal':True,'previous_batch_stdout_custody_boundary':'Prior first12 api1k zero file remains unchanged and separately recovered by independent peer b0c2bf92ba9a9bdc6ebd7b089ffe520d147db81d. New batch uses raw subprocess outputs plus independent copies; old validator not rerun.','all_new_shard_inputs_before_after_equal':True,'all_original_validator_stderr_empty':all(x['execution']['stderr']['bytes']==0 for x in t['records']),'original_outer_execution_exit':0,'original_first_child_started':t['records'][0]['execution']['started_at_utc'],'original_last_child_completed':t['records'][-1]['execution']['completed_at_utc'],'accepted_build_reused':{'source_directory':str(R/'round42-new45-build-original-intake/source-exact-G2'),'build_directory':str(R/'round42-new45-build-original-intake/original-build'),'tuple':meta(R/'round42-new45-build-original-intake/validation-attempt01/original-validate-build-return.json'),'actual_build_intake_review_blob':'767527f7cccf372e6ca1dd866466d6bf66c86da3','actual_build_intake_support_blob':'79d96014710c2172b8bd17053d2a559144ec6003'},'transport':{'new_whole_ZIPs':9,'new_complete_member_CRC_reads_per_ZIP':1,'old_ZIP_or_old_slot_rereads':0,'whole_ZIP_custody_owner':'root','whole_ZIP_bodies_in_this_support':False,'safe_path_and_duplicate_and_symlink_checks':True,'raw_native_data_retained_in_original_ZIPs':True},'semantic_scope':'Original predicates checked emitted complete native plan/raw/summary, closure, typed fifteen-table parity, build/driver/binary/source/run/attempt, resources and temporary environment. No predicates altered. Each original return retained in full.','aggregate_executed':False,'stable_tail_or_pooled_statistics':False,'native_measurement_or_compilation_locally_executed':False,'old_study_or_diagnostic_samples_added':False,'task_credit':0,'ref_or_PR_or_label_mutations':False,'frozen_root_custody_pending_record':'Original pending metadata retains its earlier actual_blob:null fields; Root records publication separately.'}
dump(D/'next9-original-intake-review.json',report)
paths=[]
for p in sorted(D.rglob('*')):
 if not p.is_file() or S in p.parents or '__pycache__' in p.parts:continue
 if 'original-shard' in p.parts:
  if p.name not in ['task-shard.json','report.json','worker-summary.json','registered-plan.json']:continue
 paths.append(p)
# Current original input metadata is already in the selected batch; root publishes whole ZIP bytes separately.
rows=[]
for p in paths:
 m=meta(p);m['archive_path']=p.relative_to(R).as_posix();rows.append(m)
selection={'schema':'selected-next9-original-task-intake-v1','files':rows,'source':t['source'],'run_id':t['run_id'],'attempt':t['attempt'],'original_ZIPs_external':True,'source_and_build_support_external':True}
dump(S/'archive-selection.json',selection)
with zipfile.ZipFile(S/'complete-next9-intake-originals.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for m in rows:
  info=zipfile.ZipInfo(m['archive_path'],date_time=(2026,10,10,0,0,0));info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,pathlib.Path(m['local_path']).read_bytes())
 info=zipfile.ZipInfo('archive-selection.json',date_time=(2026,10,10,0,0,0));info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,(S/'archive-selection.json').read_bytes())
leaves=[]
for p in [D/'next9-original-intake-review.json',S/'complete-next9-intake-originals.zip',S/'archive-selection.json']:
 m=meta(p);m.update(repository_path='artifacts/checkpoints/p8-round43-complete-bfcc-20261010/task-study/next9-intake/'+p.name,actual_created=False);leaves.append(m)
manifest={'files':leaves,'support_members':len(rows)+1,'source':t['source'],'run_id':t['run_id'],'attempt':t['attempt'],'refs_updated':False};dump(S/'upload-manifest.pending.json',manifest);print(json.dumps(manifest,indent=2))
