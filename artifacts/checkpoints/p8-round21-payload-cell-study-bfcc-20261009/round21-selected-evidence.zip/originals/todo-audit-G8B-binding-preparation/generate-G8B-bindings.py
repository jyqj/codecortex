#!/usr/bin/env python3
"""Generate two v15 binding files only after actual P8B and independent R8B exist.
This author-side mechanical tool cannot create or sign an independent review.
It does not run the original source verifier or claim any runtime/task result.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
BASE = "7354db236c9d9850a75f31672697ae9eab44565e"
EXPECTED_PRODUCT = "44e6248106335b5f0625e53de38f76d26aeeadcf"
EXPECTED_PRODUCT_PARENT = "8831de11bc8d33735b665efda6c8aa511e4f1660"
EXPECTED_PRODUCT_TREE = "6ade2b570e0d1bba09cf3f70ed6a1522c3c05e2b"
EXPECTED_REVIEW_PATH = "artifacts/checkpoints/p8-immutable-payload-cell-witness-bfcc-20261009/independent-source-review.json"
EXPECTED_COUNTS = {"product": 1095, "delta": 75, "validation": 142}
PINS = ("PRODUCT", "REVIEW", "REVIEW_PATH", "REGISTRY_SHA256")
AUTHORS = {"/root", "root", "/root/execution_recon"}  # Root oracle and execution_recon payload-change authors.
NEW_VALIDATION = set()
CHANGED_VALIDATION = set()
SEED_G = "88d5f547bb0fae273f4270742503fd1fd5e70bc2"
SEED_REGISTRY_SHA256 = "014e27e873b1aec0a43b75716725e6677fdcc4ed4410801aa0d3b3df39716cac"
SEED_GUARD_SHA256 = "ece23073d226892662d36de6204eff1eaea7a8fec791e176f783c13000a07829"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git_blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def required(condition, message):
    if not condition:
        raise ValueError(message)

def immutable(value):
    return isinstance(value, str) and re.fullmatch("[0-9a-f]{40}", value) is not None

def read_json(path):
    return json.loads(path.read_bytes())

def prepare(args):
    inputs = read_json(args.product_inputs)
    product_metadata = read_json(args.product_commit_file)
    review_metadata = read_json(args.review_commit_file)
    product = inputs.get("source")
    product_tree = inputs.get("source_tree", inputs.get("tree"))
    review_commit = review_metadata.get("sha")
    required(immutable(product) and immutable(product_tree) and immutable(review_commit),
             "Actual immutable P/tree/R metadata is required; null and placeholders are rejected")
    required(product == EXPECTED_PRODUCT and product_tree == EXPECTED_PRODUCT_TREE,
             "This prepared generator binds only the observed actual integrated P8B")
    required(product_metadata.get("sha") == product
             and product_metadata.get("tree", {}).get("sha") == product_tree,
             "P identity must equal the observed official product commit")
    required([v.get("sha") for v in product_metadata.get("parents", [])] == [EXPECTED_PRODUCT_PARENT],
             "Actual two-leaf P8B must have the fixed actual P7B as sole parent")
    parent_metadata = read_json(HERE / "P7B-official-commit.json")
    required(parent_metadata.get("sha") == EXPECTED_PRODUCT_PARENT
             and [v.get("sha") for v in parent_metadata.get("parents", [])] == [SEED_G],
             "The retained P7B parent must have actual G6B as its sole parent")
    required([v.get("sha") for v in review_metadata.get("parents", [])] == [product],
             "Actual R must have this actual P as its sole parent")
    counts = {"product": len(inputs["complete_inputs"]), "delta": len(inputs["paths"]),
              "validation": len(inputs["validation_inputs"])}
    required(counts == EXPECTED_COUNTS, "Wrong combined product/delta/validation counts")
    required(inputs.get("base") == BASE, "Historical BASE must remain unchanged")
    required(all(set(v) == {"before_sha256", "sha256"} for v in inputs["paths"].values()),
             "Review deltas must retain the original two-key schema")
    review_path = args.review_path
    required(review_path == EXPECTED_REVIEW_PATH, "Wrong final canonical review artifact path")
    required(review_path.startswith("artifacts/checkpoints/")
             and review_path.endswith("/independent-source-review.json")
             and ".." not in Path(review_path).parts and not Path(review_path).is_absolute(),
             "An actual canonical review artifact path is required")

    raw = args.review_file.read_bytes()
    review = json.loads(raw)
    required(review.get("source") == product and review.get("base") == BASE,
             "Review must bind this actual P and original BASE")
    required(review.get("verdict") == "accepted_scoped"
             and review.get("scope") == "independently_reviewed_source_and_validation_inputs",
             "A real non-author scoped source review is required")
    reviewers = review.get("independent_reviewers")
    required(isinstance(reviewers, list) and bool(reviewers)
             and all(isinstance(v, str) and v.strip() for v in reviewers),
             "Missing actual independent reviewers")
    required(reviewers == ["/root/pr_triage"],
             "Bind actual independently signed R8B; the reviewer did not author the six product changes")
    reviewer_ids = {v.split(":", 1)[0].strip() for v in reviewers}
    required(not AUTHORS.intersection(reviewer_ids),
             "The integration/fix author cannot sign this independent R")
    required(review.get("unresolved_blockers") == [],
             "Independent source blockers are unresolved or unspecified")
    required(review.get("paths") == inputs["paths"], "All 75 exact deltas must match actual P")
    required(review.get("complete_inputs") == inputs["complete_inputs"],
             "All 1095 exact product hashes must match actual P")
    required(review.get("validation_inputs") == inputs["validation_inputs"],
             "All 142 exact validation hashes must match actual P")
    if "source_tree" in review:
        required(review["source_tree"] == product_tree, "Wrong reviewed product tree")
    required(re.fullmatch("[0-9a-f]{64}", args.review_sha256) is not None
             and sha(raw) == args.review_sha256, "Actual canonical R8B SHA256 must be supplied and match")
    required(immutable(args.review_git_blob) and git_blob(raw) == args.review_git_blob,
             "Canonical review bytes must equal the actual installed R Git blob")

    required(sha((HERE / "seed-G6B-registry.json").read_bytes()) == SEED_REGISTRY_SHA256
             and sha((HERE / "seed-G6B-guard.py").read_bytes()) == SEED_GUARD_SHA256,
             "Seeds must be the exact actual G6B binding bytes")
    registry = read_json(HERE / "seed-G6B-registry.json")
    before_validation = registry["validation_inputs"]
    new_validation = set(inputs["validation_inputs"]) - set(before_validation)
    changed_validation = {p for p in before_validation
                          if inputs["validation_inputs"].get(p) != before_validation[p]}
    required(new_validation == NEW_VALIDATION and changed_validation == CHANGED_VALIDATION,
             "Combined validation domain must contain zero additions/removals/hash changes relative to actual G6B")
    expected_changes = {entry["path"]: entry for entry in inputs["six_changes"]}
    required(len(expected_changes) == 6, "Exactly six independently reviewed P8B changes are required")
    required(inputs["complete_inputs"].keys() == registry["complete_inputs"].keys()
             and {path for path in inputs["complete_inputs"]
                  if inputs["complete_inputs"][path] != registry["complete_inputs"][path]}
                 == set(expected_changes), "Exactly the six reviewed product hashes may change from G6B")
    for path, entry in expected_changes.items():
        required(registry["complete_inputs"][path] == entry["before"]["sha256"]
                 and inputs["complete_inputs"][path] == entry["after"]["sha256"],
                 "P8B change must bind exact G6B preimage and accepted candidate bytes: " + path)
    new_delta_paths = set(inputs["paths"]) - set(registry["delta"])
    required(new_delta_paths == {
        "crates/cc-db/src/freshness_store.rs",
        "crates/cc-db/tests/p2c_freshness_store.rs",
        "crates/cc-index/src/project_model/mod.rs"}, "Only three BASE-identical paths become new deltas")
    required(set(registry["delta"]) <= set(inputs["paths"]), "No existing BASE delta may disappear")
    for path, previous in registry["delta"].items():
        current = inputs["paths"][path]
        required(current["before_sha256"] == previous["before_sha256"],
                 "Every original BASE before hash must remain identical: " + path)
        if path not in expected_changes:
            required(current == previous, "Unchanged product delta must remain byte-identical: " + path)
    for path in new_delta_paths:
        required(inputs["paths"][path] == {
            "before_sha256": registry["complete_inputs"][path],
            "sha256": inputs["complete_inputs"][path]}, "New BASE delta is not exact: " + path)
    old_registry = dict(registry)
    registry.update(product_source=product, review_source=review_commit,
                    review_sha256=sha(raw), complete_inputs=inputs["complete_inputs"],
                    delta=inputs["paths"])
    allowed_registry = {"product_source", "review_source", "review_sha256",
                        "complete_inputs", "delta"}
    required({k for k in old_registry.keys() | registry.keys()
              if old_registry.get(k) != registry.get(k)} == allowed_registry,
             "Exactly the five necessary registry fields must change; validation remains original")
    registry_raw = (json.dumps(registry, indent=2, sort_keys=True) + "\n").encode()

    guard_before = (HERE / "seed-G6B-guard.py").read_text()
    guard = guard_before
    values = {"PRODUCT": product, "REVIEW": review_commit,
              "REVIEW_PATH": review_path, "REGISTRY_SHA256": sha(registry_raw)}
    for name, value in values.items():
        guard, count = re.subn("^" + name + r' = "[^"]*"$',
                               name + " = " + json.dumps(value), guard, flags=re.M)
        required(count == 1, "Expected one original pin: " + name)
    normalize = lambda text: re.sub(
        r"^(PRODUCT|REVIEW|REVIEW_PATH|REGISTRY_SHA256) = .*$",
        r"\1 = <PIN>", text, flags=re.M)
    required(normalize(guard) == normalize(guard_before),
             "Original guard changed beyond its four identity pins")
    before_lines, after_lines = guard_before.splitlines(), guard.splitlines()
    required(len(before_lines) == len(after_lines), "Guard line count changed")
    changed = [a.split(" = ")[0] for a, b in zip(before_lines, after_lines) if a != b]
    required(set(changed) == set(PINS) and len(changed) == 4,
             "Expected exactly four changed pin lines")
    receipt = {
        "stage": "G8B", "actual_G": None,
        "scope": "Mechanical G8B binding generation from actual P8B and actual non-author R8B only",
        "product": product, "product_tree": product_tree, "base": BASE, "seed_G": SEED_G,
        "review": review_commit, "review_path": review_path,
        "review_bytes": len(raw), "review_sha256": sha(raw), "review_git_blob": git_blob(raw),
        "actual_reviewers": reviewers, "counts": counts,
        "new_validation": sorted(new_validation), "changed_validation": sorted(changed_validation),
        "changed_guard_lines": changed,
        "actual_changed_registry_fields": sorted(allowed_registry),
        "changed_product_paths": sorted(expected_changes),
        "added_BASE_delta_paths": sorted(new_delta_paths),
        "registry_bytes": len(registry_raw), "registry_sha256": sha(registry_raw),
        "registry_git_blob": git_blob(registry_raw),
        "guard_bytes": len(guard.encode()), "guard_sha256": sha(guard.encode()),
        "guard_git_blob": git_blob(guard.encode()),
        "review_or_source_admission_signed_by_this_generator": False,
        "original_v15_actual_execution_remains_separate": True,
        "Rust_runtime_performance_or_TODO_credit": False,
    }
    return registry_raw, guard.encode(), receipt

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--product-inputs", type=Path, required=True)
    p.add_argument("--product-commit-file", type=Path, required=True)
    p.add_argument("--review-file", type=Path, required=True)
    p.add_argument("--review-commit-file", type=Path, required=True)
    p.add_argument("--review-path", required=True)
    p.add_argument("--review-git-blob", required=True)
    p.add_argument("--review-sha256", required=True)
    targets = p.add_mutually_exclusive_group(required=True)
    targets.add_argument("--output-directory", type=Path)
    targets.add_argument("--verify-existing-directory", type=Path)
    args = p.parse_args()
    registry, guard, receipt = prepare(args)
    if args.verify_existing_directory:
        target = args.verify_existing_directory
        required((target / "scripts/reviewed-source-registry-v15.json").read_bytes() == registry,
                 "Installed registry differs from generated bytes")
        required((target / "scripts/verify_reviewed_source_v15.py").read_bytes() == guard,
                 "Installed guard differs from four-pin generated bytes")
        receipt["mode"] = "read_only_existing_byte_comparison"
    else:
        target = args.output_directory
        required(not target.exists(), "Output must be a new directory; never overwrite old source")
        (target / "scripts").mkdir(parents=True)
        (target / "scripts/reviewed-source-registry-v15.json").write_bytes(registry)
        (target / "scripts/verify_reviewed_source_v15.py").write_bytes(guard)
        receipt["mode"] = "new_staging_directory_only"
        (target / "generation-receipt.json").write_text(
            json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(json.dumps(receipt, sort_keys=True))

if __name__ == "__main__":
    main()
