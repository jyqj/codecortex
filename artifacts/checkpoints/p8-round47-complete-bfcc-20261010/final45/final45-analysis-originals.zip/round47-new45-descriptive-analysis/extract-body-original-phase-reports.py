"""Read each accepted raw once for report attribution; no protocol implementation import."""
import pathlib,json,hashlib,collections,datetime
R=pathlib.Path('/workspace/scratch/bfccb8494ba0');D=pathlib.Path(__file__).resolve().parent
catalog=json.loads((R/'round46-final45-catalog-and-aggregate-preparation/accepted-43-original-receipt-custody-catalog.json').read_text())
extra_dir=R/'round47-batch100-100k-original-intake'
extra_report=json.loads((extra_dir/'batch100-100k-original-intake-review.json').read_text())
extra_manifest=json.loads((extra_dir/'sealed/upload-manifest.actual.json').read_text())
extra_leaf=next(x for x in extra_manifest['files'] if x['local_path'].endswith('/batch100-100k-original-intake-review.json'))
for cell in extra_report['catalog']:
    catalog['ordered_cells'].append(dict(cell,accepted_report={k:extra_leaf[k] for k in ['git_blob','repository_path','sha256']},whole_custody={'artifact':cell['artifact'],'whole_zip':cell['whole_zip'],'actual_original_byte_custody_owner':'root; final catalog joins separately'}))
facts={('api',100000,0):R/'round46-api-100k-original-intake/original-api-mutation-closure-facts.json',('config',100000,0):R/'round46-config-100k-original-intake/original-config-mutation-closure-facts.json',('batch_1000',100000,0):R/'round46-batch1000-100k-original-intake/original-batch1000-mutation-closure-facts.json',('batch_100',100000,0):extra_dir/'original-batch100-mutation-closure-facts.json'}
keys=['elapsed_ms','files_parsed','files_updated','files_scanned','files_skipped','parse_errors','dirty_plan','resolution_freshness','build_timing','phase_timing','document_changes','project_model']
def selected(report):return {k:report[k] for k in keys if k in report}
def pointer(line,b,path):return {'line':line,'original_line_bytes':len(b),'original_line_sha256':hashlib.sha256(b).hexdigest(),'json_pointer':path}
def counts(reports):
    out={'original_report_count':len(reports),'sum_scope':'Counts summed over emitted reports, including repeated work; not unique files.'}
    for k in ['files_parsed','files_updated','files_scanned','files_skipped']:
        values=[x['report'].get(k) for x in reports]
        out[k+'_sum']=sum(values) if values and all(type(x) is int for x in values) else None
        if out[k+'_sum'] is None:out[k+'_availability']='No reports or at least one original field missing; not zero.'
    values=[x['report'].get('dirty_plan',{}).get('selected_dependents') for x in reports]
    out['selected_dependents_sum']=sum(values) if values and all(type(x) is int for x in values) else None
    resumed=[x['report'].get('dirty_plan',{}).get('resumed') for x in reports]
    out['resumed_true_report_count']=sum(x is True for x in resumed) if resumed and all(type(x) is bool for x in resumed) else None
    for position,index in [('first',0),('last',-1)]:
        out[position+'_freshness']=reports[index]['report'].get('resolution_freshness') if reports else None
        out[position+'_dirty_plan']=reports[index]['report'].get('dirty_plan') if reports else None
    return out
terminal=json.loads((R/'round47-body-100k-original-intake/terminal.json').read_text())
x=terminal['records'][0]
catalog['ordered_cells']=[dict(slot=x['slot'],original_shard_directory=x['shard_directory'],accepted_report={'original_validator_execution':str(R/'round47-body-100k-original-intake/body-100000-0/original-validator-execution.json'),'original_validate_shard_exit':x['validator_exit'],'report_pending_seal':True},whole_custody={'artifact':x['artifact'],'whole_zip':x['whole_zip'],'actual_byte_custody_owner':'root'} )]
for c in catalog['ordered_cells']:
    slot=tuple(c['slot']);path=pathlib.Path(c['original_shard_directory'])/'native-shard/native/raw.jsonl'
    target=D/('phase-facts-'+slot[0]+'-'+str(slot[1])+'.json')
    if target.exists():raise RuntimeError('Refuse repeated extraction/overwrite '+str(target))
    old=None;reuse={}
    if slot in facts:
        p=facts[slot];b=p.read_bytes();old={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
        reuse={x['line']:x for x in json.loads(b)['records'] if x['event'] in ['build_finished','stage_finished']}
    groups=collections.defaultdict(list);events=[];seen=collections.Counter();reused=0
    with path.open('rb') as stream:
        for number,b in enumerate(stream,1):
            if number in reuse:
                x=reuse[number]
                assert len(b)==x['original_line_bytes'] and hashlib.sha256(b).hexdigest()==x['original_line_sha256']
                seen[x['event']]+=1;reused+=1
                if x['event']=='build_finished':groups['mutation'].append({'label':x['label'],'full':False,'wall_us':x.get('wall_us'),'report':x['report_fields'],'provenance':{**{k:x[k] for k in ['line','original_line_bytes','original_line_sha256']},'json_pointer':'/report','reused_fact_path':old['path']}})
                else:events.append({'event':'stage_finished','role':'mutation','original':{k:v for k,v in x.items() if k not in ['line','original_line_bytes','original_line_sha256']},'provenance':{**{k:x[k] for k in ['line','original_line_bytes','original_line_sha256']},'json_pointer':'','reused_fact_path':old['path']}})
                continue
            e=json.loads(b);kind=e['event'];seen[kind]+=1
            if kind=='build_finished':
                label=e['label']
                role='mutation' if not e['full'] else ('setup_full_control' if label.endswith('/cold_full_control') else ('mutation_full_control' if label.endswith('/full_control') else 'setup'))
                groups[role].append({'label':label,'full':e['full'],'wall_us':e['wall_us'],'report':selected(e['report']),'provenance':pointer(number,b,'/report')})
            elif kind in ['cold_parity','stage_finished']:
                parity=e.get('parity',{});original={k:v for k,v in e.items() if k!='parity'}
                original['parity']={k:parity[k] for k in ['equal','status','different_tables','tables','limits','canonical_bytes','scratch_peak_bytes','oracle_mode','capacity_profile'] if k in parity}
                events.append({'event':kind,'role':'setup' if kind=='cold_parity' else 'mutation','original':original,'provenance':pointer(number,b,'')})
            elif kind=='fanout_finished':
                result=e['result'];initial=result.get('initial_evidence',{})
                for k in ['incremental_report','full_report']:
                    if k in initial:groups['fanout_setup_'+k].append({'report':selected(initial[k]),'provenance':pointer(number,b,'/result/initial_evidence/'+k)})
                for j,cp in enumerate(result.get('checkpoints',[])):
                    for k,report in enumerate(cp.get('reports',[])):groups['fanout'].append({'report':selected(report),'provenance':pointer(number,b,f'/result/checkpoints/{j}/reports/{k}')})
                    if 'full_report' in cp:groups['fanout_full_control'].append({'report':selected(cp['full_report']),'provenance':pointer(number,b,f'/result/checkpoints/{j}/full_report')})
                events.append({'event':kind,'role':'fanout','original':{k:v for k,v in e.items() if k!='result'},'result_flags':{k:result.get(k) for k in ['passed','failure_signature','tables']},'initial_evidence_flags':{k:initial.get(k) for k in ['equal','runtime_config','resource_scope']},'checkpoints':[{'status':cp.get('status'),'settle_required':cp.get('settle_required'),'different_tables':cp.get('different_tables'),'truth':cp.get('truth'),'incremental_tables':list(cp.get('incremental',{})),'full_tables':list(cp.get('full',{}))} for cp in result.get('checkpoints',[])],'provenance':pointer(number,b,'')})
    out={'schema':'original-phase-reports-derived-for-descriptive-output-v1','slot':list(slot),'source':catalog['source'],'run_id':catalog['run_id'],'attempt':1,'original_raw_path':str(path),'original_acceptance':c['accepted_report'],'original_whole_custody':c['whole_custody'],'previous_fact_source':old,'previous_fact_records_reused':reused,'original_event_counts':dict(seen),'report_groups':dict(groups),'count_summaries':{k:counts(v) for k,v in groups.items()},'completion_and_parity_events':events,'scope':'One read-only report extraction from already accepted raw. No ZIP/CRC/ELF, original validation or measurement. Original absent fields stay unavailable; no new predicate or task credit.'}
    with target.open('x') as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'slot':slot,'groups':{k:len(v) for k,v in groups.items()},'reused':reused,'output':str(target)}),flush=True)
receipt={'exit_code':0,'source':catalog['source'],'run_id':catalog['run_id'],'attempt':1,'accepted_slots_analyzed':len(catalog['ordered_cells']),'original_raw_files_read_once':len(catalog['ordered_cells']),'original_validator_calls':0,'ELF_calls':0,'ZIP_CRC_calls':0,'measurements':0,'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (D/'body-phase-extraction-receipt.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
