def stable_00132():
    return 132
