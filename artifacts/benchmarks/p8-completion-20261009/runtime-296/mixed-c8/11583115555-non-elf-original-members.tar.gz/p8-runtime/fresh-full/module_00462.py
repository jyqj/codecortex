def stable_00462():
    return 462
