def stable_00337():
    return 337
