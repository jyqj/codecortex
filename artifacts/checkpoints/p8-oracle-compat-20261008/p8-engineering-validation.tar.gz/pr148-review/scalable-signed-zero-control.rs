use cc_eval::benchmark::oracle;
use rusqlite::{params, Connection};
use std::path::Path;

fn fixture(root: &Path, value: f64) {
    std::fs::create_dir_all(root.join(".codecortex")).unwrap();
    let db = Connection::open(root.join(".codecortex/index.sqlite3")).unwrap();
    for table in oracle::tables() {
        db.execute_batch(&format!("CREATE TABLE \"{table}\"(value)")).unwrap();
    }
    db.execute("INSERT INTO symbols VALUES (?1)", params![value]).unwrap();
}

fn main() {
    let a = tempfile::tempdir().unwrap();
    let b = tempfile::tempdir().unwrap();
    fixture(a.path(), -0.0);
    fixture(b.path(), 0.0);
    let legacy_a = oracle::canonical(a.path()).unwrap();
    let legacy_b = oracle::canonical(b.path()).unwrap();
    let report = oracle::compare_streaming(a.path(), b.path(), oracle::StreamingLimits::default()).unwrap();
    println!("legacy_equal={}", legacy_a == legacy_b);
    println!("legacy_a_symbols={:?}", legacy_a["symbols"]);
    println!("legacy_b_symbols={:?}", legacy_b["symbols"]);
    println!("streaming_equal={}", report["equal"]);
    println!("different_tables={}", report["different_tables"]);
    assert_eq!(legacy_a, legacy_b);
    assert_eq!(report["equal"], false);
}
