#!/usr/bin/env python3
"""Reconstruct immutable Git evidence; this is not a runner disk observation."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/71bc431c4e4f/codecortex-historical-v2')
OUT = Path(__file__).resolve().parent
SOURCE = 'b951f27d3ed50b7755bc2456c6425355f753ec17'
PR_HEAD = 'eb7cdc55aa94c8d6865bed14fa37fff08080af33'
PRODUCT = '7b1650c1f6475843d568b2649ff84ec9bdd0e613'
OLD_SOURCE = '5af7ac0089ee7522e78ff2ce2468f881c8cf70f2'
TASK_PATH = 'docs/roadmap/code-index-v2/tasks.json'

def git(*args, data=None):
    return subprocess.check_output(['git', *args], cwd=ROOT, input=data)

def jbytes(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def blob(ref, path):
    return git('show', ref + ':' + path)

def inventory(ref):
    rows = {}
    for entry in git('ls-tree', '-r', '-z', ref, '--', 'crates', 'Cargo.toml', 'Cargo.lock').split(b'\0'):
        if entry:
            meta, path = entry.split(b'\t', 1)
            mode, kind, oid = meta.decode().split()
            assert kind == 'blob' and mode in ('100644', '100755')
            rows[path.decode()] = {'mode': mode, 'git_blob': oid}
    return rows

def main():
    rows = inventory(SOURCE)
    assert len(rows) == 776
    assert rows == inventory(PR_HEAD) == inventory(PRODUCT)
    ids = list(dict.fromkeys(row['git_blob'] for row in rows.values()))
    raw = git('cat-file', '--batch', data=('\n'.join(ids) + '\n').encode())
    offset, contents = 0, {}
    for oid in ids:
        end = raw.index(b'\n', offset)
        actual, kind, length = raw[offset:end].decode().split()
        assert actual == oid and kind == 'blob'
        size, start = int(length), end + 1
        body = raw[start:start + size]
        offset = start + size
        assert len(body) == size and raw[offset:offset + 1] == b'\n'
        offset += 1
        contents[oid] = body
    assert offset == len(raw)
    for row in rows.values():
        body = contents[row['git_blob']]
        row.update(sha256=digest(body), bytes=len(body))
    mapping = {path: row['sha256'] for path, row in sorted(rows.items())}
    map_sha = digest(jbytes(mapping))
    assert map_sha == 'baf2bd238706a0fd88b91c80357d1780415afd5b917ef56d4bf283f3932e8ee6'
    parents = git('show', '-s', '--format=%P', SOURCE).decode().strip().split()
    tree = git('rev-parse', SOURCE + '^{tree}').decode().strip()
    assert parents == ['6d02d77f018a5965a6f289b0b43558ed4b9f8322', PR_HEAD]
    assert tree == git('rev-parse', PR_HEAD + '^{tree}').decode().strip()
    old_receipt = OUT.parent / 'p7-013-acceptance-reconciliation-20261007.json'
    receipt_raw = old_receipt.read_bytes()
    assert digest(receipt_raw) == '941b8026b13928c487aef858ef1bdda3441391d0c2ae79b10afcfc02a4b1fc52'
    receipt = json.loads(receipt_raw)
    authorities = {}
    for label, row in receipt['authority_files'].items():
        raw = blob(SOURCE, row['path'])
        authorities[label] = {'path': row['path'], 'sha256': digest(raw),
                              'same_as_original_reconciliation': digest(raw) == row['sha256']}
    assert [key for key, row in authorities.items() if not row['same_as_original_reconciliation']] == ['legacy_workflow']
    old_workflow = blob('149aa04f24ddcfd02c3aa5626a59343e88d74866', '.github/workflows/ci.yml')
    expected_workflow = old_workflow.replace(b'p7-engineering-20261007-v8', b'p7-engineering-20261007-v9').replace(
        b'python3 scripts/verify_fixed_e3_integration.py', b'python3 scripts/verify_historical_integrations_v2.py')
    assert expected_workflow == blob(SOURCE, '.github/workflows/ci.yml')
    original58 = json.loads((OUT.parent / 'ci-pr144-p7-run37653732468/original58-source-comparison.json').read_text())
    comparison = {path: {'sha256': digest(blob(SOURCE, path)),
                         'byte_identical_to_original_5af7': blob(SOURCE, path) == blob(OLD_SOURCE, path)}
                  for path in original58}
    assert len(comparison) == 13 and all(row['byte_identical_to_original_5af7'] for row in comparison.values())
    tasks_raw = blob(SOURCE, TASK_PATH)
    tasks = json.loads(tasks_raw)
    task = next(row for row in tasks['tasks'] if row['id'] == 'P7-013')
    immutable_task = {key: value for key, value in task.items() if key not in ('status', 'evidence', 'implementation_notes')}
    original_tasks = json.loads(blob('886f90a542a6174a037c79eebbb4f74848fb1f53', TASK_PATH))
    original_task = next(row for row in original_tasks['tasks'] if row['id'] == 'P7-013')
    immutable_original = {key: value for key, value in original_task.items()
                          if key not in ('status', 'evidence', 'implementation_notes')}
    assert immutable_task == immutable_original
    # The prior reconciliation projects the contractual fields; its seven omitted
    # plan metadata fields are independently included in the full baseline check.
    assert {key: immutable_task[key] for key in receipt['original_task_conditions']} == receipt['original_task_conditions']
    assert task['status'] == 'in_progress'
    result = {'schema_version': 1, 'reviewer': '/root/ci_history_review',
              'evidence_kind': 'independent_immutable_git_reconstruction_not_runner_disk_manifest',
              'source_commit': SOURCE, 'source_tree': tree, 'source_parents': parents,
              'PR_head': PR_HEAD, 'PR_head_entire_tree_equal_main': True,
              'crate_inputs': len(rows), 'crate_manifest_sha256': map_sha,
              'same_complete_inventory_and_git_blobs_as_reviewed_product': PRODUCT,
              'files': rows, 'original_58_source_comparison': comparison,
              'authority_comparison': authorities,
              'legacy_workflow_only_two_explicit_v9_migrations': True,
              'P7_013_original_conditions_unchanged': True,
              'current_task_sha256': digest(tasks_raw),
              'current_P7_012_dependency': next(row['status'] for row in tasks['tasks'] if row['id'] == 'P7-012'),
              'current_P7_013_status': task['status'],
              'current_counts': {status: sum(row['status'] == status for row in tasks['tasks']) for status in ['done', 'todo', 'in_progress', 'blocked']},
              'unrecorded_runner_binary_digest': None,
              'runner_execution_evidence': 'separately bound by actual main workflow logs; not asserted by this Git reconstruction'}
    (OUT / 'git-source-binding.json').write_bytes(jbytes(result))
    print(json.dumps({key: result[key] for key in ['source_commit', 'source_tree', 'crate_inputs', 'crate_manifest_sha256', 'P7_013_original_conditions_unchanged', 'current_counts']}))

if __name__ == '__main__':
    main()
