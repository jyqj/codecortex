def stable_00116():
    return 116
