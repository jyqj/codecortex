def stable_00111():
    return 111
