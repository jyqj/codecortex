def stable_00464():
    return 464
