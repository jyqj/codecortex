from pathlib import Path
import json,sys
r=Path('/workspace/independent-boundary-review');x=json.loads((r/'comparison.json').read_text());print(x['verdict'],len(x['direct_failures']),'wrapped-comparison boundary failures');
for p in x['direct_failures']:print(p['query'],'expected',p['expected_owner_bonus_permitted'],'actual',p['actual_owner_bonus_permitted'])
sys.exit(1 if x['verdict']=='REJECT' else 0)
