"""Custody-only host helper; never retries or changes the original validator."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


def byte_meta(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def write_exclusive(path, data):
    with Path(path).open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def capture_once(argv, cwd, receipt_directory):
    """Execute one child; preserve actual bytes independently of file metadata."""
    directory = Path(receipt_directory)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    result = subprocess.run(argv, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    record = {"argv": argv, "cwd": str(cwd), "started_at_utc": started,
              "completed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "wall_seconds": time.monotonic() - clock, "exit_code": result.returncode,
              "child_invocations": 1, "retry_count": 0,
              "original_validate_shard_calls": 1, "validate_build_calls": 0,
              "measurement_or_compile_calls": 0, "custody_faults": []}
    for channel in ("stdout", "stderr"):
        raw = getattr(result, channel)
        record[channel] = byte_meta(raw)
        primary = directory / ("original-validator." + channel)
        duplicate = directory / ("captured-" + channel + ".frozen-original")
        for target in (primary, duplicate):
            try:
                write_exclusive(target, raw)
                observed = byte_meta(target.read_bytes())
                if observed != record[channel]:
                    record["custody_faults"].append({"path": str(target), "observed": observed,
                                                      "expected": record[channel]})
            except OSError as error:
                record["custody_faults"].append({"path": str(target), "error": repr(error)})
    result_path = directory / "original-validate-shard-return.json"
    if result.returncode == 0:
        if result_path.is_file():
            record["successful_return_matches_captured_stdout"] = (
                byte_meta(result_path.read_bytes()) == record["stdout"])
        else:
            record["successful_return_matches_captured_stdout"] = False
        if not record["successful_return_matches_captured_stdout"]:
            record["custody_faults"].append({"path": str(result_path),
                                               "error": "return differs from actual captured stdout"})
    else:
        record["successful_return_matches_captured_stdout"] = None
    record["native_validator_outcome_distinct_from_custody"] = True
    write_exclusive(directory / "original-validator-execution.json",
                    (json.dumps(record, ensure_ascii=False, indent=2) + "\n").encode())
    return record


def inspect_recorded_stdio(receipt_directory):
    """Repeat only byte custody comparisons immediately before a new seal."""
    directory = Path(receipt_directory)
    receipt = json.loads((directory / "original-validator-execution.json").read_text())
    observations = []
    for channel in ("stdout", "stderr"):
        for name in ("original-validator." + channel, "captured-" + channel + ".frozen-original"):
            path = directory / name
            current = byte_meta(path.read_bytes()) if path.is_file() else None
            observations.append({"path": str(path), "expected": receipt[channel],
                                 "current": current, "matches": current == receipt[channel]})
    if receipt["exit_code"] == 0:
        path = directory / "original-validate-shard-return.json"
        current = byte_meta(path.read_bytes()) if path.is_file() else None
        observations.append({"path": str(path), "expected": receipt["stdout"],
                             "current": current, "matches": current == receipt["stdout"]})
    return {"original_validator_exit": receipt["exit_code"],
            "custody_complete": not receipt["custody_faults"] and all(x["matches"] for x in observations),
            "observations": observations, "validator_reexecuted": False}
