from pathlib import Path
import json,hashlib,tarfile,gzip,io,datetime
p=Path(__file__).resolve().parent;root=p.parent;base=root/'raw-pr178-c8be5afa/11606128255/attempt01/extracted'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
excluded={'p8-build/codecortex','p8-build/p8-oracle','p8-build/p8-runtime-statistics'}
files=sorted(f for f in base.rglob('*') if f.is_file() and f.relative_to(base).as_posix() not in excluded)
members=[];archive=p/'c1-original-raw-without-three-ELFs.tar.gz'
with archive.open('xb') as of,gzip.GzipFile(filename='',mode='wb',fileobj=of,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as t:
 for f in files:
  b=f.read_bytes();name=f.relative_to(base).as_posix();assert not f.is_symlink()
  ti=tarfile.TarInfo(name);ti.size=len(b);ti.mode=f.stat().st_mode&0o777;ti.mtime=0;t.addfile(ti,io.BytesIO(b));members.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with tarfile.open(archive,'r:gz') as t:
 actual=t.getmembers();assert len(actual)==len(members)
 for tm,x in zip(actual,members):assert tm.name==x['path'] and tm.isfile() and tm.size==x['bytes'] and hashlib.sha256(t.extractfile(tm).read()).hexdigest()==x['sha256']
manifest={'schema_version':1,'artifact_id':11606128255,'source':'c8be5afaac568ffd40ef86d3795423c3b73c9f39','purpose':'New reversible container of byte-exact original raw files, full stdio, original SQLite databases, authored/Git fixtures and build receipts. Only three original ELF files are excluded and retain official locator/hash. This is not the original GitHub ZIP or a new execution.','original_zip':{'artifact_id':11606128255,'bytes':16564749,'sha256':'82ca67db084cedb9a03dbff6cf84b20ef293a3bdb304e3665c21ff6c2b744fd5','locator':'https://github.com/jyqj/codecortex/actions/runs/37901930897/artifacts/11606128255'},'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(members),'uncompressed_bytes':sum(x['bytes'] for x in members),'all_members_reread_and_hash_matched':True},'excluded_original_members':[{'path':n,'bytes':(base/n).stat().st_size,'sha256':sha(base/n)} for n in sorted(excluded)],'files':members}
with (p/'c1-original-raw-archive-manifest.json').open('x') as f:json.dump(manifest,f,indent=2);f.write('\n')
print(json.dumps(manifest['archive']))
