from pathlib import Path
import json,hashlib,zipfile,collections
ROOT=Path('/workspace/scratch/bfccb8494ba0'); HERE=Path(__file__).resolve().parent
PREV=ROOT/'round41-PR201-G2-0500-ordinary-CI-observation'
HEAD='f97c5068d056969705e8387ba1f37d83847f5bee'
def read(p):return json.loads(p.read_text())
def unwrap(p):return json.loads(read(p)['response']['structuredContent']['content'])
def ident(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
pull=unwrap(HERE/'pull.official-original.json')
assert pull['head']['sha']==HEAD and pull['base']['sha']=='b9b089bb4eae072affe9326681d4980eae15fd84'
ordinary=[]
for name in ['main_jobs','runtime_jobs','platform_jobs','lifecycle_jobs']:
 ordinary+=unwrap(HERE/(name+'.official-original.json'))['jobs']
for run in [38025451862,38025451825,38025451863]:
 ordinary+=unwrap(PREV/f'jobs-{run}.official-original.json')['jobs']
assert len(ordinary)==26 and len({j['id'] for j in ordinary})==26
checks=unwrap(HERE/'checks.official-original.json')
check_by_id={j['id']:j for j in checks['check_runs']}
assert len(checks['check_runs'])==checks['total_count']==52
assert all(j['head_sha']==HEAD for j in ordinary)
for j in ordinary:
 c=check_by_id[j['id']];assert c['head_sha']==HEAD
 assert (j['status'],j['conclusion'])==(c['status'],c['conclusion'])
counts=dict(collections.Counter(j['conclusion'] or j['status'] for j in ordinary))
assert counts=={'in_progress':2,'success':24}
ordinary_ids={j['id'] for j in ordinary}
others=[{k:c.get(k) for k in ['id','name','head_sha','status','conclusion','details_url']} for c in checks['check_runs'] if c['id'] not in ordinary_ids]
report={
 'schema_version':1,'reviewer':'pr_triage','source':HEAD,
 'scope':'One finite official ordinary-CI observation. No log/artifact downloads, product executions or mutations.',
 'observed_start':read(HERE/'checks.official-original.json')['started'],
 'observed_end':read(HERE/'checks.official-original.json')['ended'],
 'pull':{'number':201,'state':pull['state'],'draft':pull['draft'],'head':pull['head']['sha'],'base':pull['base']['sha'],'mergeable':pull['mergeable']},
 'original_ordinary_scope_count':26,'ordinary_status_counts':counts,
 'ordinary_jobs':[{k:j.get(k) for k in ['id','run_id','run_attempt','name','head_sha','status','conclusion','started_at','completed_at','steps']} for j in ordinary],
 'status_attribution':'Fresh all-check response confirms all 26 ordinary statuses; four unfinished workflows received fresh jobs. Three already-complete workflow job details reused from the prior frozen response without redownload.',
 'pending_ordinary_job_ids':[j['id'] for j in ordinary if j['status']!='completed'],
 'all_head_checks_count':52,'nonordinary_checks_not_credited':others,
 'nonordinary_boundary':'25 skipped entries and one running study build are excluded from the established ordinary26 denominator. No measurement credit inferred.',
 'main_default_regression':'Step8 completed success 05:00:24→05:05:07 UTC. Current step9 started05:05:07 remains in_progress. Fullmain log not downloaded.',
 'closeout_prior_accepted_review':{'actual_git_blob':'3a7a24d3dd334b1a3447f9f231af0ba01cdc1714','full_log_actual_git_blob':'703de5825d10906a0fb8e19e9f28f971357955a7'},
 'launch_assessment_retained':{'actual_git_blob':'67b1e0f704e6167c716fccb16b0bc5e3ddf4a4d8','boundary':'Launch may proceed while soak continues; no fullCI/merge/task-done claim.'},
 'next_reasonable_observation':{'main':'Around 05:20 UTC or a separately reported concrete terminal event; no polling loop.', 'soak':'Its original workload started04:59:53; around06:00 or later is a meaningful terminal observation window, not a predicted success.'},
 'task_credit_delta':0,'not_claimed':['all26 green','main terminal success','soak terminal success','named new test log lines independently read','new study sample acceptance'],
}
save(HERE/'independent-finite-0510-observation.json',report)
files=[p for p in HERE.iterdir() if p.name.endswith('.official-original.json')]+[HERE/'independent-finite-0510-observation.json',Path(__file__)]
files=sorted(files,key=lambda p:p.name)
manifest={'files':[{'archive_path':p.name,**ident(p)} for p in files],
 'external_frozen_originals':[{'path':str(PREV/f'jobs-{run}.official-original.json'),**ident(PREV/f'jobs-{run}.official-original.json')} for run in [38025451862,38025451825,38025451863]],
 'external_support_actual_blob':'88911b414ed6c3f2f2f0a0e5bd8658939be74e8b',
 'manifest_self_hash_excluded':True}
save(HERE/'member-manifest.json',manifest)
zpath=HERE/'complete-small-0510-official-originals.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files+[HERE/'member-manifest.json']:
  info=zipfile.ZipInfo(p.name,(2026,10,10,0,0,0));info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,p.read_bytes())
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and z.namelist()==[p.name for p in files]+['member-manifest.json']
 for row in manifest['files']:assert hashlib.sha256(z.read(row['archive_path'])).hexdigest()==row['sha256']
sel={'schema_version':1,'prefix':'artifacts/checkpoints/p8-round41-complete-bfcc-20261010/PR201-ordinary-CI/0510/',
 'files':[{'name':p.name,**ident(p)} for p in [HERE/'independent-finite-0510-observation.json',zpath]],'actual_uploads_pending':True}
save(HERE/'publication-selection.json',sel)
print(json.dumps({'ordinary':counts,'files':sel['files'],'selection':ident(HERE/'publication-selection.json')}))
