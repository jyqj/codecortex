from pathlib import Path
import json,math,hashlib
root=Path('/workspace/owner-comparison-validation')
summary={'query_api_pairs':0,'common_hit_checks':0,'base_correction_removed_bonuses':[],'candidate_correction_restored_bonuses':[],'regression':[],'scores':[],'top_k_1':[],'rank_derived_metadata_differences':[]}
def trace_no_bonus(h): return [t for t in h['score_trace'] if t[0]!='boost:symbol-exact']
def reasons_no_bonus(h): return [r for r in h['reasons'] if r!='symbol-exact']
def canonical(entry):
    return dict(hits=entry['raw']['machine_pack']['hits'], normalized=entry['normalized'], status=entry['status'], scores=entry.get('scores'))
def phrase(q):
    words=[w.strip('(),?!.').lower() for w in q.split()]
    return any(pair in [('rather','than'),('instead','of')] for pair in zip(words,words[1:]))
for variant in ['base','receiver','inversion']:
    arms={a:json.loads((root/f'results/{a}-{variant}/results.json').read_text()) for a in ['base','candidate','correction']}
    assert len({obj['source_text'] for obj in arms.values()})==1
    assert len(arms['base']['queries'])==32
    for query in arms['base']['queries']:
        for api in ['engine','mcp']:
            summary['query_api_pairs']+=1
            entries={a:obj['queries'][query][api] for a,obj in arms.items()}
            maps={a:{h['chunk_id']:h for h in entry['raw']['machine_pack']['hits']} for a,entry in entries.items()}
            assert maps['base'].keys()==maps['candidate'].keys()==maps['correction'].keys(),('top-k10 membership',variant,query,api)
            normalized={a:{(h['path'],h['start_line'],h['end_line'],h['symbol_name'],h['kind']):h for h in e['normalized']} for a,e in entries.items()}
            assert normalized['base']==normalized['candidate']==normalized['correction']
            for before,after,field in [('base','correction','base_correction_removed_bonuses'),('candidate','correction','candidate_correction_restored_bonuses')]:
                for cid in maps[before]:
                    x,y=maps[before][cid],maps[after][cid]; summary['common_hit_checks']+=1
                    for k in x:
                        if k not in ['score_trace','rerank_score','reasons','metadata']: assert x[k]==y[k],(variant,query,api,cid,k)
                    assert {k:v for k,v in x['metadata'].items() if k!='evidence_priority'}=={k:v for k,v in y['metadata'].items() if k!='evidence_priority'}
                    if x['metadata'].get('evidence_priority')!=y['metadata'].get('evidence_priority'):
                        summary['rank_derived_metadata_differences'].append(dict(variant=variant,query=query,api=api,pair=[before,after],chunk_id=cid,before=x['metadata'].get('evidence_priority'),after=y['metadata'].get('evidence_priority')))
                    assert trace_no_bonus(x)==trace_no_bonus(y)
                    assert reasons_no_bonus(x)==reasons_no_bonus(y)
                    for h in [x,y]: assert math.isclose(sum(v for _,v in h['score_trace']),h['rerank_score'],abs_tol=1e-9)
                    if x['score_trace']!=y['score_trace']:
                        assert x['symbol_name']=='Beacon' and x['symbol_kind']=='class' and 'exact-target' not in x['reasons']
                        delta=y['rerank_score']-x['rerank_score']
                        expected=-.18 if before=='base' else .18
                        assert math.isclose(delta,expected,abs_tol=1e-9)
                        bonus=lambda h:[v for k,v in h['score_trace'] if k=='boost:symbol-exact']
                        assert (bonus(x),bonus(y))==(([.18],[]) if before=='base' else ([],[.18]))
                        if before=='candidate': assert phrase(query),(query,'unexpected changed query')
                        summary[field].append(dict(variant=variant,query=query,api=api,chunk_id=cid,delta=delta))
                    else: assert {k:v for k,v in x.items() if k!='metadata'}=={k:v for k,v in y.items() if k!='metadata'}
            if phrase(query):
                assert canonical(entries['base'])==canonical(entries['correction']),('comparative fallback must equal old base',variant,query,api)
            else:
                assert canonical(entries['candidate'])==canonical(entries['correction']),('unaffected candidate behavior',variant,query,api)
            if query=='Which Beacon API rather than Sink accepts state?':
                tops={a:e['raw']['machine_pack']['hits'][0]['symbol_name'] for a,e in entries.items()}
                assert tops==dict(base='Beacon',candidate='Sink',correction='Beacon'),(variant,api,tops)
                summary['regression'].append(dict(variant=variant,api=api,top1=tops))
            if query in ['Which Beacon API changes the ready state with Commit?','Which method on Beacon changes the ready state with Commit?']:
                scores={a:e['scores'] for a,e in entries.items()}
                summary['scores'].append(dict(variant=variant,query=query,api=api,scores=scores))
                if variant=='receiver': assert scores['base']['top1']==0 and scores['correction']['top1']==1
                if variant=='inversion' and ' API ' in query: assert scores['base']['top1']==scores['correction']['top1']==0
    small=lambda o:[(h['chunk_id'],h['symbol_name']) for h in o['top_k_1']['machine_pack']['hits']]
    assert [{k:v for k,v in h.items() if k!='metadata'} for h in arms['candidate']['top_k_1']['machine_pack']['hits']]==[{k:v for k,v in h.items() if k!='metadata'} for h in arms['correction']['top_k_1']['machine_pack']['hits']]
    summary['top_k_1'].append(dict(variant=variant,**{a:small(o) for a,o in arms.items()}))
summary['inputs']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('results/*/results.json')}
(root/'comparison.json').write_text(json.dumps(summary,indent=2))
print('PASS',summary['query_api_pairs'],'three-arm query/API comparisons;',summary['common_hit_checks'],'common-hit pair checks')
print('Restored candidate bonuses:',len(summary['candidate_correction_restored_bonuses']))
print('Retained base-to-correction owner suppression:',len(summary['base_correction_removed_bonuses']))
for row in summary['regression']: print(row)
print('Receiver gains preserved; stronger lexical API inversion remains Top1=0; top_k1 equals candidate, expected base window changes preserved.')
