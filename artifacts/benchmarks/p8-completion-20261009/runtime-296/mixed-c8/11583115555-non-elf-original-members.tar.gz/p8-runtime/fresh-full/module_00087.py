def stable_00087():
    return 87
