import hashlib
import json
import os
import stat
import subprocess
import shutil
from datetime import datetime, timezone
from pathlib import Path

BASE = Path('/dev/shm/a217aaae3bde')
REPO = BASE / 'codecortex-combined-guard-view'
ARTIFACT = Path('/workspace/scratch/a217aaae3bde/ci-artifacts/11592180029')
ROOT = ARTIFACT / 'extracted'
SOURCE = 'a23bb72d3c954f385b99fe81ce9189885c208557'
OUT = BASE / 'platform-review/pr167-execution/gates-e-review'
OUT.mkdir(exist_ok=False)

def read(path):
    return json.loads(path.read_text())

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def inventory(root):
    result = {}
    for path in root.rglob('*'):
        assert not path.is_symlink(), path
        if path.is_dir():
            continue
        assert stat.S_ISREG(path.stat().st_mode), path
        result[path.relative_to(root).as_posix()] = sha(path)
    return result

def git(*args, data=None):
    return subprocess.check_output(['git', *args], cwd=REPO, input=data)

metadata_path = ARTIFACT / 'artifact-metadata.json'
if not metadata_path.exists():
    metadata_path = ARTIFACT / 'metadata.json'
metadata = read(metadata_path)
assert metadata['id'] == 11592180029
assert metadata['workflow_run']['id'] == 37871838927
assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert git('rev-parse', 'HEAD^{tree}').decode().strip() == '58147c952505c44da1f41eb4b9c31643f2303b96'
archive, = ARTIFACT.glob('*.zip')
assert archive.stat().st_size == metadata['size_in_bytes']
assert 'sha256:' + sha(archive) == metadata['digest']
assert metadata['workflow_run']['head_sha'] == SOURCE
report = read(ROOT / 'report.json')
assert report['status'] == 'passed_original_failure_gates' and report['exit_code'] == 0
before = inventory(ROOT)
assert {k:v for k,v in before.items() if k != 'report.json'} == report['files']

# Recompute the original driver source identity directly from the immutable Git
# blobs, without checking out or editing the parent's active worktree.
entries = git('ls-tree', '-r', '-z', SOURCE, '--', 'crates', 'Cargo.toml', 'Cargo.lock')
blobs = {}
for entry in entries.split(b'\0'):
    if not entry:
        continue
    meta, path = entry.split(b'\t', 1)
    mode, kind, blob = meta.decode().split()
    assert kind == 'blob' and mode in ('100644', '100755')
    blobs[path.decode()] = blob
objects = list(dict.fromkeys(blobs.values()))
raw = git('cat-file', '--batch', data=('\n'.join(objects)+'\n').encode())
offset, hashes = 0, {}
for expected in objects:
    end = raw.index(b'\n', offset)
    oid, kind, size = raw[offset:end].decode().split()
    size, offset = int(size), end+1
    assert oid == expected and kind == 'blob'
    hashes[oid] = hashlib.sha256(raw[offset:offset+size]).hexdigest()
    offset += size
    assert raw[offset:offset+1] == b'\n'
    offset += 1
assert offset == len(raw)
inputs = {name:hashes[blob] for name,blob in sorted(blobs.items())}
manifest_sha = hashlib.sha256((json.dumps(inputs, ensure_ascii=False, sort_keys=True, indent=2)+'\n').encode()).hexdigest()
source = dict(source_commit=SOURCE, source_tree=git('rev-parse', SOURCE+'^{tree}').decode().strip(),
              input_count=len(inputs), manifest_sha256=manifest_sha, inputs=inputs)
assert source == report['source']
assert len(inputs) == 1087
assert manifest_sha == '4e0aa6bbfd4d5bea00416bca2cd99318d865ffc526fdcb45897c4d300de3ac00'
assert all(not (REPO/name).is_symlink() and sha(REPO/name) == expected for name, expected in inputs.items())
driver_paths = ['scripts/p8_gate_controls.py', 'scripts/p8_recovery.py', 'scripts/p7_build_identity.py',
                'crates/cc-eval/tests/benchmark_cli.rs', 'crates/cc-eval/src/benchmark/comparison.rs',
                'crates/cc-eval/src/benchmark/gate.rs', 'crates/cc-eval/src/benchmark/report.rs',
                'scripts/p8_cold_build.py', 'scripts/p8_rollback.py', 'scripts/p7_fault_lifecycle_stdio.py',
                'scripts/resource_harness/__init__.py', 'scripts/resource_harness/runtime.py']
driver_hashes = {}
for relative in driver_paths:
    data = git('show', SOURCE+':'+relative)
    driver_hashes[relative] = hashlib.sha256(data).hexdigest()
    assert not (REPO/relative).is_symlink() and sha(REPO/relative) == driver_hashes[relative]
    destination = OUT / 'reviewed-source' / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)

expected_tests = [
    'unmeasurable_latency_cannot_pass_comparison',
    'zero_measurement_gate_is_invalid',
    'cli_quality_and_latency_failures_are_nonzero_and_keep_raw',
    'cli_inconclusive_is_nonzero',
    'cli_lock_failure_preserves_machine_readable_failure_and_raw',
    'cli_bad_policy_is_recorded_without_overwriting_existing_report',
]
assert [row['test_name'] for row in report['cases']] == expected_tests
assert sha(ROOT / 'cc-eval') == report['cli']['executable_sha256']
cases = []
for number, case in enumerate(report['cases']):
    directory = ROOT / f'case-{number:02}'
    assert case == read(directory / 'test-receipt.json')
    assert case['status'] == 'passed' and case['source'] == source
    assert case['package'] == 'cc-eval' and case['target'] == 'benchmark_cli'
    assert case['build']['command'][1:] == ['test', '-p', 'cc-eval', '--locked', '--offline', '--no-run', '--message-format=json-render-diagnostics', '--test', 'benchmark_cli']
    assert Path(case['build']['command'][0]).name == 'cargo'
    assert case['build']['timeout_seconds'] == 1800 and case['execution']['timeout_seconds'] == 300
    assert sha(directory / 'fault-test') == case['executable_sha256']
    for role in ('build','execution'):
        command = case[role]
        assert command == read(directory / role / 'command.json')
        assert command['status'] == 'passed' and command['exit_code'] == 0
        for name, digest in command['logs_sha256'].items():
            assert sha(directory / role / name) == digest
    event = case['cargo_artifact']
    messages = [json.loads(line) for line in (directory/'build/stdout.log').read_text().splitlines() if line.strip()]
    selected = [row for row in messages if row.get('reason') == 'compiler-artifact' and row.get('target',{}).get('name') == 'benchmark_cli' and row.get('executable')]
    assert selected == [event]
    assert event['target']['kind'] == ['test'] and event['profile']['test'] is True
    assert event['profile'] == {'debug_assertions': True, 'debuginfo': 0, 'opt_level': '0', 'overflow_checks': True, 'test': True}
    assert event['target']['crate_types'] == ['bin']
    assert event['package_id'].endswith('/crates/cc-eval#1.0.0')
    assert event['manifest_path'] == '/home/runner/work/codecortex/codecortex/crates/cc-eval/Cargo.toml'
    assert event['target']['src_path'] == '/home/runner/work/codecortex/codecortex/crates/cc-eval/tests/benchmark_cli.rs'
    assert event['executable'].startswith('/home/runner/work/_temp/p8-gates-target/')
    assert any(row.get('reason') == 'build-finished' and row.get('success') is True for row in messages)
    assert [row for row in messages if row.get('reason') == 'build-finished'] == [messages[-1]]
    assert messages[-1] == {'reason': 'build-finished', 'success': True}
    cli_events = [row for row in messages if row.get('reason') == 'compiler-artifact' and row.get('target',{}).get('name') == 'cc-eval' and row.get('target',{}).get('kind') == ['bin'] and row.get('executable')]
    assert len(cli_events) == 1
    if number == 0:
        assert cli_events[0] == report['cli']['cargo_artifact']
    assert cli_events[0]['executable'] == report['cli']['path']
    assert cli_events[0]['manifest_path'] == event['manifest_path']
    assert cli_events[0]['package_id'] == event['package_id']
    assert cli_events[0]['target']['crate_types'] == ['bin']
    assert cli_events[0]['features'] == ['default']
    assert cli_events[0]['profile'] == {'debug_assertions': True, 'debuginfo': 0, 'opt_level': '0', 'overflow_checks': True, 'test': False}
    assert cli_events[0]['executable'] == '/home/runner/work/_temp/p8-gates-target/debug/cc-eval'
    if number == 0:
        assert cli_events[0]['fresh'] is False
        assert event['fresh'] is False
    assert cli_events[0]['target']['src_path'] == '/home/runner/work/codecortex/codecortex/crates/cc-eval/src/bin/cc-eval.rs'
    assert cli_events[0]['executable'].startswith('/home/runner/work/_temp/p8-gates-target/')
    assert case['execution']['command'][0] == case['retained_executable'] == f'/home/runner/work/_temp/p8-gates/case-{number:02}/fault-test'
    command = case['execution']['command']
    assert command[1:] == ['--exact', expected_tests[number], '--nocapture', '--test-threads=1']
    stdout = (directory/'execution/stdout.log').read_text()
    assert f'test {expected_tests[number]} ... ok' in stdout
    assert '1 passed; 0 failed; 0 ignored' in stdout
    cases.append(dict(case=number, test=case['test_name'], original_execution='passed_nonignored_exact_test',
                      test_binary_sha256=case['executable_sha256'], source_commit=SOURCE))

# Only copied fixtures are replayed. Original extracted artifacts stay immutable.
cli = OUT / 'cc-eval'
subprocess.run(['cp','--reflink=auto',str(ROOT/'cc-eval'),str(cli)],check=True)
cli.chmod(0o555)
assert sha(cli) == report['cli']['executable_sha256']
fixtures = {}
for number in (0,2,3,4,5):
    original, = (ROOT/f'case-{number:02}'/'retained-fixtures').iterdir()
    destination = OUT/f'fixtures-{number:02}'
    shutil.copytree(original, destination)
    for copied_path in destination.rglob("*"):
        if copied_path.is_file(): copied_path.chmod(0o644)
    fixtures[number] = destination

policy = {'schema_version':1,'max_ndcg_regression':0.01,'max_top1_regression':0.01,
          'max_latency_ratio':1.2,'minimum_latency_samples':30}
zero_policy = OUT/'zero-denominator-policy.json'
zero_policy.write_text(json.dumps(policy,indent=2)+'\n')
replays = []
specs = [
    (0,'zero-denominator','candidate',1,'inconclusive',None,zero_policy),
    (2,'quality','quality',1,'failed','quality-comparison.json',fixtures[2]/'policy.json'),
    (2,'latency','latency',1,'failed','latency-comparison.json',fixtures[2]/'policy.json'),
    (3,'insufficient-samples','candidate',1,'inconclusive','comparison.json',fixtures[3]/'policy.json'),
    (4,'raw-lock-drift','candidate',2,'invalid_measurement','comparison.json',fixtures[4]/'policy.json'),
    (5,'bad-policy','missing-run',2,'invalid_measurement','comparison.json',fixtures[5]/'policy.json'),
]
for number, label, candidate_name, expected_code, expected_status, original_name, policy_file in specs:
    fixture = fixtures[number]
    output = OUT/(label+'-replayed.json')
    base_name = 'missing-run' if number == 5 else 'base'
    command = [str(cli),'compare','--baseline',str(fixture/base_name),'--candidate',str(fixture/candidate_name),
               '--gate',str(policy_file),'--output',str(output)]
    raw_before = inventory(fixture)
    proc = subprocess.run(command,capture_output=True,text=True,timeout=60)
    (OUT/(label+'.stdout')).write_text(proc.stdout)
    (OUT/(label+'.stderr')).write_text(proc.stderr)
    result = read(output)
    assert proc.returncode == result['exit_code'] == expected_code, (label,proc.returncode,result)
    assert result['status'] == expected_status, (label,result)
    if number == 0:
        assert result['p95_ratio'] is None
    equivalent = None
    if original_name:
        original = read(fixture/original_name)
        relocated_fields = ('baseline','candidate','policy_path') if number in (4,5) else ()
        equivalent = {k:v for k,v in original.items() if k not in relocated_fields} == {k:v for k,v in result.items() if k not in relocated_fields}
        assert equivalent, (label,original,result)
    raw_after = inventory(fixture)
    assert {k:v for k,v in raw_before.items() if '/raw/' in '/'+k or k.startswith('raw/')} == {k:v for k,v in raw_after.items() if '/raw/' in '/'+k or k.startswith('raw/')}
    row = dict(control=label, command=command, exit_code=proc.returncode, status=result['status'],
               report=str(output), report_sha256=sha(output), original_report_equivalent=equivalent,
               ignored_comparison_fields=['baseline','candidate','policy_path'] if number in (4,5) else [],
               raw_unchanged=True)
    if number == 5:
        expected = sha(output)
        repeat = subprocess.run(command,capture_output=True,text=True,timeout=60)
        assert repeat.returncode == 2 and sha(output) == expected
        (OUT/'overwrite-refused.stdout').write_text(repeat.stdout)
        (OUT/'overwrite-refused.stderr').write_text(repeat.stderr)
        row['overwrite_control'] = dict(exit_code=repeat.returncode, report_unchanged=True)
    replays.append(row)

assert inventory(ROOT) == before
assert archive.stat().st_size == metadata['size_in_bytes'] and 'sha256:' + sha(archive) == metadata['digest']
assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert all(not (REPO/name).is_symlink() and sha(REPO/name) == expected for name, expected in inputs.items())
assert all(sha(REPO/name) == expected for name, expected in driver_hashes.items())
assert sha(cli) == report['cli']['executable_sha256']
review = dict(schema_version=1, reviewer='pr_audit', reviewed_at_utc=datetime.now(timezone.utc).isoformat(),
    assessment='accepted_scoped_original_failure_gate_execution', task='P8-013',
    source_commit=SOURCE, pr=167, workflow_run_id=37871838927, workflow_job_id=113631480750,
    artifact_id=metadata['id'], artifact_zip_sha256=sha(archive), artifact_zip_bytes=archive.stat().st_size,
    artifact_directory=str(ROOT), report_sha256=before['report.json'],
    checked_original_payload_files=len(report['files']), checked_fixed_source_files=len(inputs),
    source_manifest_sha256=manifest_sha, reviewed_driver_source_sha256=driver_hashes,
    cli_sha256=report['cli']['executable_sha256'], cases=cases, independent_cli_replays=replays,
    original_artifacts_unchanged=True, unresolved_subgate_blockers=[],
    hard_dependencies=[dict(task='P8-012',status='pending_complete_platform_and_dependency_acceptance')],
    task_done=False, measured_product_performance=False, release_approval=False,
    limitations=['Scope is the original six failure-control tests and retained evidence; applicable wider V03/V04 regressions remain with original CI acceptance.',
                 'The fixture data is explicitly synthetic. Passing controls proves failure exits/receipts/raw retention, not product quality or speed.',
                 'All original and supplementary replays use the retained a23bb72 CLI. These results belong only to the fixed E execution source and never inherit 599/296/8e evidence.',
                 'Supplementary invalid-input report comparison ignores only relocated baseline/candidate/policy filesystem paths; outcomes, reasons and raw are unchanged.',
                 'The pure zero-plan library case is verified through its exact original nonignored test binary/source/log; no extra local Cargo compilation or hosted rerun was performed.'])
(OUT/'review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:review[k] for k in ['assessment','source_commit','checked_original_payload_files','checked_fixed_source_files','task_done']},ensure_ascii=False))
print('review_path='+str(OUT/'review.json'))
