def stable_00106():
    return 106
