import json, hashlib, pathlib, datetime, decimal, collections
ROOT=pathlib.Path('/workspace/scratch/bfccb8494ba0')
SRC=ROOT/'round47-new45-descriptive-analysis'
OUT=pathlib.Path(__file__).parent
identities={}; check_count=0
def read(p):
    b=p.read_bytes(); identities[str(p)]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}; return b
def load(p):return json.loads(read(p))
def check(value, label):
    global check_count
    assert value,label
    check_count+=1
def same(actual,expected,label):check(actual==expected,label)
def numeric_sum(values):return sum(values) if values and all(type(v) is int for v in values) else None
def timing_sum(reports,key):
    v=[x['report'].get('build_timing',{}).get(key) for x in reports]
    return numeric_sum(v)
def seconds(v,unit):return '—' if v is None else format(decimal.Decimal(v)/decimal.Decimal(unit),'f')
d=load(SRC/'accepted-44-descriptive-draft.json'); md=read(SRC/'accepted-44-descriptive-draft.md').decode()
registry=load(ROOT/'round42-new45-build-original-intake/original-build/task-registry.json')
extract=load(SRC/'phase-extraction-receipt.json'); render=load(SRC/'draft-render-receipt.json')
for name in ['extract-original-phase-reports.py','render-descriptive-draft.py']: read(SRC/name)
expected={(p,scale,0) for p in ['no_op','body','api','config','batch_1','batch_10','batch_100','batch_1000'] for scale in [1000,5000,10000,50000,100000]} | {('fanout',x,0) for x in [1,4,16,64,128]}
observed={tuple(c['slot']) for c in d['cells']}
same(len(d['cells']),44,'44 cells');same(len(observed),44,'44 unique slots');same(expected-observed,{('body',100000,0)},'only missing body100k');same(observed-expected,set(),'no unregistered slots')
same(len(d['observations']),83,'83 roles');same(len({(tuple(x['slot']),x['role']) for x in d['observations']}),83,'83 unique(slot,role)')
same(dict(collections.Counter(x['role'] for x in d['observations'])),{'setup':39,'mutation':39,'fanout':5},'39+39+5')
same(d['original_aggregate'],None,'original aggregate pending');same(d['apply'],False,'draft no apply');same(d['task_credit'],0,'no task credit')
same(extract['accepted_slots_analyzed'],44,'extract44');same(extract['exit_code'],0,'extract0');same(render['exit_code'],0,'render0')
fact_cache={};ret_cache={}; per_cell=[]; missing_fields=[]; elapsed_supplements=[]
supplement_paths={
 ('api',100000,0):'round46-api-100k-independent-review/original-timing-phase-and-parity-selection.json',
 ('config',100000,0):'round46-config-100k-independent-review/original-timing-phase-and-parity-selection.json',
 ('batch_1000',100000,0):'round46-batch1000-100k-independent-review/original-timing-phase-and-parity-selection.json',
 ('batch_100',100000,0):'round47-batch100-100k-independent-review/original-timing-phase-and-parity-selection.json'}
supplements={}
for cell in d['cells']:
    slot=tuple(cell['slot']); rp=pathlib.Path(cell['original_result']['local_path']); rb=read(rp); ret=json.loads(rb)
    same(hashlib.sha256(rb).hexdigest(),cell['original_result']['sha256'],'accepted return SHA '+str(slot))
    fp=pathlib.Path(cell['phase_fact_source']['path']); fb=read(fp); facts=json.loads(fb)
    same(hashlib.sha256(fb).hexdigest(),cell['phase_fact_source']['sha256'],'facts SHA '+str(slot))
    same(facts['slot'],list(slot),'factslot');same(facts['source'],d['source'],'source');same(facts['run_id'],d['run_id'],'run');same(facts['attempt'],1,'attempt')
    same(cell['registered_plan'],ret['plan'],'registered plan exact');check(ret['plan'] in registry['plans'],'registry membership')
    same(cell['original_task_receipt_sha256'],ret['receipt_sha256'],'receipt exact')
    env=d['environments'][cell['environment_ref']]
    same(env,{'slot':list(slot),'environment':ret['environment'],'engine_cpu_parallelism':ret['engine'].get('cpu_parallelism'),'measurement_environment':ret['measurement_environment'],'profile_environment':ret['profile_environment']},'full environment exact')
    fact_cache[slot]=facts; ret_cache[slot]=ret
    roles=['fanout'] if slot[0]=='fanout' else ['setup','mutation']
    same(len(ret['measurements']),len(roles),'role denominator')
    for group,reports in facts['report_groups'].items():
        cs=facts['count_summaries'][group];same(cs['original_report_count'],len(reports),'report count')
        for k in ['files_parsed','files_updated','files_scanned','files_skipped']:
            values=[r['report'].get(k) for r in reports];same(cs[k+'_sum'],numeric_sum(values),'count exact '+k)
            if numeric_sum(values) is None:missing_fields.append([list(slot),group,k])
        same(cs['selected_dependents_sum'],numeric_sum([r['report'].get('dirty_plan',{}).get('selected_dependents') for r in reports]),'dependent selection visits')
        resumed=[r['report'].get('dirty_plan',{}).get('resumed') for r in reports]
        same(cs['resumed_true_report_count'],sum(v is True for v in resumed) if resumed and all(type(v) is bool for v in resumed) else None,'resumed actual bool')
        for pos,index in [('first',0),('last',-1)]:
            same(cs[pos+'_freshness'],reports[index]['report'].get('resolution_freshness') if reports else None,'freshness preserved')
            same(cs[pos+'_dirty_plan'],reports[index]['report'].get('dirty_plan') if reports else None,'dirty plan preserved')
        for record in reports:
            prov=record['provenance'];check(type(prov['line']) is int and prov['line']>0 and len(prov['original_line_sha256'])==64,'raw line provenance retained')
    per_cell.append({'slot':list(slot),'original_return_sha256':hashlib.sha256(rb).hexdigest(),'facts_sha256':hashlib.sha256(fb).hexdigest(),'groups':{k:len(v) for k,v in facts['report_groups'].items()}})
projection_keys=['group','sample','engine_ms','index_wall_us','outer_incremental_wall_us','whole_fixture_wall_us','full_control_ms','parity_wall_us','builds','first_build_incomplete','build_timing','full_control_build_timing','phases','counts','process_snapshot']
for row in d['observations']:
    slot=tuple(row['slot']);role=row['role'];facts=fact_cache[slot];ret=ret_cache[slot];index=1 if role=='mutation' else 0;m=ret['measurements'][index]
    same(row['original'],{k:m[k] for k in projection_keys if k in m},'role original measurement values exact')
    same(row['original_result_pointer']['json_pointer'],'/measurements/'+str(index),'role pointer')
    same(row['counts_over_original_reports'],facts['count_summaries'][role],'role counts exact')
    same(row['full_control_counts_over_original_reports'],facts['count_summaries'][role+'_full_control'],'full-control separate counts')
    same(row['original_completion_events'],[e for e in facts['completion_and_parity_events'] if e['role']==role],'completion events unchanged')
    reports=facts['report_groups'][role];controls=facts['report_groups'][role+'_full_control']
    if any('elapsed_ms' not in r['report'] for r in reports):
        sp=supplement_paths[slot]
        if slot not in supplements:supplements[slot]=load(ROOT/sp)
        bylabel={b['label']:b for b in supplements[slot]['builds']}
        elapsed=[]
        for r in reports:
            b=bylabel[r['label']]
            same(b['line'],r['provenance']['line'],'supplement same original line')
            same(b['wall_us'],r['wall_us'],'supplement same enclosing wall')
            for k,v in r['report'].items():
                if k in b['report_fields']:same(v,b['report_fields'][k],'supplement original overlapping field '+k)
            elapsed.append(b['report_fields']['elapsed_ms'])
        same(m['engine_ms'],sum(elapsed),'engine ms supplemented from prior exact peer facts')
        elapsed_supplements.append({'slot':list(slot),'role':role,'builds':len(reports),'path':sp,'reason':'Reused author closure fact omitted elapsed_ms; original return is correct. Existing independent per-build facts supply exact same-line elapsed values without raw reread.'})
    else:same(m['engine_ms'],sum(r['report']['elapsed_ms'] for r in reports),'engine milliseconds sum')
    same(m['full_control_ms'],sum(r['report']['elapsed_ms'] for r in controls),'control milliseconds sum')
    for key,value in m['build_timing'].items():same(value,timing_sum(reports,key),'phase us '+key)
    for key,value in m['full_control_build_timing'].items():same(value,timing_sum(controls,key),'control phase us '+key)
    for key,value in m['phases'].items():same(value,numeric_sum([r['report'].get('phase_timing',{}).get(key) for r in reports]),'legacy phase ms '+key)
    if role!='fanout':same(m['index_wall_us'],sum(r['wall_us'] for r in reports),'index enclosing microseconds')
    if role=='setup':
        same(m['counts']['vectors']['state'],'disabled','vector disabled');same(m['counts']['vectors']['count'],None,'missing vector count remains null')
    else:
        same(m['builds'],len(reports),'incremental build count')
        label=slot[0]+'/'+str(slot[1]);c=row['counts_over_original_reports']
        expected_line='| '+' | '.join([label,'1',row['environment_ref'],seconds(m.get('engine_ms'),1000),seconds(m.get('index_wall_us'),1000000),seconds(m.get('outer_incremental_wall_us'),1000000),seconds(m.get('whole_fixture_wall_us'),1000000),seconds(m.get('full_control_ms'),1000),seconds(m.get('parity_wall_us'),1000000),str(m['builds']),'unavailable' if c['resumed_true_report_count'] is None else str(c['resumed_true_report_count'])])+' |'
        check(expected_line in md,'markdown exact seconds '+label)
    if role=='fanout':
        same(row['fanout_actual_fixture_files'],slot[1]+1,'fanout real fixture files');same(row['fanout_plan_capacity_files'],1000,'fanout capacity not workload')
        same(m['first_build_incomplete'],reports[0]['report']['resolution_freshness']['complete'] is False,'fanout first incomplete exact')
        check('index_wall_us' not in m and 'parity_wall_us' not in m,'unavailable fanout independent clocks not manufactured')
cold=[{'slot':['no_op',scale,0],'role':'setup'} for scale in [1000,5000,10000,50000,100000]]
same(d['preselected_cold_subset'],cold,'cold5 exact setup subset')
same(len(d['environments']),44,'per-slot environment retained')
check('not added' in d['units']['build_timing'],'nested timing boundary')
check('Hostname alone is not a machine identity.' in d['scope'][0],'hostname scope')
report={'schema':'independent-44-cell-descriptive-derivation-review-v1','reviewer':'/root/pr_triage','reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decision':'accepted_scoped_draft_derivation_only','source':d['source'],'run_id':d['run_id'],'attempt':1,'counts':{'cells':44,'records':83,'roles':d['roles'],'cold_subset':5},'missing_slots':d['missing_slots'],'original_aggregate':None,'checks_passed':check_count,'mapping_findings':['44 exact accepted return SHA values and44 phase fact hashes verified; role projections and provenance are exact.','Every emitted-report counter recomputed from derived facts with missing/null retained. Selection/scanned counts mean visits or repeated work, not unique files.','All83 role timing payloads match original returns and independently sum corresponding build reports, with503 elapsed_ms values sourced from existing independent same-line facts because the reused closure projection omitted that field. Full controls remain separate. Milliseconds/microseconds and44 nonsetup markdown decimal conversions retain units.','prepare_snapshot/full_staging are nested labels, never added to prepare/total; legacy phase timing is separate emitted data, not a forced partition.','Cold5 is the fixed no_op setup subset; fanout uses actual2/5/17/65/129file fixtures with1000 capacity identity. Per-cell environments and null disabled vectors retained.'],'limits':['Accepted draft of44 cells, not final45/85 or006task acceptance. Onlybody100k missing.','No raw files orZIPs reopened by this peer. Source extraction script was statically inspected; prior line hashes plus accepted receipts bind derived facts. No new original validator/ELF/CRC/benchmark.','Original successfulN1 cells and their measured hosts remain separate; no N30/tails/speedup pooling. Body and originalActions aggregate must append actual facts before final report.'],'elapsed_provenance_supplements':elapsed_supplements,'derived_missing_count_fields':missing_fields,'reader_history':'Attempt01 KeyError on omitted elapsed_ms in four reused fact projections; preserved. Attempt02 uses existing independent same-line facts and checks overlapping original fields; no raw rerun.','task_credit':0,'apply_now':False,'peer_execution':{'original_validator':0,'aggregate':0,'combine':0,'raw_reads':0,'ZIP_CRC':0,'ELF':0,'tests':0}}
(OUT/'independent-44-cell-descriptive-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(OUT/'checked-cell-and-input-identities.json').write_text(json.dumps({'cells':per_cell,'inputs':identities},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks_passed':check_count,'cells':44,'records':83,'decision':report['decision'],'raw_reads':0}))
