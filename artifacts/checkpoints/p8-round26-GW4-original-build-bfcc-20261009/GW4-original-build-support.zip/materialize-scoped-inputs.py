import json,subprocess,pathlib,hashlib,os,stat,datetime
B=pathlib.Path(__file__).resolve().parent;R=B/'source-exact-GW4';env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0'};plan=json.loads((B/'scoped-restoration-plan.json').read_text());receipts=[]
def git(*args,input=None):
 p=subprocess.run(['git',*args],cwd=R,env=env,capture_output=True,input=input);receipts.append({'argv':['git',*args],'exit_code':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr':p.stderr.decode(errors='replace')});assert p.returncode==0,receipts[-1];return p.stdout
for row in json.loads((B/'missing-scoped-blobs.json').read_text()):
 b=(B/'official-scoped-blobs'/row['sha']).read_bytes();assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256'];assert git('hash-object','-w','--stdin',input=b).decode().strip()==row['sha']
ids=list(dict.fromkeys(row['sha'] for row in plan['inventory'].values()));out=git('cat-file','--batch',input=('\n'.join(ids)+'\n').encode());values={};off=0
for oid in ids:
 end=out.index(b'\n',off);sha,kind,size=out[off:end].decode().split();assert sha==oid and kind=='blob';size=int(size);off=end+1;b=out[off:off+size];off+=size;assert out[off:off+1]==b'\n';off+=1;values[oid]=b
assert off==len(out)
index=[]
for path,row in plan['inventory'].items():
 b=values[row['sha']];assert len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256'],path
 p=R/path;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b);p.chmod(0o755 if row['mode']=='100755' else 0o644);index.append(f"{row['mode']} {row['sha']}\t{path}\n")
git('read-tree','--empty');git('update-index','--index-info',input=''.join(index).encode());assert git('rev-parse','HEAD').decode().strip()==plan['source'];assert git('rev-parse','HEAD^{tree}').decode().strip()==plan['tree']
(B/'scoped-materialization-receipt.json').write_text(json.dumps({'source':plan['source'],'tree':plan['tree'],'paths':len(plan['paths']),'products':1095,'original_driver_helper':2,'source_hashes_all_match_canonical':True,'scope':'Complete1095products+2observer sparse index; unrelated repository files intentionally absent. Exact official commit object SHA restored, not substitute.','commands':receipts},indent=2)+'\n');print('materialized1095products+2originaldrivers; no validator yet')
