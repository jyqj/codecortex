def stable_00256():
    return 256
