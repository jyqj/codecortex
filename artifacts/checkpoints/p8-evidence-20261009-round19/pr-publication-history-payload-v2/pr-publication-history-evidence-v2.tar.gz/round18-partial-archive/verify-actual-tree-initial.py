import datetime, hashlib, json
from pathlib import Path
ROOT = Path('/dev/shm/a217aaae3bde/platform-review/round18-partial-archive')
PREP = Path('/workspace/scratch/a217aaae3bde/checkpoint-round18-prep')
PAYLOAD = Path('/workspace/scratch/a217aaae3bde/checkpoint-round17-prep/new-e-original-zip-payload')
def read(p): return json.loads(p.read_text())
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def tree(entries):
    entries=sorted(entries,key=lambda e:(e['path']+('/' if e['type']=='tree' else '')).encode())
    b=b''.join(e['mode'].lstrip('0').encode()+b' '+e['path'].encode()+b'\0'+bytes.fromhex(e['sha']) for e in entries)
    return hashlib.sha1(b'tree '+str(len(b)).encode()+b'\0'+b).hexdigest()
def slim(e): return {k:e[k] for k in ('path','mode','type','sha')}
def mapped(d): return {e['path']:slim(e) for e in d['tree']}
objects=[]
for name in ['candidate-root','base-root','candidate-artifacts','base-artifacts','candidate-checkpoints','base-checkpoints']:
    d=read(ROOT/(name+'.json')); assert d['truncated'] is False
    assert tree(d['tree'])==d['sha']; objects.append({'name':name,'sha':d['sha'],'entry_count':len(d['tree'])})
for base,cand,only in [('base-root','candidate-root','artifacts'),('base-artifacts','candidate-artifacts','checkpoints')]:
    a=mapped(read(ROOT/(base+'.json'))); b=mapped(read(ROOT/(cand+'.json')))
    assert a.keys()==b.keys()
    assert [k for k in a if a[k]!=b[k]]==[only]
a=mapped(read(ROOT/'base-checkpoints.json'));b=mapped(read(ROOT/'candidate-checkpoints.json'))
assert set(b)-set(a)=={'p8-evidence-20261009-round18','p8-original-e-a23bb72d-20261009'}
assert all(a[k]==b[k] for k in a)
leaves={}; recursive_nodes=[]
for name,prefix in [('new-round18-recursive','artifacts/checkpoints/p8-evidence-20261009-round18'),('new-originals-recursive','artifacts/checkpoints/p8-original-e-a23bb72d-20261009')]:
    d=read(ROOT/(name+'.json')); assert d['truncated'] is False
    inventory={e['path']:e for e in d['tree']}
    for parent,sha in [('',d['sha'])]+[(e['path'],e['sha']) for e in d['tree'] if e['type']=='tree']:
        kids=[]
        for e in d['tree']:
            p=Path(e['path']); par='' if str(p.parent)=='.' else str(p.parent)
            if par==parent: kids.append({**e,'path':p.name})
        assert tree(kids)==sha, (name,parent)
        recursive_nodes.append({'path':prefix+('/'+parent if parent else ''),'sha':sha,'entries':len(kids)})
    for e in d['tree']:
        if e['type']!='tree':
            assert e['type']=='blob' and e['mode']=='100644'
            row={**slim(e),'path':prefix+'/'+e['path'],'size':e['size']}; assert row['path'] not in leaves;leaves[row['path']]=row
candidate=read(PREP/'partial-archive-candidate.json')
expected={e['path']:e for e in candidate['tree_elements']}
assert len(leaves)==len(expected)==137
assert {p:slim(e) for p,e in leaves.items()}==expected
plan=read(PAYLOAD/'upload-plan.json'); assert len(plan)==195
parts=plan[:193];actual_parts=[e for e in leaves.values() if '/originals/' in e['path']]
assert len(actual_parts)==125
assert {e['path'] for e in actual_parts}=={e['repository_path'] for e in parts[:125]}
for e in parts[:125]:
    a=leaves[e['repository_path']];assert (a['sha'],a['size'],a['mode'],a['type'])==(e['git_blob_sha1'],e['bytes'],e['mode'],e['type'])
assert all(e['repository_path'] not in leaves for e in parts[125:])
small=[]
for e in read(PREP/'partial-archive-small-upload-receipts.json'):
    p=Path(e['local_path']);data=p.read_bytes();a=leaves[e['repository_path']]
    assert blob(data)==e['sha']==a['sha']
    assert len(data)==a['size']
    if 'sha256' in e:assert hashlib.sha256(data).hexdigest()==e['sha256']
    small.append({'path':a['path'],'source_path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob_sha1':a['sha']})
assert len(small)==12
remote_status=(ROOT/'actual-remote-publication-status.json').read_bytes()
local_status=(PREP/'partial-original-archive-publication.json').read_bytes()
assert remote_status==local_status and blob(remote_status)=='c01c54f4fa8d3bb3c9f0d3b67cbfb5235a888d73'
status=json.loads(remote_status)
assert status['original_zip_payload']['complete_original_zip_payload_published'] is False
assert status['original_zip_payload']['zip_parts_in_this_publication']==125
assert status['original_zip_payload']['zip_parts_still_pending']==68
assert status['original_zip_payload']['full_manifest_is_a_plan_until_remaining_parts_are_published'] is True
assert status['original_todo_ledger']=={'total':192,'done':163,'remaining':29,'newly_completed_this_task':0}
assert status['new_artifact_intake']['included_in_fixed_39_original_payload'] is False
assert status['new_artifact_intake']['soak']['full_independent_raw_acceptance_at_initial_intake'] is False
assert status['new_artifact_intake']['scale_50k']['full_independent_raw_acceptance_at_initial_intake'] is False
review=Path('/dev/shm/a217aaae3bde/platform-review/pr167-execution/original-e-39-zip-custody-independent-review.json')
assert hashlib.sha256(review.read_bytes()).hexdigest()=='5e932f345ef17adbff2714a698816a4f2855169c012246e840184c1f96e5284f'
assert hashlib.sha256((PAYLOAD/'payload-manifest.json').read_bytes()).hexdigest()=='f59f4e93343ddeee54e6e3312ccdda3da7ea98e73cc32ce638c4a288e898f794'
commit=read(ROOT/'candidate-commit.json')
assert commit['sha']==candidate['candidate_commit_sha']=='a9d21e731a92c520aaf27258977fa8bead53264d'
assert commit['tree']['sha']==candidate['candidate_tree_sha']=='0363e6747040931a80f0e997560ebdda6b7c67ec'
assert [x['sha'] for x in commit['parents']]==[candidate['base_commit_sha']]
result={'schema':'round18-partial-original-archive-actual-tree-independent-review-v1','reviewer':'/root/pr_audit','decision':'accepted_scoped','candidate_commit':commit['sha'],'candidate_tree':commit['tree']['sha'],'parent_commit':candidate['base_commit_sha'],'base_tree':candidate['base_tree_sha'],'reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':['Fresh official fixed commit and non-recursive ancestor trees, recursive new subtrees, every tree SHA independently recomputed from mode/name/type/OID','All 137 actual remote leaf OIDs/modes/sizes exactly match candidate; 125 exact prefix slice OIDs/sizes match previously independently byte-verified immutable 193-slice plan','All 12 small local original byte strings rehashed to exact actual remote leaf OIDs; explicit publication status additionally read from remote and compared byte-for-byte','All 12 non-artifact root entries, 4 artifact sibling trees and all 174 original checkpoint siblings unchanged by mode/type/OID'], 'all_actual_added_leaves':list(leaves.values()),'ancestor_tree_recomputations':objects,'new_recursive_tree_recomputations':recursive_nodes,'small_original_bindings':small,'zip_parts_present':125,'zip_parts_pending':68,'complete_original_zip_payload_published':False,'original_custody_review':{'path':str(review),'sha256':'5e932f345ef17adbff2714a698816a4f2855169c012246e840184c1f96e5284f'},'scope_limits':['No large binary downloaded or native/helper validation rerun in this assembly review','Prior all-39 whole ZIP and all-193 slice byte review remains the content provenance; actual Git tree proof is this review','Soak and 50k intake were outside the frozen 39 ZIP set, with initial raw acceptance false correctly retained as historical intake','This append-only evidence branch commit is neither E source change nor task completion nor complete archival publication'],'task_counts':status['original_todo_ledger'],'source_task_historical_evidence_changes':0,'remote_mutations_performed_by_reviewer':False,'unresolved_blockers':[]}
out=ROOT/'independent-review.json';out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');raw=out.read_bytes();print(json.dumps({'path':str(out),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'decision':result['decision']}))
