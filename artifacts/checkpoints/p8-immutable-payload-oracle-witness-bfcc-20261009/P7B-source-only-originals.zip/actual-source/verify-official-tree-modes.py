#!/usr/bin/env python3
"""Hash the 13 official directory objects; reverse only six reviewed leaves."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
bridge = json.loads((ROOT / 'actual-P7B-complete-source-bridge.json').read_bytes())
nodes = {}
for file in sorted((ROOT / 'git-trees').glob('*.json')):
    raw = json.loads(file.read_bytes())
    value = json.loads(raw['structuredContent']['content'])
    path = '' if file.stem == 'root' else file.stem.replace('__', '/')
    assert not value['truncated']
    nodes[path] = value

def tree_oid(entries):
    payload = b''
    for entry in sorted(entries, key=lambda e: (e['path'] + ('/' if e['type'] == 'tree' else '')).encode()):
        mode = entry['mode'].lstrip('0')
        payload += mode.encode() + b' ' + entry['path'].encode() + b'\0' + bytes.fromhex(entry['sha'])
    return hashlib.sha1(b'tree ' + str(len(payload)).encode() + b'\0' + payload).hexdigest()

assert len(nodes) == 13
for path, node in nodes.items():
    assert tree_oid(node['tree']) == node['sha']
    if path:
        parent, _, name = path.rpartition('/')
        assert next(e['sha'] for e in nodes[parent]['tree'] if e['path'] == name) == node['sha']
assert nodes['']['sha'] == bridge['source_tree']
changed = {r['path']: r for r in bridge['six_changes']}
for path, row in changed.items():
    directory, _, name = path.rpartition('/')
    leaf = next(e for e in nodes[directory]['tree'] if e['path'] == name)
    assert leaf['mode'] == '100644' and leaf['type'] == 'blob'
    assert leaf['sha'] == row['after']['git_blob'] and leaf['size'] == row['after']['bytes']
reverse = {}
for path in sorted(nodes, key=lambda p: len(p.split('/')), reverse=True):
    entries = [dict(e) for e in nodes[path]['tree']]
    for entry in entries:
        full = path + '/' + entry['path'] if path else entry['path']
        if full in changed:
            entry['sha'] = changed[full]['before']['git_blob']
        elif entry['type'] == 'tree' and full in reverse:
            entry['sha'] = reverse[full]
    reverse[path] = tree_oid(entries)
assert reverse[''] == 'e039a817291934b15cc018fd74d2c83982bb7f37'
print(json.dumps(dict(source=bridge['source'], source_tree=bridge['source_tree'],
                      directories_hashed=len(nodes), actual_mode_blob_leaves_verified=6,
                      reversing_only_six_leaves_restores_exact_G6B_tree=reverse[''],
                      all_other_git_paths_modes_preserved=True)))
