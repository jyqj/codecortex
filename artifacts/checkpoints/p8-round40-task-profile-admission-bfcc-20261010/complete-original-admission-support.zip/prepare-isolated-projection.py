#!/usr/bin/env python3
"""Prepare an exact selected view after real P/R/G metadata becomes available.

No CLI, Rust or workload is executed here. Shared object caches are read-only.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'guard-view'
INPUT = ROOT / 'inputs'
OLD = ROOT.parent / 'round32-capture-context-admission/guard-view'
HISTORY = ROOT.parent / 'round30-PR191-equal-lifetime-admission'
ENV = {**os.environ, 'GIT_NO_LAZY_FETCH': '1', 'GIT_TERMINAL_PROMPT': '0', 'GIT_OPTIONAL_LOCKS': '0'}


def meta(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                git_blob=hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest())


def dump(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def command(name, argv, data=None, cwd=None):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (ROOT / (name + '.stdout')).open('xb') as stdout, (ROOT / (name + '.stderr')).open('xb') as stderr:
        result = subprocess.run(argv, input=data, cwd=cwd or REPO, env=ENV, stdout=stdout, stderr=stderr)
    output, error = [(ROOT / (name + '.' + suffix)).read_bytes() for suffix in ('stdout', 'stderr')]
    dump(ROOT / (name + '.receipt.json'), dict(argv=argv, cwd=str(cwd or REPO), exit_code=result.returncode,
         started_at=started, completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         stdout=meta(output), stderr=meta(error)))
    if result.returncode:
        raise RuntimeError((name, result.returncode, error.decode(errors='replace')))
    return output


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=REPO, env=ENV)


def main():
    binding = json.loads((INPUT / 'actual-G-binding.json').read_text())
    review = json.loads((INPUT / 'independent-source-review.json').read_text())
    for key in ('source', 'source_tree', 'review', 'review_tree', 'product', 'product_tree'):
        assert isinstance(binding[key], str) and re.fullmatch('[0-9a-f]{40}', binding[key]), key
    G, R, P = [binding[key] for key in ('source', 'review', 'product')]
    assert P == 'da4584aebf2bba1b4b0a53a93ac2f9ae8f9de032'
    assert review['source'] == P
    assert review['review_path'] == binding['review_path']
    assert meta((INPUT / 'independent-source-review.json').read_bytes())['sha256'] == binding['review_sha256']
    REPO.mkdir(exist_ok=False)
    command('01-git-init', ['git', 'init', '--quiet'], cwd=REPO)
    command('02-git-origin', ['git', 'remote', 'add', 'origin', 'https://github.com/jyqj/codecortex'])
    command('03-promisor-config', ['git', 'config', 'remote.origin.promisor', 'true'])
    command('04-filter-config', ['git', 'config', 'remote.origin.partialclonefilter', 'blob:none'])
    caches = [OLD / '.git/objects', HISTORY / 'guard-view-attempt02/.git/objects']
    assert all(path.is_dir() for path in caches)
    (REPO / '.git/objects/info/alternates').write_text(''.join(str(path) + '\n' for path in caches))
    shallow = set()
    shallow_inputs = []
    for cache in (OLD, HISTORY / 'guard-view-attempt02'):
        path = cache / '.git/shallow'
        raw = path.read_bytes() if path.exists() else b''
        shallow.update(raw.splitlines())
        shallow_inputs.append(dict(path=str(path), **meta(raw)))
    if shallow:
        (REPO / '.git/shallow').write_bytes(b'\n'.join(sorted(shallow)) + b'\n')
    dump(ROOT / 'readonly-cache-reuse.json', dict(caches=[str(p) for p in caches],
         shallow_inputs=shallow_inputs, shared_caches_modified=False))
    command('05-actual-G-R-P-metadata-fetch', ['git', '-c', 'fetch.negotiationAlgorithm=noop',
            'fetch', '--no-tags', '--filter=blob:none', '--depth=1', 'origin', G, R, P])
    for commit, tree, parents in ((G, binding['source_tree'], [R]),
                                 (R, binding['review_tree'], [P]),
                                 (P, binding['product_tree'], ['b9b089bb4eae072affe9326681d4980eae15fd84'])):
        raw = git('cat-file', 'commit', commit).decode()
        assert raw.splitlines()[0] == 'tree ' + tree
        assert [line[7:] for line in raw.split('\n\n', 1)[0].splitlines() if line.startswith('parent ')] == parents
    protected = json.loads((HISTORY / 'historical-protected-paths.json').read_text())
    docs = {'README.md'} | {'docs/roadmap/code-index-v2/' + name for name in (
        'tasks.json', '06-VALIDATION.md', '05-TODO.md', 'README.md', '08-HANDOFF.md')}
    paths = set(review['complete_inputs']) | set(review['validation_inputs']) | set(protected) | docs | {
        binding['review_path'], 'scripts/verify_reviewed_source_v15.py',
        'scripts/reviewed-source-registry-v15.json', '.github/workflows/ci.yml'}
    entries = {}
    for row in git('ls-tree', '-rz', G, '--', *sorted(paths)).split(b'\0'):
        if not row:
            continue
        header, path = row.decode().split('\t', 1)
        mode, kind, oid = header.split()
        assert kind == 'blob' and mode in ('100644', '100755')
        entries[path] = dict(mode=mode, git_blob=oid)
    assert set(entries) == paths
    inventory = review['actual_input_mode_blob_inventory']
    for path, item in inventory.items():
        assert entries[path] == dict(mode=item['mode'], git_blob=item['sha']), path
    historic = json.loads((HISTORY / 'recursive-declared-closure.all-blob-locators.json').read_text())
    unique = sorted({item['git_blob'] for item in entries.values()} | set(historic))
    initial = command('06-current-and-history-presence', ['git', 'cat-file', '--batch-check=%(objectname) %(objecttype)'],
                      ('\n'.join(unique) + '\n').encode())
    missing = [line.split()[0] for line in initial.decode().splitlines() if line.endswith(' missing')]
    dump(ROOT / 'selected-current-history-closure.json', dict(source=G, current_selected=len(entries),
         historical_declared_blobs=len(historic), unique_blobs=len(unique), missing=missing,
         history_origin=str(HISTORY / 'recursive-declared-closure.complete-review.json')))
    if missing:
        command('07-missing-declared-blobs-fetch', ['git', '-c', 'fetch.negotiationAlgorithm=noop',
                'fetch', '--no-tags', '--no-write-fetch-head', 'origin', '--stdin'], ('\n'.join(missing) + '\n').encode())
    final = command('08-complete-presence', ['git', 'cat-file', '--batch-check=%(objectname) %(objecttype)'],
                    ('\n'.join(unique) + '\n').encode())
    assert not any(line.endswith(' missing') for line in final.decode().splitlines())
    command('09-read-actual-G-index', ['git', 'read-tree', G])
    command('10-detach-local-actual-G-HEAD', ['git', 'update-ref', '--no-deref', 'HEAD', G])
    process = subprocess.Popen(['git', 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, cwd=REPO, env=ENV)
    for path, item in sorted(entries.items()):
        process.stdin.write((item['git_blob'] + '\n').encode())
        process.stdin.flush()
        header = process.stdout.readline().decode().split()
        assert header[:2] == [item['git_blob'], 'blob'], (path, header)
        raw = process.stdout.read(int(header[2]))
        assert process.stdout.read(1) == b'\n' and meta(raw)['git_blob'] == item['git_blob']
        if path in inventory:
            assert meta(raw)['sha256'] == inventory[path]['sha256']
        target = REPO / path
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as output:
            output.write(raw)
        target.chmod(int(item['mode'][-3:], 8))
        item.update(meta(raw))
    process.stdin.close()
    error = process.stderr.read()
    assert process.wait() == 0, error
    assert git('rev-parse', 'HEAD').decode().strip() == G
    assert git('write-tree', '--missing-ok').decode().strip() == binding['source_tree']
    assert not git('diff-index', '--cached', '--name-only', G)
    dump(ROOT / 'actual-G-pre-admission-inputs.json', dict(source=G, source_tree=binding['source_tree'],
         product=P, review=R, selected_entries=entries,
         counts=dict(product=len(review['complete_inputs']), BASE_delta=len(review['paths']),
                     validation=len(review['validation_inputs']), selected=len(entries)),
         scope='Actual immutable G selected-file projection; exact real index/HEAD. No full checkout or Rust execution claimed.'))
    print(json.dumps(dict(status='materialized', source=G, selected=len(entries),
                         historical_blobs=len(historic), missing_before_recovery=len(missing))))


if __name__ == '__main__':
    main()
