from pathlib import Path
import datetime
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parent
def meta(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), git_blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest())
def write(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True); f.write('\n')
files=[
    'candidate/scripts/p8_task_profile_capture.py',
    'candidate/scripts/tests/test_p8_task_profile_capture.py',
    'candidate/.github/workflows/p8-task-profile.yml',
    'prepare-workflow.py',
    'verify-owned-capture-and-workflow.py',
    'workflow-generation-attempt01.json',
    'actual-host-controls-attempt01/actual-controls-and-workflow-review.json',
    'actual-host-controls-attempt01/capture-controls.stdout',
    'actual-host-controls-attempt01/capture-controls.stderr',
    'seal-author-evidence.py',
]
items={path:meta((ROOT/path).read_bytes()) for path in files}
report=json.loads((ROOT/'actual-host-controls-attempt01/actual-controls-and-workflow-review.json').read_text())
assert report['exit_code']==0 and report['inputs_unchanged']
assert all(x['exit_code']==0 for x in report['shell_syntax'])
out=ROOT/'sealed'; out.mkdir()
archive=out/'complete-author-support.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in files:
        info=zipfile.ZipInfo(path, date_time=(2026,10,10,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED; info.external_attr=0o100644<<16
        z.writestr(info, (ROOT/path).read_bytes())
author=dict(scope='Root authored three task capture/workflow leaves. Actual harmless controls and syntax checks only.',
    author='root', sealed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    actual_product_commit='da4584aebf2bba1b4b0a53a93ac2f9ae8f9de032',
    exact_inputs=report['exact_inputs_after'], source_inputs_unchanged=True,
    executed=dict(capture_controls=3, exit_code=0, python_ast='passed', workflow_shape='passed', bash_n='passed'),
    rust_compilation='not_run', rustfmt='not_run', clippy='not_run', native_measurement='not_run',
    semantic_review='8adf965b33663cb72c138d3db69dce58142df0a7',
    runtime_interface_crosscheck='313b1c18bc754952c765eefbc7f6a7bfbc6558d9',
    notes=['The first workflow-generation parse failure occurred before execution and is retained.',
           'Twenty absolute periodic checkpoints and final index20 preserve the original capture ACK chain.',
           'The whole original shard is separately uploaded; aggregate excludes progress archives.',
           'No pre-existing diagnostic process, study, task status or approval guard was changed.'],
    support_archive=meta(archive.read_bytes()), support_members=items)
write(out/'author-capture-workflow-review.json',author)
selection=dict(repository_prefix='artifacts/checkpoints/p8-round40-complete-bfcc-20261010/candidate/capture-workflow',
    files=[dict(local_path=str(p), repository_name=p.name, **meta(p.read_bytes())) for p in [archive,out/'author-capture-workflow-review.json']])
write(out/'archive-selection.json',selection)
print(json.dumps(dict(archive=meta(archive.read_bytes()), members=len(items), report=meta((out/'author-capture-workflow-review.json').read_bytes()), selection=meta((out/'archive-selection.json').read_bytes()))))
