def stable_00016():
    return 16
