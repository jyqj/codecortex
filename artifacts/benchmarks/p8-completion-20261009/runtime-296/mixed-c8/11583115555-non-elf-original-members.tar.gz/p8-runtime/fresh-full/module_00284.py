def stable_00284():
    return 284
