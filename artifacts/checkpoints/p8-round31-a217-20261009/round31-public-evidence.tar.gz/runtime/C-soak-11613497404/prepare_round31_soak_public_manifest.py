#!/usr/bin/env python3
"""Inventory the retained C soak acceptance at the closed round-31 cutoff."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import stat

B = Path('/workspace/scratch/a217aaae3bde')
BASE = B / 'original-C3ff-runtime'
OUT = BASE / 'round31-soak-public-archive'
ARTIFACT = 11613497404
CUTOFF = '2026-10-09T12:34:58+00:00'


def identity(p):
    raw = p.read_bytes()
    assert not re.search(rb'"(?:file_id|file_uri|signed_url)"\s*:', raw, re.I), str(p)
    assert not re.search(rb'[?&](?:X-Amz-Signature|sig)=[A-Za-z0-9%]{12,}', raw), str(p)
    assert not re.search(rb'"authorization"\s*:\s*"(?:Bearer|Basic)\s', raw, re.I), str(p)
    return dict(source=p.relative_to(B).as_posix(), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest(),
                git_blob=hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
                mode=format(stat.S_IMODE(p.stat().st_mode), '04o'))


def main():
    OUT.mkdir(exist_ok=True)
    assert not any(OUT.iterdir()), 'do not overwrite a frozen public manifest'
    selected = []
    def add(p, target, scope):
        assert p.is_file() and not p.is_symlink()
        selected.append(dict(target=target, scope=scope, **identity(p)))
    adir = BASE / 'artifacts' / str(ARTIFACT)
    execution = json.loads((adir / 'actual-acceptance-execution.json').read_bytes())
    assert execution['artifact_id'] == ARTIFACT and execution['workflow_run'] == 37908825814
    assert execution['source'] == '3ffcefc3b28ee1a4ed80caecebd7208a45c3e302'
    assert datetime.datetime.fromisoformat(execution['finished_at']) <= datetime.datetime.fromisoformat(CUTOFF)
    assert all(x['exit_code'] == 0 for x in execution['commands'])
    for name in ['acceptance-manifest.json', 'actual-acceptance-execution.json', 'artifact-metadata.json',
                 'preflight-and-extraction.json', 'preflight.stderr', 'preflight.stdout',
                 'ram-derived-reclamation-candidate.json', 'ram-derived-reclamation-execution.json',
                 'runtime-review.stderr', 'runtime-review.stdout']:
        add(adir / name, 'runtime/C-soak-11613497404/intake/' + name,
            'Original completed acceptance/intake or exact reversible RAM cleanup record; original ZIP excluded.')
    for entry in execution['retained_output_copies']:
        p = Path(entry['workspace_preserved_output'])
        current = identity(p)
        assert current['bytes'] == entry['bytes'] and current['sha256'] == entry['sha256']
        target = 'runtime/C-soak-11613497404/accepted/' + p.relative_to(BASE / 'accepted').as_posix()
        add(p, target, 'Original reviewer output or actual Rust statistics/no-repair 15-table replay output, retained byte-identically from RAM.')
    for name in ['run_soak_round31_ram_once.py', 'reclaim_soak_round31_ram_derivatives.py',
                 'prepare_round31_soak_public_manifest.v1.py', 'round31-soak-public-preparation-v1-note.json']:
        add(BASE / name, 'runtime/C-soak-11613497404/' + name,
            'Actual one-invocation storage wrapper or protected derivative-only reclamation implementation.')
    for p in sorted((BASE / 'monitor-1143').glob('*.json')):
        add(p, 'runtime/C-soak-11613497404/official-terminal-capture/' + p.name,
            'Original official full jobs/artifacts pages captured after the original C soak terminal result.')
    add(Path(__file__).resolve(), 'runtime/C-soak-11613497404/prepare_round31_soak_public_manifest.py',
        'Post-cutoff packaging inventory only; does not add or rerun measurement evidence.')
    assert len({x['source'] for x in selected}) == len(selected)
    assert len({x['target'] for x in selected}) == len(selected)
    previous = {}
    scopes = [('mixed-c1', 11611743908), ('mixed-c4', 11612539681),
              ('mixed-c8', 11612256751), ('mixed-c16', 11611524778), ('backfill', 11610619483)]
    for name, artifact in scopes:
        p = BASE / 'accepted' / (('backfill-' + str(artifact) + '-3ffcefc3-independent') if name == 'backfill'
                                else ('artifact-' + str(artifact) + '-3ffcefc3-independent-final')) / 'independent-review.json'
        previous[name] = dict(artifact_id=artifact, already_archived_prior_rounds=True, **identity(p))
    helpers = {p: digest for p, digest in execution['helper_inputs_before'].items()}
    assert helpers == execution['helper_inputs_after']
    for p, digest in helpers.items():
        assert identity(Path(p))['sha256'] == digest
    selected.sort(key=lambda x: x['target'])
    record = dict(schema='round31-current-C-final-soak-public-inventory-v1', cutoff_utc=CUTOFF,
                  generated_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  source=execution['source'], workflow_run=37908825814, artifact_id=ARTIFACT,
                  file_count=len(selected), total_bytes=sum(x['bytes'] for x in selected), files=selected,
                  original_zip=dict(local_path=str(adir / (str(ARTIFACT) + '.zip')),
                                    bytes=execution['original_zip_bytes'],
                                    sha256=execution['original_zip_sha256_before'],
                                    included_in_this_manifest=False,
                                    custody='Original ZIP retained locally and on Actions; permanent full-ZIP Git custody not asserted.'),
                  already_archived_previous_five_scope_reviews=previous,
                  prior_frozen_helper_references=helpers,
                  prior_helper_adaptation_manifest_sha256=execution['helper_adaptation_manifest_sha256'],
                  helpers_recopied=False, original_runtime_profiles_accepted_at_cutoff=6,
                  cutoff_scope='The last C soak was actually accepted at 11:46:31 UTC; prior five C profiles retain their original identities. This is not LG/G2 diagnostic acceptance.',
                  preserved_limits=['Configured C4 soak had actual serial RPC peak1; no saturation claim.',
                                    'One original >=3600-second workload; no new native workload or additional sample.',
                                    'Rust statistics and no-repair oracle only replayed retained original evidence.',
                                    'P8-007 separate real DB acquisition observation gap remains outside this C soak result.',
                                    'No new complete-scale, task or release approval.'],
                  excluded=['original ZIP', 'private-transfer.json and private transport identifiers',
                            'executables and large raw databases/requests', 'already archived original helper sources'],
                  publication_status='local exact public file inventory only; root owns final remote publication',
                  formal_task_completion=False, formal_done=163, formal_remaining=29)
    raw = (json.dumps(record, sort_keys=True, indent=2) + '\n').encode()
    path = OUT / 'new-public-files-manifest.json'
    path.open('xb').write(raw)
    print(json.dumps(dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                          file_count=len(selected), total_bytes=record['total_bytes'])), flush=True)


if __name__ == '__main__':
    main()
