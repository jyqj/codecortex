#!/usr/bin/env python3
"""Run the remaining fixed local1k cells sequentially; stop on any failure."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
WRAPPER_SHA = "08f72c7a7187dea2d94053ac45666ae11210984709b6e21b0f18d14e6f08c991"
REVIEW_SHA = "e2a7dfd75d84830e7b4037889678e871bfb2f925eaf4a5d6fb4c1fb4b7eb26ff"
OUT = Path("/workspace/scratch/2eaa00d0f93a/p8-local-G-1k-20261008")

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def main():
    wrapper = HERE / "run_cell.py"
    assert hashlib.sha256(wrapper.read_bytes()).hexdigest() == WRAPPER_SHA
    review = Path("/dev/shm/p8-local-first-cell-independent-review/inspection.json")
    assert hashlib.sha256(review.read_bytes()).hexdigest() == REVIEW_SHA
    assert json.loads(review.read_text())["decision"] == "accepted_scoped_exact_G_registered_primary_cell_1000_0"
    first = json.loads((OUT / "controls/00/execution.json").read_text())
    assert first["status"] == "passed_original_cell_and_validation"
    control = OUT / "controls/remaining-sequence"
    control.mkdir(exist_ok=False)
    launch = {"started_utc": now(), "indices": list(range(1, 30)),
              "wrapper_sha256": WRAPPER_SHA, "first_cell_independent_review_sha256": REVIEW_SHA,
              "sequencer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "policy": "Sequential original cells, no added deadline, stop at first nonzero, no replacement or rerun."}
    with (control / "launch.json").open("x") as stream:
        json.dump(launch, stream, indent=2, sort_keys=True)
        stream.write("\n")
    env = dict(os.environ)
    env.update(PYTHONDONTWRITEBYTECODE="1", RUSTFLAGS="")
    with (control / "completed.jsonl").open("x") as completed:
        for index in range(1, 30):
            assert hashlib.sha256(wrapper.read_bytes()).hexdigest() == WRAPPER_SHA
            command = [sys.executable, "-B", str(wrapper), "--index", str(index)]
            code = subprocess.call(command, env=env)
            row = {"shard_index": index, "wrapper_exit_code": code, "finished_utc": now()}
            completed.write(json.dumps(row, sort_keys=True) + "\n")
            completed.flush()
            if code:
                raise SystemExit(code)
    with (control / "finished.json").open("x") as stream:
        json.dump({"finished_utc": now(), "status": "all_29_remaining_wrappers_exit_zero",
                   "scope": "Local1k cohort only; not a complete150cell matrix or TODO closure."}, stream, indent=2, sort_keys=True)
        stream.write("\n")

if __name__ == "__main__":
    main()
