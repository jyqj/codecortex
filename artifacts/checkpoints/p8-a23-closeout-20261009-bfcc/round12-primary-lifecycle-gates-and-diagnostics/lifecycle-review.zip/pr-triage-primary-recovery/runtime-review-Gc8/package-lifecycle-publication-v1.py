from pathlib import Path
import json,hashlib,tarfile,gzip,io,datetime,re
p=Path(__file__).resolve().parent; root=p.parent; raw=root/'raw-pr178-c8be5afa/11604870469'; base=raw/'attempt01/extracted'
receipt=json.loads((base/'measurement/receipt.json').read_text())
prefix=Path('/home/runner/work/_temp/p8-lifecycle')
excluded={Path(o['path']).relative_to(prefix).as_posix() for x in receipt['storage'] for o in x['objects']}
excluded.update(('product/codecortex','p8-measurements'))
files=sorted(f for f in base.rglob('*') if f.is_file() and f.relative_to(base).as_posix() not in excluded)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
members=[];archive=p/'lifecycle-original-json-stdio-and-fixtures.tar.gz'
with archive.open('xb') as of,gzip.GzipFile(filename='',mode='wb',fileobj=of,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as t:
 for f in files:
  b=f.read_bytes();name=f.relative_to(base).as_posix(); assert not f.is_symlink()
  ti=tarfile.TarInfo(name);ti.size=len(b);ti.mode=f.stat().st_mode&0o777;ti.mtime=0;t.addfile(ti,io.BytesIO(b))
  members.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with tarfile.open(archive,'r:gz') as t:
 actual=t.getmembers();assert len(actual)==len(members)
 for tm,expected in zip(actual,members):assert tm.name==expected['path'] and tm.isfile() and tm.size==expected['bytes'] and hashlib.sha256(t.extractfile(tm).read()).hexdigest()==expected['sha256']
manifest={'schema_version':1,'artifact_id':11604870469,'source':'c8be5afaac568ffd40ef86d3795423c3b73c9f39','purpose':'Byte-exact original JSON, stdio, authored fixtures and build receipts in a new reversible archive. This is not the GitHub original ZIP and provides no new execution credit. All tar names are original ZIP-relative names; archived raw bytes are unchanged. Gzip/tar metadata is newly generated deterministically.','original_zip':{'artifact_id':11604870469,'bytes':49229993,'sha256':'842cd433e6f67769f1ce10411be61a1e7bc621aeec3ca4d00bc1e7a2a92ed237','locator':'https://github.com/jyqj/codecortex/actions/runs/37901930818/artifacts/11604870469'},'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(members),'uncompressed_bytes':sum(x['bytes'] for x in members),'all_members_reread_and_hash_matched':True},'excluded_original_members':[{'path':n,'bytes':(base/n).stat().st_size,'sha256':sha(base/n)} for n in sorted(excluded)],'files':members}
out=p/'lifecycle-original-small-raw-archive-manifest.json'
with out.open('x') as f:json.dump(manifest,f,indent=2);f.write('\n')
print(json.dumps(manifest['archive']));print(out.name,out.stat().st_size,sha(out))
