from pathlib import Path
import hashlib,json,zipfile,subprocess,base64,datetime,sys,time
base=Path.cwd()/'artifacts/benchmarks/p8-bfccb8494ba0';out=base/'native-public-api-merge-H2-e564-admission'
(out/'package-H-and-H2-controller.py').write_bytes(Path(sys.argv[0]).read_bytes())
r=json.loads((out/'original-v15-command-receipt.json').read_text())
assert r['exit_code']==0 and r['source_H2']=='e5640904298febdf8dc951e0baddb2819f930c0b' and 'controller_exception' not in r
assert r['domain_before']['sha256']==r['domain_after']['sha256'] and r['domain_before']['count']==1435
cli=json.loads((out/'original-v15.stdout').read_text());assert cli['status']=='passed' and cli['complete_inputs']==1093
roots={'H-preparation':base/'native-public-api-merge-H-399a-admission','H2-admission':out}
files=[]
for label,folder in roots.items():
 for p in sorted(folder.iterdir()):
  assert p.is_file(),str(p)
  b=p.read_bytes();files.append({'path':label+'/'+p.name,'original_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':oct(p.stat().st_mode&0o777)})
manifest={'schema_version':1,'H_prepared_only':'399a71a4c11e7041ce9946fba4d3f72200c47155','H2_executed':'e5640904298febdf8dc951e0baddb2819f930c0b','scope':'All original H/H2 selected-checkout preparation and the single actual H2 original v15 execution; H had no original v15 execution. H2 1435 inputs unchanged before/after, original CLI exit0; no new 181 suite, Rust, benchmark or TODO completion claim.','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files}
mb=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();zp=base/'native-public-api-H-and-H2-original-v15.zip';assert not zp.exists()
with zipfile.ZipFile(zp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in files:z.writestr(f['path'],Path(f['original_path']).read_bytes())
 z.writestr('archive-manifest.json',mb)
with zipfile.ZipFile(zp) as z:
 assert z.testzip() is None and len(z.infolist())==len(files)+1
 for f in files:
  b=z.read(f['path']);assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
raw=zp.read_bytes();oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();transport_text=base64.b64encode(raw).decode()
receipt={'zip_path':str(zp),'zip_bytes':len(raw),'zip_sha256':hashlib.sha256(raw).hexdigest(),'git_blob':oid,'members':len(files)+1,'selected_files':len(files),'expanded_bytes':sum(x['bytes'] for x in files)+len(mb),'base64_chars':len(transport_text),'base64_sha256':hashlib.sha256(transport_text.encode()).hexdigest()}
for label,encoding in [('binary','base64'),('base64-transport','utf-8')]:
 body=json.dumps({'content':transport_text,'encoding':encoding}).encode();cmd=['/opt/homebrew/bin/gh','api','-X','POST','repos/jyqj/codecortex/git/blobs','--input','-'];start=time.monotonic();p=subprocess.run(cmd,input=body,capture_output=True)
 receipt[label]={'command':cmd,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}
 if p.returncode:
  print(p.stderr.decode(errors='replace'));(base/'native-public-api-H-and-H2-original-v15-transport.json').write_text(json.dumps(receipt,indent=2)+'\n');sys.exit(p.returncode)
 result=json.loads(p.stdout);receipt[label]['sha']=result['sha'];expected=oid if encoding=='base64' else hashlib.sha1(b'blob '+str(len(transport_text)).encode()+b'\0'+transport_text.encode()).hexdigest();assert result['sha']==expected
 (base/'native-public-api-H-and-H2-original-v15-transport.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
