def stable_00258():
    return 258
