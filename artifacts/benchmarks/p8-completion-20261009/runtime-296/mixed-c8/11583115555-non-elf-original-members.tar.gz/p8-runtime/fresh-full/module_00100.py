def stable_00100():
    return 100
