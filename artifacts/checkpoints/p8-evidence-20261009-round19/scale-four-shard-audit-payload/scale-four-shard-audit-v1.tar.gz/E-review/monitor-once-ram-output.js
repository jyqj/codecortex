(async()=>{
const run=37872522779, head="a23bb72d3c954f385b99fe81ce9189885c208557", attempt=1;
const base="/dev/shm/a217aaae3bde/scale-combined-E-review/official-collection-snapshots";
const stamp=String(Date.now());
async function save(name,value){
 const path=base+"/"+stamp+"-"+name+".json";
 const patch="*** Begin Patch\n*** Add File: "+path+"\n"+JSON.stringify(value,null,2).split("\n").map(x=>"+"+x).join("\n")+"\n*** End Patch";
 const result=await tools.apply_patch(patch);if(result?.isError)throw Error("snapshot save failed");
 return path;
}
async function single(){
 const requested="https://api.github.com/repos/jyqj/codecortex/actions/runs/"+run+"?readback="+stamp+"-run";
 const r=await tools.mcp__codex_apps__github_fetch({url:requested});
 const content=r.structuredContent?.content;if(typeof content!=="string")throw Error("run metadata absent");
 const d=JSON.parse(content),path=await save("run",{observed_utc:new Date().toISOString(),requested_url:requested,original_content:content});
 if(d.id!==run||d.head_sha!==head||d.run_attempt!==attempt||d.path!==".github/workflows/p8-scale.yml")throw Error("run identity differs");
 return {data:d,path};
}
async function collection(kind){
 const url="https://api.github.com/repos/jyqj/codecortex/actions/runs/"+run+"/"+kind+"?per_page=100&page=";
 async function page(n){
  const requested=url+n+"&readback="+stamp+"-"+kind+"-"+n;
  const r=await tools.mcp__codex_apps__github_fetch({url:requested});
  const content=r.structuredContent?.content;
  if(typeof content!=="string")throw Error(kind+" missing page "+n);
  return {page:n,requested_url:requested,content,parsed:JSON.parse(content)};
 }
 const first=await page(1),total=first.parsed.total_count;
 if(!Number.isSafeInteger(total)||total<0)throw Error(kind+" invalid total_count");
 const rest=await Promise.allSettled(Array.from({length:Math.max(0,Math.ceil(total/100)-1)},(_,i)=>page(i+2)));
 const pages=[first],errors=[];
 for(const r of rest)if(r.status==="fulfilled")pages.push(r.value);else errors.push(String(r.reason));
 const path=await save(kind,{schema:"read-only-github-collection-snapshot-v1",observed_utc:new Date().toISOString(),run_id:run,head_sha:head,run_attempt:attempt,kind,pages:pages.map(({parsed,...r})=>r),transport_errors:errors});
 if(errors.length)throw Error(errors.join("; "));
 if(pages.some(p=>p.parsed.total_count!==total))throw Error(kind+" moving total_count; all raw pages retained, next observation must recollect");
 const items=pages.flatMap(p=>p.parsed[kind]);
 if(items.length!==total||new Set(items.map(x=>x.id)).size!==items.length)throw Error(kind+" incomplete/duplicate collection");
 for(const x of items){
  if(kind==="jobs"){
   if(x.run_id!==run||x.head_sha!==head||x.run_attempt!==attempt)throw Error("job identity differs");
  }else if(x.workflow_run?.id!==run||x.workflow_run?.head_sha!==head)throw Error("artifact identity differs");
 }
 return {total_count:total,[kind]:items,path};
}
const all=await Promise.allSettled([single(),collection("jobs"),collection("artifacts")]);
const output={observed_utc:new Date().toISOString(),run_id:run,source_commit:head,metadata_paths:[]};
for(let i=0;i<all.length;i++){
 const r=all[i];
 if(r.status!=="fulfilled"){(output.errors??=[]).push({kind:["run","jobs","artifacts"][i],error:String(r.reason)});continue;}
 const d=r.value;output.metadata_paths.push(d.path);
 if(i===0){output.status=d.data.status;output.conclusion=d.data.conclusion;store("E_scale_run_metadata",d.data);}
 if(i===1){
  const prev=load("E_scale_jobs"),project=j=>({id:j.id,name:j.name,status:j.status,conclusion:j.conclusion,steps:j.steps});
  const old=new Map((prev?.jobs||[]).map(j=>[j.id,JSON.stringify(project(j))]));
  output.total_jobs=d.total_count;output.changed_jobs=d.jobs.filter(j=>old.get(j.id)!==JSON.stringify(project(j))).map(j=>({id:j.id,name:j.name,status:j.status,conclusion:j.conclusion,active:j.steps?.filter(s=>s.status==="in_progress"||s.conclusion==="failure")}));
  output.status_counts={};for(const j of d.jobs){const k=j.status+":"+(j.conclusion||"");output.status_counts[k]=(output.status_counts[k]||0)+1;}
  store("E_scale_jobs",d);
 }
 if(i===2){
  const old=new Set((load("E_scale_artifacts")?.artifacts||[]).map(x=>x.id));
  output.total_artifacts=d.total_count;output.new_artifacts=d.artifacts.filter(a=>!old.has(a.id)).map(a=>({id:a.id,name:a.name,size_in_bytes:a.size_in_bytes,digest:a.digest}));
  store("E_scale_artifacts",d);
 }
}
store("E_scale_last_observation",output);text(output);
})();
