#[path = "/workspace/codecortex/crates/cc-search/src/dsl.rs"] mod dsl;
#[path = "/workspace/codecortex/crates/cc-search/src/query_target.rs"] mod query_target;
fn main() {
let rows: serde_json::Value=serde_json::from_str(include_str!("/workspace/independent-boundary-review/probes.json")).unwrap(); let mut out=Vec::new();
for row in rows.as_array().unwrap() { let q=row["query"].as_str().unwrap(); let parsed=dsl::parse_search_dsl(q); let t=query_target::QueryTarget::parse(&parsed);let ctx=query_target::NameBonusContext::parse(&parsed,&t);let kinds=["class","interface","type_alias","enum","module","namespace","method","function","unknown"];let flags:Vec<_>=kinds.iter().map(|k|serde_json::json!({"kind":k,"owner":ctx.permits("Beacon",Some(k)),"other":ctx.permits("Sink",Some(k))})).collect();out.push(serde_json::json!({"query":q,"dsl":parsed.text,"target":format!("{:?}",t),"context":format!("{:?}",ctx),"flags":flags,"contract":row["contract"]})); }
println!("{}",serde_json::to_string_pretty(&out).unwrap()); }
