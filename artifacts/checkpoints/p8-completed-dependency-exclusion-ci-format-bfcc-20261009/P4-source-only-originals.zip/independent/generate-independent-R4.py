#!/usr/bin/env python3
"""Read exact Git/source evidence and emit source-only R4; no tests or network."""
from pathlib import Path
import ast, copy, datetime, difflib, hashlib, json, re

ROOT=Path(__file__).resolve().parent
OLD=Path('/dev/shm/execution-recon-recovery-20261009/final-R3/independent-source-review.json')
AUTHOR=Path('/dev/shm/execution-recon-recovery-20261009/PR188-original-rustfmt-fix-v4')
OBS=Path('/dev/shm/pr-triage-round18-G3-C3ff-observation')
TOKENIZER=Path('/dev/shm/todo-audit-H-dependency-exclusion-v3/verify-and-freeze-formatting.py')
G='67b7f4ee15a9c9633868b446870fec1358dda3d9'
P='1930b8e37e24031c3779553e3fc5b95e8e946d50'
PTREE='9a96f4bcda2407927154b91f5a77c54d5f7670f4'
PATH='crates/cc-db/tests/p2b_resolution_store.rs'
PREFIX='artifacts/checkpoints/p8-completed-dependency-exclusion-ci-format-bfcc-20261009'
def read(p):return json.loads(Path(p).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def record(p):
    p=Path(p);b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=sha(b),git_blob=oid('blob',b))
def write(name,d):
    with (ROOT/name).open('x') as f:json.dump(d,f,ensure_ascii=False,sort_keys=True,indent=2);f.write('\n')
def tree_oid(rows):
    ordered=sorted(rows,key=lambda x:(x['path']+('/' if x['type']=='tree' else '')).encode())
    data=b''.join(x['mode'].lstrip('0').encode()+b' '+x['path'].encode()+b'\0'+bytes.fromhex(x['sha']) for x in ordered)
    return oid('tree',data)

prior_bytes=OLD.read_bytes();assert sha(prior_bytes)=='f8384ec7620c1f69be155f0a2c870e9c2fd06ff6de40920d7389c08d03d01080'
r3=json.loads(prior_bytes)
assert r3['source']=='aac83a8e57d87fa9fe95af16173c68f1dd4fb88e' and r3['verdict']=='accepted_scoped'
assert (len(r3['complete_inputs']),len(r3['validation_inputs']),len(r3['paths']),len(r3['actual_input_mode_blob_inventory']))==(1095,142,70,1237)
commit=read(ROOT/'github-api/actual-P4-commit.json');compare=read(ROOT/'github-api/actual-G3-to-P4-compare.json')
assert commit['sha']==P and commit['tree']['sha']==PTREE and [p['sha'] for p in commit['parents']]==[G]
assert compare['base_commit']['sha']==compare['merge_base_commit']['sha']==G and compare['total_commits']==1
assert len(compare['files'])==1 and compare['files'][0]['filename']==PATH and compare['files'][0]['status']=='modified'
before=(AUTHOR/'original'/PATH).read_bytes();after=(ROOT/'actual-source'/PATH).read_bytes()
assert before==bytes((AUTHOR/'original'/PATH).read_bytes()) and after==(AUTHOR/'candidate'/PATH).read_bytes()
assert oid('blob',before)=='265e2b7ae7660c7dbd07e2f8d8c26efe8206ff7c' and sha(before)==r3['complete_inputs'][PATH]
assert oid('blob',after)==compare['files'][0]['sha']=='9c2aa567b007cb7c3a97adce2bb7184c0662a18f'
assert len(after)==26615 and sha(after)=='c07be74c9b7c024b85200cf831340c96f3f54cc030182ac31aea733daa7df380'

# Reconstruct all four Git ancestor trees. Siblings are reused only after each
# complete original subtree object is independently rehashed to its official OID.
tree_files=['actual-G3-root-tree','actual-G3-crates-tree','actual-G3-ccdb-tree','actual-G3-ccdb-tests-tree']
trees=[read(ROOT/'github-api'/(n+'.json')) for n in tree_files]
parts=['crates','cc-db','tests','p2b_resolution_store.rs']
for i,t in enumerate(trees):
    assert t['truncated'] is False and tree_oid(t['tree'])==t['sha']
    leaf=next(x for x in t['tree'] if x['path']==parts[i])
    if i<3:assert leaf['sha']==trees[i+1]['sha'] and leaf['type']=='tree'
    else:assert leaf['sha']==oid('blob',before) and leaf['mode']=='100644' and leaf['type']=='blob'
assert trees[0]['sha']=='e7a7f5a685c44aee34b8716377308f0af8782fdd'
replacement=oid('blob',after);proof=[]
for i in reversed(range(4)):
    rows=copy.deepcopy(trees[i]['tree']);leaf=next(x for x in rows if x['path']==parts[i]);leaf['sha']=replacement
    replacement=tree_oid(rows)
    proof.append(dict(ancestor=tree_files[i],before=trees[i]['sha'],after=replacement,only_replaced_child=parts[i]))
assert replacement==PTREE

# Original failed formatter output independently reconstructs the actual P4
# bytes. Nothing is inferred from a successful formatter execution.
log=(OBS/'failed-check-113861171381.decoded.log').read_bytes()
assert sha(log)=='1189bd605ebf6e967502fe98b65fb3b112c451485659668217168fd2a2680fcc'
hunks=[];current=None
for line in log.decode().splitlines():
    payload=re.sub(r'^\S+Z ','',line)
    if payload.startswith('Diff in '):
        assert '/'+PATH+':' in payload
        current={'header':payload,'old':[],'new':[]};hunks.append(current)
    elif current is not None and payload[:1] in (' ','+','-'):
        if payload[0] in (' ','-'):current['old'].append(payload[1:]+'\n')
        if payload[0] in (' ','+'):current['new'].append(payload[1:]+'\n')
    else:current=None
assert len(hunks)==3
reconstructed=before.decode()
for h in hunks:
    a,b=''.join(h['old']),''.join(h['new']);assert reconstructed.count(a)==1
    reconstructed=reconstructed.replace(a,b,1)
assert reconstructed.encode()==after
patch='diff --git a/'+PATH+' b/'+PATH+'\nindex '+oid('blob',before)+'..'+oid('blob',after)+' 100644\n'
patch+=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+PATH,tofile='b/'+PATH))
assert patch.encode()==(AUTHOR/'source.patch').read_bytes()

# Reviewed pure lexical helper only; no prior main/import/test execution.
module=ast.parse(TOKENIZER.read_text());fn=next(x for x in module.body if isinstance(x,ast.FunctionDef) and x.name=='tokens')
ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<reviewed pure Rust lexical helper>','exec'),ns)
a=ns['tokens'](before.decode());b=ns['tokens'](after.decode());at=[x['token'] for x in a];bt=[x['token'] for x in b];insertions=[]
for tag,i,j,k,l in difflib.SequenceMatcher(a=at,b=bt,autojunk=False).get_opcodes():
    if tag=='equal':continue
    assert tag=='insert' and i==j and l==k+1
    insertions.append({'new_position':k,'token':bt[k],'new_line':b[k]['line']})
assert [x['token'] for x in insertions]==['{','}',',',',']
left,right=insertions[:2]
assert bt[left['new_position']-3:left['new_position']]==['|','row','|']
assert bt[left['new_position']+1:right['new_position']]==['row','.','get','::','<','_',',','String','>','(','0',')']
assert bt[insertions[2]['new_position']-1]=='"😀.py"' and bt[insertions[2]['new_position']+1]==']'
assert bt[insertions[3]['new_position']-4:insertions[3]['new_position']]==['map','(','unit',')'] and bt[insertions[3]['new_position']+1]==')'
normalized=bt.copy()
for row in reversed(insertions):del normalized[row['new_position']]
assert normalized==at

# Source-domain bridge inherits the already independently accepted R3 input
# identities; the actual complete P4 root proves only this one leaf changed.
inputs=copy.deepcopy(r3['complete_inputs']);inputs[PATH]=sha(after)
validation=copy.deepcopy(r3['validation_inputs']);modes=copy.deepcopy(r3['actual_input_mode_blob_inventory'])
assert modes[PATH]==dict(mode='100644',type='blob',sha=oid('blob',before),size=len(before),sha256=sha(before))
modes[PATH]=dict(mode='100644',type='blob',sha=oid('blob',after),size=len(after),sha256=sha(after))
delta=copy.deepcopy(r3['paths']);delta[PATH]['sha256']=sha(after)
assert sorted(p for p in inputs if inputs[p]!=r3['complete_inputs'][p])==[PATH]
assert len(delta)==70 and all(set(v)=={'before_sha256','sha256'} for v in delta.values())
assert all(delta[p]['before_sha256']==r3['paths'][p]['before_sha256'] for p in delta)
assert validation==r3['validation_inputs'] and set(modes)==set(inputs)|set(validation)
for p,d in modes.items():assert d['sha256']==(inputs|validation)[p]
review={'schema_version':1,'reviewer':'/root/pr_triage','actual_P4':P,'actual_P4_tree':PTREE,'sole_parent':G,'verdict':'accepted_scoped_source_only','Git_parent_root_and_all_siblings_verified':proof,'all_other_parent_Git_leaves_unchanged':True,'exact_official_compare_files':1,'actual_changed_path':PATH,'before':record(AUTHOR/'original'/PATH),'after':record(ROOT/'actual-source'/PATH),'formatter_hunks':[{k:v for k,v in h.items() if k=='header'} for h in hunks],'actual_P4_equals_exact_original_rustfmt_suggestion':True,'nonwhitespace_insertions':insertions,'all_other_tokens_including_literals_and_comments_exact':True,'semantic_judgment':'The braces make the identical row.get::<_, String>(0) the sole closure tail expression without a semicolon, statement or capture change. One trailing comma follows the fifth array element and the other follows the ordinary units.extend argument. Their optional syntax does not change values, order, result type, assertions, loops or tests. The third hunk changes whitespace only. This is not a claim that the patch is exclusively whitespace or that a compiler has run.','domain':{'product':1095,'validation':142,'BASE_delta':70,'unchanged_product':1094,'changed_product':1,'changed_validation':0},'exact_SQL_production_preserved':modes['crates/cc-db/src/resolution_dependency_store.rs']==r3['actual_input_mode_blob_inventory']['crates/cc-db/src/resolution_dependency_store.rs'],'old_actual_failure':{'source_G':G,'checkout':'645cbe3e04a8efe97a2063e2f65b0c637edbe526','job':113861171381,'command':'cargo fmt --all -- --check','toolchain':'stable rustc1.99.0','exit_code':1,'subsequent_Clippy_tests_181_v15':'skipped','log':record(OBS/'failed-check-113861171381.decoded.log')},'actual_P4_execution':'not_run','new_original_TODO_completed':0}
write('independent-actual-P4-format-and-domain-review.json',review)

canonical={k:copy.deepcopy(r3[k]) for k in ['schema_version','scope','base','source_modes','validation_modes','validation_path_reviewers','prior_SQL_probe']}
canonical.update(verdict='accepted_scoped',source=P,source_tree=PTREE,tree=PTREE,source_parent=G,source_parents=[G],reviewed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),independent_reviewers=['/root/pr_triage'],author_independence={'reviewer':'/root/pr_triage','candidate_author':'/root/execution_recon','source_commit_creator':'/root','reviewer_authored_current_product_or_validation_changes':False,'role_limit':'Only independent source/evidence review and archive packaging; no product source change, Rust/compiler execution, workflow execution or remote mutation.'},complete_input_count=1095,complete_inputs=inputs,changed_source_input_count=70,paths=delta,validation_input_count=142,validation_inputs=validation,actual_input_mode_blob_inventory=modes,unresolved_blockers=[])
canonical['source_path_reviewers']=copy.deepcopy(r3['source_path_reviewers'])
canonical['source_path_reviewers'][PATH]={'reviewer':'/root/pr_triage','review_kind':'Actual P4 official source/whole-tree identity and exact original rustfmt-output semantic bridge; inherited SQL/test semantics remain scoped to prior R3 unchanged tokens.','mode':'100644','git_blob':oid('blob',after),'current_byte_identity':modes[PATH],'before_sha256':delta[PATH]['before_sha256'],'execution_credit_to_current_source':False,'prior_R3_test_review':r3['source_path_reviewers'][PATH],'actual_format_and_domain_review':record(ROOT/'independent-actual-P4-format-and-domain-review.json')}
canonical['review_basis']={'method':'Official actual P4 commit, sole parent and complete one-file compare; all four original Git ancestor tree objects independently rehashed, followed by one-leaf replacement yielding actual P4 root. This proves every other Git leaf, including all archive/history/validation/CI/source inputs, unchanged. Full canonical maps are inherited from independently accepted exact R3/G3 and changed at the one actual P4 test leaf. Original three formatter hunks and entire literal/comment-aware token sequence independently matched actual P4. No large full checkout or holdout body read.','prior_R3':{**record(OLD),'commit':'4ec7543db94699077fe4075dd4b3606e92482460','repository_path':'artifacts/checkpoints/p8-dependency-exclusion-bfcc-20261009/independent-source-review.json'},'prior_G3_independent_bridge':record('/dev/shm/execution-recon-recovery-20261009/R3-G3-thin-review/actual-G3-independent-source-boundary-review.json'),'actual_P4_review':record(ROOT/'independent-actual-P4-format-and-domain-review.json'),'reviewed_pure_tokenizer':record(TOKENIZER),'retained_history':'Prior R3 review, original formatter failure, subsequent skipped steps, original +22.57 percent SQL probe counterexample and original Gc8 formal failure remain their exact original identities.','full_worktree_materialization_claim':False,'holdout_body_read':False}
canonical['current_execution_support']={'status':'runtime_not_run','acceptance_by_this_report':False,'actual_source':P,'rustfmt':'not_run_on_P4','Rust_compile':'not_run_on_P4','Rust_tests':'not_run_on_P4','Clippy':'not_run_on_P4','source_integrity_suite':'not_run_on_P4','selected_v15':'not_run_on_P4','scale_or_performance':'not_run_on_P4','prior_G3_failure':review['old_actual_failure'],'prior_G3_msrv_metadata':'Original G3 job113861171728 success is a different-source CI fact, not P4 execution.','pending_original_integration_tests':copy.deepcopy(r3['current_execution_support']['pending_original_integration_tests']),'prior_R3_current_execution_support_retained_with_original_source':{'source':r3['source'],'record':r3['current_execution_support']},'scope':'Future original CI/engineering execution must establish actual new-source success; no prior H/G1/G2/G3 or component observation is relabelled.'}
canonical['acceptance_boundary']=copy.deepcopy(r3['acceptance_boundary'])
canonical['acceptance_boundary'].update(source_level_acceptance_only=True,new_original_TODO_completed=0,TODO_done=163,TODO_remaining=29,unresolved_blockers_scope='No unresolved actual-source semantic/identity blocker; P4 fmt/tests/Clippy/source CLI/performance remain unexecuted. Source-only accepted_scoped is not execution acceptance.',prior_G3_actual_fmt_failure_retained=True,G2_complete_four_C_DB_wait_credit_to_P4=False,observed_G3_three_hunk_repair_not_automatic_fmt_pass=True)
write('independent-source-review.json',canonical)
print(json.dumps({'P4':P,'tree':PTREE,'one_file':PATH,'product':len(inputs),'validation':len(validation),'BASE_delta':len(delta),'source_only':True,'canonical':record(ROOT/'independent-source-review.json'),'review':record(ROOT/'independent-actual-P4-format-and-domain-review.json')}))
