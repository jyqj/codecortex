import datetime
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path('/workspace/scratch/bfccb8494ba0')
RAM = Path('/dev/shm/pr-triage-bfcc-c8be5afa')
OUT = ROOT / 'root-round12/publication-third'
PREFIX = 'artifacts/checkpoints/p8-a23-closeout-20261009-bfcc/round12-primary-platform-source-and-concurrency'
OUT.mkdir(parents=True, exist_ok=True)
groups, entries, selections, direct = {}, [], [], []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def member(p):
    p = p.resolve()
    if p.is_relative_to(ROOT):
        return p.relative_to(ROOT).as_posix()
    assert p.is_relative_to(RAM), str(p)
    return 'ram-intake/' + p.relative_to(RAM).as_posix()

def add(group, p, expected=None):
    p = Path(p)
    assert p.is_file() and not p.is_symlink(), str(p)
    name = member(p)
    data = p.read_bytes()
    if expected:
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256'], str(p)
    if p.name.endswith('.tar.gz'):
        assert expected and expected.get('repository_path'), str(p)
        assert len(data) <= 8 * 1024 * 1024, str(p)
        record = {'file_name':p.name, 'local_path':str(p), 'repository_path':expected['repository_path'],
                  'bytes':len(data), 'sha256':sha(data), 'git_blob_sha':blob(data),
                  'scope':'New lossless container of selected original artifact members, distinct from official GitHub ZIP.'}
        assert not any(x['repository_path'] == record['repository_path'] for x in direct)
        direct.append(record)
        entries.append({'direct_repository_path':record['repository_path'], 'original_local_path':str(p),
                        'bytes':len(data), 'sha256':sha(data)})
        return
    try:
        decoded = data.decode('utf-8')
    except UnicodeDecodeError:
        decoded = ''
    for pattern in [r'(?:[?&]|\\u0026)(?:sig|signature|x-amz-signature|x-goog-signature|token|access_token)=[A-Za-z0-9%/+_-]{12,}',
                    r'(?im)^set-cookie:\s*(?!\[?REDACTED)[^\r\n]{12,}']:
        assert not re.search(pattern, decoded, re.I), (str(p),'private transfer value')
    g = groups.setdefault(group, {})
    assert name not in g or g[name][1] == data, name
    g[name] = (str(p), data)

def select(group, source):
    p = Path(source)
    if not p.is_absolute():
        p = ROOT / p
    data = p.read_bytes()
    d = json.loads(data)
    add(group, p)
    selections.append({'local_path':str(p),'bytes':len(data),'sha256':sha(data)})
    for entry in d.get('files',d.get('entries',[])):
        p2 = Path(entry.get('local_path',entry.get('path')))
        if not p2.is_absolute():
            p2 = Path(d.get('base',str(p.parent))) / p2
        add(group,p2,entry)

select('concurrency-C8-C4-reviews',RAM/'runtime-review-Gc8/c8-publication-selection.json')
select('concurrency-C8-C4-reviews',RAM/'runtime-review-Gc8/c4-publication-selection.json')
add('concurrency-C8-C4-reviews',RAM/'runtime-review-Gc8/c8-c4-original-zip-member-bridge.json')
select('recovery-and-platform', 'todo-audit-round12/recovery-platform-Gc8/archive-selection.json')
select('recovery-and-platform', 'scale-intake-primary/historical-277f-peer/archive-selection.json')
select('original-CI-and-gates-reviews', 'todo-audit-round12/ci-original-check/archive-selection.json')
select('original-CI-and-gates-reviews', 'todo-audit-round12/gates-Gc8-transport-and-peer/archive-selection.json')
select('original-CI-and-gates-reviews', 'scale-intake-primary/gates-Gc8-peer/archive-selection.json')
add('original-CI-and-gates-reviews',ROOT/'scale-intake-primary/ci-original-check-peer.json')
for name in ['second-primary-git-publication-receipt.json','C8-C4-C1-platform-final-transfer-receipt.json',
             'publication-secondary/transport-copy-cleanup-receipt.json','prepare-third-publication.py']:
    add('root-coordination',ROOT/'root-round12'/name)

bundles = []
for group,files in sorted(groups.items()):
    p = OUT/(group+'.zip')
    assert not p.exists(), str(p)
    with zipfile.ZipFile(p,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,(original,data) in sorted(files.items()):
            info = zipfile.ZipInfo(name,date_time=(2026,10,9,0,0,0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
            entries.append({'archive':p.name,'archive_member':name,'original_local_path':original,
                            'bytes':len(data),'sha256':sha(data)})
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None and z.namelist() == sorted(files)
        assert all(z.read(n) == pair[1] for n,pair in files.items())
    data = p.read_bytes()
    assert len(data) <= 8 * 1024 * 1024, str(p)
    bundles.append({'file_name':p.name,'local_path':str(p),'repository_path':PREFIX+'/'+p.name,
                    'bytes':len(data),'sha256':sha(data),'git_blob_sha':blob(data),
                    'members':len(files),'uncompressed_bytes':sum(len(x[1]) for x in files.values())})

manifest = {'schema':'codecortex.primary-third-acceptance-publication.v1',
            'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'parent_commit':'da00e2802bd9304de698b263be9924e2dc96242f',
            'current_source_G':'c8be5afaac568ffd40ef86d3795423c3b73c9f39',
            'original_tasks':{'total':192,'done':163,'remaining':29,'new_completed':0},
            'accepted_scopes':['Original C8 and C4:900 operations each; configured concurrency8/4, observed peaks7/4, reconstructed raw overlap and parity.',
                               'Original CI181/181 and v15 on actual synthetic merge39ae6437; relevant complete product/validation domains and canonical R match Gc8.',
                               'Original recovery fault/stdio/schema25-24-25 behavior and seven platform cells in frozen selection; final eighth cell and collector are independently accepted separately when their final packet is published.',
                               'Historical277f product identity704 paths:613 identical Git blobs and91 fetched differing originals, with independent peer.',
                               'Additional gates original transport and peer records; no additional native gate run.'],
            'limits':['No original TODO status changed; scale and soak remain incomplete.',
                      'C8 initial local capacity failure preceded extraction; transparent RAM intake attempt02 succeeded without rerunning the original GitHub workload.',
                      'All frozen selection bytes and original failed attempt records are retained.',
                      'Actual ZIP/member or direct_repository_path entries below govern public location; original selection repository_path fields for ZIP-contained files describe an expanded layout.',
                      'Large official artifact ZIPs and excluded ELFs/DBs remain at their exact recorded artifact locators.',
                      'Resource observations are stage-scoped; unavailable provider costs stay null.',
                      'CI actual checkout is39ae6437c417236f40110f0d18f29aa1ac3db3de; no whole-repository-tree equality or direct-Gc8-checkout claim.'],
            'selections':selections,'bundles':bundles,'direct_files':direct,'file_count':len(entries),'files':entries}
p = OUT/'publication-manifest.json'
p.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
index = {'prefix':PREFIX,'files_to_upload':bundles+direct,
         'manifest':{'local_path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}}
(OUT/'upload-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(entries),'bundles':bundles,'direct':direct,'manifest_bytes':p.stat().st_size},ensure_ascii=False))
