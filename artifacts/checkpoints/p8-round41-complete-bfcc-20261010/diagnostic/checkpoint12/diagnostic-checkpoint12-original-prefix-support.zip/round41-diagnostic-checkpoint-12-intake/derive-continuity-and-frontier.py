"""Derived bridge only: accepted00-11 small records and newly validated12 metadata.
The frozen reader owns the sole ZIP CRC/member traversal. This helper materializes
its already-validated new metadata using deflate/stored bytes plus recorded SHA,
without a second CRC pass, and never opens an old ZIP or original raw stream.
"""
import datetime,hashlib,json,stat,struct,zipfile,zlib
from pathlib import Path
R=Path('/workspace/scratch/bfccb8494ba0'); O=R/'round41-diagnostic-checkpoint-12-intake/attempt01'; P=R/'round40-diagnostic-checkpoint-11-intake/attempt01'
def sha(b):return hashlib.sha256(b).hexdigest()
def ident(p):
 b=p.read_bytes();return {'local_path':str(p),'bytes':len(b),'sha256':sha(b),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def save(name,d):
 with (O/name).open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
reader=json.loads((O/'reader/report.json').read_text());execution=json.loads((O/'reader.execution.json').read_text());oldpath=P/'checkpoint11-prefix-review.json'
assert ident(oldpath)['sha256']=='1fde9e3169ac5b4e7f3c5d39918fb026d16d35303cbd8f0487a4b71e277c288f'
old=json.loads(oldpath.read_text());oldreader=json.loads((P/'reader/report.json').read_text());oldindex=json.loads((P/'official-index.json').read_text())
assert execution['exit_code']==0 and len(reader['artifacts'])==1
new=reader['artifacts'][0];assert new['id']=='11659516858' and new['official_digest_verified'] and new['crc_and_member_sha_checked']
assert new['bytes']==56668 and new['sha256']=='7d2a97db93e81b47cea57a5fedf74dfe05fc0d88803f176e45f4b5c58f54f8a3'
assert all(not c['retained_locations'] for s in reader['streams'].values() for c in s['chunks'])
selected=O/'selected-originals';selected.mkdir(exist_ok=False)
# New metadata is copied only after original reader accepted all members. SHA is
# checked against that acceptance. No zip.testzip, ZipExtFile or second CRC loop.
with zipfile.ZipFile(new['zip_path']) as central, open(new['zip_path'],'rb') as f:
 assert set(central.namelist())==set(new['members'])
 for entry in central.infolist():
  assert entry.compress_type in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED)
  f.seek(entry.header_offset);header=f.read(30);assert header[:4]==b'PK\x03\x04'
  n,e=struct.unpack_from('<HH',header,26);f.seek(n+e,1);compressed=f.read(entry.compress_size)
  data=compressed if entry.compress_type==zipfile.ZIP_STORED else zlib.decompress(compressed,-15)
  m=new['members'][entry.filename];assert len(data)==m['bytes'] and sha(data)==m['sha256']
  path=selected/entry.filename;assert path.parent==selected;path.write_bytes(data);path.chmod(int(m['zip_posix_mode'],8))
manifest=json.loads((selected/'manifest.json').read_text());assert manifest['index']==12 and manifest['included_chunk_names']==[]
assert (selected/'configuration.json.snapshot').read_bytes()==(P/'selected-originals/configuration.json.snapshot').read_bytes()
accepted_artifacts=old['derived_continuity_bridge']['accepted_prior_artifact_records']+oldreader['artifacts']
accepted_official=old['derived_continuity_bridge']['accepted_prior_official_artifact_rows']+oldindex['artifacts']
ids=[11655358015,11655694522,11656371239,11656517936,11656209993,11656794128,11657318324,11658151472,11658656645,11658523401,11658489665,11659341085]
assert [x['artifact']['id'] for x in accepted_official]==ids
by_id={str(a['id']):a for a in accepted_artifacts};assert len(by_id)==12
chunks={k:dict(v) for k,v in old['derived_continuity_bridge']['accepted_prior_chunk_records'].items()}
for stream in oldreader['streams'].values():
 for c in stream['chunks']:
  if c['name'] in chunks:
   prior=chunks[c['name']];assert {k:v for k,v in prior.items() if k!='retained_locations'}=={k:v for k,v in c.items() if k!='retained_locations'}
   for loc in c['retained_locations']:
    if loc not in prior['retained_locations']:prior['retained_locations'].append(loc)
  else:chunks[c['name']]=dict(c)
small={}
for path in R.glob('round*-diagnostic-checkpoint-*-intake/attempt01/selected-originals/manifest.json'):
 if path==selected/'manifest.json':continue
 d=json.loads(path.read_text())
 if d['index']<=11:
  assert d['index'] not in small;small[d['index']]=(path,d)
assert set(small)==set(range(12))
cp=reader['checkpoints'][0];assert cp['index']==12 and len(cp['acknowledgements'])==12
assert all(a['retained_original_and_official_digest_verified'] is False for a in cp['acknowledgements'])
acks=[]
for a in cp['acknowledgements']:
 p,m=small[a['checkpoint']];orig=by_id[str(a['artifact_id'])];official=next(x['artifact'] for x in accepted_official if str(x['artifact']['id'])==str(a['artifact_id']))
 assert ident(p)['sha256']==orig['members']['manifest.json']['sha256']==a['manifest_sha256']
 assert m['included_chunk_names']==a['included_chunk_names']
 assert orig['sha256']==official['digest'].removeprefix('sha256:')==a['artifact_digest']
 assert orig['official_digest_verified'] is True
 acks.append({'ack':a,'small_manifest':ident(p),'prior_original_ZIP_artifact_id':official['id'],'prior_official_ZIP_sha256':orig['sha256'],'derived_bridge_verified':True,'prior_ZIP_reopened':False})
prefixes={}
for name,s in reader['streams'].items():
 pos=0
 for c in s['chunks']:
  assert c['start']==pos and c['name'] in chunks
  prior=chunks[c['name']];assert prior['retained_locations']
  assert {k:v for k,v in c.items() if k!='retained_locations'}=={k:v for k,v in prior.items() if k!='retained_locations'}
  pos=c['end']
 assert pos==s['highest_declared_offset']==old['verified_prefixes'][name]['end_exclusive']
 prefixes[name]={'start':0,'end_exclusive':pos,'highest_declared_offset':s['highest_declared_offset'],'unknown_tail_bytes':None,'EOF_claimed':False,'verification_scope':'derived accepted00-11 records/small manifests plus new-only12 reader; no old ZIP reread'}
assert prefixes['shard/native/raw.jsonl']['end_exclusive']==16145239
bridge={'scope':'Derived evidence reuse; frozen reader12 output remains unchanged and its old-ACK false/prefix0 fields are not overwritten.','prior_reader_report':ident(P/'reader/report.json'),'prior_index':ident(P/'official-index.json'),'prior_accepted_report':ident(oldpath),'accepted_prior_artifact_records':accepted_artifacts,'accepted_prior_official_artifact_rows':accepted_official,'accepted_prior_chunk_records':chunks,'ACKs':acks,'old_ZIPs_opened':0,'old_ZIPs_CRC_rechecked':0,'all_declared_old_chunks_equal_prior_accepted_records':True,'new_chunk_start_matches_prior_end':None,'new_chunks':0,'all_stream_end_offsets_unchanged':True}
report={'schema':'p8-original-diagnostic-checkpoint12-prefix-review-v1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':old['source'],'run_id':38012409915,'attempt':1,'scope':'New12 sole frozen-reader reception; independently derived00-11 continuity includes every accepted checkpoint. Metadata-only checkpoint; no new emitted stream bytes, no EOF or current hidden-phase conclusion.','new_original_artifact':new,'old_continuity_artifact_ids':ids,'previous_accepted_review':ident(oldpath),'frozen_reader_execution':ident(O/'reader.execution.json'),'reader_exit_code':0,'frozen_reader_new_only_stream_result':reader['streams'],'verified_prefixes':prefixes,'derived_continuity_bridge':bridge,'accepted_diagnostic_build_reused_without_revalidation':old['accepted_diagnostic_build_reused_without_revalidation'],'new_raw_interval':{'scope':'derived empty interval, not an original chunk','source':'shard/native/raw.jsonl','start':16145239,'end':16145239,'bytes':0,'ends_in_newline':None,'new_complete_event_counts':{},'cumulative_complete_event_counts':old['new_raw_interval']['cumulative_complete_event_counts'],'complete_line_parse_errors':[],'partial_tail_bytes':old['new_raw_interval']['partial_tail_bytes'],'inherited_partial_tail_not_newly_read':True},'new_original_non_build_records':[],'new_finished_build_records':[],'started_but_not_finished_in_retained_prefix':old['started_but_not_finished_in_retained_prefix'],'visible_frontier':{'new_complete_original_record':None,'last_retained_complete_original_record_from11':old['visible_frontier']['last_complete_original_record'],'previous_original_pointer_report':ident(oldpath),'current_hidden_execution_phase':'unknown: checkpoint12 emits no new stream bytes, not proof of a stalled native process or current parity execution'},'cold_parity_events':old['cold_parity_events'],'stage_finished_events':old['stage_finished_events'],'frozen_reader_checkpoint12_ACKs_unverified_within_new_only_input':cp['acknowledgements'],'own_ACK_boundary':'12 snapshot precedes its own upload; no later local12 ACK supplied. Official12 ZIP custody is independently verified.','capture_faults_observed':reader['capture_faults'],'metadata_parse_unknown':reader['metadata_parse_unknown'],'observer_before_seen_and_bound':reader['observer_before_seen'],'observer_after_seen':reader['observer_after_seen'],'supervisor_terminal_seen':bool(reader['supervisor_receipts']),'native_report_seen':bool(reader['native_reports']),'reported_native_outcome':reader['reported_native_outcome'],'custody_status':reader['custody_status'],'local_metadata_materialization':'After frozen-reader sole all-member CRC pass, the eight already-verified new metadata members were decompressed and copied with SHA/size checked against its report, without a second CRC pass. No old ZIP or raw stream was opened.','source_input_typo_preserved':'official-index.time_boundary inherited the words New08; its artifact array/index9/id11658523401 and all validated source/digest fields are correct. Original file remains unchanged; this report records the explanatory text typo.','original_function_calls':{'validate_build':0,'validate_shard':0,'inspect_raw':0,'check_parity':0,'ELF':0},'full_cohort_run_not_mixed':38013753078,'full_cohort_failure':'Separate Root-observed100k and aggregate failure at03:54:45 with no100k measurementZIP; not diagnosed or supplemented by this independent prefix.','original_semantic_validation':'not_run; emitted records do not replace original complete-evidence predicates','next_fault_localization':{'evidence':'08 last emitted api/full_control build_finished;09 no byte growth. Source p8_scale.rs973-1001 has complete/full_complete evaluation, parity and config_fact before stage_finished. There is no emitted per-parity heartbeat here.','minimum_next_step':'Use the next already-authorized original diagnostic checkpoint/final receipt if it appears to establish the first new emitted event, actual native status/signal and newly preserved stderr. If stage_finished appears, its original parity_wall_us narrows the interval. Do not launch/restart a workload or read running logs to fill a fabricated state.','unknown':'No new09 terminal/status/RSS/I/O evidence; cannot distinguish ongoing parity/config-fact work, other uninstrumented time, native exit not captured or hidden tail. Cannot attribute separate full-cohort failure, OS/OOM/disk or timeout from this prefix.','future_code_change':None},'accepted_cohort_shards':0,'accepted_samples':0,'TODO_credit':0}
report.pop('source_input_typo_preserved', None)
report['official_observation_interval_utc'] = {'start':'2026-10-10 05:00:20 UTC','end':'2026-10-10 05:00:42 UTC'}
report['next_fault_localization'] = {'evidence':'Prior11 last emitted config/full_control build_finished; new12 has no stream byte growth.', 'minimum_next_step':'Use a later original checkpoint or terminal receipt only if it actually appears; emitted parity/stage/exit records would refine the boundary.', 'unknown':'No new native terminal, RSS, I/O, stderr or stage record. No inference of stalled process, hidden current phase, specific failure cause or completion.', 'future_code_change':None}
save('checkpoint12-prefix-review.json',report)
save('incremental-facts-summary.json',{k:report[k] for k in ['schema','source','run_id','attempt','new_raw_interval','visible_frontier','capture_faults_observed','reported_native_outcome','next_fault_localization','accepted_samples','TODO_credit']})
print(json.dumps({'report':ident(O/'checkpoint12-prefix-review.json'),'new_events':{},'new_raw_bytes':0,'derived_contiguous_raw_bytes':16145239,'derived_ACKs_verified':len(acks),'native_outcome':reader['reported_native_outcome']}))
