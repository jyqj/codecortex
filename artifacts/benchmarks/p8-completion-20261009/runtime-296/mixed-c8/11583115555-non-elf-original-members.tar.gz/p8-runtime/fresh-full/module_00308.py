def stable_00308():
    return 308
