#!/usr/bin/env python3
"""Offline reception only: original G2 ZIP, no product/Cargo execution."""
from pathlib import Path, PurePosixPath
import ast
from collections import Counter
import hashlib
import json
import math
import stat
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
REPO = '/workspace/scratch/2eaa00d0f93a/codecortex'
G2 = 'd2d492b329a5630bf4a5fa6bc4b6eac30d07b13c'
ZIP_SHA = 'cfb1a236ec0b0652dd978642135f3b46cec9a33419faf6f5ea2934b39e7b9e56'
def sha(b): return hashlib.sha256(b).hexdigest()
def require(ok, message):
    if not ok: raise AssertionError(message)

def main():
    archive = HERE/'artifact-11581055784.zip'
    require(archive.stat().st_size == 21033272 and sha(archive.read_bytes()) == ZIP_SHA, 'GitHub ZIP digest')
    inventory = {}
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            require(not info.is_dir(), 'unexpected directory entry')
            path = PurePosixPath(info.filename)
            require(not path.is_absolute() and '..' not in path.parts and info.filename not in inventory, 'unsafe duplicate member')
            mode = info.external_attr >> 16
            require(stat.S_IFMT(mode) in (0, stat.S_IFREG), 'nonregular ZIP member')
            h = hashlib.sha256(); size = 0
            with z.open(info) as f:
                while block := f.read(1024*1024): h.update(block); size += len(block)
            require(size == info.file_size, 'ZIP byte count')
            inventory[info.filename] = {'bytes':size,'sha256':h.hexdigest(),'crc32':format(info.CRC,'08x')}
        require(len(inventory) == 2125, 'member population')
        def read(name): return json.loads(z.read(name))
        for prefix, count in [('p8-build/',15),('p8-runtime/',2108)]:
            seal = read(prefix+'seal.json')['artifact_inventory']
            actual = {n[len(prefix):]:{k:v for k,v in r.items() if k!='crc32'} for n,r in inventory.items()
                      if n.startswith(prefix) and n != prefix+'seal.json'}
            require(seal == actual and len(seal)==count, 'complete seal '+prefix)
        plan, report = read('p8-runtime/plan.json'),read('p8-runtime/report.json')
        build = read('p8-build/build-receipt.json')
        source = read('p8-build/source-before.json')
        require(source == read('p8-build/source-after.json') == build['source_before'] == build['source_after'], 'source equality')
        require(source['source_commit']==G2 and source['input_count']==len(source['inputs'])==1087, 'G2 source scope')
        # Batch read the immutable Git blobs, then recompute every source SHA.
        batch = subprocess.Popen(['git','-C',REPO,'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
        for path, digest in source['inputs'].items():
            batch.stdin.write((G2+':'+path+'\n').encode()); batch.stdin.flush()
            head = batch.stdout.readline().decode().split(); require(len(head)==3 and head[1]=='blob','missing fixed source')
            body = batch.stdout.read(int(head[2])); require(batch.stdout.read(1)==b'\n','Git framing')
            require(sha(body)==digest,'fixed Git source differs '+path)
        batch.stdin.close(); require(batch.wait()==0,'Git reader exit')
        require(build['observer_before']==build['observer_after'], 'observer before/after')
        observer = build['observer_before']; require(observer['source_commit']==G2,'observer commit')
        for path, identity in observer['files'].items():
            b=z.read('p8-build/observer-source/'+path)
            committed=subprocess.check_output(['git','-C',REPO,'show',G2+':'+path])
            require(b==committed and len(b)==identity['bytes'] and sha(b)==identity['sha256'], 'observer body')
        require(len(observer['files'])==7,'observer count')
        require(z.read('p8-build/build-receipt.json') == z.read('p8-runtime/build-evidence/build-receipt.json'),'retained build copy')
        require(plan['build_identity']==report['final_build_verification'],'final build identity recheck')
        require(plan['build_identity']['receipt_sha256']==sha(z.read('p8-build/build-receipt.json')),'build receipt binding')
        cargo=[json.loads(line) for line in z.read('p8-build/product-build.jsonl').splitlines() if line]
        require(cargo[-1]=={'reason':'build-finished','success':True} and build['build_exit_code']==0,'Cargo completion')
        for name, identity in build['artifacts'].items():
            a=identity['cargo_artifact']; matches=[m for m in cargo if m.get('reason')=='compiler-artifact' and m.get('target',{}).get('name')==name]
            require(matches==[a] and a['profile']['opt_level']=='3' and not a['profile']['test'] and not a['profile']['debug_assertions'],'Cargo selected release')
            b=z.read('p8-build/'+name); require(len(b)==identity['binary_bytes']==identity['copy_source']['bytes'] and sha(b)==identity['binary_sha256']==identity['copy_source']['sha256'],'binary copy chain')
            require(a['executable']==identity['copy_source']['path'] and a['manifest_path'].startswith('/home/runner/work/codecortex/codecortex/crates/') and a['target']['src_path'].startswith('/home/runner/work/codecortex/codecortex/crates/'),'producer paths')
        require(plan['profile']=='soak' and plan['operations']==3601 and plan['offer_interval_ms']==1000 and plan['offer_schedule']=='uniform' and plan['files']==1000 and plan['concurrency']==4,'original soak plan')
        require(report['status']=='passed_observation' and report['exit_code']==0 and report['failures']==[] and report['artifact_seal_status']=='sealed','successful terminal report')
        require(report['task_complete'] is False and report['release_approval'] is False,'scope guard')
        for file,key in [('plan.json','plan_sha256'),('raw.jsonl','raw_sha256'),('parity.json','parity_sha256')]:
            require(inventory['p8-runtime/'+file]['sha256']==report[key], 'report raw binding')
        records=[json.loads(line) for line in z.read('p8-runtime/raw.jsonl').splitlines() if line]
        rows=[r for r in records if r['kind']=='operation']; samples=[r for r in records if r['kind']=='resources']
        require(len(rows)==3601 and sorted(r['id'] for r in rows)==list(range(3601)), 'complete operation IDs')
        require(Counter(r['state'] for r in rows)=={'success':3601},'terminal states')
        operations=Counter(r['operation'] for r in rows);require(operations=={'read':2400,'build':1201},'operation denominator')
        builds=[r for r in rows if r['operation']=='build']; require(sorted(r['mutation_ordinal'] for r in builds)==list(range(1201)), 'mutation admission order')
        for r in rows:
            require(r['finished_ns']>=r['call_started_ns']>=r['offered_ns'],'nonnegative observation clocks')
            if r['operation']=='read':require(any(h.get('name')=='p8_runtime_stable_signal' and h.get('file_path')=='stable.py' for h in r['response']),'actual stable public hit')
        # Execute only fixed, pure summary functions; no observer run/main or product.
        text=z.read('p8-build/observer-source/scripts/p8_runtime.py').decode();tree=ast.parse(text)
        names={'median','rss_trend','sample_coverage','latency_summary'}
        pure=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[])
        ns={'math':math,'require':require};exec(compile(pure,'fixed_G2_pure_summaries','exec'),ns)
        require(ns['latency_summary'](rows)==report['latency'],'all raw quantiles')
        for op in operations:require(ns['latency_summary']([r for r in rows if r['operation']==op])==report['latency_by_operation'][op], 'operation quantiles')
        require(ns['rss_trend'](samples)==report['rss'] and report['rss']['passed'],'native RSS replay')
        cov=report['resource_time_coverage'];require(ns['sample_coverage'](samples,cov['work_start_ns'],cov['work_end_ns'])==cov and cov['passed'],'temporal resource coverage')
        require(cov['work_end_ns']-cov['work_start_ns']==report['observed_work_ns']>=3600*10**9,'whole hour work')
        switches=sum(r.get('mutation',{}).get('action')=='real_git_branch_switch' for r in rows)
        compactions=z.read('p8-runtime/product/product-stderr.log').decode().count('resolver catalog dropped for tombstone compaction')
        require(switches==report['real_branch_switches']==200 and compactions==report['observed_catalog_compactions']==25,'real branch/compaction receipts')
        parity=read('p8-runtime/parity.json');comparison=parity['comparison']
        require(parity['exit_code']==report['parity_exit_code']==0 and parity['error'] is None and comparison['equal'] and comparison['different_tables']==[],'parity original receipt')
        require(len(comparison['tables'])==len({r['table'] for r in comparison['tables']})==15,'full15table oracle')
        require(all(r['equal'] and r['different_row_count']==0 and r['full_rows']==r['incremental_rows'] and r['full_digest']==r['incremental_digest'] for r in comparison['tables']),'parity all tables')
        statistics=read('p8-runtime/statistics.json');require(z.read('p8-runtime/statistics.json')==z.read('p8-runtime/statistics-replay.json'),'two retained Rust statistics bytes')
        require(statistics['recorded_samples']==statistics['expected_samples']==3601 and statistics['missing_samples']==statistics['unexpected_samples']==0,'Rust denominator')
        require({x['operation']:x['recorded_samples'] for x in statistics['by_operation']}==dict(operations),'Rust operation count')
        require(statistics['raw_sha256']==report['raw_sha256'] and statistics['plan_sha256']==report['plan_sha256'],'Rust input hashes')
        # Stream all original transport JSON, ensuring both owned sessions close cleanly.
        transport={}
        for prefix in ['product','comparison-product']:
            name='p8-runtime/'+prefix+'/rpc.jsonl'
            if name not in inventory:continue
            kinds=Counter();req={};res={};eof=exit0=False
            with z.open(name) as f:
                for line in f:
                    event=json.loads(line);kind=event.get('direction',event.get('kind'));kinds[kind]+=1
                    if kind=='process_exit':exit0=event.get('exit_code',event.get('code'))==0
                    if kind in ['stdout_eof','eof']:eof=True
            transport[prefix]={'kinds':dict(kinds),'process_exit_0_observed':exit0,'stdout_eof_observed':eof}
        endpoint=next(r['response'] for r in records if r['kind']=='endpoint_status')
        result={'decision':'accepted_scoped_original_G2_soak_observation','source_commit':G2,'run_id':37837227959,'job_id':113517255442,'artifact_id':11581055784,'artifact_sha256':ZIP_SHA,'artifact_bytes':21033272,'all_member_count':len(inventory),'all_member_bytes':sum(x['bytes'] for x in inventory.values()),'all_member_CRC_SHA_verified':True,'run_seal_files':2108,'build_seal_files':15,'source_inputs_exact_Git':1087,'observer_files_exact_Git':7,'operations':dict(operations),'outcomes':{'success':3601},'observed_work_ns':report['observed_work_ns'],'rss':report['rss'],'resource_coverage':cov,'branch_switches':switches,'catalog_compactions':compactions,'configured_C':4,'observed_workload_peak':report['actual_concurrency']['maximum'],'parity_tables':15,'original_parity_exit_code':0,'original_two_Rust_statistics_artifacts_identical':True,'endpoint_search_cache':endpoint['search_cache'],'transport':transport,'limitations':['All verification here is offline; no product/native/Rust invocation or new measurement. Full parity is accepted as original bound oracle evidence, not rerun against database files.','G2 original read workload is symbol-only; result cache hit/miss counters remain zero. This is not G3 hybrid-cache/worker-reuse evidence and not a completed P8-010.','Configured C4 has observed workload maximum1 and no read/build overlap in this uniformly offered soak. No claim of actual C4 peak, provider/semantic workers, entire-process-tree peak or new performance SLA.','Original IID quantile intervals are retained with serial-correlation limitations; this review recomputed primary raw empirical quantiles, denominator, RSS and time coverage, not interval math by a new engine.'],'TODO_closed':0,'TODO_remaining':29}
        (HERE/'member-hashes.json').write_text(json.dumps(inventory,sort_keys=True,indent=2)+'\n')
        (HERE/'inspection.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
        print(json.dumps({'accepted':True,'inspection_sha256':sha((HERE/'inspection.json').read_bytes()),'operations':dict(operations),'transport':transport}))

if __name__=='__main__':main()
