#!/usr/bin/env python3
"""Preserve selected originals without network, product execution or Git mutation."""
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / 'frozen-input-config.json'
config = json.loads(CONFIG.read_bytes())
OUT = ROOT / 'sealed-attempt01'
OUT.mkdir(exist_ok=False)
PREFIX = 'artifacts/checkpoints/p8-round20-terminal-evidence-bfcc-20261009'
PARENT = '8d585ac602f2e8d045afcb6b423e25802517a14a'
PARENT_TREE = '032a37ed5c4ce0f390d4e24b622fc9c030418540'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def oid(b):
    return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()

def js(v):
    return (json.dumps(v,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode()

def record(p):
    b=p.read_bytes()
    return {'local_path':str(p),'bytes':len(b),'sha256':sha(b),'git_blob':oid(b),'mode':'100644'}

payload={}
sources=[]
members=[]

def add(member,b,mode=0o644):
    p=PurePosixPath(member)
    assert not p.is_absolute() and '..' not in p.parts and '\x00' not in member and '\\' not in member
    assert member not in payload and not member.lower().endswith('.zip')
    payload[member]=(b,mode)
    members.append({'path':member,'bytes':len(b),'sha256':sha(b),'git_blob':oid(b),'posix_mode':format(mode,'04o')})

def add_file(p,member,expected=None,origin=None):
    assert p.is_file() and not p.is_symlink()
    b=p.read_bytes();mode=stat.S_IMODE(p.stat().st_mode)
    if expected:
        assert len(b)==expected['bytes'] and sha(b)==expected['sha256'],str(p)
        if expected.get('git_blob'):assert oid(b)==expected['git_blob']
        declared=expected.get('posix_mode',expected.get('mode'))
        if declared and len(str(declared))<=4:assert mode==int(str(declared),8)
    add(member,b,mode)
    sources.append({'member':member,**record(p),'posix_mode':format(mode,'04o'),'origin':origin})

assert config['missing_required_items']==[]
for group in config['selection_groups']:
    p=Path(group['path']);b=p.read_bytes()
    assert len(b)==group['bytes'] and sha(b)==group['sha256']
    selection=json.loads(b);rows=selection['files']
    assert len(rows)==group['file_count'] and sum(x['bytes']for x in rows)==group['selected_bytes']
    add_file(p,'selections/'+group['name']+'.json',origin=group['name'])
    for row in rows:
        p=Path(row.get('local_path',row.get('source_path')))
        relative=row.get('archive_path',row.get('relative_path',row.get('repository_path')))
        assert relative
        add_file(p,'evidence/'+group['name']+'/'+relative,row,group['name'])
for row in config['root_receipts']:
    p=Path(row['local_path'])
    add_file(p,'evidence/root-round20/'+p.name,row,'root-original-receipts')

intake_index_path=Path('/dev/shm/pr-triage-round20-CI-C3ff-M7F/upload-index.json')
intake_index=json.loads(intake_index_path.read_bytes())
add_file(intake_index_path,'references/original-intake-upload-index.json',origin='original-intake-locators')
originals=[x for x in intake_index['files']if x.get('complete_original')]
assert len(originals)==2
assert {x['git_blob']for x in originals}=={'ac44c156dd7932cf9b42aa03c35392dc89283581','860c80771c980babfa31b9b09f2b2543868f9064'}
original_checks=[]
for row in originals:
    p=Path(row['local_path']);b=p.read_bytes()
    assert len(b)==row['bytes'] and sha(b)==row['sha256'] and oid(b)==row['git_blob']
    with zipfile.ZipFile(p)as z:
        assert z.testzip()is None
        count=len(z.infolist())
    original_checks.append({**row,'actual_ZIP_member_count':count,'actual_CRC_check':'passed','source_before':record(p)})

r6_manifest_path=Path('/dev/shm/todo-audit-P6B-crash-ready-source-review/final-R6B/upload-manifest.json')
r6_manifest=json.loads(r6_manifest_path.read_bytes())
assert r6_manifest['source_P']=='5534ebf38cc31efec1590d132ca57c30e2f77f1b' and len(r6_manifest['files'])==2
add_file(r6_manifest_path,'references/R6B-original-upload-manifest.json',origin='already-created-R6B-locators')
locators={'schema':'round20-immutable-evidence-locators-v1','separate_original_ZIP_leaves':original_checks,
          'not_nested':[{'commit':PARENT,'purpose':'Already-published round19 selected checkpoint; preserved by parent ancestry, not repackaged.'},
                        {'commit':'22975e49107b3832f438f85b17275110fc0afa02','purpose':'Already-created source-only R6B canonical and support; original Git blobs reused through immutable locators.',
                         'files':r6_manifest['files']}],
          'intake_preexisting_support_ZIP_not_nested':next(x for x in intake_index['files']if not x.get('complete_original'))}

ci=json.loads(Path('/dev/shm/root-round20/G4-main-CI-terminal/root-terminal-execution-review.json').read_bytes())
ci_execution=json.loads(Path('/dev/shm/root-round20/G4-main-CI-terminal-review-execution.json').read_bytes())
assert ci['run']['conclusion']=='success' and ci['run']['head']=='cc177ddc9e6b8180b8d847539787672e7b689a1a'
assert ci['actual_checkout']['whole_tree_equal_to_G4'] and ci_execution['exit_code']==0
assert ci['DB_test_target']['passed']==9 and ci['source_suite']['passed']==181 and ci['original_v15']['status']=='passed'
phase=json.loads(Path('/dev/shm/execution-recon-recovery-20261009/round20-C3ff-phase-analysis/analysis-output/fixed-C3ff-failed-100k-phase-analysis.json').read_bytes())
assert phase['completion']['completed_full_builds']==8 and phase['completion']['completed_incremental_builds']==994
assert phase['completion']['completed_parities']==6 and phase['completion']['started_but_not_closed_mutation_stage']=='batch_10'

summary={'schema':'round20-active-terminal-and-engineering-checkpoint-v1','sealed_at_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'round20_status':'active','TODO':{'total':192,'done':163,'new_this_round':0,'new_cumulative':0,'remaining':29},
         'checkpoint_parent':{'commit':PARENT,'tree':PARENT_TREE},
         'fixed_C3ff_scale':{'source':'3ffcefc3b28ee1a4ed80caecebd7208a45c3e302','run':37910924354,'attempt':1,
                            'status':'failure','native_status':'deadline_exceeded','native_exit_code':3,'worker_exit_code':None,'stderr_complete':False,
                            'original_shard_validator':'rejected; original child exit1 retained','original_raw_coverage_validator':'rejected missing registered mutation stages; original child exit1 retained',
                            'intake_integrity_child_exit':0,'new_accepted_primary_samples':0,
                            'completed_full_builds':8,'completed_incremental_builds':994,'completed_equal_parities':6,
                            'incomplete_stage':'batch_10','unstarted_stages':['batch_100','batch_1000'],
                            'full_control_for_batch_10_finished':True,'unrecorded_terminal_inner_operation':'unknown',
                            'two_complete_original_ZIPs_separate_leaves':True,'original_failure_not_replaced_or_pooled':True},
         'G4_engineering_CI':{'run':ci['run'],'actual_checkout':ci['actual_checkout'],'main_jobs':ci['main_jobs'],
                              'DB_test_target':ci['DB_test_target'],'source_suite':ci['source_suite'],'original_v15':ci['original_v15'],
                              'all_other_checks_only_as_snapshot':ci['all_checks_snapshot'],
                              'scope':'Original main engineering CI success only; no universal speedup, complete scale acceptance or TODO closure.',
                              'local_summary_parser_first_failure_preserved':True,'corrected_summary_helper_actual_exit':0},
         'PR188_state_at_selected_snapshot':{'ready_for_review':True,'merged':False,'head':'cc177ddc9e6b8180b8d847539787672e7b689a1a',
                                             'base':'0e6b07c75183da79c5a6679d4c2b66c65f7db663','head_base_unchanged':True,
                                             'performance_adoption':'held pending scoped review of specific counterexample report80d7979da10ae242ed4706cd04be74c62194261a',
                                             'counterexample_not_relabelled_as_G4_binary':True},
         'P6B_R6B':{'P':'5534ebf38cc31efec1590d132ca57c30e2f77f1b','R':'22975e49107b3832f438f85b17275110fc0afa02',
                     'source_only':True,'new_execution':'not_run','G6B':'generation pending at selected snapshot; no object or execution inferred'},
         'late_addendum_policy':'A later G6B result may be an independent artifact leaf; this sealed snapshot will not be rewritten.',
         'selection_groups':config['selection_groups'],'root_receipt_count':len(config['root_receipts']),'missing_required_items':[],
         'package_actions':'Local read-only source custody and ZIP sealing only. No network, product test, validator rerun, workflow operation, source change or Git mutation.'}

custody={'schema':'selected-original-custody-v1','files':list(sources),'source_file_count':len(sources),'bytes_hash_Gitblob_mode_verified':True}
for name,value in [('checkpoint-summary.json',summary),('immutable-evidence-locators.json',locators),('selected-original-manifest.json',custody)]:
    b=js(value);(OUT/name).write_bytes(b);add(name,b)
add_file(CONFIG,'packaging/frozen-input-config.json',origin='frozen-packaging-config')
add_file(Path(__file__),'packaging/seal-selected-evidence.py',origin='actual-packaging-script')

archive=OUT/'round20-selected-terminal-and-engineering-support.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
    for name in sorted(payload):
        b,mode=payload[name];i=zipfile.ZipInfo(name,date_time=(2026,10,9,0,0,0));i.create_system=3;i.external_attr=(stat.S_IFREG|mode)<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,b)
with zipfile.ZipFile(archive)as z:
    assert z.testzip()is None and sorted(z.namelist())==sorted(payload)
    for i in z.infolist():
        b,mode=payload[i.filename];assert z.read(i)==b and stat.S_IMODE(i.external_attr>>16)==mode
for row in sources:
    p=Path(row['local_path']);actual=record(p)
    assert all(actual[k]==row[k] for k in ['bytes','sha256','git_blob'])
    assert format(stat.S_IMODE(p.stat().st_mode),'04o')==row['posix_mode']
for row in original_checks:
    assert record(Path(row['local_path']))==row['source_before']

member_manifest={'schema':'round20-support-ZIP-member-manifest-v1','ZIP':record(archive),'member_count':len(members),'files':sorted(members,key=lambda x:x['path']),
                 'uncompressed_bytes':sum(x['bytes']for x in members),'all_members_CRC_bytes_SHA_Gitblob_mode_verified':True,
                 'all_sources_and_separate_original_ZIPs_before_after_equal':True,'nested_ZIPs':0}
(OUT/'support-member-manifest.json').write_bytes(js(member_manifest))
result={'schema':'actual-round20-packaging-result-v1','status':'sealed_verified','ZIP':record(archive),'members':len(members),'nested_ZIPs':0,
        'selected_groups':len(config['selection_groups']),'selected_files':sum(x['file_count']for x in config['selection_groups']),
        'root_receipts':len(config['root_receipts']),'separate_original_ZIPs':2,'original_ZIP_existing_Git_blobs_reused':True,
        'source_before_after_equal':True,'remote_uploaded':False,'TODO_new_completed':0,'TODO_remaining':29,'round20_status':'active'}
(OUT/'packaging-result.json').write_bytes(js(result))
upload={'schema':'round20-root-upload-manifest-v1','suggested_parent':PARENT,'suggested_parent_tree':PARENT_TREE,'artifact_only':True,'remote_uploaded':False,'files':[]}
for row in originals:
    copy={**row,'repository_path':PREFIX+'/'+row['repository_path'],'mode':'100644','reuse_existing_git_blob':True}
    upload['files'].append(copy)
for name in ['round20-selected-terminal-and-engineering-support.zip','support-member-manifest.json','checkpoint-summary.json','immutable-evidence-locators.json','selected-original-manifest.json','packaging-result.json']:
    row=record(OUT/name);row['repository_path']=PREFIX+'/'+name;upload['files'].append(row)
(OUT/'upload-manifest.pending-command-receipt.json').write_bytes(js(upload))
print(json.dumps(result,sort_keys=True))
