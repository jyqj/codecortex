#!/usr/bin/env python3
"""Bind the exact published execution and invoke the original v15 CLI once."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

BASE=Path(__file__).parent
VIEW=Path('/dev/shm/a217aaae3bde/codecortex-combined-guard-view')
OUT=BASE/'guard-execution-a23bb72'
META=Path('/workspace/scratch/a217aaae3bde/combined-scale-cache-candidate')
ROOT=Path('/dev/shm/a217aaae3bde/codecortex')
PRODUCT='254009277688d64677361a0ca33e5dea73f295ef'
REVIEW='3a11f30f9f00a89fe3cd481b3b7609066728baad'
EXECUTION='a23bb72d3c954f385b99fe81ce9189885c208557'
assert not OUT.exists()
OUT.mkdir()
# Reuse only the independently retained pure Git-object helper definitions.
helper_path=BASE/'prepare_combined_guard_view.py'
helper_tree=ast.parse(helper_path.read_bytes())
helper_nodes=[n for n in helper_tree.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef))]
ns={};exec(compile(ast.Module(body=helper_nodes,type_ignores=[]),str(helper_path),'exec'),ns)
ns.update(VIEW=VIEW,OUT=OUT,META=META,ROOT=ROOT)
git,oid,store,overlay_tree,commit_obj,save,entries=[ns[n] for n in ['git','oid','store','overlay_tree','commit_obj','save','entries']]
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_bytes())
assert git('rev-parse','HEAD').decode().strip()==PRODUCT
initial_root_head=git('rev-parse','HEAD',cwd=ROOT).decode().strip()
root_index=Path(git('rev-parse','--path-format=absolute','--git-path','index',cwd=ROOT).decode().strip())
initial_root_index=sha(root_index.read_bytes())
pins=load(META/'execution-pins-prepared.json')
old=(VIEW/'scripts/verify_reviewed_source_v15.py').read_text()
new=(META/'execution-overlay/scripts/verify_reviewed_source_v15.py').read_text()
transformed=old
for key,value in pins['only_changed_guard_constants'].items():
    transformed,n=re.subn(r'^'+key+r' = ".*"$',key+' = '+json.dumps(value),transformed,flags=re.M)
    assert n==1
assert transformed==new and set(pins['only_changed_guard_constants'])=={'PRODUCT','REVIEW','REVIEW_PATH','REGISTRY_SHA256'}
registry=load(META/'execution-overlay/scripts/reviewed-source-registry-v15.json')
independent=load(BASE/'independent-git-inputs.json')
assert registry['complete_inputs']==independent['complete_inputs'] and registry['validation_inputs']==independent['validation_inputs']
assert registry['product_source']==PRODUCT and registry['review_source']==REVIEW
extra_pin=Path('/dev/shm/a217aaae3bde/platform-review/combined-254009-review/pins/final-four-pin-independent-review.json')
execution_info=load(META/'execution-commit-created.json')
changes={};origins={}
for e in execution_info['entries']:
    path=e['path'];origin=META/'execution-overlay'/path
    if not origin.is_file():
        assert path.endswith('/final-four-pin-independent-review.json');origin=extra_pin
    raw=origin.read_bytes();store('blob',raw,e['sha'])
    changes[path]=dict(mode=e['mode'],type=e['type'],sha=e['sha']);origins[path]=origin
assert len(changes)==3
execution_tree=overlay_tree(git('rev-parse',REVIEW+'^{tree}').decode().strip(),changes)
meta=load(META/'official-execution-commit.json')
assert meta['sha']==EXECUTION and meta['tree']['sha']==execution_tree==execution_info['execution_tree']
assert [p['sha'] for p in meta['parents']]==[REVIEW]
assert execution_tree==load(META/'official-execution-root-tree.json')['sha']
commit_proof=commit_obj(meta)
records=load(BASE/'guard-view-preparation/materialized-files-product.json')
for p,e in changes.items():
    raw=origins[p].read_bytes();target=VIEW/p;target.parent.mkdir(parents=True,exist_ok=True)
    temporary=target.with_name(target.name+'.owned-new')
    assert not temporary.exists();temporary.write_bytes(raw);temporary.chmod(0o444)
    os.replace(temporary,target)  # Never open an existing shared inode for writing.
    records[p]=dict(mode=e['mode'],git_blob=e['sha'],bytes=len(raw),sha256=sha(raw),origin=str(origins[p]),materialization='independent readonly copy; atomic replace')
(VIEW/'.git/HEAD').write_text(EXECUTION+'\n')
git('update-index','--index-info',data=''.join(f'{e["mode"]} {e["sha"]}\t{p}\n' for p,e in sorted(changes.items())).encode())
assert git('remote')==b''
save('execution-binding.json',dict(execution=EXECUTION,tree=execution_tree,parent=REVIEW,product=PRODUCT,commit_reconstruction=commit_proof,exact_changed_files={p:records[p] for p in changes},guard_only_four_constant_replacements=True,registry_complete_inputs_match_independent_git=True,complete_checkout_claim=False))
sys.dont_write_bytecode=True;sys.path.insert(0,str(VIEW/'scripts'))
import p7_build_identity,p8_runtime_build
source=p7_build_identity.source_snapshot(VIEW);observer=p8_runtime_build.observer_snapshot(VIEW)
assert source['source_commit']==EXECUTION and source['inputs']==independent['complete_inputs'] and source['input_count']==1087
assert observer['source_commit']==EXECUTION and set(observer['files'])==set(independent['runtime_observers'])
assert all(observer['files'][p]==independent['runtime_observers'][p] for p in observer['files'])
save('source-before.json',source);save('observer-before.json',observer)

def current_snapshot():
    result={}
    for p,e in sorted(records.items()):
        target=VIEW/p;assert target.is_file() and not target.is_symlink()
        raw=target.read_bytes();assert sha(raw)==e['sha256'] and oid('blob',raw)==e['git_blob']
        result[p]={'bytes':len(raw),'sha256':sha(raw),'git_blob':e['git_blob'],'executable':bool(target.stat().st_mode & 0o111)}
        assert result[p]['executable']==(e['mode']=='100755')
    return result
before=current_snapshot();save('current-files-before.json',before)
# All commit pins in the approval scripts/registries must be local before CLI.
pin_values=set()
for p in VIEW.glob('scripts/*'):
    if p.is_file() and (p.name.startswith(('verify_','current-source-registry','reviewed-source-','v14_historical','v15_historical'))):
        pin_values.update(re.findall(r'(?<![0-9a-f])[0-9a-f]{40}(?![0-9a-f])',p.read_text()))
pin_values.update([PRODUCT,REVIEW,EXECUTION])
rows=git('cat-file','--batch-check',data=('\n'.join(sorted(pin_values))+'\n').encode()).decode().splitlines()
missing=[r for r in rows if r.endswith(' missing')]
save('literal-object-availability.json',dict(requested=len(pin_values),objects=rows,missing=missing,scope='Literal40hex Git objects in original approval modules/registries; actual Git trace separately preserves every executed read.'))
assert not missing,missing
# Original v15->v14 nested historical contexts use 340,050,055 bytes total.
temp_root=Path('/workspace/scratch/a217aaae3bde/combined-original-guard-temp')
assert not temp_root.exists();temp_root.mkdir()
required=170619506+169430549+48*1024*1024
free=shutil.disk_usage(temp_root).free
save('execution-space-preflight.json',dict(temp_root=str(temp_root),v15_catalogue_bytes=170619506,v14_catalogue_bytes=169430549,reserve_bytes=48*1024*1024,required_free_bytes=required,actual_free_bytes=free))
assert free>required,(free,required)
command=[sys.executable,'-B','scripts/verify_reviewed_source_v15.py','--source-version','p8-completion-source-20261009-v15']
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(temp_root),GIT_TRACE=str(OUT/'git-trace.log'),GIT_TERMINAL_PROMPT='0',GIT_NO_LAZY_FETCH='1')
started=time.monotonic()
with (OUT/'stdout.log').open('wb') as stdout,(OUT/'stderr.log').open('wb') as stderr:
    completed=subprocess.run(command,cwd=VIEW,env=env,stdout=stdout,stderr=stderr,timeout=300)
elapsed=time.monotonic()-started
after=current_snapshot();assert after==before
source_after=p7_build_identity.source_snapshot(VIEW);observer_after=p8_runtime_build.observer_snapshot(VIEW)
assert source_after==source and observer_after==observer
save('current-files-after.json',after);save('source-after.json',source_after);save('observer-after.json',observer_after)
assert initial_root_head==git('rev-parse','HEAD',cwd=ROOT).decode().strip() and initial_root_index==sha(root_index.read_bytes())
trace=(OUT/'git-trace.log').read_text()
assert not re.search(r'\b(?:built-in: git|exec: git)\s+fetch\b',trace)
assert not list(temp_root.iterdir()),'original historical context cleanup left files'
report=dict(execution=EXECUTION,tree=execution_tree,product=PRODUCT,review=REVIEW,command=command,cwd=str(VIEW),exit_code=completed.returncode,elapsed_seconds=elapsed,status='passed' if completed.returncode==0 else 'failed',view_scope='Complete required source/validation and original historical protection file projection; not entire checkout or native CI result.',materialized_count=len(before),complete_source_count=1087,complete_validation_count=138,exact_observer_count=9,all_current_files_unchanged=True,source_before_after_equal=True,observer_before_after_equal=True,root_head_index_unchanged=True,git_fetch_executed=False,native_execution=False,task_statuses_changed=False,done=163,remaining=29,artifacts={n:{'bytes':(OUT/n).stat().st_size,'sha256':sha((OUT/n).read_bytes())} for n in ['stdout.log','stderr.log','git-trace.log','current-files-before.json','current-files-after.json','source-before.json','source-after.json','observer-before.json','observer-after.json']})
print(json.dumps(save('original-v15-cli-execution.json',report),indent=2))
print((OUT/'stdout.log').read_text());print((OUT/'stderr.log').read_text())
raise SystemExit(completed.returncode)
