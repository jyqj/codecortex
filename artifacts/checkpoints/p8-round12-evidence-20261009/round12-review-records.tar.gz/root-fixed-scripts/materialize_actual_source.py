#!/usr/bin/env python3
"""Materialize exact reviewed Git objects for original offline receiver checks."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SOURCE = Path('/workspace/scratch/2eaa00d0f93a/p8-staging-reviewed-exact-source')
OUT = Path('/workspace/scratch/2eaa00d0f93a/p8-staging-engineering-exact-source')
BASE = '260f596582f2d82b8d7c707b61a6b8b6a43b069f'
ACTUAL = '8e542e644b06a83fc82d18d9896cf82f5b2d796e'

def command(*args, data=None, env=None):
    return subprocess.check_output(args, input=data, env=env, stderr=subprocess.PIPE)

def main():
    commit = json.loads((HERE / 'actual-commit.json').read_text())
    assert commit['sha'] == ACTUAL and [p['sha'] for p in commit['parents']] == [BASE]
    assert commit['tree']['sha'] == '28a35d538f11613e98e645f37d8bbd4946d754ac'
    if OUT.exists():
        # Resume only this invocation's observed clone before any checkout;
        # preserve its objects and index rather than deleting the directory.
        assert {p.name for p in OUT.iterdir()} == {'.git'}
        assert command('git', '-C', str(OUT), 'config', '--get', 'remote.origin.url').decode().strip() == str(SOURCE)
        assert command('git', '-C', str(OUT), 'rev-parse', 'HEAD').decode().strip() == '41236c3eb6e43d8c6f0fc489d5192cf14483069c'
    else:
        command('git', 'clone', '--no-checkout', '--shared', str(SOURCE), str(OUT))
    env = dict(os.environ)
    env['GIT_INDEX_FILE'] = str(OUT / '.git' / 'p8-publication-index')
    command('git', '-C', str(OUT), 'read-tree', BASE, env=env)
    for row in json.loads((HERE / 'upload-plan.json').read_text()):
        data = Path(row['local']).read_bytes()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
        actual_blob = command('git', '-C', str(OUT), 'hash-object', '-w', '--stdin', data=data).decode().strip()
        assert actual_blob == row['git_blob']
        command('git', '-C', str(OUT), 'update-index', '--add', '--cacheinfo', row['mode'], actual_blob, row['path'], env=env)
    tree = command('git', '-C', str(OUT), 'write-tree', '--missing-ok', env=env).decode().strip()
    assert tree == commit['tree']['sha']
    headers = [f'tree {tree}', f'parent {BASE}']
    for role in ('author', 'committer'):
        identity = commit[role]
        when = int(datetime.datetime.fromisoformat(identity['date'].replace('Z', '+00:00')).timestamp())
        # GitHub normalizes API dates to UTC; the original Git header uses
        # +0800, independently established by matching the actual object SHA.
        headers.append(f"{role} {identity['name']} <{identity['email']}> {when} +0800")
    candidates = [('\n'.join(headers) + '\n\n' + commit['message'] + ending).encode() for ending in ('', '\n')]
    matches = [data for data in candidates if hashlib.sha1(b'commit ' + str(len(data)).encode() + b'\0' + data).hexdigest() == ACTUAL]
    assert len(matches) == 1, 'API commit does not exactly reconstruct; do not invent a local identity'
    assert command('git', '-C', str(OUT), 'hash-object', '-t', 'commit', '-w', '--stdin', data=matches[0]).decode().strip() == ACTUAL
    command('git', '-C', str(OUT), 'sparse-checkout', 'set', '--no-cone', '/crates/', '/Cargo.toml', '/Cargo.lock',
            '/scripts/p7_build_identity.py', '/scripts/p8_scale_matrix.py', '/scripts/p8_runner_capacity.py')
    command('git', '-C', str(OUT), 'checkout', '--detach', ACTUAL)
    assert not command('git', '-C', str(OUT), 'status', '--porcelain=v1')
    sys.path.insert(0, str(OUT / 'scripts'))
    import p8_scale_matrix as original
    snapshot = original.source_snapshot(OUT)
    driver = original.driver_snapshot(OUT)
    reviewed = json.loads((HERE / 'reviewed-production-source-snapshot.json').read_text())
    assert snapshot['source_commit'] == ACTUAL and snapshot['source_tree'] == tree
    assert snapshot['inputs'] == reviewed['inputs'] and snapshot['input_count'] == 1087
    assert snapshot['manifest_sha256'] == reviewed['manifest_sha256']
    assert driver['source_commit'] == ACTUAL
    for name, data in [('actual-source-snapshot.json', snapshot), ('actual-driver-snapshot.json', driver)]:
        (HERE / name).write_bytes(original.json_bytes(data))
    report = {'status': 'exact_actual_Git_source_materialized_and_original_inventory_verified',
              'actual_commit': ACTUAL, 'actual_tree': tree, 'source_root': str(OUT),
              'input_count': 1087, 'manifest_sha256': snapshot['manifest_sha256'],
              'git_commit_object_exact_hash': True, 'git_root_tree_exact_hash': True,
              'all_product_bytes_equal_reviewed_candidate': True,
              'untouched_unmaterialized_old_artifact_blobs': 'Referenced by their unchanged Git identities; not required or fetched for product/source validation.',
              'Cargo_executed': False, 'native_executed': False, 'new_TODO_done': 0, 'TODO_remaining': 29}
    (HERE / 'actual-source-materialization.json').write_bytes(original.json_bytes(report))
    print(json.dumps(report))

if __name__ == '__main__':
    main()
