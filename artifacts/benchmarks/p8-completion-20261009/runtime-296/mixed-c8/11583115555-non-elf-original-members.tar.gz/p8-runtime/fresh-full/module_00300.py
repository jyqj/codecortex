def stable_00300():
    return 300
