#!/usr/bin/env python3
"""Small admission controls; never a replacement for real fixed-source replay."""
import importlib.util
import json
from pathlib import Path
import stat
import sys
import tempfile
import warnings
import zipfile

sys.dont_write_bytecode = True
ROOT = Path('/dev/shm/a217aaae3bde/scale-round5-review')
FROZEN = Path('/dev/shm/a217aaae3bde/codecortex-round5-frozen')
SOURCE = '599a7050e7d52b5b7b93975c419138e175b3f754'
SPEC = importlib.util.spec_from_file_location('streaming_review', ROOT / 'review_scale_fixed_source.py')
review = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(review)
outcomes = []


def passed(name, detail):
    outcomes.append({'control': name, 'status': 'passed', 'observation': detail})


def rejects(name, operation):
    try:
        operation()
    except (ValueError, zipfile.BadZipFile) as error:
        passed(name, type(error).__name__ + ': ' + str(error))
    else:
        raise AssertionError('accepted negative control: ' + name)


with tempfile.TemporaryDirectory(prefix='controls-', dir=ROOT) as scratch:
    tmp = Path(scratch)
    good = tmp / 'good.zip'
    with zipfile.ZipFile(good, 'w') as zipped:
        zipped.writestr('native/raw.jsonl', b'{"valid":true}\n')
        zipped.writestr('shard.json', b'{}\n')
    metadata = {'id': 1, 'name': 'p8-scale-shard-1000-0-37835810882',
                'size_in_bytes': good.stat().st_size, 'digest': 'sha256:' + review.sha256(good),
                'workflow_run': {'id': 37835810882, 'head_sha': SOURCE}}
    review.check_metadata(metadata, 37835810882, SOURCE, metadata['name'])
    review.check_zip(good, metadata)
    detail = review.safe_extract(good, tmp / 'valid')
    assert (tmp / 'valid/native/raw.jsonl').read_bytes() == b'{"valid":true}\n'
    assert review.bundle_root(tmp / 'valid', 'shard.json') == tmp / 'valid'
    passed('regular_archive_preserves_bytes', detail)

    rejects('different_source_rejected', lambda: review.check_metadata(metadata, 37835810882, '0' * 40))
    rejects('different_run_rejected', lambda: review.check_metadata(metadata, 37835810883, SOURCE))
    rejects('different_name_rejected', lambda: review.check_metadata(metadata, 37835810882, SOURCE, 'wrong'))
    rejects('wrong_zip_size_rejected', lambda: review.check_zip(good, metadata | {'size_in_bytes': 1}))
    rejects('wrong_zip_digest_rejected', lambda: review.check_zip(good, metadata | {'digest': 'sha256:' + '0' * 64}))
    rejects('extraction_will_not_overwrite', lambda: review.safe_extract(good, tmp / 'valid'))
    rejects('wrong_full_git_head_rejected', lambda: review.fixed_driver(FROZEN, '0' * 40))
    rejects('abbreviated_git_head_rejected', lambda: review.fixed_driver(FROZEN, SOURCE[:7]))

    for number, name in enumerate(('../outside', '/absolute', 'nested/../../outside', 'windows\\path',
                                   'nested//empty', './dot', 'drive:/bad')):
        archive = tmp / f'unsafe-{number}.zip'
        with zipfile.ZipFile(archive, 'w') as zipped:
            zipped.writestr(name, b'unsafe')
        rejects('unsafe_path_' + name, lambda a=archive, n=number: review.safe_extract(a, tmp / f'unsafe-{n}'))

    symlink = tmp / 'symlink.zip'
    link = zipfile.ZipInfo('link')
    link.create_system = 3
    link.external_attr = (stat.S_IFLNK | 0o777) << 16
    with zipfile.ZipFile(symlink, 'w') as zipped:
        zipped.writestr(link, '../outside')
    rejects('symlink_entry_rejected', lambda: review.safe_extract(symlink, tmp / 'symlink'))

    duplicate = tmp / 'duplicate.zip'
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', UserWarning)
        with zipfile.ZipFile(duplicate, 'w') as zipped:
            zipped.writestr('same', 'one')
            zipped.writestr('same', 'two')
    rejects('duplicate_destination_rejected', lambda: review.safe_extract(duplicate, tmp / 'duplicate'))

    collision = tmp / 'collision.zip'
    with zipfile.ZipFile(collision, 'w') as zipped:
        zipped.writestr('file', 'one')
        zipped.writestr('file/child', 'two')
    rejects('file_parent_collision_rejected', lambda: review.safe_extract(collision, tmp / 'collision'))

    outside = tmp / 'outside-bundle.zip'
    with zipfile.ZipFile(outside, 'w') as zipped:
        zipped.writestr('bundle/shard.json', '{}')
        zipped.writestr('unsealed.txt', 'outside')
    review.safe_extract(outside, tmp / 'outside-bundle')
    rejects('unsealed_sibling_rejected', lambda: review.bundle_root(tmp / 'outside-bundle', 'shard.json'))

    crc = tmp / 'crc.zip'
    marker = b'CRC_BOUND_ORIGINAL_BYTES'
    with zipfile.ZipFile(crc, 'w', compression=zipfile.ZIP_STORED) as zipped:
        zipped.writestr('data', marker)
    data = crc.read_bytes()
    assert data.count(marker) == 1
    crc.write_bytes(data.replace(marker, b'X' + marker[1:]))
    rejects('bad_crc_rejected', lambda: review.safe_extract(crc, tmp / 'crc'))

    duplicate_json = tmp / 'duplicate.json'
    duplicate_json.write_text('{"status":"passed","status":"failed"}')
    rejects('duplicate_json_key_rejected', lambda: review.read_json(duplicate_json))
    nonfinite = tmp / 'nonfinite.json'
    nonfinite.write_text('{"value":NaN}')
    rejects('nonfinite_json_rejected', lambda: review.read_json(nonfinite))

    # Cross-language serialization control against previously verified actual
    # 6e3 raw. This is a helper control, explicitly NOT new-source scale evidence.
    _, matrix, current_snapshot, _ = review.fixed_driver(FROZEN, SOURCE)
    old_root = Path('/workspace/scratch/a217aaae3bde/codecortex-scale-frozen-6e3')
    old_binary = Path('/workspace/scratch/a217aaae3bde/p8-scale-monitor-37824742267/build-validation-copy/p8-scale')
    old_compact = Path('/workspace/scratch/a217aaae3bde/p8-scale-monitor-37824742267/verified/11571505784/validated-shard.json')
    old_snapshot = matrix.source_snapshot(old_root)
    assert old_snapshot['source_commit'] == '6e3eb4fd97edcf238774e74b88d397e059337bac'
    expected = review.expected_engine(old_root, matrix, old_snapshot, old_binary, tmp)
    actual = json.loads(old_compact.read_bytes())['engine']
    for field in ('engine_head_observed', 'source_files_digest', 'cargo_lock_digest'):
        assert expected[field] == actual[field], (field, expected[field], actual[field])
    passed('canonical_engine_digest_matches_prior_real_rust_raw', {
        'scope': '6e3 utility serialization control only; no workload executed; not 599 matrix evidence',
        'old_source': old_snapshot['source_commit'], 'expected_engine': expected,
        'new_source_inventory_count': current_snapshot['input_count'],
        'new_source_manifest_sha256': current_snapshot['manifest_sha256']})

receipt = {'status': 'passed_helper_admission_controls', 'controls': outcomes,
           'control_count': len(outcomes), 'observed_utc': review.utc(),
           'helper_sha256': review.sha256(ROOT / 'review_scale_fixed_source.py'),
           'native_workloads_executed': 0, 'formal_scale_shards_accepted': 0,
           'task_statuses_changed': False}
review.write_new(ROOT / 'streaming-review-controls.json', receipt)
print(json.dumps({key: receipt[key] for key in ('status', 'control_count', 'native_workloads_executed',
                                               'formal_scale_shards_accepted')}))
