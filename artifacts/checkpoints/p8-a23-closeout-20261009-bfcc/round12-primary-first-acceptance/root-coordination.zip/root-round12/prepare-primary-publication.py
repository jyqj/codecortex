import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import zipfile

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'root-round12' / 'publication-primary-first-v2'
PREFIX = 'artifacts/checkpoints/p8-a23-closeout-20261009-bfcc/round12-primary-first-acceptance'
OUT.mkdir(parents=True, exist_ok=True)
groups = {}
exclusions = []
selections = []

def digest(data):
    return hashlib.sha256(data).hexdigest()

def add(group, path, expected=None):
    p = Path(path)
    assert p.is_file() and not p.is_symlink(), str(p)
    rel = p.resolve().relative_to(ROOT).as_posix()
    data = p.read_bytes()
    if expected:
        assert len(data) == expected['bytes'], (rel, 'size')
        assert digest(data) == expected['sha256'], (rel, 'sha256')
    if rel.endswith('private-library-helper/library_file_transfer.py'):
        exclusions.append({'local_path': rel, 'bytes': len(data), 'sha256': digest(data),
                           'reason': 'Tool-owned transfer implementation is not project source and is not redistributed; unchanged local original retained.'})
        return
    try:
        txt = data.decode('utf-8')
    except UnicodeDecodeError:
        txt = ''
    patterns = [r'(?:[?&]|\\u0026)(?:sig|signature|x-amz-signature|x-goog-signature|token|access_token)=[A-Za-z0-9%/+_-]{12,}',
                r'(?im)^set-cookie:\s*(?!\[?REDACTED)[^\r\n]{12,}']
    for pattern in patterns:
        assert not re.search(pattern, txt, re.I), (rel, 'potential private transfer parameter; preserve original locally and review publication copy')
    d = groups.setdefault(group, {})
    assert rel not in d or d[rel] == data
    d[rel] = data

def select(group, rel):
    p = ROOT / rel
    d = json.loads(p.read_text())
    add(group, p)
    selections.append({'local_path': rel, 'bytes': p.stat().st_size, 'sha256': digest(p.read_bytes())})
    for e in d.get('files', d.get('entries', [])):
        raw = e.get('local_path', e.get('path'))
        source = Path(raw)
        if not source.is_absolute():
            source = Path(d.get('base', str(p.parent))) / raw
        add(group, source, e)

for rel in [
    'scale-intake-primary/primary-bootstrap-selection.json',
    'scale-intake-primary/git-recovery/recovery-selection.json',
    'scale-intake-primary/build-intake-validation-selection.json',
    'scale-intake-primary/first-shard-and-capacity-selection.json',
    'scale-intake-primary/second-shard-batch-5k-10k-selection.json',
]:
    select('scale-original-intake', rel)
for rel in [
    'todo-audit-round12/archive-selection.json',
    'todo-audit-round12/archive-selection-v2.json',
    'todo-audit-round12/scale-build-independent/archive-selection.json',
    'todo-audit-round12/ci-original-msrv/archive-selection.json',
]:
    select('independent-reviews-and-preparation', rel)
select('runtime-c16', 'pr-triage-primary-recovery/runtime-review-Gc8/publication-selection.json')
add('runtime-c16', ROOT / 'pr-triage-primary-recovery/runtime-review-Gc8/c16-concurrency-field-clarification.json')
for p in sorted((ROOT / 'root-round12').glob('*.json')):
    add('root-coordination', p)
add('root-coordination', Path(__file__))

payload = []
bundles = []
for group, files in sorted(groups.items()):
    zpath = OUT / (group + '.zip')
    assert not zpath.exists(), str(zpath)
    with zipfile.ZipFile(zpath, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for member, data in sorted(files.items()):
            info = zipfile.ZipInfo(member, date_time=(2026, 10, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o100644 << 16)
            z.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
            payload.append({'archive': zpath.name, 'archive_member': member,
                            'original_local_path': str(ROOT / member),
                            'bytes': len(data), 'sha256': digest(data)})
    with zipfile.ZipFile(zpath) as z:
        assert z.testzip() is None
        assert z.namelist() == sorted(files)
        for name, original in files.items():
            assert z.read(name) == original
    b = zpath.read_bytes()
    bundles.append({'file_name': zpath.name, 'repository_path': PREFIX + '/' + zpath.name,
                    'local_path': str(zpath), 'bytes': len(b), 'sha256': digest(b),
                    'git_blob_sha': hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest(),
                    'members': len(files), 'uncompressed_bytes': sum(map(len, files.values()))})

manifest = {
    'schema': 'codecortex.primary-first-original-acceptance-publication.v1',
    'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'publication_parent': '7e37aad7f347598b77d76c060ce154ce55d8eb94',
    'source_G': 'c8be5afaac568ffd40ef86d3795423c3b73c9f39',
    'formal_scale': {'run_id': 37902429727, 'run_attempt': 1,
                     'accepted_shards': 3, 'required_shards': 150,
                     'accepted_samples': 32, 'required_samples': 1500,
                     'scope': 'Accepted original rep0 at 1k/5k/10k; 50k/100k pending. No aggregate or substitute from other sources.'},
    'original_tasks': {'total': 192, 'done': 163, 'remaining': 29, 'new_original_completed': 0,
                       'tasks_sha256': '6e2ab2e90cbd820228e8ff397d70c770561ba20d3110e6eca31338f29a945207'},
    'accepted_scopes': [
        'Gc8 original release build and independent exact1090 input/source review.',
        'Five original capacity probes and three original shard validations.',
        'Gc8 C16 original raw/runtime verification with actual peak12 and final active read/build counters0.',
        'Original CI MSRV commands on observed synthetic merge39ae6437; relevant source domains equalGc8, whole tree differs.',
        '017-020 preparation v2 corrects v1 Rust-only owner claim; original v1 retained as historical evidence.',
    ],
    'limitations': [
        'No181/v15,150/1500 aggregate, platform/recovery/gates/lifecycle completion or original TODO closure is granted by this packet.',
        'Large original ZIP/ELF/RPC files excluded by supplied selections remain at their original primary/GitHub artifact locators; the packet does not contain them.',
        'These ZIPs are publication containers containing selected original bytes, not substitutes for the original GitHub artifact ZIPs.',
        'Supplied selection repository_path fields are proposed expanded layouts; the actual Git publication uses archive members mapped here.',
        'The source recovery is a verified sparse immutable Git recovery, not a complete working tree or history.',
        'Original GitHub native dispatch exit is unknown; the one accepted workflow_dispatch run is independently observed.',
    ],
    'selections': selections, 'explicit_publication_exclusions': exclusions,
    'bundles': bundles, 'file_count': len(payload), 'files': payload,
}
mpath = OUT / 'publication-manifest.json'
mpath.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
index = {'prefix': PREFIX, 'bundles': bundles,
         'manifest': {'local_path': str(mpath), 'bytes': mpath.stat().st_size, 'sha256': digest(mpath.read_bytes())}}
(OUT / 'upload-index.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps({'files': len(payload), 'exclusions': exclusions, 'bundles': bundles,
                  'manifest_bytes': mpath.stat().st_size}, ensure_ascii=False))
