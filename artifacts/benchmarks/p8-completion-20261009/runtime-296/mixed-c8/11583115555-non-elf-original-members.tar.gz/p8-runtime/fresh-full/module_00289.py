def stable_00289():
    return 289
