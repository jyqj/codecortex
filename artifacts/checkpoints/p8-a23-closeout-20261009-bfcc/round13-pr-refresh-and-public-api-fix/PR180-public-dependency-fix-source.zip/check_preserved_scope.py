#!/usr/bin/env python3
"""Read-only author scope checks, not Rust execution or acceptance."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
def text(tree, path):
    return (ROOT / tree / path).read_text()

path = 'crates/cc-db/src/index_db_write_batch.rs'
old, new = text('original', path), text('candidate', path)
added_helper = '''    /// Rebuild-owner dependency batching without deferred FTS. The owner must
    /// abandon staging on error, even when the FTS schema guard selects this
    /// immediate-mirror fallback. The ordinary snapshot seam does not opt in.
    pub(crate) fn insert_snapshot_file_data_for_rebuild(
        conn: &Connection,
        file: &FileWriteUnit,
        chunk_blobs: Option<&[Option<Vec<u8>>]>,
    ) -> CcResult<()> {
        Self::insert_file_data_impl(conn, file, chunk_blobs, false, true, true)
    }

'''
assert new.count(added_helper) == 1
normalized = new.replace(added_helper, '')
for before, after in [
    ('false, false', 'false, false, false'),
    ('true, false', 'true, false, false'),
    ('false, true', 'false, true, false'),
    ('true, true', 'true, true, true'),
]:
    a = f'Self::insert_file_data_impl(conn, file, chunk_blobs, {after})'
    b = f'Self::insert_file_data_impl(conn, file, chunk_blobs, {before})'
    assert normalized.count(a) == 1
    normalized = normalized.replace(a, b)
normalized = normalized.replace('        rebuild_dependency_batches: bool,\n', '')
normalized = normalized.replace('if rebuild_dependency_batches {', 'if snapshot_leaf_batches {')
assert normalized == old

path = 'crates/cc-db/src/snapshot_write_txn.rs'
old, new = text('original', path), text('candidate', path)
start = '    pub fn write_file_data(\n'
public_old = old.split(start)[1].split('    /// Opt in')[0]
public_new = new.split(start)[1].split('    /// Opt in')[0]
assert public_old == public_new
normalized = new.replace(
    '    /// Opt in to bounded dependency INSERTs and files/literal FTS mirrors\n    /// during a full rebuild.\n',
    '    /// Opt in to bounded files/literal FTS mirrors during a full rebuild.\n',
).replace(
    "    /// window without their mirrors when a later write fails, and a failed\n    /// dependency batch need not retain the per-row writer's partial prefix.\n    /// It does not own or roll back the borrowed connection's transaction.\n",
    "    /// window without their mirrors when a later write fails. It does not own\n    /// or roll back the borrowed connection's transaction.\n",
).replace(
    'IndexDb::insert_snapshot_file_data_for_rebuild(self.conn, unit, blobs)?;',
    'IndexDb::insert_snapshot_file_data_precompressed(self.conn, unit, blobs)?;',
)
assert normalized == old

path = 'crates/cc-db/tests/p2b_resolution_store.rs'
old, new = text('original', path), text('candidate', path)
marker = '\n#[test]\nfn public_snapshot_dependency_failure_preserves_original_catch_and_commit_prefix()'
assert new.count(marker) == 1
existing = new.split(marker)[0]
expected = old.replace(
    'cc_db::SnapshotWriteTxn::new(conn).write_file_data(&files, &Default::default())',
    'cc_db::SnapshotWriteTxn::new(conn)\n                .write_file_data_for_rebuild(&files, &Default::default())',
).replace('.write_file_data(&files, &Default::default())?;', '.write_file_data_for_rebuild(&files, &Default::default())?;')
assert existing == expected
assert old.count('#[test]') == 6 and new.count('#[test]') == 7
assert '[0usize, 1, 7, 8, 9, 63, 64, 65, 73]' in existing
assert "WHEN NEW.file_path='failed.py' AND NEW.key='key-00070'" in existing
assert 'snapshot_dependency_unit("failed.py", 73)' in existing
assert 'assert_eq!(snapshot_dependency_tables(&db), retained);' in existing
regression = new.split(marker)[1]
assert '.write_file_data_for_rebuild(' not in regression
assert '.write_file_data(&files, &Default::default())' in regression
assert 'IndexDb::insert_file_data(&conn, file)' in regression
assert '(0..70)' in regression and 'COMMIT' in regression

inputs = json.loads((ROOT/'original-inputs.json').read_bytes())
for row in inputs['inputs']:
    raw = (ROOT/'original'/row['path']).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    assert hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest() == row['git_blob']
result = {
    'actual_result': 'passed_readonly_author_scope_comparisons',
    'original_public_method_body_exactly_preserved': True,
    'all_existing_product_bytes_preserved_except_explicit_allowlisted_routing_and_new_optin_docs': True,
    'FTS_selection_and_leaf_batch_conditions_unmodified': True,
    'ordinary_and_public_dependency_batches': False,
    'rebuild_dependency_batches_when_FTS_deferred': True,
    'rebuild_dependency_batches_when_FTS_fallback': True,
    'old_six_test_bodies_preserved_except_two_optin_calls': True,
    'new_public_regression_count': 1,
    'public_regression_borrows_own_connection_not_rebuild_owner': True,
    'Rust_compilation_or_test_execution': 'not_run',
}
(ROOT/'author-scope-check.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
