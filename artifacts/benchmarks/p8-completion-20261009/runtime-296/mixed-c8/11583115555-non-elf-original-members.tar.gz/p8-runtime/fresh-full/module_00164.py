def stable_00164():
    return 164
