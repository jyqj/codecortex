def stable_00372():
    return 372
