# 最终 9b P7 正式 CI 证据

此包固定属于 PR #146 head `9b3711a9346b64868b64cf6cc1f6e38162a59a43`，不是旧 57 head 的重用结果。

- Run: https://github.com/jyqj/codecortex/actions/runs/37674979650
- Job: https://github.com/jyqj/codecortex/actions/runs/37674979650/job/112976034193
- 官方 artifact ID: `11506792469`。ZIP 为下载后的原字节，其摘要与 GitHub 官方 digest 完全一致。
- 14 个正式步骤均 success。Rust 24 组，95 passed / 0 failed / 1 ignored / 651 filtered out；Python 15 tests / OK。
- 唯一 ignored 的原始原因保存在 parsed-results.json：stdio mechanism smoke 需要显式当前 product path 与 SHA256，未计入通过。
- Worker 384 个原始请求，3 seeds × 2 phases × 2 concurrency cells；每格32条、ordinal 0..31恰一次，全部 stable.rs 命中；old held publication均为0。
- 实际 checkout `0b69df3ca6c3fc1a76d28b363c3f0e3d6d23a998`，父为本次运行时的 d53 main 与 9b head。tree `5fd3e14bfabd98346a4fb0b18c28b04c8b212bec` 与最终交付相同。随后 main 指针移动不改写这个历史 checkout。
- source-before/source-after 原字节相同，785 项输入逐项等于固定产品 `8e12c3884edbb2743eb2aee82fafa285e8b28ef7` 和 9b；紧凑排序 path→SHA256 JSON 摘要 `4c9aeb9cac2eea382d2dbce6d85220af3e10f6483b4c1f696b7874ecaff0fdb4`。ZIP 内 manifest_sha256 使用带缩进及结尾换行的另一种序列化，二者分别核验，不混用。

正式 decoded job log 仅作无损 gzip 压缩。官方 ZIP 内容未重打包；所有原始 artifact 成员（含完整 logs、source manifests、worker requests 和 summaries）仍在 ZIP 中。file-manifest.json 记录包内每个 payload 的字节数与SHA256（自身除外）。未创建新的PR源码提交，也未复跑Rust或Python项目测试。

复验时，指定一个已有上述 8e12/9b 固定 Git 对象的仓库：

```bash
python3 verify_artifact.py --repo /path/to/codecortex
```

脚本直接读取旁边的 gzip 日志和原 ZIP，逐项重算计数、Git blob输入清单、所有请求分组和稳定命中；默认只读且只输出结果。可选 `--output-dir /new/empty/directory` 保存重新计算的 JSON，不覆盖包内原记录。归档解开后不依赖原 attachments 路径。

范围是本次固定 P7 工程回归与实际样本完整性。summary 的 full_p7_015_complete=false、性能与资源归因未验收边界保持；此包不授予完整P7-015、质量、100k、冷构建或发布验收。主CI由独立运行证明。
