"""Independent data-only replay. Never execute archive code or product binaries."""
import hashlib,json,tarfile,tempfile,sys
from pathlib import Path,PurePosixPath
BASE=Path(__file__).resolve().parent
CANDIDATE=BASE.parents[1]/'pr-audit/cache-observer-candidate/candidate'
sys.path.insert(0,str(CANDIDATE/'scripts'))
import p8_runtime as runtime

def sha(b):return hashlib.sha256(b).hexdigest()
def load(b):return json.loads(b)
manifest=load((BASE/'original-checkpoint/cache-engineering-manifest.json').read_bytes())
archive=BASE/'original-checkpoint/cache-engineering-originals.tar.gz'
assert sha(archive.read_bytes())==manifest['archive_sha256']
files={}
with tarfile.open(archive,'r:gz') as tar:
 for member in tar.getmembers():
  n=member.name;p=PurePosixPath(n)
  assert member.isfile() and not p.is_absolute() and '..' not in p.parts and n not in files
  b=tar.extractfile(member).read();files[n]=b
  assert {'bytes':len(b),'mode':member.mode,'sha256':sha(b)}==manifest['files'][n]
assert len(files)==manifest['file_count']==167 and set(files)==set(manifest['files'])
prefix='actual-small-probe/run-01/'
original={n[len(prefix):]:b for n,b in files.items() if n.startswith(prefix)}
r=load(original['receipt.json']);plan=load(original['plan.json']);reads=load(original['reads.json']);mutations=load(original['mutations.json'])
assert r['plan']==plan and r['initial_full']==load(original['initial-full.json'])
assert r['files']=={n:{'bytes':len(b),'sha256':sha(b)} for n,b in original.items() if n!='receipt.json'}
assert len(r['files'])==58 and r['status']=='passed_small_actual_product_probe' and r['exit_code']==0 and not r['errors']
assert r['observer_hashes_after']==plan['observer_hashes_before']
for n,d in r['observer_hashes_after'].items(): assert sha(files['candidate/'+n])==d
assert sha(files['candidate/scripts/p8_runtime.py'])==sha((BASE/'candidate/scripts/p8_runtime.py').read_bytes())==plan['observer_runtime_sha256']
assert len(reads)==14 and len(mutations)==6
process=load(original['product/process.json']); project_wire=process['command'][-1]
expected=[('index',{'path':project_wire,'full':True},r['initial_full'])]
previous=None;states=[];epochs=[];pids=[]
with tempfile.TemporaryDirectory(prefix='independent-cache-original-data-') as t:
 project=Path(t)
 for n in ('.p8-owned','stable.py'): (project/n).write_bytes(original['project/'+n])
 for stage in range(7):
  preceding=None
  if stage:
   m=mutations[stage-1]
   assert m['ordinal']==stage-1 and m['status']=='success' and m['response']['parse_errors']==[] and m['response']['resolution_freshness']['complete'] is True
   assert m['started_ns']<=m['finished_ns']<=reads[2*stage]['call_started_ns']
   preceding=dict(action=m['mutation']['action'],ordinal=m['ordinal'],operation_id=m['ordinal'],index_epoch=m['response']['resolution_freshness']['index_epoch'])
   expected.append(('index',{'path':project_wire,'full':False},m['response']))
  for row in reads[2*stage:2*stage+2]:
   assert row['status']=='success' and row['offered_ns']<=row['started_ns']<=row['call_started_ns']<=row['finished_ns']
   p=row['cache_probe'];assert p['preceding_mutation']==preceding
   observed=runtime.validate_cache_probe(p,previous,project);assert observed==p['observation'];previous=observed
   assert row['response']==p['requests'][1]['response']
   assert row['call_started_ns']<=p['requests'][0]['started_ns']<=p['requests'][-1]['finished_ns']<=row['finished_ns']
   states.append(observed['lookup']['state']);epochs.append(observed['identity']['generation']['index_epoch']);pids.append(observed['identity']['pid'])
   expected.extend((c['name'],c['arguments'],c['response']) for c in p['requests'])
assert states==r['cache_states']==['miss','hit']*6+['hit','hit']
assert [m['mutation']['action'] for m in mutations]==['bounded_symbol_churn','add','rename','delete','real_git_branch_switch','restore_api']
assert sum(x['cache_probe']['observation']['invalidated'] for x in reads)==r['invalidations']==5
assert set(pids)=={process['pid']}=={16}
wire=[load(l) for l in original['product/rpc.jsonl'].splitlines()]
requests=[e['payload'] for e in wire if e['event']=='request'];responses=[e['payload'] for e in wire if e['event']=='response'];stdout=[load(e['text']) for e in wire if e['event']=='stdout_wire']
assert len(requests)==len(responses)==len(stdout)==65 and len(expected)==63
assert responses==stdout and [r['id'] for r in requests]==[r['id'] for r in responses]==list(range(1,66))
assert requests[0]['method']=='initialize' and requests[1]['method']=='tools/list'
for req,res,(name,args,body) in zip(requests[2:],responses[2:],expected):
 assert req['method']=='tools/call' and req['params']=={'name':name,'arguments':args}
 assert 'error' not in res and res['result']['isError'] is False
 value=res['result']['structuredContent'];assert value.get('result',value)==body
terminal=[e for e in wire if e['event']=='terminal']
assert len(terminal)==2 and wire[-2:]==terminal and terminal[0]['kind']=='stdout_eof' and terminal[1]['kind']=='process_exit' and terminal[1]['exit_code']==0
assert process==r['cleanup'] and process['cleanup']=='completed' and process['exit_code']==0
origin=Path('/workspace/scratch/2eaa00d0f93a/p8-formal-evidence-G/lifecycle/files/product')
origin_receipt=load((origin/'build-receipt.json').read_bytes())
assert origin_receipt['source_before']==origin_receipt['source_after'] and origin_receipt['build_exit_code']==0
assert origin_receipt['source_before']['source_commit']==plan['product_source']=='bb9a96d71622458c39a143055360cc97f0d11d78'
assert origin_receipt['source_before']['input_count']==1087
binary=origin/'codecortex';assert sha(binary.read_bytes())==plan['product_sha256']==origin_receipt['binary_sha256']
report=dict(schema_version=1,scope='Independent read-only original archived data replay; no product or archived code executed',accepted=True,archive_sha256=sha(archive.read_bytes()),archive_files=len(files),archive_bytes=sum(map(len,files.values())),run_files=len(r['files']),run_bytes=sum(v['bytes'] for v in r['files'].values()),receipt_sha256=sha(original['receipt.json']),probe_executor_sha256=sha(files['actual-small-probe/run_probe.py']),observer_runtime_sha256=plan['observer_runtime_sha256'],integrated_runtime_sha256=sha((CANDIDATE/'scripts/p8_runtime.py').read_bytes()),source=plan['product_source'],original_build_receipt_sha256=sha((origin/'build-receipt.json').read_bytes()),binary_read_only_sha256=sha(binary.read_bytes()),binary_bytes=binary.stat().st_size,original_artifact_id=plan['original_product_artifact_id'],compound_reads=14,read_rpc=56,total_tool_calls=63,wire_requests=65,wire_responses=65,wire_stdout=65,wire_bijection=True,cache_states=states,index_epochs=epochs,invalidations=5,native_pid=16,elapsed_ns=r['elapsed_ns'],limits=['Old bb9 product with P4-equivalent observer; not newly built M4/integration/P4 product.','0.648-second sequential fixture; not one-hour, sampler/queue, four-window, Rust statistics or 15-table endpoint certification.','Same process/shared pool counters do not establish individual OS-thread identity or semantic-worker reuse.'],task_complete=False)
(BASE/'original-probe-independent-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
