def stable_00105():
    return 105
