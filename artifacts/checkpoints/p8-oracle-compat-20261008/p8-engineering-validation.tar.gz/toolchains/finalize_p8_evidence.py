#!/usr/bin/env python3
"""Assemble final scoped evidence only after the actual required runs finish."""
from collections import Counter
import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

SESSION = Path('/workspace/scratch/031390cf22eb')
ROOT = SESSION / 'codecortex-scale'
DEST = ROOT / 'artifacts/checkpoints/p8-oracle-compat-20261008'
SOURCE = 'df140ad1dc97f080afd748e9571b360e0cade5fe'
REVIEW = 'b2a6c135444ef61d629cac1d739b120c8a3158d2'
VERIFIED = 'a23bbfe8e16670a98ba32363bb419337522b8ba9'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_run(directory, label, expected_exit=0):
    path = SESSION / directory / (label + '.json')
    data = json.loads(path.read_text())
    assert data.get('exit_code') == expected_exit, (label, data.get('status'))
    assert data.get('source_unchanged') is True, label
    before = data['source_before']
    source = before.get('source', before)
    log = SESSION / directory / (label + '.log')
    return {
        **{key: data[key] for key in ('command', 'status', 'exit_code', 'elapsed_seconds',
                                      'started_utc', 'finished_utc', 'source_unchanged')},
        'source_commit': source['source_commit'],
        'source_manifest_sha256': source['manifest_sha256'],
        'receipt_path_in_archive': directory + '/' + path.name,
        'receipt_sha256': sha(path.read_bytes()),
        'log_path_in_archive': directory + '/' + log.name,
        'log_sha256': sha(log.read_bytes()),
    }


runs = {}
for label in ('final-v14-cli', 'final-source-integrity', 'final-fmt',
              'final-plan', 'final-p8-facts', 'final-historical-integrations'):
    runs[label] = read_run('validation-integration', label)
    assert runs[label]['source_commit'] == VERIFIED
source_log = (SESSION / 'validation-integration/final-source-integrity.log').read_text()
assert re.search(r'Ran 174 tests in [0-9.]+s', source_log)
assert re.search(r'^OK\s*$', source_log, re.M)
assert not re.search(r'^(FAILED|FAIL:|ERROR:)', source_log, re.M)
for label in ('oracle-regressions-corrected', 'oracle-clippy', 'forwarding-scale-build'):
    runs[label] = read_run('validation-scale', label)
for label in ('forwarding-after-fix', 'forwarding-existing-parser-db-regressions',
              'forwarding-existing-module-rules', 'forwarding-clippy'):
    runs[label] = read_run('validation-forwarding', label)
runs['p8-script-tests-a20d'] = read_run('validation-integration', 'p8-script-tests-a20d')
for label, expected in (('oracle-regressions', 101), ('scale-10k-control', 2),
                        ('scale-10k-forwarding-fixed', 3)):
    runs[label] = read_run('validation-scale', label, expected)
runs['forwarding-before-fix'] = read_run('validation-forwarding', 'forwarding-before-fix', 101)

subprocess.run(['git', 'diff', '--exit-code', VERIFIED, '--', 'crates', 'Cargo.toml',
                'Cargo.lock', 'scripts', '.github/workflows', 'tests/source_integrity'],
               cwd=ROOT, check=True)
current_tasks = json.loads((ROOT / 'docs/roadmap/code-index-v2/tasks.json').read_text())
base_tasks = json.loads(subprocess.check_output(
    ['git', 'show', VERIFIED + ':docs/roadmap/code-index-v2/tasks.json'], cwd=ROOT))
changed = []
assert len(current_tasks['tasks']) == len(base_tasks['tasks']) == 192
for before, after in zip(base_tasks['tasks'], current_tasks['tasks']):
    assert before['id'] == after['id'] and before['status'] == after['status']
    if before == after:
        continue
    changed.append(after['id'])
    assert after['id'] in {'P8-002', 'P8-003', 'P8-004', 'P8-005', 'P8-006'}
    for key in set(before) | set(after):
        if key not in {'evidence', 'implementation_notes'}:
            assert before.get(key) == after.get(key), (after['id'], key)
    assert after['evidence'][:len(before.get('evidence', []))] == before.get('evidence', [])
    assert after['implementation_notes'].startswith(before.get('implementation_notes', ''))
for key in set(base_tasks) | set(current_tasks):
    if key != 'tasks':
        assert base_tasks.get(key) == current_tasks.get(key), key
states = dict(Counter(task['status'] for task in current_tasks['tasks']))
assert states == {'done': 160, 'blocked': 1, 'in_progress': 19, 'todo': 12}

subprocess.run(['python', '-B', str(SESSION / 'toolchains/assemble_round_evidence.py')], check=True)
for name in ('pr148-independent-validation.tar.gz', 'pr148-independent-validation-manifest.json',
             'p8-engineering-validation.tar.gz', 'p8-engineering-validation-manifest.json',
             'p8-executed-source-history.bundle', 'p8-executed-source-history.json'):
    shutil.copyfile(SESSION / 'round-evidence-stage' / name, DEST / name)
shutil.copyfile(SESSION / 'pr148-review/merged-main-ancestry.json', DEST / 'merged-main-ancestry.json')

readme = DEST / 'README.md'
text = readme.read_text()
pending = 'PENDING_FINAL_SOURCE_VERIFICATION'
assert text.count(pending) == 1
readme.write_text(text.replace(pending, '**全部通过；174 passed、0 skipped**'))

report = {
    'schema_version': 1,
    'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'independently reviewed engineering repairs and exact local validation; original P8 task acceptance stays open',
    'product_source': SOURCE,
    'independent_review_commit': REVIEW,
    'actual_final_validation_commit': VERIFIED,
    'final_documentation_delta_changes_source_or_validation': False,
    'review_sha256': sha((DEST / 'independent-source-review.json').read_bytes()),
    'source_inputs': 798,
    'source_manifest_sha256': 'ef3fcf15da0523391b9c25abbc589b3c14498896eff581df416228619ef22aa6',
    'reviewed_validation_inputs': 105,
    'runs': runs,
    'final_source_integrity': {'passed': 174, 'failed': 0, 'skipped': 0,
                               'original_method_count': 139, 'new_method_count': 35},
    'original_task_ledger': {'total': 192, 'states': states, 'unfinished': 32,
                             'newly_completed_this_session': 7,
                             'completed_by_merged_pr148': ['P7-014', 'P7-015', 'P7-016', 'P7-017', 'P7-019', 'P7-020', 'P8-001'],
                             'newly_completed_by_this_p8_delta': 0,
                             'appended_evidence_tasks': changed,
                             'original_definitions_and_dependencies_unchanged': True,
                             'requested_at_least_ten_complete': False,
                             'sha256': sha((ROOT / 'docs/roadmap/code-index-v2/tasks.json').read_bytes())},
    'ten_thousand_control': {'profile': 'debug_smoke', 'repetitions': 1,
                            'same_plan_bytes': True,
                            'original_exit_code': 2, 'fixed_exit_code': 3,
                            'fixed_status': 'deadline_exceeded',
                            'full_builds_finished': 2,
                            'each_full_build': {'files_parsed': 10000, 'symbols_total': 55620, 'chunks_total': 63619, 'parse_errors': 0},
                            'complete_parity_observed': False, 'complete_run_observed': False,
                            'full_scale_or_performance_certified': False},
    'task_coordination_issues': {'P8-002': 149, 'P8-003': 150, 'P8-004': 151},
    'corpus_quantity_correction': 'Original D2 plans approximately 600 reviewed questions; no invented 600-independent-family hard gate.',
    'remote_pr_ci': 'Must be read for the final published head before merge; this pre-publication local record does not pre-approve future CI.',
    'not_certified': ['full 1k/5k/10k/50k/100k matrix', '30 repetitions', 'true-provider quality',
                      'cc-switch/Flask external suite', 'clean holdout', 'whole-process-tree resource peaks', 'G8/release'],
    'artifact_files': {path.name: {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}
                       for path in sorted(DEST.iterdir()) if path.is_file() and path.name != 'execution-summary.json'},
}
(DEST / 'execution-summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + '\n')
assert pending not in readme.read_text()
print(json.dumps({'status': 'assembled_verified_records', 'directory': str(DEST),
                  'runs': len(runs), 'source_integrity_passed': 174, 'unfinished_original_tasks': 32}))
