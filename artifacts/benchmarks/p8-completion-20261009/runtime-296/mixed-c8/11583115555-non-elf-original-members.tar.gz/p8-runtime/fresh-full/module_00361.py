def stable_00361():
    return 361
