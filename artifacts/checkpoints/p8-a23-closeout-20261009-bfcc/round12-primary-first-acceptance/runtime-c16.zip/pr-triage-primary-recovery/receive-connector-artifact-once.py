from pathlib import Path, PurePosixPath
import sys,json,hashlib,datetime,urllib.request,zipfile,stat,re,shutil,traceback,platform
dest=Path(sys.argv[1]); data=json.loads((dest/'private-transport-input.json').read_text());(dest/'private-transport-input.json').unlink()
a=data['artifact'];run=data['run'];SOURCE='c8be5afaac568ffd40ef86d3795423c3b73c9f39'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(name,obj):
 with (dest/name).open('x') as f:json.dump(obj,f,ensure_ascii=False,indent=2);f.write('\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
receipt={'schema_version':1,'started_at':now(),'artifact_id':a['id'],'source':SOURCE,'run_id':run['id'],'run_attempt':run['run_attempt'],'host':platform.platform(),'transport':'GitHub connector download_workflow_artifact official ZIP -> reusable file reference -> Python HTTPS once; no local gh process','file_reference':data['file_reference'],'new_primary_host':True,'status':'started','no_automatic_retry':True,'old_Mac_finite_collector':'unknown after MCP request timeout; not redispatched','raw_semantic_validation':'pending','measurement_or_TODO_credit':False}
write('github-metadata.json',a);write('run-metadata.json',run);write('file-reference.json',data['file_reference'])
try:
 assert a['workflow_run']['id']==run['id']==37901930897 and a['workflow_run']['head_sha']==run['head_sha']==SOURCE
 assert run['run_attempt']==1 and not a['expired'] and a['name'].endswith(SOURCE)
 assert type(a['size_in_bytes']) is int and a['size_in_bytes']>0
 assert shutil.disk_usage(dest).free>a['size_in_bytes']+1024**3
 response=urllib.request.urlopen(data['download_url'],timeout=120)
 receipt['http_status']=response.status
 with response as source,(dest/'original.zip').open('xb') as target:
  shutil.copyfileobj(source,target,1048576)
 zpath=dest/'original.zip'; zsize=zpath.stat().st_size; zsha=sha(zpath)
 identity={'zip_bytes':zsize,'zip_sha256':zsha,'official_size':a['size_in_bytes'],'official_digest':a.get('digest'),'size_matches':zsize==a['size_in_bytes'],'digest_matches':a.get('digest')=='sha256:'+zsha}
 write('zip-identity.json',identity)
 assert identity['size_matches'] and identity['digest_matches'],identity
 members=[];seen=set()
 with zipfile.ZipFile(zpath) as z:
  for m in z.infolist():
   raw=m.orig_filename;p=PurePosixPath(raw);normalized=str(p).rstrip('/')
   assert '\x00' not in raw and raw==m.filename and '\\' not in raw and not p.is_absolute() and '..' not in p.parts and not re.match(r'^[A-Za-z]:',raw)
   assert normalized not in ('','.') and raw.rstrip('/')==normalized and normalized not in seen
   seen.add(normalized);mode=(m.external_attr>>16)&0xffff
   assert stat.S_IFMT(mode) in (0,stat.S_IFREG,stat.S_IFDIR) and not stat.S_ISLNK(mode) and not(m.flag_bits&1)
   members.append({'name':raw,'normalized_name':normalized,'bytes':m.file_size,'compressed_bytes':m.compress_size,'crc32':'%08x'%m.CRC,'mode':mode,'is_directory':m.is_dir(),'sha256':None})
  total=sum(m['bytes'] for m in members);assert shutil.disk_usage(dest).free>total+1024**3
  extract=dest/'extracted';extract.mkdir()
  for zi,m in zip(z.infolist(),members):
   target=extract/PurePosixPath(m['normalized_name']);assert target.resolve().is_relative_to(extract.resolve())
   if zi.is_dir():
    with z.open(zi) as f:assert f.read()==b'' and zi.file_size==0
    target.mkdir(parents=True,exist_ok=True);continue
   target.parent.mkdir(parents=True,exist_ok=True)
   with z.open(zi) as source,target.open('xb') as output:shutil.copyfileobj(source,output,1048576)
   assert target.stat().st_size==m['bytes'];m['sha256']=sha(target)
   if m['mode']&0o777:target.chmod(m['mode']&0o777)
 assert sha(zpath)==zsha
 write('zip-members.json',members)
 receipt.update(status='transport_verified',**identity,members=len(members),uncompressed_bytes=total,all_member_crc_reads_completed=True,all_regular_members_sha256_recorded=True,finished_at=now(),receiver_expected_exit_code=0)
 write('transport-receipt.json',receipt)
 print(json.dumps({k:receipt[k] for k in ['status','artifact_id','source','run_id','run_attempt','zip_bytes','zip_sha256','members','uncompressed_bytes']}))
except Exception as e:
 receipt.update(status='failed_retained_no_retry',error=repr(e),traceback=traceback.format_exc(),finished_at=now(),receiver_expected_exit_code=1)
 write('transport-receipt.json',receipt)
 print(json.dumps({'status':receipt['status'],'error':repr(e)}))
 raise

