def stable_00477():
    return 477
