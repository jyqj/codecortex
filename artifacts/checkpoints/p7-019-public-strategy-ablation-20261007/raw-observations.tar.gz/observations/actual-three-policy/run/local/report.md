# CodeCortex benchmark baseline

Suite: `p7-019-fake-public-three-policy-mechanism`
Adapter: `public-strategy-ablation-v1`
Scoring: `Native`
Measurement profile: `fake`

Status: **baseline_recorded_not_quality_certified** (exit 0)

Queries: 3; measured rows: 6.
Mean Top-1: 0.666667; mean nDCG@10: 0.666667.

These are baseline observations, not a release quality certificate.
Latency: Distribution { samples: 6, p50_us: Some(32192), p95_us: Some(36197), max_us: Some(36197), tail_claim: "insufficient_for_tail_claim" }; samples are retained, not best-of.
Source evidence: 0 invalid, 0 unverified hits.

| Case | Top-1 | nDCG@10 | Repetitions |
|---|---:|---:|---:|
| exact-a | 1.000000 | 1.000000 | 2 |
| exact-b | 1.000000 | 1.000000 | 2 |
| authored-intent | 0.000000 | -0.000000 | 2 |

## Failures
