from pathlib import Path
import json,subprocess,hashlib,sys,time,datetime,os
root=Path.cwd();out=root.parent/'native-public-api-merge-H2-e564-admission'
(out/'historical-protection-preparation-controller.py').write_bytes(Path(sys.argv[0]).read_bytes())
paths=json.load(sys.stdin);assert len(paths)==236 and len(set(paths))==236
sys.path.insert(0,str(root/'scripts'));import v15_historical_context as history
assert history.HISTORICAL_HEAD=='7354db236c9d9850a75f31672697ae9eab44565e'
for path in paths:assert history.relative(path)==path
assert hashlib.sha256(('\n'.join(paths)+'\n').encode()).hexdigest()=='aafd155302992ec650493a57ed432d81745955c1c77f8350e0a436732dd6df09'
H='e5640904298febdf8dc951e0baddb2819f930c0b';BASE=history.HISTORICAL_HEAD
receipts=[]
def run(label,args,timeout=180):
 start=time.monotonic();sp=out/(label+'.stdout');ep=out/(label+'.stderr');r={'label':label,'argv':args,'cwd':str(root),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with sp.open('wb') as so,ep.open('wb') as se:
  p=subprocess.Popen(args,cwd=root,stdout=so,stderr=se);r['pid']=p.pid
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:p.kill();code=p.wait();r['controller_timeout_seconds']=timeout
 r.update(exit_code=code,elapsed_seconds=time.monotonic()-start,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
 for k,q in [('stdout',sp),('stderr',ep)]:
  b=q.read_bytes();r[k]={'path':q.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
  if k=='stderr' and b:print(b.decode(errors='replace')[-2000:],flush=True)
 receipts.append(r);(out/'history-preparation-commands.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps({'label':label,'exit_code':code,'elapsed_seconds':r['elapsed_seconds']}),flush=True)
 if code:sys.exit(code if code>0 else 1)
 return sp.read_bytes()
def parse(data):
 d={}
 for e in data.split(b'\0'):
  if not e:continue
  left,n=e.split(b'\t',1);mode,kind,blob=left.decode().split();assert kind=='blob' and mode in ['100644','100755'];d[n.decode()]={'mode':mode,'git_blob':blob}
 return d
h=parse(run('current-H-protected-ls-tree',['/usr/bin/git','-c','core.commitGraph=false','ls-tree','-r','-z',H,'--']+paths))
b=parse(run('original-BASE-protected-ls-tree',['/usr/bin/git','-c','core.commitGraph=false','ls-tree','-r','-z',BASE,'--']+paths))
assert set(h)==set(paths) and h==b
run('checkout-exact-current-historical-records',['/usr/bin/git','-c','core.commitGraph=false','checkout',H,'--']+paths,timeout=300)
initial=json.loads((out/'initial-domain-receipt.json').read_text());expected={x['path']:x for x in initial['entries']};rows=[]
for name in paths:
 p=root/name;data=p.read_bytes();actual={'path':name,'mode':'100755' if p.stat().st_mode&0o111 else '100644','git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 assert {k:actual[k] for k in ['mode','git_blob']}==h[name]
 if name in expected:assert expected[name]==actual
 expected[name]=actual;rows.append(actual)
receipt={'source_H':H,'original_BASE':BASE,'helper_git_blob':'f7e68c27ce4d728a2e637e34fe863f74c25d485d','protected_paths_count':236,'whitelist_sha256':'aafd155302992ec650493a57ed432d81745955c1c77f8350e0a436732dd6df09','entries':rows,'scope':'exact original helper current historical protection inputs; original relative policy retained, no non-declared holdout body; preparation not original v15 execution'}
(out/'historical-protection-inputs.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
full={'source_H':H,'product_P':initial['product_P'],'review_R':initial['review_R'],'initial_selected_count':len(initial['entries']),'protected_history_count':236,'combined_selected_count':len(expected),'entries':[expected[k] for k in sorted(expected)],'scope':'complete selected H source/validation/CI/bindings/canonicalR plus original current protected history and two original Rust compile inputs; no whole-repository or admission claim'}
data=(json.dumps(full,indent=2,sort_keys=True)+'\n').encode();(out/'complete-domain-before-v15.json').write_bytes(data)
print(json.dumps({'combined_selected_count':len(expected),'added_history_count':len(expected)-len(initial['entries']),'receipt_bytes':len(data),'receipt_sha256':hashlib.sha256(data).hexdigest(),'original_v15_not_started':True}),flush=True)
