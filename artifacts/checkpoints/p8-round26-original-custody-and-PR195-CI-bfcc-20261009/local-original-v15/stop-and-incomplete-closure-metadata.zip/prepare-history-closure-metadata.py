import pathlib,json,subprocess,os,re,hashlib,datetime
B=pathlib.Path(__file__).resolve().parent;R=B/'source';O=B/'history-closure-recovery';O.mkdir(exist_ok=False);env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0'}
def git(*args,data=None):
 p=subprocess.run(['git',*args],cwd=R,env=env,input=data,capture_output=True);assert p.returncode==0,(args,p.stderr.decode());return p.stdout
refs=set(json.loads((B/'declared-script-ref-list.json').read_text()));sources={};cat=json.loads((B/'historical-catalogues-and-objects.json').read_text())
keypat=re.compile(r'(?:^|_)(?:commit|source|ref|review|base|product|integration|integrated|capture|delivery|packing|bounded|original)(?:$|_)')
def collect(x,origin,trail=''):
 if isinstance(x,dict):
  for k,v in x.items():
   if isinstance(v,str) and re.fullmatch('[0-9a-f]{40}',v) and keypat.search(k) and not re.search('sha256|digest|blob|tree',k):sources.setdefault(v,[]).append({'record':origin,'key':trail+k})
   collect(v,origin,trail+k+'.')
 elif isinstance(x,list):
  for i,v in enumerate(x):collect(v,origin,trail+str(i)+'.')
for ref,paths in cat['catalogues'].items():
 for p in paths:
  if p.endswith('.json'):
   try:collect(json.loads(git('show',ref+':'+p)),ref+':'+p)
   except (ValueError,UnicodeError):pass
ids=sorted(refs|sources.keys());checks=git('cat-file','--batch-check',data=('\n'.join(ids)+'\n').encode()).decode().splitlines();resolved=[];missing=[];noncommit=[]
for oid,line in zip(ids,checks):
 fields=line.split()
 if len(fields)==3 and fields[1]=='commit':resolved.append(oid)
 elif fields[-1]=='missing':missing.append({'oid':oid,'declared_sources':sources.get(oid,[]),'script_literal':oid in refs})
 else:noncommit.append({'oid':oid,'type':fields[1],'declared_sources':sources.get(oid,[])})
objects={};trees=[]
for ref in resolved:
 data=git('ls-tree','-r','-z',ref,'--','crates','Cargo.toml','Cargo.lock');rows=[]
 for row in data.split(b'\0'):
  if not row:continue
  meta,path=row.split(b'\t',1);mode,kind,oid=meta.decode().split();path=path.decode();assert kind=='blob' and mode in ('100644','100755');assert not re.search('hold[-_]?out|held[-_]?out',path,re.I),path
  objects.setdefault(oid,[]).append({'source_commit':ref,'path':path,'mode':mode});rows.append({'path':path,'mode':mode,'oid':oid})
 trees.append({'ref':ref,'paths':len(rows),'metadata_sha256':hashlib.sha256(data).hexdigest()})
objids=sorted(objects);stat=git('cat-file','--batch-check',data=('\n'.join(objids)+'\n').encode()).decode().splitlines();missing_blobs=[]
for oid,line in zip(objids,stat):
 fields=line.split()
 if fields[-1]=='missing':missing_blobs.append({'git_blob':oid,'declared_product_uses':objects[oid]})
 else:assert fields[1]=='blob'
report={'schema':'original-v15-declared-history-object-closure-metadata-v1','source':'34dc4e14dc96d077eae6173ab6885370323eff3f','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_cli_attempt01_preserved_exit':1,'restoration_only_no_second_cli':True,'script_declared_refs':len(refs),'catalogue_qualified_refs':len(sources),'resolved_commits':len(resolved),'unresolved_declared_refs':missing,'noncommit_declared_values':noncommit,'unique_declared_historical_product_blobs':len(objects),'missing_blob_count':len(missing_blobs),'first_observed_missing_present_in_set':any(v['git_blob']=='9801f53a1d8785467aa495ffd3e6e545c467eb27' for v in missing_blobs),'trees':trees,'no_blob_bodies_downloaded_by_this_metadata_step':True,'holdout_body_paths_rejected':True}
(O/'closure-metadata-report.json').write_text(json.dumps(report,indent=2)+'\n');(O/'missing-product-blobs.json').write_text(json.dumps(missing_blobs,indent=2)+'\n');(O/'declared-ref-provenance.json').write_text(json.dumps(sources,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ('trees','noncommit_declared_values','unresolved_declared_refs')},indent=2));print('unresolved',len(missing),'noncommit',len(noncommit))
