def stable_00392():
    return 392
