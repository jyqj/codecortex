def stable_00342():
    return 342
