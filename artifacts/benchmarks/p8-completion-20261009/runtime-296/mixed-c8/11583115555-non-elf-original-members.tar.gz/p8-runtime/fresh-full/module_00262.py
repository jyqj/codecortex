def stable_00262():
    return 262
