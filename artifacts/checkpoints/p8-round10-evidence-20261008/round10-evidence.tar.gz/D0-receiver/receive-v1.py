#!/usr/bin/env python3
"""External transport/replay of run 37854240827; never launches measurements.

Keep all original artifact ZIPs. Reuse the exact D0 validation functions. Only
new expansion directories created below this invocation's output may be removed.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import zipfile

SOURCE = "d0cb69c601e530dcef738af0c2dffb8d3b8bcf28"
CONTROLLER = "ca72a2dde363e35203f7b3cb30ed00729d460fd7"
RUN = 37854240827
UPSTREAM_RUN = 37846370300
REGISTRATION_SHA256 = "4a56e31e9838f0db1d83a3efd4a10d0a51f8b443dbce4413e68253881740eebc"
CONTROLLER_SCRIPT_SHA256 = "a65e819d3a00f8032e04d54c8da881a6efb160671f14252e96258f57813df189"
ADMISSION_NAME = f"p8-d0-study-admission-{RUN}"
ATTEMPT = 1
SCALES = (1000, 5000, 10000, 50000, 100000)
HEADROOM = 128 * 1024**2
SDK_PATHS = ("/usr/local/lib/android", "/usr/share/dotnet")


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024**2), b""):
            h.update(block)
    return h.hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON key")
        result[key] = value
    return result


def read_json(path):
    require(Path(path).is_file() and not Path(path).is_symlink(), "nonregular JSON")
    require(Path(path).stat().st_size <= 16 * 1024**2, "transport JSON too large")
    def finite_float(value):
        result = float(value)
        require(math.isfinite(result), "nonfinite JSON")
        return result
    return json.loads(Path(path).read_bytes(), object_pairs_hook=unique_object, parse_float=finite_float,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite JSON")))


def save(path, value):
    with Path(path).open("x") as f:
        json.dump(value, f, sort_keys=True, indent=2, allow_nan=False)
        f.write("\n")


def git(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args])


def load_driver(root):
    root = Path(root).resolve(strict=True)
    require(git(root, "rev-parse", "HEAD").decode().strip() == SOURCE, "replay checkout is not exact D0")
    identities = {}
    for relative in ("scripts/p8_scale_matrix.py", "scripts/p7_build_identity.py"):
        original = git(root, "show", SOURCE + ":" + relative)
        require((root / relative).read_bytes() == original, "replay driver/helper differs from D0")
        identities[relative] = hashlib.sha256(original).hexdigest()
    sys.path.insert(0, str(root / "scripts"))
    spec = importlib.util.spec_from_file_location("p8_scale_matrix", root / "scripts/p8_scale_matrix.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules["p8_scale_matrix"] = module
    spec.loader.exec_module(module)
    observer = git(root, "show", SOURCE + ":scripts/p8_runner_capacity.py")
    return module, identities, hashlib.sha256(observer).hexdigest()


def expected_names():
    names = {ADMISSION_NAME, f"p8-scale-build-{RUN}", f"p8-scale-matrix-{RUN}"}
    names.update(f"p8-scale-{kind}-{scale}-{index}-{RUN}"
                 for kind in ("shard", "capacity") for scale in SCALES for index in range(30))
    return names


def artifact_set(inventory, archives):
    require(inventory.get("schema") == "p8-fixed-D0-scale-download-set-v1" and
            inventory.get("run_id") == RUN and inventory.get("run_attempt") == ATTEMPT and
            inventory.get("source_commit") == SOURCE and inventory.get("controller_commit") == CONTROLLER and
            inventory.get("registration_sha256") == REGISTRATION_SHA256, "wrong reception run/source/controller/registration/attempt")
    artifacts = inventory.get("artifacts", [])
    require(len(artifacts) in (302, 303), "all 302 original admission/build/shard/capacity artifacts are required")
    archives = Path(archives).resolve(strict=True)
    names, ids, paths, result = set(), set(), set(), {}
    for item in artifacts:
        name = item.get("name")
        require(name in expected_names() and name not in names, "missing/duplicate/unexpected artifact name")
        require(type(item.get("id")) is int and item["id"] > 0 and item["id"] not in ids, "duplicate/invalid artifact ID")
        require(item.get("expired") is False and item.get("workflow_run", {}).get("id") == RUN and
                item["workflow_run"].get("head_sha") == CONTROLLER, "artifact is expired or from another source/run")
        require(type(item.get("size_in_bytes")) is int and item["size_in_bytes"] > 0 and
                re.fullmatch(r"sha256:[0-9a-f]{64}", item.get("digest", "")), "missing artifact bytes/digest")
        relative = item.get("archive_path", "")
        require(isinstance(relative, str) and relative and not Path(relative).is_absolute(), "relative archive path required")
        path = archives / relative
        require(not path.is_symlink() and path.is_file(), "missing/nonregular original ZIP")
        path = path.resolve(strict=True)
        require(archives in path.parents and path not in paths, "foreign/duplicate original ZIP path")
        for ancestor in (archives / relative, *(archives / relative).parents):
            require(not ancestor.is_symlink(), "symlink in archive path")
        names.add(name)
        ids.add(item["id"])
        paths.add(path)
        result[name] = (item, path)
    required = expected_names() - {f"p8-scale-matrix-{RUN}"}
    require(required <= names <= expected_names(), "missing artifact population")
    return result


def zip_members(path, expected):
    """Read all original ZIP members and CRCs without expanding to disk."""
    require(path.stat().st_size == expected["size_in_bytes"] and
            digest(path) == expected["digest"].removeprefix("sha256:"), "original ZIP bytes/digest mismatch")
    files, directories, seen = {}, set(), set()
    with zipfile.ZipFile(path) as archive:
        for info in archive.infolist():
            name = info.filename.rstrip("/") if info.is_dir() else info.filename
            parts = PurePosixPath(name)
            require(name and not parts.is_absolute() and parts.as_posix() == name and
                    ".." not in parts.parts and "\\" not in name and "\x00" not in name,
                    "unsafe ZIP member path")
            require(name not in seen, "duplicate ZIP member")
            seen.add(name)
            mode = stat.S_IFMT(info.external_attr >> 16)
            require(mode in (0, stat.S_IFREG, stat.S_IFDIR) and not info.flag_bits & 1,
                    "nonregular/encrypted ZIP member")
            require((mode != stat.S_IFDIR or info.is_dir()) and
                    (mode != stat.S_IFREG or not info.is_dir()), "ZIP mode/path mismatch")
            if info.is_dir():
                require(info.file_size == 0, "ZIP directory has hidden payload")
                directories.add(name)
                continue
            h, size = hashlib.sha256(), 0
            with archive.open(info) as stream:
                for block in iter(lambda: stream.read(1024**2), b""):
                    size += len(block)
                    h.update(block)
            require(size == info.file_size, "ZIP member byte count mismatch")
            files[name] = {"bytes": size, "sha256": h.hexdigest()}
    require(files, "empty artifact")
    for name in files:
        require(not any(parent.as_posix() in files for parent in PurePosixPath(name).parents
                        if parent.as_posix() != "."), "ZIP file is another member's parent")
    for name in (*files, *directories):
        directories.update(parent.as_posix() for parent in PurePosixPath(name).parents
                           if parent.as_posix() != ".")
    require(not directories.intersection(files), "ZIP path is both file and directory")
    return {"files": files, "directories": sorted(directories),
            "expanded_bytes": sum(item["bytes"] for item in files.values())}


def tree_inventory(root):
    result = {}
    for path in sorted(root.rglob("*")):
        require(not path.is_symlink(), "symlink in owned expansion")
        if path.is_file():
            result[path.relative_to(root).as_posix()] = {"bytes": path.stat().st_size, "sha256": digest(path)}
        else:
            require(path.is_dir(), "nonregular owned expansion member")
    return result


class Expansions:
    def __init__(self, output):
        self.root = output / "expanded"
        self.root.mkdir()
        self.created = {}
        self.identity = (self.root.stat().st_dev, self.root.stat().st_ino)

    def extract(self, name, archive_path, expected, members):
        require(name == ADMISSION_NAME or re.fullmatch(r"p8-scale-[a-z0-9-]+", name), "unexpected expansion name")
        free = shutil.disk_usage(self.root).free
        require(free >= members["expanded_bytes"] + HEADROOM, "insufficient space for complete artifact expansion")
        path = self.root / name
        path.mkdir()
        self.created[path] = (path.stat().st_dev, path.stat().st_ino)
        with zipfile.ZipFile(archive_path) as archive:
            for name in members["directories"]:
                (path / name).mkdir(parents=True, exist_ok=True)
            for name in members["files"]:
                target = path / name
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(name) as source, target.open("xb") as dest:
                    shutil.copyfileobj(source, dest, 1024**2)
        self.prove(path, archive_path, expected, members)
        return path

    def prove(self, path, archive_path, expected, members):
        require(path in self.created and path.parent == self.root and not path.is_symlink(),
                "refusing an expansion not created by this receiver")
        require(not self.root.is_symlink() and self.root.resolve() == self.root and
                self.identity == (self.root.stat().st_dev, self.root.stat().st_ino) and
                self.created[path] == (path.stat().st_dev, path.stat().st_ino), "owned expansion identity changed")
        require(zip_members(archive_path, expected) == members, "retained ZIP changed")
        require(tree_inventory(path) == members["files"], "expanded files differ from complete retained ZIP")
        require(sorted(p.relative_to(path).as_posix() for p in path.rglob("*") if p.is_dir()) == members["directories"],
                "expanded directories differ from complete retained ZIP")

    def reclaim(self, path, archive_path, expected, members):
        self.prove(path, archive_path, expected, members)
        shutil.rmtree(path)
        del self.created[path]


def capacity_review(directory, scale, observer, matrix):
    """Check the separately retained observer receipts; no SDK commands run."""
    receipt = matrix.read_json(directory / "receipt.json")
    require(receipt.get("profile") == matrix.CAPACITY_PROFILE and receipt.get("scale") == scale and
            receipt.get("status") == "capacity_available" and receipt.get("exit_code") == 0 and
            receipt.get("artifact_state") == "sealed_after_commands_finished" and
            receipt.get("source_commit") == SOURCE and receipt.get("observer_sha256") == observer,
            "capacity receipt did not complete at D0")
    require(receipt.get("files") == matrix.inventory(directory, ("receipt.json",)), "capacity files changed after sealing")
    context = receipt.get("context", {})
    for key, value in {"GITHUB_REPOSITORY": "jyqj/codecortex", "GITHUB_RUN_ID": str(RUN),
                       "GITHUB_RUN_ATTEMPT": str(ATTEMPT), "GITHUB_JOB": "measure", "RUNNER_OS": "Linux",
                       "RUNNER_ENVIRONMENT": "github-hosted", "ImageOS": "ubuntu24", "P8_EXPECTED_SOURCE": SOURCE}.items():
        require(context.get(key) == value, "capacity context mismatch: " + key)
    require(isinstance(context.get("RUNNER_NAME"), str) and context["RUNNER_NAME"] and
            isinstance(context.get("ImageVersion"), str) and context["ImageVersion"], "capacity host/image missing")
    need = scale * 256 * 1024 + 4 * 1024**3
    require(receipt.get("required_free_bytes") == need and receipt.get("allow_preparation") is True,
            "capacity requirement/invocation changed")
    for state in (receipt.get("initial"), receipt.get("final")):
        require(isinstance(state, dict) and all(type(state.get(key)) is int and state[key] >= 0
                for key in ("total_bytes", "used_bytes", "free_bytes")), "invalid capacity disk observation")
    require(receipt["final"]["free_bytes"] >= need, "registered capacity unavailable")
    steps = receipt.get("steps")
    require(isinstance(steps, list) and len(steps) <= 2, "invalid capacity step list")
    for index, step in enumerate(steps):
        require(step.get("target") == SDK_PATHS[index] and type(step.get("existed")) is bool,
                "unregistered capacity target/order")
        if not step["existed"]:
            require("directory_size" not in step and "removal" not in step, "nonexistent SDK has command")
            continue
        for field, operation, suffix in (("directory_size", ["du", "-sx", "--block-size=1", "--", SDK_PATHS[index]], "size"),
                                         ("removal", ["rm", "-rf", "--one-file-system", "--preserve-root=all", "--", SDK_PATHS[index]], "remove")):
            command = step[field]
            label = f"sdk-{index}-{suffix}"
            require(command == matrix.read_json(directory / (label + ".command.json")), "capacity command differs from original receipt")
            require(command.get("operation") == operation and command.get("argv") ==
                    ["sudo", "-n", "timeout", "--signal=TERM", "--kill-after=5s", "300s", *operation] and
                    command.get("exit_code") == 0 and command.get("status") == "completed" and
                    command.get("cleanup_complete") is True and command.get("stdout") == label + ".stdout" and
                    command.get("stderr") == label + ".stderr", "capacity command failed/unregistered/unsealed")
            require((directory / command["stdout"]).is_file() and (directory / command["stderr"]).is_file(), "missing capacity command output")
    return {"scale": scale, "receipt_sha256": digest(directory / "receipt.json"), "context": context,
            "required_free_bytes": need, "final_free_bytes": receipt["final"]["free_bytes"], "status": "passed"}


def admission_review(directory, build, built, matrix, replay_root):
    """Replay actual admission originals; metadata receipts alone cannot pass."""
    controller = directory / "p8-d0-controller"
    observed = directory / "p8-d0-admission"
    upstream = directory / "p8-d0-upstream"
    require({p.name for p in directory.iterdir()} ==
            {"p8-d0-controller", "p8-d0-admission", "p8-d0-upstream"}, "admission top-level layout differs")
    require({p.name for p in controller.iterdir()} == {"admit.py", "registration.json", "controller-inputs.json"},
            "controller copied input set differs")
    require({p.name for p in observed.iterdir()} == {"admit.py", "registration.json", "controller-inputs.json",
            "metadata-receipt.json", "verify-receipt.json", "upstream-run.json", "upstream-jobs.json", "upstream-artifacts.json"},
            "admission original observation set differs")
    registration = read_json(controller / "registration.json")
    require(digest(controller / "registration.json") == REGISTRATION_SHA256,
            "fixed registration bytes changed")
    require(registration["source"] == SOURCE and registration["upstream_run"] == UPSTREAM_RUN and
            registration["upstream_attempt"] == ATTEMPT and registration["repository"] == "jyqj/codecortex",
            "registration source/upstream differs")
    for folder in (controller, observed):
        require(digest(folder / "registration.json") == REGISTRATION_SHA256 and
                digest(folder / "admit.py") == CONTROLLER_SCRIPT_SHA256,
                "published controller/registration copies changed")
        require(read_json(folder / "controller-inputs.json") == {
            "source_commit": CONTROLLER, "registration_sha256": REGISTRATION_SHA256,
            "script_sha256": CONTROLLER_SCRIPT_SHA256, "measured_source": SOURCE,
            "upstream_run": UPSTREAM_RUN, "new_primary_measurements_started": False},
            "controller and measured source were conflated")
    metadata = read_json(observed / "metadata-receipt.json")
    verified = read_json(observed / "verify-receipt.json")
    for record, phase, status in ((metadata, "metadata", "metadata_passed_original_successful_upstream"),
            (verified, "verify", "original_prerequisites_passed_for_new_registered_study")):
        require(record.get("phase") == phase and record.get("status") == "passed" and
                record.get("source") == SOURCE and record.get("registration_sha256") == REGISTRATION_SHA256 and
                record.get("controller_sha256") == CONTROLLER_SCRIPT_SHA256 and
                record.get("result", {}).get("status") == status and
                record["result"].get("new_measurements_performed") is False,
                "actual original admission phase did not pass")
    meta = metadata["result"]
    require(meta.get("controller_source") == CONTROLLER and meta.get("controller_run_id") == RUN and
            meta.get("measured_source") == SOURCE and meta.get("upstream_run") == UPSTREAM_RUN,
            "actual admission run/source differs")
    run = read_json(observed / "upstream-run.json")
    require(run.get("id") == UPSTREAM_RUN and run.get("head_sha") == SOURCE and
            run.get("run_attempt") == ATTEMPT and run.get("status") == "completed" and run.get("conclusion") == "success" and
            run.get("event") == "push" and run.get("head_branch") == "task/p8-prefix-window-engineering-20261009" and
            run.get("path") == ".github/workflows/p8-prefix-window-engineering.yml",
            "original upstream run was not the registered successful first attempt")
    jobs = read_json(observed / "upstream-jobs.json")
    require(jobs.get("total_count") == len(jobs.get("jobs", [])) == 3 and
            [{"id": j["id"], "name": j["name"]} for j in sorted(jobs["jobs"], key=lambda j: j["id"])] == registration["upstream_jobs"] and
            all(j.get("run_id") == UPSTREAM_RUN and j.get("head_sha") == SOURCE and
                j.get("status") == "completed" and j.get("conclusion") == "success" for j in jobs["jobs"]),
            "original upstream jobs differ or did not pass")
    artifacts = read_json(observed / "upstream-artifacts.json")
    require(artifacts.get("total_count") == len(artifacts.get("artifacts", [])) == 6 and
            len({a["id"] for a in artifacts["artifacts"]}) == 6 and
            [{"id": a["id"], "name": a["name"], "bytes": a["size_in_bytes"], "sha256": a["digest"].removeprefix("sha256:")}
             for a in sorted(artifacts["artifacts"], key=lambda a: a["id"])] == registration["upstream_artifacts"] and
            all(a.get("expired") is False and a.get("workflow_run", {}).get("id") == UPSTREAM_RUN and
                a["workflow_run"].get("head_sha") == SOURCE for a in artifacts["artifacts"]),
            "six original upstream artifacts differ")
    require({p.name for p in upstream.iterdir()} == {a["name"] for a in registration["upstream_artifacts"]
            if a["id"] != registration["build"]["artifact_id"]}, "upstream original bundle set differs")
    snapshot = matrix.source_snapshot(replay_root)
    require(snapshot["source_commit"] == SOURCE and snapshot["source_tree"] == registration["source_tree"] and
            snapshot["input_count"] == 1087 and snapshot["inputs"] == registration["complete_source_inputs"] and
            snapshot["manifest_sha256"] == registration["source_manifest_sha256"] and
            matrix.driver_snapshot(replay_root)["inputs"] == registration["scale_observer_inputs"],
            "current complete D0 source/observer inputs differ")
    build_sha = digest(build / "build.json")
    require(build_sha == registration["build"]["receipt_sha256"] and
            built["binary_sha256"] == registration["build"]["binary_sha256"] and
            built["binary_blake3"] == registration["build"]["binary_blake3"], "registered original build changed")
    # validate_build has already checked the original six-member Cargo/copy seal.
    require(set(matrix.inventory(build)) == {"build.json", "cargo.jsonl", "cargo.stderr", "p8-scale",
            "source-before.json", "source-after.json"}, "original build member set changed")
    control = upstream / registration["controls"]["artifact_name"]
    controls = read_json(control / "receipt.json")
    require(digest(control / "receipt.json") == registration["controls"]["receipt_sha256"] and
            controls["files"] == matrix.inventory(control, ("receipt.json",)), "original control receipt/files changed")
    commands = registration["controls"]["commands"]
    require(len(commands) == 12 and controls["commands"] == commands and
            [r["argv"] for r in controls["results"]] == commands and all(r["exit_code"] == 0 for r in controls["results"]) and
            controls["status"] == "commands_completed" and controls["exit_code"] == 0 and
            controls["source_unchanged"] is True and controls["not_run_command_indices"] == [] and
            read_json(control / "source-before.json") == read_json(control / "source-after.json") == snapshot,
            "original twelve controls/source did not pass")
    diagnostics = []
    for item in registration["diagnostics"]:
        raw = upstream / item["artifact_name"]
        require(digest(raw / "shard.json") == item["receipt_sha256"], "original diagnostic receipt changed")
        value = matrix.validate_shard(raw, built, build / "p8-scale", build_sha)
        require(matrix.exact_equal(value["plan"], matrix.registered_plan(item["scale"], 0, 30, 30, 12648430,
                18000000, matrix.CAPACITY_PROFILE)), "original diagnostic plan differs")
        diagnostics.append({"scale": item["scale"], "receipt_sha256": item["receipt_sha256"],
                            "original_full_raw_validation_passed": True})
    require([d["scale"] for d in diagnostics] == [1000, 10000] and diagnostics == verified["result"]["diagnostics"] and
            verified["result"].get("source") == SOURCE and verified["result"].get("original_validate_build_passed") is True and
            verified["result"].get("original_controls") == 12 and verified["result"].get("new_primary_cells") == 150,
            "actual admission verify result differs from original raw replay")
    plans = [{"scale": scale, "shard_index": index, "plan": matrix.registered_plan(scale, index, 30, 30,
             12648430, 18000000, matrix.CAPACITY_PROFILE)} for scale in reversed(SCALES) for index in range(30)]
    require(matrix.exact_equal(plans, registration["primary_cells"]), "fixed complete150 original plans differ")
    require(matrix.source_snapshot(replay_root) == snapshot, "source changed during prerequisite replay")
    return {"status": "actual_admission_and_original_prerequisites_passed", "metadata_receipt_sha256": digest(observed / "metadata-receipt.json"),
            "verify_receipt_sha256": digest(observed / "verify-receipt.json"), "registration_sha256": REGISTRATION_SHA256,
            "original_controls": 12, "diagnostics": diagnostics, "diagnostics_not_new_primary_samples": True}, registration


def comparable_matrix(value):
    """Only actual local-vs-runner expansion path strings are transport-local."""
    value = json.loads(json.dumps(value))
    for item in value.get("evidence", []):
        item.pop("directory", None)
    return value


def replay(args):
    output = Path(args.output).absolute()
    require(output.parent.resolve(strict=True) == output.parent, "output parent must not use a symlink/alias")
    require(not output.exists() and not output.is_symlink(), "output must be new")
    output.mkdir()
    report = {"status": "failed", "passed": False, "source_commit": SOURCE, "run_id": RUN,
              "run_attempt": ATTEMPT, "controller_commit": CONTROLLER, "registration_sha256": REGISTRATION_SHA256,
              "scope": "original ZIP transport and original D0 validators only",
              "release_certification": "not_run", "native_measurements_launched": False, "artifacts": []}
    try:
        matrix, identities, observer = load_driver(args.replay_root)
        inventory = read_json(args.inventory)
        originals = artifact_set(inventory, args.archives)
        aggregate_job = inventory.get("aggregate_job")
        require(isinstance(aggregate_job, dict) and aggregate_job.get("name") == "aggregate" and
                aggregate_job.get("run_id") == RUN and aggregate_job.get("head_sha") == CONTROLLER and
                type(aggregate_job.get("id")) is int and aggregate_job["id"] > 0 and
                aggregate_job.get("status") in ("queued", "in_progress", "completed"),
                "missing original aggregate job observation")
        report["original_aggregate_job"] = aggregate_job
        report["actions_all_green"] = "not_claimed"
        report.update(replay_source=identities, inventory_sha256=digest(args.inventory), receiver_sha256=digest(__file__))
        members = {name: zip_members(path, item) for name, (item, path) in originals.items()}
        save(output / "zip-members.json", members)
        build_name = f"p8-scale-build-{RUN}"
        required = members[build_name]["expanded_bytes"] + max(v["expanded_bytes"] for k, v in members.items() if k != build_name) + HEADROOM
        free = shutil.disk_usage(output).free
        report["replay_disk_admission"] = {"available_bytes": free, "required_additional_bytes": required,
                                           "all_original_zips_already_present": True, "operational_headroom_bytes": HEADROOM}
        require(free >= required, "insufficient free space for original build plus largest complete artifact")
        expanded = Expansions(output)
        item, archive = originals[build_name]
        build = expanded.extract(build_name, archive, item, members[build_name])
        (build / "p8-scale").chmod(0o755)
        built, binary = matrix.validate_build(build)
        build_sha = matrix.file_sha256(build / "build.json")
        admission_item, admission_archive = originals[ADMISSION_NAME]
        admission_directory = expanded.extract(ADMISSION_NAME, admission_archive, admission_item, members[ADMISSION_NAME])
        admission_result, registration = admission_review(admission_directory, build, built, matrix, args.replay_root)
        report["admission"] = admission_result
        save(output / "registration.json", registration)
        registered_plans = {(item["scale"], item["shard_index"]): item["plan"] for item in registration["primary_cells"]}
        expanded.reclaim(admission_directory, admission_archive, admission_item, members[ADMISSION_NAME])
        report["artifacts"].append({"artifact_id": admission_item["id"], "name": ADMISSION_NAME,
            "zip_sha256": admission_item["digest"], "zip_bytes": admission_item["size_in_bytes"],
            "archive_path": str(admission_archive), "complete_original_zip_verified_before_reclaim": True})
        records, capacity, remote = [], [], None
        for name in sorted(originals):
            if name in (build_name, ADMISSION_NAME):
                continue
            item, archive = originals[name]
            directory = expanded.extract(name, archive, item, members[name])
            evidence = {"artifact_id": item["id"], "name": name, "zip_sha256": item["digest"],
                        "zip_bytes": item["size_in_bytes"], "archive_path": str(archive), "extraction_directory": str(directory)}
            if name.startswith("p8-scale-capacity-"):
                scale, index = map(int, name.removeprefix("p8-scale-capacity-").removesuffix(f"-{RUN}").split("-"))
                value = capacity_review(directory, scale, observer, matrix)
                capacity.append({"shard_index": index, **value})
                evidence["receipt_sha256"] = value["receipt_sha256"]
            elif name.startswith("p8-scale-shard-"):
                value = matrix.validate_shard(directory, built, binary, build_sha)
                scale, index = map(int, name.removeprefix("p8-scale-shard-").removesuffix(f"-{RUN}").split("-"))
                require(value["plan"]["files"] == [scale] and value["plan"]["shard"]["index"] == index,
                        "artifact name differs from original shard identity")
                require(matrix.exact_equal(value["plan"], registered_plans[(scale, index)]),
                        "new primary shard differs from the fixed original registration plan")
                records.append(value)
                evidence["receipt_sha256"] = value["receipt_sha256"]
            else:
                require(set(members[name]["files"]) == {"matrix.json"}, "unexpected aggregate artifact files")
                remote = matrix.read_json(directory / "matrix.json")
            expanded.reclaim(directory, archive, item, members[name])
            evidence["complete_original_zip_verified_before_reclaim"] = True
            report["artifacts"].append(evidence)
        require(len(records) == len(capacity) == 150, "incomplete original artifact population")
        result = matrix.combine(records, repetitions=30, shard_count=30, capacity_profile=matrix.CAPACITY_PROFILE)
        result.update(build_receipt_sha256=build_sha, replay_driver_sha256=matrix.file_sha256(matrix.__file__), driver_source=built["driver_source"])
        if remote is None:
            report["remote_aggregate"] = {"status": "artifact_not_generated", "original_job": aggregate_job}
        elif remote.get("passed") is True:
            require(comparable_matrix(remote) == comparable_matrix(result),
                    "successful remote aggregate differs from full local original-raw replay")
            report["remote_aggregate"] = {"status": "passed_and_equal_except_expansion_paths", "original_result": remote}
        else:
            require(remote.get("schema") == matrix.SCHEMA and remote.get("passed") is False and
                    remote.get("status") == "failed", "unrecognized unsuccessful remote matrix result")
            report["remote_aggregate"] = {"status": "original_failure_preserved", "original_result": remote}
        for name, (item, archive) in originals.items():
            require(zip_members(archive, item) == members[name], "original ZIP changed before final sealing")
        _, after, after_observer = load_driver(args.replay_root)
        require(after == identities and after_observer == observer, "replay source changed")
        require(matrix.validate_build(build)[0] == built, "retained build changed")
        snapshot_after = matrix.source_snapshot(args.replay_root)
        require(snapshot_after["source_commit"] == SOURCE and snapshot_after["source_tree"] == registration["source_tree"] and
                snapshot_after["inputs"] == registration["complete_source_inputs"], "complete D0 source changed before final seal")
        save(output / "matrix.json", result)
        save(output / "capacity-review.json", capacity)
        item, archive = originals[build_name]
        expanded.reclaim(build, archive, item, members[build_name])
        report["artifacts"].append({"artifact_id": item["id"], "name": build_name, "zip_sha256": item["digest"],
                                    "zip_bytes": item["size_in_bytes"], "archive_path": str(archive),
                                    "receipt_sha256": build_sha, "complete_original_zip_verified_before_reclaim": True})
        report.update(status="complete_measurement_coverage", passed=True, sample_count=result["sample_count"],
                      capacity_receipts=150, original_zips=len(originals))
    except Exception as error:
        report["error"] = f"{type(error).__name__}: {error}"
    save(output / "reception.json", report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inventory", type=Path, required=True)
    parser.add_argument("--archives", type=Path, required=True)
    parser.add_argument("--replay-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    result = replay(parser.parse_args())
    print(json.dumps({key: result.get(key) for key in ("status", "passed", "error", "sample_count")}, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
