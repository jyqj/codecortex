def stable_00413():
    return 413
