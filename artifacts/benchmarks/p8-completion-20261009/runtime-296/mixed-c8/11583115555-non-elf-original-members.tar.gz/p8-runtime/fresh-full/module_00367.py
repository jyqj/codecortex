def stable_00367():
    return 367
