def stable_00134():
    return 134
