这是新独立 `scale_capacity_v1` 研究的操作清单，不是启动记录或验收结果。当前仍为 163 done / 29 未完成。旧 Gc8、C3ff 的失败和 4/150、41/1500 保持原身份；G7B 准备暂停不影响这些记录。

1. 完成最终产品 P、非作者 R 和原四 pin 的 G 绑定，保留完整源码与验证输入映射。选择最终实际 PR head 的完整 SHA；如使用只增证据的合法合流提交，以真实被执行的提交为研究来源。原 CI 与研究可以并行；原工作流没有要求额外在本机先跑一遍 181 项或 v15，也没有要求先执行额外 smoke。CI 中的原源完整性、v15、编译与相关回归仍必须真实通过，不能用静态 R 代替。

2. 用当前可用的原标签事件启动一次新研究。先读取最终 PR head，确认等于选定 SHA。若 `p8-scale-run` 已存在，先删除再添加一次：删除是 `unlabeled`，不在原触发事件中；添加是 `labeled`，满足原 build 条件。API 操作是 `DELETE /repos/jyqj/codecortex/issues/{pr}/labels/p8-scale-run`，随后 `POST /repos/jyqj/codecortex/issues/{pr}/labels`，body 为 `{"labels":["p8-scale-run"]}`。这两项只列供 root 执行，本报告没有调用。不要调用旧 run 的 rerun，也不要重用旧 artifact 名下的样本。`synchronize` 本身不会触发 scale。

3. 添加标签后核对实际新 run/event 的源和构建收据。四个 job 都明确 checkout `${{ github.event.pull_request.head.sha || github.sha }}`，因此同一次 labeled 事件固定其当时的 PR head；后续 PR 前进不会让原 job 改成新 head。若删除/添加之间 PR 被他人推进，以事件实际 SHA 为准，不把另一个来源的运行标成预定来源。构建、每片和聚合均核同一 source、driver/helper、实际 release 二进制；不能重标旧 receipt。

4. 让原工作流自行完成：一次 release build → 五容量各 shard 0 → 若五片全部成功则其余 145 片 → aggregate。首五片就是原 repetition 0，不是额外预检。不要另 dispatch/另打标签复制同一研究。一次构建 + 150 测量 job + 一次聚合，共 152 个逻辑 job；失败可能使后续 job skipped，不能把实际 materialized 数当完成分母。

5. 保留 build、capacity、shard、matrix 的原产物与实际 exit，不论成功失败。原输出名称含新的 `run_id`，但不含 `run_attempt`，所以独立新 run 更适合明确保留这次新研究身份。原 build 的 Cargo 命令为 `cargo build --release --locked -p cc-eval --bin p8-scale --message-format=json --target-dir <原目标>`；这是工作流自行执行的构建，不需要另造本地构建。原 per-shard 参数是 `--repetitions 30 --shard-count 30 --capacity-profile scale_capacity_v1`，seed 默认固定 12648430。五规模是 1k/5k/10k/50k/100k，九主阶段是 cold/no-op/body/API/config/batch1/10/100/1000；1k 的三十片另负责 fanout1/4/16/64/128 各三十次。

6. 原 aggregate 必须真实 exit 0，`matrix.json.passed=true`、`status=complete_measurement_coverage`、`sample_count=1500`；全部 150 唯一片、五十组各三十个全局 repetition 齐全。它逐条重验原 raw、全部闭包完成后的十五表 parity、输入/操作正文、独立配置见证、fanout 手写真值、所有 build 和失败/截断状态。它已执行这些检查，不需要为了形式在第二台机器再运行同一 aggregate；独立验收可以核原实际结果、完整性及范围。若做接收端复核，必须使用同源原 driver/helper/ELF，不改归因。

7. 对 005/006 原条款逐项验收，再按原硬依赖顺序验收其余八项。1500 样本的通过只证明注册覆盖/正确性与所记录分层统计，不自动成为因果提速、稳定尾延迟、进程树内存峰值或 G8/release 认证。容量协议明确按 host/CPU/kernel 分层，不混算异构 host 均值；`strict_paired_causal_performance=not_established` 和 `whole_tree_memory_peak=unknown` 不能凭 aggregate 改成通过。既有 Gc8 运行、G2 四 C 实际 DB acquisition wait 等组件保留各自 source；可以作为各自原任务组件证据，不拼进新 scale cohort，也不重标新代码已实测。

8. 只有条款、相关旧回归及硬依赖都满足后，基于届时 fresh main 的台账追加结果并派生视图；不覆盖外部已添加 notes/evidence。十项都验收时才变为 173 done / 19 未完成。P7-018、P8-014/015 的条件授权范围不因这次合成研究而启用，P8-020/G8/release 也不自动通过。

| 原要求 | 本次保持的具体值或条件 |
|---|---|
| 主闭包 | dirty 200 / resume 1024；完整 closure 与每阶段 full parity |
| 专门 fanout 压力 | dirty 8 / resume 128；必须实际观察至少一次首 build 未闭合并最终完成 |
| 每片预算 | native 18,000,000 ms；证据 512 MiB；workflow 350 min 不替代 native 预算 |
| oracle | 两侧十五表累计 16 GiB、scratch 8 GiB、cache 2 MiB、每侧每表 5m 行、每行 1 MiB |
| 资源准备 | 原 disposable hosted VM capacity preparation；不足记录 not_run/非零，不修改预算或清理共享宿主 |
| 来源 | 实际固定完整 SHA、同一编译 ELF、原 driver/helper、toolchain/profile/features/seed/input/runtime 一致 |
| 输出 | 原始记录全保留；新 run 不覆盖历史失败；摘要由 raw 得出 |

真正需要更新的文件和字段如下。这里没有修改其中任何一件。

| 文件 | 成功后必要变动 |
|---|---|
| `docs/roadmap/code-index-v2/tasks.json` | 对原十个 ID 的 `status` 改 `done`；`evidence[]` 追加各自精确源、原 run/artifact、验收报告定位；`implementation_notes` 追加有限结论及历史失败边界，不改 steps/acceptance/depends_on/validations |
| 同一台账 `P8-005.acceptance_subgates.full_1k_5k_10k_50k_100k_scale_acceptance` | 从 `open` 更新为与既有枚举口径一致的 `closed_declared_local_scope`，明确只为完整规模覆盖；既有三个 once/local 子门及未建立因果/未知峰值字段保持实际结论 |
| 同一台账顶层 | `last_implementation_date` 写实际落账日期；`current_phase` 保持 P8，`status` 仍 in_progress；十项都关后 `next_task` 可选硬依赖已完成且非条件任务 P8-017。`execution_note` 如需新轮概述只追加，`task_count=192`、phase counts 和定义不变 |
| `docs/roadmap/code-index-v2/05-TODO.md` | 用原生成器全量派生，不手工维护第二份状态 |
| 根 `README.md`、roadmap `README.md`、roadmap `08-HANDOFF.md` | 仅原 `code-index-progress` 标记块由同一生成器派生，保留块外内容 |

原生成命令是 `python3 scripts/code_index_plan.py --write`，再无参运行 `python3 scripts/code_index_plan.py` 检查全部四个视图和硬依赖；这两条尚未执行。无需为销项改 `06-VALIDATION.md`、`09-BENCHMARK.md`、协议、N 或 thresholds。

| 任务 | 完成顺序与已有组件边界 |
|---|---|
| P8-005 | 新完整五容量研究 + 原计数/范围/相关回归；P8-004 已 done |
| P8-006 | 新全部增量阶段、完整闭包/full parity 与 fanout 曲线；005 和原 P7-020/P8-001 依赖先 done |
| P8-007 | 006 后；原 mixed/backfill 加 G2 完整四 C acquisition-wait 组件。无需再补 G1 Mac C8/C16 来替代已接受四 C |
| P8-008 | 007 后；已接受生命周期分层、全样本 N/分布/CI，保留实际旧源 |
| P8-009 | 008 后；已接受资源/费用归属及合法 unavailable，不外推 scale 未采到的峰值 |
| P8-010 | 009 后；已接受一小时真实 soak、终点对账和增长边界 |
| P8-011 | 007/010/P7-020 后；已接受恢复原组件及其来源 |
| P8-012 | 011 后；已接受八格真实冷构建与原 collector，不以缓存工程测试替代 |
| P8-013 | 012 后；已接受原故障注入、实际非零退出和 raw 保留 |
| P8-016 | 012/013/P7-020 后；已接受旧 binary/schema/cache/disable 回滚组件 |

普通工程 PR 的合并边界与研究销项分开：原普通 CI 的格式、Clippy、编译/适用回归、源完整性及 v15 等实际检查和相关正确性必须成立；硬正确性失败不能被吞吐抵消。`07-ROLLOUT` 明确 100k 属 nightly/release，不在普通 PR 强跑；scale 工作流仅标签/dispatch，普通 synchronize 没有新的 150 片前置。研究失败可以与一个范围清楚的工程 PR 合并并存，条件是继续保留失败、未完成任务和未认证发布范围。此报告没有重新读取当前仓库 protection/review 状态，也不自动批准 merge。

以下均不是新研究的附加硬门：单独再跑本机 181/v15、固定 Docker/Mac 平台、先额外 smoke、小对照必须每个负例都更快、再跑已接受所有八组件、每个 docs/artifact 提交重开完整 cohort、所有工程 PR 必须等 150 片后才合并、为了打包而制作大 canonical/多层 ZIP。既有 source 审查、相关回归与原研究记录仍需真实满足；这些不能反向用于声称失败/partial 已通过。

依据：原 `P8-SCALE.md` 141–156、184–197、212–234、250–281；`09-BENCHMARK.md` §8–11；`06-VALIDATION.md` V20/V21、G8 和硬失败；`07-ROLLOUT.md` 风险表“100k 测试挤爆开发机”；原 tasks 各字段；当前 G6 的 `p8-scale.yml`、`p8_scale_matrix.py`、`code_index_plan.py`。精确来源字节与本次只读证明范围见配套 JSON。
