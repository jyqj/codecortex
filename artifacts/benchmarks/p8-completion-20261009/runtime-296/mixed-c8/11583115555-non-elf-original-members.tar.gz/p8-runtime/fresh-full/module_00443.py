def stable_00443():
    return 443
