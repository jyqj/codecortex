"""Summarize already received original prefix; no original predicate execution.

This preserves selected original event lines and all point-in-time metadata.
The full input event/raw chunk remains in the unchanged Root-owned original ZIP.
"""
import collections
import datetime
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'round33-diagnostic-checkpoint-00-intake/attempt01'
BUILD = ROOT / 'round33-PR200-build-capacity-original-intake/attempt01'
BINDING = ROOT / 'round32-100k-diagnostic-intake-bound-9cc6-run38012409915/binding.json'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def identity(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}

def write(path, value):
    with path.open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

reader = json.loads((OUT / 'reader/report.json').read_text())
receipt = json.loads((OUT / 'reader.execution.json').read_text())
assert receipt['exit_code'] == 0 and receipt['validate_build_calls'] == receipt['ELF_calls'] == 0
binding = json.loads(BINDING.read_text())
built = json.loads((BUILD / 'original-validate-build-result.json').read_text())['original_build_record']
build_receipt = identity(BUILD / 'extracted/build/build.json')
artifact = reader['artifacts'][0]
assert artifact['id'] == '11655358015' and len(reader['artifacts']) == 1
selected = OUT / 'selected-originals'
selected.mkdir(exist_ok=False)
with zipfile.ZipFile(artifact['zip_path']) as archive:
    manifest_bytes = archive.read('manifest.json')
    manifest = json.loads(manifest_bytes)
    (selected / 'manifest.json').write_bytes(manifest_bytes)
    for item in manifest['metadata_snapshots']:
        raw = archive.read(item['file'])
        assert sha(raw) == item['sha256'] and len(raw) == item['bytes']
        (selected / item['file']).write_bytes(raw)
    config = json.loads((selected / 'configuration.json.snapshot').read_text())
    assert config['original_build_receipt_sha256'] == build_receipt['sha256']
    assert config['original_driver_sha256'] == built['driver_sha256']
    chunks = reader['streams']['shard/native/raw.jsonl']['chunks']
    # This actual artifact contains one contiguous raw interval. No future case is generalized from it.
    assert len(chunks) == 1 and chunks[0]['start'] == 0
    chunk = chunks[0]
    raw = archive.read(chunk['retained_locations'][0]['member'])
    assert sha(raw) == chunk['sha256'] and len(raw) == chunk['bytes']

lines = raw.splitlines(keepends=True)
events, line_records, malformed_complete_lines = [], [], []
offset = 0
for index, line in enumerate(lines):
    record = {'line_index_zero_based': index, 'start': offset, 'end': offset + len(line),
              'bytes': len(line), 'sha256': sha(line), 'complete_newline': line.endswith(b'\n')}
    offset += len(line)
    if not record['complete_newline']:
        record['status'] = 'retained_partial_tail_not_parsed_as_complete_event'
        line_records.append(record)
        continue
    try:
        event = json.loads(line)
    except (ValueError, UnicodeError) as error:
        record['status'] = 'complete_line_parse_error'
        record['error'] = str(error)
        malformed_complete_lines.append(record)
        line_records.append(record)
        continue
    events.append(event)
    record.update(event=event.get('event'), label=event.get('label'))
    if event.get('event') != 'input':
        path = selected / ('raw-event-%04d.jsonl' % index)
        path.write_bytes(line)
        record['selected_original_file'] = str(path)
    else:
        record['selected_original_file'] = None
        record['custody'] = 'Full unchanged input event retained in original ZIP raw chunk; not duplicated into small support.'
    line_records.append(record)
run_started = next(x for x in events if x.get('event') == 'run_started')
assert run_started['engine']['binary_digest'] == built['binary_blake3']
assert run_started['engine']['engine_head_observed'] == binding['G']
assert run_started['plan'] == binding['plan']
finished = [x for x in events if x.get('event') == 'build_finished']
started = [x for x in events if x.get('event') == 'build_started']
unfinished = [x for x in started if x['label'] not in {y['label'] for y in finished}]
last_finished = finished[-1] if finished else None
phase = {key: last_finished['report'].get(key) for key in (
    'elapsed_ms', 'phase_timing', 'build_timing', 'dirty_plan', 'resolution_freshness',
    'files_scanned', 'files_added', 'files_updated', 'files_removed', 'files_skipped',
    'files_parsed', 'symbols_total', 'chunks_total', 'parse_errors')} if last_finished else None
review = {
    'schema': 'original-diagnostic-checkpoint-prefix-review-v1',
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'First custody intake of checkpoint00 and readonly interpretation of emitted complete event lines. Not inspect_raw/validate_shard or stage acceptance.',
    'source': binding['G'], 'run': binding['run_id'], 'attempt': binding['run_attempt'],
    'binding': identity(BINDING), 'original_artifact': artifact,
    'frozen_reader_execution': identity(OUT / 'reader.execution.json'), 'reader_actual_exit_code': 0,
    'reused_build': {'accepted_result': identity(BUILD / 'original-validate-build-result.json'),
                     'receipt': build_receipt,
                     'configuration_build_receipt_sha256': config['original_build_receipt_sha256'],
                     'raw_engine_binary_digest_matches_accepted_build': True,
                     'new_build_validation_calls': 0, 'new_ELF_calls': 0},
    'verified_prefixes': {name: {'start': 0, 'end_exclusive': value['verified_retained_contiguous_chunk_prefix_bytes'],
                                'declared_highest_offset': value['highest_declared_offset'],
                                'unknown_tail_bytes': None, 'EOF_claimed': False}
                          for name, value in reader['streams'].items()},
    'original_prior_upload_ACKs': manifest['acknowledged_uploads_before_this_upload'],
    'ACK_boundary': 'Checkpoint00 was frozen before its own upload. Prior ACK list is empty. Official retained artifact/whole ZIP digest establishes its custody without requiring a later local ACK.',
    'observer_before_seen_and_bound': reader['observer_before_seen'],
    'observer_after_seen': reader['observer_after_seen'], 'capture_faults_in_this_checkpoint': reader['capture_faults'],
    'metadata_parse_unknown': reader['metadata_parse_unknown'],
    'raw_prefix': {'chunk': chunk, 'bytes': len(raw), 'ends_in_newline': raw.endswith(b'\n'),
                   'line_count': len(lines), 'complete_event_counts': dict(collections.Counter(x.get('event') for x in events)),
                   'malformed_complete_lines': malformed_complete_lines,
                   'partial_tail_bytes': 0 if not lines or lines[-1].endswith(b'\n') else len(lines[-1]),
                   'original_line_intervals': line_records,
                   'boundary': 'Trailing newline means this retained prefix ends on an emitted record boundary; it does not mean file EOF or a terminal native result.'},
    'last_finished_build': {'label': last_finished['label'], 'full': last_finished['full'],
                            'start_us': last_finished['start_us'], 'end_us': last_finished['end_us'],
                            'outer_wall_us': last_finished['wall_us'], 'original_report_fields': phase,
                            'original_process_snapshot': last_finished['process_snapshot']} if last_finished else None,
    'started_but_not_finished_in_prefix': unfinished,
    'original_run_engine': run_started['engine'],
    'engine_dirty_boundary': 'Original engine records an untracked scripts/__pycache__/p7_build_identity.cpython-312.pyc. Preserve that observation; the original typed product/driver source maps remain separately bound. Do not relabel it as clean.',
    'completed_parity_events': sum(x.get('event') in ('cold_parity', 'stage_finished') for x in events),
    'native_report_seen': bool(reader['native_reports']), 'supervisor_terminal_seen': bool(reader['supervisor_receipts']),
    'reported_native_outcome': reader['reported_native_outcome'],
    'custody_status': reader['custody_status'],
    'timing_boundary': 'full_staging is nested within prepare; phase and build timers overlap. No speedup estimate or cause attribution from a single current full build.',
    'new_original_predicate_calls': {'validate_build': 0, 'validate_shard': 0, 'inspect_raw': 0},
    'accepted_cohort_shards': 0, 'accepted_cohort_samples': 0, 'task_completion_credit': 0,
    'full_cohort_separation': 'New full wide cohort run38013753078 is a different run/binary population; no diagnostic event or byte is pooled into it.'
}
write(OUT / 'checkpoint-prefix-review.json', review)
print(json.dumps({'review': identity(OUT / 'checkpoint-prefix-review.json'),
                  'complete_events': len(events), 'prefix_bytes': len(raw),
                  'native_outcome': reader['reported_native_outcome'], 'cohort_samples': 0}))
