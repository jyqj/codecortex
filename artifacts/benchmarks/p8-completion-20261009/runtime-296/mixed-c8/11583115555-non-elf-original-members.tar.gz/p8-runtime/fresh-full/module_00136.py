def stable_00136():
    return 136
