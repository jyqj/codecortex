import hashlib
import json
from pathlib import Path
import subprocess

out = Path(__file__).resolve().parent
root = out.parent / 'codecortex-runtime-followup-sparse'
def git(*args): return subprocess.check_output(['git', '-C', str(root), *args])
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
commit = 'd0fe84a3e3f556c4f5907cc62190b20902a9f84d'
parent = 'd5d4d570d97b59cda29a55251db875235ff6e507'
assert git('rev-parse', 'HEAD').decode().strip() == commit
assert not git('status', '--porcelain', '--untracked-files=all')
assert git('show', parent + ':scripts/p8_cold_build.py') == git('show', 'bb9a96d71622458c39a143055360cc97f0d11d78:scripts/p8_cold_build.py')
assert not git('diff', parent, commit, '--', 'scripts/p8_runtime.py', 'scripts/tests/test_p8_runtime.py')
assert 'Ran 58 tests in 31.173s\n\nOK' in (out / 'platform-final.stderr').read_text()
assert list((out / 'red-empty-output').iterdir()) == []
failure = json.loads((out / 'green-empty-output/matrix.json').read_text())
assert failure['status'] == 'invalid' and failure['counts'] is None and failure['expected_cell_count'] == 8
assert failure['requested_commit'] == commit and 'cells' not in failure
assert 'received 0' in failure['error']
names = ['scripts/p8_cold_build.py', 'scripts/tests/test_p8_platform.py']
assert git('diff-tree', '--no-commit-id', '--name-only', '-r', commit).decode().splitlines() == names
report = {
    'schema_version': 1, 'status': 'passed_scoped_python_controls',
    'source_commit': commit, 'parent_commit': parent,
    'changed_files': {name: {'bytes': (root / name).stat().st_size, 'sha256': sha(root / name)} for name in names},
    'scope': 'Retain failed strict platform collection receipt in this invocation newly owned output directory only',
    'runtime_fix_files_unchanged': True,
    'old_real_cli': {'source_commit': parent, 'cold_bytes_equal_published_G': True,
                     'input': 'red-empty-input', 'output': 'red-empty-output', 'exit_code': 2,
                     'output_file_count': 0, 'stderr': 'red-empty.stderr', 'stdout': 'red-empty.stdout'},
    'fixed_real_cli': {'source_commit': commit, 'input': 'red-empty-input', 'output': 'green-empty-output',
                       'exit_code': 2, 'status': 'invalid', 'counts': None,
                       'expected_cell_count': 8, 'stderr': 'green-empty.stderr', 'stdout': 'green-empty.stdout'},
    'checks': [{'argv': ['python', '-B', '-m', 'unittest', 'test_p8_platform', 'test_p8_platform_independent_review', '-v'],
                'exit_code': 0, 'tests': 58, 'failed': 0, 'errors': 0, 'skipped': 0,
                'seconds': 31.173, 'stdout': 'platform-final.stdout', 'stderr': 'platform-final.stderr'},
               {'scope': 'New controls on original code', 'exit_code': 1,
                'tests': 3, 'errors': 2, 'passed': 1,
                'stderr': 'red-controls.stderr', 'stdout': 'red-controls.stdout'},
               {'argv': ['git', 'diff', '--check'], 'exit_code': 0}],
    'controls': ['Complete eight synthetic cells produce the exact unchanged original success record through main',
                 'Empty collection and malformed JSON return exit 2 with invalid failure receipt',
                 'Existing output directory and final symlink are unchanged and receive no new files',
                 'Original portable source/compiler/profile/stdio/eight-cell controls remain enabled'],
    'limitations': ['Synthetic compiler/RPC fixtures are protocol controls, not product execution',
                    'Failure receipt counts remain unknown; no inference about producer execution or partial cell validity',
                    'No Cargo compilation, new platform measurement, TODO closure or new SOURCE approval claimed'],
    'superseded_local_trial': {'stderr': 'platform-green.stderr', 'tests': 58, 'exit_code': 0,
        'note': 'Earlier uncommitted receipt draft used not_run counts; review corrected them to unknown. Only platform-final is final code.'},
    'inventory': {p.relative_to(out).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p)}
                  for p in sorted(out.rglob('*')) if p.is_file() and p.name != 'validation-receipt.json'},
}
(out / 'validation-receipt.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps({'receipt': str(out / 'validation-receipt.json'), 'sha256': sha(out / 'validation-receipt.json')}))
