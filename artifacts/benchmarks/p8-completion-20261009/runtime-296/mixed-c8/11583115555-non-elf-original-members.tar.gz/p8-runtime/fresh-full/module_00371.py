def stable_00371():
    return 371
