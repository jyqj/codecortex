#!/usr/bin/env python3
"""Read-only fixed-byte applicability analysis; no product or test execution."""
from pathlib import Path
import hashlib,json,difflib,stat,datetime,shutil
ROOT=Path(__file__).resolve().parent
def digest(b):return hashlib.sha256(b).hexdigest()
def oid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def meta(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':digest(b),'git_blob':oid(b)}
def obj(k):return json.loads(json.loads((ROOT/'official-responses'/f'{k}.json').read_text())['structuredContent']['content'])
def write(n,d):(ROOT/n).write_text(json.dumps(d,indent=2,sort_keys=True,ensure_ascii=False)+'\n')
src=ROOT/'source';old=(src/'b2-p7_crash_preparation.rs').read_bytes();new=(src/'candidate-p7_crash_preparation.rs').read_bytes();cur=(src/'M7F-p7_crash_preparation.rs').read_bytes()
assert old==cur and oid(old)=='6493cbe6c291bc4622cf93cdb566f68e6e215155'
assert oid(new)=='97ce7a96471cabc0943a1f5ecf9d2a62bde40d12'
old_body='''fn signal_and_wait(root: &Path) -> ! {
    durable(
        &root.join("ready"),
        std::process::id().to_string().as_bytes(),
    );
    loop {
        std::thread::park_timeout(Duration::from_secs(1));
    }
}
'''
new_body='''fn signal_and_wait(root: &Path) -> ! {
    let pid = std::process::id();
    let ready = root.join("ready");
    let staging = root.join(format!("ready.{pid}.tmp"));
    durable(&staging, pid.to_string().as_bytes());
    std::fs::rename(&staging, &ready).unwrap();
    loop {
        std::thread::park_timeout(Duration::from_secs(1));
    }
}
'''
assert old.count(old_body.encode())==1 and old.replace(old_body.encode(),new_body.encode(),1)==new
assert b'#![cfg(unix)]' in old
patch=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='M7F/crates/cc-semantic/tests/p7_crash_preparation.rs',tofile='existing-candidate/crates/cc-semantic/tests/p7_crash_preparation.rs'))
(ROOT/'existing-candidate-applicability.patch').write_text(patch)

comparison=obj('candidate-product-diff');review_diff=obj('candidate-review-diff');rcommit=obj('candidate-commit')
assert comparison['base_commit']['sha']==comparison['merge_base_commit']['sha']=='b2a17adc188338c48b95d01761836916e5d0fcdb'
assert comparison['total_commits']==2 and [x['sha'] for x in comparison['commits']]==['3ebf3f6163e37e7e23c441e23d706abd54c3dd82','c04033a02a7ed27f35a77247c0e5d45d0bb000a7']
assert len(comparison['files'])==2
assert rcommit['sha']=='3f9dcce4d072b04f21fcfcf1712bacb6171274c4' and [p['sha'] for p in rcommit['parents']]==['c04033a02a7ed27f35a77247c0e5d45d0bb000a7']
assert len(review_diff['files'])==1
review_path=review_diff['files'][0]['filename'];assert review_diff['files'][0]['sha']==oid((src/'candidate-independent-review.json').read_bytes())

for n in ('PR180-external-M7F-original-commit.json','PR180-external-M7F-original-compare.json'):
 original=Path('/dev/shm/root-round19')/n;target=ROOT/'official-responses'/n;target.write_bytes(original.read_bytes());assert target.read_bytes()==original.read_bytes()
def unwrap(d):
 if 'structuredContent' in d:
  assert not d.get('isError');return json.loads(d['structuredContent']['content'])
 return d
mcommit=unwrap(json.loads((ROOT/'official-responses/PR180-external-M7F-original-commit.json').read_text()))
mcmp=unwrap(json.loads((ROOT/'official-responses/PR180-external-M7F-original-compare.json').read_text()))
assert mcommit['sha']=='fffd950d5b34b0180f308db1428a57d5bf358bf1'
assert mcmp['base_commit']['sha']==mcmp['merge_base_commit']['sha']=='b2a17adc188338c48b95d01761836916e5d0fcdb'
assert len(mcmp['files'])==7 and mcmp['commits'][-1]['sha']==mcommit['sha']
crashpath='crates/cc-semantic/tests/p7_crash_preparation.rs'
assert crashpath not in {x['filename'] for x in mcmp['files']}
assert next(f['sha'] for f in mcmp['files'] if f['filename']=='crates/cc-search/src/preselect.rs')=='3d2daf9788173cb6fee2cb91350ea5c425e3e2a0'
assert next(f['sha'] for f in comparison['files'] if f['filename']=='crates/cc-search/src/preselect.rs')=='3d2daf9788173cb6fee2cb91350ea5c425e3e2a0'

workflow=Path('/dev/shm/todo-audit-P4-G4-binding-preparation/workflow-source/p7-closeout.yml').read_bytes()
inputmap=json.loads(Path('/dev/shm/todo-audit-P5B-G5B-binding-preparation/actual-P5B-1237-mode-blob-input-map.json').read_text())
wr=inputmap['.github/workflows/p7-closeout.yml'];assert oid(workflow)==wr['sha'] and digest(workflow)==wr['sha256']
(src/'b2-p7-closeout.yml').write_bytes(workflow)
assert 'ref: ${{ github.event.pull_request.head.sha || github.sha }}' in workflow.decode()
assert 'cargo test -p cc-semantic --locked --all-targets -- --nocapture' in workflow.decode()
logpath=ROOT/'original-closeout-113859546794.decoded.log';log=logpath.read_text();lines=log.splitlines()
assert '2026-10-09T14:42:49.8719965Z b2a17adc188338c48b95d01761836916e5d0fcdb' in log
for s in ('isolated_sigkill_reopen_replay_preparation','p7_crash_preparation.rs:218:18','ParseIntError { kind: Empty }','test result: FAILED. 0 passed; 1 failed; 1 ignored','Process completed with exit code 101.'):
 assert s in log
excerpts=[]
for a,b in [(190,198),(1374,1395),(1641,1676)]:excerpts.append({'first_line':a,'last_line':b,'text':'\n'.join(lines[a-1:b])})
write('original-log-selected-line-references.json',{'complete_log':meta(logpath),'boundary':'Connector-decoded complete GitHub job log; not claimed as original HTTP binary log bytes. No original measured artifact ZIP downloaded.','excerpts':excerpts})
steps=json.loads((ROOT/'official-responses/original-closeout-steps.json').read_text())['structuredContent']['steps']
assert [s['name'] for s in steps if s['conclusion']=='failure']==['Actual cache races, process faults and WAL recovery']
later=['Original thirteen-checkpoint real stdio lifecycle','Three-seed real product retry, crash, deletion, recovery and automatic GC','Attributed resources and actual worker contention']
assert all(next(s for s in steps if s['name']==n)['conclusion']=='success' for n in later)
rawreview=json.loads((src/'candidate-independent-review.json').read_text())
original_review=rawreview['pull_requests']['180']['candidate_review']
assert 'No source-level blocker' in original_review['static_decision']
assert 'not a pass' in original_review['static_decision']
registry=json.loads(Path('/dev/shm/todo-audit-P5B-G5B-binding-preparation/seed-b2-registry.json').read_text())
assert crashpath not in registry['delta'] and registry['complete_inputs'][crashpath]==digest(old)

report={'schema':'round19-existing-crash-ready-repair-applicability-v1','created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/todo_audit','scope':'Independent original failure, exact existing candidate diff and fixed M7F applicability; read-only/no tests or remote writes','verdict':'existing_candidate_applicable_scoped_source_only','source_failure':{'head':'b2a17adc188338c48b95d01761836916e5d0fcdb','workflow_path':'.github/workflows/p7-closeout.yml','workflow_blob':wr['sha'],'run_id':37942313114,'job_id':113859546794,'actual_checkout':'b2a17adc188338c48b95d01761836916e5d0fcdb','url':'https://github.com/jyqj/codecortex/actions/runs/37942313114/job/113859546794','command':'cargo test -p cc-semantic --locked --all-targets -- --nocapture','failed_step':'Actual cache races, process faults and WAL recovery','test':'isolated_sigkill_reopen_replay_preparation','error':'ParseIntError { kind: Empty }','source_line':218,'actual_original_exit':101,'result':{'passed':0,'failed':1,'ignored':1},'original_log':meta(logpath),'later_separate_steps_succeeded':later,'wiring_step':'skipped','artifact_not_downloaded':{'id':11623452978,'zip_bytes_reported_in_original_log':20408457,'zip_sha256_reported_in_original_log':'7ea08ad5283ecef16d5593db8fdc72a2c12457b024956e1af186e399ad19f9fc','url':'https://github.com/jyqj/codecortex/actions/runs/37942313114/artifacts/11623452978'}},'source_mechanism':{'observed_fact':'Parent parse of ready contents returned Empty at line218; exact original log retained.','causal_inference':'Old durable helper creates the final ready path before writing and syncing PID bytes, while parent only waits for exists(). That permits visibility of the empty file before write_all; the observed Empty is consistent with this exact source race. No instrumentation of the interleaving was performed.','old_source_lines':{'durable_create_write_sync':[90,95],'signal_final_path':[96,104],'fresh_root':[187,189],'deadline_exists_parse_pid_kill':[205,222]},'existing_fix':'Same-directory ready.<pid>.tmp; durable write_all+sync_all; helper return drops/closes File; rename into ready only after PID bytes are complete. The parent is unchanged.','boundary':'This repairs the readiness publication signal for process-kill preparation. It does not claim power-loss/directory durability, completion of P7-016, or a new runtime pass.'},'existing_candidate':{'P1':'3ebf3f6163e37e7e23c441e23d706abd54c3dd82','P2':'c04033a02a7ed27f35a77247c0e5d45d0bb000a7','R':'3f9dcce4d072b04f21fcfcf1712bacb6171274c4','R_tree':'0abbd55427efb63a0247dc328d84207b8ae9e547','review_repository_path':review_path,'review_original':meta(src/'candidate-independent-review.json'),'review_scope':'Existing bounded source-level review explicitly says not tested/not passed; it is not transplanted as a new complete canonical v15 review.','old_source':meta(src/'b2-p7_crash_preparation.rs'),'candidate_source':meta(src/'candidate-p7_crash_preparation.rs'),'changed_function':'signal_and_wait','all_other_source_bytes_equal':True,'preserved':['existing durable helper','15-second deadline','10ms polling','PID equality with owned child','SIGKILL and wait signal9 assertion','all three seeds and four original crash points','fresh per-case directory refusing old-run overwrite','all recovery and database/cache assertions','Unix cfg and all test definitions','production code and workflow budgets'],'no_new_execution':True},'current_fixed_M7F':{'head':mcommit['sha'],'tree':mcommit['tree']['sha'],'official_change_count_from_b2':7,'preselect_fix_already_present':True,'crash_fix_present':False,'crash_source_original_blob':'6493cbe6c291bc4622cf93cdb566f68e6e215155','direct_official_M7F_raw_equals_failed_b2':True,'new_external_artifacts_and_bindings_must_be_preserved':True},'minimal_next_action':{'source_change':'Use exactly existing candidate blob97ce7a96471cabc0943a1f5ecf9d2a62bde40d12 for only crates/cc-semantic/tests/p7_crash_preparation.rs on a fresh-confirmed descendant of M7F; do not reapply already-present preselect or transplant old candidate whole tree.','evidence':'Retain original b2 failure and existing candidate review path/ancestry. The old review remains source-bound to c040 and must not be relabeled as a complete current-M7F canonical review.','binding':'New actual P needs its own non-author complete review and the usual two binding files; counts mechanically expected1095 product/72 BASE delta/142 validation because this fixture was previously BASE-identical. This is not an actual new P/map or a new acceptance gate.','validation':'Use the unchanged original CI/P7 closeout path on the resulting exact source when root chooses to publish. No workflow/test/timeout expansion and no local rerun was performed by this review.','current_CI':'M7F CI remains independent and is not cancelled, restarted or called failed solely from the old-head observation.'},'actions_not_performed':['no code edit','no ref or PR update','no tests or native job','no workflow dispatch or rerun','no new study','no full artifact ZIP download','no TODO mutation'],'remaining_original_todos':29,'new_todo_credit':0}
report['round_boundary']={'started_in_round':19,'round19_closed_at_utc':'2026-10-09T15:26:31Z','round19_new_todo_credit':0,'completed_in_active_round':20,'remaining_todos':29}
# The candidate's two source deltas and M7F's one source delta are complete official
# compare inventories. No new whole-source audit or source execution is performed.
from copy import deepcopy
p2map={'source':'c04033a02a7ed27f35a77247c0e5d45d0bb000a7','source_tree':'1241bd5a2ce04f218cf36b064107ed425de7bf5d','base':registry['base_source'],'scope':'Mechanical fixed existing-P2 inventory inherited from exact b2 with its two official product deltas; not a new canonical review','complete_inputs':deepcopy(registry['complete_inputs']),'paths':deepcopy(registry['delta']),'validation_inputs':deepcopy(registry['validation_inputs'])}
preselect='crates/cc-search/src/preselect.rs'
formatted=Path('/dev/shm/execution-recon-recovery-20261009/PR180-preselect-format-fix-P5B/candidate/crates/cc-search/src/preselect.rs').read_bytes()
assert oid(formatted)=='3d2daf9788173cb6fee2cb91350ea5c425e3e2a0'
p2map['complete_inputs'][preselect]=digest(formatted);p2map['paths'][preselect]['sha256']=digest(formatted)
m7map=deepcopy(p2map)
p2map['complete_inputs'][crashpath]=digest(new);p2map['paths'][crashpath]={'before_sha256':digest(old),'sha256':digest(new)}
assert [len(p2map[k]) for k in ('complete_inputs','paths','validation_inputs')]==[1095,72,142]
assert [p for p in p2map['complete_inputs'] if p2map['complete_inputs'][p]!=m7map['complete_inputs'][p]]==[crashpath]
assert p2map['validation_inputs']==m7map['validation_inputs']
write('existing-P2-mechanical-input-map.json',p2map)
canonical_required=['source','base','verdict','scope','independent_reviewers','unresolved_blockers','paths','complete_inputs','validation_inputs']
missing=[k for k in canonical_required if k not in rawreview]
assert missing==canonical_required
guard=Path('/dev/shm/todo-audit-P5B-G5B-binding-preparation/seed-b2-guard.py').read_bytes()
(src/'original-v15-guard-b2.py').write_bytes(guard)
binding_review={'scope':'Read-only original v15 applicability, not a new source admission or changed contract','guard':meta(src/'original-v15-guard-b2.py'),'fixed_current_M7F':mcommit['sha'],'existing_P2':p2map['source'],'complete_product_equal_to_M7F_plus_one_crash_fixture':True,'ordinary_validation_equal':True,'counts':{'product':1095,'BASE_delta':72,'validation':142},'candidate_R3f9_directly_reusable_as_canonical':False,'missing_canonical_keys':missing,'original_guard_requirements':{'lines149_153':'Exact BASE-to-PRODUCT changed-path set must equal registry.delta','lines156_169':'Installed exact review digest and current bytes; source/base/verdict/scope/reviewers/blockers/paths must match','lines170_191':'Exact before/after deltas, complete product and validation maps','lines123_131_and231_238':'Current disk and tracked validation/product inputs must match fixed PRODUCT bytes','lines207_222':'Original CI selector and P7 engineering remain constrained'},'legal_options':[{'name':'reuse_existing_actual_P2_product','status':'Permitted by original fixed-product current-byte checks when all current product/validation inputs equal P2 and all other original guards pass.','needed':'A new genuine complete canonical review of P2, new original two-file binding, and an artifact-preserving merge to current M7F. Retain R3f9 as historical source-review evidence, not as an already valid canonical record.','limits':'No new execution claimed, no head update or old results relabeled here.'},{'name':'one_leaf_successor_of_fresh_M7F','status':'Operationally simpler preservation route; no reimplementation.','needed':'Use only existing crash-file blob97ce7a…, preserve M7F complete tree otherwise; non-author thin source bridge/full canonical maps and new original bindings.','limits':'This is a route choice, not a new protocol requirement or a new test gate.'}],'no_algorithm_or_threshold_change':True}
write('original-v15-reuse-and-forward-boundary.json',binding_review)
req={'base_tree':mcommit['tree']['sha'],'tree':[{'path':crashpath,'mode':'100644','type':'blob','sha':oid(new)}]}
write('fixed-M7F-one-leaf-create-tree-request.json',req)
write('existing-one-leaf-payload.json',{'actual_new_P':None,'base_head':mcommit['sha'],'base_tree':mcommit['tree']['sha'],'path':crashpath,'mode':'100644','local_path':str(src/'candidate-p7_crash_preparation.rs'),'bytes':len(new),'sha256':digest(new),'git_blob':oid(new),'blob_already_exists_in_official_candidate':True,'required_fresh_head_check_before_any_mutation':True,'evidence_preservation':'Existing review at R3f9 and the original b2 failure remain historical evidence. No current M7F artifact is deleted by this one-leaf request.'})
report['existing_P2_current_domain_equivalence']=binding_review
report['minimal_next_action']['binding']='The original guard permits reusing existing P2 as fixed product if exact current maps match; original narrow R3f9 is not a canonical record. Either obtain a new complete R/G for P2 plus nonloss M7F merge, or apply the existing one-leaf blob on fresh M7F and thin-bridge a new P/R/G. No extra tests are imposed.'
write('independent-existing-repair-applicability-review.json',report)
readme='''# Round19: existing PR180 crash-ready repair applicability

The old b2 failure is real and the existing candidate addresses its source-level readiness race. The fixed external M7F head still contains the failed fixture bytes; its only source change from b2 was the already-equivalent preselect formatter repair.

Original closeout run37942313114/job113859546794 checked out b2 exactly and failed with `ParseIntError { kind: Empty }` in `isolated_sigkill_reopen_replay_preparation`, original exit101 and result0pass/1fail/1ignored. Later lifecycle/retry/contention steps independently succeeded. The full connector-decoded log is retained; no original artifact ZIP was downloaded.

Existing candidate P2 c04033a02a7ed27f35a77247c0e5d45d0bb000a7 changes only `signal_and_wait` from a directly-created final ready file to a same-directory staged PID file followed by rename, after the unchanged durable helper has written/synced/closed it. Whole-file comparison proves all remaining bytes identical, including15seconds, PID equality, actual SIGKILL, fresh roots, all seeds/crash points and recovery assertions. Its original independent review R3f9 explicitly claims source-only acceptance, not execution.

Minimum successor scope is that one existing test-file blob atop a fresh-confirmed M7F descendant while preserving its four artifacts and new bindings. Keep the old independent review/source ancestry as historical evidence; a future complete canonical review must name the future actual P. No new P/ref was created here. Do not transplant the old whole candidate tree or reapply preselect. Expected source counts would be1095/72/142 because the fixture is not an existing b2 BASE delta; this count is prospective, not a completed new-source audit.

This package is read-only evidence and source applicability, not runtime or TODO acceptance. Original remaining count29; new completions0.
'''
(ROOT/'README.md').write_text(readme)
entries=[]
for p in sorted(ROOT.rglob('*')):
 if p.is_file() and p.name!='archive-selection.json':
  b=p.read_bytes();entries.append({'source_path':str(p),'archive_path':p.relative_to(ROOT).as_posix(),'mode':format(stat.S_IMODE(p.stat().st_mode),'04o'),'bytes':len(b),'sha256':digest(b),'git_blob':oid(b)})
write('archive-selection.json',{'schema':'round19-crash-ready-selected-evidence-v1','file_count':len(entries),'total_bytes':sum(e['bytes'] for e in entries),'files':entries,'scope':'Complete fetched decoded log and narrow existing candidate source/review applicability; no full original artifact ZIP','new_todo_credit':0,'remaining_todos':29})
print(json.dumps({'report':meta(ROOT/'independent-existing-repair-applicability-review.json'),'selection':meta(ROOT/'archive-selection.json'),'file_count':len(entries),'total_bytes':sum(e['bytes'] for e in entries),'verdict':report['verdict']},sort_keys=True))
