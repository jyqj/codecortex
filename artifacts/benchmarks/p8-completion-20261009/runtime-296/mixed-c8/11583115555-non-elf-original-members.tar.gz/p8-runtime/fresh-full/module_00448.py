def stable_00448():
    return 448
