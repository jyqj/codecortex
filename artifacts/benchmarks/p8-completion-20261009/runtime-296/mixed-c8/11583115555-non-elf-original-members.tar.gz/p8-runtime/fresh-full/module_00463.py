def stable_00463():
    return 463
