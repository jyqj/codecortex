#!/usr/bin/env python3
"""Recover original bytes only when the previously archived SHA-256 agrees.

No validator, original helper CLI, compiler, or workload is executed.
The original init JSON omitted from the archive has one clock field. All other
fields are derived from the preserved original build, metadata, and init review.
Only the original init execution's bounded clock interval is searched. A result
is written as the original state only if its full length and SHA match the
independently archived old seal; otherwise recovery fails without a state file.
"""
import hashlib
import json
import shutil
import time
import zipfile
from datetime import datetime, timedelta
from pathlib import Path

BASE = Path('/workspace/scratch/a217aaae3bde')
REVIEW = BASE / 'scale-pr180-C-review'
RECOVERY = REVIEW / 'recovery'
STATE = REVIEW / 'validated'
ORIGINAL_ZIP = REVIEW / 'artifacts/11607655032/11607655032.zip'
RECOVERED_ZIP = BASE / 'recovered-originals/artifacts/11607655032/11607655032.zip'
TARGET_SHA = '114193a7920ba1175ff79c210adea584a305b9dae9bae9990579f1d5252de464'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()

def write_absent(path, data, mode=0o644):
    assert not path.exists() and not path.is_symlink(), str(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)
    path.chmod(mode)
    assert path.read_bytes() == data

start = time.monotonic()
assert not (STATE / 'state.json').exists()
zip_bytes = RECOVERED_ZIP.read_bytes()
assert len(zip_bytes) == 9224061
assert sha(zip_bytes) == 'a1fbe7ea747fe9819ac3ddcb9144c3c3acf554cce843a698e7d796c499eb7e8e'
write_absent(ORIGINAL_ZIP, zip_bytes)
metadata_bytes = (RECOVERY / 'R27/build-original-metadata.json').read_bytes()
assert sha(metadata_bytes) == '10d51f651946bc3acbb3032d75d0d77a47411f647a10c249d0927240530febd3'
write_absent(REVIEW / 'artifact-metadata/11607655032.json', metadata_bytes)
metadata = json.loads(metadata_bytes)
initial_bytes = (RECOVERY / 'R27/build-init-original-review.json').read_bytes()
assert sha(initial_bytes) == 'd284ef73fed6e9049e54a48118e781a85804c7c5bdae9e82228d1e9cc05cac6e'
initial = json.loads(initial_bytes)
execution = json.loads((RECOVERY / 'R27/build-init-execution.json').read_bytes())
admitted = json.loads((REVIEW / 'admitted-subset-004.json').read_bytes())
assert admitted['state']['bytes'] == 2432 and admitted['state']['sha256'] == TARGET_SHA
assert initial['state_sha256'] == TARGET_SHA

build_dir = STATE / 'build-validation'
restored_members = []
with zipfile.ZipFile(ORIGINAL_ZIP) as archive:
    members = archive.infolist()
    names = [m.filename for m in members]
    assert set(names) == {'build.json', 'cargo.jsonl', 'cargo.stderr', 'p8-scale', 'source-before.json', 'source-after.json'}
    assert len(names) == len(set(names)) == 6
    assert sum(m.file_size for m in members) == 28781567
    built = json.loads(archive.read('build.json'))
    for m in members:
        b = archive.read(m)
        assert len(b) == m.file_size
        if m.filename != 'build.json':
            assert built['files'][m.filename] == {'bytes': len(b), 'sha256': sha(b)}
        write_absent(build_dir / m.filename, b, 0o700 if m.filename == 'p8-scale' else 0o644)
        restored_members.append({'name': m.filename, 'bytes': len(b), 'sha256': sha(b)})

snapshot = json.loads((RECOVERY / 'source-snapshot.json').read_bytes())
assert snapshot == json.loads((build_dir / 'source-before.json').read_bytes())
driver = json.loads((RECOVERY / 'driver-snapshot.json').read_bytes())
assert driver == built['driver_source']
source_bytes = encoded(snapshot)
engine_bytes = encoded(initial['expected_engine'])
write_absent(STATE / 'source-snapshot.json', source_bytes)
write_absent(STATE / 'expected-engine.json', engine_bytes)

state = {
    'schema': 'p8-fixed-source-streaming-review-v1',
    'source_commit': snapshot['source_commit'], 'run_id': 37910924354,
    'root': str(BASE / 'scale-original-c3ff'), 'build_directory': str(build_dir),
    'build_artifact': metadata, 'build_archive': str(ORIGINAL_ZIP),
    'build_receipt_sha256': sha((build_dir / 'build.json').read_bytes()),
    'source_snapshot_sha256': sha(source_bytes),
    'expected_engine_sha256': sha(engine_bytes),
    'source_manifest_sha256': snapshot['manifest_sha256'], 'driver_source': driver,
    'binary_sha256': built['binary_sha256'], 'binary_blake3': built['binary_blake3'],
    'helper_sha256': sha((REVIEW / 'review_scale_fixed_source.py').read_bytes()),
    'created_utc': 'CLOCK_PLACEHOLDER', 'task_statuses_changed': False,
}
template = encoded(state)
prefix, suffix = template.split(b'CLOCK_PLACEHOLDER')
base_digest = hashlib.sha256(prefix)
lo = datetime.fromisoformat(execution['started_at'])
hi = datetime.fromisoformat(execution['completed_at'])
steps = int((hi - lo).total_seconds() * 1000000) + 1
matched = None
for attempt in range(steps):
    instant = hi - timedelta(microseconds=attempt)
    clock = instant.isoformat().encode()
    digest = base_digest.copy()
    digest.update(clock)
    digest.update(suffix)
    if digest.hexdigest() == TARGET_SHA:
        matched = prefix + clock + suffix
        assert len(matched) == 2432 and sha(matched) == TARGET_SHA
        break
receipt = {
    'schema': 'C3ff-byte-exact-init-state-recovery-v1',
    'previously_archived_state_sha256': TARGET_SHA,
    'previously_archived_state_bytes': 2432,
    'original_init_execution': str(RECOVERY / 'R27/build-init-execution.json'),
    'bounded_clock_window': [execution['started_at'], execution['completed_at']],
    'tested_clock_candidates': attempt + 1,
    'full_original_state_hash_matched': matched is not None,
    'original_build_zip': {'path': str(ORIGINAL_ZIP), 'sha256': sha(zip_bytes), 'bytes': len(zip_bytes)},
    'restored_members': restored_members,
    'helper_cli_executed': False, 'native_workload_executed': False,
    'previous_four_shards_replayed': False,
    'accepted_shards': 4, 'accepted_samples': 41,
    'elapsed_seconds': time.monotonic() - start,
}
if matched is not None:
    write_absent(STATE / 'state.json', matched)
    write_absent(STATE / 'initialization-review.json', initial_bytes)
    receipt['recovered_original_created_utc'] = json.loads(matched)['created_utc']
write_absent(RECOVERY / 'byte-exact-init-state-recovery-result.json', encoded(receipt))
print(json.dumps(receipt, sort_keys=True), flush=True)
assert matched is not None, 'No original state bytes matched; original seal not restored.'
