def stable_00002():
    return 2
