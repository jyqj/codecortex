#!/usr/bin/env python3
"""Read accepted metadata/facts only. Does not import product/validators or read raw ZIP/JSONL."""
import copy, datetime, hashlib, json, pathlib, zipfile

ROOT = pathlib.Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'round47-final45-results'
D = ROOT / 'round47-new45-descriptive-analysis'
R = ROOT / 'round47-complete45-original-aggregate-recovery'
PREFIX = 'artifacts/checkpoints/p8-round47-complete-bfcc-20261010/'
SOURCE = 'f97c5068d056969705e8387ba1f37d83847f5bee'
def read(p): return json.loads(pathlib.Path(p).read_text())
def dump(p, v):
    with pathlib.Path(p).open('x') as f: json.dump(v, f, ensure_ascii=False, indent=2); f.write('\n')
def meta(p):
    p=pathlib.Path(p); b=p.read_bytes()
    return dict(local_path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest(), git_blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
def selection(paths, base):
    return [dict(meta(p), member=str(p.relative_to(base))) for p in paths]
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
draft=read(D/'accepted-45-descriptive-pending-aggregate-draft.json')
matrix=read(R/'aggregate-output/task-matrix.json')
execution=read(R/'original-recovery-execution.json')
trace=read(R/'actual-native-hash-child-trace.json')
functions=read(R/'original-function-call-counts.json')
identity=read(R/'input-identity-comparison.json')
assert execution['exit_code']==0 and not execution['custody_faults']
assert len(trace)==91 and all(t['returncode']==0 and t['stderr']['bytes']==0 for t in trace)
assert identity['equal'] and identity['product_observer_count']==1107 and identity['directories']==45
assert matrix['passed'] and matrix['cell_count']==45 and matrix['record_count']==85
assert matrix['validated_input_count']==matrix['accepted_cell_count']==45
assert not matrix['missing_slots'] and not matrix['input_errors']
assert matrix['setup_pair_count']==matrix['mutation_sample_count']==40 and matrix['fanout_sample_count']==5
assert matrix['study']['run_id']=='38026411200' and matrix['study']['run_attempt']==1
assert read(R/'original-aggregate-return.json')==matrix
raw_index_path=ROOT/'round47-final45-raw-custody/complete-45-raw-custody.prepublication.json'
raw_index=read(raw_index_path)
assert raw_index['whole_artifacts_present']==45 and not raw_index['missing_slots']
custody={tuple(x['slot']):x for x in raw_index['ordered_cells']}
mcells={tuple(x['slot']):x for x in matrix['cells']}
assert len(mcells)==len(custody)==45
observations={(tuple(x['slot']),x['role']):x for x in draft['observations']}
assert len(observations)==85
sample_checks=0
for field,role in [('setup_pairs','setup'),('mutation_samples','mutation'),('fanout_samples','fanout')]:
    for x in matrix[field]:
        obs=observations[(tuple(x['slot']),role)]
        assert x['n']==obs['n']==1
        for k,v in obs['original'].items(): assert x['sample'][k]==v,(x['slot'],role,k)
        env=draft['environments'][obs['environment_ref']]
        expected=dict(env['environment'],engine_cpu_parallelism=env['engine_cpu_parallelism'],measurement_environment=env['measurement_environment'],profile_environment=env['profile_environment'])
        assert matrix['environments'][x['environment_id']]==expected
        sample_checks+=1
assert sample_checks==85
assert {(tuple(x['slot']), 'setup') for x in matrix['cold_curve_from_no_op']}=={(tuple(x['slot']),x['role']) for x in draft['preselected_cold_subset']}

# Four previously frozen mutation fact sets omitted elapsed_ms. Join the already
# accepted independent timing facts; preserve old facts and do not reopen raw.
bridge=[]
peer_fact_paths=[]
for profile,dirname,n in [('api','round46-api-100k-independent-review',171),('config','round46-config-100k-independent-review',330),('batch_1000','round46-batch1000-100k-independent-review',1),('batch_100','round47-batch100-100k-independent-review',1)]:
    fp=D/f'phase-facts-{profile}-100000.json'
    pp=ROOT/dirname/'original-timing-phase-and-parity-selection.json'
    peer_fact_paths.append(pp)
    facts=read(fp); peer=read(pp)
    lookup={(b['line'],b['label']):b for b in peer['builds']}
    rows=[]
    assert len(facts['report_groups']['mutation'])==n
    for i,b in enumerate(facts['report_groups']['mutation']):
        line=b['provenance']['line']; p=lookup[(line,b['label'])]
        assert p['wall_us']==b['wall_us'] and p['full']==b['full']
        for key,value in b['report'].items():
            if key in p['report_fields']: assert value==p['report_fields'][key],(profile,line,key)
        assert 'elapsed_ms' not in b['report'] and isinstance(p['report_fields']['elapsed_ms'],int)
        rows.append(dict(line=line,label=b['label'],elapsed_ms=p['report_fields']['elapsed_ms'],original_line_sha256=b['provenance']['original_line_sha256'],old_fact_pointer=f'/report_groups/mutation/{i}',peer_fact_pointer=f"/builds/{peer['builds'].index(p)}/report_fields/elapsed_ms"))
    total=sum(x['elapsed_ms'] for x in rows)
    engine=observations[((profile,100000,0),'mutation')]['original']['engine_ms']
    assert total==engine,(profile,total,engine)
    bridge.append(dict(slot=[profile,100000,0],role='mutation',count=n,old_phase_facts=meta(fp),existing_independent_timing_facts=meta(pp),elapsed_ms_sum=total,original_engine_ms=engine,rows=rows))
assert sum(x['count'] for x in bridge)==503
bridge_doc=dict(schema='existing-original-timing-facts-source-bridge-v1',created_at_utc=now,source=SOURCE,run_id=38026411200,attempt=1,count=503,method='Read-only join on original raw line and build label; every overlapping report field equal. No raw reread or validator/hash/measurement invocation. Original fact files remain unchanged.',groups=bridge)
dump(OUT/'503-build-elapsed-source-bridge.json',bridge_doc)

actions_meta=read(ROOT/'round47-original-Actions-aggregate/root-original-files.actual.json')
actions_refs=[{k:x[k] for k in ['repository_path','bytes','sha256','actual_git_blob']} for x in actions_meta['files']]
recovery_summary=dict(schema='original-complete-input-aggregate-recovery-execution-review-v1',recorded_at_utc=now,source=SOURCE,run_id=38026411200,attempt=1,kind='Local complete-input recovery of the original aggregate; no new Actions run/attempt, no new measurements.',execution=execution,original_function_calls=functions,actual_hash_children=dict(count=91,all_exit_zero=True,all_stderr_empty=True,trace=meta(R/'actual-native-hash-child-trace.json')),input_identity=identity,result={k:matrix[k] for k in ['schema','scope','status','passed','cell_count','sample_count','record_count','setup_pair_count','mutation_sample_count','fanout_sample_count','validated_input_count','accepted_cell_count','input_errors','missing_slots','registration_sha256','task_build_receipt_sha256','statistics_scope','release_certification','G8','task_statuses_changed']},original_return=meta(R/'original-aggregate-return.json'),original_matrix=meta(R/'aggregate-output/task-matrix.json'),return_matrix_structural_equality=read(R/'original-return-vs-matrix.json'),original_Actions_failure=dict(job_id=114158378120,accepted_inputs=42,missing_slots=[['batch_100',100000,0],['body',100000,0],['config',100000,0]],original_files=actions_refs,status='failed; preserved'),independent_review_git='d9b9bb0b332e14793405c8848a2ab1eac1c60835',limits=['ELF executed only for 91 hash-file utility calls, not measurements.','Original aggregate internally revalidated one build and45shards as required by its unchanged successful path. Earlier separate original intakes remain separate executions.','No task/ref/PR state changed by this execution.'])
dump(R/'complete45-recovery-execution-review.json',recovery_summary)

# Catalog links original aggregate receipt identities to accepted results and all
# existing immutable whole-ZIP byte leaves. R47 publication remains honestly null.
catalog=[]
for c in draft['cells']:
    slot=tuple(c['slot']); m=mcells[slot]
    assert c['original_task_receipt_sha256']==m['receipt_sha256']
    catalog.append(dict(slot=c['slot'],records=1 if slot[0]=='fanout' else 2,environment_ref=c['environment_ref'],aggregate_environment_id=m['environment_id'],receipt_sha256=m['receipt_sha256'],aggregate_directory=m['directory'],accepted_original_return=c['original_result'],acceptance_report=c['acceptance_report'],raw_whole_custody=custody[slot]))
assert sum(c['records'] for c in catalog)==85
catalog_doc=dict(schema='accepted45-original-receipt-custody-catalog-v1',recorded_at_utc=now,source=SOURCE,run_id=38026411200,attempt=1,accepted_cells=45,records=85,roles=dict(setup=40,mutation=40,fanout=5),preselected_cold_subset=draft['preselected_cold_subset'],raw_index_source=meta(raw_index_path),all_whole_artifacts_present=True,all_original_byte_leaves_created=True,all_original_byte_leaves_published=raw_index['all_original_byte_leaves_published'],raw_archive_bytes=raw_index['raw_archive_bytes'],raw_byte_leaf_count=raw_index['raw_byte_leaf_count'],publication_note='R42–R46 published commits retained; R47 original body/batch100 byte leaves exist as immutable Git blobs but their publication commit is pending. Root will append an actual-commit bridge after publishing.',cells=catalog,original_build=dict(directory=str(ROOT/'round42-new45-build-original-intake/original-build'),accepted_review_git='767527f7cccf372e6ca1dd866466d6bf66c86da3',accepted_support_git='79d96014710c2172b8bd17053d2a559144ec6003',independent_review_git='e21da10f97d88e7d8836669e88e02be8374457cb'),stdout_custody_exception=dict(slot=['api',1000,0],scope='Original first12 primary stdout was empty at later sealing although execution recorded11657B; same-digest original return preserved and independent copy restored. Original empty file/support and peer first failure retained; cause unknown.',independent_review_git='b0c2bf92ba9a9bdc6ebd7b089ffe520d147db81d'),aggregate_recovery=meta(R/'complete45-recovery-execution-review.json'))
dump(OUT/'complete45-receipt-custody-catalog.json',catalog_doc)

final=copy.deepcopy(draft)
final.update(schema='original45-descriptive-results-v1',publication='Final descriptive data from45 accepted original cells; local complete-input original aggregate passed. Original Actions42-input failure retained separately.',recorded_at_utc=now,task_credit=0)
final.pop('draft_projection_calls')
final['report_projection_calls']=dict(validator=0,aggregate=0,combine=0,ELF=0,CRC=0,raw_reread=0)
final['original_Actions_aggregate']=copy.deepcopy(draft['original_aggregate'])
final['original_Actions_aggregate']['scope']='Historical original Actions execution failed with42inputs; unchanged by local recovery.'
final['complete_input_aggregate_recovery']=recovery_summary
final.pop('original_aggregate')
final['original_aggregate_measurement_bridge']=dict(all85_original_measurement_subsets_equal=True,all45_environment_identities_equal=True,all45_receipt_sha256_equal=True,all5_preselected_cold_slots_equal=True,original_45_payload_changed=False)
final['elapsed_source_bridge']=meta(OUT/'503-build-elapsed-source-bridge.json')
final['receipt_custody_catalog']=meta(OUT/'complete45-receipt-custody-catalog.json')
final['data_review_git']='df34da270300c1b905b760f3332e4cfcea04444a'
dump(OUT/'final45-descriptive-results.json',final)

regression=read(ROOT/'round46-twelve-task-acceptance-report-draft/final-acceptance-report-slots.applyfalse.json')['evidence_index']['G2']
definition=read(ROOT/'round46-twelve-task-acceptance-report-draft/final-acceptance-report-slots.applyfalse.json')['clause_rows'][:4]
decision=dict(schema='P8-006-original-four-clause-evidence-decision-v1',apply_now=False,task_status_changed=False,recorded_at_utc=now,task='P8-006',recommendation='accept_task_scope_for_root_manual_application',source=SOURCE,run_id=38026411200,attempt=1,original_clause_rows=definition,clause_decisions=[
dict(field='steps[0]',original='测no-op/body/API/config/batch和超预算闭包',judgment='covered',evidence='40mutation cells =8registeredprofiles×5scales (no_op/body/api/config/batch1/10/100/1000), plus5fanoutcells. All45originalcells complete with original45/85aggregate recovery passed. Fanout16/64/128 first incomplete then complete2/8/16builds; API/body/config have real bounded resumes. No invented resume for batch1000 whose direct writes complete in one incremental build.',references=['final45-descriptive-results.json#/observations','complete45-receipt-custody-catalog.json#/cells']),
dict(field='steps[1]',original='输出各phase计数',judgment='covered',evidence='85role-qualified observations preserve original timing/counts and per-build raw report provenance; parsed/updated/scanned/skipped/selected counters, first/lastfreshness and resume counts derived from original emitted records.503 elapsed_ms values joined from previously accepted independent timing facts; sums match originalengine_ms. Repeated-work counts are not distinctfiles; missing emitted fields remainunavailable.',references=['final45-descriptive-results.json#/observations','503-build-elapsed-source-bridge.json','final45-analysis-originals.zip']),
dict(field='acceptance[0]',original='时间可归因且闭包完成后full parity，未完成有显式status',judgment='covered_at_descriptive_N1_task_scope',evidence='Separate engine/index/outer/full/parity timings, phase/build timing and per-cell environment retained. No nested timing doubleaddition or causal speedup claim. Original validators and aggregate confirm full15-table parity and finalclosure/EOF for all45. Intermediate incomplete states remain explicit. OriginalActions42 failure and prior incomplete/failed studies remain distinct; complete-input recovery does not overwrite them.',references=['final45-descriptive-results.json','complete45-recovery-execution-review.json']),
dict(field='acceptance[1]',original='相关旧功能回归通过；没有证据的项标not_run/blocked而非done。',judgment='covered_by_existing_exact_source_regression_and_scoped_historical_evidence',evidence='Currentf97/main0da9 fulltree match and originalmainCI/all26/soak evidence retained. Named ordinary index/invalidation/resume regressions executed; ignored publicMCP methods are not relabelled as current runs. Their historical coverage stays attached to its original source. No claim of allV20/G8, stableN30, real-repository G2 incremental workload or passing oldquality/replay failure.',references=regression)
],final_data=meta(OUT/'final45-descriptive-results.json'),recovery_review=meta(R/'complete45-recovery-execution-review.json'),regression=regression,scope_limits=['This is the preregistered independent profile_task_descriptive_v1 N1/45cells85records task study, not completion of old150/N30 studies.','Fivecold no_op setups are a subset of40setups; there are85records, not90.','D4 whole-program real-repository coverage and release-level V20/G8 remain their original broader scope; synthetic45 are not realrepository data.','Original Actions aggregate failed; local unchanged original aggregate recovered with complete inputs and91observed hash utility children.','No performance causal inference or stable tail/p99 claim. No taskdefinitions, dependencies, gates, budgets, source or states changed.'],related_scope_originals=['round43-final-nine-application/006-clause-decision.applyfalse.json','round43-final-nine-application/readiness-and-real-repository.addendum.json'])
dump(OUT/'P8-006-original-clause-decision.applyfalse.json',decision)
md=(D/'accepted-45-descriptive-pending-aggregate-draft.md').read_text()
md=md.replace('# 新45格原始结果：N=1描述性草表','# 新45格原始结果：N=1描述性完整报告',1)
old='现45/45格、85/85条记录逐格已接受；原Actions aggregate只收到42输入而失败，恢复聚合尚未执行。本文是scratch草表，不授任务或发布完成信用。'
new='45/45格、85/85条记录逐格已接受。原Actions aggregate只收到42输入而失败，该失败原样保留；07:18:55–07:19:32在完整45个原目录上执行未修改的原aggregate一次，实际exit0、45accepted/85records，91次hash utility子调用全部0。恢复没有运行新测量，也不是新的Actions attempt。本文不自动修改任务状态。'
assert old in md; md=md.replace(old,new,1)
md+='\n\n## 完整输入恢复及证据边界\n\n原Actions job114158378120的42输入失败、原日志及矩阵独立保留。完整输入恢复实际调用原aggregate1次、原validate_build1次、validate_shard45次、combine1次；91次原ELF --hash-file是真实hash utility执行，不是本地测量。1107源/observer、build与45输入前后保持一致。19.66MB的stdout、return和矩阵完整保存在恢复support中，原stdout与return字节相等，矩阵仅JSON结构相等，未将键顺序差异隐藏。\n\n最终JSON的45cells、85observations及所有环境/计时/计数payload与已独审草表逐对象相同，仅追加实际恢复与证据指针。原聚合85条对应measurement字段和45个环境、receipt SHA逐项相等。\n\n## 503项elapsed来源补充\n\nAPI100k的171个、config100k的330个、batch100与batch1000各1个增量report，旧派生事实未复制elapsed_ms。新503项桥按原行号/label及重叠字段连接已冻结独审计时事实；不重读raw、不改变旧事实。各组elapsed_ms之和精确等于原return的engine_ms，旧计时值未修改。\n\n## P8-006原条款判断（不自动应用）\n\n| 原条款 | 证据判断 |\n|---|---|\n| 测no-op/body/API/config/batch和超预算闭包 | 40mutation与5fanout全完整；真实incomplete/resume保留，未人为制造batch1000的resume。 |\n| 输出各phase计数 | 原phase/build字段与parsed/updated/skipped/selected计数完整分列；原未发出的字段保持unavailable。 |\n| 时间可归因且闭包完成后full parity，未完成有显式status | engine/index/outer/full/parity及host分列；全部原closure和15表parity通过；Actions失败和旧研究失败仍明确。 |\n| 相关旧功能回归通过；无证据项not_run/blocked | 引用同产品树的原mainCI、26工程检查、soak及明确原source的相关历史回归；不把ignored或旧失败标通过。 |\n\n建议Root按上述有限任务范围作正式验收；本报告apply=false，不改变任何tasks。此结论不等于旧150/N30、全V20/G8或真实repo增量研究完成。不得跨host推断因果加速或稳定尾分位。\n'
(OUT/'final45-descriptive-results.md').write_text(md)
dump(OUT/'finalization-receipt.json',dict(started_from='accepted45 frozen descriptive payload',completed_at_utc=now,exit_code=0,cells=45,records=85,elapsed_bridge_count=503,all_observation_payloads_unchanged=final['observations']==draft['observations'],all_cells_payloads_unchanged=final['cells']==draft['cells'],all_environments_unchanged=final['environments']==draft['environments'],aggregate_sample_environment_receipt_checks=True,original_predicate_invocations=0,ELF_invocations=0,raw_reads=0,ZIP_reads=0))

# Preserve all original recovery streams, matrix and actual91child outputs.
recovery_paths=sorted(p for p in R.rglob('*') if p.is_file() and 'sealed' not in p.parts)
sealed=R/'sealed'; sealed.mkdir(exist_ok=True)
recovery_selection=dict(schema='complete-original-aggregate-recovery-selection-v1',files=selection(recovery_paths,R),no_original_output_omitted=True)
dump(sealed/'archive-selection.json',recovery_selection)
with zipfile.ZipFile(sealed/'complete45-original-aggregate-recovery-support.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in recovery_paths: z.write(p,str(p.relative_to(R)))
    z.write(sealed/'archive-selection.json','archive-selection.json')

analysis_paths=[*sorted(D.glob('phase-facts-*.json')),*peer_fact_paths,*[p for p in D.iterdir() if p.is_file() and p.suffix in ['.py'] or p.is_file() and ('receipt' in p.name or p.name.endswith('.stdout') or p.name.endswith('.stderr'))],ROOT/'round43-final-nine-application/006-clause-decision.applyfalse.json',ROOT/'round43-final-nine-application/readiness-and-real-repository.addendum.json',raw_index_path,*sorted(p for p in OUT.iterdir() if p.is_file())]
assert len(set(analysis_paths))==len(analysis_paths)
dump(OUT/'archive-selection.json',dict(schema='complete45-final-descriptive-analysis-selection-v1',files=selection(analysis_paths,ROOT),scope='Full original report-derived phase facts and exact503existing timing sources; excludes wholeZIPs/rawJSONL/ELF already preserved by immutable custody.'))
with zipfile.ZipFile(OUT/'final45-analysis-originals.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in analysis_paths: z.write(p,str(p.relative_to(ROOT)))
    z.write(OUT/'archive-selection.json','archive-selection.json')
publish=[(R/'complete45-recovery-execution-review.json','aggregate-recovery/complete45-recovery-execution-review.json'),(sealed/'complete45-original-aggregate-recovery-support.zip','aggregate-recovery/complete45-original-aggregate-recovery-support.zip'),(sealed/'archive-selection.json','aggregate-recovery/archive-selection.json')]
for name in ['final45-descriptive-results.json','final45-descriptive-results.md','complete45-receipt-custody-catalog.json','503-build-elapsed-source-bridge.json','P8-006-original-clause-decision.applyfalse.json','finalization-receipt.json','final45-analysis-originals.zip','archive-selection.json']:
    publish.append((OUT/name,'final45/'+name))
manifest=dict(schema='round47-complete45-recovery-and-final-description-upload-v1',source=SOURCE,run_id=38026411200,attempt=1,refs_changed=False,files=[dict(meta(p),repository_path=PREFIX+dest,actual_created=False) for p,dest in publish])
dump(OUT/'upload-manifest.pending.json',manifest)
print(json.dumps(dict(exit_code=0,cells=45,records=85,elapsed_bridge=503,files=[dict(path=x['repository_path'],bytes=x['bytes'],git=x['git_blob']) for x in manifest['files']]),indent=2))
