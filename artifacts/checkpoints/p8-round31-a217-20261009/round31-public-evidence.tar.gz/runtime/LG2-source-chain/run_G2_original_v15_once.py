#!/usr/bin/env python3
"""Run the unmodified fixed G2 v15 CLI once, retaining exact exit and all inputs."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import time

B = Path('/workspace/scratch/a217aaae3bde')
I = B / 'p8-db-lock-observation-integration'
OUT = I / 'LG2-actual-G2-proof'
VIEW = B / 'p8-lock-observation-P2-validated'
CFG = json.loads((I / 'LG2-final-composition-inputs.json').read_bytes())
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def oid(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def save(name, value):
    raw = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()
    p = OUT / name
    p.open('xb').write(raw)
    return dict(path=str(p), bytes=len(raw), sha256=sha(raw), git_blob=oid(raw))


def head():
    return subprocess.check_output(['git', '-C', str(VIEW), 'rev-parse', 'HEAD'], env=ENV).decode().strip()


def snapshot(paths):
    rows = {}
    for p in paths:
        f = VIEW / p
        if not f.is_file() or f.is_symlink():
            rows[p] = {'invalid_input': True}
            continue
        raw = f.read_bytes()
        mode = '100755' if stat.S_IMODE(f.stat().st_mode) & 0o111 else '100644'
        rows[p] = dict(bytes=len(raw), sha256=sha(raw), git_blob=oid(raw), mode=mode)
    return rows


def main():
    prepared = json.loads((OUT / 'actual-G2-composition-proof.json').read_bytes())
    assert prepared['verdict'] == 'accepted_scoped_actual_G2_composition'
    expected = json.loads((OUT / 'all-1851-inputs-before.json').read_bytes())
    assert len(expected) == 1851 and head() == CFG['guard']
    before = snapshot(expected)
    assert before == expected
    before_ref = save('CLI-all-1851-inputs-before.json', before)
    command = CFG['actual_cli']
    assert command == ['python3', '-B', 'scripts/verify_reviewed_source_v15.py', '--source-version',
                       'p8-completion-source-20261009-v15']
    assert CFG['timeout_seconds'] == 3600
    out = OUT / 'original-v15.stdout.txt'
    err = OUT / 'original-v15.stderr.txt'
    started_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    started = time.monotonic()
    rc = None
    exception = None
    timed_out = False
    with out.open('xb') as stdout, err.open('xb') as stderr:
        try:
            process = subprocess.run(command, cwd=VIEW, env=ENV, stdout=stdout, stderr=stderr,
                                     timeout=3600)
            rc = process.returncode
        except subprocess.TimeoutExpired:
            timed_out = True
            exception = 'original CLI exceeded its unchanged 3600-second outer bound'
        except Exception as exc:
            exception = type(exc).__name__ + ': ' + str(exc)
    elapsed = time.monotonic() - started
    finished_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    after = snapshot(expected)
    after_ref = save('CLI-all-1851-inputs-after.json', after)
    source_after = head()
    record = dict(schema=1, source_before=CFG['guard'], source_after=source_after,
                  command=command, cwd=str(VIEW), started_at=started_at, finished_at=finished_at,
                  elapsed_seconds=elapsed, returncode=rc, timed_out=timed_out,
                  timeout_seconds=3600, exception=exception,
                  input_count=1851, before=before_ref, after=after_ref,
                  all_input_bytes_modes_unchanged=before == after,
                  stdout=dict(path=str(out), bytes=out.stat().st_size, sha256=sha(out.read_bytes())),
                  stderr=dict(path=str(err), bytes=err.stat().st_size, sha256=sha(err.read_bytes())),
                  product=CFG['product'], review=CFG['review'],
                  original_history_count=187, task_definitions_or_status_changes=0,
                  compile_or_native='not_run', formal_task_completion=False,
                  formal_done=163, formal_remaining=29)
    saved = save('original-v15-execution.json', record)
    print(json.dumps(dict(receipt=saved, returncode=rc, timed_out=timed_out,
                          elapsed_seconds=elapsed, inputs_unchanged=before == after,
                          stdout_bytes=out.stat().st_size, stderr_bytes=err.stat().st_size)), flush=True)
    assert before == after and source_after == CFG['guard']
    raise SystemExit(rc if rc is not None else 124)


if __name__ == '__main__':
    main()
