# CodeCortex benchmark baseline

Suite: `V19 TypeScript 04 oce-compat-v1 candidate; review/custody pending`
Adapter: `mcp-stdio`
Scoring: `OceCompat`
Measurement profile: `quality`

Status: **gate_failed** (exit 1)

Queries: 11; measured rows: 33.
Mean Top-1: 0.636364; mean nDCG@10: 0.602812.

These are baseline observations, not a release quality certificate.
Latency: Distribution { samples: 0, p50_us: None, p95_us: None, max_us: None, tail_claim: "insufficient_for_tail_claim" }; samples are retained, not best-of.
Source evidence: 0 invalid, 0 unverified hits.

| Case | Top-1 | nDCG@10 | Repetitions |
|---|---:|---:|---:|
| v19.typescript.f0062.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0064.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0065.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0067.en01 | 0.000000 | 0.000000 | 3 |
| v19.typescript.f0068.en01 | 0.000000 | 0.000000 | 3 |
| v19.typescript.f0069.en01 | 1.000000 | 0.859719 | 3 |
| v19.typescript.f0070.en01 | 0.000000 | 0.000000 | 3 |
| v19.typescript.f0072.en01 | 1.000000 | 0.380094 | 3 |
| v19.typescript.f0075.en01 | 1.000000 | 0.760188 | 3 |
| v19.typescript.f0076.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0077.en01 | 0.000000 | 0.630930 | 3 |

## Failures

- v19.typescript.f0070.en01 Partial
- v19.typescript.f0064.en01 Partial
- v19.typescript.f0069.en01 Partial
- v19.typescript.f0067.en01 Partial
- v19.typescript.f0072.en01 Partial
- v19.typescript.f0076.en01 Partial
- v19.typescript.f0065.en01 Partial
- v19.typescript.f0062.en01 Partial
- v19.typescript.f0068.en01 Partial
- v19.typescript.f0077.en01 Partial
- v19.typescript.f0075.en01 Partial
- v19.typescript.f0068.en01 Partial
- v19.typescript.f0062.en01 Partial
- v19.typescript.f0064.en01 Partial
- v19.typescript.f0072.en01 Partial
- v19.typescript.f0065.en01 Partial
- v19.typescript.f0076.en01 Partial
- v19.typescript.f0077.en01 Partial
- v19.typescript.f0067.en01 Partial
- v19.typescript.f0070.en01 Partial
- v19.typescript.f0075.en01 Partial
- v19.typescript.f0069.en01 Partial
- v19.typescript.f0067.en01 Partial
- v19.typescript.f0069.en01 Partial
- v19.typescript.f0076.en01 Partial
- v19.typescript.f0072.en01 Partial
- v19.typescript.f0065.en01 Partial
- v19.typescript.f0062.en01 Partial
- v19.typescript.f0068.en01 Partial
- v19.typescript.f0077.en01 Partial
- v19.typescript.f0075.en01 Partial
- v19.typescript.f0064.en01 Partial
- v19.typescript.f0070.en01 Partial