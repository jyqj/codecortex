def stable_00273():
    return 273
