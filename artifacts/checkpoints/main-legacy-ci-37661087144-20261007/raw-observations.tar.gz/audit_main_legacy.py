#!/usr/bin/env python3
"""Bind actual main CI logs to fixed Git source; never rerun product tests."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import legacy_log_indexer as indexer

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent / 'codecortex-historical-v2'
SOURCE = 'b951f27d3ed50b7755bc2456c6425355f753ec17'
RUN = 37661087144

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def load(name):
    return json.loads((OUT / name).read_bytes())

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n')

def main():
    run, jobs, binding = load('final-run-api.json'), load('final-jobs-api.json'), load('git-source-binding.json')
    assert run['id'] == RUN and run['head_sha'] == SOURCE and run['run_attempt'] == 1
    assert run['status'] == 'completed' and run['conclusion'] == 'success' and run['event'] == 'push'
    assert run['head_commit']['tree_id'] == binding['source_tree']
    assert jobs['total_count'] == len(jobs['jobs']) == 3
    assert {job['name'] for job in jobs['jobs']} == {'check', 'msrv', 'security'}
    workflow = subprocess.check_output(['git', 'show', SOURCE + ':.github/workflows/ci.yml'], cwd=ROOT).decode()
    checkouts, parsed = [], None
    for job in jobs['jobs']:
        assert job['run_id'] == RUN and job['head_sha'] == SOURCE
        assert job['status'] == 'completed' and job['conclusion'] == 'success'
        assert all(step['status'] == 'completed' and step['conclusion'] == 'success' for step in job['steps'])
        name = job['name'] + '-job.log'
        raw = (OUT / name).read_bytes()
        lines = indexer.plain(raw)
        markers = [i for i, line in enumerate(lines) if line == '[command]/usr/bin/git log -1 --format=%H']
        assert len(markers) == 1 and lines[markers[0] + 1] == SOURCE
        checkouts.append({'job_id': job['id'], 'job': job['name'], 'source_commit': SOURCE,
                          'raw_log': name, 'source_log_line': markers[0] + 2,
                          'bytes': len(raw), 'sha256': sha(raw)})
        if job['name'] == 'check':
            parsed = indexer.parse_check(raw, job, workflow)
    assert parsed is not None
    assert all(group['summary']['status'] == 'ok' and group['summary']['failed'] == 0
               for group in parsed['rust_groups'] if 'summary' in group)
    assert all(suite['result'] == 'OK' for suite in parsed['python_suites'])
    total = {key: sum(group['summary'][key] for group in parsed['rust_groups'] if 'summary' in group)
             for key in ('passed', 'failed', 'ignored', 'measured', 'filtered_out')}
    observations = parsed['structured_log_observations']
    products = [observation for observation in observations if 'binary' in observation['value']]
    assert len(products) == 2
    assert {item['value']['package_kind'] for item in products} == {'default', 'semantic'}
    for item in products:
        assert item['value']['source_commit'] == SOURCE and item['value']['source_inputs'] == 776
        assert re.fullmatch('[0-9a-f]{64}', item['value']['sha256'])
    final_artifacts = load('final-artifacts-api.json')
    assert final_artifacts['total_count'] == 0
    security_lines = indexer.plain((OUT / 'security-job.log').read_bytes())
    audit_rows = [json.loads(line) for line in security_lines if line.startswith('{"database":')]
    assert len(audit_rows) == 1
    assert audit_rows[0]['vulnerabilities'] == {'found': False, 'count': 0, 'list': []} and audit_rows[0]['warnings'] == {}
    save('step-and-test-index.json', parsed)
    result = {'schema_version': 1, 'reviewer': '/root/ci_history_review',
              'source_commit': SOURCE, 'source_tree': binding['source_tree'],
              'run_id': RUN, 'run_attempt': 1, 'event': 'push', 'status': 'completed', 'conclusion': 'success',
              'run_url': run['html_url'], 'all_jobs_and_steps_completed_success': True,
              'job_checkouts': checkouts, 'workflow_sha256': sha(workflow.encode()),
              'exact_workflow_command_blocks': len(parsed['steps']),
              'rust_target_executions': sum('summary' in group for group in parsed['rust_groups']),
              'rust_results_counted_as_executions_not_unique_functions': total,
              'python_suites': parsed['python_suites'], 'structured_log_observations': observations,
              'products': products, 'rustsec_audit': audit_rows[0],
              'artifact_count': 0, 'runner_full_build_receipt_or_stdio_observation_files_retained': False,
              'source_manifest_kind': '776-entry immutable Git reconstruction; not a downloaded legacy runner manifest',
              'no_product_or_tests_executed_by_reviewer': True,
              'network_isolation': 'not_isolated_not_claimed; original P7-017 local isolation failure remains separate',
              'old_failed_legacy_run': 37653732411,
              'acceptance_limit': 'Actual main CI scope; task acceptance remains separately mapped to original P7-013 conditions.'}
    save('main-run-audit.json', result)
    print(json.dumps({'run_id': RUN, 'rust_target_executions': result['rust_target_executions'],
                      'rust': total, 'python': result['python_suites'], 'products': products}, ensure_ascii=False))

if __name__ == '__main__':
    main()
