#!/usr/bin/env python3
import hashlib,json,pathlib,zipfile,datetime
ROOT=pathlib.Path(__file__).resolve().parent
WORK=ROOT.parent
SOURCE=WORK/'round30-PR190-main-integration-P2'
PEER=WORK/'round30-PR190-main-integration-P2-peer'
def meta(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git_blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
def main():
    terminal=json.loads((ROOT/'actual-original-validation-attempt01/terminal.json').read_text())
    assert terminal['all_planned_commands_completed'] and len(terminal['records'])==1
    receipt=terminal['records'][0]
    assert receipt['source']=='4786c1457b47c5baf4c09d32b96048795e863111'
    stdout=(ROOT/'actual-original-validation-attempt01/original-v15.stdout').read_bytes()
    result=json.loads(stdout) if receipt['exit_code']==0 else None
    files=[]
    # Preserve each actual command's raw stdout/stderr/receipt and full pre/post maps.
    files.extend(p for p in ROOT.iterdir() if p.is_file() and not p.name.startswith(('seal-final-admission', 'sealing.')))
    files.extend(p for p in (ROOT/'actual-original-validation-attempt01').iterdir() if p.is_file())
    for name in ['actual-R-binding-input.json','R-created-objects-original.json','G-created-objects-original.json','actual-G-binding.json','generation-manifest.json','generation-execution.json','generation.stdout','generation.stderr','generation.exit','generate-actual-R-bindings.py','two-binding-create-tree-request.json','P2-domain-preparation-receipt.json','BASE-test-read.stdout','BASE-test-read.stderr','BASE-test-read.exit']:
        f=SOURCE/name
        if f.exists():files.append(f)
    files.extend(p for p in (SOURCE/'official').glob('actual-[RG]-*.original.json'))
    files.extend(p for p in (SOURCE/'generated/scripts').iterdir() if p.is_file())
    for name in ['installed-R-generated-G-independent-thin-review.json','actual-G-independent-bridge.json']:
        files.append(PEER/name)
    files.append(pathlib.Path(__file__))
    entries=[]
    for p in sorted(set(files)):
        b=p.read_bytes();entries.append(dict(local_path=str(p),path=p.relative_to(WORK).as_posix(),mode=oct(p.stat().st_mode&0o777),**meta(b)))
    manifest=dict(schema='pr190-main-P2-R-G-original-admission-selection-v1',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=entries,file_count=len(entries),scope='Selected original source-admission support; not the full Git repository or Rust/benchmark execution.')
    out=ROOT/'sealed-final-v2';out.mkdir()
    selection=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();(out/'archive-selection.json').write_bytes(selection)
    zpath=out/'source-admission-originals.zip'
    with zipfile.ZipFile(zpath,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for e in entries:z.write(e['local_path'],e['path'])
        z.writestr('archive-selection.json',selection)
    with zipfile.ZipFile(zpath) as z:
        assert z.testzip() is None and len(z.infolist())==len(entries)+1
        for e in entries:assert meta(z.read(e['path']))=={k:e[k] for k in ['bytes','sha256','git_blob']}
    report=dict(schema='pr190-main-P2-R-G-original-admission-v1',source='4786c1457b47c5baf4c09d32b96048795e863111',source_tree='6518a5b317683a24ded3a69b027da6a04b8c996c',product='2b6e9ebf2baeb8102df72d09360700e23487f870',review='ca10314fbc5a4ffa28ada5b7c1097c1091b48aa4',source_domains=dict(product=1096,BASE_delta=79,validation=146),selected_inputs=1435,original_admission=terminal,result=result,canonical_git_blob='2c007a66bf32a80c0b7eeec6c166cf5400aae5ae',canonical_support_git_blob='1fd73f3830093361830b6934e8c60a0882194446',independent_binding_peer_git_blobs=['780f3e099abd957791423c9d2d88aa846980daf4','f031fb17781f62a1f41366248277c02641be7f5e'],source_support_archive=meta(zpath.read_bytes()),selection=meta(selection),scope='Original source-admission only. No Rust, benchmark, workflow or task credit. No refs or PR changes.',preserved_history=dict(P1='d2b853b6a57fdc6c5ffb500c0efcb4f976a480d0',donor_failure_log_git_blob='3efadf710a054e2beda886cdd29938639145e94b',donor_failure_evidence_commit='a7791788ee2bf5da26f8b8048c284bff951ead05',donor_equal_lifetime_analysis_git_blob='c86bfcdbde71616d9847a9620ba915d0dc03e200',limits='The donor finite five-case cost evidence retains its original f675 identity. New G has not executed Rust or measured performance.'),preparation_notes=['An initial oversized tool text read was truncated at 512 KiB and JSON decoding failed before any upload. Source files were unchanged; subsequent binary chunks and server Git OIDs confirmed exact bytes.','The unexecuted pending CLI plan omitted required --source-version. The actual receipt and runner contain the original complete argument.','Shared historical Git objects were used read-only. Only this isolated view and its shallow metadata/index/selected files were written.'])
    b=(json.dumps(report,indent=2,sort_keys=True)+'\n').encode();(out/'actual-admission.json').write_bytes(b)
    prefix='artifacts/checkpoints/p8-borrowed-oracle-main-integration-bfcc-20261009'
    upload=dict(schema='pr190-final-admission-upload-v1',files=[dict(local_path=str(out/'actual-admission.json'),path=prefix+'/actual-admission.json',**meta(b)),dict(local_path=str(zpath),path=prefix+'/source-admission-originals.zip',**meta(zpath.read_bytes()))])
    (out/'upload-manifest.json').write_text(json.dumps(upload,indent=2)+'\n')
    print(json.dumps(upload))
if __name__=='__main__':main()
