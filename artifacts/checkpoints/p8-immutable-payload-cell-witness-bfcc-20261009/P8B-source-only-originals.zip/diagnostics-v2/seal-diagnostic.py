#!/usr/bin/env python3
"""Seal already completed finite diagnostic outputs; never executes a workload."""
from pathlib import Path
import datetime,hashlib,json,os,stat,zipfile
P=Path(__file__).resolve().parent
DATA=Path('/workspace/scratch/bfccb8494ba0/round21-oracle-raw-cell-diagnostic-v2')
OLD=P.parent/'round21-oracle-witness-diagnostic'
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def ident(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b),'git_blob':blob(b),'posix_mode':oct(stat.S_IMODE(p.stat().st_mode))}
def write(n,o):
 with (P/n).open('x') as f:json.dump(o,f,indent=2,ensure_ascii=False);f.write('\n')
result=json.loads((P/'result.json').read_text());receipt=json.loads((P/'child-receipt.json').read_text());plan=json.loads((P/'pre-execution-plan.json').read_text())
assert receipt['child_exit_code']==0 and not receipt['timed_out'] and receipt['elapsed_seconds']<45
assert result['all_18_completed'] and result['all_9_pairs_exact_sorted_bytes_and_shared_results_equal']
inputs=json.loads((P/'input-files-before.json').read_text());assert inputs==json.loads((P/'input-files-after.json').read_text())
trials=[json.loads((P/f'trial-{n:02}.json').read_text()) for n in range(1,19)]
assert [(t['case'],t['pair'],t['variant']) for t in trials]==[tuple(x) for x in plan['schedule']]
for t in trials:
 assert t['canonical_bytes']==8388608 and t['incremental_rows']==t['full_rows']==4096
 for m in t['sorted_outputs'].values():
  b=Path(m['path']).read_bytes();assert len(b)==m['bytes'] and sha(b)==m['sha256'] and blob(b)==m['git_blob']
for i in range(0,18,2):
 a,b=trials[i:i+2]
 for side in ('A','B'):assert Path(a['sorted_outputs'][side]['path']).read_bytes()==Path(b['sorted_outputs'][side]['path']).read_bytes()
for m in inputs:
 b=Path(m['path']).read_bytes();assert len(b)==m['bytes'] and sha(b)==m['sha256']
source_pairs=[('original-streaming.rs',Path(plan['source_original']['path'])),('candidate-streaming.rs',Path(plan['source_candidate']['path'])),('candidate-benchmark_oracle_streaming.rs',Path('/dev/shm/root-round21/oracle-raw-cell-witness-v2/candidate/crates/cc-eval/tests/benchmark_oracle_streaming.rs'))]
for n,p in source_pairs:
 b=p.read_bytes()
 with (P/n).open('xb') as f:f.write(b)
assert sha((P/'candidate-streaming.rs').read_bytes())=='6370b04d008787868666b0c035c8dbb9d92d67dfc3eb1bd790c578b1c2e2ad1c'
assert sha((P/'candidate-benchmark_oracle_streaming.rs').read_bytes())=='0eebe45448130c73319736ec856f07ff7bc07a2538b418a50f152b19e25994a1'
paths=[Path(m['path']) for m in inputs]+[Path(m['path']) for t in trials for m in t['sorted_outputs'].values()]
assert len(paths)==42 and len(set(paths))==42
members=[{'member':str(p.relative_to(DATA)),**ident(p)} for p in paths]
manifest=json.dumps({'schema':'retained-actual-byte-results-v2','members':members},indent=2).encode()+b'\n'
zp=P/'complete-diagnostic-byte-results.zip'
with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for m,p in zip(members,paths):
  before=p.read_bytes();assert sha(before)==m['sha256'];z.write(p,m['member'])
 z.writestr('member-manifest.json',manifest)
with zipfile.ZipFile(zp) as z:
 assert len(z.infolist())==43 and z.testzip() is None and z.read('member-manifest.json')==manifest
 for m in members:
  b=z.read(m['member']);assert len(b)==m['bytes'] and sha(b)==m['sha256'] and blob(b)==m['git_blob']
  assert stat.S_IMODE(z.getinfo(m['member']).external_attr>>16)==int(m['posix_mode'],8)
write('byte-results-archive-receipt.json',{'whole_zip':ident(zp),'members':43,'all_member_CRC_and_exact_SHA256_verified':True,'uncompressed_data_bytes':sum(m['bytes'] for m in members),'scope':'Six actual SQLite inputs and all 36 sorted JSON outputs. Scratch files remain at original locations; no workload replay or recomputation.'})
write('scratch-locators.json',{'scope':'Already produced scratch files, retained without modification; hashes only, not duplicated in selected archive.','files':[ident(p) for p in sorted(DATA.glob('*/scratch.sqlite'))]})
case_work={}
for case in plan['cases']:
 by={v:[t for t in trials if t['case']==case and t['variant']==v] for v in ('old','candidate')}
 assert all(t['work_counters']==by['old'][0]['work_counters'] for t in by['old'])
 assert all(t['work_counters']==by['candidate'][0]['work_counters'] for t in by['candidate'])
 case_work[case]={v:by[v][0]['work_counters'] for v in by}
review={
 'schema':'raw-cell-witness-independent-terminal-risk-review-v2',
 'observed_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'reviewer':'execution_recon; not author of the Rust oracle candidate; author of this explicitly limited Python transcription',
 'source_verdict':'accepted_scoped_for_engineering_candidate; no identified correctness blocker in reviewed source',
 'adoption_recommendation':'The raw-cell witness is reasonable to submit to the original Rust engineering controls. Accept its explicit fallback cost as a tradeoff, not a guarantee of performance improvement. These bounded results do not establish full-scale runtime or resolve failed studies.',
 'source_identities':[ident(P/n) for n,_ in source_pairs],
 'prior_static_report':ident(P/'independent-source-review.json'),
 'terminal_execution':receipt,
 'checks':{'all_original_18_calls_completed':True,'nine_pairs_exact_complete_sorted_bytes_and_common_results_equal':True,'six_original_inputs_before_after_unchanged':True,'canonical_bytes_each_trial':8388608,'original_data_and_sources_remain_unmodified':True},
 'result':result,
 'deterministic_work_counters':case_work,
 'interpretation':[
  'Same-order equal inputs take the witness: scratch inserted rows are 4096 instead of 8192, JSON projections remain 8192 in total, and the witness adds 4096 raw A rows / 12288 cell comparisons. The median paired wall ratio is 0.9076299482850626, with all three ratios retained rather than selecting the fastest.',
  'Reverse-order equal inputs fall back at the first row: the candidate adds only one B projection and one raw-cell comparison before the unchanged dual spool. Its three ratios are 1.6033551030430044, 1.3683205412705048 and 1.108833988580289. The observed median slowdown cannot be attributed entirely to that single-row extra work from this small, noisy Python timing experiment.',
  'Last-row mismatch adds a complete B projection pass: 12288 JSON projections versus 8192, plus 4096 raw A rows; scratch insertions stay 8192. All three measured ratios are greater than one, with median 1.2254548334586473. This is a concrete adverse case retained in the evidence, not hidden or declared a new hard acceptance threshold.',
  'This v2 and the earlier v1 were separate runs, not a contemporaneous paired v1/v2 experiment. Do not subtract their medians or describe their difference as a measured Rust speedup.'
 ],
 'implementation_bridge_limits':plan['limitations']+[
  'CPython sqlite3 statement caching and SQLite3.53.1 differ from the Rust rusqlite bundled build and its explicit prepared-statement lifetime. Real SQLite schema, PRAGMAs, pending-byte threshold and insert tiers are retained, but this is not a runtime-identical reproduction.',
  'The fixed 4096-row / 1024-byte fixture exercises the 64-row insert tier. 8/1 tail insert branches are retained in the driver but are not exercised by this chosen fixture.',
  'All sorted audit arrays are materialized by Python, and integrity/FK checks plus host open/close work are inside the measured call. The observer differs from the product streaming implementation.',
  'SHA256 only locates the complete retained bytes. Original Rust BLAKE3, float/blob/non-ASCII/projection-error controls, all 15 tables, scratch-fault equivalence and memory peaks were not executed here.',
  'Successful witness intentionally avoids B scratch writes: it preserves canonical semantics and logical budgets, but cannot promise the same counterfactual B-only SQLITE_FULL or I/O-error sequence.',
  'Candidate Rust tests, rustfmt, Clippy, product tests and original source-admission/scale workflows remain not_run for this source by this report.'
 ],
 'v1_frozen_evidence':{n:ident(OLD/n) for n in ('archive-selection.json','bounded-risk-review.json','result.json','child-receipt.json','complete-diagnostic-byte-results.zip')},
 'new_primary_samples':0,'new_TODO_completions':0,'TODO_remaining':29,
 'no_new_trials_retries_thresholds_or_source_changes':True
}
write('bounded-risk-review.json',review)
selected=sorted(p for p in P.iterdir() if p.is_file() and p.name not in {'archive-selection.json','sealing.stdout','sealing.stderr','sealing-receipt.json'})
files=[{**ident(p),'relative_path':p.name,'repository_path':'artifacts/checkpoints/p8-oracle-raw-cell-witness-v2-bfcc-20261009/'+p.name} for p in selected]
write('archive-selection.json',{'schema':'selected-original-evidence-files-v1','files':files,'count':len(files),'total_bytes':sum(m['bytes'] for m in files),'scope':'Source-only independent review plus one completed limited Python/SQLite18-call v2 diagnostic. Old v1 evidence referenced without rewriting; no Rust or primary credit. Selection excludes its own bytes and sealing receipt.'})
print(json.dumps({'review':ident(P/'bounded-risk-review.json'),'selection':ident(P/'archive-selection.json'),'selected_count':len(files),'selected_bytes':sum(m['bytes'] for m in files),'complete_bytes_zip':ident(zp)}))
