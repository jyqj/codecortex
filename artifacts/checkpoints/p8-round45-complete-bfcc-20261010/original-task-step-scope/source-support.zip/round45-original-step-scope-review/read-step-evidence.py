import datetime, hashlib, json, pathlib, re

D = pathlib.Path(__file__).resolve().parent
ROOT = D.parent
def load(path): return json.loads(path.read_text())
def identity(path):
    b = path.read_bytes()
    return dict(path=str(path.relative_to(ROOT)), bytes=len(b), sha256=hashlib.sha256(b).hexdigest(), git_blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())

old = load(ROOT/'round44-main-eight-scope-applicability/independent-merged-main-eight-scope-review.json')
review = load(D/'recovered/recovery-original-review.json')
author = load(D/'recovered/recovery-original-author-receipt.json')
checks = review['checks']
assert checks == author['checks']
assert review['source'] == '275e8799d4947d297329073eaa3ca675d3fd0777'
assert review['run'] == 37890757129 and review['artifact'] == 11597639035
assert review['actual_execution']['exit_code'] == 0
assert checks['local_scope']['passed'] == ['kill_restart', 'database_busy', 'deleted_source']
assert checks['local_scope']['not_run_in_local_profile'] == ['transaction_internal_crash_points','active_provider_network_disconnect','active_semantic_cache_corruption','concurrent_database_replacement']
assert [x['seed'] for x in checks['active_faults']] == [223,227,229]
for x in checks['active_faults']:
    assert x['cases'] == ['active_provider_network_disconnect','active_semantic_cache_corruption','active_cache_reader_rejects_unknown_format','concurrent_database_replacement']
    assert x['provider_requests'] == 6 and x['paid_cost'] is None
assert checks['p7-crash-raw']['cases'] == 12 and checks['independent-crash-raw']['cases'] == 15
assert len(checks['original_fault_tests']) == 7 and all(x['exit']==0 for x in checks['original_fault_tests'])
auditor = (D/'recovered/original-retained-recovery-auditor.py').read_text()
assert identity(D/'recovered/original-retained-recovery-auditor.py')['git_blob'] == 'a9f42ff0a794486679a6be441b282a14b3c63966'
assert identity(D/'recovered/recovery-original-author-receipt.json')['git_blob'] == '4704801d577640d617f4533160b96f4fa68c036b'

mainlog = ROOT/'round42-new45-study/114135224079-original-main.log'
assert identity(mainlog)['git_blob']=='b42f2f685f4f2caaaa0497db6706399d9f89d998'
names=[x['test'] for x in checks['original_fault_tests']]
selected=[]
for n,line in enumerate(mainlog.read_text(encoding='utf-8-sig').splitlines(),1):
    for name in names:
        if 'test '+name+' ... ' in line:
            selected.append(dict(line=n,name=name,original=line,result=line.split(' ... ',1)[1]))
assert len(selected)==5 and all(x['result']=='ok' for x in selected)

mapping=[
 dict(original_step='kill进程', local_case='kill_restart', local_status='passed', additional_cases=['transaction_internal_crash_points','isolated_sigkill_reopen_replay_preparation','independently_observed_sigkill_boundaries','index_db_rebuild::fault_tests::owned_process_kill_between_sidecar_cleanup_rename_and_reopen_preserves_database'], actual_evidence='Local actual kill/restart; 12+15 separate SIGKILL cases, signal9/integrity ok; uncommitted rollback; other points three no-op replays/final epoch1; reopen provider calls1 at claimed/response, otherwise0.', auditor_lines=[137,164], missing_required_step=None),
 dict(original_step='网络断开', local_case='active_provider_network_disconnect', local_status='not_run', additional_cases=['active_provider_network_disconnect'], actual_evidence='All3 active seeds executed owned loopback HTTP disconnect; each6 HTTP requests/1 disconnect. Before semantic backfilling+dense partial; after recovery semantic ready. This is actual local HTTP transport failure, not a live-provider billing claim.', auditor_lines=[225,246], missing_required_step=None),
 dict(original_step='缓存损坏', local_case='active_semantic_cache_corruption', local_status='not_run', additional_cases=['active_semantic_cache_corruption','active_cache_reader_rejects_unknown_format','meta_tampering_is_detected_as_corrupt','different_spaces_never_cross_hit','namespaces_are_isolated'], actual_evidence='All3 active seeds: corrupt lane partial, complete false, semantic_artifact_unavailable; restored complete, additional provider requests0. Unknown format999 rejected partial then restored complete. Three exact cache Rust controls passed separately.', auditor_lines=[137,152,234,239], missing_required_step=None),
 dict(original_step='数据库忙', local_case='database_busy', local_status='passed', additional_cases=['index_db_rebuild::fault_tests::writer_mutex_spans_rename_reopen_and_connection_installation'], actual_evidence='Original accepted local real SQLite busy/release receipt; distinct exact writer mutex test passed. Do not substitute the mutex test for the local busy exercise.', auditor_lines=[137,152,257,263], missing_required_step=None),
 dict(original_step='换库', local_case='concurrent_database_replacement', local_status='not_run', additional_cases=['concurrent_database_replacement','index_db_rebuild::fault_tests::writer_mutex_spans_rename_reopen_and_connection_installation'], actual_evidence='All3 active seeds: held query pins>0, incarnation changes, swapped state is not ready, settled ready, one persisted manifest, deleted source absent. Actual historical25->24->25->original backup is a distinct corroborating scope, not a tagged release.', auditor_lines=[240,246], missing_required_step=None),
 dict(original_step='保持raw故障工件', local_case=None, local_status=None, additional_cases=[], actual_evidence='Original immutable499-member recovery artifact, bound exact products/observer/source, original command/stdout/stderr and fault results. Original receiver/root review accepted custody; this read-only review does not reopen or revalidate its ZIP.', auditor_lines=None, missing_required_step=None)
]
report={
 'schema':'original-P8-011-exact-case-and-merged-main-eight-scope-addendum-v1',
 'reviewer':'/root/pr_triage', 'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'apply_now':False,
 'conclusion':'no_uncovered_original_five_fault_step_identified_after_exact_original_case_mapping; original_sources_limits_dependencies_preserved',
 'actual_main':{k:old['actual_merged_main'][k] for k in ['commit','tree','parents','merged_PR','merged_at']},
 'main_identity_bridge':{'actual_git_blob':'08aa3635f4a6572fef3bbf2bd82cba1ad527d80c','meaning':'Exact merged main tree equals G2; nine definitions/dependencies unchanged. Existing executions retain G2 producer identity.'},
 'original_task':{'id':'P8-011','steps':['kill进程/网络断开/缓存损坏/数据库忙/换库','保持raw故障工件'],'acceptance':['没有假ready或删除复活，恢复与费用影响清楚','相关旧功能回归通过；没有证据的项标not_run/blocked而非done。'],'harddeps':['P7-020','P8-007','P8-010'],'ledger_blob':'adb44ee70a4c129bfb443d4ecf678fb934c8ea6b'},
 'source_of_exact_names':{'source':review['source'],'run':review['run'],'artifact':review['artifact'],'commit':'cd92ce4b931e770994770ba3dba6fd0a47a505ea','repository_path':'artifacts/checkpoints/p8-round19-evidence-20261009/recovery/root-independent-original-evidence-review.json','root_review_identity':identity(D/'recovered/recovery-original-review.json'),'original_author_receipt':identity(D/'recovered/recovery-original-author-receipt.json'),'original_auditor_read_not_executed':identity(D/'recovered/original-retained-recovery-auditor.py')},
 'local_report_unchanged':checks['local_scope'],
 'precise_not_run_interpretation':{'not_run_means':'Not executed by that limited local profile; never relabel its3passed/4not_run as7passed.','none_of_the_four_is_excused_merely_as_live_provider_not_applicable':True,'separate_executions_cover_them':['transaction_internal_crash_points: separate original12+15 SIGKILL cases','network/cache/replacement: separate3seed active end-to-end cases'],'live_or_paid_cost_boundary':'Paid provider charges remain null. Owned loopback HTTP calls and recovery-call counts were observed; physical power loss, vendor outages and release certification were not claimed.'},
 'step_mapping':mapping,'all_seven_exact_original_Rust_controls':checks['original_fault_tests'],
 'original_crash_matrices':{k:checks[k] for k in ['p7-crash-raw','independent-crash-raw']},
 'original_active_seeds':checks['active_faults'],
 'current_G2_regression_corroboration':{'job':114135224079,'run':38025451919,'log':identity(mainlog),'actual_checkout':old['bounded_source_applicability']['admission_and_source_review']['actual_CI_checkout'] if 'actual_CI_checkout' in old['bounded_source_applicability']['admission_and_source_review'] else '9c4f29f5b290bfcd60375bc1c1c7a194b5099eae, complete tree equals G2','exact_five_observations':selected,'other_two_original_crash_controls_in_this_selected_main_scan':'not observed; do not claim a current rerun from their historical pass','scope':'Current main engineering regressions corroborate applicability; historical active full fault exercise remains G275, not relabelled as G2/main.'},
 'eight_scope_source_applicability':old['bounded_source_applicability'],
 'eight_task_ids':['P8-007','P8-008','P8-009','P8-010','P8-011','P8-012','P8-013','P8-016'],
 'P8_007_owner':'/root/execution_recon independently maps mixed/backfill original workload and concurrency; this report does not replace that peer.',
 'preserved_scope':review['limitations'],
 'remaining_final_acceptance':{'research_as_of_existing_0601_receipts':{'accepted_cells':37,'total_cells':45,'accepted_records':69,'total_records':85,'pending_cells':8,'pending_records':16,'pending_population':'all8 profiles at100k','cold_points_accepted':4,'cold_points_total':5},'needs_actual_originals':['remaining8 complete whole records with original producer outcomes','original Actions aggregate/full log and complete45 population/custody','independent clause-by-clause P8-006 decision using original contract','per-ID dependency/accepted-scope decision before any task write'],'not_new_requirements':['no new blanket eight-task rerun','no extra150/N30 gate for this registered N1 task route','no repeat original fault exercise solely because local subset retains4not_run'],'tasks_modified':False,'TODO_credit':0},
 'retrieval_and_execution_boundary':{'Git_immutable_small_reports_read':True,'Actions_downloads':0,'old_ZIP_open_CRC':0,'product_or_Rust_or_original_auditor_execution':0,'local_targeted_reader_only':True,'computed_Gc8_review_blob_404_preserved':'original-responses/computed-runtime-blob-404-original.json','local_G275_ls_tree':{'exit_code':128,'reason':'old tree metadata not materialized; NoLazy prevented implicit fetch','inference':'No exact whole G275-to-main byte equality claimed.'},'missing_local_closeout_path':'Targeted rg returned2 because prior closeout log path absent; present main matched5 methods. No repeat download or fabricated two-crash current result.'}
}
(D/'independent-original-fault-step-and-main-scope-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'accepted_scoped_original_step_coverage_with_historical_identity','report':identity(D/'independent-original-fault-step-and-main-scope-review.json'),'exact_current_main_methods':len(selected),'original_local_passed':3,'original_local_not_run':4,'separate_active_seeds':3,'original_SIGKILL_cases':27,'new_execution_credit':0},ensure_ascii=False,indent=2))
