def stable_00217():
    return 217
