import collections, datetime, hashlib, json
from pathlib import Path
ROOT=Path('/workspace/scratch/bfccb8494ba0'); OUT=Path(__file__).resolve().parent
IN=ROOT/'round46-batch1000-100k-original-intake'; CELL=IN/'batch_1000-100000-0'; SHARD=CELL/'original-shard'; NATIVE=SHARD/'native-shard/native'
BUILD=ROOT/'round42-new45-build-original-intake'; G='f97c5068d056969705e8387ba1f37d83847f5bee'; RUN=38026411200
inputs={}
def read(p):
 b=p.read_bytes();inputs[str(p)]={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()};return b
def load(p):return json.loads(read(p))
def dump(name,v):
 text=json.dumps(v,ensure_ascii=False,indent=2)+'\n'
 if (OUT/name).exists():
  assert (OUT/name).read_text()==text
 else:
  with (OUT/name).open('x') as f:f.write(text)

t=load(IN/'terminal.json'); official=load(ROOT/'round46-new45-original-artifacts/batch1000-100k-original-inputs.json')
ret=load(CELL/'original-validate-shard-return.json'); ex=load(CELL/'original-validator-execution.json')
registry=load(BUILD/'original-build/task-registry.json'); bt=load(BUILD/'validation-attempt01/original-validate-build-return.json')
prior=load(ROOT/'round45-batch10-100k-independent-review/independent-batch10-100k-review.json')
assert (t['source'],t['run_id'],t['attempt'],t['accepted_cells'],t['failed_cells'],t['accepted_records'])==(G,RUN,1,1,0,2)
assert t['records'][0]['slot']==['batch_1000',100000,0]
assert t['validate_build_calls']==t['compile_or_measurement_calls']==t['old_slots_reexecuted']==0
assert t['stdio_custody_complete'] and load(IN/'shared-source-build-before.json')==load(IN/'shared-source-build-after.json')
assert prior['cumulative']['cells']==40 and prior['cumulative']['records']==75 and prior['source']==G and prior['registry_sha256']==bt['outer']['registration_sha256']
stdout=read(CELL/'original-validator.stdout');assert stdout==read(CELL/'captured-stdout.frozen-original')==read(CELL/'original-validate-shard-return.json')
assert len(stdout)==ex['stdout']['bytes'] and hashlib.sha256(stdout).hexdigest()==ex['stdout']['sha256']
assert read(CELL/'original-validator.stderr')==read(CELL/'captured-stderr.frozen-original')==b''
assert ex['exit_code']==0 and ex['original_validate_shard_calls']==1 and ex['validate_build_calls']==ex['measurement_or_compile_calls']==0
assert load(CELL/'shard-before.json')==load(CELL/'shard-after.json')
sr=load(SHARD/'task-shard.json');nr=load(NATIVE/'report.json');assert nr['summary']==load(NATIVE/'worker-summary.json')
p=ret['plan'];assert p==sr['plan'] and p in registry['plans']
assert (p['deadline_ms'],p['max_output_bytes'],p['dirty_budget'],p['max_resume_builds'],p['seed'])==(18000000,536870912,200,1024,12648430)
assert p['profile']=='release' and p['capacity_profile']=='scale_capacity_v1' and p['stage_scope']=='profile_task_descriptive_v1'
assert p['files']==[100000] and p['repetitions']==1 and p['shard']=={'count':1,'index':0}
assert p['profile_study']=={'fanout':None,'mutation_profile':'batch_1000','run_attempt':1,'run_id':str(RUN)}
assert ret['study']==sr['study']==registry['study'] and ret['driver_source']==sr['driver_source']==registry['driver_source']
assert len(ret['driver_source']['inputs'])==11 and ret['registration_sha256']==bt['outer']['registration_sha256']
assert ret['build_receipt_sha256']==sr['task_build_receipt_sha256']=='5b3f02a114fd68355916a4d94ec3b2c65a5895371e2bbdd97d24077598e50aab'
assert sr['passed'] and sr['status']=='passed' and sr['task_statuses_changed'] is False
assert sr['files']['native-shard/source-before.json']==sr['files']['native-shard/source-after.json']
assert ret['engine']['engine_head_observed']==G and ret['engine']['binary_digest']==registry['binary_blake3'] and not ret['engine']['eval_debug_assertions']
assert nr['status']=='measurement_complete' and nr['exit_code']==nr['worker_exit_code']==0 and nr['stderr_complete'] and nr['worker_binary_unchanged']
assert nr['worker_binary_digest_before']==nr['worker_binary_digest_after']==registry['binary_blake3']
assert nr['fixture_cleanup']['error'] is None and nr['summary']['passed'] and nr['summary']['sample_count']==2
assert [x['group'] for x in ret['measurements']]==['scale-100000/cold','scale-100000/batch_1000']
hs=load(CELL/'native-hash-subprocess-originals.json');assert len(hs)==2
for h,k in zip(hs,['plan_digest','raw_digest']):
 assert h['returncode']==0 and '--hash-file' in h['argv'] and read(CELL/h['stderr']['file'])==b''
 assert read(CELL/h['stdout']['file']).decode().strip()==nr[k]

TABLES={'document_manifest','resolution_frontier','semantic_edges','dispatch_sites','resolution_manifests','resolution_dependencies','public_surfaces','files','symbols','imports','symbol_refs','call_edges','chunks','test_edges','routes'}
counts=collections.Counter(); builds=[];parities=[];stages=[];mutations=[]
raw=NATIVE/'raw.jsonl';sha=hashlib.sha256();raw_bytes=0
with raw.open('rb') as f:
 for ln,b in enumerate(f,1):
  sha.update(b);raw_bytes+=len(b);e=json.loads(b);ev=e['event'];counts[ev]+=1
  if ev=='build_finished':
   r=e['report'];pm=r['project_model'];pm_short={k:(dict(array_count=len(v),canonical_sha256=hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()) if isinstance(v,list) else v) for k,v in pm.items()}
   fields={k:v for k,v in r.items() if k.startswith('files_') or k in ['dirty_plan','dirty_propagation','document_changes','build_timing','phase_timing','resolution_freshness','elapsed_ms','symbols_total','chunks_total','parse_errors','used_parallel_parse']}
   builds.append({'line':ln,'label':e['label'],'full':e['full'],'start_us':e['start_us'],'end_us':e['end_us'],'wall_us':e['wall_us'],'report_fields':fields,'project_model_list_values_summarized':pm_short})
   assert e['wall_us']==e['end_us']-e['start_us'] and r['resolution_freshness']['complete']
  if ev in ['cold_parity','stage_finished']:
   q=e['parity'];assert q['equal'] is True and q['status']=='equal' and q['different_tables']==[]
   assert len(q['tables'])==15 and {x['table'] for x in q['tables']}==TABLES
   for v in q['tables']:
    assert type(v['equal']) is bool and v['equal'] and type(v['full_rows']) is int and type(v['incremental_rows']) is int
    assert v['full_rows']==v['incremental_rows'] and v['full_digest']==v['incremental_digest'] and isinstance(v['full_digest'],str)
    assert type(v['different_row_count']) is int and v['different_row_count']==0 and v['different_row_examples']==[]
   assert q['full_counts']['files']==q['incremental_counts']['files']==100000
   parities.append({'line':ln,'event':ev,'original_parity':q,'parity_wall_us':e['parity_wall_us'],'independent_config_fact':e['independent_config_fact']})
   if ev=='stage_finished':stages.append({'line':ln,**{k:v for k,v in e.items() if k!='parity'}})
  if ev=='mutation':mutations.append({'line':ln,'event':e})
assert raw_bytes==nr['summary']['raw_bytes'] and len(builds)==4 and len(parities)==2 and len(stages)==1 and len(mutations)==1
assert sum(not b['full'] for b in builds)==1 and [b['line'] for b in builds]==[4,6,10,12]
no=next(b for b in builds if not b['full']); stage=stages[0]
assert stage['passed'] and stage['complete'] and stage['full_complete'] and stage['no_op_unchanged'] and stage['incremental_builds']==1
assert no['report_fields']['files_parsed']==no['report_fields']['dirty_plan']['parsed_files']==1000 and no['report_fields']['files_scanned']==100000
assert no['report_fields']['build_timing']['full_staging_us'] is None and no['report_fields']['dirty_plan']['resumed'] is False
assert no['report_fields']['resolution_freshness']['status']=='ready'
assert no['report_fields']['files_updated']==1000 and no['report_fields']['files_skipped']==99000
assert mutations[0]['event']['requested_files']==1000 and len(mutations[0]['event']['operations'])==len(mutations[0]['event']['receipts'])==1000
art=official['inputs'][0]['artifact'];job=official['producer_job']
assert art==t['records'][0]['artifact'] and art['id']==11662340730 and art['digest']=='sha256:'+t['records'][0]['whole_zip']['sha256']
assert (job['id'],job['head_sha'],job['run_id'],job['run_attempt'],job['status'],job['conclusion'])==(114139258884,G,RUN,1,'completed','success')
assert all(s['conclusion']=='success' for s in job['steps'])

timing={'scope':'Each raw unit retained; full_staging and prepare_snapshot are nested within prepare, and legacy phase_timing is not an additive partition of build_timing. No cross-host or prior-study causal ratio.','raw_path':str(raw),'raw_bytes':raw_bytes,'raw_sha256':sha.hexdigest(),'original_BLAKE3_from_native_report':nr['raw_digest'],'builds':builds,'parities':parities,'stage':stage,'measurements':ret['measurements'],'mutation':mutations}
dump('original-timing-phase-and-parity-selection.json',timing)
report={'schema':'independent-original-batch1-100k-whole-acceptance-v1','reviewer':'/root/pr_triage','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':G,'run_id':RUN,'attempt':1,'result':'accepted_scoped_one_registered_batch1000_100k_cell','new_cells':1,'new_records':2,'roles':['setup','batch_1000 mutation'],'cumulative':{'cells':41,'expected_cells':45,'records':77,'expected_records':85,'setup':36,'mutation':36,'fanout':5,'cold_curve_selected_setup':5,'cold_curve_selected_scales':[1000,5000,10000,50000,100000]},'remaining':{'cells':4,'records':8,'population':'body/api/config/batch_100 at100k'},'cold_subset_boundary':'The no_op setup from the separately accepted prior cell supplies the fifth cold point. This batch_1000 setup remains retained but does not replace or add a sixth cold point. All original failed continuous studies remain failed/incomplete and are never pooled.','artifact':art,'whole_zip_identity_from_original_receiver':t['records'][0]['whole_zip'],'producer':job,'official_pagination_limit':official.get('observation_limit', 'Individual exact-name artifact query; not a full population enumeration. Original input retains the actual lookup metadata.'),'original_validator_execution':ex,'original_hash_utility_calls':2,'validate_build_reexecuted':False,'stdio_two_copies_return_receipt_equal':True,'source_build_and_shard_before_after_equal':True,'registry_sha256':ret['registration_sha256'],'task_build_receipt_sha256':ret['build_receipt_sha256'],'binary_blake3':registry['binary_blake3'],'binary_sha256':registry['binary_sha256'],'observer':ret['driver_source'],'plan':p,'native_report':nr,'engine':ret['engine'],'environment':ret['environment'],'profile_environment':ret['profile_environment'],'measurement_environment':ret['measurement_environment'],'resource_snapshots':ret['resource_snapshots'],'measurements':ret['measurements'],'phase_count_mapping':builds,'raw_event_counts':dict(counts),'raw_identity':{'bytes':raw_bytes,'sha256':sha.hexdigest(),'original_report_blake3':nr['raw_digest']},'typed_parity':{'observations':2,'tables_each':15,'equal_table_observations':30,'initial_raw_line':7,'final_raw_line':13,'different_rows':0,'reported_no_op_unchanged_flag':True,'initial_and_final_full_control_complete':True,'batch_1000_builds':1,'first_build_incomplete':False,'initial_and_final_capacity_profile':'scale_capacity_v1','canonical_bytes_initial_final':[q['original_parity']['canonical_bytes'] for q in parities],'scratch_peak_bytes_initial_final':[q['original_parity']['scratch_peak_bytes'] for q in parities]},'limits':['N1, one environment and fixed source/build. No stable tail, confidence interval, all100k/full-study or release claim.','Raw reports retain semantic vectors disabled/countnull, untracked Python caches, PID-only resource snapshots, observed seed-cache max500000 and hardware identity; no fabricated peak or clean host.','Timing scopes differ: engine elapsed_ms, detailed total_us, enclosing wall_us, parity_wall_us and native child wall_ms. Nested full_staging/prepare_snapshot are not added again.','Whole payload and producer completion are proven for this slot; concurrent artifact enumeration is not a final complete population index.','Original aggregate has not been executed or accepted by this peer; no task status updated.'],'peer_execution':{'read_only_original_returns_and_new_raw':True,'CRC_ZIP_ELF_original_validator_or_product_calls':0,'old_raw_or_ZIP_reads':0,'Actions_downloads':0},'task_credit':0,'reader_attempt_history':{'attempt01':'Pure independent new-slot receipt/raw reader; no original validator, ELF, CRC, ZIP or product operation.'},'initial_incomplete_resume_boundary':'Observed first and only batch_1000 build is complete/ready: parsed1000, selected_dependents0, file_budget200, resumedfalse. No incomplete or resume occurrence is fabricated. The independently accepted fanout records preserve their own actual incomplete/resume behavior.'}
dump('independent-batch1000-100k-review.json',report);dump('read-input-identities.json',list(inputs.values()))
print(json.dumps({'status':report['result'],'accepted_new_cells':1,'accepted_new_records':2,'cumulative':report['cumulative'],'native_wall_ms':nr['wall_ms'],'batch_1000_engine_ms':ret['measurements'][1]['engine_ms'],'batch_1000_parsed_files':no['report_fields']['files_parsed'],'cold_counts':ret['measurements'][0]['counts'],'new_original_function_executions_by_peer':0},ensure_ascii=False,indent=2))
