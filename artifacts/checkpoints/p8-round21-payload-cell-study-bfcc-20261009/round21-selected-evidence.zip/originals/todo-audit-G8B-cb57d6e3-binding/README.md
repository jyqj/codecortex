G8B mechanical binding generation from actual P8B 44e62481 and actual R8B cb57d6e3.

The original prepared generator ran once and returned integer exit 0. Only the five necessary registry fields and four guard identity pins changed; 1095 product inputs, 75 BASE deltas, and 142 unchanged validation inputs are bound. No product, v15 CLI, Rust tests, study, or task acceptance was executed. actual_G remains null in this frozen proposal.

Original R7 canonical/support and both diagnostic result ZIPs were retained through the six artifact-only R8 additions. SHA/OID/size of all six installed bytes matched the official compare. Original G6 scripts tree reconstructed from retained official tree plus its exact two binding blobs equals the actual R8 scripts-tree reference. The prospective G8 tree is d8891f547c92044fd40b63165d6ef54cb6de8bab.

Prepared generator and immutable seeds are separately preserved in /dev/shm/todo-audit-G8B-binding-preparation/archive-selection.json (SHA256 325cf66c7132851417dc413dfe90933a1b90c4e284a89753a4df1a65927c7a2b).
