#!/usr/bin/env python3
"""Session-local execution receipt; never changes repository inputs."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
root = Path('/workspace/scratch/031390cf22eb/codecortex-scale')
output = Path('/workspace/scratch/031390cf22eb/validation-scale')
output.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(root / 'scripts'))
from p7_build_identity import source_snapshot

label, *command = sys.argv[1:]
if not command or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789_-' for c in label):
    raise SystemExit('usage: record_validation.py LABEL COMMAND...')
receipt = {
    'label': label,
    'command': command,
    'cwd': str(root),
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'environment': {k: os.environ[k] for k in (
        'CARGO_HOME', 'RUSTUP_HOME', 'CARGO_TARGET_DIR', 'RUSTUP_TOOLCHAIN',
        'CARGO_TERM_COLOR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL',
        'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'RUSTFLAGS',
        'CODECORTEX_BENCH_PROCESS_PROBE', 'CODECORTEX_CACHE_DIR',
        'CODECORTEX_SEMANTIC_CACHE_ROOT') if k in os.environ},
    'rustc': subprocess.check_output(['rustc', '--version', '--verbose'], text=True),
    'cargo': subprocess.check_output(['cargo', '--version'], text=True).strip(),
    'source_before': source_snapshot(root),
}
path = output / (label + '.json')
log = output / (label + '.log')
receipt['log_path'] = str(log)
receipt['status'] = 'running'
path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({'label': label, 'status': 'running', 'command': command, 'log_path': str(log)}), flush=True)
started = time.monotonic()
with log.open('wb') as stream:
    result = subprocess.run(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
receipt.update({
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'elapsed_seconds': round(time.monotonic() - started, 3),
    'exit_code': result.returncode,
    'status': 'passed' if result.returncode == 0 else 'failed',
    'source_after': source_snapshot(root),
})
receipt['source_unchanged'] = receipt['source_before'] == receipt['source_after']
path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: receipt[k] for k in ('label', 'status', 'exit_code', 'elapsed_seconds', 'source_unchanged', 'log_path')}), flush=True)
raise SystemExit(result.returncode if receipt['source_unchanged'] else 99)
