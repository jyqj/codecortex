#!/usr/bin/env python3
"""Pure receiver lifecycle control; no artifact or product result is asserted."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
PATH = Path('/workspace/scratch/2eaa00d0f93a/p8-staging-engineering-publication-root/receive_engineering.py')
source = PATH.read_bytes()
expected = '5e4878a3facda9d817ec95c03b1e496832cb581e2ef60d072c91514387a7c7be'
assert hashlib.sha256(source).hexdigest() == expected
(HERE / 'receive_engineering-v1.py').write_bytes(source)
spec = importlib.util.spec_from_file_location('receiver_under_review', PATH)
receiver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(receiver)
root = HERE / 'synthetic-reception'
root.mkdir()
directory = root / 'synthetic-controls'
directory.mkdir()
target = directory / 'original'
target.mkdir()
before = receiver.original.source_snapshot(receiver.SOURCE_ROOT)
for name in ('source-before.json', 'source-after.json'):
    (target / name).write_bytes(receiver.original.json_bytes(before))
original_inventory = receiver.original.inventory
members = original_inventory(target)
proof = {'artifact': {'name': f'p8-staging-controls-{receiver.RUN}'}, 'members': members}
job = {'status': 'completed', 'conclusion': 'success', 'id': 113604866890, 'name': 'controls_and_build'}
interrupts = []
def interrupt_final_inventory(path, *args, **kwargs):
    if Path(path) == target:
        interrupts.append('SIGINT at final inventory, after tentative verdict')
        os.kill(os.getpid(), signal.SIGINT)
        raise AssertionError('SIGINT did not interrupt')
    return original_inventory(path, *args, **kwargs)

exception = None
with patch.object(receiver, 'RECEPTION', root), \
     patch.object(receiver, 'receive', return_value=(target, proof, {}, job)), \
     patch.object(receiver, 'inspect_controls', return_value={'status': 'accepted_scoped_actual_engineering_controls'}), \
     patch.object(receiver.original, 'inventory', side_effect=interrupt_final_inventory), \
     patch.object(sys, 'argv', [str(PATH), '--kind', 'controls', '--artifact-directory', str(directory)]):
    try:
        receiver.main()
    except BaseException as error:
        exception = type(error).__name__
inspection = json.loads((directory / 'inspection.json').read_bytes())
assert exception == 'KeyboardInterrupt' and len(interrupts) == 1
assert inspection['status'] == 'accepted_scoped_actual_engineering_controls'
assert inspection['source_and_driver_unchanged'] is True
assert PATH.read_bytes() == source
result = {'scope': 'Explicit synthetic lifecycle fixture; receive and test verdict are injected, actual SIGINT interrupts final inventory. No real artifact or product test.',
          'receiver_sha256': expected, 'exception': exception, 'interrupts': interrupts,
          'retained_verdict': inspection['status'], 'source_and_driver_unchanged': inspection['source_and_driver_unchanged'],
          'finding': 'Interrupted inspection can retain an accepted verdict before all acceptance checks complete.',
          'Cargo_executed': False, 'native_executed': False, 'new_TODO_done': 0, 'TODO_remaining': 29}
(HERE / 'interrupt-reproduction.json').write_bytes(receiver.original.json_bytes(result))
print(json.dumps(result, ensure_ascii=False))
