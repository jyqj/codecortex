"""Prepare a byte-proven cleanup candidate after an accepted exact E audit.

Does not delete, run products, change originals, or replay acceptance.
"""
import argparse, datetime, hashlib, json, pathlib, stat, zipfile
p=argparse.ArgumentParser();p.add_argument('artifact_id',type=int);p.add_argument('label');a=p.parse_args()
base=pathlib.Path('/dev/shm/a217aaae3bde/runtime-review/e-a23-artifact-review')
assert a.label in {f'mixed-c{c}-{a.artifact_id}' for c in (1,4,8,16)} | {f'soak-{a.artifact_id}'}
root=base/'actual-originals'/str(a.artifact_id)/'extracted'
archive=pathlib.Path('/workspace/scratch/a217aaae3bde/ci-artifacts')/str(a.artifact_id)/(str(a.artifact_id)+'.zip')
out=base/(a.label+'-derived-cleanup-candidate.json');inventory_path=base/(a.label+'-derived-cleanup-files-attempt2.json')
assert not out.exists() and not inventory_path.exists()
def sha(path):
 h=hashlib.sha256()
 with pathlib.Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def ref(path):
 path=pathlib.Path(path);return dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path))
review=base/'accepted'/f'artifact-{a.artifact_id}-a23bb72d-independent-final'/'independent-review.json'
r=json.loads(review.read_text());assert r['artifact_id']==a.artifact_id and r['head']=='a23bb72d3c954f385b99fe81ce9189885c208557' and r['status']=='accepted_scoped'
process=base/(a.label+'-review-process.json');assert json.loads(process.read_text())['exit_code']==0
zip_before=ref(archive);assert zip_before['sha256']==r['zip_sha256'] and zip_before['bytes']==r['zip_bytes']
files,dirs=set(),set()
for path in root.rglob('*'):
 assert not path.is_symlink()
 if path.is_dir():dirs.add(str(path.relative_to(root)))
 else:assert path.is_file();files.add(str(path.relative_to(root)))
rows=[]
with zipfile.ZipFile(archive) as z:
 expected={m.filename for m in z.infolist() if not m.is_dir()};expected_dirs=set()
 for name in expected:expected_dirs.update(str(x) for x in pathlib.PurePosixPath(name).parents if str(x)!='.')
 assert files==expected and dirs==expected_dirs
 for name in sorted(expected):
  path=root/name;s=path.stat();assert stat.S_IMODE(s.st_mode)==0o444 and s.st_size==z.getinfo(name).file_size
  h=hashlib.sha256();n=0
  with z.open(name) as original,path.open('rb') as derived:
   for b in iter(lambda:original.read(1048576),b''):
    assert derived.read(len(b))==b;h.update(b);n+=len(b)
   assert derived.read(1)==b''
  now=path.stat();assert (now.st_ino,now.st_size,now.st_mtime_ns,now.st_ctime_ns)==(s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
  rows.append(dict(path=name,bytes=n,sha256=h.hexdigest(),mode='0444',device=now.st_dev,inode=now.st_ino,nlink=now.st_nlink,mtime_ns=now.st_mtime_ns,ctime_ns=now.st_ctime_ns,allocated_bytes=now.st_blocks*512))
assert ref(archive)==zip_before
inventory_path.write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
record=dict(schema_version=1,checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='exact_single_accepted_runtime_derived_extraction_candidate',candidate_directory=str(root),artifact_id=a.artifact_id,file_count=len(rows),directory_count=len(dirs),logical_bytes=sum(x['bytes'] for x in rows),possible_allocated_release_bytes=sum(x['allocated_bytes'] for x in rows if x['nlink']==1),every_member_streamed_byte_identical_to_original_zip=True,no_extra_files_or_directories=True,no_symlinks=True,all_mode0444=True,inventory=ref(inventory_path),original_zip=zip_before,original_metadata=ref(archive.parent/'artifact-metadata.json'),preserved_review=ref(review),preserved_exact_process_receipt=ref(process),path_alias=ref(base/(a.label+'-path-alias.json')),preserved_frozen_manifest=ref(base/'frozen-helper-manifest.json'),deletion_performed=False,known_owner_dependency='Frozen original audit and retained native replay subprocesses completed with actual exit0. Runtime owner has no current/future reader/writer dependency on this extraction; not a system-wide PID assertion.',parent_action='Immediately recheck this exact inventory against extracted bytes and immutable ZIP, then delete only candidate_directory. Preserve original ZIP/metadata/path alias, every review/replay output and process receipt, source and frozen helper.',native_measurements_or_acceptance_rerun=False,formal_task_completion=False,done=163,remaining=29)
out.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(receipt=ref(out),files=len(rows),possible_allocated_release_bytes=record['possible_allocated_release_bytes'])))
