from pathlib import Path,PurePosixPath
import json,hashlib,zipfile,stat,re,datetime,difflib
BASE=Path("/workspace/scratch/bfccb8494ba0");OUT=Path("/dev/shm/pr-triage-round15-P1-native-peer")
Z=BASE/"root-round15/native-controls-transfer/native-db-observation-P0-P1-controls-round15.zip";EXTRACTED=Z.parent/"extracted"
P0="3ced45d1f4bbfc38eeab3fbe1a1ef17eae26721a";P1="bb290be2deaf4334863e09dbf47fe4ccc9625f2b";TREE="4dbe8ee3d09701c8563f42695b483ae104da0a2a"
def h(b):return hashlib.sha256(b).hexdigest()
def gb(b,t="blob"):return hashlib.sha1(t.encode()+b" "+str(len(b)).encode()+b"\0"+b).hexdigest()
def desc(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=h(b),git_blob=gb(b))
assert Z.stat().st_size==3702778 and h(Z.read_bytes())=="9c7ca53255dc31ce54fd77a91b9852436631560f0344218ef624429ffac547d0" and gb(Z.read_bytes())=="8fea67def09ac9931509a2b7761819953fe493fb"
data={};member_rows=[]
with zipfile.ZipFile(Z) as z:
 for i in z.infolist():
  n=PurePosixPath(i.filename);assert i.orig_filename==i.filename and "\0" not in i.orig_filename and not i.is_dir()
  assert not n.is_absolute() and ".." not in n.parts and str(n)==i.filename and i.filename not in data
  assert not stat.S_ISLNK(i.external_attr>>16)
  b=z.read(i);assert len(b)==i.file_size and (EXTRACTED/i.filename).read_bytes()==b
  data[i.filename]=b;member_rows.append(dict(path=i.filename,bytes=len(b),sha256=h(b),crc32=i.CRC))
manifest=json.loads(data["archive-manifest.json"])
assert len(data)==135 and len(manifest["files"])==134 and {x["path"] for x in manifest["files"]}==set(data)-{"archive-manifest.json"}
for x in manifest["files"]:
 b=data[x["path"]];assert len(b)==x["bytes"] and h(b)==x["sha256"]
def j(n):return json.loads(data[n])
def tree(raw):
 d={}
 for x in raw.split(b"\0"):
  if not x:continue
  left,n=x.split(b"\t",1);mode,kind,blob=left.decode().split();assert kind=="blob" and n.decode() not in d
  d[n.decode()]={"mode":mode,"git_blob":blob}
 return d
source_audit_paths={P0:BASE/"scale-intake-primary/db-wait-cleanup-P-3ced-independent/actual-P-complete-source-audit.json",P1:BASE/"scale-intake-primary/db-wait-cleanup-P-bb29-independent/actual-P1-complete-source-audit.json"}
source_hashes={P0:"f7b654299ff8b26920fe4a0fb89ae068b749a573761270227c829c9340c45692",P1:"3a15a6b13bd76dd78118b620070c7d2dfad9e2d7ca08c4f069ea9b55f56f6d66"}
baselines={};canonicals={};extra={};prep=[]
for phase,commit in [("P0-negative",P0),("P1-controls",P1)]:
 cp=source_audit_paths[commit];assert h(cp.read_bytes())==source_hashes[commit];ca=json.loads(cp.read_bytes());canonicals[commit]=ca
 b=j(phase+"/before-domain-receipt.json");assert b["source_P"]==commit
 assert gb(data[phase+"/actual-P-object.stdout"],"commit")==commit
 assert data[phase+"/actual-P-object.stdout"].decode().startswith("tree "+b["tree"]+"\n")
 rows={x["path"]:x for x in b["entries"]};assert len(rows)==len(b["entries"])==1250
 git=tree(data[phase+"/official-domain-ls-tree.stdout"]);assert set(git)==set(rows)
 for n,x in rows.items():assert {k:x[k] for k in ("mode","git_blob")}==git[n]
 for n,e in ca["actual_input_mode_blob_inventory"].items():
  x=rows[n];assert x["mode"]==e["mode"] and x["git_blob"]==e["sha"] and x["sha256"]==e["sha256"] and x["bytes"]==e["size"]
 assert len(ca["complete_inputs"])==1095 and len(ca["validation_inputs"])==142
 baselines[phase]=rows;extra[phase]=[x for n,x in rows.items() if n not in ca["actual_input_mode_blob_inventory"]];assert len(extra[phase])==13
 for c in j(phase+"/preparation-receipts.json"):
  assert type(c["exit_code"]) is int and c["exit_code"]==0
  for k in ("stdout","stderr"):
   e=c[k];raw=data[phase+"/"+e["path"]];assert len(raw)==e["bytes"] and h(raw)==e["sha256"]
  prep.append({"phase":phase,"label":c["label"],"exit_code":c["exit_code"]})
assert canonicals[P1]["source"]==P1 and canonicals[P1]["tree"]==TREE and canonicals[P1]["parents"]==[P0]
delta=sorted(n for n in baselines["P1-controls"] if baselines["P1-controls"][n]!=baselines["P0-negative"][n])
assert delta==["crates/cc-db/src/lock_observation.rs","crates/cc-server/tests/p8_db_lock_observation.rs"]
commands=[];method_sets={};rust_total=0;rust_phase={"P1-first":0,"P1-continuation":0};input_maps=0
for n in sorted(data):
 if not n.endswith("-receipt.json"):continue
 r=j(n)
 if not isinstance(r,dict) or "test_kind" not in r:continue
 phase="P0-negative" if n.startswith("P0-negative/") else "P1-controls";commit=P0 if phase=="P0-negative" else P1
 loc=str(PurePosixPath(n).parent)
 assert r["source_P"]==commit and type(r["exit_code"]) is int
 assert "controller_budget_seconds" not in r
 for k in ("stdout","stderr","before","after"):
  e=r[k];raw=data[loc+"/"+e["path"]];assert len(raw)==e["bytes"] and h(raw)==e["sha256"],(n,k)
 for k in ("before","after"):
  sm=j(loc+"/"+r[k]["path"]);assert sm["source_P"]==commit and sm["tree"]==r["tree"]
  assert sm["entries"]==list(baselines[phase].values());assert len(sm["entries"])==1250;input_maps+=1
 stdout=data[loc+"/"+r["stdout"]["path"]].decode();stderr=data[loc+"/"+r["stderr"]["path"]].decode();full=stdout+stderr
 results=[dict(passed=int(a),failed=int(b),ignored=int(c),measured=int(d),filtered_out=int(e)) for a,b,c,d,e in re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;",full)]
 named=re.findall(r"^test (\S+) \.\.\. ok$",full,re.M)
 entry={"receipt_member":n,"phase":("P0-negative" if phase=="P0-negative" else "P1-continuation" if "/continuation-canonical-temp/" in n else "P1-first"),"label":r["label"],"source_P":commit,"tree":r["tree"],"cwd":r["cwd"],"command":r["command"],"test_kind":r["test_kind"],"started_at":r["started_at"],"ended_at":r["ended_at"],"elapsed_seconds":r["elapsed_seconds"],"pid":r["pid"],"exit_code":r["exit_code"],"before":r["before"],"after":r["after"],"stdout":r["stdout"],"stderr":r["stderr"],"environment":r["environment"],"rust_results":results,"named_rust_methods":named}
 if r["test_kind"]=="rust":
  assert r["exit_code"]==0 and len(results)==1 and results[0]["passed"]==r["expected_test_count"]==len(named)>0
  assert results[0]["failed"]==results[0]["ignored"]==results[0]["measured"]==0
  rust_total+=len(named);rust_phase[entry["phase"]]+=len(named)
 elif r["test_kind"]=="python":
  counts=re.findall(r"Ran (\d+) tests? in ([\d.]+)s",full);assert len(counts)==1 and int(counts[0][0])==77
  methods=re.findall(r"^(test_\S+ \([^\n]+\)) \.\.\. (ok|FAIL|ERROR|skipped[^\n]*)$",full,re.M)
  assert len(methods)==77 and len({m[0] for m in methods})==77
  method_sets[entry["phase"]]={a:b for a,b in methods}
  failures=len([b for a,b in methods if b=="FAIL"]);errors=len([b for a,b in methods if b=="ERROR"]);passed=len([b for a,b in methods if b=="ok"])
  entry["python_results"]={"executed":77,"passed":passed,"failures":failures,"errors":errors,"skipped":0,"seconds_from_original_summary":float(counts[0][1]),"methods":[{"method":a,"status":b} for a,b in methods]}
  if entry["phase"]=="P1-first":assert r["exit_code"]==1 and failures==10 and errors==6 and "FAILED (failures=10, errors=6)" in full
  else:assert r["exit_code"]==0 and passed==77 and re.search(r"^OK\s*$",full,re.M)
 commands.append(entry)
assert len(commands)==17 and input_maps==34 and rust_total==60 and rust_phase=={"P1-first":10,"P1-continuation":50}
assert set(method_sets["P1-first"])==set(method_sets["P1-continuation"])
by={(x["phase"],x["label"]):x for x in commands}
assert by[("P0-negative","locked-dependency-fetch")]["exit_code"]==0
assert by[("P0-negative","workspace-format")]["exit_code"]==1
assert by[("P1-first","workspace-format")]["exit_code"]==0
for label in ("cc-db-default-strict-clippy","cc-db-observation-strict-clippy"):
 r=by[("P1-continuation",label)];assert r["exit_code"]==0 and "-D" in r["command"] and "warnings" in r["command"] and "--all-targets" in r["command"]
 assert r["command"][r["command"].index("-p")+1]=="cc-db"
first=by[("P1-first","all-original-runtime-python-controls")];last=by[("P1-continuation","all-original-runtime-python-controls")]
assert first["command"]==last["command"] and first["cwd"]==last["cwd"] and first["tree"]==last["tree"]
assert {k:v for k,v in last["environment"].items() if k!="TMPDIR"}==first["environment"]
tmp=j("P1-controls/continuation-canonical-temp/canonical-temp-provision-and-continuation.json")
assert tmp["new_TMPDIR"]==tmp["resolved_new_TMPDIR"]==last["environment"]["TMPDIR"] and tmp["owned_directory_created"] is True
probe=j("P1-controls/python-failure-diagnosis/initial-path-observation.json")
assert probe["exit_code"]==0 and probe["current_environment_observation"]["same_spelling"] is False
assert probe["current_environment_observation"]["TMPDIR"]==tmp["old_TMPDIR_observed_in_controller"]
assert first["before"]["sha256"]==last["before"]["sha256"] and first["after"]["sha256"]==last["after"]["sha256"]
controller=data["P1-controls/controls-controller.py"].decode();continuation=data["P1-controls/continuation-canonical-temp/controls-controller.py"].decode()
diff="\n".join(difflib.unified_diff(controller.splitlines(),continuation.splitlines(),fromfile="original-P1-controller",tofile="original-P1-continuation-controller"))+"\n"
for s in [controller,continuation]:
 assert "subprocess.Popen(cmd,cwd=root,env=env,stdout=so,stderr=se)" in s and "code=child.wait(timeout=max(1,5400-(time.monotonic()-total_start)))" in s and "r.update(exit_code=code" in s and "assert head(root)==P" in s
 assert "b=p.read_bytes()" in s and "assert row==e" in s
clone=j("P1-controls/target-clone-receipt.json");assert clone["exit_code"]==0 and clone["command"][:2]==["/bin/cp","-cR"]
assert clone["command"][-1]==first["environment"]["CARGO_TARGET_DIR"]
bridge=j("P1-controls/unchanged-locked-dependency-fetch-bridge.json");assert bridge["source_P0"]==P0 and bridge["source_P1"]==P1 and bridge["fetch_executed_at_P0"]["exit_code"]==0
for n,e in bridge["unchanged_dependency_inputs"].items():assert baselines["P0-negative"][n]==baselines["P1-controls"][n]==e
failure_raw=data["P1-controls/all-original-runtime-python-controls.stderr"].decode()
sections=re.split(r"^={10,}\n",failure_raw,flags=re.M)[1:]
signatures=[{"test":s.splitlines()[0],"exception_lines":[l for l in s.splitlines() if l.startswith(("ValueError:","AssertionError:","KeyError:"))]} for s in sections]
assert len(signatures)==16
report={
"schema_version":1,"reviewed_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"verdict":"accepted_scoped_actual_P1_focused_native_controls_with_initial_failures_preserved",
"reviewer":"pr_triage (non-author; retained-evidence verification only)","source_P1":P1,"tree":TREE,"parent_P0":P0,
"original_ZIP":desc(Z),"ZIP_verification":{"members":135,"original_manifest_files":134,"all_member_CRC_and_SHA":True,"all_existing_extracted_bytes_equal_original_ZIP":True,"unsafe_or_duplicate_members":0},
"source_binding":{"selected_entries_per_snapshot":1250,"original_command_count":17,"snapshots_checked":34,"all_before_after_entry_arrays_equal_the_exact_phase_baseline":True,"before_after_file_byte_equality_not_claimed":"JSON label/phase metadata differs; compare every 1250 path/bytes/SHA/mode/Gitblob entry. Repeated P1 Python before and after files are respectively byte-identical across first/continuation.","actual_P1_product_inputs":1095,"actual_P1_validation_inputs":142,"all_1237_match_independent_actual_P1_Git_inventory":True,"additional_13_selected_inputs":extra["P1-controls"],"P0_to_P1_selected_delta":delta,"actual_both_commit_object_hashes_reconstructed":True,"P1_canonical_source_audit":desc(source_audit_paths[P1]),"P0_canonical_source_audit":desc(source_audit_paths[P0])},
"counts":{"P0":{"fetch_exit":0,"fmt_exit":1,"Rust_or_Python_tests_started":0},"P1_first":{"fmt_exit":0,"Rust_passed":10,"Python_executed":77,"Python_passed":61,"Python_failures":10,"Python_errors":6,"Python_exit":1},"P1_continuation":{"Python_passed":77,"Python_failed":0,"Python_errors":0,"Python_skipped":0,"Rust_passed":50,"Rust_failed":0,"Rust_ignored":0,"default_cc_db_strict_Clippy_exit":0,"feature_cc_db_strict_Clippy_exit":0},"unique_passing_scope":{"Rust":60,"Python_methods":77,"Rust_ignored":0,"Python_skipped":0},"repeated_Python_attempts_not_summed":True},
"python_method_sets_identical_across_attempts":True,"first_python_failure_signatures":signatures,
"environment_review":{"actual_cwd":first["cwd"],"common_recorded_environment":first["environment"],"continuation_added_TMPDIR":last["environment"]["TMPDIR"],"old_TMPDIR_observed":tmp["old_TMPDIR_observed_in_controller"],"original_path_probe":probe,"controller_diff_file":"P1-controller-to-continuation.diff","finding":"Same actual P1/1250 input arrays, same Python argv/cwd/target and common recorded environment; continuation explicitly creates and selects a fresh canonical TMPDIR. Its controller also writes a new output directory, reuses the existing P1 target instead of cloning again, and skips already-passed commands. Test assertions, source and full Python discovery are unchanged.","causal_limit":"Initial child receipt did not include TMPDIR; later same-project probe and continuation old-value record show /var alias vs /private canonical spelling. Neither receipt is a full inherited-environment dump. Therefore this proves the successful canonical-TMPDIR execution and preserves a path-sensitive first failure; it does not establish every inherited variable unchanged or universal correctness under the former noncanonical path.","failure_interpretation":"13 initial failures/errors surface the runtime Cargo target-path contract before intended branches; 3 finalization controls miss expected metadata/exit behavior. Their unchanged-method continuation succeeds under canonical TMPDIR. No product fix or relaxed path check is inferred from success alone."},
"cache_and_toolchain":{"target_clone":clone,"recorded_cargo_launcher":"/Users/jin/.cargo/bin/cargo +1.95.0","recorded_RUSTUP_TOOLCHAIN":"1.95.0","recorded_SDKROOT":"/Library/Developer/CommandLineTools/SDKs/MacOSX15.4.sdk","cold_claim":False,"scope":"Original cached engineering controls, not new release-performance build identity. This native archive binds explicit launcher/env and child results; it is not a new compiler-binary-digest measurement.","locked_dependencies":bridge["scope"]},
"command_results":commands,
"separate_scope":["No original workload, release diagnostic build, four-C measurements, fullscale, new v15 source admission or original TODO closure was executed by this reviewer.","60 focused Rust controls and package cc-db Clippy are not a full cargo test --workspace or all-workspace Clippy claim.","P1 contains the reviewed older b715 PR184 cleanup donor; later ae033 PR184 and new-main4ef changes are not tested by this P1 execution.","Root/execution_recon own any next actual R/G and subsequent integrated source. This report is exact P1 only."],
"task_ledger":{"done":163,"remaining":29,"new_completions":0}
}
def save(n,b):
 with (OUT/n).open("xb") as f:f.write(b)
save("P1-controller-to-continuation.diff",diff.encode())
save("original-ZIP-member-verification.json",(json.dumps({"schema_version":1,"original_zip":desc(Z),"files":member_rows,"exit_code":0},indent=2)+"\n").encode())
save("independent-P1-native-execution-review.json",(json.dumps(report,ensure_ascii=False,indent=2)+"\n").encode())
print(json.dumps({"verdict":report["verdict"],"ZIP_files":134,"snapshots":input_maps,"all_snapshot_entries":1250,"Rust_unique_passed":60,"Python_continuation_passed":77,"first_Python_failures_preserved":[10,6],"exit_code":0}))

