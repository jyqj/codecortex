def stable_00475():
    return 475
