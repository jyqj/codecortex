import pathlib,json,hashlib,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
def meta(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git_blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
files=sorted([p for p in ROOT.rglob('*') if p.is_file() and 'sealed' not in p.parts and p.name not in {'sealing.stdout','sealing.stderr'}])
entries=[dict(path=p.relative_to(ROOT).as_posix(),local_path=str(p),**meta(p.read_bytes())) for p in files]
out=ROOT/'sealed';out.mkdir()
selection=(json.dumps({'schema':'PR199-two-finite-official-observations-v1','files':entries,'scope':'Original official metadata and static exact-method lookup only; no workflow logs or artifacts downloaded.'},indent=2)+'\n').encode()
(out/'archive-selection.json').write_bytes(selection)
zpath=out/'official-observation-originals.zip'
with zipfile.ZipFile(zpath,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for e in entries:z.write(e['local_path'],e['path'])
    z.writestr('archive-selection.json',selection)
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    for e in entries:assert meta(z.read(e['path']))=={k:e[k] for k in ['bytes','sha256','git_blob']}
prefix='artifacts/checkpoints/p8-round31-PR199-initial-CI-bfcc-20261010'
summary=(ROOT/'at-0020/summary.json').read_bytes()
manifest={'files':[dict(path=prefix+'/summary.json',local_path=str(ROOT/'at-0020/summary.json'),**meta(summary)),dict(path=prefix+'/official-observation-originals.zip',local_path=str(zpath),**meta(zpath.read_bytes()))]}
(out/'upload-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest))
