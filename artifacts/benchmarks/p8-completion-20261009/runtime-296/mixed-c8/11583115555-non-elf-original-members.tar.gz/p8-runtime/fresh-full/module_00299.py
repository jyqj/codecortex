def stable_00299():
    return 299
