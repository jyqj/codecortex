def stable_00335():
    return 335
