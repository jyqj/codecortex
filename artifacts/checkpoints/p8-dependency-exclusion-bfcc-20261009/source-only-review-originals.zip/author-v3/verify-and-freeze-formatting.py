#!/usr/bin/env python3
"""Mechanical text/Git verification only. Does not invoke rustfmt, Rust, tests or CI."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
V2 = Path('/dev/shm/todo-audit-H-dependency-exclusion-v2')
PLAN = Path('/dev/shm/todo-audit-P3-H-d22-candidate-plan')
P3 = '9c1605118edcb7e88d211c3f6bd31249ebe36dc7'
P3_TREE = '5ac4d3fb96cfb11433d529b8292d1e7652471036'
FILES = ['crates/cc-db/src/resolution_dependency_store.rs', 'crates/cc-db/tests/p2b_resolution_store.rs']

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def tokens(text):
    """Preserve literals/comments exactly; whitespace outside tokens is ignored."""
    out = []
    i = 0
    while i < len(text):
        start = i
        if text[i].isspace():
            i += 1
            continue
        if text.startswith('//', i):
            end = text.find('\n', i)
            i = len(text) if end < 0 else end
        elif text.startswith('/*', i):
            depth = 1
            i += 2
            while depth:
                assert i < len(text)
                if text.startswith('/*', i):
                    depth += 1
                    i += 2
                elif text.startswith('*/', i):
                    depth -= 1
                    i += 2
                else:
                    i += 1
        else:
            raw = re.match(r'(?:br|cr|r)(#*)"', text[i:])
            quoted = re.match(r'(?:b|c)?"', text[i:])
            char = re.match(r"(?:b)?'(?:\\(?:u\{[0-9A-Fa-f_]+\}|x[0-9A-Fa-f]{2}|.)|[^'\\])'", text[i:])
            ident = re.match(r'(?:r#)?[^\W\d]\w*', text[i:], re.UNICODE)
            number = re.match(r'[0-9][A-Za-z0-9_]*(?:\.[0-9][A-Za-z0-9_]*)?', text[i:])
            if raw:
                close = '"' + raw.group(1)
                end = text.find(close, i + len(raw.group()))
                assert end >= 0
                i = end + len(close)
            elif quoted:
                i += len(quoted.group())
                while True:
                    assert i < len(text)
                    if text[i] == '\\':
                        i += 2
                    elif text[i] == '"':
                        i += 1
                        break
                    else:
                        i += 1
            elif char:
                i += len(char.group())
            elif ident:
                i += len(ident.group())
            elif number:
                i += len(number.group())
            else:
                compound = next((s for s in ['<<=', '>>=', '..=', '::', '->', '=>', '==', '!=', '<=', '>=', '&&', '||', '+=', '-=', '*=', '/=', '%=', '&=', '|=', '^=', '<<', '>>', '..'] if text.startswith(s, i)), None)
                i += len(compound) if compound else 1
        out.append({'token': text[start:i], 'line': text.count('\n', 0, start) + 1, 'offset': start})
    return out

def comma_context(tok, position):
    stack = []
    for i, item in enumerate(tok[:position]):
        value = item['token']
        if value in ['(', '[', '{']:
            previous = [x['token'] for x in tok[max(0, i-3):i]]
            stack.append((value, previous, item['line']))
        elif value in [')', ']', '}']:
            opener, _, _ = stack.pop()
            assert (opener, value) in [('(', ')'), ('[', ']'), ('{', '}')]
    opener, previous, line = stack[-1]
    assert tok[position+1]['token'] in [')', ']', '}']
    if opener == '(':
        assert previous and re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*', previous[-1])
        kind = 'function_or_constructor_argument_list'
    elif opener == '[':
        kind = 'array_literal'
    else:
        raise AssertionError('No struct formatting insertion is expected here')
    return {'kind': kind, 'preceding_tokens': previous, 'opening_line': line}

def main():
    verification = []
    replacements = []
    patches = []
    for name in FILES:
        before = (V2/'candidate'/name).read_bytes()
        after = (HERE/'candidate'/name).read_bytes()
        a, b = tokens(before.decode()), tokens(after.decode())
        at, bt = [v['token'] for v in a], [v['token'] for v in b]
        inserts = []
        stripped = bt.copy()
        matcher = difflib.SequenceMatcher(a=at, b=bt, autojunk=False)
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == 'equal':
                continue
            assert tag == 'insert' and i1 == i2 and bt[j1:j2] == [','], (name, tag, at[i1:i2], bt[j1:j2])
            context = comma_context(b, j1)
            inserts.append({'v2_before_token_index': i1, 'v3_token_index': j1, 'v3_line': b[j1]['line'], 'token': ',', **context})
        for item in reversed(inserts):
            del stripped[item['v3_token_index']]
        assert stripped == at
        token_raw = json.dumps(at, ensure_ascii=False, separators=(',', ':')).encode()
        verification.append({'path': name, 'v2_bytes': len(before), 'v2_sha256': sha(before), 'v2_git_blob': blob(before), 'v3_bytes': len(after), 'v3_sha256': sha(after), 'v3_git_blob': blob(after), 'all_nonwhitespace_tokens_equal_except_listed_optional_trailing_commas': True, 'literal_and_comment_tokens_byte_equal': True, 'optional_trailing_comma_insertions': inserts, 'v2_token_count_including_comments': len(at), 'v3_token_count_including_comments': len(bt), 'normalized_token_list_sha256': sha(token_raw)})
        patches.append(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile='a/'+name, tofile='b/'+name)))
        replacements.append({'path': name, 'mode': '100644', 'type': 'blob', 'sha': blob(after)})
    (HERE/'v2-to-v3-format-only.patch').write_text(''.join(patches))
    result = {'scope': 'Manual formatting, no rustfmt execution; exact token comparison with each optional trailing comma identified', 'Rust_execution': 'not_run', 'rustfmt_execution': 'not_run', 'CI_execution': 'not_run', 'files': verification}
    (HERE/'format-token-equivalence.json').write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    # Reuse only pure function definitions, never import/run the old plan module.
    module = ast.parse((PLAN/'verify-prospective-plan.py').read_text())
    namespace = {'hashlib':hashlib}
    code = ast.Module(body=[n for n in module.body if isinstance(n,ast.FunctionDef) and n.name in ['oid','tree_oid','leaf_map']],type_ignores=[])
    exec(compile(code,'retained-pure-Git-functions','exec'),namespace)
    load = lambda p:json.loads(Path(p).read_text())
    leaves = namespace['leaf_map'](load('/dev/shm/todo-audit-p8007-final-main-integration/actual-P2/actual-P2-complete-derived-Git-tree.json'))
    for item in load('/dev/shm/execution-recon-recovery-20261009/final-R2/upload-manifest.json')['files']:
        leaves[item['repository_path']]={'mode':'100644','type':'blob','sha':item['git_blob']}
    for req in ['/dev/shm/todo-audit-G2-cd68-binding/two-binding-create-tree-request.json','/dev/shm/todo-audit-G2-cd68-binding/future-H-20-artifact-create-tree-request.json',str(PLAN/'prospective-P3-create-tree-request.json')]:
        data=load(req)
        assert namespace['tree_oid'](leaves)==data['base_tree']
        for row in data['tree']:
            leaves[row['path']]={k:row[k] for k in ['mode','type','sha']}
    assert namespace['tree_oid'](leaves)==P3_TREE
    for row in replacements:
        leaves[row['path']]={k:row[k] for k in ['mode','type','sha']}
    tree=namespace['tree_oid'](leaves)
    request={'base_tree':P3_TREE,'tree':replacements}
    (HERE/'P3f-create-tree-request.json').write_text(json.dumps(request,sort_keys=True,indent=2)+'\n')
    maps=load(PLAN/'prospective-P3-complete-product-validation-inputs.json')
    for v in verification:
        path=v['path']
        maps['complete_inputs'][path]=v['v3_sha256']
        maps['paths'][path]['sha256']=v['v3_sha256']
        row=maps['actual_input_mode_blob_inventory_from_source_except_two_prospective_rows'][path]
        row.update(sha=v['v3_git_blob'],size=v['v3_bytes'])
    for key in ['actual_P3','expected_tree','required_ordered_parents','local_replacement_files','all_H_leaves_preserved_except_three_declared_replacements']:
        maps.pop(key,None)
    maps.update(actual_P3f=None,actual_parent_P3=P3,actual_parent_tree=P3_TREE,expected_P3f_tree=tree,required_ordered_parents=[P3],formatting_only=True,Rust_execution='not_run',rustfmt_execution='not_run',source_identity_basis='actual parent P3 creation reported by root; expected P3f is derived, not a committed object',local_replacement_files=[{'path':v['path'],'local_path':str(HERE/'candidate'/v['path']),'bytes':v['v3_bytes'],'sha256':v['v3_sha256'],'git_blob':v['v3_git_blob']}for v in verification])
    (HERE/'prospective-P3f-complete-product-validation-inputs.json').write_text(json.dumps(maps,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    manifest={'actual_P3f':None,'actual_parent_P3':P3,'required_ordered_parents':[P3],'parent_tree':P3_TREE,'expected_tree':tree,'counts':{'product':1095,'BASE_delta':70,'validation':142},'registry_guard_CI_validation': 'unchanged','new_algorithm_changes':False,'rustfmt_execution':'not_run','runtime_execution':'not_run','all_other_P3_leaves_unchanged':True,'v1_v2_SQL_counterexample_preserved':True,'files':maps['local_replacement_files']}
    (HERE/'source-manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
    return manifest

if __name__=='__main__':
    print(json.dumps(main(),sort_keys=True,indent=2))
