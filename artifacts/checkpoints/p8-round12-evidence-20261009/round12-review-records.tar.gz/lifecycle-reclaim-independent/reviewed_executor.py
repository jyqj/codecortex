#!/usr/bin/env python3
"""Reclaim only reviewed, byte-proven duplicate G4 lifecycle expansion files."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import sys

PLAN = Path('/dev/shm/p8-G4-lifecycle-expansion-reclaim-root/plan.json')
PLAN_SHA = '570a03e01ff434c8fa11fbbb66fc3a914bda0657ed33fda772fa289900f76d19'
TARGET = Path('/workspace/scratch/2eaa00d0f93a/p8-formal-evidence-G4/lifecycle/files')
ZIP = TARGET.parent / 'original-artifact.zip'
ZIP_SHA = '81756f7d1990147961c87f905625c33da69b57d703f8eb4afa7e0f690ca52c31'
DIRECTORY_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW

def require(ok, message):
    if not ok:
        raise ValueError(message)

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def identity(s):
    return {'device': s.st_dev, 'inode': s.st_ino, 'mode': s.st_mode, 'links': s.st_nlink,
            'bytes': s.st_size, 'mtime_ns': s.st_mtime_ns, 'uid': s.st_uid, 'gid': s.st_gid,
            'allocated_bytes': s.st_blocks * 512}

def physical(entry):
    return {key: value for key, value in entry.items() if key not in ('sha256', 'zip_crc32', 'zip_mode')}

def same_directory(actual, expected):
    return stat.S_ISDIR(actual.st_mode) and all(identity(actual)[key] == expected[key] for key in ('device', 'inode', 'mode', 'uid', 'gid'))

def parent_fd(root_fd, relative, plan):
    parts = Path(relative).parts
    require(parts and all(part not in ('', '.', '..') for part in parts), 'noncanonical planned path')
    current, prefix = os.dup(root_fd), []
    try:
        for part in parts[:-1]:
            prefix.append(part)
            child = os.open(part, DIRECTORY_FLAGS, dir_fd=current)
            os.close(current)
            current = child
            require(same_directory(os.fstat(current), plan['directories']['/'.join(prefix)]), 'directory identity changed')
        return current, parts[-1]
    except BaseException:
        os.close(current)
        raise

def main():
    require(not sys.flags.optimize, 'reclamation requires ordinary Python without -O')
    parser = argparse.ArgumentParser()
    parser.add_argument('--review-file', type=Path, required=True)
    parser.add_argument('--review-sha256', required=True)
    args = parser.parse_args()
    require(sha(PLAN) == PLAN_SHA, 'fixed plan changed')
    plan = json.loads(PLAN.read_bytes())
    require(sha(args.review_file) == args.review_sha256, 'independent review bytes differ')
    review = json.loads(args.review_file.read_bytes())
    require(review['status'] == 'accepted_scoped_for_targeted_duplicate_expansion_reclaim', 'independent review has not accepted this scope')
    require(review['plan_sha256'] == PLAN_SHA and review['target'] == str(TARGET) and review['zip_sha256'] == ZIP_SHA, 'independent review targets other data')
    require(review['executor_sha256'] == sha(Path(__file__)), 'executor differs from independently reviewed code')
    require(plan['target'] == str(TARGET) and plan['zip_to_keep'] == str(ZIP), 'unexpected target or keep path')
    require(plan['expanded_file_count'] == plan['complete_zip_member_count'] == 2391 and len(plan['files']) == 2391, 'incomplete planned population')
    require(TARGET.resolve(strict=True) == TARGET and ZIP.resolve(strict=True) == ZIP, 'target or ZIP path is a symlink')
    for parent in [TARGET, *TARGET.parents]:
        require(stat.S_ISDIR(parent.lstat().st_mode) and not parent.is_symlink(), 'nonregular ancestor')
    require(sha(ZIP) == ZIP_SHA and identity(ZIP.lstat()) == plan['zip_identity'], 'original ZIP changed or missing')
    actual_files, actual_dirs = set(), set()
    for current, children, leaves in os.walk(TARGET, followlinks=False):
        directory = Path(current)
        name = directory.relative_to(TARGET).as_posix()
        require(name in plan['directories'] and identity(directory.lstat()) == plan['directories'][name], 'directory population or identity differs')
        actual_dirs.add(name)
        for child in children:
            require(not (directory / child).is_symlink(), 'unexpected directory symlink')
        for leaf in leaves:
            path = directory / leaf
            relative = path.relative_to(TARGET).as_posix()
            require(relative in plan['files'], 'unplanned live file')
            expected = plan['files'][relative]
            require(identity(path.lstat()) == physical(expected) and stat.S_ISREG(path.lstat().st_mode) and path.lstat().st_nlink == 1, 'file inode/mode/link identity differs')
            require(sha(path) == expected['sha256'], 'file differs from preserved ZIP member')
            actual_files.add(relative)
    require(actual_files == set(plan['files']) and actual_dirs == set(plan['directories']), 'live population is incomplete')
    require(identity(TARGET.lstat()) == plan['target_identity'] and sha(ZIP) == ZIP_SHA, 'source changed during preflight')
    log = PLAN.parent / 'execution.jsonl'
    final = PLAN.parent / 'execution.json'
    require(not log.exists() and not final.exists(), 'preserve previous execution records')
    result = {'status': 'started', 'plan_sha256': PLAN_SHA, 'review_sha256': args.review_sha256,
              'executor_sha256': sha(Path(__file__)), 'target': str(TARGET), 'zip_to_keep': str(ZIP),
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'free_bytes_before': shutil.disk_usage(TARGET.parent).free,
              'removed_files': 0, 'removed_directories': 0, 'planned_duplicate_bytes': plan['expanded_bytes'],
              'original_measurement_or_old_temporary_directory_removed': False,
              'TODO_newly_completed': 0, 'TODO_remaining': 29}
    root_fd = os.open(TARGET, DIRECTORY_FLAGS)
    require(same_directory(os.fstat(root_fd), plan['target_identity']), 'opened root identity differs')
    try:
        with log.open('x') as journal:
            for relative, expected in sorted(plan['files'].items()):
                directory_fd, name = parent_fd(root_fd, relative, plan)
                try:
                    file_fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=directory_fd)
                    try:
                        require(identity(os.fstat(file_fd)) == physical(expected), 'file changed before removal')
                        digest = hashlib.sha256()
                        while True:
                            block = os.read(file_fd, 1024 * 1024)
                            if not block:
                                break
                            digest.update(block)
                        require(digest.hexdigest() == expected['sha256'] and identity(os.fstat(file_fd)) == physical(expected), 'file bytes changed before removal')
                        require(identity(os.stat(name, dir_fd=directory_fd, follow_symlinks=False)) == physical(expected), 'directory entry changed before removal')
                        os.unlink(name, dir_fd=directory_fd)
                    finally:
                        os.close(file_fd)
                    result['removed_files'] += 1
                    journal.write(json.dumps({'file_unlinked': relative, 'device': expected['device'], 'inode': expected['inode'], 'sha256': expected['sha256']}) + '\n')
                    journal.flush()
                finally:
                    os.close(directory_fd)
            for relative in sorted((p for p in plan['directories'] if p != '.'), key=lambda p: (-len(Path(p).parts), p)):
                directory_fd, name = parent_fd(root_fd, relative, plan)
                try:
                    require(same_directory(os.stat(name, dir_fd=directory_fd, follow_symlinks=False), plan['directories'][relative]), 'empty directory identity changed')
                    os.rmdir(name, dir_fd=directory_fd)
                    result['removed_directories'] += 1
                    journal.write(json.dumps({'empty_directory_removed': relative, 'inode': plan['directories'][relative]['inode']}) + '\n')
                    journal.flush()
                finally:
                    os.close(directory_fd)
            base_fd = os.open(TARGET.parent, DIRECTORY_FLAGS)
            try:
                require(same_directory(os.stat(TARGET.name, dir_fd=base_fd, follow_symlinks=False), plan['target_identity']), 'root identity changed before empty removal')
                os.rmdir(TARGET.name, dir_fd=base_fd)
                result['removed_directories'] += 1
            finally:
                os.close(base_fd)
        require(not TARGET.exists() and result['removed_files'] == 2391, 'target reclamation did not finish')
        require(sha(ZIP) == ZIP_SHA and identity(ZIP.lstat()) == plan['zip_identity'], 'preserved original ZIP changed')
        result['original_zip_unchanged'] = True
        result['status'] = 'completed_exact_reviewed_duplicate_reclamation'
    except BaseException as error:
        result['status'] = 'partial_or_failed_stop_preserve_remaining'
        result['error'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        os.close(root_fd)
        result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result['free_bytes_after'] = shutil.disk_usage(TARGET.parent).free
        with final.open('x') as stream:
            stream.write(json.dumps(result, sort_keys=True, indent=2) + '\n')
    print(json.dumps(result))

if __name__ == '__main__':
    main()
