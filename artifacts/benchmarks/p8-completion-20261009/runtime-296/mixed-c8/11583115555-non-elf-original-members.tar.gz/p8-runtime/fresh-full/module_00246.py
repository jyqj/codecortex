def stable_00246():
    return 246
