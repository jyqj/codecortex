def stable_00274():
    return 274
