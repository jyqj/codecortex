def stable_00166():
    return 166
