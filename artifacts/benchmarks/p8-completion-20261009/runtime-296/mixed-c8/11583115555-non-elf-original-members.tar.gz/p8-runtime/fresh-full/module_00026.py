def stable_00026():
    return 26
