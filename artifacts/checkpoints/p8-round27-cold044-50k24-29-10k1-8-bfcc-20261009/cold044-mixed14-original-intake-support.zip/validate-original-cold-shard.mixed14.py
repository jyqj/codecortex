import pathlib,json,hashlib,subprocess,sys,datetime,time,traceback,stat,zipfile
B=pathlib.Path(__file__).resolve().parent; ROOT=B/"source"; BUILD=B/"build-restoration/extracted"; aid=int(sys.argv[1])
slot=next(s for s in json.loads((B/"increment-50k24-29-and-10k1-8/claim-input.json").read_text())["ledger"]["slots"] if s["measurement"]["id"]==aid)
ART=slot["measurement"]; OUT=B/"raw"/str(aid)/"original-validation-attempt01";OUT.mkdir(exist_ok=False)
ZIP=B/"raw"/str(aid)/(ART["name"]+"-original.zip")
sys.path.insert(0,str(ROOT/"scripts"));import p8_cold_matrix as cold;import p8_scale_matrix as full
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snap():
 return {"source_commit":subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip(),"observer":cold.driver_snapshot(ROOT),"build_inventory":full.inventory(BUILD),"zip":{"bytes":ZIP.stat().st_size,"sha256":sh(ZIP)}}
start=full.utc();t=time.monotonic();code=0;error=None;accepted=None;before=None;after=None
try:
 assert ZIP.stat().st_size==ART["size_in_bytes"] and "sha256:"+sh(ZIP)==ART["digest"]
 dest=OUT/"extracted";dest.mkdir();members=[];seen=set()
 with zipfile.ZipFile(ZIP) as z:
  for i in z.infolist():
   p=pathlib.PurePosixPath(i.filename);mode=i.external_attr>>16
   assert not p.is_absolute() and ".." not in p.parts and not stat.S_ISLNK(mode) and str(p) not in seen
   seen.add(str(p))
   if i.is_dir():(dest/p).mkdir(parents=True,exist_ok=True);continue
   data=z.read(i);q=dest/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
   members.append({"path":str(p),"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"crc32":i.CRC,"zip_mode":oct(mode)})
 (OUT/"zip-members.json").write_text(json.dumps(members,indent=2)+"\n")
 prior=json.loads((B/"original-build-validation-attempt01/original-validate-build-output.json").read_text());binary=pathlib.Path(prior["binary"])
 assert sh(binary)==prior["built"]["binary_sha256"];binary.chmod((binary.stat().st_mode&0o777)|0o111)
 before=snap();(OUT/"inputs-before.json").write_text(json.dumps(before,indent=2)+"\n")
 expected=json.loads((B/"original-build-validation-attempt01/source-before.json").read_text())
 assert before["source_commit"]==expected["source"]["source_commit"]
 for key in ("observer","build_inventory"):assert before[key]==expected[key],key+" drift from accepted original build"
 accepted=cold.validate_shard(dest,prior["outer"],prior["built"],binary,BUILD,ROOT)
 assert accepted["study"]=={"protocol":"p8-cold-only-study-v1","run_id":"37954851017","run_attempt":1}
 assert accepted["plan"]["files"]==[slot["scale"]] and accepted["plan"]["shard"]["index"]==slot["repetition"] and len(accepted["measurements"])==1
 (OUT/"original-validate-shard-output.json").write_text(json.dumps(accepted,indent=2)+"\n")
 print(json.dumps({"accepted":True,"artifact_id":aid,"scale":slot["scale"],"repetition":slot["repetition"],"samples":len(accepted["measurements"]),"source":before["source_commit"]}),flush=True)
except BaseException as exc:code=1;error=type(exc).__name__+": "+str(exc);traceback.print_exc()
finally:
 if before is not None:
  after=snap();(OUT/"inputs-after.json").write_text(json.dumps(after,indent=2)+"\n")
  if before!=after:code=1;error=(error or "")+";input drift"
 (OUT/"receipt.json").write_text(json.dumps({"argv":[sys.executable,str(pathlib.Path(__file__).resolve()),str(aid)],"started":start,"finished":full.utc(),"wall_seconds":time.monotonic()-t,"exit_code":code,"error":error,"inputs_unchanged":before==after if before else None,"artifact":ART,"slot":{"scale":slot["scale"],"repetition":slot["repetition"]},"source":"044c008c9459cfa61e7701db2eb868342c508a39","run_id":37954851017,"run_attempt":1,"accepted_shards":int(code==0),"accepted_samples":1 if code==0 else 0,"scope":"Unchanged cold.validate_shard and original retained ELF --hash-file only; no workload rerun or partial aggregate; capacity artifact separately received","remaining_todos":29,"newly_completed_todos":0},indent=2)+"\n")
raise SystemExit(code)

