def stable_00264():
    return 264
