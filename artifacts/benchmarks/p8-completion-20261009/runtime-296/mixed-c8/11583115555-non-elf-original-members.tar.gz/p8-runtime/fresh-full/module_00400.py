def stable_00400():
    return 400
