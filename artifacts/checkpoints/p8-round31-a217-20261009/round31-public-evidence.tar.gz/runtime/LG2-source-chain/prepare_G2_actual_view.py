#!/usr/bin/env python3
"""Validate actual P2/R2/G2 composition and atomically install only new trust roots."""
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

B = Path('/workspace/scratch/a217aaae3bde')
I = B / 'p8-db-lock-observation-integration'
OUT = I / 'LG2-actual-G2-proof'
VIEW = B / 'p8-lock-observation-P2-validated'
OLD = B / 'p8-lock-observation-validated'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def oid(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def git(*args, data=None, root=VIEW):
    return subprocess.check_output(['git', '-C', str(root), *args], input=data, env=ENV)


def write(name, value):
    raw = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    path = OUT / name
    path.open('xb').write(raw)
    return dict(path=str(path), bytes=len(raw), sha256=sha(raw), git_blob=oid(raw))


def tree(ref):
    result = {}
    for row in git('ls-tree', '-r', '-z', ref).split(b'\0'):
        if row:
            meta, p = row.decode().split('\t', 1)
            mode, kind, object_id = meta.split()
            result[p] = dict(mode=mode, type=kind, sha=object_id)
    return result


def main():
    assert not OUT.exists()
    OUT.mkdir()
    cfg = json.loads((I / 'LG2-final-composition-inputs.json').read_bytes())
    assert git('rev-parse', 'HEAD').decode().strip() == cfg['product']
    assert git('remote') == b''
    trees = {ref: tree(ref) for ref in [cfg['product'], cfg['review'], cfg['guard'], cfg['old_guard']]}
    for child, parent, expected_tree in [(cfg['review'], cfg['product'], cfg['review_tree']),
                                        (cfg['guard'], cfg['review'], cfg['guard_tree'])]:
        assert git('show', '-s', '--format=%T%n%P', child).decode().splitlines() == [expected_tree, parent]
    for before, after, elements in [(cfg['product'], cfg['review'], cfg['review_elements']),
                                    (cfg['review'], cfg['guard'], cfg['guard_elements'])]:
        actual = {p: trees[after].get(p) for p in trees[before].keys() | trees[after].keys()
                  if trees[before].get(p) != trees[after].get(p)}
        expected = {x['path']: {k: x[k] for k in ('mode', 'type', 'sha')} for x in elements}
        assert actual == expected
    assert len(cfg['review_elements']) == 27 and len(cfg['guard_elements']) == 2
    assert all(x['path'].startswith('artifacts/') and x['path'] not in trees[cfg['product']]
               for x in cfg['review_elements'])

    candidates = {}
    roots = [I, B / 'original-C3ff-platform-gates/LG-diagnostic',
             B / 'original-C3ff-runtime/LG-format-followup']
    for root in roots:
        for p in root.rglob('*'):
            if p.is_file() and not p.is_symlink() and p.stat().st_size <= 2 * 1024 * 1024:
                raw = p.read_bytes()
                candidates.setdefault(oid(raw), (p, raw))
    materialized = []
    raws = {}
    for row in cfg['review_elements'] + cfg['guard_elements']:
        assert row['sha'] in candidates, row['path']
        local, raw = candidates[row['sha']]
        assert oid(raw) == trees[cfg['guard']][row['path']]['sha'] == row['sha']
        assert git('hash-object', '-w', '--stdin', data=raw).decode().strip() == row['sha']
        actual_raw = git('cat-file', 'blob', row['sha'])
        assert actual_raw == raw
        raws[row['path']] = raw
        materialized.append(dict(path=row['path'], local_source=str(local), bytes=len(raw),
                                 sha256=sha(raw), git_blob=oid(raw), mode=row['mode']))
    regpath = 'scripts/reviewed-source-registry-v15.json'
    verpath = 'scripts/verify_reviewed_source_v15.py'
    for p, remote in [(regpath, 'registry.json'), (verpath, 'verifier.py'),
                      (cfg['review_path'], 'core.json')]:
        assert raws[p] == (I / 'LG2-remote-originals' / remote).read_bytes()
    core = json.loads(raws[cfg['review_path']])
    registry = json.loads(raws[regpath])
    assert sha(raws[cfg['review_path']]) == cfg['review_sha256']
    assert sha(raws[regpath]) == cfg['registry_sha256']
    for key, filename in [('complete_inputs', 'product-domain.json'),
                          ('validation_inputs', 'validation-domain.json'),
                          ('delta', 'historical-delta.json')]:
        value = json.loads((I / 'LG2-actual-P2-proof-v2' / filename).read_bytes())
        assert registry[key] == value and core['paths' if key == 'delta' else key] == value
        assert all(trees[cfg['guard']][p] == trees[cfg['product']][p] for p in value)
    assert core['source'] == registry['product_source'] == cfg['product']
    assert registry['review_source'] == cfg['review']
    assert registry['review_sha256'] == cfg['review_sha256']
    assert core['verdict'] == 'accepted_scoped' and core['unresolved_blockers'] == []
    assert core['task_and_release_boundary']['remaining'] == 29
    assert core['task_and_release_boundary']['newly_completed'] == 0
    records = []
    for record in core['review_records']:
        raw = raws[record['path']]
        assert len(raw) == record['bytes'] and sha(raw) == record['sha256'] and oid(raw) == record['git_blob']
        records.append(record)
    assert len(records) == 26
    assert any(r['sha256'] == '20b21cdc5431631e0055e25012d99e979c5e1b4b059cc870609580d41f41bc37' for r in records)
    assert any(r['sha256'] == '5e80b45fda13ef759a1bb27d3a12f3039f3767d327e26fa21708a6c8241dc937' for r in records)
    oldverifier = (OLD / verpath).read_bytes()
    assert oid(oldverifier) == trees[cfg['old_guard']][verpath]['sha']
    replacements = {'PRODUCT': cfg['product'], 'REVIEW': cfg['review'],
                    'REVIEW_PATH': cfg['review_path'], 'REGISTRY_SHA256': cfg['registry_sha256']}
    lines = oldverifier.decode().splitlines(keepends=True)
    for key, value in replacements.items():
        matches = [i for i, line in enumerate(lines) if line.startswith(key + ' = ')]
        assert len(matches) == 1
        lines[matches[0]] = key + ' = ' + json.dumps(value) + '\n'
    assert ''.join(lines).encode() == raws[verpath]
    def nonpins(raw):
        node = ast.parse(raw)
        node.body = [x for x in node.body if not (isinstance(x, ast.Assign) and
                    len(x.targets) == 1 and isinstance(x.targets[0], ast.Name) and
                    x.targets[0].id in replacements)]
        return ast.dump(node, include_attributes=False)
    assert nonpins(oldverifier) == nonpins(raws[verpath])
    oldregistry = json.loads((OLD / regpath).read_bytes())
    allowed = {'product_source', 'review_source', 'review_sha256', 'complete_inputs', 'validation_inputs', 'delta'}
    assert {k for k in oldregistry.keys() | registry.keys() if oldregistry.get(k) != registry.get(k)} == allowed
    oldproof = json.loads((I / 'LG2-actual-P2-proof-v2/old-materialized-before.json').read_bytes())
    for r in oldproof:
        p = OLD / r['path']
        assert sha(p.read_bytes()) == r['sha256'] and stat.S_IMODE(p.stat().st_mode) == r['physical_mode']
    oldindex = Path(git('rev-parse', '--absolute-git-dir', root=OLD).decode().strip())
    oldguards = {str(oldindex / p): sha((oldindex / p).read_bytes()) for p in ['HEAD', 'index']}

    for p in [regpath, verpath, cfg['review_path']]:
        target = VIEW / p
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_name(target.name + '.G2-atomic-new')
        assert not temporary.exists()
        temporary.open('xb').write(raws[p])
        temporary.chmod(0o644)
        os.replace(temporary, target)
        if p in (regpath, verpath):
            assert target.stat().st_ino != (OLD / p).stat().st_ino
    git('update-ref', '--no-deref', 'HEAD', cfg['guard'])
    git('read-tree', cfg['guard'])
    git('update-index', '--skip-worktree', '-z', '--stdin', data=b'\0'.join(p.encode() for p in sorted(trees[cfg['guard']])) + b'\0')
    paths = sorted({r['path'] for r in oldproof} | {cfg['review_path']})
    assert len(paths) == 1851
    git('update-index', '--no-skip-worktree', '-z', '--stdin', data=b'\0'.join(p.encode() for p in paths) + b'\0')
    snapshot = {}
    for p in paths:
        f = VIEW / p
        assert f.is_file() and not f.is_symlink()
        raw = f.read_bytes()
        leaf = trees[cfg['guard']][p]
        assert oid(raw) == leaf['sha'] and stat.S_IMODE(f.stat().st_mode) == int(leaf['mode'][-3:], 8)
        snapshot[p] = dict(bytes=len(raw), sha256=sha(raw), git_blob=oid(raw), mode=leaf['mode'])
    history = json.loads((I / 'root-actual-composition-and-preparation.json').read_bytes())['verified_original_artifacts_materialized_during_attempt_v1']
    assert len(history) == 187
    for row in history:
        actual = snapshot[row['path']]
        assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
        assert actual['git_blob'] == row['sha'] and actual['mode'] == row['mode']
    for r in oldproof:
        p = OLD / r['path']
        assert sha(p.read_bytes()) == r['sha256'] and stat.S_IMODE(p.stat().st_mode) == r['physical_mode']
    assert oldguards == {p: sha(Path(p).read_bytes()) for p in oldguards}
    assert git('diff', '--name-only') == b'' and git('diff', '--cached', '--name-only') == b''
    assert git('remote') == b''
    inputs = write('all-1851-inputs-before.json', snapshot)
    object_record = write('exact-R2-G2-private-object-materialization.json', materialized)
    proof = dict(schema=1, verdict='accepted_scoped_actual_G2_composition', source=cfg['guard'],
                 tree=cfg['guard_tree'], product=cfg['product'], review=cfg['review'],
                 review_additions=27, guard_changes=2, verifier_changes=list(replacements),
                 unchanged_verifier_algorithm=True, product_inputs=1094, validation_inputs=142,
                 historical_delta=60, exact_review_records=records,
                 source_view=str(VIEW), inputs_before=inputs, private_objects=object_record,
                 original_history_count=187, original_history_bytes=sum(x['bytes'] for x in history),
                 old_LG_HEAD_index_and_all_1850_bytes_modes_preserved=True,
                 old_LG_HEAD_index_sha256=oldguards,
                 review_sha256=cfg['review_sha256'], registry_sha256=cfg['registry_sha256'],
                 task_snapshot=snapshot['docs/roadmap/code-index-v2/tasks.json'],
                 required_file_projection=True, full_checkout=False, guard_cli='not_run_yet',
                 native_or_compile='not_run', formal_done=163, formal_remaining=29,
                 finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    print(json.dumps(write('actual-G2-composition-proof.json', proof)), flush=True)


if __name__ == '__main__':
    main()
