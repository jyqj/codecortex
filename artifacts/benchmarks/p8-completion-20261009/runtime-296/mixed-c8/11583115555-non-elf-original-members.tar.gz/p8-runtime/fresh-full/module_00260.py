def stable_00260():
    return 260
