"""Read already extracted original capacity receipt; no observer execution."""
import datetime
import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'round33-PR200-build-capacity-original-intake/attempt01'
SOURCE = ROOT / 'round32-capture-context-admission/guard-view'
BINDING = ROOT / 'round32-100k-diagnostic-intake-bound-9cc6-run38012409915/binding.json'

def identity(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}

def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

binding = json.loads(BINDING.read_text())
receipt_path = OUT / 'extracted/capacity/receipt.json'
capacity = json.loads(receipt_path.read_text())
report = json.loads((OUT / 'reader/report.json').read_text())
capacity_zip = next(x for x in report['artifacts'] if x['kind'] == 'capacity')
build_zip = next(x for x in report['artifacts'] if x['kind'] == 'build')
assert list(capacity_zip['members']) == ['receipt.json']
assert capacity['schema_version'] == 1 and capacity['profile'] == 'scale_capacity_v1'
assert capacity['scale'] == 100000 and capacity['source_commit'] == binding['G']
context = capacity['context']
assert context['GITHUB_REPOSITORY'] == 'jyqj/codecortex'
assert context['GITHUB_RUN_ID'] == str(binding['run_id']) and context['GITHUB_RUN_ATTEMPT'] == str(binding['run_attempt'])
assert context['GITHUB_JOB'] == 'diagnose' and context['P8_EXPECTED_SOURCE'] == binding['G']
assert context['RUNNER_ENVIRONMENT'] == 'github-hosted' and context['RUNNER_OS'] == 'Linux'
assert context['ImageOS'] == 'ubuntu24'
observer = SOURCE / 'scripts/p8_runner_capacity.py'
committed = subprocess.check_output(['git', 'show', binding['G'] + ':scripts/p8_runner_capacity.py'], cwd=SOURCE)
assert committed == observer.read_bytes()
assert hashlib.sha256(committed).hexdigest() == capacity['observer_sha256']
required = 100000 * 256 * 1024 + 4 * 1024**3
assert capacity['required_free_bytes'] == required == 30509367296
assert capacity['status'] == 'capacity_available' and type(capacity['exit_code']) is int and capacity['exit_code'] == 0
assert capacity['artifact_state'] == 'sealed_after_commands_finished'
assert capacity['steps'] == [] and capacity['files'] == {}
assert capacity['initial'] == capacity['final'] and capacity['final']['free_bytes'] >= required
cap_review = {'schema': 'original-capacity-receipt-readonly-review-v1',
              'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'original_receipt': identity(receipt_path), 'artifact': capacity_zip,
              'observer_source': identity(observer), 'source': binding['G'],
              'run': binding['run_id'], 'attempt': binding['run_attempt'],
              'original_status': capacity['status'], 'original_exit_code': capacity['exit_code'],
              'original_job': context['GITHUB_JOB'], 'required_free_bytes': required,
              'observed_free_bytes': capacity['final']['free_bytes'], 'SDK_cleanup_commands': 0,
              'boundary': 'Original point-in-time capacity/environment evidence only. No capacity observer, deletion command, ELF, or measurement executed by this review. No guarantee about later disk capacity.'}
save(OUT / 'capacity-receipt-review.json', cap_review)
terminal = json.loads((OUT / 'terminal.json').read_text())
build = json.loads((OUT / 'original-validate-build-result.json').read_text())['original_build_record']
assert terminal['reader_exit'] == 0 and terminal['original_validate_build_exit'] == 0
assert terminal['original_function_calls'] == {'validate_build': 1, 'validate_shard': 0, 'inspect_raw': 0}
assert json.loads((OUT / 'source-evidence-before.json').read_text()) == json.loads((OUT / 'source-evidence-after.json').read_text())
review = {'schema': 'independent-diagnostic-build-capacity-original-intake-v1',
          'scope': 'Custody + original build predicate + capacity receipt. Not 100k execution completion, full capture custody or a cohort sample.',
          'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'binding': identity(BINDING), 'source': binding['G'], 'source_tree': binding['G_tree'],
          'run': binding['run_id'], 'attempt': binding['run_attempt'], 'event': binding['event'],
          'original_artifacts': [build_zip, capacity_zip],
          'original_predicate': {'validate_build_actual_calls': 1, 'actual_exit_code': 0,
                                 'execution': identity(OUT / 'original-validate-build.execution.json'),
                                 'result': identity(OUT / 'original-validate-build-result.json'),
                                 'ELF_invocation_scope': 'Only unchanged original native_digest(binary,binary): --hash-file. No build/profile/workload executed.'},
          'original_build': {'status': build['status'], 'exit_code': build['exit_code'],
                             'source_manifest_sha256': build['source_manifest_sha256'],
                             'product_count': 1096, 'driver_count': 2,
                             'binary_bytes': build['binary_bytes'], 'binary_sha256': build['binary_sha256'],
                             'binary_blake3': build['binary_blake3'],
                             'receipt': identity(OUT / 'extracted/build/build.json')},
          'unchanged_input_snapshot_count': terminal['snapshot_count'],
          'before_after_equal': True,
          'capacity_review': identity(OUT / 'capacity-receipt-review.json'),
          'custody_state': report['custody_status'], 'reported_native_outcome': report['reported_native_outcome'],
          'checkpoint_count': len(report['checkpoints']), 'observer_before_seen': report['observer_before_seen'],
          'observer_after_seen': report['observer_after_seen'], 'configuration_seen': report['configuration_seen_and_bound'],
          'new_raw_or_shard_predicates': 'not_run: neither checkpoint/final nor shard raw supplied',
          'accepted_cohort_shards': 0, 'accepted_cohort_samples': 0, 'task_completion_credit': 0,
          'ownership': 'Root uniquely downloaded/materialized and owns whole ZIP Git custody; execution_recon ran the frozen reader and original build function once. No duplicate Actions transport.',
          'limitations': ['Build job and harmless controls success is engineering evidence only.',
                          'All stream tails, 100k stage completion and any capture faults remain unknown until original checkpoints/final receipts arrive.',
                          'Native success cannot override custody faults; a prefix cannot prove EOF.',
                          'Original build maps cover defined products and driver/helper. Runtime three-observer receipts will be evaluated when captured; no claim they were in the build ZIP.']}
save(OUT / 'build-capacity-intake-review.json', review)
print(json.dumps({'status': 'accepted_build_and_capacity_only', 'review': identity(OUT / 'build-capacity-intake-review.json'),
                  'capacity_review': identity(OUT / 'capacity-receipt-review.json'), 'cohort_samples': 0}))
