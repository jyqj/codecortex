#!/usr/bin/env python3
"""Thin original-receipt/source/counter reconciliation; no validator is run."""
import hashlib,json
from pathlib import Path
OUT=Path(__file__).resolve().parent
BASE=Path('/dev/shm/pr-triage-G2-db-lock-cohort-37930392164')
def read(p):return json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)}
summary_path=BASE/'complete-four-C-cohort/complete-G2-four-C-independent-review.json';summary=read(summary_path)
assert digest(summary_path)=='01f05df875bd8d2a5936798660f7ae349a764bd560e3ac676ddd2f8841136706'
G='4d18dcdb34b5d7a277566b57801cc882d8b1eb61'
assert summary['source_G']==G and summary['run_id']==37930392164 and summary['run_attempt']==1
assert summary['complete_Cs']==[1,4,8,16] and not summary['missing_Cs']
canon_path=BASE/'source-admission/canonical-review.json';canonical=read(canon_path);registry=read(BASE/'source-admission/registry.json')
assert digest(canon_path)==summary['canonical_review_sha256']=='9610ea3abc0c5e7efd27667126ba6b6a2d3569e040d332664363cd5e8e96de7b'
assert canonical['source']==summary['product_P']=='b79f7749eb8f0a6c728493adfb073ca7db5563be'
assert len(canonical['complete_inputs'])==1094 and len(canonical['validation_inputs'])==142
assert registry['complete_inputs']==canonical['complete_inputs'] and registry['validation_inputs']==canonical['validation_inputs'] and registry['review_sha256']==digest(canon_path)
meta=read(BASE/'source-admission/G2-commit.raw.json');assert meta['sha']==G and meta['tree']['sha']==summary['source_tree'] and meta['parents'][0]['sha']==summary['review_R']
script_tree=read(BASE/'source-admission/G2-scripts-tree.raw.json');script_objects={'scripts/'+r['path']:r for r in script_tree['tree'] if r['type']=='blob'}
helper=BASE/'independent-runtime-review/review-original-G2-runtime.py';assert digest(helper)=='a4e6d2e016ad5f8d53de2686026ef12eac71ee4bbf822581ef17ed30cd67f824'
cells=[]
for c in summary['cells']:
    C=c['configured_C'];aid=c['artifact_id'];rpath=Path(c['independent_review']['path']);r=read(rpath)
    assert rpath.stat().st_size==c['independent_review']['bytes'] and digest(rpath)==c['independent_review']['sha256']
    assert r['source_sha']==G and r['run_id']==summary['run_id'] and r['review_status']=='raw_and_receipt_review_passed' and not r['errors']
    prefix=BASE/f'C{C}-independent-review' if C in (1,16) else BASE/f'independent-runtime-review/{aid}.review'
    receipt=Path(str(prefix)+'-command-receipt.json');cmd=read(receipt)
    assert cmd['exit_code']==0 and cmd['native_workload_executed'] is False and cmd['helper_sha256']==digest(helper)
    assert cmd['argv'][3:]==[str(aid),c['original_zip']['sha256'],'mixed',str(C),'1']
    for stream in ('stdout','stderr'):assert digest(Path(str(prefix)+'.'+stream))==cmd[stream+'_sha256']
    assert Path(str(prefix)+'.exit').read_text().strip()=='0'
    verified=BASE/f'independent-runtime-review/{aid}'
    assert (verified/'original-verify.exit').read_text().strip()=='0' and not (verified/'original-verify.stderr').read_bytes()
    v=read(verified/'original-verify.stdout');assert v['status']=='sealed_artifacts_verified' and v['observation_exit_code']==0 and v['observation_status']=='passed_observation'
    raw=BASE/f'raw/{aid}/attempt01/extracted';build=raw/'p8-lock-build';runtime=raw/'p8-lock-runtime'
    before=read(build/'source-before.json');after=read(build/'source-after.json');b=read(build/'build-receipt.json');plan=read(runtime/'plan.json');original=read(runtime/'report.json')
    assert before==after==b['source_before']==b['source_after']==plan['source']==original['final_build_verification']['source']
    assert before['inputs']==canonical['complete_inputs'] and before['input_count']==1094 and before['source_commit']==G and before['source_tree']==meta['tree']['sha']
    assert b['build_exit_code']==0 and b['status']=='passed' and b['target_initially_absent'] is True
    assert b['diagnostic_profile']==plan['diagnostic_profile']==original['diagnostic_profile']=='mixed_db_lock_observation_v1'
    assert plan['operations']==900 and plan['files']==1000 and plan['offer_interval_ms']==500 and plan['concurrency']==C
    assert plan['offer_schedule']=='fixed_concurrency_sized_bursts'
    assert original['status']=='passed_observation' and original['exit_code']==0 and original['failures']==[] and original['outcomes']=={'success':900}
    assert original['db_lock_observation']==r['db_lock_observation']==c['counter_window']
    obs=b['observer_before'];assert obs==b['observer_after'] and len(obs['files'])==10
    for path,item in obs['files'].items():
        content=(build/'observer-source'/path).read_bytes();git=hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()
        assert hashlib.sha256(content).hexdigest()==item['sha256']==canonical['validation_inputs'][path]
        assert git==script_objects[path]['sha']==item['git_blob'] and len(content)==script_objects[path]['size']==item['bytes'] and item['git_mode']==script_objects[path]['mode']
    assert r['outcomes']=={'read':600,'build':300} and r['raw_kind_counts']['operation']==900
    assert r['actual_concurrency']['maximum']==c['actual_call_peak'] and r['actual_concurrency']['read']==r['actual_concurrency']['build']==0
    assert r['db_lock_observation']['sqlite_busy_wait_observed'] is False and r['db_lock_observation']['interval_maximum_observed'] is False
    boundary=[];counts={}
    with (runtime/'raw.jsonl').open() as f:
        for line in f:
            item=json.loads(line);counts[item['kind']]=counts.get(item['kind'],0)+1
            if item['kind']=='db_lock_observation':boundary.append(item)
    assert boundary==r['counter_boundary_rows'] and len(boundary)==2 and counts['operation']==900
    assert boundary[0]['phase']=='before_work' and boundary[1]['phase']=='after_work_and_sampler_drain'
    assert boundary[0]['owned_product_pid']==boundary[1]['owned_product_pid']==r['db_lock_observation']['process_id']==c['native_PID']
    # Reconcile only the six published counter deltas; no collector/latency replay.
    for role in ('workload','observer'):
        for metric in ('writer_mutex_acquire','read_pool_lock_acquire','read_connection_checkout'):
            a=boundary[0]['response'][role][metric];z=boundary[1]['response'][role][metric];v=r['db_lock_observation']['counters'][role][metric]
            for key in ('attempts','acquired','poisoned','failed','would_block','elapsed_ns_total'):assert z[key]-a[key]==v[key]
            assert v['in_flight_at_boundaries']==[a['in_flight'],z['in_flight']]==[0,0]
            assert v['interval_max_ns'] is None and v['process_lifetime_max_ns_at_end']==z['elapsed_ns_max']
    assert len(r['parity_tables'])==15 and all(x['equal'] for x in r['parity_tables'])
    cells.append({'C':C,'artifact':aid,'job':c['job_id'],'original_operations':900,'read':600,'build':300,'actual_peak':c['actual_call_peak'],'actual_overlap':c['actual_read_build_overlap'],'reader_receipt':ref(receipt),'reader_exit':0,'original_verify_exit':0,'original_verify_stdout':ref(verified/'original-verify.stdout'),'source_manifest':ref(build/'source-before.json'),'ten_observer_Gitblob_mode_SHA_matches':True,'build_profile':'mixed_db_lock_observation_v1','counter_metrics':r['db_lock_observation']['counters']['workload'],'original_snapshot_boundary_rows_verified':2,'review':ref(rpath)})
assert [r['actual_peak'] for r in cells]==[1,4,7,12]
continuity=BASE/'source-continuity/G2-original-acquisition-semantics-continuity.json';co=read(continuity)
assert co['source_G']==G and len(co['unchanged_actual_canonical_inputs'])==10
for row in co['unchanged_actual_canonical_inputs']:assert row['same_bytes'] is True and row['G2_canonical_sha256']==(canonical['complete_inputs']|canonical['validation_inputs'])[row['path']]
for row in co['actual_G2_two_official_files']:
    src=BASE/'source-continuity'/Path(row['path']).name
    assert digest(src)==row['actual_G2_sha256']==canonical['complete_inputs'][row['path']]
report={'schema':'independent-thin-peer-four-C-acquisition-evidence-v1','reviewer':'/root/execution_recon','producer_reviewer':'/root/pr_triage','verdict':'accepted_scoped_complete_original_four_C_acquisition_observation_component','G':G,'P':summary['product_P'],'R':summary['review_R'],'tree':summary['source_tree'],'run_id':37930392164,'attempt':1,'product_inputs':1094,'validation_inputs':142,'summary':ref(summary_path),'reader_script_read_not_executed':ref(helper),'source_continuity':ref(continuity),'cells':cells,'total_original_operations':3600,'method':'Read original complete summary, four reports, real reader command/stdout/stderr/exit receipts, original verify outputs, per-cell build/source manifests and10 archived observer scripts; independently reconcile retained two-boundary six-metric arithmetic. No original Python collector/verifier, Rust binary, compiler, workload or new measurement rerun.','P8_007_appendable_evidence':'The original four-C mixed actual DB acquisition observation component is now evidenced by one complete fixed G2 cohort: per-C900 outcomes, instrumented actual writer/read-pool acquisition and checkout call wall, observer/workload role split, coherent before/after boundaries and drained counters. This replaces no prior cohort and does not close the task.','limits':['Explicit feature diagnostic build; cannot append these latencies to default-build distributions or compare them as a default speedup.','Acquisition-call elapsed includes uncontended overhead. Checkout includes possible validation/construction. These are not pure scheduler-blocked time.','SQLite internal busy/BEGIN wait remains unobserved; interval maxima remain null. Process-lifetime maxima are not subtracted to invent interval maxima.','ConfiguredC8/16 actual peaks7/12; C1 no read/build overlap is retained, not treated as a missing cell.','Prior native G1 C1/C4, Gc8 failed scale, H, SQL G3 and main are different source populations.','P8-005/006 hard dependencies remain open. P8-007 stays in_progress; no task or release certification.','Thin peer does not repeat all original RPC/raw/quantile/seal validation already performed by the identified original reader; extraction POSIX equivalence is not asserted.'],'TODO_done':163,'TODO_remaining':29,'TODO_newly_complete':0}
with (OUT/'independent-four-C-acquisition-evidence-thin-review.json').open('x') as f:json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({'verdict':report['verdict'],'source':G,'cells':4,'operations':3600,'TODO_remaining':29}))
