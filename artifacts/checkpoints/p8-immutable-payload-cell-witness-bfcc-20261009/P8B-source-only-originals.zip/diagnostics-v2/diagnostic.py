#!/usr/bin/env python3
"""Finite Python/SQLite algorithm diagnostic; NOT Rust or a primary study."""
import collections
import datetime
import hashlib
import io
import json
import platform
import sqlite3
import statistics
import struct
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = Path('/workspace/scratch/bfccb8494ba0/round21-oracle-raw-cell-diagnostic-v2')
CASES = ('same_order_equal', 'reverse_order_equal', 'last_row_different')
SCHEDULE = [(case, pair, variant) for case in CASES for pair in range(3)
            for variant in (('old', 'candidate') if pair % 2 == 0 else ('candidate', 'old'))]
ROWS = 4096
ROW_BYTES = 1024
BUDGET_SECONDS = 45
TIERS = (64, 8, 1)
PENDING_BYTES = 64 * 1024
MAX_ROWS = 5_000_000
MAX_CANONICAL_BYTES = 4 * 1024 * 1024 * 1024
MAX_ROW_BYTES = 1024 * 1024
MAX_SCRATCH_BYTES = 8 * 1024 * 1024 * 1024
SCHEMA = '''PRAGMA page_size=4096;
PRAGMA journal_mode=OFF;
PRAGMA synchronous=OFF;
PRAGMA temp_store=FILE;
PRAGMA cache_size=-2048;
PRAGMA mmap_size=0;
PRAGMA max_page_count=2097152;
CREATE TABLE canonical_rows(
    side INTEGER NOT NULL,
    value TEXT COLLATE BINARY NOT NULL,
    ordinal INTEGER NOT NULL,
    PRIMARY KEY(side, value, ordinal)
) WITHOUT ROWID;'''
SORTED_SQL = 'SELECT value FROM canonical_rows WHERE side=?1 ORDER BY value COLLATE BINARY'
ORIGINAL = Path('/dev/shm/root-round21/oracle-order-witness/original/crates/cc-eval/src/benchmark/oracle/streaming.rs')
CANDIDATE = Path('/dev/shm/root-round21/oracle-raw-cell-witness-v2/candidate/crates/cc-eval/src/benchmark/oracle/streaming.rs')

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def h(data):
    return hashlib.sha256(data).hexdigest()

def identity(path):
    b = path.read_bytes()
    return dict(path=str(path), bytes=len(b), sha256=h(b),
                git_blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())

def write_json(path, obj):
    with path.open('x') as f:
        json.dump(obj, f, indent=2, ensure_ascii=False, sort_keys=True)
        f.write('\n')

def canonical(values):
    return json.dumps(values, sort_keys=True, separators=(',', ':'), ensure_ascii=False)

def columns(conn):
    cols = [r[1] for r in conn.execute('PRAGMA table_info("symbols")')]
    assert cols
    return cols

class Projection:
    def __init__(self, cols, counts, key):
        self.cols = cols
        self.values = dict.fromkeys(cols)
        self.counts = counts
        self.key = key

    def serialize(self, row):
        size = sum(len(col) + (len(value.encode()) if isinstance(value, str) else 16)
                   for col, value in zip(self.cols, row))
        assert size <= MAX_ROW_BYTES
        for col, value in zip(self.cols, row):
            assert isinstance(value, (str, int)) and not isinstance(value, bool)
            self.values[col] = value
        text = canonical(self.values)
        for col in self.cols:
            self.values[col] = None
        assert len(text.encode()) <= MAX_ROW_BYTES
        self.counts[self.key] += 1
        return text

def stream(conn):
    cols = columns(conn)
    quoted = ','.join('"'+x.replace('"','""')+'"' for x in cols)
    return cols, conn.execute('SELECT '+quoted+' FROM "symbols"')

def account(current, text):
    value = current + len(text.encode())
    assert value <= MAX_CANONICAL_BYTES and value <= (1 << 64)-1
    return value

def spool(source, scratch, side, total, counts):
    cols, cursor = stream(source)
    project = Projection(cols, counts, 'spool_project_'+str(side))
    scratch.execute('BEGIN')
    statements = {n:'INSERT INTO canonical_rows(side, value, ordinal) VALUES '+', '.join(['(?, ?, ?)']*n) for n in TIERS}
    pending = []
    pending_bytes = 0
    count = 0

    def execute(n, rows):
        scratch.execute(statements[n], [v for text, ordinal in rows for v in (side,text,ordinal)])
        counts['insert_tier_'+str(n)] += 1
        counts['scratch_rows_inserted'] += n

    def flush():
        offset = 0
        for n in TIERS:
            while len(pending)-offset >= n:
                execute(n,pending[offset:offset+n])
                offset += n
        assert offset == len(pending)
        pending.clear()

    for row in cursor:
        assert count < MAX_ROWS
        text = project.serialize(row)
        total = account(total,text)
        size = len(text.encode())
        if size > PENDING_BYTES:
            flush()
            pending_bytes = 0
            execute(1,[(text,count)])
        else:
            if len(pending)==64 or pending_bytes+size > PENDING_BYTES:
                flush()
                pending_bytes = 0
            pending.append((text,count))
            pending_bytes += size
        count += 1
    flush()
    scratch.commit()
    return count,total

def stored(conn):
    row = conn.execute("SELECT rootpage FROM sqlite_schema WHERE type = 'table' AND name = ?1",('symbols',)).fetchone()
    return row is not None and row[0] > 0

def witness(a,b,total,expected,counts):
    if not stored(a) or not stored(b):
        return False,total
    acols,arows = stream(a)
    bcols,brows = stream(b)
    if acols != bcols:
        return False,total
    bp = Projection(bcols,counts,'witness_project_B')
    tentative = total
    count = 0
    for brow in brows:
        assert count < MAX_ROWS
        bv = bp.serialize(brow)
        tentative = account(tentative,bv)
        arow = arows.fetchone()
        if arow is None:
            return False,total
        counts['witness_A_raw_rows'] += 1
        equal = True
        for avalue,bvalue in zip(arow,brow):
            counts['witness_raw_cells_compared'] += 1
            if type(avalue) is not type(bvalue):
                equal = False
            elif isinstance(avalue,float):
                equal = struct.pack('=d',avalue) == struct.pack('=d',bvalue)
            else:
                equal = avalue == bvalue
            if not equal:
                break
        if not equal:
            return False,total
        count += 1
    if arows.fetchone() is None and count==expected:
        return True,tentative
    return False,total

def trial(case,pair,variant,number):
    start_utc = utc()
    started = time.perf_counter_ns()
    counts = collections.Counter({key:0 for key in ('spool_project_0','spool_project_1','witness_project_A','witness_project_B','witness_A_raw_rows','witness_raw_cells_compared','insert_tier_64','insert_tier_8','insert_tier_1','scratch_rows_inserted')})
    run = DATA/f'{number:02d}-{case}-pair{pair}-{variant}'
    run.mkdir()
    a = sqlite3.connect('file:'+str(DATA/case/'A.sqlite')+'?mode=ro',uri=True)
    b = sqlite3.connect('file:'+str(DATA/case/'B.sqlite')+'?mode=ro',uri=True)
    for conn in (a,b):
        conn.execute('BEGIN DEFERRED TRANSACTION')
        assert conn.execute('PRAGMA integrity_check').fetchone()==('ok',)
        assert conn.execute('SELECT COUNT(*) FROM pragma_foreign_key_check').fetchone()==(0,)
    scratch = sqlite3.connect(str(run/'scratch.sqlite'),isolation_level=None)
    scratch.executescript(SCHEMA)
    actual = {key:scratch.execute('PRAGMA '+key).fetchone()[0] for key in ('page_size','journal_mode','synchronous','temp_store','cache_size','mmap_size','max_page_count')}
    assert actual == dict(page_size=4096,journal_mode='off',synchronous=0,temp_store=1,cache_size=-2048,mmap_size=0,max_page_count=2097152)
    ac,total = spool(a,scratch,0,0,counts)
    identical = False
    if variant=='candidate':
        identical,total = witness(a,b,total,ac,counts)
    if identical:
        bc = ac
    else:
        bc,total = spool(b,scratch,1,total,counts)
    ar = scratch.execute(SORTED_SQL,(0,))
    br = scratch.execute(SORTED_SQL,(1,))
    ah,bh = hashlib.sha256(b'['),hashlib.sha256(b'[')
    ao,bo = io.BytesIO(b'['),io.BytesIO(b'[')
    ao.seek(0,2);bo.seek(0,2)
    position = 0
    differences = 0
    while True:
        av = ar.fetchone()
        av = av[0] if av else None
        bv = av if identical else br.fetchone()
        if not identical:
            bv = bv[0] if bv else None
        if av is None and bv is None:
            break
        equal = av==bv or (av is not None and bv is not None and json.loads(av)==json.loads(bv))
        differences += int(not equal)
        for value,hasher,output in ((av,ah,ao),(bv,bh,bo)):
            if value is not None:
                chunk = (',' if position else '').encode()+value.encode()
                hasher.update(chunk)
                output.write(chunk)
        position += 1
    for hasher,output in ((ah,ao),(bh,bo)):
        hasher.update(b']');output.write(b']')
    a.close();b.close();scratch.close()
    wall_ns = time.perf_counter_ns()-started
    result = dict(case=case,pair=pair,variant=variant,ordinal=number,started_UTC=start_utc,finished_UTC=utc(),
                  wall_ns=wall_ns,equal=differences==0,different_row_count=differences,
                  incremental_rows=ac,full_rows=bc,canonical_bytes=total,
                  incremental_sha256=ah.hexdigest(),full_sha256=bh.hexdigest(),
                  digest_scope='diagnostic SHA-256 of exact sorted JSON arrays; NOT original Rust BLAKE3',
                  equal_input_order_witness=identical,work_counters=dict(counts),scratch_pragmas=actual,
                  sorted_outputs={})
    for side,output in (('A',ao),('B',bo)):
        path=run/f'{side}-sorted.json'
        path.write_bytes(output.getvalue())
        result['sorted_outputs'][side]=identity(path)
    assert ac==bc==ROWS and total==2*ROWS*ROW_BYTES
    assert result['equal'] == (case!='last_row_different')
    assert result['different_row_count'] == (1 if case=='last_row_different' else 0)
    assert identical == (variant=='candidate' and case=='same_order_equal')
    write_json(HERE/f'trial-{number:02d}.json',result)
    return result

def main():
    begun = time.monotonic()
    DATA.mkdir(exist_ok=False)
    assert h(ORIGINAL.read_bytes())=='9d9ef3624af2f1a27107baf3c625b7ee29643b8dbedcbf3b39b8a662c98e82a4'
    assert h(CANDIDATE.read_bytes())=='6370b04d008787868666b0c035c8dbb9d92d67dfc3eb1bd790c578b1c2e2ad1c'
    plan=dict(schema='finite-python-sqlite-raw-cell-witness-diagnostic-v2',prepared_UTC=utc(),
              source_original=identity(ORIGINAL),source_candidate=identity(CANDIDATE),driver=identity(Path(__file__)),
              rows=ROWS,canonical_row_bytes=ROW_BYTES,cases=CASES,schedule=SCHEDULE,max_trials=18,budget_seconds=BUDGET_SECONDS,
              insert_tiers=TIERS,pending_bytes=PENDING_BYTES,scratch_schema=SCHEMA,
              environment=dict(python=sys.version,sqlite=sqlite3.sqlite_version,platform=platform.platform(),
                               sqlite_compile_options=[x[0] for x in sqlite3.connect(':memory:').execute('PRAGMA compile_options')]),
              limitations=['Python algorithm transcription of revised raw-cell witness, not Rust or a primary P8 sample.','ASCII text/integer fixture only; no float/blob/error/15-table equivalence claim.','A witness uses typed raw-cell equality and performs no A JSON serialization; B retains original projection/accounting.','Python json sort_keys compact encoding matches this limited JSON subdomain; no original BLAKE3 library is installed.','Sorted outputs are retained in bounded Python byte buffers for audit. This observer work and Python allocation costs differ from Rust streaming.','Scratch/input files use this host overlay filesystem, not the original runner storage.','Exactly three pre-fixed pairs per case, AB/BA/AB; no threshold, sample exclusion, retries or fastest-of selection.'])
    write_json(HERE/'pre-execution-plan.json',plan)
    rows=[]
    for i in range(ROWS):
        d=dict(name=f'row-{i:08d}',payload='',value=100000+i)
        d['payload']='x'*(ROW_BYTES-len(canonical(d).encode()))
        assert len(canonical(d).encode())==ROW_BYTES
        rows.append((d['name'],d['payload'],d['value']))
    inputs=[]
    for case in CASES:
        directory=DATA/case;directory.mkdir()
        for side in ('A','B'):
            path=directory/f'{side}.sqlite'
            conn=sqlite3.connect(str(path))
            conn.execute('CREATE TABLE symbols(name TEXT NOT NULL,payload TEXT NOT NULL,value INTEGER NOT NULL)')
            selected=rows if side=='A' or case!='reverse_order_equal' else list(reversed(rows))
            if side=='B' and case=='last_row_different':
                selected=list(rows)
                name,payload,value=selected[-1]
                selected[-1]=(name,payload[:-1]+'y',value)
            conn.executemany('INSERT INTO symbols VALUES(?,?,?)',selected)
            conn.commit();conn.close();inputs.append(identity(path))
    write_json(HERE/'input-files-before.json',inputs)
    results=[]
    comparisons=[]
    for number,(case,pair,variant) in enumerate(SCHEDULE,1):
        if time.monotonic()-begun >= BUDGET_SECONDS:
            write_json(HERE/'incomplete.json',dict(completed=len(results),remaining=len(SCHEDULE)-len(results),reason='fixed diagnostic budget'))
            return 2
        with (HERE/'events.jsonl').open('a') as f:
            f.write(json.dumps(dict(event='trial_started',ordinal=number,case=case,pair=pair,variant=variant,UTC=utc()))+'\n')
        result=trial(case,pair,variant,number);results.append(result)
        with (HERE/'events.jsonl').open('a') as f:
            f.write(json.dumps(dict(event='trial_finished',ordinal=number,wall_ns=result['wall_ns'],UTC=utc()))+'\n')
        if number%2==0:
            old=next(x for x in results[-2:] if x['variant']=='old')
            new=next(x for x in results[-2:] if x['variant']=='candidate')
            keys=('equal','different_row_count','incremental_rows','full_rows','canonical_bytes','incremental_sha256','full_sha256')
            assert {k:old[k] for k in keys}=={k:new[k] for k in keys}
            for side in ('A','B'):
                assert Path(old['sorted_outputs'][side]['path']).read_bytes()==Path(new['sorted_outputs'][side]['path']).read_bytes()
            comparisons.append(dict(case=case,pair=pair,order=[x['variant'] for x in results[-2:]],
                                    old_wall_ns=old['wall_ns'],candidate_wall_ns=new['wall_ns'],
                                    candidate_over_old=new['wall_ns']/old['wall_ns'],all_sorted_bytes_equal=True,all_shared_results_equal=True))
    after=[identity(Path(x['path'])) for x in inputs]
    assert inputs==after
    write_json(HERE/'input-files-after.json',after)
    summary=dict(scope=plan['limitations'],all_18_completed=True,all_9_pairs_exact_sorted_bytes_and_shared_results_equal=True,
                 elapsed_including_setup_and_audit_seconds=time.monotonic()-begun,comparisons=comparisons,
                 per_case={case:dict(pairs=3,all_ratios=[x['candidate_over_old'] for x in comparisons if x['case']==case],
                                    median_ratio=statistics.median(x['candidate_over_old'] for x in comparisons if x['case']==case)) for case in CASES},
                 original_inputs_before_after_equal=True,performance_acceptance_threshold=None,new_primary_samples=0,new_TODO_completions=0)
    write_json(HERE/'result.json',summary)
    print(json.dumps(summary,sort_keys=True))
    return 0

if __name__=='__main__':
    sys.exit(main())
