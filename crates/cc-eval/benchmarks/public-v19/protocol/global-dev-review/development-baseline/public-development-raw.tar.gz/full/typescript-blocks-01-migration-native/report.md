# CodeCortex benchmark baseline

Suite: `V19 TypeScript 01-migration codecortex-native-v1 candidate; review/custody pending`
Adapter: `mcp-stdio`
Scoring: `Native`
Measurement profile: `quality`

Status: **gate_failed** (exit 1)

Queries: 15; measured rows: 45.
Mean Top-1: 0.500000; mean nDCG@10: 0.564229.

These are baseline observations, not a release quality certificate.
Latency: Distribution { samples: 0, p50_us: None, p95_us: None, max_us: None, tail_claim: "insufficient_for_tail_claim" }; samples are retained, not best-of.
Source evidence: 0 invalid, 0 unverified hits.

| Case | Top-1 | nDCG@10 | Repetitions |
|---|---:|---:|---:|
| v19.typescript.f0001.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0002.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0003.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0004.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0006.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0008.en01 | 1.000000 | 1.000000 | 3 |
| v19.typescript.f0009.en01 | 0.000000 | 0.444123 | 3 |
| v19.typescript.f0011.en01 | 0.000000 | 0.000000 | 3 |
| v19.typescript.f0012.en01 | 0.000000 | 0.326626 | 3 |
| v19.typescript.f0013.en01 | 0.000000 | 0.000000 | 3 |
| v19.typescript.f0015.en01 | 0.000000 | 0.000000 | 3 |
| v19.typescript.f0016.en01 | 0.000000 | 0.000000 | 3 |

## Failures

- v19.typescript.f0008.en01 Partial
- v19.typescript.f0016.en01 Partial
- v19.typescript.f0012.en01 Partial
- v19.typescript.f0006.en01 Partial
- v19.typescript.f0002.en01 Partial
- v19.typescript.f0013.en01 Partial
- v19.typescript.f0020.en01 Partial
- v19.typescript.f0020.en01 no-answer failure
- v19.typescript.f0011.en01 Partial
- v19.typescript.f0019.en01 Partial
- v19.typescript.f0019.en01 no-answer failure
- v19.typescript.f0009.en01 Partial
- v19.typescript.f0003.en01 Partial
- v19.typescript.f0001.en01 Partial
- v19.typescript.f0015.en01 Partial
- v19.typescript.f0018.en01 Partial
- v19.typescript.f0018.en01 no-answer failure
- v19.typescript.f0004.en01 Partial
- v19.typescript.f0008.en01 Partial
- v19.typescript.f0006.en01 Partial
- v19.typescript.f0002.en01 Partial
- v19.typescript.f0012.en01 Partial
- v19.typescript.f0019.en01 Partial
- v19.typescript.f0019.en01 no-answer failure
- v19.typescript.f0001.en01 Partial
- v19.typescript.f0009.en01 Partial
- v19.typescript.f0004.en01 Partial
- v19.typescript.f0013.en01 Partial
- v19.typescript.f0011.en01 Partial
- v19.typescript.f0003.en01 Partial
- v19.typescript.f0016.en01 Partial
- v19.typescript.f0018.en01 Partial
- v19.typescript.f0018.en01 no-answer failure
- v19.typescript.f0015.en01 Partial
- v19.typescript.f0020.en01 Partial
- v19.typescript.f0020.en01 no-answer failure
- v19.typescript.f0011.en01 Partial
- v19.typescript.f0004.en01 Partial
- v19.typescript.f0001.en01 Partial
- v19.typescript.f0018.en01 Partial
- v19.typescript.f0018.en01 no-answer failure
- v19.typescript.f0019.en01 Partial
- v19.typescript.f0019.en01 no-answer failure
- v19.typescript.f0006.en01 Partial
- v19.typescript.f0020.en01 Partial
- v19.typescript.f0020.en01 no-answer failure
- v19.typescript.f0013.en01 Partial
- v19.typescript.f0012.en01 Partial
- v19.typescript.f0016.en01 Partial
- v19.typescript.f0003.en01 Partial
- v19.typescript.f0009.en01 Partial
- v19.typescript.f0015.en01 Partial
- v19.typescript.f0008.en01 Partial
- v19.typescript.f0002.en01 Partial