"""Read accepted build/capacity receipts, then retain a small complete support set.

This does not reopen original ZIPs or execute any original function or ELF.
"""
import datetime
import hashlib
import json
from pathlib import Path
import stat
import zipfile

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'round34-full-cohort-build-capacities-intake/attempt01'
PREP = ROOT / 'round34-full-cohort-build-capacities-preparation'
SOURCE = ROOT / 'round32-capture-context-admission/guard-view'
REGISTRATION = ROOT / 'round34-full-cohort-first-original-intake-registration.json'
LOG = ROOT / 'round34-full-cohort-original-job-logs/114099388607-original.log'
PREFIX = 'artifacts/checkpoints/p8-round34-full-cohort-build-capacities-bfcc-20261010/'

def identity(p):
    raw = p.read_bytes()
    return {'local_path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
            'posix_mode': oct(stat.S_IMODE(p.stat().st_mode))}

def save(p, v):
    with p.open('x') as f:
        json.dump(v, f, ensure_ascii=False, indent=2)
        f.write('\n')

binding = json.loads((OUT / 'binding.json').read_text())
custody = json.loads((OUT / 'original-six-zip-custody.json').read_text())
terminal = json.loads((OUT / 'build-terminal.json').read_text())
execution = json.loads((OUT / 'original-validate-build.execution.json').read_text())
assert terminal['original_validate_build_calls'] == 1 and terminal['original_validate_build_exit'] == 0
assert execution['exit_code'] == 0
assert json.loads((OUT / 'source-evidence-before.json').read_text()) == json.loads((OUT / 'source-evidence-after.json').read_text())
registration = json.loads(REGISTRATION.read_text())
jobs = json.loads(registration['original_api_snapshot']['full_cohort_jobs']['value']['structuredContent']['content'])['jobs']
build_job = next(j for j in jobs if j['id'] == 114099388607)
assert build_job['head_sha'] == binding['G'] and build_job['run_id'] == binding['run_id'] and build_job['run_attempt'] == 1
assert build_job['conclusion'] == 'success' and build_job['status'] == 'completed'
build = json.loads((OUT / 'original-validate-build-result.json').read_text())['original_build_record']
caps = []
for row in sorted((r for r in custody['records'] if r['kind'] == 'capacity'), key=lambda r:r['scale']):
    scale = row['scale']
    receipt_path = Path(row['extracted_directory']) / 'receipt.json'
    c = json.loads(receipt_path.read_text())
    assert list(row['members']) == ['receipt.json']
    assert c['schema_version'] == 1 and c['scale'] == scale and c['profile'] == 'scale_capacity_v1'
    assert c['source_commit'] == binding['G'] and c['observer_sha256'] == binding['observer_inputs']['scripts/p8_runner_capacity.py']['sha256']
    context = c['context']
    assert context['GITHUB_RUN_ID'] == str(binding['run_id']) and context['GITHUB_RUN_ATTEMPT'] == '1'
    assert context['GITHUB_JOB'] == 'preflight' and context['GITHUB_REPOSITORY'] == 'jyqj/codecortex'
    assert context['P8_EXPECTED_SOURCE'] == binding['G']
    assert context['RUNNER_ENVIRONMENT'] == 'github-hosted' and context['RUNNER_OS'] == 'Linux' and context['ImageOS'] == 'ubuntu24'
    required = scale * 256 * 1024 + 4 * 1024**3
    assert c['required_free_bytes'] == required
    assert c['status'] == 'capacity_available' and type(c['exit_code']) is int and c['exit_code'] == 0
    assert c['artifact_state'] == 'sealed_after_commands_finished' and c['steps'] == [] and c['files'] == {}
    assert c['final']['free_bytes'] >= required
    caps.append({'scale': scale, 'artifact_id': row['artifact']['id'], 'official_zip_sha256': row['artifact']['digest'],
                 'original_receipt': identity(receipt_path), 'original_status': c['status'], 'original_exit_code': c['exit_code'],
                 'original_job': context['GITHUB_JOB'], 'physical_capacity_profile': c['profile'],
                 'required_free_bytes': required, 'initial_free_bytes': c['initial']['free_bytes'],
                 'final_free_bytes': c['final']['free_bytes'], 'recorded_SDK_commands': 0,
                 'scope': 'Point-in-time hosted VM capacity. Not a product sample or later capacity guarantee.'})
save(OUT / 'five-capacity-receipts-review.json', {'schema': 'p8-five-original-capacity-receipts-readonly-review-v1',
     'source': binding['G'], 'run_id': binding['run_id'], 'attempt': 1, 'receipts': caps,
     'observer_not_executed_locally': True, 'initial_final_free_bytes_need_not_equal': True})
lines = LOG.read_text().splitlines()
needles = ['9cc6bf49f6dd81e4069a8004eed49addba0ab79b', 'cargo fmt --all -- --check',
           'cargo test --locked -p cc-eval --test p8_scale', 'test result: ok. 16 passed; 0 failed; 0 ignored;',
           'python3 scripts/p8_scale_matrix.py build', '"status": "passed"',
           'db774b0964b648ba12ae0afcf50827cbe43c532c336ab20f9c4c6c06b2e0d269', 'Artifact ID 11655028182']
matches = {s: [{'line': n, 'text': line} for n, line in enumerate(lines, 1) if s in line] for s in needles}
assert all(matches.values())
log_review = {'schema': 'p8-full-cohort-original-build-log-scoped-review-v1', 'original_log': identity(LOG),
              'actual_build_job': build_job, 'exact_matches': matches,
              'engineering_scope': 'Original exact-source checkout, formatting then 16 p8_scale Rust protocol controls and a fresh release producer build. No diagnostic host-controls claim and no scale measurement credit.'}
save(OUT / 'original-build-job-log-review.json', log_review)
binary = OUT / 'extracted/build/p8-scale'
report = {'schema': 'p8-full-cohort-build-and-capacities-original-intake-v1',
          'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'verdict': 'accepted_scoped_own_cohort_original_build_and_five_capacity_receipts',
          'source': binding['G'], 'source_tree': binding['G_tree'], 'run_id': binding['run_id'], 'attempt': 1,
          'event': binding['event'], 'workflow': binding['workflow_path'], 'binding': identity(OUT / 'binding.json'),
          'build_artifact': next(r for r in custody['records'] if r['kind'] == 'build'),
          'original_build': {'receipt': identity(OUT / 'extracted/build/build.json'), 'status': build['status'],
              'source_manifest_sha256': build['source_manifest_sha256'], 'product_inputs': 1096, 'driver_inputs': 2,
              'producer_root': build['build_root'], 'producer_target_directory': build['target_directory'],
              'binary_bytes': build['binary_bytes'], 'binary_sha256': build['binary_sha256'], 'binary_blake3': build['binary_blake3']},
          'original_validate_build': {'actual_calls': 1, 'exit_code': 0, 'execution': identity(OUT / 'original-validate-build.execution.json'),
              'result': identity(OUT / 'original-validate-build-result.json'),
              'ELF_actual_invocation': [str(binary), '--hash-file', str(binary)],
              'ELF_exit_zero_evidence': 'The unchanged native_digest uses subprocess.run(check=True), and validate_build returned successfully after matching its result.',
              'inner_stdio_boundary': 'The original function captured hash-mode stdout/stderr internally. Its returned matching BLAKE3 is retained; separate inner raw stdio was not exported. Outer caller stdout/stderr are retained empty. No second ELF call was made.'},
          'capacities': caps, 'input_snapshot_count': terminal['snapshot_count'], 'inputs_before_after_equal': True,
          'engineering_build_log_review': identity(OUT / 'original-build-job-log-review.json'),
          'no_duplicate_prior_validation': True, 'shard_zip_files_not_opened': True,
          'original_validate_shard_calls': 0, 'original_inspect_raw_calls': 0,
          'accepted_shards_by_this_receiver': 0, 'accepted_samples_by_this_receiver': 0, 'TODO_credit': 0,
          'separate_diagnostic_run_not_reused': 38012409915,
          'boundary': 'The fresh build record is from this full cohort even where immutable binary bytes equal the separate diagnostic build. Capacity does not validate measurements. Whole study remains governed by its own original shard/aggregate predicates.',
          'whole_ZIP_custody_owner': 'root; six whole original ZIPs retained separately, not nested in this support archive'}
save(OUT / 'build-capacities-intake-review.json', report)
selected = []
paths = [*sorted(PREP.glob('*.py')), *sorted(PREP.glob('receive-attempt01.*')),
         *sorted(p for p in OUT.iterdir() if p.is_file()), REGISTRATION, LOG,
         ROOT / 'round32-100k-diagnostic-intake-preparation/call-original-validator-once.py']
paths += [SOURCE / x for x in (*binding['driver_inputs'], *binding['observer_inputs'])]
paths += [p for p in (OUT / 'extracted').rglob('*') if p.is_file() and p.name != 'p8-scale']
assert len(paths) == len(set(paths))
for p in sorted(paths):
    selected.append({**identity(p), 'archive_path': str(p.relative_to(ROOT))})
sealed = OUT.parent / 'sealed'
sealed.mkdir(exist_ok=False)
selection = {'schema': 'selected-originals-no-wholeZIP-or-ELF-v1', 'files': selected,
             'files_count': len(selected), 'bytes': sum(x['bytes'] for x in selected),
             'whole_ZIPs_and_ELF': 'Not nested. Original build ZIP retains the ELF; root publishes the whole ZIPs separately.'}
save(sealed / 'archive-selection.json', selection)
archive = sealed / 'full-cohort-build-five-capacities-original-support.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for row in selected:
        z.write(row['local_path'], row['archive_path'])
    z.write(sealed / 'archive-selection.json', 'archive-selection.json')
leaves = [(archive, 'full-cohort-build-five-capacities-original-support.zip'),
          (OUT / 'build-capacities-intake-review.json', 'build-capacities-intake-review.json'),
          (sealed / 'archive-selection.json', 'archive-selection.json')]
manifest = {'schema': 'three-pure-evidence-leaves-v1', 'prefix': PREFIX,
            'entries': [{**identity(p), 'repository_path': PREFIX + name, 'git_mode': '100644'} for p, name in leaves],
            'actual_commit': None, 'root_owns_ref_publication': True}
save(sealed / 'upload-manifest.json', manifest)
print(json.dumps({'verdict': report['verdict'], 'capacity_scales': [c['scale'] for c in caps],
                  'selection_files': len(selected), 'support': identity(archive), 'manifest': str(sealed / 'upload-manifest.json')}))
