import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import zipfile

B = Path('/workspace/scratch/a217aaae3bde/original-173-platform-gates')
OUT = Path('/dev/shm/a217aaae3bde/platform-review/round30-old173-reclamation')
MODE = os.environ.get('RECLAIM_ACTION', 'plan')

def sha(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def st(p):
    s = p.lstat()
    return dict(dev=s.st_dev, ino=s.st_ino, mode=s.st_mode, bytes=s.st_size,
                mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns,
                nlink=s.st_nlink, blocks=s.st_blocks)

def safe_file(p):
    assert B in p.parents and not p.is_symlink() and p.is_file(), str(p)
    for parent in p.parents:
        if parent == B: break
        assert not parent.is_symlink(), str(parent)

def info(p):
    return dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))

def dump(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

OUT.mkdir(parents=True, exist_ok=True)
if MODE == 'plan':
    original = B/'original-materialization-receipt.json'
    intake = B/'zip-intake-verification.json'
    official = B/'original-artifact-metadata.json'
    receipt = json.loads(original.read_text())
    intake_rows = {x['id']: x for x in json.loads(intake.read_text())['rows']}
    metas = {}
    for capture in json.loads(official.read_text())['captures']:
        body = capture['body']
        assert len(body['artifacts']) == body['total_count']
        for a in body['artifacts']: metas[a['id']] = a
    pairs = json.loads((B/'platform-pairs.json').read_text())
    bundle_ids = {x[0] for x in pairs}
    assert len(receipt['rows']) == len(intake_rows) == 18 and len(bundle_ids) == 8
    roots, candidates, retained, archives = [], [], [], []
    for row in receipt['rows']:
        aid = row['artifact_id']; archive = Path(row['original_zip'])
        assert archive == B/'zips'/str(aid)/(str(aid)+'.zip')
        safe_file(archive)
        md = metas[aid]; expected = intake_rows[aid]
        assert archive.stat().st_size == md['size_in_bytes'] == expected['bytes']
        assert 'sha256:'+sha(archive) == md['digest']
        assert sha(archive) == row['original_zip_sha256'] == expected['sha256']
        assert md['workflow_run']['head_sha'] == '275e8799d4947d297329073eaa3ca675d3fd0777'
        archive_before = st(archive)
        original_files = {x['path']: x for x in row['files']}
        destinations = [(Path(row['extracted']), 'original_extraction')]
        if aid in bundle_ids:
            destinations.append((B/'platform-review/collector-input'/str(aid), 'collector_hardlink_copy'))
        with zipfile.ZipFile(archive) as z:
            members = {x.filename: x for x in z.infolist() if not x.is_dir()}
            assert set(members) == set(original_files)
            hashes = {}
            for name, zi in members.items():
                old = original_files[name]
                assert zi.file_size == old['bytes'] and oct(zi.external_attr >> 16) == old['zip_mode']
                with z.open(zi) as f: digest = hashlib.file_digest(f, 'sha256').hexdigest()
                assert digest == old['sha256']; hashes[name] = digest
            for root, kind in destinations:
                assert root.is_dir() and not root.is_symlink()
                roots.append(str(root))
                actual = {p.relative_to(root).as_posix(): p for p in root.rglob('*') if not p.is_dir() or p.is_symlink()}
                for name, p in actual.items():
                    if name not in members:
                        retained.append(dict(path=str(p), reason='unknown original member; retain file and ancestors')); continue
                    safe_file(p); before = st(p); digest = sha(p); after = st(p)
                    old = original_files[name]; expected_mode = int(old['materialized_mode'], 8)
                    if before != after or before['bytes'] != old['bytes'] or digest != hashes[name] or stat.S_IMODE(before['mode']) != expected_mode:
                        retained.append(dict(path=str(p), reason='stat/bytes/hash/mode differs from exact original materialization; no repair', stat=after, sha256=digest, expected_mode=oct(expected_mode))); continue
                    if kind == 'collector_hardlink_copy':
                        peer = Path(row['extracted'])/name
                        assert peer.stat().st_dev == before['dev'] and peer.stat().st_ino == before['ino']
                    candidates.append(dict(path=str(p), kind=kind, artifact_id=aid, member=name, bytes=before['bytes'], sha256=digest, expected_mode=expected_mode, stat=before))
                missing = set(members)-set(actual)
                for name in sorted(missing): retained.append(dict(path=str(root/name), reason='already absent; not removed by this run'))
            if aid == 11598517678:
                p=B/'gates-review/cc-eval'; safe_file(p); before=st(p); digest=sha(p); after=st(p)
                original_cli=json.loads((B/'gates-review/review.json').read_text())
                assert digest == hashes['cc-eval'] and before['bytes'] == original_files['cc-eval']['bytes']
                assert before == after and stat.S_IMODE(before['mode']) == 0o555
                candidates.append(dict(path=str(p),kind='retained_cli_copy',artifact_id=aid,member='cc-eval',bytes=before['bytes'],sha256=digest,expected_mode=0o555,stat=before))
        assert st(archive) == archive_before and 'sha256:'+sha(archive) == md['digest']
        archives.append(dict(**info(archive),artifact_id=aid,stat=archive_before))
    assert len({x['path'] for x in candidates}) == len(candidates)
    inode_counts=collections.Counter((x['stat']['dev'],x['stat']['ino']) for x in candidates)
    inode_rows={ (x['stat']['dev'],x['stat']['ino']):x['stat'] for x in candidates }
    expected_freed=sum(s['blocks']*512 for key,s in inode_rows.items() if inode_counts[key] == s['nlink'])
    protection=[info(p) for p in B.iterdir() if p.is_file()]
    report=dict(schema_version=1,status='exact_original_member_candidates_verified_not_yet_removed',reviewer='/root/pr_audit',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),authorization='Root round30 explicitly authorized bounded reclamation after complete verification; peer runtime_closeout and scale_closeout confirm no current or future readers/writers of these old173 derived paths.',scope='Only old173 verified extracted original members, completed old173 collector hardlinks and copied retained CLI. All current C/LG, source/views, ZIPs, metadata, helpers and unique replay/review results stay.',original_materialization_receipt=info(original),original_intake=info(intake),official_metadata=info(official),archives=archives,roots=roots,candidates=candidates,retained=retained,protected_top_level_files=protection,expected_unique_inode_bytes_reclaimed=expected_freed,source_or_native_runs=0,remaining_todos=29)
    dump(OUT/'candidate.json',report)
    print(json.dumps(dict(path=str(OUT/'candidate.json'),sha256=sha(OUT/'candidate.json'),candidate_count=len(candidates),retained_count=len(retained),expected_freed_bytes=expected_freed)))
elif MODE == 'reclaim':
    cp=OUT/'candidate.json'; plan=json.loads(cp.read_text()); failures=[]
    for x in plan['archives']:
        p=Path(x['path']);safe_file(p)
        if st(p)!=x['stat'] or sha(p)!=x['sha256']:failures.append(dict(path=str(p),reason='archive changed'))
    for x in plan['candidates']:
        p=Path(x['path']);safe_file(p)
        if st(p)!=x['stat'] or sha(p)!=x['sha256']:failures.append(dict(path=str(p),reason='candidate changed'))
    assert not failures, failures
    fs=os.statvfs(B);before=fs.f_bavail*fs.f_frsize;removed=[]
    for x in plan['candidates']:
        p=Path(x['path']);s=st(p)
        # Removing another hardlink only changes nlink/ctime on the same inode.
        assert all(s[k]==x['stat'][k] for k in ('dev','ino','mode','bytes','mtime_ns','blocks'))
        p.unlink();removed.append(x['path'])
    dirs=[]
    for root in plan['roots']:
        p=Path(root)
        if p.exists():dirs.extend(q for q in p.rglob('*') if q.is_dir() and not q.is_symlink());dirs.append(p)
    removed_dirs=[]
    for p in sorted(set(dirs),key=lambda x:len(x.parts),reverse=True):
        try:p.rmdir();removed_dirs.append(str(p))
        except OSError:pass
    for x in plan['archives']:
        p=Path(x['path']);assert st(p)==x['stat'] and sha(p)==x['sha256']
    for x in plan['protected_top_level_files']:
        p=Path(x['path']);assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256']
    fs=os.statvfs(B);after=fs.f_bavail*fs.f_frsize
    result=dict(schema_version=1,status='only_verified_old173_derived_files_removed',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidate=info(cp),removed_files=removed,removed_empty_directories=removed_dirs,retained_unmatched=plan['retained'],original_archives_unchanged=True,protected_top_level_files_unchanged=True,bavail_bytes_before=before,bavail_bytes_after=after,actual_bavail_increase=after-before,remaining_todos=29,new_native_runs=0)
    dump(OUT/'reclamation-receipt.json',result)
    print(json.dumps(dict(path=str(OUT/'reclamation-receipt.json'),sha256=sha(OUT/'reclamation-receipt.json'),removed_files=len(removed),bavail_before=before,bavail_after=after)))
else: raise ValueError(MODE)
