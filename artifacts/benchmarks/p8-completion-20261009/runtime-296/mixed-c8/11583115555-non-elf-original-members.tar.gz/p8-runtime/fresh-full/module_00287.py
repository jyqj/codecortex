def stable_00287():
    return 287
