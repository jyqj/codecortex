from pathlib import Path
import json,hashlib,zipfile,stat,datetime
B=Path(__file__).resolve().parent;D=B/"increment-50k24-29-and-10k1-8";O=D/"sealed";O.mkdir(exist_ok=False)
PREFIX="artifacts/checkpoints/p8-round27-cold044-50k24-29-10k1-8-bfcc-20261009/"
def get(p):return json.loads(p.read_text())
def meta(p):
 d=p.read_bytes();return {"bytes":len(d),"sha256":hashlib.sha256(d).hexdigest(),"git_blob":hashlib.sha1(f"blob {len(d)}".encode()+bytes([0])+d).hexdigest(),"mode":oct(stat.S_IMODE(p.stat().st_mode))}
def write(p,d):p.write_text(json.dumps(d,sort_keys=True,ensure_ascii=False,indent=2)+"\n")
def clean(x):
 if isinstance(x,dict):return {k:("[REDACTED temporary signed URL]" if k=="download_url" else clean(v)) for k,v in x.items()}
 if isinstance(x,list):return [clean(v) for v in x]
 if isinstance(x,str) and "https://" in x and ("sig=" in x or "skoid=" in x):return "[REDACTED signed-transfer-bearing text; original kept locally]"
 return x
claim=get(D/"claim-input.json")["ledger"];originals=[];samples=[];sources=[]
for s in claim["slots"]:
 r=B/"raw"/str(s["measurement"]["id"]);v=r/"original-validation-attempt01";p=get(v/"receipt.json");child=get(r/"validator-child.json");a=get(v/"original-validate-shard-output.json")
 assert p["exit_code"]==child["exit_code"]==0 and p["inputs_unchanged"] and len(a["measurements"])==1
 assert a["plan"]["files"]==[s["scale"]] and a["plan"]["shard"]["index"]==s["repetition"]
 samples.append({"scale":s["scale"],"repetition":s["repetition"],"artifact_id":s["measurement"]["id"],"receipt":meta(v/"receipt.json"),"output":meta(v/"original-validate-shard-output.json"),"sample":a["measurements"][0],"study":a["study"],"plan":a["plan"],"child_exit":0})
 for k in ["measurement","capacity"]:
  art=s[k];p=B/"raw"/str(art["id"])/(art["name"]+"-original.zip");m=meta(p);assert m["bytes"]==art["size_in_bytes"] and "sha256:"+m["sha256"]==art["digest"]
  originals.append({"local_path":str(p),"repository_path":PREFIX+"original-zips/"+p.name,"artifact":art,"kind":k,**m})
  for f in sorted(p.parent.rglob("*")):
   if not f.is_file() or f.suffix==".zip" or "extracted" in f.parts:continue
   sources.append((f,f.relative_to(B).as_posix()))
  if k=="capacity":
   files=list((p.parent/"capacity-transport-extracted").rglob("*.json"));assert len(files)==1;c=get(files[0]);assert c["source_commit"]==claim["source"] and c["scale"]==s["scale"] and c["context"]["GITHUB_RUN_ID"]=="37954851017" and c["context"]["GITHUB_RUN_ATTEMPT"]=="1" and c["status"]=="capacity_available" and c["exit_code"]==0
assert len(samples)==14 and len(originals)==28
assert get(D/"intake/whole-source-before.json")==get(D/"intake/whole-source-after.json")
summary={"schema":"cold044-incremental-mixed14-original-intake-v1","sealed":datetime.datetime.now(datetime.timezone.utc).isoformat(),"source":claim["source"],"run_id":37954851017,"attempt":1,"slots":[{"scale":s["scale"],"repetition":s["repetition"]} for s in claim["slots"]],"new_accepted_samples":14,"accepted_union":71,"accepted_union_scope":"16 owner original intakes +41 previously published root intakes +these14; owner6 previously intaken still await owner append publication","published_before_this_increment":51,"published_after_this_increment":65,"owner_unpublished":6,"registered_total":150,"aggregate_or_workload_executed":False,"new_build_validator_executions":0,"original_shard_validator_executions":14,"parent_evidence_commit":"2c20e8bf3d505a67ad7b0bad47815978b1a0e18e","parent_evidence_prefix":"artifacts/checkpoints/p8-round26-cold044-50k18-23-bfcc-20261009/","reuse":"Exact original source0441095+5observer and accepted original build are referenced from39cc355 selected components; previous7b647 and6at2c20 retained. No old sample rerun/copy.","original_15_table_parity_preserved":True,"newly_completed_todos":0,"remaining_todos":29,"samples":samples,"originals":originals}
write(O/"summary.json",summary)
for p in sorted(D.rglob("*")):
 if p.is_file() and O not in p.parents:sources.append((p,p.relative_to(B).as_posix()))
for p in [B/"validate-original-cold-shard.mixed14.py",B/"intake-next-mixed14.py",Path(__file__),O/"summary.json"]:sources.append((p,p.relative_to(B).as_posix()))
assert len({n for p,n in sources})==len(sources)
entries=[]
for p,n in sources:
 data=p.read_bytes();actual=p;redacted=False
 if p.suffix==".json":
  val=get(p);cv=clean(val)
  if cv!=val:
   actual=O/"sanitized"/n;actual.parent.mkdir(parents=True,exist_ok=True);write(actual,cv);redacted=True
 m=meta(actual);entries.append({"local_path":str(actual),"member_path":n,**m,**({"redaction":"signed URL only; original receipt retained locally","original_sha256":hashlib.sha256(data).hexdigest()} if redacted else {})})
write(O/"archive-selection.json",{"schema":"new-mixed14-selected-originals-v1","entries":entries,"file_count":len(entries),"reuse_parent":summary["parent_evidence_commit"],"scope":"Only new14 intake and28 ZIP metadata, raw retained in separate originals; no prior355 components copied"})
zpath=O/"cold044-mixed14-original-intake-support.zip"
with zipfile.ZipFile(zpath,"x",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for e in entries:
  p=Path(e["local_path"]);d=p.read_bytes();assert hashlib.sha256(d).hexdigest()==e["sha256"];i=zipfile.ZipInfo(e["member_path"]);i.create_system=3;i.external_attr=(stat.S_IFREG|int(e["mode"],8))<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,d)
 z.write(O/"archive-selection.json","archive-selection.json")
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 for e in entries:assert hashlib.sha256(z.read(e["member_path"])).hexdigest()==e["sha256"]
pub=[]
for e in originals:pub.append({"local_path":e["local_path"],"path":e["repository_path"],"mode":"100644","type":"blob","sha":e["git_blob"],"bytes":e["bytes"],"sha256":e["sha256"]})
for p in [O/"summary.json",O/"archive-selection.json",zpath]:
 e=meta(p);pub.append({"local_path":str(p),"path":PREFIX+p.name,"mode":"100644","type":"blob","sha":e["git_blob"],"bytes":e["bytes"],"sha256":e["sha256"]})
write(O/"publication-manifest.json",{"schema":"exact-new-mixed14-evidence-publication-v1","observed_parent":"2c20e8bf3d505a67ad7b0bad47815978b1a0e18e","actual_publication_parent":None,"parent_chosen_by_root_at_publication":True,"prefix":PREFIX,"entries":pub,"old_files_replaced":False})
print(json.dumps({"publication":meta(O/"publication-manifest.json"),"support":meta(zpath),"selected_files":len(entries),"original_zips":28,"new_samples":14}))

