"""Non-author read-only receipt peer. No imports of product/validator, ZIP or ELF.

Reads already-extracted JSONL once to retain original parity/closure observations;
does not recompute oracle equality or repeat original semantic validation.
"""
import collections
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/bfccb8494ba0')
IN = ROOT / 'R42-first12-intake'
OUT = Path(__file__).resolve().parent
BUILD = ROOT / 'round42-new45-build-original-intake'
SOURCE = 'f97c5068d056969705e8387ba1f37d83847f5bee'
RUN = 38026411200
inputs = {}

def identity(p, data):
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}

def read(p):
    b = p.read_bytes()
    inputs[str(p)] = identity(p, b)
    return b

def load(p):
    return json.loads(read(p))

def save(name, data):
    (OUT/name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
terminal = load(IN/'terminal.json')
tuple_ = load(BUILD/'validation-attempt01/original-validate-build-return.json')
registry = load(BUILD/'original-build/task-registry.json')
task_build_hash = hashlib.sha256(read(BUILD/'original-build/task-build.json')).hexdigest()
assert terminal['source'] == SOURCE and terminal['run_id'] == RUN and terminal['attempt'] == 1
assert registry['cell_count'] == 45 and registry['record_count'] == 85
assert registry['source_commit'] == SOURCE and registry['repetitions'] == 1
assert load(IN/'shared-source-build-before.json') == load(IN/'shared-source-build-after.json')
job_wrapper = load(OUT/'producer-jobs.official-original.json')
jobs = json.loads(job_wrapper['response']['structuredContent']['content'])['jobs']
tables = {'document_manifest','resolution_frontier','semantic_edges','dispatch_sites',
          'resolution_manifests','resolution_dependencies','public_surfaces','files','symbols',
          'imports','symbol_refs','call_edges','chunks','test_edges','routes'}
expected = {(p,s,0) for p in ('no_op','body','api','config') for s in (1000,5000,10000)}
assert {tuple(r['slot']) for r in terminal['records']} == expected
selected, cells = [], []
for item in terminal['records']:
    profile, scale, repetition = item['slot']
    d = IN/f'{profile}-{scale}-{repetition}'
    sd = d/'original-shard'
    nd = sd/'native-shard/native'
    returned = load(d/'original-validate-shard-return.json')
    execution = load(d/'original-validator-execution.json')
    observed_stdout = read(d/'original-validator.stdout')
    stdout_path = d/'original-validator.stdout'
    if (profile, scale) == ('api', 1000):
        assert observed_stdout == b''
        stdout_path = OUT/'api-1000-original-stdout-recovered-from-same-digest-return.json'
    assert read(stdout_path) == read(d/'original-validate-shard-return.json')
    assert not read(d/'original-validator.stderr')
    assert execution['exit_code'] == 0 and execution['original_validate_shard_calls'] == 1
    assert execution['validate_build_calls'] == execution['measurement_or_compile_calls'] == 0
    assert inputs[str(stdout_path)]['sha256'] == execution['stdout']['sha256']
    assert load(d/'shard-before.json') == load(d/'shard-after.json')
    original = load(sd/'task-shard.json')
    native = load(nd/'report.json')
    assert native['summary'] == load(nd/'worker-summary.json')
    assert original['status'] == 'passed' and original['passed'] is True
    assert original['task_statuses_changed'] is False and original['release_certification'] == 'not_run'
    assert returned['plan'] == original['plan'] and returned['plan'] in registry['plans']
    assert returned['study'] == registry['study'] == original['study']
    assert returned['driver_source'] == registry['driver_source'] == original['driver_source']
    assert len(returned['driver_source']['inputs']) == 11
    assert returned['registration_sha256'] == tuple_['outer']['registration_sha256']
    assert returned['build_receipt_sha256'] == original['task_build_receipt_sha256'] == task_build_hash
    assert original['files']['native-shard/source-before.json'] == original['files']['native-shard/source-after.json']
    assert returned['engine']['engine_head_observed'] == SOURCE
    assert returned['engine']['binary_digest'] == registry['binary_blake3']
    assert returned['engine']['eval_debug_assertions'] is False
    assert native['status'] == 'measurement_complete' and native['exit_code'] == native['worker_exit_code'] == 0
    assert native['stderr_complete'] is True and native['fixture_cleanup']['error'] is None
    assert native['worker_binary_digest_before'] == native['worker_binary_digest_after'] == registry['binary_blake3']
    assert native['worker_binary_unchanged'] is True
    hashes = load(d/'native-hash-subprocess-originals.json')
    assert len(hashes) == 2
    for h, key in zip(hashes, ('plan_digest','raw_digest')):
        assert h['returncode'] == 0 and '--hash-file' in h['argv']
        assert read(d/h['stdout']['file']).decode().strip() == native[key]
        assert not read(d/h['stderr']['file'])
    assert len(returned['measurements']) == 2
    assert [m['group'] for m in returned['measurements']] == [f'scale-{scale}/cold', f'scale-{scale}/{profile}']
    assert native['summary']['passed'] is True and native['summary']['sample_count'] == 2
    # Stream originals without allocating a new raw copy or executing any validation function.
    raw_path = nd/'raw.jsonl'
    event_counts, parities, builds, stage = collections.Counter(), [], [], []
    with raw_path.open() as raw:
        for lineno, line in enumerate(raw, 1):
            event = json.loads(line)
            event_counts[event.get('event')] += 1
            if event.get('event') in ('cold_parity','stage_finished'):
                selected.append({'slot': item['slot'], 'raw_path': str(raw_path), 'line': lineno, 'event': event})
                parity = event['parity']
                assert parity['equal'] is True and parity['status'] == 'equal' and parity['different_tables'] == []
                assert {t['table'] for t in parity['tables']} == tables and len(parity['tables']) == 15
                for t in parity['tables']:
                    assert type(t['equal']) is bool and t['equal']
                    assert type(t['full_rows']) is int and type(t['incremental_rows']) is int
                    assert t['full_rows'] == t['incremental_rows']
                    assert isinstance(t['full_digest'], str) and t['full_digest'] == t['incremental_digest']
                    assert type(t['different_row_count']) is int and t['different_row_count'] == 0
                    assert t['different_row_examples'] == []
                parities.append({'event':event['event'], 'line':lineno, 'oracle_mode':parity.get('oracle_mode'),
                                 'capacity_profile':parity.get('capacity_profile'), 'equal_tables':15,
                                 'canonical_bytes':parity.get('canonical_bytes'), 'scratch_peak_bytes':parity.get('scratch_peak_bytes'),
                                 'limits':parity.get('limits'), 'comparison':parity.get('comparison')})
                if event['event'] == 'stage_finished':
                    assert event['complete'] is True and event['full_complete'] is True and event['passed'] is True
                    stage.append({k:v for k,v in event.items() if k!='parity'})
            if event.get('event') == 'build_finished':
                report=event['report']
                builds.append({'line':lineno,'label':event['label'],'full':event['full'],
                               'resolution_freshness':report.get('resolution_freshness'),
                               'dirty_propagation':report.get('dirty_propagation'),
                               'dirty_plan':report.get('dirty_plan'),
                               'build_timing':report.get('build_timing'), 'phase_timing':report.get('phase_timing')})
    assert len(parities) == 2 and len(stage) == 1
    incrementals=[b for b in builds if not b['full']]
    assert len(incrementals) == stage[0]['incremental_builds']
    assert incrementals[-1]['resolution_freshness']['complete'] is True
    job = next(j for j in jobs if j['name']==f'measure ({profile}-{scale}, {profile}, {scale})')
    assert job['status']=='completed' and job['conclusion']=='success' and job['head_sha']==SOURCE
    critical_steps = [s for s in job['steps'] if s['number'] in (7,48,49,50,51)]
    assert len(critical_steps)==5 and all(s['conclusion']=='success' for s in critical_steps)
    artifact = item['artifact']
    assert artifact['workflow_run']['id']==RUN and artifact['workflow_run']['head_sha']==SOURCE
    assert artifact['digest']=='sha256:'+item['whole_zip']['sha256']
    cells.append({'slot': item['slot'], 'artifact':artifact, 'whole_zip_original_identity':item['whole_zip'],
                  'original_return':inputs[str(d/'original-validate-shard-return.json')], 'validator_execution':execution,
                  'producer':{'id':job['id'],'name':job['name'],'status':job['status'],'conclusion':job['conclusion'],
                              'started_at':job['started_at'],'completed_at':job['completed_at'],'critical_steps':critical_steps},
                  'plan':returned['plan'], 'input_digest':returned['input_digest'],
                  'environment':returned['environment'],'engine':returned['engine'],
                  'profile_environment':returned['profile_environment'],'measurement_environment':returned['measurement_environment'],
                  'native':native, 'measurements':returned['measurements'],
                  'raw_events':dict(event_counts), 'parity_observations':parities, 'stage_finished':stage,
                  'build_closure_observations':builds,
                  'first_incremental_actually_incomplete':incrementals[0]['resolution_freshness']['complete'] is False,
                  'resource_snapshot_count':len(returned['resource_snapshots'])})
assert len(cells)==12
report = {'schema':'independent-existing-first12-receipt-peer-v1','reviewer':'/root/pr_triage',
          'scope':'Non-author inspection of existing original receiver returns and producer output, not repeated validation or measurement.',
          'source':SOURCE,'tree':'39a053ae49b486764751a570d164e7cd41d7ff29','run_id':RUN,'attempt':1,
          'protocol':'p8-profile-task-descriptive-v1','registry_sha256':tuple_['outer']['registration_sha256'],
          'binary_blake3':registry['binary_blake3'],'binary_sha256':registry['binary_sha256'],
          'observer_inputs':registry['driver_source'],'task_build_receipt_sha256':task_build_hash,
          'accepted_cells':12,'expected_cells':45,'accepted_records':24,'expected_records':85,
          'roles':{'setup':12,'mutation':12,'fanout':0,'cold_curve_selected_setup':3,
                   'cold_curve_selected_scales':[1000,5000,10000]},
          'remaining':{'cells':33,'records':61,'setup':28,'mutation':28,'fanout':5},
          'original_validator_calls_by_receiver':12,'original_hash_utility_calls_by_receiver':24,
          'peer_validator_calls':0,'peer_crc_or_zip_reads':0,'peer_elf_or_product_calls':0,
          'original_parity_observations':24,'table_comparisons_observed':360,
          'first_incremental_incomplete_slots':[c['slot'] for c in cells if c['first_incremental_actually_incomplete']],
          'receiver_immutable_evidence':{'report':'ec7263820a97b6022e06dbb105f3b9592671d97b',
            'support':'6bee9e49b0468f70414f500d3faaaf2c7d0c9df3','selection':'b485b969c30b44d27f856ae423a697adf53a0cf1'},
          'build_immutable_evidence':{'report':'767527f7cccf372e6ca1dd866466d6bf66c86da3',
            'support':'79d96014710c2172b8bd17053d2a559144ec6003'},
          'local_stdout_custody_observation':load(OUT/'stdout-custody-observation.json'),
          'peer_attempt_history':'Attempt01 failed its stdout equality assertion because local api-1000 stdout was zero-length. Original independent return has exact recorded stdout length and SHA256; bytes recovered separately, originals untouched; no product or validator failure implied.',
          'limitations':[
            'Only these twelve observed whole original artifacts are accepted; the during-run artifact enumeration is not a final stable population.',
            '24 records comprise 12 setup plus 12 mutation. Only the 3 no_op setup records belong to the preselected cold curve; setup is not counted again.',
            'No 50k/100k, batch, or fanout cell is supplied by this batch. All 45 cells and original aggregate remain outstanding.',
            'Parity equality is the original typed full-projection comparator output accepted by the original validator; this peer does not reperform database comparison.',
            'N=1 descriptive, distinct fresh histories and observed host environments; no pooling into old 150/1350 cohorts or stable-tail/performance adoption/release claim.',
            'Observed dirty state lists Python __pycache__ files. Recorded complete source/build and peer receiver inputs are unchanged; do not claim a clean working tree.',
            'Native summary first_build_incomplete_samples uses an attribute populated for fanout summaries, not these mutation summaries. Actual mutation incomplete/resume evidence is retained directly from build_finished resolution_freshness.',
            'Capture checkpoints and wrapper success are not additional measurements; complete whole shard and original native verdict determine acceptance.',
            'CPU/cache/resource settings are observations. Effective seed cache 500000 does not itself establish a cache hit or causal performance attribution.',
            'No original TODO status or engineering merge status is changed.'],
          'cells':cells,'input_identities':list(inputs.values()),
          'started_at_utc':started,'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'result':'accepted_scoped_first12_original_receipts'}
save('selected-original-parity-and-stage-events.json',selected)
save('independent-first12-original-receipt-review.json',report)
print(json.dumps({'result':report['result'],'accepted_cells':12,'accepted_records':24,
                  'parity_observations':24,'table_comparisons_observed':360,
                  'first_incremental_incomplete_slots':report['first_incremental_incomplete_slots']}))
