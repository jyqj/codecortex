def stable_00268():
    return 268
