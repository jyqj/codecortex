import pathlib,json,hashlib,re,datetime
p=pathlib.Path('/dev/shm/root-round20/G4-main-CI-terminal')
log=p/'check-113877118380.decoded.log'
b=log.read_bytes()
ls=b.decode().splitlines()
def data(n):
    return json.loads(json.loads((p/n).read_text())['structuredContent']['content'])
c=data('actual-executed-checkout-official.json')
jobs=data('main-jobs-original-snapshot.json')
checks=data('all-checks-original-snapshot.json')
run=data('official-context-1.json')
assert c['tree']['sha']=='26baafefb05e113d9f4bab63716d8e72128208cf'
assert all(j['conclusion']=='success' for j in jobs['jobs'])
assert run['conclusion']=='success'
rows=[{'line':i+1,'text':l} for i,l in enumerate(ls) if 1007<=i+1<=1020]
tests=[re.sub(r'^.*Z test ','',r['text']).split(' ... ')[0] for r in rows if re.search(r'Z test \S+ \.\.\. ok$',r['text'])]
assert len(tests)==9
srcrow=next((i+1,l) for i,l in enumerate(ls) if '"source_version": "p8-completion-source-20261009-v15"' in l and '"status": "passed"' in l)
src=json.loads(srcrow[1][srcrow[1].index('{'):])
assert src['product_source']=='1930b8e37e24031c3779553e3fc5b95e8e946d50'
assert src['review_source']=='b4ad0852fb0f164f89ba194409e2a78578f5413f'
report={
 'schema_version':1,'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'reviewer':'/root','scope':'Original completed G4 CI and exact executed checkout; no new execution or full scale certification',
 'run':{'id':run['id'],'attempt':run['run_attempt'],'head':run['head_sha'],'status':run['status'],'conclusion':run['conclusion'],'completed_update':run['updated_at']},
 'main_jobs':[{'id':j['id'],'name':j['name'],'conclusion':j['conclusion'],'started_at':j['started_at'],'completed_at':j['completed_at']} for j in jobs['jobs']],
 'actual_checkout':{'sha':c['sha'],'tree':c['tree']['sha'],'parents':[v['sha'] for v in c['parents']],'whole_tree_equal_to_G4':True,'not_relabelled_as_literal_G4_checkout':True},
 'original_decoded_log':{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'lines':len(ls)},
 'DB_test_target':{'path':'crates/cc-db/tests/p2b_resolution_store.rs','passed':9,'failed':0,'ignored':0,'filtered':0,'names':tests,'original_line_range':[1007,1020],'detail':'Seven existing tests and two new exclusion tests actually ran. Successful-test output did not expose numeric Rust VM counters; no numeric counter is fabricated.'},
 'source_suite':{'passed':181,'result':'OK','reported_seconds':569.393,'original_line_range':[5975,5979]},
 'original_v15':{'stdout_line':srcrow[0],'stdout':src,'status':'passed','historical_v14_executed':src['executed_previous_proof']},
 'all_checks_snapshot':{'total':checks['total_count'],'success':sum(x['conclusion']=='success' for x in checks['check_runs']),'in_progress':sum(x['status']=='in_progress' for x in checks['check_runs']),'failed':sum(x['conclusion']=='failure' for x in checks['check_runs']),'note':'Point-in-time snapshot. Remaining original jobs and a possible later collector are not marked complete.'},
 'preserved_limits':[
  'Original G3 fmt exit1 and skipped steps remain in R4 evidence.',
  'Python scattered-case VM regression remains; no universal speedup or original 5h scale failure repair is claimed.',
  'Current G4 CI is not M7F/P6B/G6B execution.',
  'The fixed failed C3ff scale study retains its own source/run/attempt.',
  'Original TODO completions remain zero; 163 done and29 remaining.',
  'First local summary-parser assertion counted the result-summary as a test. Its actual exit1 is retained separately; exact test-row parsing corrects this helper error only.'
 ]
}
(p/'root-terminal-execution-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
files=[]
for x in sorted(p.iterdir()):
    if x.is_file() and x.name!='archive-selection.json':
        z=x.read_bytes()
        files.append({'source_path':str(x),'archive_path':x.name,'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(z)).encode()+b'\0'+z).hexdigest(),'mode':format(x.stat().st_mode&0o777,'04o')})
sel={'schema_version':1,'scope':'Complete original G4 decoded terminal log plus official metadata and bounded root review','file_count':len(files),'total_bytes':sum(x['bytes'] for x in files),'files':files}
(p/'archive-selection.json').write_text(json.dumps(sel,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'report':str(p/'root-terminal-execution-review.json'),'report_sha256':hashlib.sha256((p/'root-terminal-execution-review.json').read_bytes()).hexdigest(),'selection':str(p/'archive-selection.json'),'files':len(files),'bytes':sel['total_bytes'],'checks_snapshot':report['all_checks_snapshot']}))

