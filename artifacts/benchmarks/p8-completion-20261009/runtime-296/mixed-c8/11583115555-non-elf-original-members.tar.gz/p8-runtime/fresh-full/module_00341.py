def stable_00341():
    return 341
