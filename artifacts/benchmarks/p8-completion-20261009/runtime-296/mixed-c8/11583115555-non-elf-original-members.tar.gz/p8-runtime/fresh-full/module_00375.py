def stable_00375():
    return 375
