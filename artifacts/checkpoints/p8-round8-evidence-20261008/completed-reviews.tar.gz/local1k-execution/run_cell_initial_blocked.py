#!/usr/bin/env python3
"""Execute a preregistered original-G cell and call the unchanged validators."""
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
REGISTRATION_SHA = 'a2301a5b016cdba7c5ce85e55431d0a473a451bbec831f4d8fedffed7f45d874'
PUBLICATION = 'b94a93a9d92a237e0c55a23fd8e931c5dae659f0'
G = 'bb9a96d71622458c39a143055360cc97f0d11d78'

def sha(raw): return hashlib.sha256(raw).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path, data):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(data, stream, sort_keys=True, indent=2)
        stream.write('\n')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--index', type=int, required=True, choices=range(30))
    args = parser.parse_args()
    raw = (HERE / 'registration.json').read_bytes()
    assert sha(raw) == REGISTRATION_SHA
    registration = json.loads(raw)
    published = json.loads((HERE / 'publication.json').read_text())
    assert published['sha'] == PUBLICATION and published['branch_created'] is True
    assert published['registration_sha256'] == REGISTRATION_SHA
    root = Path(registration['compiled_source_root'])
    output = Path(registration['local_output_root'])
    cell = next(row for row in registration['primary_cells'] if row['scale'] == 1000 and row['shard_index'] == args.index)
    assert cell['primary_origin'] == 'local-G-1k-20261008'
    target = Path(cell['primary_local_directory'])
    assert target.parent == output and not target.exists()
    if args.index == 0:
        output.mkdir(exist_ok=False)
        (output / 'controls').mkdir(exist_ok=False)
    else:
        assert output.is_dir() and not output.is_symlink()
        for previous in range(args.index):
            prior = json.loads((output / 'controls' / f'{previous:02}' / 'execution.json').read_text())
            assert prior['status'] == 'passed_original_cell_and_validation'
    control = output / 'controls' / f'{args.index:02}'
    control.mkdir(exist_ok=False)
    with (output / 'cohort.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        run_one(registration, published, root, output, control, target, cell, args.index)

def run_one(registration, published, root, output, control, target, cell, index):
    owned_build = output / 'original-build'
    original_build = Path(registration['original_build']['directory'])
    record = {'schema_version': 1, 'study': registration['study'], 'registration_sha256': REGISTRATION_SHA,
              'registration_publication': PUBLICATION, 'source': G, 'scale': 1000, 'shard_index': index,
              'status': 'not_run', 'started_utc': now(), 'executor_sha256': sha(Path(__file__).read_bytes()),
              'control_directory': str(control), 'cell_directory': str(target), 'original_build': str(original_build),
              'owned_execution_build': str(owned_build), 'errors': [], 'cli_exit_code': None,
              'source_or_gate_modifications': False, 'todo_closed': 0}
    start = time.monotonic_ns()
    try:
        assert root.resolve(strict=True) == root and not root.is_symlink()
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == G
        assert subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=root) == b''
        assert sha((original_build / 'build.json').read_bytes()) == registration['original_build']['receipt_sha256']
        assert sha((original_build / 'p8-scale').read_bytes()) == registration['original_build']['binary_sha256']
        if index == 0:
            assert not owned_build.exists()
            owned_build.mkdir()
            copied = {}
            for path in sorted(original_build.iterdir()):
                assert path.is_file() and not path.is_symlink()
                target_file = owned_build / path.name
                shutil.copy2(path, target_file)
                source_raw = path.read_bytes()
                assert target_file.read_bytes() == source_raw
                copied[path.name] = {'bytes': len(source_raw), 'sha256': sha(source_raw), 'original_mode': path.stat().st_mode & 0o777}
            (owned_build / 'p8-scale').chmod(0o755)
            write(output / 'controls' / 'build-copy.json', {'files': copied, 'mode_only_change': 'owned p8-scale copy 0644 to0755',
                  'original_untouched': True, 'producer_receipt_bytes_rewritten': False, 'started_utc': now()})
        assert sha((owned_build / 'build.json').read_bytes()) == registration['original_build']['receipt_sha256']
        assert sha((owned_build / 'p8-scale').read_bytes()) == registration['original_build']['binary_sha256']
        assert (original_build / 'p8-scale').stat().st_mode & 0o777 == 0o644
        sys.path.insert(0, str(root / 'scripts'))
        spec = importlib.util.spec_from_file_location('original_G_cell_driver', root / 'scripts/p8_scale_matrix.py')
        driver = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(driver)
        plan = driver.registered_plan(1000, index, 30, 30, 12648430, 18000000, driver.CAPACITY_PROFILE)
        assert plan == cell['registered_plan']
        # No secrets, proxies or provider keys are forwarded. HOME is preserved
        # at its existing value; no system variable is repurposed.
        env = {key: os.environ[key] for key in ('PATH', 'HOME', 'LANG', 'LC_ALL', 'LC_CTYPE', 'TZ') if key in os.environ}
        env.update(RUSTFLAGS='', PYTHONDONTWRITEBYTECODE='1', CARGO_TERM_COLOR='never',
                   CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2', RUSTC_WRAPPER='', RUSTC_WORKSPACE_WRAPPER='')
        record['environment'] = env
        command = [sys.executable, '-B', str(root / 'scripts/p8_scale_matrix.py'), 'run',
                   '--root', str(root), '--build', str(owned_build), '--scale', '1000',
                   '--shard-index', str(index), '--shard-count', '30', '--repetitions', '30',
                   '--seed', '12648430', '--deadline-ms', '18000000', '--capacity-profile', 'scale_capacity_v1',
                   '--output', str(target)]
        record['argv'] = command
        record['status'] = 'running_original_driver'
        write(control / 'launch.json', record)
        with (control / 'cli.stdout').open('xb') as stdout, (control / 'cli.stderr').open('xb') as stderr:
            process = subprocess.Popen(command, cwd=root, env=env, stdout=stdout, stderr=stderr)
            write(control / 'process.json', {'pid': process.pid, 'started_utc': now(), 'argv': command,
                  'scope': 'Original Python driver owns its native300min plus Python302min supervision'})
            record['cli_pid'] = process.pid
            record['cli_exit_code'] = process.wait()
        if record['cli_exit_code'] != 0:
            raise RuntimeError('original driver returned ' + str(record['cli_exit_code']))
        # Native --hash-file here validates the exact retained executable; this
        # is separate from the original measured native worker above.
        built, binary = driver.validate_build(owned_build, root)
        validated = driver.validate_shard(target, built, binary, registration['original_build']['receipt_sha256'])
        assert validated['plan'] == plan
        write(control / 'original-validation.json', validated)
        assert subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=root) == b''
        assert sha((original_build / 'build.json').read_bytes()) == registration['original_build']['receipt_sha256']
        assert sha((original_build / 'p8-scale').read_bytes()) == registration['original_build']['binary_sha256']
        record['status'] = 'passed_original_cell_and_validation'
        record['measurements'] = len(validated['measurements'])
        record['measurement_groups'] = sorted(row['group'] for row in validated['measurements'])
        record['original_shard_receipt_sha256'] = sha((target / 'shard.json').read_bytes())
    except Exception as error:
        record['status'] = 'failed_or_not_run_preserved'
        record['errors'].append(type(error).__name__ + ': ' + str(error))
    finally:
        record['finished_utc'] = now()
        record['elapsed_ns'] = time.monotonic_ns() - start
        record['remaining_planned_local_cells'] = list(range(index + 1, 30))
        record['artifact_files'] = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
                                    for p in sorted(control.iterdir()) if p.is_file()}
        write(control / 'execution.json', record)
    print(json.dumps({k: record[k] for k in ('status', 'shard_index', 'cli_exit_code', 'errors', 'elapsed_ns')}, sort_keys=True), flush=True)
    if record['status'] != 'passed_original_cell_and_validation':
        raise SystemExit(1)

if __name__ == '__main__':
    main()
