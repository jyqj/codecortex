def branch_signal():
    return 1
