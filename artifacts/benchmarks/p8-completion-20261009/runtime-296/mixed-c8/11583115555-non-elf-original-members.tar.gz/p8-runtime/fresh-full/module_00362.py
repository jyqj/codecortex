def stable_00362():
    return 362
