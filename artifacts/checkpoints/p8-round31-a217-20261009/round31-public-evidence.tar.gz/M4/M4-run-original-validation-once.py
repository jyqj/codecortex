import datetime, hashlib, json, os, pathlib, subprocess, time
BASE=pathlib.Path('/workspace/scratch/a217aaae3bde');OUT=BASE/'p8-db-lock-observation-integration';VIEW=pathlib.Path('/dev/shm/a217aaae3bde/pr180-M4-832f-validated');TMP=pathlib.Path('/dev/shm/a217aaae3bde/pr180-M4-832f-tmp')
def sha(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,x):
 b=(json.dumps(x,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode();p=OUT/name;p.open('xb').write(b);return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
beforepath=OUT/'M4-independent-inputs-before.json';before=json.loads(beforepath.read_bytes());s=os.statvfs('/dev/shm');free=s.f_bavail*s.f_frsize;assert free>1024**3;assert not TMP.exists();TMP.mkdir()
assert all(sha((VIEW/p).read_bytes())==v['sha256'] for p,v in before.items())
env={**os.environ,'TMPDIR':str(TMP),'PYTHONDONTWRITEBYTECODE':'1'}
commands=[('v15',['python3','-B','scripts/verify_reviewed_source_v15.py','--source-version','p8-completion-source-20261009-v15']),('task-plan',['python3','scripts/code_index_plan.py'])]
receipts=[]
for label,cmd in commands:
 start=now();tic=time.monotonic();stdout=OUT/('M4-original-'+label+'.stdout');stderr=OUT/('M4-original-'+label+'.stderr');
 save('M4-original-'+label+'-started.json',{'command':cmd,'cwd':str(VIEW),'started_utc':start,'timeout_seconds':3600,'TMPDIR':str(TMP),'source':'832f79b8702c6cdfb567b7cf949508cd4589f286','remaining_todos':29})
 timed=False
 with stdout.open('xb') as a,stderr.open('xb') as b:
  try:p=subprocess.run(cmd,cwd=VIEW,env=env,stdin=subprocess.DEVNULL,stdout=a,stderr=b,timeout=3600);rc=p.returncode
  except subprocess.TimeoutExpired:timed=True;rc=None
 rec={'command':cmd,'cwd':str(VIEW),'started_utc':start,'finished_utc':now(),'elapsed_seconds':time.monotonic()-tic,'actual_exit_code':rc,'timeout':timed,'timeout_seconds':3600,'TMPDIR':str(TMP),'source':'832f79b8702c6cdfb567b7cf949508cd4589f286','stdout':{'path':str(stdout),'bytes':stdout.stat().st_size,'sha256':sha(stdout.read_bytes())},'stderr':{'path':str(stderr),'bytes':stderr.stat().st_size,'sha256':sha(stderr.read_bytes())},'measurement_or_compile':False}
 receipts.append(rec);save('M4-original-'+label+'-execution.json',rec);print(json.dumps({'label':label,'exit_code':rc,'timeout':timed,'elapsed_seconds':rec['elapsed_seconds']}),flush=True)
after={};changed=[]
for p,v in before.items():
 raw=(VIEW/p).read_bytes();actual={'bytes':len(raw),'sha256':sha(raw),'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'mode':format((VIEW/p).stat().st_mode&0o777 | 0o100000,'o')};after[p]=actual
 if actual!=v:changed.append(p)
afterref=save('M4-independent-inputs-after.json',after)
head=subprocess.check_output(['git','-C',str(VIEW),'rev-parse','HEAD']).decode().strip();tree=subprocess.check_output(['git','-C',str(VIEW),'rev-parse','HEAD^{tree}']).decode().strip()
assert head=='832f79b8702c6cdfb567b7cf949508cd4589f286' and tree=='c40de30474ae9de97fb938dade9a51e6b028b7c6'
assert not changed
out={'schema':'M4-original-validation-independent-execution-v1','reviewer':'/root/scale_closeout','head':head,'tree':tree,'source_view':str(VIEW),'ram_free_before_bytes':free,'TMPDIR':str(TMP),'temporary_entries_after':[str(p.relative_to(TMP)) for p in TMP.rglob('*')],'commands':receipts,'inputs_before':{'path':str(beforepath),'bytes':beforepath.stat().st_size,'sha256':sha(beforepath.read_bytes())},'inputs_after':afterref,'source_guard_history_and_input_bytes_modes_unchanged':True,'changed_paths':changed,'actual_source_guard_passed':receipts[0]['actual_exit_code']==0,'actual_task_plan_passed':receipts[1]['actual_exit_code']==0,'native_measurement_or_Rust_compile':False,'formal_completion':False,'remaining_todos':29}
print(json.dumps(save('M4-independent-original-validation-result.json',out)),flush=True)
