def stable_00438():
    return 438
