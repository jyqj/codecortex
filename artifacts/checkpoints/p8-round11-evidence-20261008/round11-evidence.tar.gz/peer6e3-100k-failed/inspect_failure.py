import collections,hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,'/workspace/scratch/2eaa00d0f93a/codecortex-scale-replay-G/scripts')
import p8_scale_matrix as matrix
home=Path(__file__).resolve().parent;out=home/'original'
receipt=matrix.read_json(out/'shard.json');before=matrix.read_json(out/'source-before.json');after=matrix.read_json(out/'source-after.json');report=matrix.read_json(out/'native/report.json')
assert receipt['files']==matrix.inventory(out,('shard.json',))
matrix.validate_snapshot(before)
assert before==after and before['source_commit']==receipt['source_commit']=='6e3eb4fd97edcf238774e74b88d397e059337bac'
assert before['manifest_sha256']==receipt['source_manifest_sha256']
plan=matrix.registered_plan(100000,0,30,30,12648430,18000000,'scale_capacity_v1')
assert plan==receipt['plan']==matrix.read_json(out/'registered-plan.json')==matrix.read_json(out/'native/plan.json')
assert receipt['status']=='failed' and receipt['exit_code']==3 and report['status']=='deadline_exceeded' and report['exit_code']==3
assert report['worker_binary_unchanged'] is True and report['worker_binary_digest_before']==report['worker_binary_digest_after']==receipt['binary_blake3']
events=[json.loads(line) for line in (out/'native/raw.jsonl').open()]
try:matrix.inspect_raw(out/'native/raw.jsonl',plan)
except ValueError as error:rejection=str(error)
else:raise AssertionError('Incomplete native shard was accepted by inspect_raw')
builds=[e for e in events if e['event']=='build_finished'];starts=[e for e in events if e['event']=='build_started'];finished={e['label'] for e in builds}
parities=[e for e in events if e['event'] in ('cold_parity','stage_finished')]
assert all(e['parity']['equal'] and len(e['parity']['tables'])==15 for e in parities)
def build_summary(items):
 return {'count':len(items),'outer_wall_us':sum(e['wall_us'] for e in items),'timing_observed_us':{k:(sum(e['report']['build_timing'][k] for e in items if e['report']['build_timing'][k] is not None) if any(e['report']['build_timing'][k] is not None for e in items) else None) for k in ('prepare_us','full_staging_us','commit_write_us')}}
r={'scope':'Failed original peer 100k single-repetition raw; exact deadline failure retained. Completed subphases do not certify the missing phases or N30. No product executed by this review.', 'source':receipt['source_commit'],'status':'deadline_exceeded_not_certified','artifact_id':11586146906,'zip_sha256':hashlib.sha256((home/'11586146906.zip').read_bytes()).hexdigest(),'raw_sha256':hashlib.sha256((out/'native/raw.jsonl').read_bytes()).hexdigest(),'receipt_sha256':hashlib.sha256((out/'shard.json').read_bytes()).hexdigest(),'source_before_after_equal':True,'inventory_exact':True,'plan_original_exact':True,'raw_rejection':rejection,'native_report':report,'event_counts':dict(collections.Counter(e['event'] for e in events)),'last_events':[{k:e[k] for k in ('event','label','start_us','end_us','wall_us','incremental_builds','complete','passed') if k in e} for e in events[-5:]],'unfinished_builds':[{k:e[k] for k in ('label','full','start_us') if k in e} for e in starts if e['label'] not in finished],'completed_parity_groups':[e.get('sample',e.get('label')) for e in parities],'completed_full_builds':build_summary([e for e in builds if e['full']]),'completed_incremental_builds':build_summary([e for e in builds if not e['full']]),'completed_oracle_wall_us':sum(e['parity_wall_us'] for e in parities),'environment':receipt['environment'],'TODO_closed':0}
(home/'inspection.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ('status','raw_rejection','event_counts','last_events','unfinished_builds','completed_parity_groups','completed_full_builds','completed_incremental_builds','completed_oracle_wall_us')}));print('inspection_sha256',hashlib.sha256((home/'inspection.json').read_bytes()).hexdigest())
