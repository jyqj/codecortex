Add IndexDb::publish_semantic_group for up to four requests sharing one DB receiver, expected incarnation and lifecycle. Validate duplicate task/token/doc and mixed incarnation before DB access; empty input returns Some([]). Run the original per-item CAS and each changed-item epoch bump under one IMMEDIATE transaction and lifecycle permit. Rejections keep their fenced retry outcome; SQL/ack/epoch errors roll back the whole group, and COMMIT errors return no partial outcomes and explicitly require state reconciliation.

This draft is stacked on the user-specified production head 513a98c9a94b15ec77153df41af26fa3c8c0b5e8 (source 11f5b76273a16b520e6b6e01ad32a0a6743173fb). Original single-item interfaces and CAS are byte-identical. Only semantic_publish.rs, its direct new tests, and specialty documentation/evidence changed.

Validation: initial red missing-API compile; 9 group tests, 11 existing publish tests and 9 existing lease tests pass with official direct Rust 1.95.0 and original Cargo.lock. Controlled temporary-DB triggers test publication/ack/epoch/deferred-constraint COMMIT failure; a private seam tests reader visibility and permit/close ordering. Changed-file rustfmt and final-range diff checks pass.

Not wired into production queue/wiring. Cache and HTTP remain external; no cache validation, warm optimization, crash/OS-permission/GCWAL experiments, real provider, runtime-wide tests or performance benchmark. Performance is unknown. Future queue integration belongs to a separate session. Details and red/green evidence: docs/design/2026-10-03-bounded-db-publication.md.

## 2026-10-07 整合后处理

此 PR 保持开放，等待独立范围审查。固定 head：`222da64761971a3b546458aa16e2c2c9ea46cea7`；已合入 main 的比较源：`886f90a542a6174a037c79eebbb4f74848fb1f53`（整合 PR #142）。

固定源无祖先关系；delta 路径 0 同字节、1 演进、7 缺失、0 删除仍缺失、0 删除后重现；unique 非 merge 提交 0/4 有 raw-delta 匹配，unique merge 0 个。独立未集成功能 IndexDb::publish_semantic_group：上限 4、共享事务/lifecycle；API 和 7 条新增 tests/docs/evidence 路径不在固定集成源。历史 CI 成功，但尚未接生产 queue、未证明性能收益；保留并单独迁移审查。

完整采用关系、缺口和处置快照记录在 `artifacts/checkpoints/pr-management-20261007/`，随当前推进批 PR #143 保存。后续按尚未采用的具体意图拆分迁移；旧 head 的 CI 与测量继续按原来源解释。
