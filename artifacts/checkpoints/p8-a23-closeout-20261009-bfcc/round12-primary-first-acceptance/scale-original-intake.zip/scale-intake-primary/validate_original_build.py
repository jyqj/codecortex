import hashlib,json,platform,shutil,sys,traceback
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=Path('/workspace/scratch/bfccb8494ba0/candidate-ready-signal-github')
RAW=BASE/'raw/37902429727/11603522248/attempt-03'
OUT=BASE/'build-validation-11603522248'
OUT.mkdir(exist_ok=False)
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'scripts'))
import p8_scale_matrix as original
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
 with (OUT/name).open('x') as f:json.dump(data,f,indent=2,ensure_ascii=False);f.write('\n')
def state(root):
 return {str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)} for p in sorted(root.rglob('*')) if p.is_file()}
before=state(RAW/'extracted')
zip_before=sha(RAW/'p8-scale-build-37902429727-original.zip')
write('original-before.json',{'zip_sha256':zip_before,'files':before})
copy=OUT/'build-replay-input';shutil.copytree(RAW/'extracted',copy)
assert all(sha(copy/name)==value['sha256'] for name,value in before.items())
# GitHub artifact materialization does not preserve executable permission.
# Original extracted bytes/modes stay immutable; only the replay copy is executable.
(copy/'p8-scale').chmod(0o555)
write('replay-permissions.json',{'path':'build-replay-input/p8-scale','mode_before':before['p8-scale']['mode'],'mode_after':'0o555','all_copied_bytes_equal_original':True,'original_changed':False})
receipt={'started_at':original.utc(),'function':'p8_scale_matrix.validate_build(directory, root=None)','argv_scope':'Original validate_build calls preserved Linux ELF --hash-file; no build, benchmark or native workload','source_root':str(ROOT),'source_G':'c8be5afaac568ffd40ef86d3795423c3b73c9f39','platform':platform.platform(),'libc':platform.libc_ver(),'python':sys.version,'complete_source_checkout_claim':False,'measurement_or_todo_credit':False}
code=1
try:
 record,binary=original.validate_build(copy)
 assert record['source_commit']==receipt['source_G']
 write('original-function-output.json',{'build_record':record,'returned_binary':str(binary)})
 receipt.update(status='original_validate_build_passed',binary_sha256=record['binary_sha256'],binary_blake3=record['binary_blake3'],binary_bytes=record['binary_bytes'])
 code=0
except Exception as error:
 receipt.update(status='failed_retained',error=repr(error));traceback.print_exc()
after=state(RAW/'extracted')
zip_after=sha(RAW/'p8-scale-build-37902429727-original.zip')
write('original-after.json',{'zip_sha256':zip_after,'files':after})
receipt.update(finished_at=original.utc(),original_zip_and_extracted_unchanged=before==after and zip_before==zip_after,actual_exit=code)
if not receipt['original_zip_and_extracted_unchanged']:
 code=1;receipt['actual_exit']=1;receipt['status']='original_invariance_failure'
write('receipt.json',receipt)
print(json.dumps(receipt))
sys.exit(code)
