# PR #144 P7 workflow independent audit

Run: https://github.com/jyqj/codecortex/actions/runs/37653732468
Job: `112903425598` (`engineering`). All 14 job steps completed successfully.

## Verified result

The reviewed job executed the exact original 58-function matrix: 40 integration functions across 11 targets, 13 query-encoding unit controls and 5 executor unit controls. Every expected identity appeared exactly once and passed. The 13 source files carrying those tests are byte-identical to the original executed source `5af7ac0089ee7522e78ff2ce2468f881c8cf70f2`. Executed commands keep the original test scheduler: no `--test-threads` override, no serial retry, no changed budget or assertion.

| Uploaded log | Passed | Failed | Ignored |
|---|---:|---:|---:|
| `coverage-config.log` | 14 | 0 | 0 |
| `deadline-cache.log` | 40 | 0 | 0 |
| `execution-deadline.log` | 5 | 0 | 0 |
| `gc-unlink.log` | 13 | 0 | 0 |
| `query-encoding.log` | 13 | 0 | 0 |
| `worker-strategy.log` | 10 | 0 | 1 |
| `input-lock.log` (Python) | 15 | 0 | 0 |
| **Total selected functions** | **110** | **0** | **1** |

The only ignored function is `actual_stdio_local_and_auto_have_equal_effective_budget_and_verified_source`: it requires an explicit current product path and SHA256 and is a mechanism smoke, not quality certification. The separate actual three-policy stdio target is not selected by this workflow. The unit-test logs also record 337 and 314 deliberately filtered-out functions outside the selected original 13 and 5.

## Source and execution identity

- PR head: `149aa04f24ddcfd02c3aa5626a59343e88d74866`.
- Actual checkout: PR merge `1d73d87a602c214ca227ed896fa9abc9ba83c5b3`, merging the PR into `6d02d77f018a5965a6f289b0b43558ed4b9f8322`.
- Actual full tree equals the PR head tree: `c19cf91f6455472806b0d08a5408016e262ab5ab`.
- `source-before.json` and `source-after.json` are byte-identical. Independent direct Git blob hashing matched every one of the 776 crate/Cargo inputs to the fixed PR head.
- Canonical input manifest SHA256: `baf2bd238706a0fd88b91c80357d1780415afd5b917ef56d4bf283f3932e8ee6`.
- Snapshot SHA256 (both): `765c22acc49fb125ea3c75be550f8cf77968d2b438cf2e9f39af050b21316a4a`.
- Observed compiler: `rustc 1.95.0 (59807616e 2026-04-14)`. Both target and build directory point at the same newly absent job-owned private directory; no cache restore. Build jobs 2, debug 0, incremental 0, `RUSTFLAGS=-D warnings`.

## Observations and limits

The previously failing public deadline recovery function passed. All six completed deadline/cancellation PUBLIC_JSON scenarios are preserved in the uploaded log and indexed separately. They keep real product stdio and loopback HTTP evidence, 150 ms semantic / 8,000 ms total deadline configuration, source-hit assertions and actual closure/recovery observations. These 58 cases mix unit, service and product-stdio layers; they are not all live-provider tests. Historical normal-schedule 57/1 and the separate serial diagnostic 2/0 remain unchanged. This new combined-source run does not prove the root cause of the old failure.

The real worker fixture retains 384 per-request rows: three seeds, two phases, concurrency 1 and 4, 32 samples per cell. Six lifecycle scenario receipts are also retained. These are observations within three test functions, not additional test counts. Old held-input publications are zero for all three seeds; resource attribution remains explicitly unknown and the full P7-015 performance gate remains unaccepted. P8 tests validate offline lock mechanisms. No live-provider quality/cost, dense-only counterfactual, full G7, P7-017 isolated gate, or release acceptance is inferred.

The workflow did not emit a new standalone product SHA256 receipt or archive binaries. The recorded source and fresh-job command evidence must not be upgraded into a nonexistent compiler-artifact hash. Python inputs are part of the fixed checked-out full tree but are outside the 776 crate/Cargo map.

## Evidence files

- `independent-review.json`: bounded conclusion and evidence relationships.
- `actual-rust-test-index.json`, `actual-python-test-index.json`: every observed identity, result, raw-log line and Rust target summary.
- `expected-original58.json`, `original58-source-comparison.json`: original expected identities and immutable old/new test-source hashes.
- `expected-source-head149.json`: independently reconstructed complete 776-input map.
- `executed-command-index.json`: actual source/test commands and shell records indexed into the complete job log.
- `public-deadline-observation-index.json`, `worker-observation-index.json`: compact raw-observation indexes.
- `jobs-initial.json`, `jobs-final.json`, `artifacts-api.json`: preserved connector API responses.
- `job-log-api.json` and `engineering-job.log`: the full available API response and its decoded job-log text.
- `pr144-p7-engineering-11496843573.zip`: original artifact archive, 217,882 bytes; SHA256 `7a1d199876e6a5c24593096d5406c2195e6c03ac645c05041ad15df5ba2ad2a1`, exactly matching the GitHub artifact API digest.
- `artifact-members.json`: all 26 members, their byte lengths and SHA256; total uncompressed 3,106,295 bytes. `artifact/` holds byte-identical convenience copies. The ZIP already preserves all these originals.
- `audit_ci.py`: reproduces the read-only comparisons from preserved responses, ZIP and the fixed local Git objects. It does not run products/tests or modify repository files.

Independent review SHA256: `6c3a2feff8c114bdcbb3d161c39eb15d57c3976926c029b26c5f537fa03f29bb`.

Review owner: `/root/pr_audit`. Execution owner: GitHub Actions job above. No tests/products/workflows were rerun, no repository files or task states changed, and no PR was merged by this audit.
