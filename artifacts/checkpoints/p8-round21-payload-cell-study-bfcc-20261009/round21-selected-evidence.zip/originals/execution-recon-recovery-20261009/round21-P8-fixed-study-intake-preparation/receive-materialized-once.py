#!/usr/bin/env python3
"""Receive one already materialized original ZIP. No network or workload execution.

Reuses unchanged v2 ZIP size/digest/path/CRC/extraction functions. Source-specific
binding replaces only the old transport host identity; no matrix algorithm runs.
"""
import argparse, datetime, hashlib, importlib.util, json, re, sys
from pathlib import Path
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
RECEIVER_SHA = '61f4ae48bc84dbc9f90862a80d06a8268ec4aa93f83c75582b716bc32f4c3369'

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def write(p,value):
 with p.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,ensure_ascii=False);f.write('\n')
def require(test,message):
 if not test:raise ValueError(message)

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 for key in ('binding','run-metadata','artifact-metadata','zip','output'):parser.add_argument('--'+key,required=True,type=Path)
 args=parser.parse_args();out=args.output;out.mkdir(parents=True,exist_ok=False)
 receipt={'started_UTC':utc(),'status':'pending','network':False,'measurement_executed':False,'automatic_retry':False,'semantic_status':'not_evaluated','new_primary_credit':0,'new_TODO_credit':0}
 code=1
 try:
  # Preserve caller's exact original metadata even if identity checks fail.
  for name,p in [('binding.used.json',args.binding),('run.original.json',args.run_metadata),('artifact.original.json',args.artifact_metadata)]:
   b=p.read_bytes()
   with (out/name).open('xb') as f:f.write(b)
  binding=json.loads(args.binding.read_text());run=json.loads(args.run_metadata.read_text());meta=json.loads(args.artifact_metadata.read_text())
  require(binding.get('repository')=='jyqj/codecortex','Unexpected repository')
  require(re.fullmatch('[0-9a-f]{40}',binding.get('source_G') or ''),'Actual public G must be bound; pending template cannot execute')
  require(type(binding.get('run_id')) is int and binding['run_id']>0 and binding.get('run_attempt')==1,'Actual original attempt1 must be bound')
  require(isinstance(binding.get('branch'),str) and binding['branch'] and binding.get('event')=='workflow_dispatch','Actual branch and root-owned dispatch must be bound')
  expected={'id':binding['run_id'],'head_sha':binding['source_G'],'run_attempt':1,'event':binding['event'],'head_branch':binding['branch'],'path':'.github/workflows/p8-scale.yml'}
  require(all(run.get(k)==v for k,v in expected.items()),'Run identity differs from the fixed source study')
  require(type(meta.get('id')) is int and meta['id']>0 and meta.get('expired') is False,'Artifact identity/expiry invalid')
  origin=meta.get('workflow_run',{})
  require(origin.get('id')==binding['run_id'] and origin.get('head_sha')==binding['source_G'],'Artifact belongs to another source/run')
  suffix=str(binding['run_id']);name=meta.get('name','')
  require(re.fullmatch(r'p8-scale-(?:build|matrix|(?:shard|capacity)-(?:1000|5000|10000|50000|100000)-(?:[0-9]|[12][0-9]))-'+suffix,name),'Artifact name outside the unchanged protocol')
  require(args.zip.is_file() and not args.zip.is_symlink(),'Materialized original ZIP is missing or is a symlink')
  receiver_path=HERE/'intake_once.v2.py';require(sha(receiver_path)==RECEIVER_SHA,'Original reviewed receiver bytes differ')
  spec=importlib.util.spec_from_file_location('retained_v2_zip_functions',receiver_path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
  original_before=sha(args.zip)
  digest,verified=m.verify_zip_identity(args.zip,meta,out)
  members=m.extract_original(args.zip,out/'extracted')
  require(sha(args.zip)==digest==original_before,'Original ZIP changed during intake')
  write(out/'members.json',{'members':members,'total_uncompressed_bytes':sum(x.get('bytes',0) for x in members)})
  receipt.update(status='transport_received' if verified else 'transport_received_digest_unavailable',artifact_id=meta['id'],name=name,run_id=run['id'],run_attempt=1,source_G=run['head_sha'],original_zip={'path':str(args.zip.resolve()),'bytes':args.zip.stat().st_size,'sha256':digest},official_digest_verified=verified,original_unchanged=True,member_count=len(members),zip_modes='Original external_attr and receiver extracted mode recorded separately; no claim of POSIX-copy identity.',durability='pending until immutable remote locator and exact ZIP/chunk hashes are recorded')
  code=0
 except Exception as error:
  receipt.update(status='failed_retained',error_type=type(error).__name__,error=str(error))
 finally:
  receipt.update(ended_UTC=utc(),process_exit_code=code)
  write(out/'transport-receipt.json',receipt)
  print(json.dumps({'output':str(out),'status':receipt['status'],'exit_code':code,'semantic_status':'not_evaluated'}))
 return code
if __name__=='__main__':raise SystemExit(main())
