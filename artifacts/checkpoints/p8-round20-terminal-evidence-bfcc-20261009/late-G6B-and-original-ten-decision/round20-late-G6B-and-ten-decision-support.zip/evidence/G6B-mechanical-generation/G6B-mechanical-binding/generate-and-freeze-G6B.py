#!/usr/bin/env python3
"""Mechanical metadata/byte validation and binding generation; no product execution."""
import copy
import datetime
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

B = Path(__file__).resolve().parent
P = "5534ebf38cc31efec1590d132ca57c30e2f77f1b"
R = "22975e49107b3832f438f85b17275110fc0afa02"
RT = "6538f382443f8975d252b4ff084ef32688f31ac1"
CANON = Path('/dev/shm/todo-audit-P6B-crash-ready-source-review/final-R6B')
INPUTS = CANON.parent / 'actual-P6B-complete-product-validation-inputs.json'
PREFIX = 'artifacts/checkpoints/p8-crash-ready-publication-bfcc-20261009/'

def sha(x): return hashlib.sha256(x).hexdigest()
def blob(x): return hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()
def read(p): return json.loads(Path(p).read_bytes())
def unwrap(n): return json.loads(read(B/n)['structuredContent']['content'])
def write(n,obj): (B/n).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def tree_oid(rows):
    body = b''
    for r in sorted(rows,key=lambda r:(r['path']+('/' if r['type']=='tree' else '')).encode()):
        mode = '40000' if r['mode']=='040000' else r['mode']
        body += mode.encode()+b' '+r['path'].encode()+b'\0'+bytes.fromhex(r['sha'])
    return hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).hexdigest()

def main():
    assert not (B/'generated').exists(), 'fresh generation only'
    meta = read(B/'R6B-official-commit.json')
    pmeta = read(B/'P6B-official-commit.json')
    assert meta['sha']==R and meta['tree']['sha']==RT and [p['sha'] for p in meta['parents']]==[P]
    assert pmeta['sha']==P and pmeta['tree']['sha']=='3d3d5a6ef11f3e632eb5ab8ce2502d7854aa2bd1'
    comp=unwrap('R6B-install-compare-tool-response.json')
    assert comp['base_commit']['sha']==P and comp['total_commits']==1 and comp['commits'][0]['sha']==R
    manifest=read(CANON/'upload-manifest.json')
    expected={x['repository_path']:x for x in manifest['files']}
    assert len(expected)==2 and len(comp['files'])==2
    for f in comp['files']:
        x=expected[f['filename']]; raw=Path(x['local_path']).read_bytes()
        assert f['status']=='added' and f['sha']==x['git_blob']==blob(raw)
        assert len(raw)==x['bytes'] and sha(raw)==x['sha256'] and x['mode']=='100644'
    roots=unwrap('R6B-root-tree-tool-response.json')
    scripts=unwrap('R6B-scripts-tree-tool-response.json')
    assert roots['truncated'] is False and scripts['truncated'] is False
    assert tree_oid(roots['tree'])==roots['sha']==RT
    assert tree_oid(scripts['tree'])==scripts['sha']=='f691d18ff1ab98f96c02b2d604dc23d57bb12e20'
    assert next(x['sha'] for x in roots['tree'] if x['path']=='scripts')==scripts['sha']
    write('actual-R6B-two-leaf-installation-review.json',{
      'source_P':P,'actual_R':R,'actual_R_tree':RT,'ordered_parents':[P],
      'verdict':'accepted_scoped_artifact_only_installation','exact_added_leaves':list(expected.values()),
      'official_compare_only_two_additions':True,'root_and_scripts_tree_objects_independently_rehashed':True,
      'runtime_or_source_admission_execution':False})
    argv=[sys.executable,str(B/'prepared/generate-g-bindings.py'),
      '--product-inputs',str(INPUTS),'--product-commit-file',str(B/'P6B-official-commit.json'),
      '--review-file',str(CANON/'independent-source-review.json'),
      '--review-commit-file',str(B/'R6B-official-commit.json'),
      '--review-path',PREFIX+'independent-source-review.json',
      '--review-git-blob','0d87f6a2e6ffd6c293e4521c7c778610023181c2',
      '--output-directory',str(B/'generated')]
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (B/'generation.stdout').open('wb') as out,(B/'generation.stderr').open('wb') as err:
        proc=subprocess.run(argv,stdout=out,stderr=err,check=False)
    write('generation-command-receipt.json',{'argv':argv,'started_utc':start,
        'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_exit_code':proc.returncode,
        'scope':'local mechanical generator only; no original v15 or Rust tests'})
    assert proc.returncode==0, 'generator failure retained; do not retry automatically'
    regpath='scripts/reviewed-source-registry-v15.json'
    guardpath='scripts/verify_reviewed_source_v15.py'
    oldreg=read(B/'prepared/seed-M7F-registry.json'); newreg=read(B/'generated'/regpath)
    fields=sorted(k for k in oldreg.keys()|newreg.keys() if oldreg.get(k)!=newreg.get(k))
    assert fields==['complete_inputs','delta','product_source','review_sha256','review_source']
    inputs=read(INPUTS)
    assert newreg['complete_inputs']==inputs['complete_inputs'] and newreg['delta']==inputs['paths']
    assert newreg['validation_inputs']==oldreg['validation_inputs']==inputs['validation_inputs']
    assert [len(newreg[k]) for k in ['complete_inputs','delta','validation_inputs']]==[1095,72,142]
    oldguard=(B/'prepared/seed-M7F-guard.py').read_text()
    newguard=(B/'generated'/guardpath).read_text()
    norm=lambda x:re.sub(r'^(PRODUCT|REVIEW|REVIEW_PATH|REGISTRY_SHA256) = .*$',r'\1 = <PIN>',x,flags=re.M)
    assert norm(oldguard)==norm(newguard)
    changed=[a.split(' = ')[0] for a,b in zip(oldguard.splitlines(),newguard.splitlines()) if a!=b]
    assert set(changed)=={'PRODUCT','REVIEW','REVIEW_PATH','REGISTRY_SHA256'} and len(changed)==4
    combined=''
    for path,old in [(regpath,(B/'prepared/seed-M7F-registry.json').read_text()),(guardpath,oldguard)]:
        new=(B/'generated'/path).read_text()
        combined+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='M7F/'+path,tofile='G6B-candidate/'+path))
    (B/'two-binding.diff').write_text(combined)
    items=[]; srows=copy.deepcopy(scripts['tree'])
    for path,seed in [(regpath,'seed-M7F-registry.json'),(guardpath,'seed-M7F-guard.py')]:
        raw=(B/'generated'/path).read_bytes(); old=(B/'prepared'/seed).read_bytes()
        row=next(x for x in srows if x['path']==path.split('/',1)[1])
        assert row['mode']=='100644' and row['sha']==blob(old)
        item={'repository_path':path,'local_path':str(B/'generated'/path),'mode':'100644',
              'type':'blob','bytes':len(raw),'sha256':sha(raw),'git_blob':blob(raw),
              'before_git_blob':row['sha'],'before_sha256':sha(old)}
        items.append(item);row['sha']=item['git_blob'];row['size']=len(raw)
    new_scripts=tree_oid(srows);rrows=copy.deepcopy(roots['tree'])
    next(x for x in rrows if x['path']=='scripts')['sha']=new_scripts
    newtree=tree_oid(rrows)
    request={'base_tree':RT,'tree':[{'path':x['repository_path'],'mode':x['mode'],'type':'blob','sha':x['git_blob']} for x in items]}
    write('G6B-two-leaf-create-tree-request.json',request)
    result={'actual_G':None,'expected_G_tree':newtree,'expected_scripts_tree':new_scripts,
       'actual_P':P,'actual_R':R,'actual_R_tree':RT,'suggested_G_ordered_parents':[R],
       'files':items,'file_count':2,'counts':{'product':1095,'delta':72,'validation':142},
       'allowlisted_actual_registry_fields':fields,'allowlisted_guard_pin_lines':changed,
       'new_BASE_delta_only':'crates/cc-semantic/tests/p7_crash_preparation.rs',
       'all_prior_71_BASE_deltas_preserved':True,'all_142_validation_bytes_preserved':True,
       'M7F_preselect_formatter_fix_preserved':True,'BASE_FROZEN_historical_CI_and_guard_algorithm_unchanged':True,
       'current_G_CLI_tests_runtime_performance_TODO_credit':False,
       'source_scope':'P6B source-only independent R; generated bindings are not an execution result'}
    write('allowlisted-delta-and-installation-manifest.json',result)
    print(json.dumps(result,sort_keys=True))

if __name__=='__main__':main()
