from pathlib import Path
import ast, datetime, hashlib, json, subprocess, yaml

ROOT = Path('/workspace/scratch/2eaa00d0f93a/p8-staging-engineering-publication-root')
REPO = Path('/workspace/scratch/2eaa00d0f93a/p8-staging-cached-draft-G4')
OUT = Path(__file__).parent
BASE = '260f596582f2d82b8d7c707b61a6b8b6a43b069f'
REVIEWED = '41236c3eb6e43d8c6f0fc489d5192cf14483069c'
PUBLISHED = '8e542e644b06a83fc82d18d9896cf82f5b2d796e'

def git(*args, data=None):
    return subprocess.check_output(['git', '-C', str(REPO), *args], input=data)

def sha(body):
    return hashlib.sha256(body).hexdigest()

def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()

observed = json.loads((OUT / 'public-api-observations.json').read_bytes())
assert observed['commit']['sha'] == PUBLISHED
assert [p['sha'] for p in observed['commit']['parents']] == [BASE]
assert observed['commit']['tree']['sha'] == observed['new_root']['sha'] == '28a35d538f11613e98e645f37d8bbd4946d754ac'
assert not observed['new_root']['truncated'] and not observed['base_root']['truncated']
def tree_rows(value):
    return {p['path']: {k:p[k] for k in ['mode','type','sha']} for p in value['tree']}
before, after = tree_rows(observed['base_root']), tree_rows(observed['new_root'])
assert before.keys() == after.keys() and len(after) == 13
assert {p for p in before if before[p] != after[p]} == {'crates', '.github', 'artifacts'}
assert after['crates']['sha'] == git('rev-parse', REVIEWED+':crates').decode().strip() == '8db43a9d0a3ddaaff8740f1b55986f871b8c5112'
for p in ['Cargo.toml','Cargo.lock','scripts']:
    assert after[p]['sha'] == git('rev-parse', REVIEWED+':'+p).decode().strip()

plan = json.loads((ROOT/'upload-plan.json').read_bytes())
comparison = observed['compare']
assert comparison['base'] == BASE and comparison['total_commits'] == comparison['ahead_by'] == 1 and comparison['behind_by'] == 0
assert len(comparison['files']) == len(plan) == 18
remote = {r['path']:r for r in comparison['files']}
assert set(remote) == {r['path'] for r in plan}
records = {}
for row in plan:
    p = Path(row['local'])
    assert p.is_file() and not p.is_symlink()
    body = p.read_bytes()
    blob = hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()
    assert blob == row['git_blob'] == remote[row['path']]['sha']
    assert len(body) == row['bytes'] and sha(body) == row['sha256'] and row['mode'] == '100644'
    if row['path'].startswith('crates/'):
        assert git('show', REVIEWED+':'+row['path']) == body
        assert remote[row['path']]['status'] == 'modified'
    else:
        assert remote[row['path']]['status'] == 'added'
    records[row['path']] = {k:row[k] for k in ['bytes','sha256','git_blob','mode']}
assert sum(p.startswith('crates/') for p in records) == 4
assert sum(p.startswith('artifacts/') for p in records) == 13
assert [p for p in records if p.startswith('.github/')] == ['.github/workflows/p8-staging-cache-engineering.yml']

# Root tree identity makes the complete remote Cargo/crates inventory identical
# to REVIEWED. Hash all actual immutable member bodies independently here.
raw = git('ls-tree','-r','-z',REVIEWED,'--','crates','Cargo.lock','Cargo.toml')
entries = {}
for item in raw.split(b'\0'):
    if not item: continue
    info,path = item.split(b'\t',1)
    mode,kind,oid = info.decode().split()
    assert kind == 'blob' and mode in ['100644','100755']
    entries[path.decode()] = {'mode':mode,'blob':oid}
assert len(entries) == 1087
objects = list(dict.fromkeys(v['blob'] for v in entries.values()))
batch = git('cat-file','--batch',data=('\n'.join(objects)+'\n').encode())
cursor = 0
hashes = {}
for expected in objects:
    end = batch.index(b'\n',cursor)
    oid,kind,size = batch[cursor:end].decode().split()
    assert oid == expected and kind == 'blob'
    size = int(size); cursor = end+1
    body = batch[cursor:cursor+size]; cursor += size
    assert hashlib.sha1(b'blob '+str(size).encode()+b'\0'+body).hexdigest() == oid
    assert batch[cursor:cursor+1] == b'\n'; cursor += 1
    hashes[oid] = sha(body)
assert cursor == len(batch)
inputs = {p:hashes[r['blob']] for p,r in sorted(entries.items())}
snapshot = json.loads((ROOT/'reviewed-production-source-snapshot.json').read_bytes())
assert snapshot['source_commit'] == REVIEWED and snapshot['inputs'] == inputs
assert snapshot['input_count'] == 1087
assert sha(json_bytes(inputs)) == snapshot['manifest_sha256'] == '7a561d39191708023052b22ef5d626bf26ecf4ca6042eb39dc2f50a82ceb34bf'

admission = json.loads((ROOT/'admission.json').read_bytes())
engineering = json.loads((ROOT/'engineering-plan.json').read_bytes())
assert admission['TODO_newly_completed'] == engineering['TODO_closed'] == 0
assert admission['TODO_remaining'] == engineering['TODO_remaining'] == 29
assert admission['new_primary_study'] is False and admission['replace_old_sample'] is False and admission['retry'] is False
for p,digest in admission['reviews'].items():
    assert sha((ROOT/p).read_bytes()) == digest
assert admission['reviews']['source-independent-audit.json'] == '17efa139a5ad0d0814d24c952bd84454029199408a7cc4c1f3f4ba0d733b495d'
assert admission['reviews']['workflow-independent-review.json'] == '176c255f5ef210f4592dee781713a7841d4bd89698abdb5aaee529e2a43439c6'
assert admission['production_manifest_sha256'] == snapshot['manifest_sha256']

workflow_body = (ROOT/'p8-staging-cache-engineering.yml').read_bytes()
assert sha(workflow_body) == admission['workflow_sha256'] == engineering['workflow_sha256'] == 'b68a2601e5c6577c54dce435eb2baba05b8588d09dcd35e5af574746be96735a'
w = yaml.load(workflow_body, Loader=yaml.BaseLoader)
assert w['on'] == {'push':{'branches':['task/p8-staging-cache-engineering-20261008']}}
assert w['permissions'] == {'contents':'read'}
assert set(w['jobs']) == {'controls_and_build','diagnostic_small','diagnostic_100k'}
for job in w['jobs'].values():
    assert job['if'] == 'github.run_attempt == 1'
    assert 'continue-on-error' not in job
    for step in job['steps']:
        assert 'continue-on-error' not in step
        if step.get('uses','').startswith('actions/checkout@'):
            assert step['with']['ref'] == '${{ github.sha }}'
assert w['jobs']['diagnostic_small']['needs'] == 'controls_and_build'
assert w['jobs']['diagnostic_small']['strategy']['matrix']['scale'] == ['1000','10000']
assert w['jobs']['diagnostic_100k']['needs'] == ['controls_and_build','diagnostic_small']
assert w['jobs']['controls_and_build']['timeout-minutes'] == '45'
for name in ['diagnostic_small','diagnostic_100k']:
    assert w['jobs'][name]['timeout-minutes'] == '350'
    run = next(s['run'] for s in w['jobs'][name]['steps'] if s.get('name')=='Execute the original single repetition with every phase and parity check')
    for argument in ['--shard-index 0','--shard-count 30','--repetitions 30','--seed 12648430','--deadline-ms 18000000','--capacity-profile scale_capacity_v1']:
        assert argument in run
run = next(s['run'] for s in w['jobs']['controls_and_build']['steps'] if s.get('name')=='Capture fixed-source controls and preserve every attempted command')
embedded = run.split("python3 - <<'PY'\n",1)[1].rsplit('\nPY',1)[0]
commands = next(ast.literal_eval(n.value) for n in ast.parse(embedded).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='commands' for t in n.targets))
assert commands == engineering['commands'] and len(commands) == 13
for key,value in {'raw_budget_bytes':536870912,'canonical_stream_budget_bytes':17179869184,'oracle_scratch_budget_bytes':8589934592,'native_deadline_ms':18000000,'original_wrapper_minutes':302,'dirty_budget':200,'resume_iterations':1024,'repetitions':30,'shard_count':30,'seed':12648430}.items():
    assert engineering[key] == value
readme = (ROOT/'README.md').read_text()
assert 'There is no performance result at publication time.' in readme
assert '29 remain' in readme and 'No new original TODO is complete' in readme
assert 'not a primary N=30 study' in readme

report = {
    'schema':'p8-staging-actual-publication-bridge-v1',
    'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer':'pr_audit; non-author of publication/workflow',
    'status':'accepted_scoped_actual_source_bridge_for_auxiliary_engineering_trigger',
    'actual_commit':PUBLISHED,'actual_tree':observed['new_root']['sha'],'sole_parent':BASE,
    'reviewed_local_source':REVIEWED,'changed_paths':records,
    'root_changes':['.github','artifacts','crates'],
    'complete_production':{'input_count':1087,'manifest_sha256':snapshot['manifest_sha256'],'all_immutable_Git_bodies_independently_rehashed':True,'remote_crates_tree_equals_reviewed':'8db43a9d0a3ddaaff8740f1b55986f871b8c5112','Cargo_and_scripts_root_entries_unchanged_from_G4':True},
    'workflow':{'sha256':sha(workflow_body),'sole_trigger':'push task/p8-staging-cache-engineering-20261008','attempt':1,'read_only_permissions':True,'commands':13,'expected_nonignored_tests':41,'actual_tests':'not_run; receipt intake must verify nonempty exact test population','diagnostics':'index0 auxiliary 1k+10k then100k only if both succeed; no formal150','original_budgets_and_driver_preserved':True},
    'old_evidence':'G4/D0/localcandidate retain own identities; no substitution, retry or automatic inheritance',
    'source_approval_scope':'New auxiliary source has not run full v15/PR/release approval; existing G4 pins/guard untouched',
    'remote_branch_created_by_reviewer':False,'local_Cargo_product_or_benchmark':False,
    'TODO_closed':0,'TODO_remaining':29,
}
(OUT/'audit.json').write_bytes(json_bytes(report))
print(json.dumps({'status':report['status'],'audit_sha256':sha((OUT/'audit.json').read_bytes()),'inputs':len(inputs),'paths':len(records)}))
