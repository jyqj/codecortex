def stable_00277():
    return 277
