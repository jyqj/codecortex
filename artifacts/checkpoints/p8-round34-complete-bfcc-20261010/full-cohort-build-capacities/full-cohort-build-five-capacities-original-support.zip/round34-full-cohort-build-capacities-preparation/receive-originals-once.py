"""Receive this cohort's build and five capacities once; no workload execution.

The unchanged original validate_build executes its preserved ELF --hash-file.
Two shard ZIPs are deliberately excluded; they have a separate intake owner.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import time
import zipfile

ROOT = Path('/workspace/scratch/bfccb8494ba0')
SOURCE = ROOT / 'round32-capture-context-admission/guard-view'
REGISTRATION = ROOT / 'round34-full-cohort-first-original-intake-registration.json'
ORIGINALS = ROOT / 'round34-full-cohort-original-artifacts'
OLD_BINDING = ROOT / 'round32-100k-diagnostic-intake-bound-9cc6-run38012409915/binding.json'
CALLER = ROOT / 'round32-100k-diagnostic-intake-preparation/call-original-validator-once.py'
OUT = ROOT / 'round34-full-cohort-build-capacities-intake/attempt01'
G = '9cc6bf49f6dd81e4069a8004eed49addba0ab79b'
RUN = 38013753078
SCALES = (1000, 5000, 10000, 50000, 100000)

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def identity(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
            'posix_mode': oct(stat.S_IMODE(path.stat().st_mode))}

def save(name, obj):
    with (OUT / name).open('x') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
        f.write('\n')

def command(label, argv):
    start, tick = utc(), time.monotonic()
    with (OUT / (label + '.stdout')).open('xb') as stdout, (OUT / (label + '.stderr')).open('xb') as stderr:
        p = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr, check=False,
                           env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'GIT_NO_LAZY_FETCH': '1'})
    receipt = {'argv': argv, 'cwd': str(ROOT), 'started_utc': start, 'finished_utc': utc(),
               'duration_seconds': time.monotonic() - tick, 'exit_code': p.returncode,
               'stdout': identity(OUT / (label + '.stdout')), 'stderr': identity(OUT / (label + '.stderr'))}
    save(label + '.execution.json', receipt)
    return p.returncode

def snapshot(binding):
    paths = {SOURCE / p for p in binding['product_inputs']}
    paths |= {SOURCE / p for p in binding['driver_inputs']}
    paths |= {SOURCE / p for p in binding['observer_inputs']}
    paths |= {p for p in (OUT / 'extracted').rglob('*') if p.is_file()}
    paths |= {CALLER, OUT / 'binding.json', Path(__file__).resolve()}
    rows = {}
    for p in sorted(paths):
        assert p.is_file() and not p.is_symlink(), str(p)
        row = identity(p)
        row.pop('path')
        rows[str(p)] = row
    return {'source_HEAD': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip(),
            'count': len(rows), 'rows': rows}

OUT.mkdir(parents=True, exist_ok=False)
registration = json.loads(REGISTRATION.read_text())
assert registration['source_commit'] == G and registration['run_id'] == RUN
assert registration['attempt'] == 1 and registration['event'] == 'pull_request'
old = json.loads(OLD_BINDING.read_text())
assert old['G'] == G and len(old['product_inputs']) == 1096
observers = ('.github/workflows/p8-scale-wide-dirty.yml', 'scripts/p8_runner_capacity.py')
observer_inputs = {}
for relative in observers:
    p = SOURCE / relative
    committed = subprocess.check_output(['git', 'show', G + ':' + relative], cwd=SOURCE)
    assert committed == p.read_bytes()
    observer_inputs[relative] = identity(p)
binding = {k: old[k] for k in ('G', 'G_tree', 'P', 'R', 'canonical_reference', 'product_inputs', 'driver_inputs', 'repository')}
binding.update(schema='p8-full-wide-cohort-build-capacity-binding-v1', run_id=RUN, run_attempt=1,
               event='pull_request', workflow_path=observers[0], observer_inputs=observer_inputs,
               workload_profile='scale_wide_dirty_v1', physical_oracle_profile='scale_capacity_v1',
               cohort={'scales': list(SCALES), 'repetitions': 30, 'registered_shards': 150},
               original_registration=identity(REGISTRATION),
               identity_boundary='Source-map identity reused because exact G is identical. No diagnostic build/result/plan is reused.')
save('binding.json', binding)
assert sha(CALLER) == 'adca44a11784871edfc526888f5420f14bc7fd1a653a0f1183ebf7983e6cd16e'
for relative, expected in {**binding['product_inputs'], **binding['driver_inputs']}.items():
    assert sha(SOURCE / relative) == expected, relative

requested = {'p8-scale-wide-dirty-build-' + str(RUN): ('build', None)}
requested.update({f'p8-scale-wide-dirty-capacity-{scale}-0-{RUN}': ('capacity', scale) for scale in SCALES})
records = []
for row in registration['exact_received_files']:
    artifact = row['artifact']
    if artifact['name'] not in requested:
        continue
    kind, scale = requested[artifact['name']]
    assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == G
    path = ORIGINALS / row['file_name']
    assert path.name == artifact['name'] + '-original.zip'
    assert path.stat().st_size == artifact['size_in_bytes']
    assert 'sha256:' + sha(path) == artifact['digest']
    dest = OUT / 'extracted' / ('build' if kind == 'build' else 'capacity-' + str(scale))
    dest.mkdir(parents=True)
    members = {}
    with zipfile.ZipFile(path) as z:
        seen = set()
        for item in z.infolist():
            name = item.filename
            pure = PurePosixPath(name)
            assert name and not pure.is_absolute() and '..' not in pure.parts and '\\' not in name
            assert name not in seen and not item.flag_bits & 1
            seen.add(name)
            mode = item.external_attr >> 16
            assert not stat.S_ISLNK(mode)
            target = dest / name
            if item.is_dir():
                assert stat.S_IFMT(mode) in (0, stat.S_IFDIR)
                target.mkdir(parents=True, exist_ok=True)
                continue
            assert stat.S_IFMT(mode) in (0, stat.S_IFREG)
            raw = z.read(item)  # This single complete read validates the member CRC.
            assert len(raw) == item.file_size
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as f:
                f.write(raw)
            os.chmod(target, stat.S_IMODE(mode) or 0o644)
            members[name] = {**identity(target), 'zip_crc32': f'{item.CRC:08x}',
                             'zip_posix_mode': oct(stat.S_IMODE(mode)), 'complete_member_read_crc_passed': True}
    records.append({'kind': kind, 'scale': scale, 'artifact': artifact, 'zip': identity(path),
                    'extracted_directory': str(dest), 'members': members})
assert len(records) == 6 and len({x['artifact']['id'] for x in records}) == 6
assert {r['scale'] for r in records if r['kind'] == 'capacity'} == set(SCALES)
save('original-six-zip-custody.json', {'recorded_utc': utc(), 'records': records,
     'shard_zip_files_not_opened': True, 'transport_downloads_here': 0, 'original_registration': identity(REGISTRATION)})
before = snapshot(binding)
assert before['source_HEAD'] == G
save('source-evidence-before.json', before)
code = command('original-validate-build', ['python3', '-B', str(CALLER), 'build', '--binding', str(OUT / 'binding.json'),
    '--source-root', str(SOURCE), '--build-directory', str(OUT / 'extracted/build'),
    '--output', str(OUT / 'original-validate-build-result.json')])
after = snapshot(binding)
save('source-evidence-after.json', after)
assert before == after, 'source, caller, binding or extracted originals changed'
save('build-terminal.json', {'recorded_utc': utc(), 'original_validate_build_calls': 1,
     'original_validate_build_exit': code, 'source_and_evidence_before_after_equal': True,
     'snapshot_count': before['count'], 'ELF_execution': 'Original --hash-file only; no workload or compilation.',
     'original_validate_shard_calls': 0, 'original_inspect_raw_calls': 0,
     'build_directory': str(OUT / 'extracted/build'), 'run_id': RUN, 'source': G,
     'capacity_semantic_review': 'pending separate read-only receipt review',
     'accepted_shards_by_this_receiver': 0, 'accepted_samples_by_this_receiver': 0, 'TODO_credit': 0})
print(json.dumps({'build_exit': code, 'output': str(OUT), 'source_unchanged': True}))
sys.exit(code)
