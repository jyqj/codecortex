def stable_00005():
    return 5
