from pathlib import Path
import json,hashlib,statistics,re
R=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_bytes())
def api(name):return json.loads(load(R/name)['structuredContent']['content'])
def meta(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git_blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
p190=api('PR190-original.json');p191=api('PR191-original.json')
f190=api('PR190-files-original.json');f191=api('PR191-files-original.json')
assert [f['filename']for f in f190 if f['filename'].startswith('crates/')]==['crates/cc-eval/src/benchmark/oracle.rs']
assert [f['filename']for f in f191 if f['filename'].startswith('crates/')]==['crates/cc-db/src/index_db_write_batch.rs','crates/cc-db/src/rebuild_chunk_statement_tests.rs']
run=api('PR190-cost-run-original.json');assert run['head_sha']=='eded24951c3e99693410ce959a627ab575f66bec' and run['run_attempt']==1 and run['conclusion']=='success'
rows=load(R/'PR190-original-cost-100-rows.json');assert len(rows)==100
assert len({(x['case'],x['round'])for x in rows})==100
cases=['blob','empty_text','multiple_text','null','short_fields'];stats={}
for c in cases:
 a=[x for x in rows if x['case']==c];assert len(a)==20 and {x['round']for x in a}==set(range(20))
 assert all(x['rows']==256 and x['borrowed_digest']==x['original_digest'] and x['timing_threshold'] is None for x in a)
 stats[c]=dict(median_borrowed_over_original=statistics.median(int(x['borrowed_ns'])/int(x['original_ns'])for x in a),borrowed_faster_pairs=sum(int(x['borrowed_ns'])<int(x['original_ns'])for x in a),pairs=20)
stats['multiple_text']['order_strata']={k:statistics.median(int(x['borrowed_ns'])/int(x['original_ns'])for x in rows if x['case']=='multiple_text' and x['first']==k) for k in ['original','borrowed']}
checks={}
for n in (190,191):
 c=api(f'PR{n}-checks-original.json')['check_runs'];checks[str(n)]=[dict(name=x['name'],id=x['id'],status=x['status'],conclusion=x['conclusion'],url=x['details_url'])for x in c]
jobs=load(R/'PR191-main-CI-jobs.json')['structuredContent']['jobs'];j=next(x for x in jobs if x['id']==113923069943)
assert j['conclusion']=='failure' and next(x for x in j['steps']if x['number']==5)['conclusion']=='failure'
assert all(x['conclusion']=='skipped'for x in j['steps']if 6<=x['number']<=32)
log=(R/'PR191-check113923069943-original-decoded.log').read_text();assert 'Process completed with exit code 1' in log
diffs=re.findall(r'Diff in /home/runner/work/codecortex/codecortex/([^:\n]+):(\d+):',log);assert len(diffs)==4
out=dict(schema_version=1,reviewer='/root/pr_triage',finalized_UTC='2026-10-09T16:52:37Z',scope='Single official read plus necessary terminal logs; no execution, mutation or whole-domain adoption review.',
 pr190=dict(head=p190['head']['sha'],base=p190['base']['sha'],state=p190['state'],draft=p190['draft'],
  product_files=[dict(path=f['filename'],blob=f['sha'])for f in f190 if f['filename'].startswith('crates/')],
  current_checks=checks['190'],normal_Rust_tests_on_current_head='not established; main check is queued in this snapshot, engineering label success is not proof of ordinary Rust test execution',
  original_finite_Rust_execution=dict(source=run['head_sha'],run=run['id'],attempt=1,job=113909856107,conclusion='success',log=meta(R/'PR190-observe113909856107-original-decoded.log'),
   observed_libtest='borrowed_serialization_release_cost_probe: 1 passed / 0 failed / 0 ignored / 73 filtered, release compilation completed; this explicit ignored-probe execution does not run four normal controls',paired_stats=stats,
   original_bytes_scope='All 100 original timing rows, digest equality and complete terminal log independently read; full original artifact ZIP and Cargo producer seals were not downloaded or independently accepted in this limited task.'),
  P8_API_compatibility=dict(verdict='statically compatible interface; combined runtime unexecuted',
   P8='44e6248106335b5f0625e53de38f76d26aeeadcf',P8_streaming_blob='b5eff557bed7d775490bc02c48a4678e0dd0f865',oracle_blob='1b2cc162d888706a46ca9a3b4e2dd9275b86352b',
   findings=['P8 streaming calls RowProjection::new(&cols) and serialize_row(&Row)->Result<String>, both signatures retained. Borrowed cells exist only inside serialize_row before it returns an owned String; no borrowed row escapes to pending rows.',
    'P8 checks raw size before serialize_row and serialized byte length after it. Borrowing keeps SELECT-order get_ref/UTF8 checks, exact scalar conversion and Blob digest; all cells are visited before duplicate-key output selection.',
    'P8 raw-cell witness requires identical column layouts and exact typed SQL cell values, including Real bits. Deterministic borrowed serialization of equal cells still satisfies this sufficient equality proof; original fallback and B full validation remain applicable.',
    'The one oracle.rs product leaf is disjoint from six P8 modified paths; new workflow adds a 143rd validation input relative to P8 142. An actual combined P/R/G and its own normal controls would be required before integration, without transferring the Geded cost observation to that combination.']),
  adoption='Hold default performance integration. Large-text paired median 1.066429 and 10/20 faster with pronounced order association is real adverse evidence; first output Vec stays alive while timing the other side, unlike bounded product streaming, but this does not prove allocator/cache causation or justify deleting any round. No whole-parity/indexing improvement established.'),
 pr191=dict(head=p191['head']['sha'],base=p191['base']['sha'],state=p191['state'],draft=p191['draft'],current_checks=checks['191'],
  product_files=[dict(path=f['filename'],blob=f['sha'])for f in f191 if f['filename'].startswith('crates/')],
  actual_first_failure=dict(run=37960872769,job=113923069943,test_merge='f36edfef8cee6710bbc1b9b5034f03623187d7f6',command='cargo fmt --all -- --check',toolchain='stable rustc 1.99.0',actual_exit=1,original_formatter_hunks=diffs,log=meta(R/'PR191-check113923069943-original-decoded.log'),subsequent_main_steps_6_through_32='skipped',minimal_fix='Apply the four exact original formatter hunks; retain this original failure. No code changed in this review.'),
  cost_observer=dict(run=37960889762,job=113923127642,status='in_progress in snapshot; no terminal or cost acceptance claimed'),
  source_review_boundary=['Retains two lazy CachedStatement handles per rebuild-owned file and clears bindings after each execute result, including errors. The original public loop remains selected for non-rebuild ownership.',
   'Diff preserves source JSON and compression choice before base INSERT, last_insert_rowid before FTS INSERT, and the existing transaction/file boundary; no chunk batching or FTS deferral is introduced.',
   'Six new normal control definitions are present, including binding cleanup, lazy/missing-FTS/error prefix and rollback. Main CI stopped at formatting and does not prove those controls ran.',
   'The changed batch file overlaps a P8 file, in later chunk-insertion code while P8 changes PreparedUpdate/frontier reuse. A real textual integration and independent combined-source review are still needed; this report does not certify a merged file.',
   'Cost timing omits begin/readback/rollback and observes per-file chunk insertion only; until original terminal evidence exists, no measured improvement is credited.'],
  adoption='Not ready for engineering integration: first actual formatter failure remains. Preserve ordinary CI and independent finite-cost provenance; do not merge or infer scale benefits from queued/running work.'),
 TODO=dict(done=163,remaining=29,newly_completed=0),new_runs=0,remote_mutations=0)
with (R/'independent-PR190-191-source-and-CI-review.json').open('x')as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
names=['PR190-original.json','PR191-original.json','PR190-files-original.json','PR191-files-original.json','PR190-checks-original.json','PR191-checks-original.json','PR191-main-CI-jobs.json','PR190-original-cost-jobs.json','PR190-cost-run-original.json','PR190-oracle.rs','PR190-observe113909856107-original-decoded.log','PR191-check113923069943-original-decoded.log','PR190-original-cost-100-rows.json','independent-PR190-191-source-and-CI-review.json','finalize-readonly-review.py']
files=[meta(R/n)for n in names]
with (R/'archive-selection.json').open('x')as f:json.dump(dict(schema_version=1,file_count=len(files),total_bytes=sum(x['bytes']for x in files),files=files),f,indent=2);f.write('\n')
print(json.dumps(dict(report=meta(R/'independent-PR190-191-source-and-CI-review.json'),selection=meta(R/'archive-selection.json'))))
