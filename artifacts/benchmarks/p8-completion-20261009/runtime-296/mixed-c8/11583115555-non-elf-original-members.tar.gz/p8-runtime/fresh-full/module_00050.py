def stable_00050():
    return 50
