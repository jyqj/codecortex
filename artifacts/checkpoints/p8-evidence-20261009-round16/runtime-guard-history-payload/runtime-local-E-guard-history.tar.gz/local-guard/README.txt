组合候选2540092：八脚本审查与原协议新执行计划

当前163完成/29剩余；本目录不修改账本、源码、index或refs，也不声明任何新native通过。

1. independent-git-inventory-review.json / independent-git-inputs.json：独立从官方完整Git树重算树OID、逐blob字节核对。1087产品+138验证，新产品manifest4e0aa6bbfd4d5bea00416bca2cd99318d865ffc526fdcb45897c4d300de3ac00。不是完整候选checkout或v15通过声明。
2. eight-validation-files-independent-review.json：八个e95脚本原字节移植的限定接受。新缓存探针、终态封存、portable-v2 collector和rollback同字节快照均在范围。六个Rust产品文件语义由其他独审负责。
3. combined-original-protocol-acceptance-plan.json：最终execution HEAD及run尚未指定。新源必须实际完成runtime四C+真实1h+768 backfill、生命周期30+3×400、完整recovery/rollback、平台8格+collector、原6失败控制，以及规模150片/1500样本/原combine；所有原标准、重复数、时间/存储预算不变。

共享DB产品已经改变，所以旧599/296/e95成功原件只能保留原身份。e95冻结helper及独审不会更名成新候选；最终HEAD固定后另版本绑定新Git/9observer/新native binaries并做窄审。旧296真实一小时/RSS/parity/seal事实保留，cache缺口更正不可撤回。

原workflow Git blob是精确命令和环境的权威来源；JSON中的CLI仅导航模板，并未执行。
