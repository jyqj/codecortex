import ast,difflib,hashlib,json,pathlib
B=pathlib.Path('/workspace/scratch/a217aaae3bde');OLD=B/'original-173-runtime/recovery-helpers-275e-v2';OUT=B/'original-C3ff-runtime/recovery-helpers-C3ff-v1';OUT.mkdir(exist_ok=False)
def record(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),git_blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
def count(v):return sum(isinstance(n,ast.Assert) or (isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='check') for n in ast.walk(ast.parse(v)))
rows=[]
for name in ['review-recovery-e.py','review-recovery-e-011.py','preflight_recovery_zip.py']:
 old=(OLD/name).read_text();new=old;edits=[]
 candidates=[('/workspace/scratch/a217aaae3bde/original-173-runtime','/workspace/scratch/a217aaae3bde/original-C3ff-runtime'),('11597639035','11611995300'),('/workspace/scratch/a217aaae3bde/scale-original-275e','/workspace/scratch/a217aaae3bde/scale-original-c3ff'),('reviews/recovery-11611995300-275e8799-independent','accepted/recovery-11611995300-3ffcefc3-independent'),('275e8799d4947d297329073eaa3ca675d3fd0777','3ffcefc3b28ee1a4ed80caecebd7208a45c3e302'),('recovery-173-review.json','recovery-C3ff-review.json'),('recovery-173-011-review.json','recovery-C3ff-011-review.json'),('retained 173 recovery','retained C3ff recovery'),('original 173 execution scope','original C3ff execution scope'),('RUN = 37890757129','RUN = 37908825722')]
 for a,b in candidates:
  n=new.count(a)
  if n:new=new.replace(a,b);edits.append(dict(old=a,new=b,count=n))
 restored=new
 for e in reversed(edits):restored=restored.replace(e['new'],e['old'])
 assert restored==old and ast.dump(ast.parse(restored))==ast.dump(ast.parse(old))
 assert count(old)==count(new)
 p=OUT/name;p.write_text(new);(OUT/(name+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='173/'+name,tofile='C/'+name)))
 rows.append(dict(original=record(OLD/name),candidate=record(p),edits=edits,checks=count(old),reverse_entire_text_and_AST_equal=True))
support=B/'original-C3ff-runtime/helpers-C3ff-v1/e_raw_cache_audit.py';(OUT/support.name).write_bytes(support.read_bytes())
v=dict(schema='exact-C-recovery-identity-adaptation-v1',source='3ffcefc3b28ee1a4ed80caecebd7208a45c3e302',source_view=str(B/'scale-original-c3ff'),workflow_run=37908825722,artifact_id=11611995300,previous_source_unchanged='277f2490fad3fa30f2812b5547bad033867c9ea5',records=rows,shared_preflight_support=dict(original=record(support),copy=record(OUT/support.name),byte_identical=True),source_inventory_semantics='Original helpers compare complete current and previous Git inventories dynamically. No former1089 count or manifest override retained; C actual1092/be60 must be observed in the new artifact.',scope='Only exact identity, output/source paths and labels changed;84+55 checks and12preflight assertions unchanged. No original artifact/native/SQL execution yet; all gates and budgets preserved.',formal_completion=False,todo_remaining=29)
p=OUT/'adaptation-manifest.json';p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n');print(json.dumps(record(p)))
