import datetime, hashlib, json
from pathlib import Path
BASE=Path('/workspace/scratch/bfccb8494ba0')
OUT=Path(__file__).parent
TASKS=BASE/'task-closeout-ready/docs/roadmap/code-index-v2/tasks.json'
def ref(p): return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
ledger=json.loads(TASKS.read_bytes())
assert hashlib.sha256(TASKS.read_bytes()).hexdigest()=='6e2ab2e90cbd820228e8ff397d70c770561ba20d3110e6eca31338f29a945207'
alltasks={t['id']:t for t in ledger['tasks']}
ids=[f'P8-{i:03}' for i in [5,6,7,8,9,10,11,12,13,16]]
snapshot=Path('/dev/shm/pr-triage-bfcc-c8be5afa/runtime-review-Gc8/mixed-lifecycle-backfill-soak-evidence-snapshot.json')
assert ref(snapshot)['sha256']=='92a867636fbdc677adbcd7b25f2498173114fe7e73f0a5285df4862673322d55'
(OUT/'runtime-owner-snapshot.json').write_bytes(snapshot.read_bytes())
required={
'P8-005':'同一固定Gc8的release构建、五规模各30个原重复、150分片/1500样本及原严格aggregate成功；完整files/symbols/chunks/各edge/向量状态、资源与阶段原raw归属清楚。',
'P8-006':'同一完整scale总体的no-op/body/API/config/batch1/10/100/1000和1k专属五fanout各N30，闭包完整、每检查点原15表full parity/手写fanout见证及phase计时守恒通过。',
'P8-007':'原mixed C1/4/8/16每档完整900投递与全部终态、offer/queue/timeout/tail和C>1真实read/build交叠；另原backfill三seed×两phase×四C完整768请求、持有/恢复/排空。',
'P8-008':'原lifecycle分离30次真正空index/parse-cache冷建，以及reopen、uncached warm、cache-hit各400query；1230全样本/431进程会话及原统计重放，OS page-cache未清的事实保留。',
'P8-009':'原lifecycle/mixed/scale的资源账本按client/server/有凭据process-tree和DB/WAL/SHM/FTS/cache分开，原字节/单位/采样归属与实际费用状态可核；缺失与不适用保持unavailable/null。',
'P8-010':'原soak计划和实际工作均至少1小时、3601原操作完整终态、同一进程连续修改/删除/分支/catalog/cache复用、原RSS趋势与全时段coverage门、终点原完整15表full parity和统计重放通过。',
'P8-011':'原故障/恢复矩阵的kill/断网/cache损坏/DB busy/换库负例与原raw、真实stdio恢复和ready/删除不复活、请求/费用边界核验通过。',
'P8-012':'Linux/macOS×声明MSRV/stable×default/semantic八个原fresh-target冷构建+stdio均通过；原8格collector完整通过，SDK范围/实际编译器如实记录。',
'P8-013':'原scorer相关回归、六个原Rust失败门和七个retained CLI控制均验证quality/perf/inconclusive/lock/policy/overwrite的原非零退出与raw保留；原V20和上游依赖同时闭合。',
'P8-016':'原旧277f/新Gc8真实构建身份和受控schema重建/还原、default/semantic配置与用户源码保全、cache版本隔离/disabled回退、原DB完整性/FK和stdio回滚步骤实测通过。'
}
observed={
'P8-005':'目前仅原build+五capacity及1k/5k/10k rep0原函数接受：3/150、32/1500；50k/100k rep0运行。',
'P8-006':'已接受3片的原九阶段/原1k fanout证据；完整总体仍未收齐，不能由小规模代替。',
'P8-007':'非scale owner已接受四mixed档各900操作和backfill768请求；实际峰值1/4/7/12，C>1均有交叠，不额外要求并发饱和。',
'P8-008':'非scale owner已接受原1230 lifecycle样本、431sessions、原全样本统计及cache分层。',
'P8-009':'非scale owner已接受lifecycle1261资源观察/90物理对象与mixed/backfill归属；规模总体资源记录尚不完整。',
'P8-010':'原job113726259431 step7自09:12:43运行；尚无原小时终态封包，不能用墙钟到点代替验收。',
'P8-011':'recovery owner已接受7原故障控制、4原构建、13stdio、3active cache反例及14DB快照；下游完成仍受原依赖限制。',
'P8-012':'平台owner已接受8原冷构建；collector11374637801109:13:38success，artifact11605154697，原collect_cells重算09:23:01exit0、8/0/0一致。',
'P8-013':'六原Rust和七CLI非零1/1/1/1/2/2/2已接受；本agent薄核所有原件和实际退出，合成数据不作为性能结果。',
'P8-016':'recovery owner操作审核已接受；历史704源map另经本agent613同blob+91独算闭环，未移用旧运行。'
}
missing={
'P8-005':['147个尚未接受的原分片/1468个样本','原全150严格aggregate及其独立原件验收'],
'P8-006':['剩余scale原九阶段及全部fanout N30覆盖','P8-005原完成'],
'P8-007':['P8-006原硬依赖完成'],
'P8-008':['P8-007原硬依赖完成'],
'P8-009':['完整scale总体的原资源/阶段记录闭合','P8-008原硬依赖完成'],
'P8-010':['当前原soak真实成功终态与完整封包验收','P8-009原硬依赖完成'],
'P8-011':['P8-007与P8-010原硬依赖完成'],
'P8-012':['P8-011原硬依赖完成'],
'P8-013':['P8-012及其传递V20依赖完成','最终汇总适用V03/V04旧回归与失败门引用'],
'P8-016':['P8-012与P8-013原硬依赖完成']
}
rows=[]
for key in ids:
 t=alltasks[key]
 rows.append({'id':key,'title':t['title'],'original_status':t['status'],'original_steps':t['steps'],'original_acceptance':t['acceptance'],'original_validations':t['validations'],'original_hard_dependencies':t['depends_on'],'dependencies_still_not_done':[d for d in t['depends_on']if alltasks[d]['status']!='done'],'enough_for_scoped_closeout':required[key]+' 并且本项原硬依赖和相关旧功能回归已验收。','currently_observed':observed[key],'remaining_original_evidence_or_dependencies':missing[key],'closable_now':False})
inputs=[ref(TASKS),ref(BASE/'task-closeout-ready/docs/roadmap/code-index-v2/06-VALIDATION.md')]
inputs += [dict(ref(p),fixed_source_G='c8be5afaac568ffd40ef86d3795423c3b73c9f39',repository_path=p.relative_to(OUT/'protocol').as_posix())for p in sorted((OUT/'protocol').rglob('*.md'))]
references=[ref(OUT/'runtime-owner-snapshot.json'),ref(BASE/'todo-audit-round12/platform-final-Gc8/independent-final-collector-review.json'),ref(BASE/'todo-audit-round12/recovery-platform-Gc8/independent-recovery-and-seven-platform-review.json'),ref(BASE/'scale-intake-primary/ci-original-check-peer.json'),ref(BASE/'scale-intake-primary/gates-Gc8-peer/independent-review.json'),ref(BASE/'scale-intake-primary/historical-277f-peer/independent-review.json')]
result={'schema_version':1,'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_G':'c8be5afaac568ffd40ef86d3795423c3b73c9f39','formal_scale_run':37902429727,'run_attempt':1,'kind':'original_ten_task_closeout_mapping_no_new_gate','authority_inputs':inputs,'evidence_snapshot_references':references,'dependency_semantics':ledger['dependency_semantics'],'rows':rows,'common_regression_source_status':'原CI job113726259355于09:11:42成功；181原source tests和selected-v15实际P35/Ra970/1090 passed已亲核。实际checkout39ae在产品/139验证/CI/原R目录与Gc8相同，整repo不等，不标成directGc8 checkout。具体相关Rust/stdio回归使用各owner原报告，勿计重叠用例为额外唯一测试。','allowed_limits_not_new_blockers':['P8-005既有strict_paired_causal_performance=not_established和whole_tree_memory_peak=unknown不改成新完成门。','heterogeneous_stratified_coverage_v1允许每host层N很小；五规模各N30是总体覆盖，不要求凑同host N30，不输出跨host均值、因果提速或稳定p99。','09-BENCHMARK的可靠tail统计要求只适用于对应声明；本已注册描述性profile不凭新要求增样本、重跑或修改预算。','向量disabled/count null、provider成本null/unavailable、未清OS cache及非paid/live/非发行包pair等范围保持真实标签；不补伪0，不新增付费/live/holdout运行前置。','新study保留首五rep0作为原primary，原145只能在其通过后继续；原失败不得通过替换slot/重新挑样本闭合。','原CLI/aggregate成功本身不自动改tasks；闭合依赖与原任务范围后更新原ledger及派生视图即可，不新增本报告审批门。'],'not_claimed':['G8/M4全量发行认证','P8-014/015/017/018/019/020完成','holdout内容或新的live provider证据'],'current_counts':{'total':192,'done':163,'remaining':29,'newly_done_this_mapping':0,'accepted_scale_shards':3,'expected_scale_shards':150,'accepted_scale_samples':32,'expected_scale_samples':1500},'task_state_changed':False,'new_product_executions':0}
(OUT/'original-ten-task-closeout-map.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
md=['Gc8 原十项完成条件映射（只读，未修改任务状态）','',f"固定 source `c8be5afaac568ffd40ef86d3795423c3b73c9f39`，正式规模 run `37902429727` attempt 1。当前 **163 done / 29 remaining**；原规模 **3/150 片、32/1500 样本**。以下均沿用原任务定义及硬依赖。",'', '| 原任务 | 自身证据足够关闭的条件 | 当前仍缺 |','|---|---|---|']
for x in rows:md.append('| '+x['id']+' '+x['title']+' | '+required[x['id']]+' | '+'；'.join(missing[x['id']])+' |')
md += ['', '所有行还需其原硬依赖完成及相关旧功能回归通过。当前两项真正仍在执行的工作是完整规模矩阵和原一小时 soak；平台八格及原 collector、lifecycle、四档 mixed、backfill、故障恢复及失败门已有各 owner 的固定 Gc8 原件审核。完成依赖按原 P8-005→006→007→008→009→010，再到011→012→013/016顺序收口，不能把后段先通过的执行当作依赖已完成。', '', '原 CI 的181 source tests和selected-v15已实际通过；实际checkout是合成merge39ae，其产品/验证/CI/原R目录等于Gc8，整仓树并不相同。没有为本映射重跑任何命令。', '', 'P8-005已允许的paired causal not_established和whole-tree peak unknown继续保留；分host描述性统计不变成稳定p99或同host N30要求。向量disabled、费用null、无法测得的资源unavailable等如实分栏。不能补新live/holdout/付费/冷OS-cache门，也不能用重跑替换失败primary。', '', '详细原定义、源文件摘要、每项原依赖及已读证据摘要见 original-ten-task-closeout-map.json。']
(OUT/'original-ten-task-closeout-map.md').write_text('\n'.join(md)+'\n')
files=[ref(p)for p in sorted(OUT.rglob('*'))if p.is_file()and p.name!='archive-selection.json']
(OUT/'archive-selection.json').write_text(json.dumps({'entries':files,'task_state_changed':False,'task_credit':0,'remaining':29},indent=2)+'\n')
print(json.dumps({'report':ref(OUT/'original-ten-task-closeout-map.json'),'markdown':ref(OUT/'original-ten-task-closeout-map.md'),'selection':ref(OUT/'archive-selection.json'),'files':len(files),'bytes':sum(x['bytes']for x in files)}))
