#!/usr/bin/env python3
"""Read retained official evidence; do not run repository code, Git, tests, or network."""
import copy
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HEAD = '10ec828beb94200ec679302c45115760ebd55ee9'
CHECKOUT = '0dd17383a1e8bc526c5c4fb1a5d255c6fcb9bebf'
MAIN = '23eab8a7ea1fdfd6333c2e5a001cfb41e2a10d69'
BASE = 'fffd950d5b34b0180f308db1428a57d5bf358bf1'
PRODUCT = 'e7947428a449ed8fecc2d7b91a3c8df80700ed9c'
REVIEW = '9c8ecddf295db708ffaa6bacef7f6ede1bf4b658'
COLD = '044c008c9459cfa61e7701db2eb868342c508a39'
PID = 'crates/cc-semantic/tests/p7_crash_preparation.rs'
BINDINGS = ['scripts/reviewed-source-registry-v15.json', 'scripts/verify_reviewed_source_v15.py']

def dump(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n')

def original(name):
    value = json.loads((ROOT / (name + '.original-response.json')).read_text())['structuredContent']
    return json.loads(value['content']) if isinstance(value.get('content'), str) else value

def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}

pr = original('pr')
assert pr['head_sha'] == HEAD and pr['base_sha'] == BASE
head = original('commit-' + HEAD)
checkout = original('commit-' + CHECKOUT)
assert head['tree']['sha'] == checkout['tree']['sha'] == 'bbf90d3a3924e89f31c59c6f3f5c4e3a5c7de4a4'
assert [p['sha'] for p in checkout['parents']] == [BASE, HEAD]
cold_changes = original('M7F-to-10ec')
main_changes = original('M7F-to-main')
format_changes = original('044-to-10ec')
assert cold_changes['merge_base_commit']['sha'] == main_changes['merge_base_commit']['sha'] == BASE
assert format_changes['merge_base_commit']['sha'] == COLD
assert len(cold_changes['files']) == 32 and len(main_changes['files']) == 5
assert format_changes['total_commits'] == 3
cold_by_path = {f['filename']: f for f in cold_changes['files']}
main_by_path = {f['filename']: f for f in main_changes['files']}
overlap = sorted(set(cold_by_path) & set(main_by_path))
assert overlap == BINDINGS
assert [f['filename'] for f in main_changes['files'] if f['filename'].startswith('crates/')] == [PID]

log_path = ROOT / 'main-check-113916979105.decoded.log'
lines = re.sub(r'\x1b\[[0-9;]*m', '', log_path.read_text()).splitlines()
assert any('HEAD is now at 0dd17383 Merge ' + HEAD + ' into ' + BASE in l for l in lines)
def matches(needle):
    return [{'line': i + 1, 'text': line} for i, line in enumerate(lines) if needle in line]

new_rust = ['cold_stage_identity_is_explicit_and_old_plan_wire_stays_unchanged',
            'real_cold_scope_finishes_both_fresh_builds_and_all_fifteen_tables']
new_rust_results = {name: matches('test ' + name + ' ... ok') for name in new_rust}
assert all(len(rows) == 2 for rows in new_rust_results.values())
integration_runs = []
for index, line in enumerate(lines):
    if 'Running tests/p8_scale.rs (' not in line:
        continue
    end = next(i for i in range(index + 1, len(lines)) if 'test result:' in lines[i])
    assert '14 passed; 0 failed; 0 ignored;' in lines[end]
    integration_runs.append({'start_line': index + 1, 'end_line': end + 1,
                             'summary': lines[end], 'passed': 14, 'failed': 0, 'ignored': 0})
assert len(integration_runs) == 2
cold_python = [dict(line=i+1, text=l) for i, l in enumerate(lines) if '(test_p8_cold_matrix.' in l]
assert len(cold_python) == 12 and all(x['text'].endswith(' ... ok') for x in cold_python)
assert len(matches('Ran 430 tests in 49.110s')) == 1
start = next(i for i, l in enumerate(lines) if 'test_altered_lint_transformation (test_current_source.' in l)
end = next(i for i, l in enumerate(lines) if 'Ran 181 tests in 580.830s' in l)
source_tests = [dict(line=i+1, text=lines[i]) for i in range(start, end)
                if re.search(r'test_\w+ \(test_\w+\.\w+\.test_\w+\) \.\.\. ok$', lines[i])]
assert len(source_tests) == len(set(re.sub(r'^\S+ ', '', row['text']) for row in source_tests)) == 181
assert lines[end + 2].endswith(' OK')
guard_row = next((i, l) for i, l in enumerate(lines) if '"source_version": "p8-completion-source-20261009-v15"' in l and '"status": "passed"' in l)
guard = json.loads(guard_row[1][guard_row[1].index('{'):])
assert guard['product_source'] == PRODUCT and guard['review_source'] == REVIEW
assert guard['complete_inputs'] == 1095 and guard['executed_previous_proof'] == 'p8-oracle-compat-source-20261008-v14'
jobs = original('main-jobs')['jobs']
assert len(jobs) == 3 and all(j['conclusion'] == 'success' for j in jobs)
main_job = next(j for j in jobs if j['id'] == 113916979105)
assert all(s['conclusion'] == 'success' for s in main_job['steps'])
checks = original('checks')['check_runs']
ordinary = [c for c in checks if any(p['number'] == 189 for p in c['pull_requests'])]
other = [c for c in checks if c not in ordinary]
assert len(ordinary) == 26 and sum(c['conclusion'] == 'success' for c in ordinary) == 25
assert len(other) == 2 and all(c['conclusion'] == 'skipped' and '37961502917' in c['html_url'] for c in other)

canonical = json.loads((ROOT / 'cold-R9c8-canonical.json').read_text())
assert identity(ROOT / 'cold-R9c8-canonical.json')['git_blob'] == '2c4e9f5eeb160edf1978e20c5b9276b27fea0f19'
assert canonical['source'] == PRODUCT
assert [len(canonical[k]) for k in ('complete_inputs', 'paths', 'validation_inputs')] == [1095, 71, 145]
seed = Path('/dev/shm/todo-audit-G6B-22975e49-binding/generated/scripts/reviewed-source-registry-v15.json')
assert identity(seed)['git_blob'] == main_by_path[BINDINGS[0]]['sha'] == '93639088746cd51e4be22e8359f933f71b20546a'
(ROOT / 'main-G6-registry.original.json').write_bytes(seed.read_bytes())
main_map = json.loads(seed.read_text())
product_diff = [{'path': p, 'current_cold_sha256': canonical['complete_inputs'][p],
                 'main_sha256': main_map['complete_inputs'][p]} for p in canonical['complete_inputs']
                if canonical['complete_inputs'][p] != main_map['complete_inputs'][p]]
assert len(product_diff) == 4
assert PID not in canonical['paths']
assert canonical['complete_inputs'][PID] == main_map['delta'][PID]['before_sha256']
validation_diff = [{'path': p, 'change': 'added' if p not in main_map['validation_inputs'] else 'modified',
                    'cold_sha256': h, 'main_sha256': main_map['validation_inputs'].get(p)}
                   for p, h in canonical['validation_inputs'].items()
                   if main_map['validation_inputs'].get(p) != h]
assert len(validation_diff) == 4 and sum(x['change'] == 'added' for x in validation_diff) == 3
planned_complete = copy.deepcopy(canonical['complete_inputs'])
planned_complete[PID] = main_map['complete_inputs'][PID]
planned_delta = copy.deepcopy(canonical['paths'])
planned_delta[PID] = main_map['delta'][PID]
assert len(planned_complete) == 1095 and len(planned_delta) == 72
incoming = [dict(path=f['filename'], git_blob=f['sha'], action='retain_main_original_bytes')
            for f in main_changes['files'] if f['filename'] not in BINDINGS]
assert len(incoming) == 3
plan = {'schema_version': 1, 'status': 'read_only_prospective_not_created', 'actual_product_commit': None,
        'actual_review_commit': None, 'actual_guard_commit': None,
        'fixed_comparison_base': BASE, 'current_cold_head': HEAD, 'fixed_main': MAIN,
        'suggested_ordered_product_parents': [HEAD, MAIN],
        'preserve_all_cold_changes': len(cold_changes['files']),
        'preserve_cold_artifact_leaves': sum(p.startswith('artifacts/') for p in cold_by_path),
        'main_additions_or_replacements_excluding_bindings': incoming,
        'shared_changed_paths_requiring_identity_reconciliation': overlap,
        'textual_merge_conflict_status': 'not_executed; shared changed paths identified, not a claimed Git merge result',
        'product_differences_main_vs_current_cold': product_diff,
        'validation_differences_main_vs_current_cold': validation_diff,
        'prospective_counts': {'complete_inputs': 1095, 'base_delta': 72, 'validation_inputs': 145},
        'complete_inputs': planned_complete, 'paths': planned_delta,
        'validation_inputs': copy.deepcopy(canonical['validation_inputs']),
        'minimal_sequence': ['Fresh-check actual PR head and main before a later authorized mutation.',
           'Create a product composition preserving all cold leaves, the main PID fixture and both R6 artifacts; retain ancestry from head10ec and main23eab.',
           'Independently review the exact composed product and 145 validation inputs, preserving all prior P/R/G records.',
           'Install a new artifact-only R; mechanically rebind the existing v15 registry and four guard pins without algorithm changes.',
           'Use the ordinary CI on the actual resulting source; do not transfer the old source identity or add a new full scale study as an automatic retarget requirement.'],
        'measurement_boundary': 'Run37954851017 attempt1 remains source044. Successful current head10ec engineering checks do not relabel its original cold samples. A future source composition gets its own ordinary engineering identity; no study is started or changed by this plan.'}
dump('future-main-retarget-prospective-input-plan.json', plan)
evidence = {'schema_version': 1, 'created_at_utc': '2026-10-09T17:09:02Z',
    'verdict': 'accepted_scoped_current_engineering_CI_and_readonly_retarget_plan',
    'local_product_or_test_execution': False, 'remote_mutations': False,
    'head': HEAD, 'product_source': PRODUCT, 'review_source': REVIEW,
    'actual_ci_checkout': CHECKOUT, 'whole_repository_tree_equality_to_head': head['tree']['sha'],
    'checkout_identity_not_relabelled': True,
    'main_CI': {'run_id': 37959075859, 'job_id': 113916979105, 'conclusion': 'success',
        'completed_at_utc': next(c['completed_at'] for c in checks if c['id'] == 113916979105),
        'official_steps': main_job['steps'], 'full_decoded_log': identity(log_path),
        'log_transport_scope': 'Once fetched GitHub connector decoded log string preserved as UTF-8 including BOM; not raw HTTP archive bytes or a local shell exit receipt.',
        'new_cold_Rust_tests': new_rust_results, 'p8_scale_integration_runs': integration_runs,
        'cold_python_tests': cold_python, 'P8_python_summary': matches('Ran 430 tests in 49.110s'),
        'source_integrity_tests': source_tests, 'source_integrity_summary': matches('Ran 181 tests in 580.830s'),
        'selected_v15_argv': 'python3 scripts/verify_reviewed_source_v15.py --source-version p8-completion-source-20261009-v15',
        'selected_v15_result': guard, 'selected_v15_result_line': guard_row[0] + 1,
        'exit_evidence': 'GitHub job and every step completed/success under the recorded bash -e command; passed stdout retained. No invented numeric native child receipt.'},
    'ordinary_PR_snapshot': {'count': 26, 'success': 25, 'in_progress': 1,
        'pending': [{k:c[k] for k in ('id','name','status','conclusion','started_at','completed_at')} for c in ordinary if c['conclusion'] != 'success'],
        'excluded_separate_manual_skipped': [{k:c[k] for k in ('id','name','status','conclusion','html_url')} for c in other]},
    'main_CI_companion_jobs': [{k:j[k] for k in ('id','name','status','conclusion')} for j in jobs],
    'original_formatter_failure_preserved': {'run_id':37953884132,'job_id':113899341171,
        'repo_path':'artifacts/checkpoints/p8-cold-format-repair-a217-20261009/original-fmt-failure.log',
        'git_blob':'01486310ca85ed8d17616ac604e6eba8c12044df',
        'scope':'Immutable prior failure locator retained; current success is independently checked, not an erasure or rerun claim.'},
    'format_bridge': {'fixed_cold_source':COLD,'current_head':HEAD,'commits':3,
        'product_changed_paths':[f['filename'] for f in format_changes['files'] if f['filename'].startswith('crates/')],
        'semantic_scope':'Original formatter removes the redundant lazy closure block around the same single expression and adjusts line wrapping/import formatting. The other cold producer bytes and 145 validation map are unchanged except the source bindings.',
        'evidence':'044-to-10ec.original-response.json; fetched exact canonical R and original CI'},
    'current_related_regression_gap':'No failed current main-CI engineering step found; soak remains a distinct pending observation in this fixed snapshot.',
    'prospective_merge_counts':plan['prospective_counts'], 'prospective_plan':'future-main-retarget-prospective-input-plan.json',
    'measurement_scope': {'cold_run':37954851017,'attempt':1,'source':COLD,'measurement_credit_added':0,
        'cold_study_progress':'Not repolled or validated here; delegated unique study intake owner retains that responsibility.',
        'TODO_status_changed':False,'remaining_TODOs':29}}
dump('PR189-current-CI-and-retarget-review.json', evidence)
print(json.dumps({'status':'passed_readonly_audit','source_integrity_unique_ok':len(source_tests),
 'new_cold_Rust':2,'actual_p8_scale_integration_runs':len(integration_runs),'cold_Python':len(cold_python),
 'main_CI':'success','checkout_tree':head['tree']['sha'],'prospective_counts':plan['prospective_counts'],
 'product_tests_or_measurements_executed':False},sort_keys=True))
