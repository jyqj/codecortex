from pathlib import Path
import hashlib,json,zipfile
B=Path(__file__).resolve().parent
O=B/'sealed-50k-evidence'
O.mkdir(exist_ok=False)
PREFIX='artifacts/checkpoints/p8-round27-GW4-50k-original-bfcc-20261009'
def identity(p):
 b=p.read_bytes()
 return {'local_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def read(p):return json.loads(p.read_bytes())
transfer=read(B/'transfers.public-derived.json')
review=read(B/'scale-50000-validation-attempt01/independent-shard-intake-review.json')
receipt=read(B/'scale-50000-validation-attempt01/receipt.json')
assert receipt['exit_code']==0 and review['measurement_count']==9 and review['original_function_calls']==1
assert read(B/'capacity-check-receipt.json')['exit_code']==0
originals=[]
for item in transfer['originals']:
 d=identity(Path(item['workspace_path']));m=item['metadata'];assert d['bytes']==m['size_in_bytes'] and 'sha256:'+d['sha256']==m['digest']
 originals.append(dict(d,artifact_id=m['id'],artifact_name=m['name'],repository_path=PREFIX+'/original-zips/'+Path(d['local_path']).name))
summary={'schema':'GW4-one-original-50k-shard-intake-v1','source':review['source'],'run_id':review['run_id'],'run_attempt':1,'scale':50000,'repetition':0,'workload_profile':'scale_wide_dirty_v1','oracle_physical_profile':'scale_capacity_v1','status':'original_validate_shard_passed_once','receipt':receipt,'shard':review,'capacity':read(B/'capacity-original-intake-review.json'),'new_accepted_shards':1,'new_accepted_measurements':9,'cumulative_same_run_accepted_shards':4,'planned_shards':150,'cumulative_same_run_accepted_measurements':41,'planned_measurements':1500,'original_build':{'artifact_id':11642471195,'zip_git_blob':'d6bf17c610c18701345a1a58a414ca4762dc251d','review_git_blob':'4ffa93afa05d410be04e281e84a306515634096d','revalidated':False},'original_zip_leaves':originals,'transport_recovery':'Each artifact downloaded twice: first call results were lost by a client JSON parse error after completion; root explicitly authorized second transport of the same artifacts. Only one shard validator call and one new registered slot, no second experiment.','limits':['No aggregate pass or complete-study/release/TODO credit.','Prior three 008f shards, G8, cold044 and failed studies were not revalidated or pooled.','Source008f retains the known inherited oracle scratch/public-output compatibility issue; these raw results are not execution on subsequent repaired P2 and do not discharge that HOLD.','Private temporary download URLs retained locally and omitted from public-derived copies.'],'new_product_workload_executions':0,'new_TODO_completions':0,'TODO_remaining':29}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
names=['official-50k-original-selection.json','download-result-retention-failure-attempt01.json','transfers.public-derived.json','50000.descriptor.actual.json','review-capacity-originals.py','capacity-check-receipt.json','capacity-check.stdout','capacity-check.stderr','capacity-original-intake-review.json','seal-50k-intake.py']
files=[B/n for n in names]
files.extend(p for p in (B/'scale-50000-validation-attempt01').iterdir() if p.is_file())
files.extend(p for p in (B/'capacity-11642662865').iterdir() if p.is_file())
files.append(B.parent/'GW4-original-shard-intake-preparation/intake-original-shard-once.py')
entries=[]
for p in sorted(set(files)):
 name=str(p.relative_to(B)) if p.is_relative_to(B) else 'external/'+p.parent.name+'/'+p.name
 entries.append(dict(identity(p),archive_path=name))
selection={'schema':'selected-original-intake-evidence-v1','entries':entries,'whole_original_zips_separate':True,'exclusions':['Private temporary-URL transfer receipts; source SHA retained in public-derived record','Duplicate extracted raw present in whole original measurement ZIP','Previously accepted build ZIP/ELF and old shard archives retained by immutable locators']}
(O/'archive-selection.json').write_text(json.dumps(selection,indent=2)+'\n')
with zipfile.ZipFile(O/'support.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for entry in entries:z.write(entry['local_path'],entry['archive_path'])
 z.write(O/'archive-selection.json','archive-selection.json')
leaves=originals+[dict(identity(O/n),repository_path=PREFIX+'/'+n) for n in ['support.zip','summary.json','archive-selection.json']]
manifest={'schema':'immutable-five-leaf-upload-plan-v1','entries':leaves,'root_selects_actual_parent_and_commits_refs':True,'whole_original_zips_separate':True,'selected_original_files':len(entries),'no_prior_archive_repacked':True}
(O/'root-upload-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'leaves':len(leaves),'selected_files':len(entries),'support':identity(O/'support.zip'),'manifest':identity(O/'root-upload-manifest.json')}))
