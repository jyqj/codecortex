def stable_00388():
    return 388
