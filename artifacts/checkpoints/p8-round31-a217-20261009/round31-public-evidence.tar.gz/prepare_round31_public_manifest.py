import pathlib, json, hashlib, re, datetime
ROOT=pathlib.Path('/workspace/scratch/a217aaae3bde')
DOMAIN=ROOT/'original-C3ff-platform-gates'
CUTOFF='2026-10-09T12:34:58Z'
old_sources={}
for rnd in (28,29,30):
    inv=json.loads((ROOT/f'p8-db-lock-observation-integration/round{rnd}-public-evidence-inventory.json').read_text())
    for x in inv['files']: old_sources[x['source']]={'round':rnd,**x}
def record(rel,target):
    p=ROOT/rel
    assert p.is_file() and not p.is_symlink()
    data=p.read_bytes()
    # Only small finished reports/logs/metadata are read to enumerate a public selection.
    # Original ZIP bytes, extracted measurements and native binaries are never opened here.
    assert not rel.endswith('.zip') and 'private-download' not in rel
    txt=data.decode('utf-8')
    counts={
        'private_file_id':len(re.findall(r'file_[0-9a-f]{16,}',txt,re.I)),
        'library_uri':len(re.findall(r'library://[A-Za-z0-9]',txt)),
        'signed_url':len(re.findall(r'https?://[^\s"<>]+[?&](?:sig|signature|X-Amz-Signature)=',txt,re.I)),
    }
    assert not any(counts.values()),(rel,counts)
    assert rel not in old_sources, rel
    return {'source':rel,'target':target,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),
            'mode':format(p.stat().st_mode & 0o777,'06o').replace('000644','100644'),
            'public_reference_scan':counts}

references=[]
for rel in [
 'original-C3ff-platform-gates/helper-storage-root-v1/independent-review.json',
 'original-C3ff-platform-gates/helper-storage-root-v1/review-platform-C3ff-storage-root.py',
 'original-C3ff-platform-gates/helper-storage-root-v1/adaptation-manifest.json']:
    if rel in old_sources:
        x=old_sources[rel];rnd=x['round']
        references.append({'scope':'unchanged_storage_root_interface_or_peer','source':rel,'git_blob':x['git_blob'],'bytes':x['bytes'],'sha256':x['sha256'],
          'commit':'098a93cf6783887f1aed12466bc844b2c8d980dd',
          'container':f'artifacts/checkpoints/p8-round{rnd}-a217-20261009/round{rnd}-public-evidence.tar.gz','member':x['target']})
repair=json.loads((DOMAIN/'LG-diagnostic/format-failure-repair-public-inventory.json').read_text())
composition=json.loads((ROOT/'p8-db-lock-observation-integration/LG2-final-composition-inputs.json').read_text())
for x in repair['entries']:
    matches=[el for el in composition['review_elements'] if el['sha']==x['git_blob'] and el['path'].endswith('/'+x['target'])]
    assert len(matches)==1,x['source']
    references.append({'scope':'fixed_LG_failure_and_three_path_repair','source':x['source'],
      'commit':composition['guard'],'path':matches[0]['path'],'git_blob':x['git_blob'],
      'bytes':x['bytes'],'sha256':x['sha256'],'mode':matches[0]['mode'],
      'binding_basis':'root actual G2 composition and published ref receipt; this selection does not republish the already fixed original'})
ref_path=DOMAIN/'round31-existing-public-evidence-references.json'
ref_path.write_text(json.dumps({'schema':'round31-existing-public-reference-index-v1','cutoff':CUTOFF,
  'references':references,'formal_newly_completed':0,'formal_remaining':29,
  'limit':'LG2 source admission/repair is not feature control or mixed native success; storage interface is unchanged. Existing R30 inputs are referenced, not recopied.'},ensure_ascii=False,indent=2)+'\n')

selections=[]
def add(relative,target): selections.append(record('original-C3ff-platform-gates/'+relative,target))
for name in ['intake_linux_stable_default.py','eighth-original-copies.json','linux-stable-default-safe-extraction-receipt.json','linux-stable-default-pairs.json','linux-stable-default-RAM-backcopy-receipt.json']:
    add(name,'platform/eighth-linux-stable-default/'+name)
for name in ['platform-C3ff-cell-review.json','cli.stdout','cli.stderr','execution.json']:
    add('linux-stable-default-review/'+name,'platform/eighth-linux-stable-default/review/'+name)
for aid in (11614026675,11612849803):
    add(f'zips/{aid}/artifact-metadata.json',f'platform/eighth-linux-stable-default/original-metadata/{aid}.json')
for name in ['C3ff-linux-stable-default-113748747034-original.log','C3ff-linux-stable-default-113748747034-original-review.json',
             'official-C-platform-artifacts-1791547624869.json','official-C-platform-jobs-1791547624869.json']:
    add('C3ff-ci/'+name,'platform/eighth-linux-stable-default/official/'+name)
for name in ['all-eight-pairs.json','first-six-original-copies.json','first-six-RAM-safe-extraction-receipt.json','intake_first_six_for_collector.py',
             'complete-eight-RAM-backcopy-receipt.json','last-two-pairs-metadata-backcopy.json']:
    add(name,'platform/complete-eight/'+name)
for name in ['platform-C3ff-cell-review.json','independent-collected-matrix.json','cli.stdout','cli.stderr','execution.json']:
    add('complete-eight-review/'+name,'platform/complete-eight/review/'+name)
for name in ['M4-three-source-and-P5-regression-scoped-review.json','PR186-actual.json','actual-0-raw.json','actual-1-raw.json','actual-2-raw.json',
             'engineering-tree.json','mechanism-tree.json','empty-format-fetch-error.json']:
    add('M4-lane-registry-review/'+name,'M4-three-source-review/'+name)
add('LG-diagnostic/artifacts/11613902661/original-failure-zip-inspection.json','LG-first-failure/original-failure-zip-inspection.json')
add('LG-diagnostic/format-failure-repair-public-inventory.json','LG-first-failure/already-published-16-file-repair-inventory.json')
add(ref_path.name,'existing-public-evidence-references.json')
add('prepare_round31_public_manifest.py','prepare_round31_public_manifest.py')
assert len({x['source'] for x in selections})==len(selections)
assert len({x['target'] for x in selections})==len(selections)
assert all(x['mode']=='100644' for x in selections)
manifest={'schema':'round31-pr-audit-public-manifest-v1','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'cutoff':CUTOFF,'selection_status':'prepared_not_published','source_root':str(ROOT),
 'entries':selections,'file_count':len(selections),'total_bytes':sum(x['bytes'] for x in selections),
 'scope':'Only original C eighth cell and original independent complete collector acceptance records, new immutable storage receipts, scoped M4 three-source/P5 history review, first LG failure ZIP inspection and existing-public repair navigation.',
 'task_counts':{'done':163,'remaining':29,'newly_closed':0},
 'measured_source_C':'3ffcefc3b28ee1a4ed80caecebd7208a45c3e302',
 'platform_scope':{'accepted_cells':8,'required_cells':8,'independent_original_collector_returncode':0,'official_collector_job':113802173447,'official_collector_as_last_observed_before_cutoff':'queued','official_equivalence':'pending'},
 'M4_scope':'Actual three source paths independently reviewed; original P5 selected regression facts remain P5, not M4 execution.',
 'LG_scope':'First run fmt failure preserved; 16 failure/repair records already fixed in G2 4d18 and referenced instead of repackaged. No feature native success credit.',
 'not_reselected_prior_round_source_count':len(old_sources),'existing_public_reference_file':ref_path.relative_to(ROOT).as_posix(),
 'exclusions':['All original ZIPs/native binaries/SQLite/raw workload payloads','All private transfers/download captures/actual file identifiers/signed URLs',
 'R28/R29/R30 original selected source files, including the storage-root helper and peer','Runtime soak and LG2 intake records owned by runtime agent',
 'Official collector future results and all post-cutoff outcomes'],
 'operations_for_this_selection':'Small finished records read solely for manifest hashes/public scan; no ZIP/member byte reverification, no helper replay, no native execution, no remote mutation.'}
out=DOMAIN/'round31-public-archive-manifest.json'
out.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
b=out.read_bytes()
print(json.dumps({'path':str(out),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'files':len(selections),'payload_bytes':manifest['total_bytes']}))
