from pathlib import Path
import json,hashlib,stat,zipfile
H=Path('/workspace/scratch/bfccb8494ba0/round40-borrowed-sorted-cursor-candidate');O=H/'sealed';O.mkdir(exist_ok=False)
def meta(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
paths=sorted(p for p in H.rglob('*') if p.is_file() and O not in p.parents)
files=[{'local_path':str(p),'archive_path':str(p.relative_to(H)),'posix_mode':oct(stat.S_IMODE(p.stat().st_mode)),**meta(p)} for p in paths]
selection={'schema':'borrowed-sorted-cursor-author-selected-originals-v1','files':files,'scope':'author candidate bytes, exact original file, instructions, patch and all static preparation/negative/success receipts; no Rust/probe/workload execution','third_party_upstream_source':'not re-bundled; exact official-origin hashes and reviewed API locations are in author-static-preservation.json'}
sel=O/'archive-selection.json';sel.write_text(json.dumps(selection,indent=2)+'\n');zp=O/'complete-author-source-and-static-originals.zip'
with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p,f in zip(paths,files):
  i=zipfile.ZipInfo(f['archive_path'],(2026,10,10,0,0,0));i.create_system=3;i.external_attr=(stat.S_IFREG|stat.S_IMODE(p.stat().st_mode))<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,p.read_bytes())
 i=zipfile.ZipInfo('archive-selection.json',(2026,10,10,0,0,0));i.create_system=3;i.external_attr=(stat.S_IFREG|0o644)<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,sel.read_bytes())
with zipfile.ZipFile(zp) as z:
 assert len(z.infolist())==len(files)+1
 for f in files:
  b=z.read(f['archive_path']);assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
  assert oct((z.getinfo(f['archive_path']).external_attr>>16)&0o777)==f['posix_mode']
 assert z.read('archive-selection.json')==sel.read_bytes()
source=H/'candidate/crates/cc-eval/src/benchmark/oracle/streaming.rs';uploads=[]
for p in [source,H/'source-manifest.json',H/'source.patch',H/'author-design-and-validation-boundary.json',zp]:uploads.append({'local_path':str(p),**meta(p)})
(O/'upload-manifest.pending.json').write_text(json.dumps({'files':uploads,'support_members':len(files)+1,'actual_P':None,'refs_mutated':False},indent=2)+'\n')
print(json.dumps({'files':uploads,'support_members':len(files)+1}))
