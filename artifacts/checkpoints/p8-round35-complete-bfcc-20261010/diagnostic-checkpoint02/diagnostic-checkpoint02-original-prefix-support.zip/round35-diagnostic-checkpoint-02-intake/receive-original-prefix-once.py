"""First checkpoint02 intake; accepted00/01 are only continuity dependencies.

Execute the unchanged frozen byte reader once. No original validator, ELF,
product, workload or network transport is executed by this controller.
"""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'round35-diagnostic-checkpoint-02-intake/attempt01'
OLD = ROOT / 'round34-diagnostic-checkpoint-01-intake/attempt01'
OFFICIAL = ROOT / 'round35-diagnostic-and-full-cohort-official-originals.json'
BINDING = ROOT / 'round32-100k-diagnostic-intake-bound-9cc6-run38012409915/binding.json'
READER = ROOT / 'round32-100k-diagnostic-intake-preparation/read-original-diagnostic.py'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save(name, value):
    with (OUT / name).open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

OUT.mkdir(parents=True, exist_ok=False)
assert sha(READER) == 'ae7945e5f7150b350ae856a1fd22d7ad92e157c74ae73c8ab3e3799a857bca23'
assert sha(BINDING) == '12819cd48434ac181d4aaac0eb020ba936c9a48e39d02683766f5dd5f07c17cb'
index = json.loads((OLD / 'official-index.json').read_text())
official = json.loads(OFFICIAL.read_text())
artifact = next(x for x in official['diagnostic_artifacts']['artifacts'] if x['id'] == 11656371239)
assert artifact['size_in_bytes'] == 58486 and artifact['digest'] == 'sha256:9789306184d0a0056122dc147888136cd12c85e8a8936f45866021ef2faa2801'
assert [x['index'] for x in index['artifacts']] == [0, 1]
index['artifacts'].append({'kind': 'checkpoint', 'index': 2, 'artifact': artifact, 'run_attempt': 1,
    'zip_path': str(ROOT / 'round35-diagnostic-original-artifacts/p8-100k-diagnostic-progress-38012409915-1-02-original.zip'),
    'official_original_reference': {'path': str(OFFICIAL), 'sha256': sha(OFFICIAL)}})
index['time_boundary'] = 'Run identity and prior job status remain the original historical snapshots, not current diagnostic status. Only the new artifact metadata comes from the round35 observation. Old checkpoints00/01 are previously accepted continuity inputs, not new receptions or samples.'
index['new_artifact_observed_at'] = official['observed_at']
index['continuity_dependency'] = {'artifact_ids': [11655358015, 11655694522],
    'previous_report': str(OLD / 'checkpoint01-prefix-review.json'), 'sha256': sha(OLD / 'checkpoint01-prefix-review.json'),
    'new_artifact_ids': [11656371239]}
save('official-index.json', index)
argv = ['python3', '-B', str(READER), '--binding', str(BINDING), '--official-index', str(OUT / 'official-index.json'), '--output', str(OUT / 'reader')]
start, tick = datetime.datetime.now(datetime.timezone.utc).isoformat(), time.monotonic()
with (OUT / 'reader.stdout').open('xb') as o, (OUT / 'reader.stderr').open('xb') as e:
    r = subprocess.run(argv, cwd=ROOT, stdout=o, stderr=e, check=False)
save('reader.execution.json', {'argv': argv, 'cwd': str(ROOT), 'started_utc': start,
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'duration_seconds': time.monotonic() - tick,
    'exit_code': r.returncode, 'stdout_sha256': sha(OUT / 'reader.stdout'), 'stderr_sha256': sha(OUT / 'reader.stderr'),
    'reader_sha256': sha(READER), 'new_artifact_ids': [11656371239], 'continuity_old_artifact_ids': [11655358015, 11655694522],
    'validate_build_calls': 0, 'validate_shard_calls': 0, 'inspect_raw_calls': 0, 'ELF_calls': 0,
    'new_downloads': 0, 'accepted_samples': 0, 'task_credit': 0})
print(json.dumps({'reader_exit': r.returncode, 'output': str(OUT)}))
raise SystemExit(r.returncode)
