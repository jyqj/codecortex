#!/usr/bin/env python3
"""Package already-fixed canonical R3; preserve first selector-schema failure."""
import json, hashlib, stat, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
FINAL=ROOT.parent/'final-R3'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def write(p,d):
    with p.open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2,sort_keys=True);f.write('\n')
def desc(p,member=None):
    b=p.read_bytes();r={'path':str(p),'bytes':len(b),'sha256':sha(b),'git_blob':oid('blob',b)}
    if member:r['support_member']=member
    return r
fixed=(FINAL/'independent-source-review.json').read_bytes()
assert len(fixed)==899946 and sha(fixed)=='f8384ec7620c1f69be155f0a2c870e9c2fd06ff6de40920d7389c08d03d01080'
meta=json.loads(read(ROOT/'official-P3f-commit.json')['response_content'])
assert meta['sha']=='aac83a8e57d87fa9fe95af16173c68f1dd4fb88e'
roots=read(ROOT/'actual-P3f-independent-tree-input-review.json')['root_reconstruction']
canonical_path='artifacts/checkpoints/p8-dependency-exclusion-bfcc-20261009/independent-source-review.json'
selected={}
def add(p,name,expected=None):
    p=Path(p);assert p.is_file() and not p.is_symlink();b=p.read_bytes()
    if expected:assert len(b)==expected['bytes'] and sha(b)==expected['sha256']
    assert name not in selected
    selected[name]={'local_path':str(p),'archive_path':name,'bytes':len(b),'sha256':sha(b),'git_blob':oid('blob',b),'POSIX_mode':oct(stat.S_IMODE(p.stat().st_mode))}
for p in sorted(ROOT.iterdir()):
    if p.is_file() and p.name not in ('package-only.stdout','package-only.stderr','package-only.exit'):add(p,'independent/'+p.name)
for folder,label,selection in [('/dev/shm/todo-audit-H-dependency-exclusion','author-v1','archive-selection.json'),('/dev/shm/todo-audit-H-dependency-exclusion-v2','author-v2','archive-selection.json'),('/dev/shm/todo-audit-H-dependency-exclusion-v3','author-v3','archive-selection.json'),('/dev/shm/pr-triage-H-dependency-exclusion-peer','source-peer','archive-selection.v2.json')]:
    folder=Path(folder);s=read(folder/selection)
    for row in s['files']:
        p=Path(row['path'] if 'path' in row else row['local_path']);relative=row.get('relative_path',p.relative_to(folder).as_posix());add(p,label+'/'+relative,row)
    add(folder/selection,label+'/'+selection)
for p,name in [(ROOT.parent/'final-R2/independent-source-review.json','inherited/canonical-R2.original.json'),(Path('/dev/shm/todo-audit-G2-cd68-binding/generated/scripts/verify_reviewed_source_v15.py'),'contract/original-v15-guard.py'),(Path('/dev/shm/todo-audit-P3-H-d22-candidate-plan/original-ci.yml'),'contract/original-ci.yml'),(Path('/dev/shm/todo-audit-P3-H-d22-candidate-plan/existing-CI-coverage-and-R3-boundary.json'),'contract/existing-CI-and-runtime-boundary.json'),(ROOT.parent/'H-package-round17-pending-recovery.json','prior-native/pending-recovery.original.json')]:add(p,name)
selection={'schema':'source-only-actual-P3f-R3-support-selection-v1','source':meta['sha'],'tree':meta['tree']['sha'],'runtime_status':'not_run','native_tunnel_calls':0,'files':list(selected.values()),'file_count':len(selected),'total_bytes':sum(x['bytes'] for x in selected.values()),'canonical_uploaded_separately':desc(FINAL/'independent-source-review.json'),'large_original_native_or_scale_ZIPs_duplicated':False,'TODO_remaining':29}
write(FINAL/'support-selection.json',selection)
zip_path=FINAL/'source-only-review-originals.zip'
with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,row in selected.items():
        p=Path(row['local_path']);raw=p.read_bytes();assert sha(raw)==row['sha256']
        info=zipfile.ZipInfo(name,(2026,10,9,0,0,0));info.create_system=3;info.external_attr=(stat.S_IFREG|int(row['POSIX_mode'],8))<<16;info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,raw)
    z.write(FINAL/'support-selection.json','support-selection.json')
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None and len(z.infolist())==len(selected)+1
    for name,row in selected.items():
        raw=z.read(name);assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
        assert stat.S_IMODE(z.getinfo(name).external_attr>>16)==int(row['POSIX_mode'],8)
    assert z.read('support-selection.json')==(FINAL/'support-selection.json').read_bytes()
manifest={'schema':'source-only-actual-P3f-R3-upload-manifest-v1','parent_P':meta['sha'],'base_tree':meta['tree']['sha'],'canonical_repository_path':canonical_path,'files':[],'product_count':1095,'BASE_delta_count':70,'validation_count':142,'source_and_validation_paths_changed_by_R':0,'source_only':True,'runtime_status':'not_run','original_TODO_closed':0,'TODO_remaining':29}
for p,repo in [(FINAL/'independent-source-review.json',canonical_path),(zip_path,canonical_path.rsplit('/',1)[0]+'/source-only-review-originals.zip')]:
    d=desc(p);d['local_path']=d.pop('path');d.update(repository_path=repo,mode='100644',type='blob');manifest['files'].append(d)
write(FINAL/'upload-manifest.json',manifest)
print(json.dumps({'source':meta['sha'],'tree':meta['tree']['sha'],'roots':roots,'support_members':len(selected)+1,'support_original_bytes':selection['total_bytes'],'upload_manifest':str(FINAL/'upload-manifest.json'),'files':manifest['files'],'verdict':'accepted_scoped','runtime_status':'not_run','TODO_remaining':29},ensure_ascii=False))

assert (FINAL/'independent-source-review.json').read_bytes()==fixed
