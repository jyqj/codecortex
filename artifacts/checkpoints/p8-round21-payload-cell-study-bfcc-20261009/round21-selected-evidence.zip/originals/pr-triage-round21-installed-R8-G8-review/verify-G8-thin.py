from pathlib import Path
import json,hashlib,re
HERE=Path(__file__).resolve().parent
A=Path('/dev/shm/todo-audit-G8B-cb57d6e3-binding')
S=Path('/dev/shm/todo-audit-G8B-binding-preparation')
def load(p):return json.loads(p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
rpath=Path('/dev/shm/pr-triage-round21-P8B-source-review/final-R8B/independent-source-review.json')
rr=rpath.read_bytes();r=json.loads(rr)
old=load(S/'seed-G6B-registry.json');newpath=A/'generated/scripts/reviewed-source-registry-v15.json';nr=newpath.read_bytes();new=json.loads(nr)
changed={k for k in old.keys()|new.keys() if old.get(k)!=new.get(k)}
assert changed=={'complete_inputs','delta','product_source','review_sha256','review_source'}
assert new['complete_inputs']==r['complete_inputs'] and new['delta']==r['paths']
assert new['validation_inputs']==r['validation_inputs']==old['validation_inputs']
assert new['product_source']==r['source']=='44e6248106335b5f0625e53de38f76d26aeeadcf'
assert new['review_source']=='cb57d6e39f446e68ed5bd5bce26a7a76d1a26e5c' and new['review_sha256']==sha(rr)
og=(S/'seed-G6B-guard.py').read_bytes();gp=A/'generated/scripts/verify_reviewed_source_v15.py';ng=gp.read_bytes()
pins={'PRODUCT':r['source'],'REVIEW':new['review_source'],'REVIEW_PATH':r['review_path'],'REGISTRY_SHA256':sha(nr)}
pattern=rb'(?m)^(PRODUCT|REVIEW|REVIEW_PATH|REGISTRY_SHA256) = "[^"]*"$'
assert re.sub(pattern,b'<PIN>',og)==re.sub(pattern,b'<PIN>',ng)
actual=dict((k.decode(),v.decode()) for k,v in re.findall(rb'(?m)^(PRODUCT|REVIEW|REVIEW_PATH|REGISTRY_SHA256) = "([^"]*)"$',ng))
assert actual==pins
m=load(A/'allowlisted-delta-and-installation-manifest.json')
for f in m['files']:
 b=Path(f['local_path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'] and oid(b)==f['git_blob']
c=load(HERE/'G8-commit.original.json');d=load(HERE/'R8-to-G8-compare.original.json')
assert c['sha']=='4fe927488d5cb7f26bd27c7624745fb1b6ca202b' and c['tree']['sha']==m['expected_G_tree']=='d8891f547c92044fd40b63165d6ef54cb6de8bab'
assert [p['sha']for p in c['parents']]==[new['review_source']]
assert d['ahead_by']==1 and d['behind_by']==0 and d['total_commits']==1 and len(d['files'])==2
assert all(f['status']=='modified' for f in d['files'])
assert {f['filename']:f['sha']for f in d['files']}=={f['repository_path']:f['git_blob']for f in m['files']}
out=dict(schema_version=1,verdict='accepted_for_publication_source_binding_only',actual_G=c['sha'],tree=c['tree']['sha'],sole_R_parent=new['review_source'],source_P=r['source'],counts=dict(product=1095,delta=75,validation=142),exact_registry_changed_fields=sorted(changed),guard_four_pins=pins,guard_algorithm_BASE_FROZEN_and_CI_unchanged=True,all_maps_exact_canonical=True,all_other_Git_paths_modes_unchanged=True,actual_two_leafs={f['filename']:f['sha']for f in d['files']},new_execution_credit=False,original_TODO_remaining=29)
with (HERE/'independent-actual-G8-thin-review.json').open('x') as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(out))
