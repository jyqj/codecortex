#!/usr/bin/env python3
"""Read-only Git-object inventory verification; no checkout/CI claim."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/dev/shm/a217aaae3bde/codecortex')
DATA = Path('/workspace/scratch/a217aaae3bde/combined-scale-cache-candidate')
OUT = Path(__file__).resolve().parent
PRODUCT = '254009277688d64677361a0ca33e5dea73f295ef'
BASE = '29682890c89511dd6f477a6bf48bd969aa1537af'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def oid(kind, raw):
    return hashlib.sha1(kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def read(name):
    return json.loads((DATA / name).read_bytes())

def git(*args, data=None):
    return subprocess.check_output(['git', *args], cwd=ROOT, input=data)

def write(name, value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()
    (OUT / name).write_bytes(raw)
    return {'path': str(OUT / name), 'bytes': len(raw), 'sha256': sha(raw)}

def tree_oid(entries):
    raw = b''
    for e in sorted(entries, key=lambda e: (e['path'] + ('/' if e['type'] == 'tree' else '')).encode()):
        mode = e['mode'].lstrip('0')
        raw += mode.encode() + b' ' + e['path'].encode() + b'\0' + bytes.fromhex(e['sha'])
    return oid('tree', raw)

def verify_recursive(tree):
    assert tree['truncated'] is False
    entries = {x['path']: x for x in tree['tree']}
    assert len(entries) == len(tree['tree'])
    subtrees = {'': tree['sha'], **{p: e['sha'] for p, e in entries.items() if e['type'] == 'tree'}}
    for prefix, expected in subtrees.items():
        children = []
        for p, e in entries.items():
            parent, _, name = p.rpartition('/')
            if parent == prefix:
                children.append(dict(e, path=name))
        assert tree_oid(children) == expected, (prefix, expected)
    return len(subtrees)

def local_entries(ref):
    entries = {}
    for row in git('ls-tree', '-r', '-z', ref).split(b'\0'):
        if not row:
            continue
        meta, path = row.decode().split('\t', 1)
        mode, kind, blob = meta.split()
        entries[path] = dict(mode=mode, type=kind, sha=blob)
    return entries

def main():
    initial = git('rev-parse', 'HEAD').decode().strip()
    overlay = read('prepared-source-overlay.json')
    commit = read('official-product-commit.json')
    root = read('official-product-root-tree.json')
    assert commit['sha'] == PRODUCT
    assert commit['tree']['sha'] == root['sha'] == '4202266e59934dba86e1ea10154392247fff15e7'
    assert [x['sha'] for x in commit['parents']] == ['55902428d49b09bb4a90cee6ccccf985680618bb']
    assert root['truncated'] is False and tree_oid(root['tree']) == root['sha']
    roots = {x['path']: x for x in root['tree']}
    base_roots = {}
    for row in git('ls-tree', '-z', BASE).split(b'\0'):
        if row:
            meta, path = row.decode().split('\t', 1)
            mode, kind, blob = meta.split()
            base_roots[path] = dict(mode=mode, type=kind, sha=blob)
    assert set(roots) == set(base_roots)
    differing_roots = [p for p in roots if any(roots[p][k] != base_roots[p][k] for k in ('mode','type','sha'))]
    assert set(differing_roots) == {'artifacts', 'crates', 'scripts'}
    actual = local_entries(BASE)
    verified_subtrees = {}
    for prefix in ('crates', 'scripts'):
        tree = read(f'official-product-{prefix}-recursive.json')
        assert tree['sha'] == roots[prefix]['sha']
        verified_subtrees[prefix] = verify_recursive(tree)
        actual = {p: e for p, e in actual.items() if not p.startswith(prefix + '/')}
        actual.update({prefix + '/' + e['path']: e for e in tree['tree'] if e['type'] != 'tree'})
    product = {p: e for p, e in actual.items() if p.startswith('crates/') or p in ('Cargo.toml','Cargo.lock')}
    exclusions = {'scripts/verify_reviewed_source_v15.py','scripts/reviewed-source-registry-v15.json','.github/workflows/ci.yml'}
    validation = {p: e for p,e in actual.items() if p.startswith(('scripts/','.github/workflows/','tests/source_integrity/'))
                  and p not in exclusions and not ('__pycache__' in Path(p).parts and p.endswith('.pyc'))}
    assert set(product) == set(overlay['product_inputs'])
    assert set(validation) == set(overlay['validation_inputs'])
    wanted = dict(product, **validation)
    changed = overlay['changes']
    changed_oids = {e['git_blob']: Path(e['source_path']).read_bytes() for e in changed.values()}
    need = sorted(set(e['sha'] for e in wanted.values()) - set(changed_oids))
    response = git('cat-file', '--batch', data=('\n'.join(need) + '\n').encode())
    objects = dict(changed_oids)
    offset = 0
    for expected in need:
        end = response.index(b'\n', offset)
        found, kind, length = response[offset:end].decode().split()
        assert found == expected and kind == 'blob'
        length = int(length); offset = end + 1
        raw = response[offset:offset+length]; offset += length
        assert response[offset:offset+1] == b'\n'; offset += 1
        assert len(raw) == length and oid('blob', raw) == expected
        objects[expected] = raw
    assert offset == len(response)
    complete = {}
    for p, entry in sorted(wanted.items()):
        assert entry['type'] == 'blob' and entry['mode'] in ('100644','100755')
        raw = objects[entry['sha']]
        digest = sha(raw)
        assert oid('blob', raw) == entry['sha']
        assert digest == (overlay['product_inputs'].get(p) or overlay['validation_inputs'][p]), p
        complete[p] = dict(git_blob=entry['sha'], git_mode=entry['mode'], bytes=len(raw), sha256=digest)
    product_map = {p: complete[p]['sha256'] for p in sorted(product)}
    validation_map = {p: complete[p]['sha256'] for p in sorted(validation)}
    canonical = (json.dumps(product_map, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    old = local_entries(BASE)
    product_changes = [p for p in sorted(product) if product[p]['sha'] != old.get(p, {}).get('sha')]
    validation_changes = [p for p in sorted(validation) if validation[p]['sha'] != old.get(p, {}).get('sha')]
    assert len(product) == 1087 and len(validation) == 138
    assert len(product_changes) == 6 and len(validation_changes) == 8
    assert set(product_changes + validation_changes) == set(changed)
    ast_facts = {}
    for p in validation_changes:
        newer = ast.parse(objects[actual[p]['sha']])
        older = ast.parse(git('cat-file','blob',old[p]['sha'])) if p in old else None
        names = lambda t: sorted(n.name for n in ast.walk(t) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')) if t else []
        before, after = names(older), names(newer)
        assert set(before) <= set(after), p
        ast_facts[p] = {'original_test_methods_retained': len(before), 'test_methods_now': len(after), 'added_test_methods': sorted(set(after)-set(before))}
    build_ast = ast.parse(objects[actual['scripts/p8_runtime_build.py']['sha']])
    observer_names = next(ast.literal_eval(n.value) for n in build_ast.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='OBSERVER_FILES' for t in n.targets))
    assert len(observer_names) == len(set(observer_names)) == 9
    observer = {p: complete[p] for p in observer_names}
    assert git('rev-parse','HEAD').decode().strip() == initial
    manifest = write('independent-git-inputs.json', {'source':PRODUCT,'source_tree':root['sha'],'complete_inputs':product_map,'validation_inputs':validation_map,'files':complete,'runtime_observers':observer})
    receipt = {
        'schema_version':1,'verdict':'accepted_scoped_inventory_and_eight_validation_file_binding',
        'source':PRODUCT,'source_tree':root['sha'],'parent':commit['parents'][0]['sha'],
        'verification':'Official complete recursive Git tree objects independently rehashed; every selected blob Git SHA1/size/SHA256 checked from original local Git objects or exact changed source bytes.',
        'not_claimed':['complete candidate checkout','native build or execution','v15 source approval CLI completion','semantic review of the six product Rust files'],
        'product_input_count':len(product),'validation_input_count':len(validation),
        'canonical_product_manifest_sha256':sha(canonical),'tree_objects_rehashed':dict(root=1,**verified_subtrees),
        'root_entries_different_from_296':differing_roots,
        'other_root_entries_mode_type_oid_identical_to_296':True,
        'product_changes':product_changes,'validation_changes':validation_changes,
        'runtime_observers':observer,'tests_ast':ast_facts,
        'input_manifest':manifest,'prepared_source_overlay':{'path':str(DATA/'prepared-source-overlay.json'),'sha256':sha((DATA/'prepared-source-overlay.json').read_bytes())},
        'official_metadata':{n:sha((DATA/n).read_bytes()) for n in ['official-product-commit.json','official-product-root-tree.json','official-product-crates-recursive.json','official-product-scripts-recursive.json']},
        'root_head_before':initial,'root_head_after':initial,'root_index_or_refs_modified':False,
        'unresolved_inventory_blockers':[],'formal_task_completion':False,'done':163,'remaining':29,
    }
    result = write('independent-git-inventory-review.json',receipt)
    print(json.dumps({'receipt':result,'inputs':manifest,'product_manifest_sha256':sha(canonical),'counts':[len(product),len(validation)]},indent=2))

if __name__ == '__main__':
    main()
