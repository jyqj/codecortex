#!/usr/bin/env python3
"""Read-only immutable-source admission preparation; never installs acceptance."""
import hashlib, json, pathlib, subprocess, sys, datetime
ROOT=pathlib.Path('/workspace/scratch/2eaa00d0f93a/p8-staging-engineering-exact-source')
OUT=pathlib.Path(__file__).resolve().parent
SOURCE='8e542e644b06a83fc82d18d9896cf82f5b2d796e'
G4='260f596582f2d82b8d7c707b61a6b8b6a43b069f'
BASE='7354db236c9d9850a75f31672697ae9eab44565e'
R4='9c24adfa6bb8b8114b4dec8c8a344072957956ce'
REVIEW_PATH='artifacts/checkpoints/p8-completion-20261009/independent-source-review.json'
EXCLUDED={'scripts/verify_reviewed_source_v15.py','scripts/reviewed-source-registry-v15.json','.github/workflows/ci.yml'}
FROZEN=['scripts/verify_reviewed_source_v14.py','scripts/reviewed-source-registry-v14.json','tests/source_integrity/test_reviewed_source_v14.py','scripts/v14_historical_context.py','tests/source_integrity/v14_historical_test_adapter.py','tests/source_integrity/test_v14_historical_context.py']
def git(*args,data=None):return subprocess.check_output(['git',*args],cwd=ROOT,input=data,stderr=subprocess.PIPE)
def sha(data):return hashlib.sha256(data).hexdigest()
def write(name,value):
    body=(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode();(OUT/name).write_bytes(body)
    return {'path':str(OUT/name),'sha256':sha(body),'bytes':len(body)}
def entries(ref,roots):
    result={}
    for row in git('ls-tree','-r','-z',ref,'--',*roots).split(b'\0'):
        if not row:continue
        meta,path=row.split(b'\t',1);mode,kind,oid=meta.decode().split()
        assert kind=='blob' and mode in ('100644','100755'),(ref,path,mode,kind)
        result[path.decode()]={'mode':mode,'git_blob':oid}
    return result
def enrich(rows):
    ids=list(dict.fromkeys(v['git_blob'] for v in rows.values()))
    data=git('cat-file','--batch',data=('\n'.join(ids)+'\n').encode());offset=0;bodies={}
    for oid in ids:
        end=data.index(b'\n',offset);got,kind,size=data[offset:end].decode().split();assert got==oid and kind=='blob'
        size=int(size);body=data[end+1:end+1+size];offset=end+size+2
        assert data[offset-1:offset]==b'\n' and len(body)==size
        assert hashlib.sha1(('blob '+str(size)+'\0').encode()+body).hexdigest()==oid
        bodies[oid]=body
    assert offset==len(data)
    return {p:{**v,'bytes':len(bodies[v['git_blob']]),'sha256':sha(bodies[v['git_blob']])} for p,v in rows.items()}
def manifest(rows):return {p:v['sha256'] for p,v in sorted(rows.items())}
def blob(ref,path):return git('show',ref+':'+path)
def validation(ref):
    return enrich({p:v for p,v in entries(ref,['scripts','.github/workflows','tests/source_integrity']).items() if p not in EXCLUDED and not ('__pycache__' in pathlib.Path(p).parts and p.endswith('.pyc'))})
def changed(a,b):return sorted(p for p in set(a)|set(b) if a.get(p)!=b.get(p))
def state():return {'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'status_porcelain':git('status','--porcelain=v1').decode(),'tracked_diff':git('diff','--name-status','HEAD').decode()}
before=state();assert before['head']==SOURCE and before['tracked_diff']==''
roots=['Cargo.toml','Cargo.lock','crates']
source=enrich(entries(SOURCE,roots));baseline=enrich(entries(BASE,roots));g4=enrich(entries(G4,roots))
validation_source=validation(SOURCE);validation_g4=validation(G4)
assert len(source)==1087 and len(validation_source)==137 and len(validation_g4)==136
assert set(baseline)<=set(source)
old_review_raw=blob(R4,REVIEW_PATH);old_review=json.loads(old_review_raw)
assert sha(old_review_raw)=='cac8cdeec96d8454e94e66e7f2ab96d8b9c1c2b6348246a4e05d1d764ed7d78f'
assert manifest(g4)==old_review['complete_inputs'] and manifest(validation_g4)==old_review['validation_inputs']
assert {p:v['mode'] for p,v in g4.items()}==old_review['source_modes']
assert {p:v['mode'] for p,v in validation_g4.items()}==old_review['validation_modes']
source_delta=changed(g4,source);validation_delta=changed(validation_g4,validation_source)
assert source_delta==['crates/cc-db/src/resolution_dependency_store.rs','crates/cc-db/src/symbol_identity_store.rs','crates/cc-db/tests/p2b_resolution_store.rs','crates/cc-index/tests/qname_identity_transaction.rs']
assert validation_delta==['.github/workflows/p8-staging-cache-engineering.yml']
paths={p:{'before_sha256':baseline[p]['sha256'] if p in baseline else None,'sha256':source[p]['sha256']} for p in changed(baseline,source)}
assert set(paths)==set(git('diff','--name-only',BASE,SOURCE,'--',*roots).decode().splitlines())
inherited_pairs={p:v for p,v in paths.items() if old_review['paths'].get(p)==v}
evidence_paths={
 'source_nonauthor':'/dev/shm/p8-staging-cached-independent-pr-audit/audit.json',
 'actual_publication_bridge':'/dev/shm/p8-staging-publication-bridge-pr-audit/audit.json',
 'workflow_nonauthor':'/dev/shm/p8-staging-engineering-workflow-independent-review/review.json',
 'static_test_expectations':'/dev/shm/p8-staging-engineering-test-expectations/expectations.json'}
evidence={k:{'path':p,'sha256':sha(pathlib.Path(p).read_bytes()),'bytes':pathlib.Path(p).stat().st_size} for k,p in evidence_paths.items()}
source_review=json.loads(pathlib.Path(evidence_paths['source_nonauthor']).read_bytes())
publication=json.loads(pathlib.Path(evidence_paths['actual_publication_bridge']).read_bytes())
for p in source_delta:
    assert all(source[p][k]==source_review['scope'][p][k] for k in ('git_blob','bytes','sha256'))
assert publication['actual_commit']==SOURCE and publication['actual_tree']==before['tree']
assert validation_source[validation_delta[0]]['sha256']=='b68a2601e5c6577c54dce435eb2baba05b8588d09dcd35e5af574746be96735a'
for path in FROZEN+['.github/workflows/p7-engineering.yml']:
    assert blob(SOURCE,path)==blob(BASE,path),path
for path in EXCLUDED:
    assert blob(SOURCE,path)==blob(G4,path),path
assert blob(SOURCE,'docs/roadmap/code-index-v2/tasks.json')==blob(G4,'docs/roadmap/code-index-v2/tasks.json')
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'scripts'))
from p7_build_identity import source_snapshot
snapshot=source_snapshot(ROOT)
assert snapshot['inputs']==manifest(source) and snapshot['source_commit']==SOURCE
guard_ast=__import__('ast').parse(blob(SOURCE,'scripts/verify_reviewed_source_v15.py'))
guard_pins={n.targets[0].id:__import__('ast').literal_eval(n.value) for n in guard_ast.body if isinstance(n,__import__('ast').Assign) and isinstance(n.targets[0],__import__('ast').Name) and n.targets[0].id in ('BASE','PRODUCT','REVIEW','REGISTRY_SHA256')}
after=state();assert after==before
reports={}
reports['source_inventory']=write('production-inventory.json',{'source':SOURCE,'source_tree':before['tree'],'base':BASE,'inputs':source,'complete_inputs':manifest(source),'paths':paths,'source_snapshot':snapshot})
reports['validation_inventory']=write('validation-inventory.json',{'source':SOURCE,'input_count':137,'inputs':validation_source,'validation_inputs':manifest(validation_source),'roots':['scripts','.github/workflows','tests/source_integrity'],'existing_exclusions':sorted(EXCLUDED),'added_exclusions':[]})
reports['draft']=write('independent-source-review-Pnext.draft.json',{
 'schema_version':1,'source':SOURCE,'source_tree':before['tree'],'base':BASE,
 'scope':'independently_reviewed_source_and_validation_inputs','verdict':'draft_pending_actual_engineering_and_final_nonauthor_acceptance',
 'independent_reviewers':[], 'draft_prepared_by':'/root/acceptance_audit',
 'unresolved_blockers':['Pending actual 8e engineering controls/build and original 1k/10k/conditional100k diagnostics; no execution acceptance supplied by this draft.','Pending final canonical independent source review and public PRODUCT/REVIEW binding for the actual chosen source; original source/historical proof on final installation remains required.'],
 'paths':paths,'complete_inputs':manifest(source),'complete_input_count':len(source),'changed_source_input_count':len(paths),
 'source_modes':{p:v['mode'] for p,v in source.items()},'validation_inputs':manifest(validation_source),'validation_input_count':len(validation_source),'validation_modes':{p:v['mode'] for p,v in validation_source.items()},
 'inherited_review':{'commit':R4,'path':REVIEW_PATH,'sha256':sha(old_review_raw),'source':old_review['source'],'source_inputs_exactly_unchanged':len(source)-len(source_delta),'source_delta_pairs_exactly_unchanged':len(inherited_pairs),'validation_inputs_exactly_unchanged':136},
 'newly_reviewed_production_paths':source_delta,'newly_reviewed_validation_paths':validation_delta,'review_evidence':evidence,
 'execution_claims':{'local_Cargo_or_product':'not_run','test_count_41':'static_expectation_only','formal_150':'not_completed_or_claimed','TODO_closed':0,'TODO_remaining':29},
 'identity_limit':'No G4/D0/aux results are relabeled. If the eventual PRODUCT is another public commit, regenerate all identities/manifests and verify exact whole-tree/source bridge; this draft is fixed only to actual8e.'})
result={
 'schema':'p8-next-source-admission-preparation-v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'static_inventory_and_review_coverage_prepared_not_final_admission',
 'source_before':before,'source_after':after,'tracked_source_unchanged':True,'original_build_identity_source_snapshot_passed':True,
 'production_inputs':1087,'production_manifest_sha256':snapshot['manifest_sha256'],'BASE_delta_count':len(paths),'prior_delta_count':len(old_review['paths']),'prior_delta_pairs_unchanged':len(inherited_pairs),'new_or_changed_delta_pairs':sorted(set(paths)-set(inherited_pairs)),
 'source_delta_from_G4':source_delta,'source_inputs_unchanged_from_G4':1083,'validation_count':137,'validation_delta_from_G4':validation_delta,'all_136_prior_validation_bytes_and_modes_unchanged':True,
 'frozen_v14_six_and_original_P7_workflow_equal_BASE':True,'tasks_equal_G4':True,'CI_guard_registry_equal_G4':True,'current_guard_pins':guard_pins,
 'existing_guard_does_not_approve_8e':'PRODUCT remains priorP5 and validation set prior136; no guard execution or pin mutation was attempted',
 'next_steps':['Receive actual8e controls with all13 original command argv/exits, exact41 nonignored tests, original raw logs/sourcebeforeafter; fmt and strictclippy must pass.','Validate immutable release build Cargo/copy/source/driver chain and original two small diagnostics; conditional100k is auxiliary only and keeps its actual terminal outcome.','Assemble final non-author source review from the fixed1087 source/BASE pairs and137 validation inputs; no new exclusions; retain exact source and reviewer authorship scope.','If chosen final PRODUCT differs from8e, re-enumerate actual publiccommit/tree and preserve explicit byte bridge. Publish canonical review in its own immutable commit, then update only permitted pins/registry binding.','Run complete unchanged source_integrity suite, selectedv15 source proof, historical integrations and normal finalCI on finalinstalledsource. Keep prior failures/originalidentities; no TODO auto-closure.'],
 'review_evidence':evidence,'reports':reports,'heldout_bodies_read':False,'local_Cargo_or_product':'not_run','remote_write':False,'TODO_closed':0,'TODO_remaining':29}
write('preparation-review.json',result)
print(json.dumps({k:result[k] for k in ['verdict','source_before','production_inputs','production_manifest_sha256','BASE_delta_count','prior_delta_pairs_unchanged','new_or_changed_delta_pairs','validation_count','TODO_remaining']},indent=2))
