from pathlib import Path
import json,hashlib,datetime,collections
ROOT=Path('/workspace/scratch/bfccb8494ba0');OUT=Path(__file__).resolve().parent
D=ROOT/'round42-new45-build-original-intake'; A=D/'validation-attempt01';B=D/'original-build'
HEAD='f97c5068d056969705e8387ba1f37d83847f5bee';TREE='39a053ae49b486764751a570d164e7cd41d7ff29'
def load(p):return json.loads(p.read_text())
def ident(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
receipt=load(D/'original-validator-execution.json'); result=load(A/'original-validate-build-return.json')
assert receipt['exit_code']==0 and receipt['original_validate_build_calls_requested']==1
assert receipt['source']==HEAD and receipt['run']==38026411200 and receipt['attempt']==1
assert ident(D/'original-validator.stdout')['sha256']==receipt['stdout']['sha256']
assert ident(D/'original-validator.stderr')['bytes']==receipt['stderr']['bytes']==0
assert (D/'original-validator.stdout').read_bytes()==(A/'original-validate-build-return.json').read_bytes()
before=load(A/'inputs-before.json');after=load(A/'inputs-after.json');assert before==after
assert before['head']==HEAD and before['tree']==TREE and len(before['source'])==1107 and len(before['build'])==8
original_before=load(B/'native-build/source-before.json');original_after=load(B/'native-build/source-after.json')
assert original_before==original_after and original_before['input_count']==len(original_before['inputs'])==1096
assert original_before['source_commit']==HEAD and original_before['source_tree']==TREE
assert all(before['source'][k]['sha256']==v for k,v in original_before['inputs'].items())
outer,built=result['outer'],result['built']
assert outer['source_commit']==built['source_commit']==HEAD
assert outer['source_manifest_sha256']==built['source_manifest_sha256']==original_before['manifest_sha256']
assert outer['study']=={'protocol':'p8-profile-task-descriptive-v1','run_id':'38026411200','run_attempt':1}
assert outer['status']==built['status']=='passed' and outer['passed'] is True and built['exit_code']==0
assert len(outer['driver_source']['inputs'])==11
assert all(before['source'][k]['sha256']==v for k,v in outer['driver_source']['inputs'].items())
registry=load(B/'task-registry.json')
assert ident(B/'task-registry.json')['sha256']==outer['registration_sha256']
assert registry['driver_source']==outer['driver_source'] and registry['source_commit']==HEAD
assert registry['cell_count']==45 and registry['record_count']==85 and registry['repetitions']==1
plans=registry['plans'];assert len(plans)==45
keys=[(p['profile_study']['mutation_profile'],p['files'][0],p['profile_study']['fanout']) for p in plans]
assert len(set(keys))==45
profiles={'no_op','body','api','config','batch_1','batch_10','batch_100','batch_1000'}
actual_profiles={k[0] for k in keys if k[0]!='fanout'}
# The original registry spells profiles as frozen by its producer; retain exact names below.
assert len(actual_profiles)==8 and sum(k[0]=='fanout' for k in keys)==5
assert all(p['profile_study']['run_id']=='38026411200' and p['profile_study']['run_attempt']==1 for p in plans)
for p in plans:
 assert p['stage_scope']=='profile_task_descriptive_v1' and p['capacity_profile']=='scale_capacity_v1'
 assert p['profile']=='release' and p['repetitions']==1 and p['shard']=={'index':0,'count':1}
 assert p['deadline_ms']==18000000 and p['max_output_bytes']==536870912 and p['seed']==12648430
 assert p['dirty_budget']==200 and p['max_resume_builds']==1024 and p['fanouts']==[1,4,16,64,128]
 assert p['batch_sizes']==[1,10,100,1000]
for profile in actual_profiles:assert {k[1] for k in keys if k[0]==profile}=={1000,5000,10000,50000,100000}
assert {(k[1],k[2]) for k in keys if k[0]=='fanout'}=={(1000,x) for x in [1,4,16,64,128]}
cargo=built['cargo_artifact'];assert cargo['reason']=='compiler-artifact' and cargo['fresh'] is False
assert cargo['target']['name']=='p8-scale' and cargo['target']['kind']==['bin'] and cargo['features']==['default']
assert cargo['profile']['debug_assertions'] is False and cargo['profile']['test'] is False and cargo['profile']['opt_level']=='3'
assert built['command'][:8]==['cargo','build','--release','--locked','-p','cc-eval','--bin','p8-scale']
hash_calls=load(A/'native-hash-subprocess-original.json');assert len(hash_calls)==1 and hash_calls[0]['returncode']==0
assert hash_calls[0]['argv'][1]=='--hash-file'
assert (A/'native-hash-stdout.original').read_text().strip()==outer['binary_blake3']==built['binary_blake3']
assert ident(A/'native-hash-stdout.original')['sha256']==hash_calls[0]['stdout']['sha256']
assert ident(A/'native-hash-stderr.original')['bytes']==0
transport=load(D/'transport-original.json')
assert transport['member_read_and_crc_passes']==1 and len(transport['members'])==8
assert transport['whole_zip']['sha256']=='65ae643b212d826533aa74a55c69e875ea964751966c5487434adbdfb57ac3b9'
assert transport['whole_zip']['bytes']==9250795
assert built['binary_sha256']==outer['binary_sha256']==before['build']['native-build/p8-scale']['sha256']
assert built['binary_bytes']==before['build']['native-build/p8-scale']['bytes']==28344792
assert registry['binary_blake3']==outer['binary_blake3'] and registry['binary_sha256']==outer['binary_sha256']
paths=[D/'original-validator-execution.json',D/'original-validator.stdout',D/'original-validator.stderr',D/'validate-original-build-once.py',D/'transport-original.json',A/'original-validate-build-return.json',A/'native-hash-subprocess-original.json',A/'native-hash-stdout.original',A/'native-hash-stderr.original',A/'inputs-before.json',A/'inputs-after.json',B/'task-registry.json',B/'native-build/source-before.json',B/'native-build/source-after.json']
report={
 'schema_version':1,'reviewer':'pr_triage','formal_round':42,'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'conclusion':'accepted_scoped_original_build_tuple_and_release_plan_gate; zero accepted measurement cells',
 'source':HEAD,'source_tree':TREE,'run_id':38026411200,'attempt':1,'artifact_id':11659139900,
 'review_method':'Read-only receipt/original small JSON and stdio comparison. No ZIP open/CRC, ELF bytes read, validator import/call, product or measurement execution by this reviewer.',
 'original_validator':receipt,'receiver_owner':'execution_recon','sole_call_wrapper_reviewed':ident(D/'validate-original-build-once.py'),
 'original_log_peer':{'actual_git_blob':'1d00bf6c097258ac3553fc86cadbd38a6838e20d','scope':'Direct G2 checkout; producer job success; actual release control1passed21filtered; pure45plans; uploadidentity'},
 'transport_receipt':ident(D/'transport-original.json'),'whole_zip_identity_reused':transport['whole_zip'],
 'validated_tuple':{'source_manifest_sha256':outer['source_manifest_sha256'],'registration_sha256':outer['registration_sha256'],'binary_bytes':built['binary_bytes'],'binary_sha256':outer['binary_sha256'],'binary_blake3':outer['binary_blake3'],'native_build_receipt_sha256':outer['native_build_receipt_sha256'],'observer_manifest_sha256':outer['driver_source']['manifest_sha256']},
 'producer':cargo,'build_command':built['command'],
 'source_preservation':{'original_product_inputs':1096,'observer_inputs':11,'receiver_selected_inputs':1107,'build_files':8,'original_before_after_equal':True,'receiver_before_after_equal':True,'head_tree_index_unchanged':True,'observer_only_docs_not_added_to_canonical_validation_domain':True},
 'registered_population':{'cells':45,'records':85,'repetitions':1,'mutation_profiles':sorted(actual_profiles),'mutation_cells':40,'fanout_cells':5,'keys':keys,'cold_curve_selection':registry['cold_curve_selection'],'statistics':registry['statistics'],'release_certification':registry['release_certification']},
 'limits':{'native_ms':18000000,'max_output_bytes':536870912,'dirty_budget':200,'max_resume_builds':1024,'fanout_dirty_resume':[8,128]},
 'native_hash_original_call':hash_calls[0],
 'accepted_cells':0,'accepted_measurement_records':0,'task_credit_delta':0,
 'frozen_prior_pending_log_review_not_rewritten':True,
 'next_boundary':'Reuse this original accepted tuple for later original task shard receipts under the frozen contract; no revalidation of build or prefix-as-measurement acceptance. All45 whole shards, all85 records and eventual original aggregate required before task-study conclusion.',
 'inputs':[ident(p) for p in paths],
}
(OUT/'independent-original-build-tuple-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':report['conclusion'],'report':ident(OUT/'independent-original-build-tuple-review.json')}))
