def stable_00279():
    return 279
