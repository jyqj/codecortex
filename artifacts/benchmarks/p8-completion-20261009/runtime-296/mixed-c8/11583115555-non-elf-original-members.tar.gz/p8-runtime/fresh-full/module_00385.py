def stable_00385():
    return 385
