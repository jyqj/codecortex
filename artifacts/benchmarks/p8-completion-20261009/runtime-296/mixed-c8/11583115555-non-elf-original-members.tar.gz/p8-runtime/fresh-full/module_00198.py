def stable_00198():
    return 198
