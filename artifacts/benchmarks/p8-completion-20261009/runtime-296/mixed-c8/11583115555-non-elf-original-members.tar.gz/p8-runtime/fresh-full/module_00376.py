def stable_00376():
    return 376
