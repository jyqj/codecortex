def stable_00080():
    return 80
