import hashlib,json,zipfile
from pathlib import Path

ROOT=Path('/workspace/scratch/bfccb8494ba0')
HERE=Path(__file__).resolve().parent
def dump(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def ident(p,b): return {'local_path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
r=json.loads((HERE/'independent-first12-original-receipt-review.json').read_text())
short={k:v for k,v in r.items() if k not in ('cells','input_identities')}
short['cells']=[{'slot':c['slot'],'artifact_id':c['artifact']['id'],'artifact_name':c['artifact']['name'],
                 'artifact_original':c['whole_zip_original_identity'],'producer_job':c['producer']['id'],
                 'producer_conclusion':c['producer']['conclusion'],'producer_completed_at':c['producer']['completed_at'],
                 'original_return':c['original_return'],'original_validator_exit':c['validator_execution']['exit_code'],
                 'native_exit':c['native']['exit_code'],'native_worker_exit':c['native']['worker_exit_code'],
                 'native_wall_ms':c['native']['wall_ms'],'records':2,'roles':['setup','mutation'],
                 'selected_cold_curve_record':c['slot'][0]=='no_op',
                 'incremental_builds':c['stage_finished'][0]['incremental_builds'],
                 'first_incremental_actually_incomplete':c['first_incremental_actually_incomplete'],
                 'final_incremental_complete':c['stage_finished'][0]['complete'],
                 'independent_full_complete':c['stage_finished'][0]['full_complete'],
                 'original_equal_parities':2,'equal_tables_per_parity':15,
                 'cpu_model':c['environment']['cpu_model'],'cpu_count':c['environment']['cpu_count'],
                 'source_build_observer_bindings_match':True} for c in sorted(r['cells'],key=lambda c:(c['slot'][0],c['slot'][1]))]
short['source_of_summary_limitation']={'source_path':'crates/cc-eval/src/benchmark/p8_scale.rs','source':r['source'],
 'lines':'1222-1243 fanout inserts first_build_incomplete; 1272 summary counts only true fields. Mutation raw resolution_freshness remains authoritative for initial-incomplete/resume observations.'}
short['local_stdout_custody_observation']['receiver_selection_has_zero_stdout']=True
short['local_stdout_custody_observation']['receiver_selection_git_blob']='b485b969c30b44d27f856ae423a697adf53a0cf1'
dump(HERE/'independent-first12-review.json',short)
files=[HERE/n for n in ('read-existing-receipts.py','reader.stdout','reader.stderr','reader-execution.json',
 'producer-jobs.official-original.json','selected-original-parity-and-stage-events.json',
 'independent-first12-original-receipt-review.json','independent-first12-review.json',
 'api-1000-original-stdout-recovered-from-same-digest-return.json','stdout-custody-observation.json','seal-peer.py')]
files+=sorted((HERE/'reader-attempt01').iterdir())
files += [ROOT/'R42-first12-intake'/n for n in ('terminal.json','api-1000-0/original-validator-execution.json',
 'api-1000-0/original-validate-shard-return.json','sealed/archive-selection.json')]
files += [ROOT/'round42-0530-PR201-main-observation/main-jobs.official-original.json']
members=[]
zp=HERE/'complete-independent-first12-peer-support.zip'
with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:
  b=p.read_bytes(); name=str(p.relative_to(ROOT)); row=ident(p,b)|{'archive_path':name};members.append(row);z.writestr(name,b)
 manifest={'schema':'new-peer-selected-members-v1','files':members,'original_archives_reopened':0,
  'whole_original_zip_custody':'External root custody; not nested here. Original receiver support6bee9e49… is independently referenced, not reopened.',
  'original_validator_or_elf_executed_by_peer':False}
 mb=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();z.writestr('MANIFEST.json',mb)
dump(HERE/'archive-selection.json',manifest|{'support':ident(zp,zp.read_bytes()),'support_members':len(members)+1,
 'manifest_member':{'bytes':len(mb),'sha256':hashlib.sha256(mb).hexdigest()}})
prefix='artifacts/checkpoints/p8-round42-complete-bfcc-20261010/new45/first12-peer/'
upload={'repository':'jyqj/codecortex','files':[ident(p,p.read_bytes())|{'repository_path':prefix+p.name} for p in
 (HERE/'independent-first12-review.json',zp,HERE/'archive-selection.json')]}
dump(HERE/'upload-manifest.pending.json',upload)
print(json.dumps(upload))
