def stable_00271():
    return 271
