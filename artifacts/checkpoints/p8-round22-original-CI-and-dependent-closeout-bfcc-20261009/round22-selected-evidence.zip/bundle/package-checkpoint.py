#!/usr/bin/env python3
"""Seal only explicitly selected existing evidence after root's real round22 closeout."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile
import zlib

B=Path(__file__).resolve().parent
OUT=B/'sealed-attempt01'
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
def facts(p):
    p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode),str(p)
    b=p.read_bytes()
    return {'bytes':len(b),'sha256':sha(b),'git_blob':blob(b),'mode':format(stat.S_IMODE(s.st_mode),'04o'),'source_mtime_ns':s.st_mtime_ns},b

def main():
    cfg=read(B/'package-inputs.final.json')
    assert cfg['stage']=='ready_to_seal_after_root_actual_closeout'
    closepath=Path(cfg['formal_closeout_path']);closebytes=closepath.read_bytes();close= json.loads(closebytes)
    assert close['round']==22 and close['schema']=='p8-multi-agent-round-closeout-v1' and close['closed_at_utc']=='2026-10-09 17:21:17 UTC'
    assert close['next_round']==23 and close['next_round_status']=='active'
    assert close['original_task_accounting']['newly_completed_in_round']==0 and close['original_task_accounting']['remaining_after_round']==29
    assert not OUT.exists(),'Never overwrite a frozen or failed attempt'
    OUT.mkdir()
    members={};sources={};dedup=[];selected=[]
    def add(path,origin,expected=None):
        p=Path(path);assert p.is_absolute() and '..' not in p.parts and p.suffix.lower()!='.zip'
        name='originals/'+p.relative_to('/dev/shm').as_posix();f,b=facts(p)
        if expected:
            assert f['bytes']==expected['bytes'] and f['sha256']==expected['sha256'],str(p)
            expectedblob=expected.get('git_blob',expected.get('expected_git_blob'))
            if expectedblob:assert f['git_blob']==expectedblob,str(p)
            mode=expected.get('posix_mode',expected.get('mode'))
            if mode:assert int(f['mode'],8)==int(mode,8)&0o7777,str(p)
        if name in members:
            assert members[name]['facts']==f and members[name]['data']==b
            members[name]['origins'].append(origin);dedup.append({'member':name,'origin':origin,'sha256':f['sha256']})
        else:members[name]={'facts':f,'data':b,'source_path':str(p),'origins':[origin]}
        sources[str(p)]=f
        return name
    for item in cfg['selections']:
        p=Path(item['path']);f,b=facts(p)
        assert f['bytes']==item['bytes'] and f['sha256']==item['sha256']
        obj=json.loads(b);rows=obj.get('entries',obj.get('files'))
        assert isinstance(rows,list) and len(rows)==item['expected_entry_count']
        if 'file_count' in obj:assert obj['file_count']==len(rows)
        if 'count' in obj:assert obj['count']==len(rows)
        if 'total_bytes' in obj:assert obj['total_bytes']==sum(x['bytes'] for x in rows)
        paths=[]
        for i,row in enumerate(rows):
            path=row.get('source',row.get('path',row.get('local_path')));assert path
            paths.append(add(path,{'selection':str(p),'label':item['label'],'entry_index':i},row))
        selectionmember=add(p,{'kind':'original_selection','label':item['label']},item)
        selected.append({**item,'member':selectionmember,'declared_members':paths,'complete':True})
    rootmembers=[add(p,{'kind':'explicit_root_original'}) for p in cfg['root_original_files']]
    additional=[add(p,{'kind':'additional_original_peer'}) for p in cfg['additional_original_files']]
    formal=add(closepath,{'kind':'root_actual_formal_closeout'})
    (OUT/'round22-formal-closeout.json').write_bytes(closebytes)
    summary={'schema_version':1,'artifact_scope':'Complete selected evidence only, not complete original studyZIP/ELF/RPCcorpora',
        'round':22,'status':'closed','closed_at_utc':close['closed_at_utc'],'root_formal_closeout':close,
        'observed_context':{'PR189_head':'10ec828beb94200ec679302c45115760ebd55ee9','PR189_actual_CI_checkout':'0dd17383a1e8bc526c5c4fb1a5d255c6fcb9bebf',
            'PR189_main_CI':'success at original16:54:51UTC; no latestsource relabel',
            'PR193_G8_source':'4fe927488d5cb7f26bd27c7624745fb1b6ca202b','PR193_CI_observation':'17:20 retained snapshot queued; no terminal inferred',
            'cold_run':37954851017,'cold_source':'044c008c9459cfa61e7701db2eb868342c508a39','cold_scope':'firstfive originals have confirmed independentGit custody; fullN30 not complete',
            'G8_run':37962416564,'G8_scope':'originalbuild/source custody accepted and separately published; no fullscaleacceptance',
            'task_update_inputs':'ten originaltask pendingfield inputs only; no status changes'},
        'observation_policy':'Original times/nulls/pending values remain unchanged. Earlier queued observations are not overwritten by later facts. No originalcohorts are pooled.',
        'retained_selections':selected,'root_original_members':rootmembers,'additional_original_members':additional,'formal_closeout_member':formal,
        'unique_original_files':len(members),'deduplicated_references':dedup,'already_durable_not_nested':cfg['already_durable_not_nested'],
        'known_checkpoint_parent_only_not_a_publish_lease':cfg['known_checkpoint_parent_only_not_a_lease'],
        'product_or_validator_tests_or_measurements_run':False,'remote_mutations':False}
    write(OUT/'round22-summary.json',summary)
    readme='''# Round22 selected evidence checkpoint

This package preserves the explicitly selected existing PR189 engineering CI, source/retarget audit, pending original ten-task closeout inputs, PR193/G8 CI observations, open-PR coordination, independent study follow-up/custody evidence, root publication/comment receipts and the exact root-issued round22 closeout. The separate formal-closeout leaf retains its actual date and accounting. This ZIP does not execute or certify a new workload and does not apply the pending task updates.

PR189 head10ec's main CI succeeded on actual merge checkout0dd17383, whose whole repository tree equals10ec. Its cold study remains source044/run37954851017. The firstfive cold original archives have existing independent Git custody; a full N30 population is not inferred. The separate G8 study remains source4fe927/run37962416564. Its verified originalbuild has already been published at0a9c96 and is linked, not nested again. The retained PR193 ordinary-CI snapshots remain at their original queued times.

Eight downstream task components are already accepted at their declared sources, including the independent G2 four-C DB acquisition component. The pending10-task inputs preserve original dependencies and every unknown actualcloseout field. They do not conflate004/005/006 studies, migrate old measurements toG8, delete oldfailure records or impose a new all-component latesthead rerun requirement. Fullscale acceptance and original hard dependencies still govern any real future state update.

The member index records every byte/hash/Gitblob/POSIXmode/CRC and source-selection reference. All selectedentries and each originalselection are included; deterministic samepath/samebytes duplicates share one member with every provenance reference retained. Sources are rehashed after sealing. No existingZIP/ELF/fullRPC corpus is nested, and already published checkpoint/build archives remain exactimmutable locators. Root must fresh-check the checkpoint ref before publishing.
'''
    (OUT/'README.md').write_text(readme)
    def extra(name,b):
        assert name not in members
        members[name]={'facts':{'bytes':len(b),'sha256':sha(b),'git_blob':blob(b),'mode':'0644','source_mtime_ns':None},'data':b,'source_path':None,'origins':[{'kind':'packaging_context_only'}]}
    for n in ['README.md','round22-summary.json']:extra('bundle/'+n,(OUT/n).read_bytes())
    for n in ['package-checkpoint.py','run-package-once.py','package-inputs.final.json']:extra('bundle/'+n,(B/n).read_bytes())
    zpath=OUT/'round22-selected-evidence.zip'
    with zipfile.ZipFile(zpath,'x',zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as z:
        for name,v in sorted(members.items()):
            p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts and '\\' not in name
            i=zipfile.ZipInfo(name,(2026,10,9,0,0,0));i.create_system=3;i.external_attr=(stat.S_IFREG|int(v['facts']['mode'],8))<<16;i.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(i,v['data'],compresslevel=9)
    rows=[]
    with zipfile.ZipFile(zpath) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members) and set(z.namelist())==set(members)
        for i in z.infolist():
            v=members[i.filename];f=v['facts'];b=z.read(i)
            assert len(b)==f['bytes'] and sha(b)==f['sha256'] and blob(b)==f['git_blob']
            assert i.CRC==zlib.crc32(b)&0xffffffff and stat.S_IMODE(i.external_attr>>16)==int(f['mode'],8)
            rows.append({'member':i.filename,**f,'crc32':format(i.CRC,'08x'),'compressed_bytes':i.compress_size,'source_path':v['source_path'],'origins':v['origins']})
    for p,old in sources.items():assert facts(p)[0]==old,'Originalsource changed: '+p
    zf,_=facts(zpath)
    idx={'schema_version':1,'archive':{'local_path':str(zpath),**zf},'member_count':len(rows),'uncompressed_bytes':sum(r['bytes'] for r in rows),
        'selected_original_file_count':len(sources),'selection_count':len(selected),'root_original_file_count':len(rootmembers),
        'deduplicated_references':dedup,'all_selected_entries_present':True,'CRC_SHA_gitblob_modes_verified':True,'all_original_sources_unchanged':True,'nested_original_ZIPs':0,'members':rows}
    write(OUT/'round22-member-index.json',idx)
    print(json.dumps({k:v for k,v in idx.items() if k!='members'},sort_keys=True))

if __name__=='__main__':main()
