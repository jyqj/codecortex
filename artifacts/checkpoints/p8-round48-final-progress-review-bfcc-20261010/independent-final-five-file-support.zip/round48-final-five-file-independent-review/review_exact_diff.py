#!/usr/bin/env python3
"""Read-only independent final progress-diff audit; does not import/run the generator."""
import collections, datetime, hashlib, json, pathlib, re, subprocess

ROOT = pathlib.Path('/workspace/scratch/bfccb8494ba0')
OUT = ROOT / 'round48-final-five-file-independent-review'
BEFORE = ROOT / 'round44-nine-application-main-0da9-view'
AFTER = ROOT / 'round48-twelve-task-final-candidate'
EXEC = ROOT / 'round48-twelve-task-final-execution'
checks = []
def check(name, condition):
    checks.append({'name': name, 'passed': bool(condition)})
    if not condition:
        raise AssertionError(name)
def read(p): return json.loads(pathlib.Path(p).read_bytes())
def sha(b): return hashlib.sha256(b).hexdigest()
def identity(p):
    b = pathlib.Path(p).read_bytes()
    return {'bytes': len(b), 'sha256': sha(b), 'git_blob': hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def digest(v): return sha(json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode())
def fragments(p):
    text = p.read_text()
    i = re.search(r'"tasks"\s*:\s*\[', text).end()
    dec = json.JSONDecoder(); rows = {}
    while True:
        while text[i].isspace() or text[i] == ',': i += 1
        if text[i] == ']': break
        obj, end = dec.raw_decode(text, i)
        rows[obj['id']] = text[i:end]
        i = end
    return rows

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
path = pathlib.Path('docs/roadmap/code-index-v2/tasks.json')
b = read(BEFORE/path); a = read(AFTER/path)
approved = read(EXEC/'approved-input.actual.json')
baseline = read(ROOT/'round46-twelve-task-application-preparation/original-192-task-preservation-baseline.json')
manifest = read(EXEC/'candidate-files.manifest.json')
uploaded = read(EXEC/'five-source-upload-manifest.actual.json')
authority = read(ROOT/'round48-final-acceptance/ROOT-CLOSEOUT-DECISION.json')
pub = read(ROOT/'round48-final-acceptance/actual-readback.json')
targets = [f'P8-{n:03}' for n in [6,7,8,9,10,11,12,13,16,17,18,19]]
updates = {u['task_id']: u for u in approved['updates']}
old = {t['id']:t for t in b['tasks']}; new = {t['id']:t for t in a['tasks']}
check('exact_target_12', list(updates)==targets)
check('original_192_order', list(old)==list(new)==baseline['original_task_order'] and len(old)==192)
allow = {'status','evidence','implementation_notes'}
raw_b = fragments(BEFORE/path); raw_a = fragments(AFTER/path)
rows = []
for key in old:
    ob,na=old[key],new[key]
    definition_b={k:v for k,v in ob.items() if k not in allow}
    definition_a={k:v for k,v in na.items() if k not in allow}
    check(key+'/definition', digest(definition_b)==digest(definition_a)==baseline['all192_immutable_definition_sha256'][key])
    if key not in targets:
        check(key+'/entire_record', ob==na and digest(na)==baseline['other180_entire_record_sha256'][key])
        check(key+'/raw_bytes', raw_b[key]==raw_a[key])
    else:
        u=updates[key]
        changed=[k for k in ob if ob[k]!=na[k]]
        check(key+'/only_three_fields', set(changed)==allow and set(ob)==set(na))
        check(key+'/status', ob['status']=='in_progress' and na['status']=='done')
        check(key+'/evidence_append', na['evidence']==ob['evidence']+[u['append_evidence']])
        check(key+'/notes_append', na['implementation_notes']==ob['implementation_notes']+'\n'+u['append_implementation_notes'])
        check(key+'/deps', all(new[d]['status']=='done' for d in na['depends_on']))
        ev=na['evidence'][-1]
        check(key+'/evidence_identity', ev['date']=='2026-10-10' and ev['original_task_id']==key and ev['target_sha']=='f97c5068d056969705e8387ba1f37d83847f5bee')
        check(key+'/root_decision', ev['root_formal_acceptance']==approved['actual_root_application_authorization'])
        rows.append({'id':key,'old_status':ob['status'],'new_status':na['status'],'changed_fields':changed,'appended_evidence_sha256':digest(ev),'old_evidence_count':len(ob['evidence']),'hard_dependencies':na['depends_on']})
root_changed=[k for k in b if k!='tasks' and b[k]!=a[k]]
check('root_fields_exact', set(root_changed)=={'next_task','last_implementation_date'} and set(a)==set(b))
check('navigation', a['next_task']=='P8-020' and a['current_phase']==b['current_phase']=='P8' and a['last_implementation_date']=='2026-10-10')
check('next_hard_deps', all(new[d]['status']=='done' for d in new[a['next_task']]['depends_on']))
states=dict(collections.Counter(t['status'] for t in a['tasks']))
check('candidate_counts', states=={'done':176,'blocked':1,'in_progress':3,'todo':12})
check('actual_done_delta', sum(t['status']=='done' for t in b['tasks'])==164 and sum(t['status']=='done' for t in a['tasks'])==176)
check('root_actual_authority', approved['apply_now'] is True and authority['apply_now'] is True and pub['exact_paths_modes_types_oids'] is True and pub['commit']==approved['actual_evidence_commit'])
for k,f in [('actual_root_application_authorization','ROOT-CLOSEOUT-DECISION.json')]:
    check('actual_authority_bytes', all(identity(ROOT/'round48-final-acceptance'/f)[n]==approved[k][n] for n in ['bytes','sha256','git_blob']))
s45=new['P8-006']['evidence'][-1]['source_evidence']['S45']
check('S45_current', s45['current_cells']==45 and s45['current_records']==85 and s45['registered_population']=={'cells':45,'records':85,'setup':40,'mutation':40,'fanout':5,'cold_subset':5})
check('S45_fixed_identity', s45['source']=='f97c5068d056969705e8387ba1f37d83847f5bee' and s45['run']==38026411200 and s45['attempt']==1 and s45['profile']=='profile_task_descriptive_v1')
check('S45_recovery_not_Actions_relabel', s45['original_Actions_failure_review_git']=='e6ab7248a27e731171f0d741499486c59ea11bb5' and s45['full45_recovery_peer_git']=='d9b9bb0b332e14793405c8848a2ab1eac1c60835' and s45['final_aggregate']['git_blob']=='ca75e2ec7f81603b6f587cb6ae25c7ccc43f5656')
check('S45_published_custody', all(identity(ROOT/'round48-final-acceptance/complete-45-raw-custody.published.json')[k]==s45['complete45_all_raw_custody'][k] for k in ['bytes','sha256','git_blob']) and s45['complete45_all_raw_custody']['commit']==pub['commit'])
paths_b=sorted(str(p.relative_to(BEFORE)) for p in BEFORE.rglob('*') if p.is_file())
paths_a=sorted(str(p.relative_to(AFTER)) for p in AFTER.rglob('*') if p.is_file())
check('seven_projection_inputs', paths_b==paths_a and len(paths_a)==7)
changed=[p for p in paths_a if (BEFORE/p).read_bytes()!=(AFTER/p).read_bytes()]
declared=[r['repository_path'] for r in manifest['files']]
check('exact_five_files', set(changed)==set(declared) and len(changed)==5)
files=[]
for r in manifest['files']:
    p=r['repository_path'];bi=identity(BEFORE/p);ai=identity(AFTER/p)
    check(p+'/before_manifest', bi==r['before'])
    check(p+'/after_manifest', all(ai[k]==r[k] for k in ai))
    ur=next(x for x in uploaded['files'] if x['repository_path']==p)
    check(p+'/actual_server_OID', ur['actual_created'] and ur['actual_server_oid']==ai['git_blob']==ur['response']['structuredContent']['sha'])
    check(p+'/only_regular_doc', r['mode']=='100644' and r['change']=='M' and (p.endswith('.md') or p.endswith('/tasks.json')))
    files.append({'path':p,'mode':r['mode'],'before':bi,'after':ai,'server_oid':ur['actual_server_oid']})
for p in ['scripts/code_index_plan.py','docs/roadmap/code-index-v2/06-VALIDATION.md']:
    check(p+'/unchanged', (BEFORE/p).read_bytes()==(AFTER/p).read_bytes())
for p in ['README.md','docs/roadmap/code-index-v2/README.md','docs/roadmap/code-index-v2/08-HANDOFF.md']:
    ob=(BEFORE/p).read_text();na=(AFTER/p).read_text()
    pat=r'(?s)(<!-- code-index-progress:start -->).*?(<!-- code-index-progress:end -->)'
    check(p+'/only_generated_block', re.sub(pat,r'\1\2',ob)==re.sub(pat,r'\1\2',na))
    check(p+'/new_counts_and_hash', '176 done / 3 in_progress / 12 todo / 1 blocked' in na and identity(AFTER/path)['sha256'] in na)
todo_path='docs/roadmap/code-index-v2/05-TODO.md'
def sections(text):
    pieces=re.split(r'(?m)^### \[[ x]\] (P\d+-\d+)｜',text)
    return {pieces[i]:pieces[i+1].split('\n## ',1)[0] for i in range(1,len(pieces),2)}
tb=sections((BEFORE/todo_path).read_text());ta=sections((AFTER/todo_path).read_text())
check('TODO_exact192_sections', list(tb)==list(ta)==list(old))
for key in old:
    if key not in targets: check(key+'/TODO_section_unchanged', tb[key]==ta[key])
    else:
        check(key+'/TODO_evidence_exact', '证据：'+json.dumps(new[key]['evidence'],ensure_ascii=False) in ta[key])
        check(key+'/TODO_notes_exact', '实施备注：'+new[key]['implementation_notes'] in ta[key])
patch=(EXEC/'source.patch').read_text()
check('patch_exactfive', re.findall(r'(?m)^\+\+\+ b/(.+)$',patch)==declared)
receipts=[]
for name,argv in [('write',['python3','scripts/code_index_plan.py','--write']),('check',['python3','scripts/code_index_plan.py'])]:
    rec=read(EXEC/(name+'.execution.json'));stdout=read(EXEC/(name+'.stdout'))
    check(name+'/actual_original_execution', rec['argv']==argv and rec['actual_exit']==0 and rec['cwd']==str(AFTER) and rec['started_at_utc']<rec['ended_at_utc'])
    check(name+'/original_stdout_stderr', stdout['status']=='passed' and stdout['task_count']==192 and stdout['states']==states and stdout['views']==4 and stdout['task_sha256']==identity(AFTER/path)['sha256'] and (EXEC/(name+'.stderr')).read_bytes()==b'')
    receipts.append({'name':name,**rec,'stdout':identity(EXEC/(name+'.stdout')),'stderr':identity(EXEC/(name+'.stderr'))})
proc=subprocess.run(['git','-C',str(ROOT/'round42-new45-build-original-intake/source-exact-G2'),'ls-tree','-r','f97c5068d056969705e8387ba1f37d83847f5bee','.github/workflows'],text=True,capture_output=True,env={'PATH':'/usr/bin:/bin','GIT_NO_LAZY_FETCH':'1'})
check('workflow_metadata_readonly', proc.returncode==0 and proc.stderr=='')
workflows=[{'mode':m[0],'type':m[1],'git_blob':m[2],'path':m[3]} for line in proc.stdout.splitlines() if (m:=line.split())]
check('workflow_preserved_by_exact_doc_delta', len(workflows)==15 and not any(p.startswith('.github/') for p in changed))
report={'schema':'round48-final-five-file-independent-exactdiff-review-v1','reviewer':'pr_triage','authors':['todo_audit','root'],'decision':'accepted_scoped_for_normal_progress_PR','started_at_utc':started,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_main':manifest['base_main'],'base_tree':manifest['base_tree'],'published_root_decision_commit':pub['commit'],'candidate_only':True,'candidate_commit':None,'checks_passed':len(checks),'blockers':[],'files':files,'task_changes':rows,'preservation':{'all_192_order_definitions_dependencies':True,'other_180_entire_records_and_raw_fragments':True,'all_old_evidence_and_note_prefixes':True,'original_generator_and_validation_doc':True,'actual_root_field_changes':root_changed,'allowed_navigation_fields':['current_phase','next_task','last_implementation_date'],'current_phase_unchanged':'P8','next_task':'P8-020'},'candidate_counts':{'total':192,'states':states,'remaining':16,'new_in_this_candidate':12,'session_total_if_normally_merged':13},'original_generator_receipts':receipts,'current_S45':s45,'scope':{'actual_generated_views':4,'only_progress_markers_changed_in_three_entrypoints':True,'TODO_other180_sections_byte_equal':True,'source_guard_registry_P_R_G_native_observers_workflows_changed':False,'existing_workflow_metadata':workflows,'CI_note':'15 existing workflow files retained by exact five-doc delta; ordinary CI triggers/gates unchanged. No claim of 19 workflow files or future PR CI passing.','original_measurement_validator_generator_rerun_by_reviewer':False,'publication_and_new_PR_CI':'not yet performed for this candidate; root owns commit/ref/PR and normal CI','task_scope_limits':'Original 47 clauses already independently reviewed and root accepted in published R48. Descriptive N=1 45/85 recovery remains separate from failed Actions42, old 150/1350 studies, paid/live/holdout and release approval.'},'checks':checks}
OUT.mkdir(exist_ok=True)
(OUT/'independent-five-file-exactdiff-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'passed','checks':len(checks),'changed_files':changed,'states':states,'report':identity(OUT/'independent-five-file-exactdiff-review.json')},ensure_ascii=False))
