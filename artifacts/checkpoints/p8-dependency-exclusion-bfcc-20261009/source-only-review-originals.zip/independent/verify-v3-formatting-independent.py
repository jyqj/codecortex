#!/usr/bin/env python3
"""Peer read of formatter-only diff; never executes author main or Rust tools."""
import ast, difflib, hashlib, json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
V3=Path('/dev/shm/todo-audit-H-dependency-exclusion-v3')
V2=Path('/dev/shm/todo-audit-H-dependency-exclusion-v2')
script=(V3/'verify-and-freeze-formatting.py').read_text()
# The pure lexer was read in full: it retains string/char/raw-string/comment
# bytes and token boundaries, including nested comments; it does not parse Rust.
mod=ast.parse(script)
exec(compile(ast.Module(body=[n for n in mod.body if isinstance(n,ast.FunctionDef) and n.name=='tokens'],type_ignores=[]),'<read-only reviewed lexer>','exec'))
expected=[[],['extend','Some','Some','Some','array','new']]
files=[]
for i,row in enumerate(json.loads((V3/'source-manifest.json').read_text())['files']):
    p=row['path'];a=(V2/'candidate'/p).read_bytes();b=(V3/'candidate'/p).read_bytes()
    assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
    assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_blob']
    at=[x['token'] for x in tokens(a.decode())];bt=[x['token'] for x in tokens(b.decode())]
    inserts=[]
    for tag,i1,i2,j1,j2 in difflib.SequenceMatcher(a=at,b=bt,autojunk=False).get_opcodes():
        if tag=='equal':continue
        assert tag=='insert' and i1==i2 and bt[j1:j2]==[',']
        stack=[]
        for index,value in enumerate(bt[:j1]):
            if value in ('(','[','{'):stack.append((value,index))
            elif value in (')',']','}'):assert (stack.pop()[0],value) in [('(',')'),('[',']'),('{','}')]
        op,pos=stack[-1]
        assert bt[j1+1] in (')',']')
        name='array' if op=='[' else bt[pos-1]
        assert name in ('extend','Some','array','new')
        # Reviewed contexts are ordinary argument lists and a >=2-element array;
        # no tuple/grouping change or custom macro-token change is accepted.
        inserts.append({'new_token_index':j1,'context':name,'closing':bt[j1+1]})
    assert [r['context'] for r in inserts]==expected[i]
    stripped=list(bt)
    for r in reversed(inserts):del stripped[r['new_token_index']]
    assert stripped==at
    files.append({'path':p,'after_bytes':len(b),'after_sha256':row['sha256'],'after_git_blob':row['git_blob'],'all_other_tokens_including_literals_and_comments_equal':True,'optional_trailing_commas':inserts})
report={'schema':'independent-v3-manual-format-review-v1','reviewer':'/root/execution_recon','author':'/root/todo_audit','verdict':'accepted_scoped_format_only','method':'Read complete exact diff and pure lexer; independently align actual tokens and validate exactly6 inserted commas in observed ordinary argument/array contexts. Author main never imported/executed. This is static token equivalence, not rustfmt or Rust parsing/compilation.','files':files,'semantic_review_retained':'independent-P3-source-semantics.json','runtime':'not_run','rustfmt':'not_run','counterexample_preserved':True,'TODO_closed':0,'TODO_remaining':29}
with (ROOT/'independent-v3-manual-format-review.json').open('x') as f:json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(report))
