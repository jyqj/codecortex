#!/usr/bin/env python3
"""Provide fixed public inputs for the two unchanged Requests diagnostic tests.

This prepares existing raw and a newly built source-bound product. It does not
rerun the Requests study or claim the historical worker binary was recovered.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import tarfile

PRODUCT = '37dd042eaa1209a86e0cafdcd92ae77e036e76f5'
CORPUS = 'e49f9ada5826b4206d2128f3bfb8d31603ff42fa'
PREFIX = 'crates/cc-eval/benchmarks/public-v19/requests/source'
CHECKPOINT = 'artifacts/checkpoints/public-dev-paired-requests-20261004'
ARCHIVE_SHA = '45ebffc53dc519a8132e886dafec396e532d4ee1515fb99995480dd2696a5d00'
BINDING_SHA = 'c53738c2a8d1e96cb2638d547ebc264d61da03a573e1e0d4580890681bdc4c2d'
RAW_MANIFEST_SHA = '87c3597d5182fcf272f4a5eba34a0fe30632ebc6a8ff0a3337622895e5303a2c'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    require(stat.S_ISREG(path.lstat().st_mode), f'not a regular input: {path}')
    result = hashlib.sha256()
    with path.open('rb') as source:
        while data := source.read(1024 * 1024):
            result.update(data)
    return result.hexdigest()


def safe_relative(value):
    path = PurePosixPath(value)
    require(isinstance(value, str) and path.as_posix() == value and
            not path.is_absolute() and bool(path.parts) and
            '..' not in path.parts and '\\' not in value, 'unsafe input path')
    return Path(*path.parts)


def pinned_json(path, expected):
    require(digest(path) == expected, f'fixed input digest mismatch: {path}')
    return json.loads(path.read_bytes())


def git(root, *arguments):
    return subprocess.check_output(['git', '-C', str(root), *arguments])


def product_snapshot(root, expected):
    actual = {name: digest(root / safe_relative(name)) for name in expected}
    require(actual == expected, 'checkout does not match the fixed product source inputs')
    tracked = git(root, 'ls-files', '-z').decode().split('\0')
    selected = {p for p in tracked if p in ('Cargo.toml', 'Cargo.lock') or
                (p.startswith('crates/') and ('/src/' in p or p.endswith('/Cargo.toml')))}
    require(selected == set(expected), 'fixed product source inventory changed')
    return actual


def save(path, value):
    with path.open('x', encoding='utf-8') as target:
        json.dump(value, target, sort_keys=True, indent=2)
        target.write('\n')


def prepare(args):
    root = args.root.resolve(strict=True)
    corpus_checkout = args.corpus_checkout.resolve(strict=True)
    output = args.output_dir.absolute()
    output.mkdir()  # New directory only; never overwrite prior diagnostic output.
    source_root = output / 'source'
    raw_root = output / 'raw'
    observations = output / 'observations'
    for path in (source_root, raw_root, observations):
        path.mkdir()
    checkpoint = root / CHECKPOINT
    binding = pinned_json(checkpoint / 'binding-candidate.json', BINDING_SHA)
    require(binding['head'] == PRODUCT and len(binding['source_sha256']) == 387,
            'unexpected fixed product binding')
    before = product_snapshot(root, binding['source_sha256'])
    raw_manifest = pinned_json(checkpoint / 'raw-artifact-manifest.json', RAW_MANIFEST_SHA)
    members = raw_manifest['files']
    require(len(members) == 1118 and sum(x['bytes'] for x in members.values()) == 34564799,
            'fixed raw member inventory changed')
    archive = checkpoint / 'paired-requests-raw.tar.gz'
    require(archive.stat().st_size == 4758303 and digest(archive) == ARCHIVE_SHA and
            raw_manifest['archive_sha256'] == ARCHIVE_SHA, 'fixed raw archive changed')
    require(shutil.disk_usage(output).free >= 34564799 + 64 * 1024 * 1024,
            'insufficient room for the fixed raw fixture and reserve')
    seen = set()
    with tarfile.open(archive, 'r:gz') as original:
        for member in original:
            relative = safe_relative(member.name)
            if member.isdir():
                continue
            require(member.isfile() and member.name in members and member.name not in seen,
                    'unknown, duplicate or non-regular raw member')
            expected = members[member.name]
            require(member.size == expected['bytes'], 'raw member size mismatch')
            target = raw_root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            stream = original.extractfile(member)
            require(stream is not None, 'missing raw member body')
            h = hashlib.sha256()
            copied = 0
            with target.open('xb') as sink:
                while data := stream.read(1024 * 1024):
                    copied += len(data)
                    require(copied <= expected['bytes'], 'oversized raw member')
                    h.update(data)
                    sink.write(data)
            require(copied == expected['bytes'] and h.hexdigest() == expected['sha256'],
                    'raw member digest mismatch')
            target.chmod(0o444)
            seen.add(member.name)
    require(seen == set(members), 'missing fixed raw members')
    require(git(corpus_checkout, 'rev-parse', 'HEAD').decode().strip() == CORPUS,
            'wrong original source checkout')
    source_files = {}
    for record in git(corpus_checkout, 'ls-tree', '-rz', 'HEAD', '--', PREFIX).split(b'\0'):
        if not record:
            continue
        left, name = record.split(b'\t', 1)
        mode, kind, oid = left.decode().split()
        name = name.decode()
        require(mode == '100644' and kind == 'blob' and name.startswith(PREFIX + '/'),
                'unsupported original corpus entry')
        relative = name[len(PREFIX) + 1:]
        data = (corpus_checkout / safe_relative(name)).read_bytes()
        require(hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest() == oid,
                'original corpus Git bytes mismatch')
        target = source_root / safe_relative(relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as sink:
            sink.write(data)
        target.chmod(0o444)
        source_files[relative] = {'bytes': len(data), 'git_blob': oid,
                                  'sha256': hashlib.sha256(data).hexdigest()}
    require(len(source_files) == 20, 'unexpected Requests original source inventory')
    for side in ('base', 'candidate'):
        for mode in ('native', 'compat'):
            original = json.loads((raw_root / side / mode / 'manifest.json').read_bytes())
            inputs = original['input']['files']
            require(len(inputs) == 20 and {x['path'] for x in inputs} == set(source_files),
                    'original replay source set mismatch')
            require(all(source_files[x['path']]['bytes'] == x['bytes'] for x in inputs),
                    'original replay source size mismatch')
    # The unchanged Rust replay still checks every original per-file BLAKE3 and
    # all 1044 rows, fields, statuses and scores. No Python replacement scorer.
    save(output / 'input-receipt.json', {'fixed_product': PRODUCT, 'checkout':
         git(root, 'rev-parse', 'HEAD').decode().strip(), 'source_sha256': before,
         'corpus_commit': CORPUS, 'corpus_files': source_files,
         'raw_archive_sha256': ARCHIVE_SHA, 'raw_members': len(seen),
         'raw_bytes': 34564799, 'historical_worker_binary_recovered': False})
    target = output / 'target'
    command = ['cargo', 'build', '--locked', '-p', 'cc-server', '--bin', 'codecortex',
               '--target-dir', str(target), '--message-format=json-render-diagnostics']
    with (output / 'cargo-build.jsonl').open('xb') as stdout, \
            (output / 'cargo-build.stderr').open('xb') as stderr:
        result = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr, timeout=900)
    require(result.returncode == 0, 'fixed-source product build failed; original logs retained')
    events = [json.loads(line) for line in (output / 'cargo-build.jsonl').read_text().splitlines()]
    finished = [e for e in events if e.get('reason') == 'build-finished']
    require(len(finished) == 1 and finished[0]['success'] is True and events[-1] == finished[0],
            'Cargo did not finish successfully')
    artifacts = [e for e in events if e.get('reason') == 'compiler-artifact' and
                 e.get('target', {}).get('name') == 'codecortex' and e.get('executable')]
    require(len(artifacts) == 1, 'expected one product binary artifact')
    artifact = artifacts[0]
    binary = Path(artifact['executable']).resolve(strict=True)
    require(artifact['target']['kind'] == ['bin'] and artifact['fresh'] is False and
            Path(artifact['manifest_path']).resolve() == root / 'crates/cc-server/Cargo.toml' and
            binary == target / 'debug/codecortex', 'wrong product artifact origin')
    after = product_snapshot(root, before)
    receipt = {'fixed_product_source': PRODUCT, 'command': command, 'returncode': result.returncode,
               'cargo_artifact': artifact, 'source_before': before, 'source_after': after,
               'binary': {'path': str(binary), 'bytes': binary.stat().st_size, 'sha256': digest(binary)},
               'rustc_verbose': subprocess.check_output(['rustc', '-Vv'], text=True),
               'cargo_verbose': subprocess.check_output(['cargo', '-Vv'], text=True),
               'historical_worker_binary_recovered': False,
               'scope': 'New fixed-source CI binary for self-authored analogue; historical raw results remain unchanged.'}
    save(output / 'build-receipt.json', receipt)
    environment = {'REQUESTS_ZERO_PRODUCT_BINARY': str(binary), 'REQUESTS_ZERO_OUTPUT': str(observations),
                   'REQUESTS_ZERO_RAW': str(raw_root), 'REQUESTS_ZERO_SOURCE': str(source_root)}
    require(all('\n' not in v and '\r' not in v for v in environment.values()), 'invalid environment path')
    with args.github_env.open('a', encoding='utf-8') as sink:
        for key, value in environment.items():
            sink.write(f'{key}={value}\n')
    print(json.dumps({'status': 'inputs_ready', 'source_inputs': 387, 'raw_members': 1118,
                      'requests_source_files': 20, 'binary_sha256': receipt['binary']['sha256'],
                      'historical_worker_binary_recovered': False}, sort_keys=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--corpus-checkout', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--github-env', type=Path, required=True)
    prepare(parser.parse_args())
