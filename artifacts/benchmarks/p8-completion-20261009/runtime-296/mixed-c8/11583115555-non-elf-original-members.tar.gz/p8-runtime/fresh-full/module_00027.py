def stable_00027():
    return 27
