from pathlib import Path
import hashlib,json,subprocess
R=Path('/workspace/scratch/28fef0db5e01');D=R/'acceptance-review/round9-seal-finalization';G=R/'codecortex';S='fec0698c7fa4d76076b828cc17cf277ad8b307e0'
def git(*a):return subprocess.check_output(['git','-C',str(G),*a])
files=[p.decode() for p in git('ls-tree','-r','--name-only',S,'scripts').splitlines() if p.endswith(b'.py')]
records=[]
for p in files:
 b=git('show',S+':'+p)
 for side in ['candidate','baseline']:
  q=D/side/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 records.append({'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
f=D/'candidate/scripts/p8_runtime.py';s=f.read_text();assert hashlib.sha256(f.read_bytes()).hexdigest()=='bc33ed073a2e035912a4d6f1794ceec8b836243c2bbb46c8a4dddfcdda791559'
s=s.replace('from p8_cold_build import digest, new_directory, write_json','from p8_cold_build import digest, json_bytes, new_directory, write_json')
helper='''def finalize_artifacts(output, report, writers_stopped):
    """Keep a failed sealing attempt distinct from its pre-seal observation."""
    report_path = output / "report.json"
    before = json_bytes(report)
    report_path.write_bytes(before)
    if not writers_stopped:
        return
    phase = "seal_output"
    try:
        seal_output(output)
        phase = "verify_output"
        verify_output(output)
    except (Exception, KeyboardInterrupt) as error:
        failure = f"{type(error).__name__}: {error}"
        report.update(status="failed", exit_code=2, artifact_seal=None,
                      artifact_seal_status="unsealed_finalization_error",
                      finalization_error=dict(phase=phase, error=failure))
        if isinstance(error, KeyboardInterrupt):
            report["interrupted"] = True
        try:
            # One exclusive copy, never a retry series. Preserve the exact bytes
            # submitted to the failed seal before replacing the final report.
            original = output / "report-before-seal-failure.json"
            with original.open("xb") as stream:
                stream.write(before)
            report["pre_seal_report"] = dict(path=original.name, bytes=len(before),
                                             sha256=hashlib.sha256(before).hexdigest())
            failed_seal = output / "seal.json"
            if failed_seal.exists():
                # Leave an already-written (possibly partial) seal untouched.
                # It describes the failed attempt, never the final archive.
                report["failed_artifact_seal"] = dict(path=failed_seal.name,
                    bytes=failed_seal.stat().st_size, sha256=digest(failed_seal),
                    scope="original failed sealing attempt; not a validated archive")
            write_json(report_path, report)
        except (Exception, KeyboardInterrupt) as retention_error:
            # A read-only/lost output or occupied backup must not destroy the
            # old report or trigger unbounded backups. main retains CLI exit 2.
            raise RuntimeError(
                f"artifact finalization failed ({phase}: {failure}); "
                "final status failed/unsealed; could not preserve/update failure metadata: "
                f"{type(retention_error).__name__}: {retention_error}") from error


'''
needle='def main():\n';assert s.count(needle)==1;s=s.replace(needle,helper+needle)
old='''        write_json(out / "report.json", report)
        if writers_stopped:
            seal_output(out)
            verify_output(out)
''';assert s.count(old)==1;s=s.replace(old,'        finalize_artifacts(out, report, writers_stopped)\n')
f.write_text(s)
(D/'baseline-source-manifest.json').write_text(json.dumps({'source_commit':S,'runtime_sha256':'bc33ed073a2e035912a4d6f1794ceec8b836243c2bbb46c8a4dddfcdda791559','files':records},indent=2)+'\n')
print(json.dumps({'candidate_runtime_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'copied_python_files':len(records)}))
