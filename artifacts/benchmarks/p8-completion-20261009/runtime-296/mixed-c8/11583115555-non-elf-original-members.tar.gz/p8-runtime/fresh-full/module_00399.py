def stable_00399():
    return 399
