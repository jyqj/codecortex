#!/usr/bin/env python3
"""Independent fixed f8 mixed-matrix data audit. Imports only our own review code."""
from pathlib import Path
from collections import Counter
import datetime
import hashlib
import json
import math
import traceback
import review_helpers as a

BASE = Path(__file__).resolve().parent
HEAD = 'fec0698c7fa4d76076b828cc17cf277ad8b307e0'
REPORT = {'schema_version':1,'reviewer':'/root/runtime_review','state':'incomplete',
          'scope':'Original local M5 mixed C1/4/8/16 artifacts, read-only; root sole executor, no reviewer product run',
          'checks':[],'artifacts':{},'missing_artifacts':[]}
a.REPORT = REPORT
CURRENT = None
old_check = a.check


def check(name,value,detail=None):
    result = old_check(name,value,detail)
    REPORT['checks'][-1]['artifact_id'] = CURRENT
    return result


a.check = check


def save():
    (BASE/'mixed-independent-report.json').write_text(json.dumps(REPORT,ensure_ascii=False,sort_keys=True,indent=2)+'\n')


def call_occupancy(ops):
    events = [(r['call_started_ns'],1,r['operation']) for r in ops] + [(r['finished_ns'],-1,r['operation']) for r in ops]
    current = Counter(read=0,build=0)
    peak = 0
    by_kind = Counter(read=0,build=0)
    overlap = False
    for _,delta,kind in sorted(events):
        current[kind] += delta
        peak = max(peak,sum(current.values()))
        by_kind[kind] = max(by_kind[kind],current[kind])
        overlap |= current['read'] > 0 and current['build'] > 0
    return {'peak':peak,'by_kind_peak':dict(by_kind),'read_build_overlap':overlap,'remaining':dict(current)}


def runtime(meta,c):
    z,hashes,out = a.archive(meta)
    with z:
        out['sealed_files'] = {'build':a.seal(z,hashes,'p8-build/'),'runtime':a.seal(z,hashes,'p8-runtime/')}
        receipt,plan,report = [a.js(z,p) for p in ('p8-build/build-receipt.json','p8-runtime/plan.json','p8-runtime/report.json')]
        out['source'] = a.source(receipt['source_before'],HEAD,'mixed')
        out['observer'] = a.observer(z,hashes,receipt['observer_before'],HEAD,'p8-build/observer-source/','mixed')
        check('identity_unchanged',receipt['source_before'] == receipt['source_after'] == plan['source'] == plan['build_identity']['source']
              and receipt['observer_before'] == receipt['observer_after'] == plan['build_identity']['observer']
              and receipt['toolchain_before'] == receipt['toolchain_after'] == plan['build_identity']['toolchain']
              and plan['build_identity'] == report['final_build_verification'])
        check('copied_build_receipts',all(hashes['p8-runtime/build-evidence/'+p] == hashes['p8-build/'+p] == entry
              for p,entry in plan['retained_build_evidence'].items())
              and plan['build_identity']['build_seal_sha256'] == hashes['p8-build/seal.json']['sha256']
              and plan['build_identity']['receipt_sha256'] == hashes['p8-build/build-receipt.json']['sha256'])
        events = [json.loads(x) for x in a.member(z,'p8-build/product-build.jsonl').splitlines()]
        for name,r in receipt['artifacts'].items():
            e=r['cargo_artifact']
            check('fresh_release_binary/'+name,e in events and e['fresh'] is False and e['features'] == []
                  and e['profile']['opt_level'] == '3' and e['profile']['debug_assertions'] is False
                  and e['target']['name'] == name and e['target']['kind'] == ['bin']
                  and r['binary_sha256'] == r['copy_source']['sha256'] == hashes['p8-build/'+name]['sha256']
                  and r['binary_bytes'] == r['copy_source']['bytes'] == hashes['p8-build/'+name]['bytes']
                  and r['copy_source']['path'] == e['executable'])
        check('fresh_build_invocation_and_logs',receipt['build_exit_code'] == 0 and receipt['target_initially_absent'] is True
              and all(f in receipt['build_command'] for f in ('--release','--locked','--offline','--no-default-features'))
              and receipt['cargo_log_sha256'] == hashes['p8-build/product-build.jsonl']['sha256']
              and receipt['stderr_sha256'] == hashes['p8-build/product-build.stderr']['sha256'])
        for f,p in [('raw_sha256','raw.jsonl'),('plan_sha256','plan.json'),('parity_sha256','parity.json')]:
            check('report_hash/'+p,report[f] == hashes['p8-runtime/'+p]['sha256'])
        rows=[json.loads(x) for x in a.member(z,'p8-runtime/raw.jsonl').splitlines()]
        ops=[r for r in rows if r['kind']=='operation'];rs=[r for r in rows if r['kind']=='resources']
        ordered=sorted(ops,key=lambda r:r['id']);n=plan['operations']
        check('full_original_offered_denominator',n == len(ops) == report['offered'] == 900
              and [r['id'] for r in ordered] == list(range(n))
              and plan['concurrency'] == c and plan['profile'] == report['profile'] == 'mixed'
              and plan['files'] == 1000 and plan['offer_schedule'] == 'fixed_concurrency_sized_bursts'
              and plan['offer_interval_ms'] == 500 and plan['queue_capacity'] == 128)
        check('schedule_and_actual_terminal_timings',all(r['scheduled_ns'] == ordered[0]['scheduled_ns'] + r['id']//c*c*500_000_000
              and r['scheduled_ns'] <= r['offered_ns'] <= r['started_ns'] <= r['call_started_ns'] <= r['finished_ns']
              and r['operation'] == ('build' if r['id']%3==0 else 'read') for r in ops))
        outcomes=dict(Counter(r['status'] for r in ops))
        check('original_outcomes_and_report_exit',outcomes == report['outcomes'] == {'success':900}
              and report['status'] == 'passed_observation' and report['exit_code'] == 0 and report['failures'] == [])
        builds=[r for r in ops if r['operation']=='build'];reads=[r for r in ops if r['operation']=='read']
        mutations=sorted(builds,key=lambda r:r['mutation_ordinal'])
        check('all_original_valid_build_and_read_responses',len(builds)==300 and len(reads)==600
              and all(r['response']['parse_errors']==[] and r['response']['resolution_freshness']['complete'] is True for r in builds)
              and all(any(h.get('name')=='p8_runtime_stable_signal' and h.get('file_path')=='stable.py' for h in r['response']) for r in reads))
        check('complete_mutation_cycle',[r['mutation_ordinal'] for r in mutations]==list(range(300))
              and all(r['mutation']['action']==a.ACTIONS[r['mutation_ordinal']%6] for r in mutations))
        calls=call_occupancy(ops);executor=a.occupancy(ops,'started_ns','finished_ns');waiting=a.occupancy(ops,'offered_ns','started_ns')
        check('actual_concurrency_and_overlap',calls['peak']==report['actual_concurrency']['maximum']
              and calls['read_build_overlap']==report['actual_concurrency']['read_build_overlap']
              and (c==1 or calls['read_build_overlap']) and calls['peak']<=c and executor[0]<=c
              and executor[1]==0 and all(v==0 for v in calls['remaining'].values()))
        endpoint=next(r['response'] for r in rows if r['kind']=='endpoint_status')
        check('final_admission_and_pins_drained',all(endpoint['query_execution'][k]==0 for k in ('async_admitted','async_in_flight','cpu_admitted','cpu_in_flight','rejected'))
              and endpoint['retrieval']['query_pins']==0)
        branches=[r['mutation'] for r in mutations if r['mutation']['action']=='real_git_branch_switch']
        check('actual_branch_switch_receipts',len(branches)==report['real_branch_switches']==50
              and all(b['exit_code']==0 and b['branch']==('p8-b' if i%2==0 else 'p8-a') and 'core.hooksPath=/dev/null' in b['argv'] for i,b in enumerate(branches)))
        compactions=a.member(z,'p8-runtime/product/product-stderr.log').count(b'resolver catalog dropped for tombstone compaction')
        check('catalog_compaction_raw_log',compactions==report['observed_catalog_compactions'])
        originals={}
        for side in ('project','fresh-full'):
            prefix='p8-runtime/'+side+'/'
            originals[side]={p[len(prefix):]:v for p,v in hashes.items() if p.startswith(prefix) and not p.startswith(prefix+'.codecortex/')}
        check('fresh_full_source_and_git_equal',originals['project']==originals['fresh-full'])
        rpc=a.audit_rpc(z,'p8-runtime/product');full_rpc=a.audit_rpc(z,'p8-runtime/full-product')
        check('no_incremental_side_repair',len(rpc['index_calls'])==301 and rpc['index_calls'][0]['arguments']['full'] is True
              and all(r['arguments']['full'] is False for r in rpc['index_calls'][1:])
              and len(full_rpc['index_calls'])==1 and full_rpc['index_calls'][0]['arguments']['full'] is True)
        initial=next(r['report'] for r in rows if r['kind']=='initial_build');full=next(r['report'] for r in rows if r['kind']=='full_control')
        public=next(r for r in rows if r['kind']=='endpoint_public')
        check('all_raw_build_responses_match_wire',rpc['response_hashes']['index']==Counter(a.sha(a.canonical(r['response'])) for r in builds)+Counter([a.sha(a.canonical(initial))])
              and full_rpc['response_hashes']['index']==Counter([a.sha(a.canonical(full))]))
        check('all_raw_read_responses_match_wire',rpc['response_hashes']['search']==Counter(a.sha(a.canonical(r['response'])) for r in reads)+Counter([a.sha(a.canonical(public['incremental']))])
              and full_rpc['response_hashes']['search']==Counter([a.sha(a.canonical(public['full']))]) and public['incremental']==public['full'])
        processes={side:a.js(z,'p8-runtime/'+side+'/process.json') for side in ('product','full-product')}
        check('owned_processes_closed_and_server_pid',all(p['cleanup']=='completed' and p['exit_code']==p['expected_exit_code']==0
              and p['binary_sha256']==hashes['p8-build/codecortex']['sha256'] for p in processes.values())
              and {r['server']['pid'] for r in rs}=={processes['product']['pid']})
        statistics=a.js(z,'p8-runtime/statistics.json')
        check('two_retained_statistical_replays',a.member(z,'p8-runtime/statistics.json')==a.member(z,'p8-runtime/statistics-replay.json')
              and statistics['raw_sha256']==hashes['p8-runtime/raw.jsonl']['sha256']
              and statistics['plan_sha256']==hashes['p8-runtime/plan.json']['sha256']
              and statistics['replay_binary_sha256']==hashes['p8-build/p8-runtime-statistics']['sha256']
              and report['statistics']['sha256']==hashes['p8-runtime/statistics.json']['sha256']
              and all(r['exit_code']==0 for r in a.js(z,'p8-runtime/statistics-execution.json')))
        groups=[]
        for g in statistics['by_operation']+statistics['by_build_mutation']:
            selected=[r for r in ops if r['operation']==g['operation'] and (g['mutation_action'] is None or r.get('mutation',{}).get('action')==g['mutation_action'])]
            m=len(selected);elapsed=[(r['finished_ns']-r['offered_ns'])//1000 for r in selected]
            success=[(r['finished_ns']-r['offered_ns'])//1000 for r in selected if r['status']=='success']
            views={'all_attempt_offered_to_terminal':(elapsed,m),'successful_offered_to_terminal':(success,len(success)),
                   'scheduled_to_terminal':([(r['finished_ns']-r['scheduled_ns'])//1000 for r in selected],m),
                   'client_dispatch_wait':([(r['started_ns']-r['offered_ns'])//1000 for r in selected],m),
                   'write_admission_and_preparation':([(r['call_started_ns']-r['started_ns'])//1000 for r in selected],m),
                   'client_call_to_terminal_including_validation':([(r['finished_ns']-r['call_started_ns'])//1000 for r in selected],m)}
            check('independent_statistics/'+g['operation']+'/'+str(g['mutation_action']),g['recorded_samples']==g['expected_samples_in_group']==m
                  and all(g[k]==a.timing(v,e) for k,(v,e) in views.items()))
            groups.append({'operation':g['operation'],'mutation_action':g['mutation_action'],'n':m,'offered_to_terminal':a.timing(elapsed,m)})
        latency={}
        for kind,selected in [('all',ops),('read',reads),('build',builds)]:
            values=[r['finished_ns']-r['offered_ns'] for r in selected]
            item={'n':len(values),'p50_ns':a.nearest(values,.5),'p95_ns':a.nearest(values,.95),'p99_ns':a.nearest(values,.99),'maximum_ns':max(values)}
            claim=report['latency'] if kind=='all' else report['latency_by_operation'][kind]
            check('legacy_all_attempt_latency/'+kind,all(claim[k]==v for k,v in item.items()))
            latency[kind]=item
        parity=a.js(z,'p8-runtime/parity.json')
        check('original_oracle_success',parity['exit_code']==0 and parity['tables']==a.TABLES
              and parity['comparison']['equal'] is True and parity['comparison']['different_tables']==[]
              and next(r for r in rows if r['kind']=='oracle_process')['exit_code']==0)
        a.sqlite_compare(z,out,parity)
        out.update({'profile':'mixed','concurrency_cap':c,'operations':len(ops),'read_operations':len(reads),'build_operations':len(builds),
                    'outcomes':outcomes,'observed_work_ns':report['observed_work_ns'],
                    'successful_per_second_descriptive':len(ops)/(report['observed_work_ns']/1e9),
                    'reported_actual_concurrency':report['actual_concurrency'],'independent_call_occupancy':calls,
                    'observed_executor_peak':executor[0],'observed_waiting_for_executor_peak':waiting[0],
                    'queue_wait_ns':{'maximum':max(r['started_ns']-r['offered_ns'] for r in ops),'p95':a.nearest([r['started_ns']-r['offered_ns'] for r in ops],.95)},
                    'latency':latency,'mutation_counts':dict(Counter(r['mutation']['action'] for r in mutations)),
                    'branch_switches':len(branches),'catalog_compactions':compactions,'endpoint_query_execution':endpoint['query_execution'],
                    'raw_event_counts':dict(Counter(r['kind'] for r in rows)),'resource_samples':len(rs),
                    'sampled_query_execution_maxima':{k:max(r['query_execution'][k] for r in rs) for k in rs[0]['query_execution'] if k!='completed'},
                    'rss':report['rss'],'processes':processes,'statistic_groups':groups,
                    'raw_sha256':hashes['p8-runtime/raw.jsonl']['sha256'],'report_sha256':hashes['p8-runtime/report.json']['sha256'],
                    'statistics_sha256':hashes['p8-runtime/statistics.json']['sha256'],
                    'rpc':{k:v for k,v in rpc.items() if k not in ('response_hashes','index_calls')},
                    'scope_limits':['Original local M5 execution on shared host overlapping M5soak; no isolated performance or earlier-source relabeling.','C is a client cap; actual overlapping client calls and sampled product executor occupancy are separate.','Timing groups are descriptive; each mutation has50 samples and retains insufficient_for_tail_claim rather than pooling across C or mutation.','Backfill uses the separately reviewed seeded original worker control; default stdio mixed profile has semantic disabled.']})


def main():
    global CURRENT
    REPORT['started_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    REPORT['review_repository_head']=a.git('rev-parse','HEAD').decode().strip()
    api=json.loads((BASE/'api-runtime-matrix.json').read_text())
    by_name={v['name']:v for v in api['artifacts']}
    for c in (1,4,8,16):
        meta=by_name['p8-mixed-c'+str(c)+'-'+HEAD]
        CURRENT=meta['id']
        path=a.ORIGINALS/str(CURRENT)/(str(CURRENT)+'.zip')
        if not path.is_file():
            REPORT['missing_artifacts'].append({'concurrency':c,'api_identity':meta,'expected_local_path':str(path),'state':'not_available_not_audited'})
            continue
        runtime(meta,c)
        save()
    REPORT['failed_checks']=[r for r in REPORT['checks'] if not r['passed']]
    REPORT['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    REPORT['state']='review_findings' if REPORT['failed_checks'] else ('incomplete_matrix_missing_original_artifact' if REPORT['missing_artifacts'] else 'complete_scoped_original_mixed_matrix_verified')
    REPORT['original_todos_completed']=0
    REPORT['remaining_todos_authority_unchanged']=29
    save()
    print(json.dumps({'state':REPORT['state'],'checks':len(REPORT['checks']),'failed_checks':REPORT['failed_checks'],
                      'missing_artifacts':[r['api_identity']['id'] for r in REPORT['missing_artifacts']],
                      'cells':[{'c':r['concurrency_cap'],'offered':r['operations'],'peak':r['independent_call_occupancy']['peak'],'overlap':r['independent_call_occupancy']['read_build_overlap']} for r in REPORT['artifacts'].values()]},ensure_ascii=False))


if __name__=='__main__':
    try:
        main()
    except Exception as error:
        REPORT['state']='review_harness_incomplete';REPORT['error']=type(error).__name__+': '+str(error)
        save()
        traceback.print_exc()
        raise SystemExit(2)
