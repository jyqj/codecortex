def stable_00364():
    return 364
