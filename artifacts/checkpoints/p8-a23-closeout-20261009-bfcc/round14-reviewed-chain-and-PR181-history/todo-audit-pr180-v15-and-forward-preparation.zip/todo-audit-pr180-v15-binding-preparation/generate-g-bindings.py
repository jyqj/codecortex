#!/usr/bin/env python3
"""Generate two binding files outside the source tree from a completed independent R.

This mechanical preparation does not sign a review or execute source admission.
The unchanged original v15 CLI must still verify actual Git P/R/G identities.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
PRODUCT = 'c92eb5ac7ece70d1f62271d7e2dacac513c285b5'
PRODUCT_TREE = '9ae248f8e0c42a8a7389e26e3f44710dfb029640'
BASE = '7354db236c9d9850a75f31672697ae9eab44565e'
REVIEW_PATH = 'artifacts/checkpoints/p8-public-api-merge-bfcc-20261009/independent-source-review.json'
SCOPE = 'independently_reviewed_source_and_validation_inputs'
PINS = ('PRODUCT', 'REVIEW', 'REVIEW_PATH', 'REGISTRY_SHA256')
AUTHORS = {'/root/todo_audit', 'todo_audit', '/root', 'root'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def required(condition, message):
    if not condition:
        raise ValueError(message)

def prepare(review_file, review_commit):
    required(re.fullmatch('[0-9a-f]{40}', review_commit) is not None, 'R must be a full immutable commit SHA')
    inputs = json.loads((HERE / 'actual-P-mechanical-review-inputs.json').read_bytes())
    required(inputs['source'] == PRODUCT and inputs['source_tree'] == PRODUCT_TREE, 'wrong actual P inputs')
    required(inputs['counts'] == {'complete_inputs': 1093, 'paths': 59, 'validation_inputs': 139}, 'wrong current counts')
    raw = review_file.read_bytes()
    review = json.loads(raw)
    required(review.get('source') == PRODUCT and review.get('base') == BASE, 'review must bind this actual P and historical BASE')
    required(review.get('verdict') == 'accepted_scoped' and review.get('scope') == SCOPE,
             'independent reviewer has not accepted the original source-only scope')
    reviewers = review.get('independent_reviewers')
    required(isinstance(reviewers, list) and bool(reviewers)
             and all(isinstance(v, str) and v.strip() for v in reviewers), 'missing actual independent reviewer')
    required(not AUTHORS.intersection(reviewers), 'this fix/integration author cannot sign the independent R')
    required(review.get('unresolved_blockers') == [], 'independent source review has unresolved or unspecified blockers')
    required(review.get('paths') == inputs['paths'], 'all 59 exact before/after records must match actual P')
    required(review.get('complete_inputs') == inputs['complete_inputs'], 'all 1093 product hashes must match')
    required(review.get('validation_inputs') == inputs['validation_inputs'], 'all 139 validation hashes must match')
    if 'source_tree' in review:
        required(review['source_tree'] == PRODUCT_TREE, 'review tree does not match actual P')

    registry = json.loads((HERE / 'original-4652-registry.json').read_bytes())
    # Keep every other original identity/scope field intact.
    registry.update(product_source=PRODUCT, review_source=review_commit,
                    review_sha256=sha(raw), complete_inputs=inputs['complete_inputs'],
                    delta=inputs['paths'], validation_inputs=inputs['validation_inputs'])
    registry_raw = (json.dumps(registry, indent=2, sort_keys=True) + '\n').encode()
    guard_before = (HERE / 'original-4652-guard.py').read_text()
    guard = guard_before
    values = {'PRODUCT': PRODUCT, 'REVIEW': review_commit,
              'REVIEW_PATH': REVIEW_PATH, 'REGISTRY_SHA256': sha(registry_raw)}
    for name, value in values.items():
        guard, count = re.subn('^' + name + r' = "[^"]*"$', name + ' = ' + json.dumps(value), guard, flags=re.M)
        required(count == 1, 'expected exactly one original pin: ' + name)
    normalize = lambda text: re.sub(r'^(PRODUCT|REVIEW|REVIEW_PATH|REGISTRY_SHA256) = .*$', r'\1 = <PIN>', text, flags=re.M)
    required(normalize(guard) == normalize(guard_before), 'guard changed beyond the four pins')
    before_lines, after_lines = guard_before.splitlines(), guard.splitlines()
    required(len(before_lines) == len(after_lines), 'guard line count changed')
    changed = [a.split(' = ')[0] for a,b in zip(before_lines,after_lines) if a != b]
    required(set(changed) == set(PINS) and len(changed) == 4, 'expected exactly four changed pin lines')
    return registry_raw, guard.encode(), {
        'kind': 'mechanically_generated_G_binding_files_only',
        'product': PRODUCT, 'product_tree': PRODUCT_TREE, 'base': BASE,
        'review': review_commit, 'review_path': REVIEW_PATH,
        'canonical_review_file': str(review_file), 'review_bytes': len(raw), 'review_sha256': sha(raw),
        'reviewers_recorded_by_the_independent_review': reviewers,
        'registry_bytes': len(registry_raw), 'registry_sha256': sha(registry_raw),
        'guard_bytes': len(guard.encode()), 'guard_sha256': sha(guard.encode()),
        'changed_guard_lines': changed, 'counts': inputs['counts'],
        'review_or_source_admission_signed_by_this_generator': False,
        'actual_R_blob_and_git_chain_still_checked_by_original_v15': True,
        'runtime_performance_task_release_credit': False,
    }

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--review-file', type=Path, required=True)
    parser.add_argument('--review-commit', required=True)
    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument('--output-directory', type=Path)
    target.add_argument('--verify-existing-directory', type=Path,
                        help='read-only comparison with an already installed root containing scripts/')
    args = parser.parse_args()
    registry, guard, receipt = prepare(args.review_file, args.review_commit)
    if args.verify_existing_directory:
        target = args.verify_existing_directory
        required((target / 'scripts/reviewed-source-registry-v15.json').read_bytes() == registry,
                 'installed registry differs from the exact generated bytes')
        required((target / 'scripts/verify_reviewed_source_v15.py').read_bytes() == guard,
                 'installed guard differs from the four-pin generated bytes')
        receipt['mode'] = 'read_only_installed_byte_comparison'
    else:
        target = args.output_directory
        required(not target.exists(), 'output must be a new directory; never overwrite a source or prior attempt')
        (target / 'scripts').mkdir(parents=True)
        (target / 'scripts/reviewed-source-registry-v15.json').write_bytes(registry)
        (target / 'scripts/verify_reviewed_source_v15.py').write_bytes(guard)
        receipt['mode'] = 'new_staging_directory_only'
        (target / 'generation-receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print(json.dumps(receipt, sort_keys=True))

if __name__ == '__main__':
    main()
